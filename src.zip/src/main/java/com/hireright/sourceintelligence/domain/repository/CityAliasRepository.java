package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.CityAliasMapping;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CityAliasRepository extends MongoRepository<CityAliasMapping, String> {

    @Query("{ 'country': ?0, $or: [ { 'city': { $regex: ?1, $options: 'i' } }, { 'aliases': { $regex: ?1, $options: 'i' } } ] }")
    CityAliasMapping findByCountryAndCityOrAliases(String country, String city);

}
