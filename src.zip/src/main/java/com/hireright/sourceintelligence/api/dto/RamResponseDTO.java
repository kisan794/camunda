package com.hireright.sourceintelligence.api.dto;

import lombok.Data;

@Data
public class RamResponseDTO {
    private SourceOrganizationDTO currentSource;
    private SourceOrganizationDTO approvedSource;
}
