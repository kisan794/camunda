package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.reports.dto.MetaDTO;

import java.util.ArrayList;
import java.util.List;

import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.AUTO_MATCH;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MetaData.*;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MetaData.ACTION;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MetaData.CHANGE_TYPE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MetaData.CREATED_BY;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.ReportTypes.*;

public class ReportUtils {

    private ReportUtils() {
        throw new IllegalStateException("Utility class");
    }

    public static List<MetaDTO> getMetaDataByReport(String reportType){
        List<MetaDTO> metaDTOList = new ArrayList<>();
        String[] metaData = metaDataByReportType(reportType);
        for (String s : metaData) {
            String key = convertToReadableFormat(s);
            if(s.equals(LAST_USED)){
                s = USED_DATE;
            }
            if(reportType.equals(DELETE_SOURCE_REPORT)){
                if(s.equals(SOURCE_NAME)){
                    s = ORG_NAME;
                }
                if(s.equals(DELETED_BY)){
                    s = APPROVED_BY;
                }
                if(s.equals(DELETED_DATE)){
                    s = USED_DATE;
                }
            }else if(reportType.equals(APPROVAL_TAT)){
                if(s.equals(REVIEWER_NAME)){
                    s = APPROVED_BY;
                }else if(s.equals(ORIGINATOR_NAME)){
                    s = CREATED_BY;
                }else if(s.equals(CHANGE_TYPE)){
                    s = ACTION;
                }
            }
            metaDTOList.add(new MetaDTO(key, s));
        }
        return metaDTOList;
    }

    private static String[] metaDataByReportType(String reportType){
        return switch (reportType) {
            case CONTACT_UTILIZATION -> CONTACT_UTILIZATION_META_DATA;
            case AUTO_MATCH, ReportConstants.ReportTypes.AUTO_MATCH -> AUTO_MATCH_META_DATA;
            case APPROVAL_TAT -> APPROVAL_TAT_META_DATA;
            case SOURCE_INFORMATION -> SOURCE_INFORMATION_META_DATA;
            case DELETE_SOURCE_REPORT -> DELETE_META_DATA;
            case SOURCE_INFORMATION_REVIEWER -> SOURCE_INFORMATION_REVIEWER_META_DATA;
            case SOURCE_INFORMATION_OPERATOR_REVIEWER -> SOURCE_INFORMATION_OPERATOR_REVIEWER_META_DATA;
            default -> DEFAULT_META_DATA;
        };
    }
    private static String convertToReadableFormat(String input) {
        return input.replace("_", " ");
    }

}
