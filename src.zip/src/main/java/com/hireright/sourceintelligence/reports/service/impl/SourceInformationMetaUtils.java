package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.reports.dto.MetaDTO;
import com.hireright.sourceintelligence.reports.dto.NestedMetaDTO;

import java.util.ArrayList;
import java.util.List;

public class SourceInformationMetaUtils {

    private SourceInformationMetaUtils() {
    }

    public static List<NestedMetaDTO> getOperatorMetadata() {
        List<NestedMetaDTO> metaList = new ArrayList<>();

        metaList.add(NestedMetaDTO.builder()
                .header("Operator Name")
                .accessorKey("Operator_Name")
                .build());

        List<NestedMetaDTO> addedColumns = new ArrayList<>();
        addedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("added.new").build());
        addedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("added.inProgress").build());
        addedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("added.onHold").build());
        addedColumns.add(NestedMetaDTO.builder().header("Rejected").accessorKey("added.cancelled").build());
        addedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("added.completed").build());
        addedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("added.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Added")
                .accessorKey("added")
                .columns(addedColumns)
                .build());

        List<NestedMetaDTO> changedColumns = new ArrayList<>();
        changedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("changed.new").build());
        changedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("changed.inProgress").build());
        changedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("changed.onHold").build());
        changedColumns.add(NestedMetaDTO.builder().header("Rejected").accessorKey("changed.cancelled").build());
        changedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("changed.completed").build());
        changedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("changed.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Changed")
                .accessorKey("changed")
                .columns(changedColumns)
                .build());

        List<NestedMetaDTO> archivedColumns = new ArrayList<>();
        archivedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("archived.new").build());
        archivedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("archived.inProgress").build());
        archivedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("archived.onHold").build());
        archivedColumns.add(NestedMetaDTO.builder().header("Rejected").accessorKey("archived.cancelled").build());
        archivedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("archived.completed").build());
        archivedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("archived.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Archived")
                .accessorKey("archived")
                .columns(archivedColumns)
                .build());

        List<NestedMetaDTO> deletedColumns = new ArrayList<>();
        deletedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("deleted.new").build());
        deletedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("deleted.inProgress").build());
        deletedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("deleted.onHold").build());
        deletedColumns.add(NestedMetaDTO.builder().header("Rejected").accessorKey("deleted.cancelled").build());
        deletedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("deleted.completed").build());
        deletedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("deleted.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Deleted")
                .accessorKey("deleted")
                .columns(deletedColumns)
                .build());

        metaList.add(NestedMetaDTO.builder()
                .header("Total")
                .accessorKey("Total")
                .build());

        return metaList;
    }

    public static List<MetaDTO> getReviewerMetadata() {
        List<MetaDTO> metaDTOList = new ArrayList<>();
        metaDTOList.add(new MetaDTO("Operator Name", "Researcher_Name"));
        metaDTOList.add(new MetaDTO( "New", "New"));
        metaDTOList.add(new MetaDTO( "In Progress", "In_Progress"));
        metaDTOList.add(new MetaDTO( "On Hold", "On_Hold"));
        metaDTOList.add(new MetaDTO( "Rejected", "Cancelled"));
        metaDTOList.add(new MetaDTO( "Completed", "Completed"));
        metaDTOList.add(new MetaDTO("Total", "Total"));
        return metaDTOList;
    }

    public static List<MetaDTO> getOperatorAndReviewerMetadata() {
        List<MetaDTO> metaDTOList = new ArrayList<>();
        metaDTOList.add(new MetaDTO( "Operator Name", "Researcher_Name"));
        metaDTOList.add(new MetaDTO( "Added new organizations as originator", "Added"));
        metaDTOList.add(new MetaDTO( "Changed new organizations as originator", "Changed"));
        metaDTOList.add(new MetaDTO( "Deactivated new organizations as originator", "Archived"));
        metaDTOList.add(new MetaDTO( "Deleted new organizations as originator", "Deleted"));
        metaDTOList.add(new MetaDTO( "Has Organizations in status 'NEW' as reviewer", "New"));
        metaDTOList.add(new MetaDTO( "Has Organizations in status 'IN PROGRESS' as reviewer", "In_Progress"));
        metaDTOList.add(new MetaDTO( "Has Organizations in status 'ON HOLD' as reviewer", "On_Hold"));
        metaDTOList.add(new MetaDTO( "Has Organizations in status 'CANCELLED' as reviewer", "Cancelled"));
        metaDTOList.add(new MetaDTO( "Has Organizations in status 'COMPLETED' as reviewer", "Completed"));
        metaDTOList.add(new MetaDTO("Total", "Total"));
        return metaDTOList;
    }
}