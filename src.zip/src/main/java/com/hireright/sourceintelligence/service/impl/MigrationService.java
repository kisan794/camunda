package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.InstitutionRecord;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.entity.Vendors;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.domain.repository.VendorsRepository;
import com.hireright.sourceintelligence.util.Helper;
import com.hireright.sourceintelligence.util.StateMapper;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static com.hireright.sourceintelligence.domain.constants.Constants.SOURCE_COLLECTION_SUFFIX;

@Slf4j
@Service
@RequiredArgsConstructor
public class MigrationService {
    
    private final CustomSourceRepository<Source> customSourceRepository;
    private final VendorsRepository vendorsRepository;
    private final MongoTemplate mongoTemplate;
    
    private static final String PARCHMENT_EXCHANGE = "Parchment Exchange";
    private static final String CONTACT_TYPE_AUTOMATED_SERVICES = "contactAutomatedServices";
    private static final String SOURCE_TYPE_EDUCATION = "Education";
    private static final String CURRENCY_USD = "USD";
    private static final String TIME_UNIT_DAYS = "days";

    @Transactional
    public Map<String, Object> processInstitutionRecords(List<InstitutionRecord> records) {
        int totalRecords = records.size();
        int updatedRecords = 0;
        int notFoundRecords = 0;
        List<String> notFoundInstitutions = new ArrayList<>();

        // Find vendor by name
        List<Vendors> vendors = vendorsRepository.findAll();
        Vendors vendor = vendors.stream()
            .filter(v -> PARCHMENT_EXCHANGE.equals(v.getVendor()))
            .findFirst()
            .orElseThrow(() -> new RuntimeException("Vendor 'Parchment Exchange' not found in database"));
        
        log.info("Found vendor: {} with providerId: {}", vendor.getVendor(), vendor.getProviderId());
        
        for (InstitutionRecord record : records) {
            try {
                boolean updated = processInstitutionRecord(record, vendor);
                if (updated) {
                    updatedRecords++;
                } else {
                    notFoundRecords++;
                    notFoundInstitutions.add(record.getInstitutionName());
                }
            } catch (Exception e) {
                log.error("Error processing record: {}", record.getInstitutionName(), e);
                notFoundRecords++;
                notFoundInstitutions.add(record.getInstitutionName() + " (Error: " + e.getMessage() + ")");
            }
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("totalRecords", totalRecords);
        result.put("updatedRecords", updatedRecords);
        result.put("notFoundRecords", notFoundRecords);
        result.put("notFoundInstitutions", notFoundInstitutions);
        
        log.info("Processing complete. Total: {}, Updated: {}, Not Found: {}", 
            totalRecords, updatedRecords, notFoundRecords);
        
        return result;
    }

    private boolean processInstitutionRecord(InstitutionRecord record, Vendors vendor) {
        String stateFullName = StateMapper.getFullName(record.getStateCountyRegion());
        if (stateFullName.isEmpty() && !record.getStateCountyRegion().isEmpty()) {
            stateFullName = record.getStateCountyRegion();
        }
        
        log.debug("Searching for institution: {}, City: {}, Country: {}, State: {}",
            record.getInstitutionName(), record.getCity(), record.getCountry(), stateFullName);

        // Search for source using MongoTemplate with regex for case-insensitive search
        Query query = new Query();
        query.addCriteria(Criteria.where("organizationName").regex("^" + record.getInstitutionName() + "$", "i")
            .and("city").regex("^" + record.getCity() + "$", "i")
            .and("country").regex("^" + record.getCountry() + "$", "i")
            .and("state").is(stateFullName));

        // Search across all education source collections
        Source source = mongoTemplate.findOne(query, Source.class, "education_source");

        if (source == null) {
            log.warn("Institution not found: {}", record.getInstitutionName());
            return false;
        }

        log.info("Found matching institution: {} (HON: {})", source.getOrganizationName(), source.getHon());

        updateParchmentExchangeContact(source, record, vendor);

        // Save the source back to its collection
        String collectionName = Helper.getCollectionName(source.getHon(), SOURCE_COLLECTION_SUFFIX);
        mongoTemplate.save(source, collectionName);
        log.info("Updated institution: {}", source.getOrganizationName());

        return true;
    }

    private void updateParchmentExchangeContact(Source source, InstitutionRecord record, Vendors vendor) {
        BasicDBObject payload = (BasicDBObject) source.getPayload();
        if (payload == null) {
            payload = new BasicDBObject();
            source.setPayload(payload);
        }

        BasicDBList contacts = (BasicDBList) payload.get("contacts");
        if (contacts == null) {
            contacts = new BasicDBList();
            payload.put("contacts", contacts);
        }

        BasicDBObject contact;
        if (contacts.isEmpty()) {
            contact = new BasicDBObject();
            contact.put("purpose", "");
            contact.put("purposeRule", new BasicDBList());
            contact.put("contactDetails", new BasicDBList());
            contacts.add(contact);
        } else {
            contact = (BasicDBObject) contacts.get(0);
        }
        
        BasicDBList contactDetails = (BasicDBList) contact.get("contactDetails");
        if (contactDetails == null) {
            contactDetails = new BasicDBList();
            contact.put("contactDetails", contactDetails);
        }

        BasicDBObject automatedServicesContact = findContactDetailByType(contactDetails, CONTACT_TYPE_AUTOMATED_SERVICES);

        if (automatedServicesContact == null) {
            int maxPriority = getMaxPriority(contactDetails);
            int newPriority = maxPriority + 1;

            automatedServicesContact = createAutomatedServicesContact(newPriority);
            contactDetails.add(automatedServicesContact);
            log.debug("Created new contactAutomatedServices with priority: {}", newPriority);
        }

        updateParchmentExchangeCommunication(automatedServicesContact, record, vendor);
    }

    private BasicDBObject findContactDetailByType(BasicDBList contactDetails, String type) {
        for (Object obj : contactDetails) {
            BasicDBObject cd = (BasicDBObject) obj;
            if (type.equals(cd.get("type"))) {
                return cd;
            }
        }
        return null;
    }

    private int getMaxPriority(BasicDBList contactDetails) {
        int maxPriority = 0;
        for (Object obj : contactDetails) {
            BasicDBObject cd = (BasicDBObject) obj;
            Object priority = cd.get("priority");
            if (priority != null) {
                int p = priority instanceof Integer ? (Integer) priority : Integer.parseInt(priority.toString());
                maxPriority = Math.max(maxPriority, p);
            }
        }
        return maxPriority;
    }

    private BasicDBObject createAutomatedServicesContact(int priority) {
        BasicDBObject contact = new BasicDBObject();
        contact.put("followUpAllowed", "");
        contact.put("type", CONTACT_TYPE_AUTOMATED_SERVICES);
        contact.put("priority", priority);
        contact.put("version", "");
        contact.put("turnAroundTime", "");
        contact.put("surChargeAmount", "");
        contact.put("name", "");
        contact.put("paymentMethod", "");
        contact.put("turnAroundTimeUnit", TIME_UNIT_DAYS);
        contact.put("surChargeCurrency", "");
        contact.put("communication", new BasicDBList());
        contact.put("fromYear", "");
        contact.put("toYear", "");
        return contact;
    }
    
    private void updateParchmentExchangeCommunication(BasicDBObject contactDetail, InstitutionRecord record, Vendors vendor) {
        BasicDBList communications = (BasicDBList) contactDetail.get("communication");
        if (communications == null) {
            communications = new BasicDBList();
            contactDetail.put("communication", communications);
        }

        BasicDBObject parchmentComm = null;
        for (Object obj : communications) {
            BasicDBObject comm = (BasicDBObject) obj;
            if (PARCHMENT_EXCHANGE.equals(comm.get("name"))) {
                parchmentComm = comm;
                break;
            }
        }

        if (parchmentComm == null) {
            int maxPriority = getMaxPriority(communications);
            int newPriority = maxPriority + 1;

            parchmentComm = createParchmentExchangeCommunication(record, vendor, newPriority);
            communications.add(parchmentComm);
            log.debug("Added Parchment Exchange communication with priority: {}", newPriority);
        } else {
            updateCommunicationInfo((BasicDBList) parchmentComm.get("communicationInfo"), record, vendor);
            log.debug("Updated existing Parchment Exchange communication");
        }
    }

    private BasicDBObject createParchmentExchangeCommunication(InstitutionRecord record, Vendors vendor, int priority) {
        BasicDBList communicationInfoList = createCommunicationInfoList(record, vendor);

        BasicDBObject communication = new BasicDBObject();
        communication.put("name", PARCHMENT_EXCHANGE);
        communication.put("communicationInfo", communicationInfoList);
        communication.put("providerID", String.valueOf(vendor.getProviderId()));
        communication.put("priority", priority);
        return communication;
    }

    private BasicDBList createCommunicationInfoList(InstitutionRecord record, Vendors vendor) {
        BasicDBList infoList = new BasicDBList();

        infoList.add(createCommunicationInfo("companyNames", record.getInstitutionName()));
        infoList.add(createCommunicationInfo("codes", record.getCode()));
        infoList.add(createCommunicationInfo("branch", ""));
        infoList.add(createCommunicationInfo("uri", vendor.getWebsite()));
        infoList.add(createCommunicationInfo("sourceType", SOURCE_TYPE_EDUCATION));

        String surchargeAmount = record.getSurchargeAmount() != null ? record.getSurchargeAmount() : "";
        String currency = "USA".equalsIgnoreCase(record.getCountry()) ? CURRENCY_USD : "";
        infoList.add(createCommunicationInfo("surChargeAmount", surchargeAmount));
        infoList.add(createCommunicationInfo("surChargeCurrency", currency));

        String paymentMethod = record.getPaymentMethod() != null ? record.getPaymentMethod() : "";
        infoList.add(createCommunicationInfo("paymentMethod", paymentMethod));

        String followUpAllowed = record.getFollowUpAllowed() != null ? record.getFollowUpAllowed() : "";
        infoList.add(createCommunicationInfo("followUpAllowed", followUpAllowed));
        infoList.add(createCommunicationInfo("followUpAllowedAfter", ""));
        infoList.add(createCommunicationInfo("followUpAllowedAfterTimeUnit", TIME_UNIT_DAYS));

        String turnaroundTime = record.getTurnaroundTime() != null ? record.getTurnaroundTime() : "";
        infoList.add(createCommunicationInfo("turnAroundTime", turnaroundTime));
        infoList.add(createCommunicationInfo("turnAroundTimeUnit", TIME_UNIT_DAYS));

        infoList.add(createCommunicationInfo("fromYear", ""));
        infoList.add(createCommunicationInfo("toYear", ""));

        return infoList;
    }

    private BasicDBObject createCommunicationInfo(String type, String value) {
        BasicDBObject info = new BasicDBObject();
        info.put("type", type);
        info.put("value", value != null ? value : "");
        return info;
    }

    private void updateCommunicationInfo(BasicDBList communicationInfoList, InstitutionRecord record, Vendors vendor) {
        if (communicationInfoList == null) {
            return;
        }

        updateInfoValue(communicationInfoList, "companyNames", record.getInstitutionName());
        updateInfoValue(communicationInfoList, "codes", record.getCode());
        updateInfoValue(communicationInfoList, "uri", vendor.getWebsite());

        String surchargeAmount = record.getSurchargeAmount() != null ? record.getSurchargeAmount() : "";
        String currency = "USA".equalsIgnoreCase(record.getCountry()) ? CURRENCY_USD : "";
        updateInfoValue(communicationInfoList, "surChargeAmount", surchargeAmount);
        updateInfoValue(communicationInfoList, "surChargeCurrency", currency);

        String paymentMethod = record.getPaymentMethod() != null ? record.getPaymentMethod() : "";
        updateInfoValue(communicationInfoList, "paymentMethod", paymentMethod);

        String followUpAllowed = record.getFollowUpAllowed() != null ? record.getFollowUpAllowed() : "";
        updateInfoValue(communicationInfoList, "followUpAllowed", followUpAllowed);

        String turnaroundTime = record.getTurnaroundTime() != null ? record.getTurnaroundTime() : "";
        updateInfoValue(communicationInfoList, "turnAroundTime", turnaroundTime);
    }

    private void updateInfoValue(BasicDBList communicationInfoList, String type, String value) {
        for (Object obj : communicationInfoList) {
            BasicDBObject info = (BasicDBObject) obj;
            if (type.equals(info.get("type"))) {
                info.put("value", value != null ? value : "");
                break;
            }
        }
    }
}

