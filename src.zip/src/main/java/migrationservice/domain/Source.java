package migrationservice.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "education_source")
public class Source {
    
    @Id
    private String id;
    
    private String hon;
    private String organizationName;
    private String status;
    private Integer version;
    private String organizationType;
    private String city;
    private String country;
    private String state;
    private List<OrganizationAlias> organizationAlias;
    private Payload payload;
    private String approvalStatus;
    private String postalCode;
    private String searchOrg;
    private String action;
    
    @Field("created_date")
    private Date createdDate;
    
    private String lastModifiedBy;
    private String lastModifierId;
    
    @Field("last_modified_date")
    private Date lastModifiedDate;
    
    private String approvedBy;
    private String approverId;
    private String assignedTo;
    private String assignedId;
    
    @Field("last_approved_date")
    private Date lastApprovedDate;
    
    @Field("_class")
    private String className;
    
    private String logFlag;
    
    @Field("last_action_date")
    private Date lastActionDate;
    
    private Boolean flagPriority;
}

