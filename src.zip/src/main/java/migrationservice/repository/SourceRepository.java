package migrationservice.repository;

import com.hireright.migrationservice.domain.Source;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SourceRepository extends MongoRepository<Source, String> {

    @Query("{ 'organizationName': { $regex: ?0, $options: 'i' }, 'city': { $regex: ?1, $options: 'i' }, 'country': { $regex: ?2, $options: 'i' }, 'state': ?3 }")
    Optional<Source> findByOrganizationNameAndCityAndCountryAndState(
        String organizationName,
        String city,
        String country,
        String state
    );
}

