package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.constants.ErrorConstants;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Sort;
import com.hireright.sourceintelligence.exception.InvalidRequestException;





import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class OffsetBasedPageRequestTest {
    @Test
    void constructor_shouldThrowForNegativeOffset() {
        Sort sort = Sort.unsorted();

        assertThatThrownBy(() -> new OffsetBasedPageRequest(-1, 10, sort))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessageContaining("Offset index must not be less than zero!");
    }



    @Test
    void constructor_shouldThrowForZeroLimit() {
        Sort sort = Sort.unsorted();

        assertThatThrownBy(() -> new OffsetBasedPageRequest(0, 0, sort))
                .isInstanceOf(InvalidRequestException.class)
                .hasMessageContaining("Limit must not be less than one!");
    }



    @Test
    void getPageNumber_shouldReturnCorrectValue() {
        OffsetBasedPageRequest pageRequest = new OffsetBasedPageRequest(20, 10, Sort.unsorted());
        assertThat(pageRequest.getPageNumber()).isEqualTo(2);
    }

    @Test
    void next_shouldReturnNextPage() {
        OffsetBasedPageRequest current = new OffsetBasedPageRequest(10, 5, Sort.by("field"));
        OffsetBasedPageRequest next = (OffsetBasedPageRequest) current.next();
        assertThat(next.getOffset()).isEqualTo(15);
        assertThat(next.getPageSize()).isEqualTo(5);
    }

    @Test
    void previous_shouldReturnPreviousPageIfHasPrevious() {
        OffsetBasedPageRequest current = new OffsetBasedPageRequest(20, 10, Sort.by("name"));
        OffsetBasedPageRequest prev = current.previous();
        assertThat(prev.getOffset()).isEqualTo(10);
    }

    @Test
    void previous_shouldReturnSameInstanceIfNoPrevious() {
        OffsetBasedPageRequest current = new OffsetBasedPageRequest(5, 10, Sort.by("name"));
        assertThat(current.previous()).isSameAs(current);
    }

    @Test
    void first_shouldResetOffset() {
        OffsetBasedPageRequest pageRequest = new OffsetBasedPageRequest(25, 5, Sort.by("field"));
        assertThat(pageRequest.first().getOffset()).isZero();
    }

    @Test
    void hasPrevious_shouldReturnTrueWhenOffsetGreaterThanLimit() {
        OffsetBasedPageRequest pageRequest = new OffsetBasedPageRequest(30, 10, Sort.unsorted());
        assertThat(pageRequest.hasPrevious()).isTrue();
    }

    @Test
    void hasPrevious_shouldReturnFalseWhenOffsetLessThanLimit() {
        OffsetBasedPageRequest pageRequest = new OffsetBasedPageRequest(5, 10, Sort.unsorted());
        assertThat(pageRequest.hasPrevious()).isFalse();
    }

    @Test
    void equalsAndHashCode_shouldBeCorrect() {
        OffsetBasedPageRequest request1 = new OffsetBasedPageRequest(0, 10, Sort.by("name"));
        OffsetBasedPageRequest request2 = new OffsetBasedPageRequest(0, 10, Sort.by("name"));

        assertThat(request1)
                .isEqualTo(request2)
                .hasSameHashCodeAs(request2);
    }

    @Test
    void toString_shouldIncludeValues() {
        OffsetBasedPageRequest request = new OffsetBasedPageRequest(0, 10, Sort.by("email"));
        assertThat(request.toString()).contains("limit=10", "offset=0", "sort=email");
    }

    @Test
    void withPage_shouldReturnNull() {
        OffsetBasedPageRequest request = new OffsetBasedPageRequest(0, 10, Sort.by("email"));
        assertThat(request.withPage(5)).isNull();
    }
}
