package com.hireright.sourceintelligence.domain.mapper;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.util.TestDataProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.bson.types.ObjectId;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
class SourceOrganizationMapperTest {

    private SourceMapper sourceMapper;

    @BeforeEach
    void setUp() {
        sourceMapper = Mappers.getMapper(SourceMapper.class);
    }

    @Test
    void entityToDTOTest() {
        //given
        Source orgEntity = TestDataProvider.getSourceOrganizationEntity();
        orgEntity.setHon(TestDataProvider.getHon());
        //when
        SourceOrganizationDTO sourceOrganizationDTO = sourceMapper.entitySourceToDTO(orgEntity);
        //then
        assertThat(sourceOrganizationDTO).isNotNull();
        assertThat(sourceOrganizationDTO.getOrganizationName()).isEqualTo(orgEntity.getOrganizationName());

    }
    @Test
    void entityToDTOTest_ReturnNull() {
        //given
        Source orgEntity = null;
        //when
        SourceOrganizationDTO sourceOrganizationDTO = sourceMapper.entitySourceToDTO(orgEntity);
        //then
        assertThat(sourceOrganizationDTO).isNull();
    }

    @Test
    void DTOToEntityTest() {
        //given
        SourceOrganizationDTO orgDTO = TestDataProvider.getSourceOrganizationDTO();
        orgDTO.setHon(TestDataProvider.getHon());
        //when
        Source orgEntity = sourceMapper.dtoToEntitySource(orgDTO);
        //then
        assertThat(orgEntity).isNotNull();
        assertThat(orgEntity.getOrganizationName()).isEqualTo(orgDTO.getOrganizationName());
    }

    @Test
    void DTOToEntityTest_ReturnNull() {
        //given
        SourceOrganizationDTO orgDTO = null;

        //when
        Source orgEntity = sourceMapper.dtoToEntitySource(orgDTO);
        //then
        assertThat(orgEntity).isNull();
    }


    @Test
    void toDTOListTest() {
        // given
        List<Source> sourceOrganizationList = TestDataProvider.getSourceOrganizationList();

        sourceOrganizationList.forEach(source -> {
            if (source.getId() == null) {
                source.setId(new ObjectId());
            }
        });

        // when
        List<SourceOrganizationDTO> sourceOrganizationDTOList =
                sourceMapper.toSourceDTOList(sourceOrganizationList);

        // then
        assertThat(sourceOrganizationDTOList)
                .isNotNull()
                .hasSameSizeAs(sourceOrganizationList);

        for (int i = 0; i < sourceOrganizationList.size(); i++) {
            assertThat(sourceOrganizationDTOList.get(i).getId())
                    .isEqualTo(sourceOrganizationList.get(i).getId().toHexString());
        }
    }

    @Test
    void toDTOListTest_ReturnNull() {
        //given
        List<Source> sourceOrganizationList = null;
        //when
        List<SourceOrganizationDTO> sourceOrganizationDTOList = sourceMapper.toSourceDTOList(sourceOrganizationList);
        //then
        assertThat(sourceOrganizationDTOList).isNull();

    }

}