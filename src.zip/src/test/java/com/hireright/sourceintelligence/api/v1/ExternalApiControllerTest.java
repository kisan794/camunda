package com.hireright.sourceintelligence.api.v1;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.sourceintelligence.api.dto.ApproverDTO;
import com.hireright.sourceintelligence.api.dto.UserDataDTO;
import com.hireright.sourceintelligence.api.dto.UserLoginDetailsDTO;
import com.hireright.sourceintelligence.api.v2.dto.PermissionsDTO;
import com.hireright.sourceintelligence.exception.AccessDeniedException;
import com.hireright.sourceintelligence.service.ExternalService;
import com.hireright.sourceintelligence.service.PermissionsService;
import com.hireright.sourceintelligence.util.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;

import static com.hireright.sourceintelligence.api.ApiConstants.SearchParams.USER_NAME;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.MockedStatic;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.hireright.sourceintelligence.api.dto.ExternalResponse;
import com.hireright.sourceintelligence.api.dto.Parameter;
import com.hireright.sourceintelligence.api.dto.ParametersList;
import java.io.ByteArrayInputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

class ExternalApiControllerTest {

    private ExternalService externalService;
    private PermissionsService permissionsService;
    private HttpServletRequest request;
    private ExternalApiController controller;
    private final ObjectMapper mapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        externalService = mock(ExternalService.class);
        permissionsService = mock(PermissionsService.class);
        request = mock(HttpServletRequest.class);
        controller = new ExternalApiController(externalService, permissionsService, request);
        ReflectionTestUtils.setField(controller, "hrg1ApiUrl", "/api/v1/auth?key=");
        ReflectionTestUtils.setField(controller, "hrg1PermissionApiUrl", "/permissions/");
        ReflectionTestUtils.setField(controller, "hrg1ApproversApiUrl", "/approvers/");
        ReflectionTestUtils.setField(controller, "hrg1PermissionUSApiUrl", "http://us.perms/api/permissions/");
        ReflectionTestUtils.setField(controller, "hrg1ApproversUSApiUrl", "http://us.perms/api/approvers/");
        ReflectionTestUtils.setField(controller, "reactUiUrl", "http://ui.example.com?token=");
        ReflectionTestUtils.setField(controller, "permissionsFromOptool", Boolean.TRUE);
    }

    @Test
    void redirectToUi_buildsFinalUrl_and200() throws Exception {
        String tokenKey = "abc.def.g";
        String expectedJwt = "jwt-content";

        Field f = ExternalApiController.class.getDeclaredField("jwtCache");
        f.setAccessible(true);
        ((Map<String, String>) f.get(controller)).put(tokenKey, expectedJwt);

        Field flag = ExternalApiController.class.getDeclaredField("permissionsFromOptool");
        flag.setAccessible(true);
        flag.set(controller, false);
        ExternalResponse externalResponse = mock(ExternalResponse.class);
        ParametersList params = mock(ParametersList.class);

        Parameter email = mock(Parameter.class);
        when(email.getName()).thenReturn(USER_EMAIL);
        when(email.getValue()).thenReturn("dummy@hireright.com");

        Parameter name = mock(Parameter.class);
        when(name.getName()).thenReturn(USER_NAME);
        when(name.getValue()).thenReturn("dummy");

        Parameter trust = mock(Parameter.class);
        when(trust.getName()).thenReturn(TRUST_SCORE);
        when(trust.getValue()).thenReturn("5");

        when(params.getParameter()).thenReturn(List.of(email, name, trust));
        when(externalResponse.getParametersList()).thenReturn(params);
        when(externalService.getExternalApiResponse(anyString())).thenReturn(externalResponse);

        PermissionsDTO perm = new PermissionsDTO();
        perm.setPermissions(List.of("read"));
        perm.setUserEmail("dummy@hireright.com");
        perm.setUserName("dummy");
        perm.setScope("test");
        perm.setTrustScore("5");

        when(permissionsService.getPermissionByNameAndStatus(any(), eq("active")))
                .thenReturn(perm);

        var resp = controller.getCachedToken(tokenKey, "");
        assertEquals(200, resp.getStatusCode().value());
        assertEquals(expectedJwt, ((Map<String, String>) f.get(controller)).get(tokenKey));

        verify(externalService).getExternalApiResponse(anyString());
        verifyNoMoreInteractions(externalService);
    }


    @Test
    void getHRGPermissions_usesPermissionsService_whenFlagFalse() {
        ReflectionTestUtils.setField(controller, "permissionsFromOptool", Boolean.FALSE);

        PermissionsDTO p = new PermissionsDTO();
        p.setUserName("Jane Smith");
        p.setUserEmail("jsmith@hireright.com");
        p.setScope("si2");
        p.setTrustScore("7");
        p.setPermissions(List.of("read", "write"));

        when(permissionsService.getPermissionByNameAndStatus("John Doe", "active"))
                .thenReturn(p);

        ResponseEntity<UserLoginDetailsDTO> resp =
                controller.getHRGPermissions("jsmith@hireright.com", "John Doe");

        UserLoginDetailsDTO dto = resp.getBody();
        assertNotNull(dto, "Response body must not be null");
        assertNotNull(dto.getData(), "dto.data must not be null");
        assertEquals(1, dto.getData().size(), "dto.data must have exactly 1 item");

        UserDataDTO user = dto.getData().get(0);

        assertAll("HRG Permissions response",
                () -> assertEquals(200, resp.getStatusCodeValue()),
                () -> assertEquals("userDetails", dto.getKind()),
                () -> assertEquals("John Doe", user.getUserName()),
                () -> assertEquals("jsmith@hireright.com", user.getUserEmail()),
                () -> assertEquals("7", user.getTrustScore()),
                () -> assertEquals(List.of("read", "write"), user.getPermissions()),
                () -> assertNull(user.getApprovalGroupList())
        );

        verify(permissionsService).getPermissionByNameAndStatus("John Doe", "active");
    }


    @Test
    void prepareResponse_buildsExpectedUserLoginDetailsDTO() throws Exception {
        ReflectionTestUtils.setField(controller, "permissionsFromOptool", Boolean.TRUE);
        ReflectionTestUtils.setField(controller, "hrg1PermissionApiUrl", "/permissions/");
        ReflectionTestUtils.setField(controller, "hrg1PermissionUSApiUrl", "http://us-permissions/");
        ReflectionTestUtils.setField(controller, "hrg1ApproversApiUrl", "/approvers");
        ReflectionTestUtils.setField(controller, "hrg1ApproversUSApiUrl", "http://us-approvers");

        ExternalResponse externalResponse = mock(ExternalResponse.class);
        ParametersList paramsList = mock(ParametersList.class);

        Parameter fromSub = new Parameter();
        fromSub.setName(FROM_SUB_REQUEST);
        fromSub.setValue("true");

        Parameter orgType = new Parameter();
        orgType.setName(ORGANIZATION_TYPE_OPTOOL);
        orgType.setValue("Manufacturing");

        Parameter orgName = new Parameter();
        orgName.setName(ORGANIZATION_NAME_OPTOOL);
        orgName.setValue("AgriCorp");

        Parameter country = new Parameter();
        country.setName(COUNTRY_OPTOOL);
        country.setValue("US");

        Parameter state = new Parameter();
        state.setName(STATE_OPTOOL);
        state.setValue("CA");

        Parameter city = new Parameter();
        city.setName(CITY_OPTOOL);
        city.setValue("San Diego");

        Parameter port = new Parameter();
        port.setName(OPTOOL_WEBSERVER_PORT);
        port.setValue("8080");

        Parameter uname = new Parameter();
        uname.setName(USER_NAME);
        uname.setValue("lazy.farmer");

        Parameter uemail = new Parameter();
        uemail.setName(USER_EMAIL);
        uemail.setValue("lazy.farmer@hireright.com");

        Parameter trust = new Parameter();
        trust.setName(TRUST_SCORE);
        trust.setValue("9");

        when(externalResponse.getParametersList()).thenReturn(paramsList);
        when(paramsList.getParameter()).thenReturn(List.of(
                fromSub, orgType, orgName, country, state, city,
                port, uname, uemail, trust
        ));

        String json = """
    {
      "data": [{
        "permissions": [
          "optool.webtool.si2.read",
          "optool.webtool.si2.write"
        ],
        "subject": "lazy.farmer",
        "sourceVerificationTrustLevel": 9
      }]
    }
    """;
        JsonNode root = mapper.readTree(json);
        when(externalService.getHRGPermissions(anyString())).thenReturn(root);

        Method m = ExternalApiController.class.getDeclaredMethod(
                "prepareResponse",
                ExternalResponse.class,
                String.class,
                boolean.class
        );
        m.setAccessible(true);

        UserLoginDetailsDTO dto = (UserLoginDetailsDTO) m.invoke(controller, externalResponse, "api.host", false);

        assertNotNull(dto);
        assertEquals("subRequest", dto.getKind());
        assertEquals(1, dto.getData().size());

        UserDataDTO user = dto.getData().get(0);
        assertEquals("lazy.farmer@hireright.com", user.getUserEmail());
        assertEquals("lazy.farmer", user.getUserName());
        assertEquals("9", user.getTrustScore());

        assertNotNull(user.getSearchRequest());
        assertEquals("Manufacturing", user.getSearchRequest().getOrganizationType());
        assertEquals("AgriCorp", user.getSearchRequest().getOrganizationName());
        assertEquals("US", user.getSearchRequest().getCountry());
        assertEquals("CA", user.getSearchRequest().getState());
        assertEquals("San Diego", user.getSearchRequest().getCity());
        assertEquals(List.of("read", "write"), user.getPermissions());
    }


    @Test
    void uploadAttachment_success_and_failure() {
        MockMultipartFile file = new MockMultipartFile(
                "file", "doc.txt", "text/plain", "hello".getBytes()
        );
        doReturn("ok").when(externalService).retryUploadService(any(), eq("{\"k\":\"v\"}"));
        var ok = controller.uploadAttachment(file, "{\"k\":\"v\"}");
        assertEquals(200, ok.getStatusCode().value());
        assertEquals("ok", ok.getBody());
        doThrow(new RuntimeException("boom"))
                .when(externalService).retryUploadService(any(), any());

        assertThrows(RuntimeException.class, () -> controller.uploadAttachment(file, "{}"));
    }

    @Test
    void getAttachment_success() {
        byte[] bytes = "pdf".getBytes(StandardCharsets.UTF_8);
        InputStreamResource body = new InputStreamResource(new ByteArrayInputStream(bytes));
        ResponseEntity<InputStreamResource> serviceResp = ResponseEntity.ok(body);
        when(externalService.getAttachmentByUrl("doc-1")).thenReturn(serviceResp);

        var resp = controller.getAttachment("doc-1");
        assertEquals(200, resp.getStatusCode().value());
        assertNotNull(resp.getBody());
    }

    @Test
    void deleteAttachment_success_and_failure() throws Exception {
        when(externalService.deleteAttachment("d1")).thenReturn("deleted");

        var ok = controller.deleteAttachment("d1");
        assertEquals(200, ok.getStatusCode().value());
        assertEquals("deleted", ok.getBody());

        when(externalService.deleteAttachment("d2")).thenThrow(new IOException("nope"));
        assertThrows(RuntimeException.class, () -> controller.deleteAttachment("d2"));
    }
    @Test
    void populateUserPermissionsAndApprovalList_staticApprovers_whenFlagTrue_andApproverPermissionPresent() throws Exception {
        // Given
        ReflectionTestUtils.setField(controller, "permissionsFromOptool", Boolean.TRUE);
        ReflectionTestUtils.setField(controller, "hrg1ApproversUSApiUrl", "http://us-approvers");

        String json = """
    {
      "data": [{
         "permissions": [
           "optool.webtool.si2.approvalManager",
           "optool.webtool.si2.read",
           "optool.webtool.si2.write"
         ],
         "subject": "jdoe",
         "sourceVerificationTrustLevel": 5
      }]
    }
    """;

        JsonNode root = mapper.readTree(json);

        UserDataDTO user = new UserDataDTO();
        user.setUserEmail("jdoe@hireright.com");
        user.setUserName("jdoe");

        String approverJson = """
    {
        "data": [],
        "meta": {"count":0, "total":0, "offset":0}
    }
    """;

        JsonNode emptyApprovers = mapper.readTree(approverJson);
        when(externalService.getApproversList(anyString())).thenReturn(emptyApprovers);

        Method m = ExternalApiController.class.getDeclaredMethod(
                "populateUserPermissionsAndApprovalList",
                JsonNode.class,
                UserDataDTO.class,
                String.class,
                boolean.class
        );
        m.setAccessible(true);

        UserDataDTO out = (UserDataDTO) m.invoke(controller, root, user, null, true);

        assertEquals(List.of("approvalManager", "read", "write"), out.getPermissions());
        assertEquals("5", out.getTrustScore());
        assertEquals("jdoe@hireright.com", out.getUserEmail());

        List<ApproverDTO> approvers = out.getApprovalGroupList();
        assertNotNull(approvers);
        assertTrue(approvers.isEmpty(), "Approvers should be empty when API returns no data");
    }

    @Test
    void populateUserPermissionsAndApprovalList_apiApprovers_whenFlagFalse_callsExternal() throws Exception {
        ReflectionTestUtils.setField(controller, "permissionsFromOptool", Boolean.TRUE);
        ReflectionTestUtils.setField(controller, "hrg1ApproversApiUrl", "/approvers");
        ReflectionTestUtils.setField(controller, "hrg1ApproversUSApiUrl", "http://us-approvers");

        String json = """
    {
      "data": [{
         "permissions": [
           "optool.webtool.si2.approvalManager",
           "optool.webtool.si2.read"
         ],
         "subject": "mary.smith",
         "sourceVerificationTrustLevel": 9
      }]
    }
    """;
        JsonNode root = mapper.readTree(json);

        UserDataDTO user = new UserDataDTO();
        user.setUserEmail("mary.smith@hireright.com");
        user.setUserName("mary.smith");

        String approversJson = """
    {
      "data": [
         {"username": "john.doe", "email": "john.doe@hireright.com", "formattedName": "John doe"},
         {"username": "anna.lee", "email": "anna.lee@hireright.com", "formattedName": "Anna lee"}
      ],
      "meta": {"count":2, "total":2, "offset":0}
    }
    """;
        JsonNode approverRoot = mapper.readTree(approversJson);
        when(externalService.getApproversList(anyString())).thenReturn(approverRoot);

        Method m = ExternalApiController.class.getDeclaredMethod(
                "populateUserPermissionsAndApprovalList",
                JsonNode.class,
                UserDataDTO.class,
                String.class,
                boolean.class
        );
        m.setAccessible(true);

        UserDataDTO out = (UserDataDTO) m.invoke(controller, root, user, "api.host", true);

        assertEquals(List.of("approvalManager", "read"), out.getPermissions());
        assertEquals("9", out.getTrustScore());
        assertEquals("mary.smith@hireright.com", out.getUserEmail());

        List<ApproverDTO> approvers = out.getApprovalGroupList();
        assertNotNull(approvers);
        assertEquals(2, approvers.size());

        assertEquals("John doe", approvers.get(0).getApproverName());
        assertEquals("john.doe", approvers.get(0).getUserName());
        assertEquals("john.doe@hireright.com", approvers.get(0).getApproverEmail());

        assertEquals("Anna lee", approvers.get(1).getApproverName());
        assertEquals("anna.lee", approvers.get(1).getUserName());
        assertEquals("anna.lee@hireright.com", approvers.get(1).getApproverEmail());

        verify(externalService, atLeastOnce()).getApproversList(anyString());
    }


    @Test
    void getExternalApiResponse_happyPath_hitsPrepareResponse_andBuildsRedirect() {
        when(request.getMethod()).thenReturn("GET");
        when(request.getRequestURI()).thenReturn("/external");
        when(request.getQueryString()).thenReturn("key=k1&entry=e1&apiHost=api.host");

        ReflectionTestUtils.setField(controller, "reactUiUrl", "http://ui.example.com?token=");
        ReflectionTestUtils.setField(controller, "hrg1ApiUrl", "/api/v1/auth?key=");
        ReflectionTestUtils.setField(controller, "permissionsFromOptool", Boolean.FALSE);

        ExternalResponse externalResponse = mock(ExternalResponse.class);
        ParametersList parametersList = mock(ParametersList.class);

        Parameter userEmailParam = mock(Parameter.class);
        when(userEmailParam.getName()).thenReturn(USER_EMAIL);
        when(userEmailParam.getValue()).thenReturn("someone@hireright.com");

        Parameter userNameParam = mock(Parameter.class);
        when(userNameParam.getName()).thenReturn(USER_NAME);
        when(userNameParam.getValue()).thenReturn("someone");

        when(externalResponse.getParametersList()).thenReturn(parametersList);
        when(parametersList.getParameter()).thenReturn(List.of(userEmailParam, userNameParam));

        when(externalService.getExternalApiResponse("http://api.host/api/v1/auth?key=k1"))
                .thenReturn(externalResponse);

        PermissionsDTO permissionsDTO = new PermissionsDTO();
        permissionsDTO.setUserName("someone");
        permissionsDTO.setUserEmail("someone@hireright.com");
        permissionsDTO.setTrustScore("10");
        permissionsDTO.setScope("test-scope");
        permissionsDTO.setPermissions(List.of("read"));

        when(permissionsService.getPermissionByNameAndStatus("someone", "active"))
                .thenReturn(permissionsDTO);

        try (MockedStatic<JwtUtil> util = mockStatic(JwtUtil.class)) {
            util.when(() -> JwtUtil.generateToken(any())).thenReturn("tok123");

            ResponseEntity<String> response =
                    controller.getExternalApiResponse("k1", "e1", "api.host");

            assertNotNull(response);
            assertEquals(HttpStatus.FOUND, response.getStatusCode());
            assertEquals("http://ui.example.com?token=tok123",
                    response.getHeaders().getFirst(HttpHeaders.LOCATION));
        }

        verify(externalService).getExternalApiResponse("http://api.host/api/v1/auth?key=k1");
        verify(permissionsService).getPermissionByNameAndStatus("someone", "active");
    }



    @Test
    void getAttachment_failure_throws() {
        when(externalService.getAttachmentByUrl("bad"))
                .thenThrow(new RuntimeException("fetch failed"));

        assertThrows(RuntimeException.class, () -> controller.getAttachment("bad"));
    }

    @Test
    void getPermission_optool_emptyPermissions_throws() throws Exception {
        ReflectionTestUtils.setField(controller, "permissionsFromOptool", Boolean.TRUE);

        ObjectNode root = mapper.createObjectNode();
        ArrayNode data = root.putArray("data");
        ObjectNode rec = data.addObject();
        rec.putArray("permissions");

        when(externalService.getHRGPermissions(anyString())).thenReturn(root);

        UserDataDTO dto = new UserDataDTO();
        dto.setUserEmail("someone@hireright.com");
        dto.setUserName("someone");

        var m = ExternalApiController.class.getDeclaredMethod(
                "populateUserPermissionsAndApprovalList",
                JsonNode.class,
                UserDataDTO.class,
                String.class,
                boolean.class
        );
        m.setAccessible(true);

        InvocationTargetException ite = assertThrows(
                InvocationTargetException.class,
                () -> m.invoke(controller, root, dto, "api.host", false)
        );

        assertTrue(ite.getCause() instanceof AccessDeniedException);
        assertTrue(ite.getCause().getMessage().contains("Access denied"));
    }

    @Test
    void getPermission_permissionsService_emptyPermissions_throws() {
        ReflectionTestUtils.setField(controller, "permissionsFromOptool", Boolean.FALSE);

        PermissionsDTO p = new PermissionsDTO();
        p.setUserName("X");
        p.setUserEmail("x@hireright.com");
        p.setScope("s");
        p.setTrustScore("1");
        p.setPermissions(java.util.Collections.emptyList());
        when(permissionsService.getPermissionByNameAndStatus("John Doe", "active"))
                .thenReturn(p);

        assertThrows(RuntimeException.class,
                () -> controller.getHRGPermissions("x@hireright.com", "John Doe"));
    }

    @Test
    void capitalizeUsername_dotSeparated() throws Exception {
        var m = ExternalApiController.class.getDeclaredMethod("capitalizeUsername", String.class);
        m.setAccessible(true);
        String out = (String) m.invoke(controller, "john.smith");
        assertEquals("John.smith", out);
    }

}
