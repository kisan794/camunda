package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.constants.APIConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SourceIntelligenceServiceController.class)
class SourceIntelligenceServiceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private String healthEndpoint;

    @BeforeEach
    void setUp() {
        healthEndpoint = APIConstants.SOURCEINTELLIGENCE_SERVICE + APIConstants.V1 + APIConstants.HEALTH;
    }

    @Test
    void testHealthCheckEndpoint() throws Exception {
        mockMvc.perform(get(healthEndpoint))
                .andExpect(status().isOk())
                .andExpect(content().string(APIConstants.HEALTH_CHECK));
    }
}
