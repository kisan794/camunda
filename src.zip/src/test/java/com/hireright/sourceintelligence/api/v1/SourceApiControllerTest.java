package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.service.SourceService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SourceApiControllerTest {

    @InjectMocks
    private SourceApiController sourceApiController;

    @Mock
    private SourceService sourceService;

    @Mock
    private HttpServletRequest httpServletRequest;

    private static final String HON = "OUEMP123";
    private static final String ACTION = "LOCK";
    private static final String VERSION = "1.0";
    private static final String TEMP_VERSION = "1.1";

    private SourceOrganizationDTO sourceOrganizationDTO;
    private SourceRequestDTO sourceRequestDTO;
    private UIActionsDTO uiActionsDTO;

    @BeforeEach
    void setUp() {
        sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setHon(HON);

        uiActionsDTO = new UIActionsDTO();

        sourceRequestDTO = new SourceRequestDTO();
        sourceRequestDTO.setSourceOrganizationDTO(sourceOrganizationDTO);
        sourceRequestDTO.setUiActionsDTO(uiActionsDTO);
    }

    @Test
    void createSourceOrganization_shouldReturnCreated() {
        when(sourceService.createSource(sourceOrganizationDTO, uiActionsDTO)).thenReturn(sourceOrganizationDTO);

        ResponseEntity<SourceOrganizationDTO> response =
                sourceApiController.createSourceOrganization(sourceRequestDTO, httpServletRequest);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertSame(sourceOrganizationDTO, response.getBody());
        verify(sourceService).createSource(sourceOrganizationDTO, uiActionsDTO);
    }

    @Test
    void updateSourceOrganization_shouldReturnOk() {
        when(sourceService.updateSource(sourceOrganizationDTO, uiActionsDTO)).thenReturn(sourceOrganizationDTO);

        ResponseEntity<SourceOrganizationDTO> response =
                sourceApiController.updateSourceOrganization(HON, sourceRequestDTO, httpServletRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(sourceOrganizationDTO, response.getBody());
        verify(sourceService).updateSource(sourceOrganizationDTO, uiActionsDTO);
    }

    @Test
    void updateSourceOrganization_shouldThrowWhenPathHonIsBlank() {
        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> sourceApiController.updateSourceOrganization(" ", sourceRequestDTO, httpServletRequest));

        assertNotNull(exception);
        verify(sourceService, never()).updateSource(any(), any());
    }

    @Test
    void updateSourceOrganization_shouldThrowWhenPayloadHonIsBlank() {
        sourceOrganizationDTO.setHon(" ");

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> sourceApiController.updateSourceOrganization(HON, sourceRequestDTO, httpServletRequest));

        assertNotNull(exception);
        verify(sourceService, never()).updateSource(any(), any());
    }

    @Test
    void updateSourceOrganization_shouldThrowWhenHonMismatch() {
        sourceOrganizationDTO.setHon("DIFFERENT_HON");

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> sourceApiController.updateSourceOrganization(HON, sourceRequestDTO, httpServletRequest));

        assertNotNull(exception);
        verify(sourceService, never()).updateSource(any(), any());
    }

    @Test
    void archiveSource_shouldReturnOk() {
        ResponseObject responseObject = new ResponseObject();
        when(sourceService.archiveSource(HON, uiActionsDTO)).thenReturn(responseObject);

        ResponseEntity<ResponseObject> response =
                sourceApiController.archiveSource(HON, sourceRequestDTO, httpServletRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(responseObject, response.getBody());
        verify(sourceService).archiveSource(HON, uiActionsDTO);
    }

    @Test
    void getSourceOrganization_shouldReturnSourceWhenIsRamTrue() {
        when(sourceService.getSourceByHonAndApprovalStatus(HON, ApprovalStatus.APPROVED))
                .thenReturn(sourceOrganizationDTO);

        ResponseEntity<SourceOrganizationDTO> response =
                sourceApiController.getSourceOrganization(HON, "anything", ApprovalStatus.APPROVED, ACTION, true, 1.0, 1.1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(sourceOrganizationDTO, response.getBody());
        verify(sourceService).getSourceByHonAndApprovalStatus(HON, ApprovalStatus.APPROVED);
    }

    @Test
    void getSourceOrganization_shouldReturnViewModeSource() {
        when(sourceService.getSourceByHonAndApprovalStatus(HON, ApprovalStatus.APPROVED))
                .thenReturn(sourceOrganizationDTO);

        ResponseEntity<SourceOrganizationDTO> response =
                sourceApiController.getSourceOrganization(HON, "VIEW", ApprovalStatus.APPROVED, ACTION, false, 1.0, 1.1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(sourceOrganizationDTO, response.getBody());
        verify(sourceService).getSourceByHonAndApprovalStatus(HON, ApprovalStatus.APPROVED);
    }

    @Test
    void getSourceOrganization_shouldReturnEditModeSource() {
        when(sourceService.getSourceForEditByHon(HON, ACTION)).thenReturn(sourceOrganizationDTO);

        ResponseEntity<SourceOrganizationDTO> response =
                sourceApiController.getSourceOrganization(HON, "EDIT", ApprovalStatus.APPROVED, ACTION, false, 1.0, 1.1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(sourceOrganizationDTO, response.getBody());
        verify(sourceService).getSourceForEditByHon(HON, ACTION);
    }

    @Test
    void getSourceOrganization_shouldReturnOpToolViewSource() {
        when(sourceService.getSourceByHonForOpTool(HON)).thenReturn(sourceOrganizationDTO);

        ResponseEntity<SourceOrganizationDTO> response =
                sourceApiController.getSourceOrganization(HON, "optoolView", ApprovalStatus.APPROVED, ACTION, false, 1.0, 1.1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(sourceOrganizationDTO, response.getBody());
        verify(sourceService).getSourceByHonForOpTool(HON);
    }

    @Test
    void getSourceOrganization_shouldReturnOpToolEditSource() {
        when(sourceService.getSourceForEditByHon(HON, ACTION)).thenReturn(sourceOrganizationDTO);

        ResponseEntity<SourceOrganizationDTO> response =
                sourceApiController.getSourceOrganization(HON, "optoolEdit", ApprovalStatus.APPROVED, ACTION, false, 1.0, 1.1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(sourceOrganizationDTO, response.getBody());
        verify(sourceService).getSourceForEditByHon(HON, ACTION);
    }

    @Test
    void getSourceOrganization_shouldReturnNoContentForUnknownMode() {
        ResponseEntity<SourceOrganizationDTO> response =
                sourceApiController.getSourceOrganization(HON, "UNKNOWN", ApprovalStatus.APPROVED, ACTION, false, 1.0, 1.1);

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertNull(response.getBody());
        verify(sourceService, never()).getSourceByHonAndApprovalStatus(any(), any());
        verify(sourceService, never()).getSourceForEditByHon(any(), any());
        verify(sourceService, never()).getSourceByHonForOpTool(any());
    }

    @Test
    void updateVerificationData_shouldReturnOkAndPopulateTimings() {
        VerificationRequest verificationRequest = new VerificationRequest();
        verificationRequest.setApprovalStatus(ApprovalStatus.APPROVED);

        AutoMatchResponseDTO autoMatchResponseDTO = new AutoMatchResponseDTO();
        when(sourceService.incrementUsedCount(HON, ApprovalStatus.APPROVED)).thenReturn(autoMatchResponseDTO);

        ResponseEntity<AutoMatchResponseDTO> response =
                sourceApiController.updateVerificationData(HON, verificationRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(autoMatchResponseDTO, response.getBody());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().getStartTime() > 0);
        assertTrue(response.getBody().getRequestTime() >= 0);
        verify(sourceService).incrementUsedCount(HON, ApprovalStatus.APPROVED);
    }

    @Test
    void getSourceOrganizationsByHonIds_shouldReturnOk() {
        List<String> honIds = List.of("HON1", "HON2");
        List<SourceOrganizationDTO> sourceList = List.of(new SourceOrganizationDTO(), new SourceOrganizationDTO());

        when(sourceService.getSourcesByHonIds(honIds)).thenReturn(sourceList);

        ResponseEntity<List<SourceOrganizationDTO>> response =
                sourceApiController.getSourceOrganizationsByHonIds(honIds);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(sourceList, response.getBody());
        verify(sourceService).getSourcesByHonIds(honIds);
    }

    @Test
    void getSourceOrganizationsByHonIds_shouldThrowWhenLimitExceeds100() {
        List<String> honIds = new ArrayList<>();
        for (int i = 0; i < 101; i++) {
            honIds.add("HON" + i);
        }

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> sourceApiController.getSourceOrganizationsByHonIds(honIds));

        assertNotNull(exception);
        verify(sourceService, never()).getSourcesByHonIds(any());
    }

    @Test
    void assignApproveManagerToSource_shouldReturnOk() {
        ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
        ResponseObject responseObject = new ResponseObject();
        responseObject.setStatus("SUCCESS");

        when(sourceService.assignApproveManagerToSource(approvalRequestDTO)).thenReturn(responseObject);

        ResponseEntity<ResponseObject> response =
                sourceApiController.assignApproveManagerToSource(approvalRequestDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(responseObject, response.getBody());
        assertEquals("SUCCESS", response.getBody().getStatus());
        verify(sourceService).assignApproveManagerToSource(approvalRequestDTO);
    }

    @Test
    void updateFlagForPriority_shouldReturnOkWhenTrue() {
        when(sourceService.updateFlagForPriority(HON, 1.0)).thenReturn(true);

        ResponseEntity<ResponseObject> response =
                sourceApiController.updateFlagForPriority(HON, 1.0);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(HttpStatus.OK.toString(), response.getBody().getStatus());
        assertEquals("Organization with hon : " + HON + " flagged true for priority",
                response.getBody().getMessage());
        verify(sourceService).updateFlagForPriority(HON, 1.0);
    }

    @Test
    void updateFlagForPriority_shouldReturnOkWhenFalse() {
        when(sourceService.updateFlagForPriority(HON, 2.0)).thenReturn(false);

        ResponseEntity<ResponseObject> response =
                sourceApiController.updateFlagForPriority(HON, 2.0);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Organization with hon : " + HON + " flagged false for priority",
                response.getBody().getMessage());
        verify(sourceService).updateFlagForPriority(HON, 2.0);
    }

    @Test
    void updateUsedCount_shouldReturnOk() {
        UsedCountIncrementDTO usedCountIncrementDTO = new UsedCountIncrementDTO();
        usedCountIncrementDTO.setHon(HON);
        usedCountIncrementDTO.setAutoMatch(true);

        when(sourceService.updateUsedCount(HON, true)).thenReturn(true);

        ResponseEntity<Boolean> response = sourceApiController.updateUsedCount(usedCountIncrementDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(Boolean.TRUE, response.getBody());
        verify(sourceService).updateUsedCount(HON, true);
    }

    @Test
    void updateUsedCount_shouldThrowWhenHonIsNull() {
        UsedCountIncrementDTO usedCountIncrementDTO = new UsedCountIncrementDTO();
        usedCountIncrementDTO.setHon(null);

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> sourceApiController.updateUsedCount(usedCountIncrementDTO));

        assertNotNull(exception);
        verify(sourceService, never()).updateUsedCount(any(), anyBoolean());
    }

    @Test
    void updateUsedCount_shouldThrowWhenHonIsEmpty() {
        UsedCountIncrementDTO usedCountIncrementDTO = new UsedCountIncrementDTO();
        usedCountIncrementDTO.setHon("");

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> sourceApiController.updateUsedCount(usedCountIncrementDTO));

        assertNotNull(exception);
        verify(sourceService, never()).updateUsedCount(any(), anyBoolean());
    }

    @Test
    void deleteSource_shouldReturnOk() {
        DeleteRequestDTO deleteRequestDTO = new DeleteRequestDTO();
        ResponseObject responseObject = new ResponseObject();

        when(sourceService.deleteSource(HON, deleteRequestDTO)).thenReturn(responseObject);

        ResponseEntity<ResponseObject> response =
                sourceApiController.deleteSource(HON, deleteRequestDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(responseObject, response.getBody());
        verify(sourceService).deleteSource(HON, deleteRequestDTO);
    }

    @Test
    void lockSource_shouldReturnOk() {
        ResponseObject responseObject = new ResponseObject();
        when(sourceService.lockSource(HON, uiActionsDTO)).thenReturn(responseObject);

        ResponseEntity<ResponseObject> response =
                sourceApiController.lockSource(HON, uiActionsDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(responseObject, response.getBody());
        verify(sourceService).lockSource(HON, uiActionsDTO);
    }

    @Test
    void unlockSource_shouldReturnOk() {
        ResponseObject responseObject = new ResponseObject();
        when(sourceService.unlockSource(HON, uiActionsDTO)).thenReturn(responseObject);

        ResponseEntity<ResponseObject> response =
                sourceApiController.unlockSource(HON, uiActionsDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(responseObject, response.getBody());
        verify(sourceService).unlockSource(HON, uiActionsDTO);
    }

    @Test
    void updateSourceStatus_shouldReturnSuccessResponse() {
        when(sourceService.updateSourceStatus(HON, VERSION, TEMP_VERSION, ApprovalStatus.APPROVED)).thenReturn(true);

        ResponseEntity<ResponseObject> response =
                sourceApiController.updateSourceStatus(HON, ApprovalStatus.APPROVED, VERSION, TEMP_VERSION);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("SUCCESS", response.getBody().getStatus());
        assertEquals("Updated the status successfully", response.getBody().getMessage());
        verify(sourceService).updateSourceStatus(HON, VERSION, TEMP_VERSION, ApprovalStatus.APPROVED);
    }

    @Test
    void updateSourceStatus_shouldReturnFailureResponse() {
        when(sourceService.updateSourceStatus(HON, VERSION, TEMP_VERSION, ApprovalStatus.REJECTED)).thenReturn(false);

        ResponseEntity<ResponseObject> response =
                sourceApiController.updateSourceStatus(HON, ApprovalStatus.REJECTED, VERSION, TEMP_VERSION);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("FAILURE", response.getBody().getStatus());
        assertEquals("Update failed", response.getBody().getMessage());
        verify(sourceService).updateSourceStatus(HON, VERSION, TEMP_VERSION, ApprovalStatus.REJECTED);
    }

    @Test
    void getSourceOrganizationForRAM_shouldReturnOk() {
        RamResponseDTO ramResponseDTO = new RamResponseDTO();
        when(sourceService.getSourceForRAM(HON, sourceRequestDTO)).thenReturn(ramResponseDTO);

        ResponseEntity<RamResponseDTO> response =
                sourceApiController.getSourceOrganizationForRAM(HON, sourceRequestDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(ramResponseDTO, response.getBody());
        verify(sourceService).getSourceForRAM(HON, sourceRequestDTO);
    }
}