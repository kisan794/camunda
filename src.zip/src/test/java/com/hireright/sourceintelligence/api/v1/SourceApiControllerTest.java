package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.SOURCE_ORGANIZATION;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.SOURCE_ORGANIZATIONS;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.VERIFY;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.domain.enums.UserRoles;
import com.hireright.sourceintelligence.exception.GlobalApiExceptionHandler;
import com.hireright.sourceintelligence.service.CommonUtilService;
import com.hireright.sourceintelligence.service.SearchService;
import com.hireright.sourceintelligence.service.SourceHistoryService;
import com.hireright.sourceintelligence.service.SourceService;
import com.hireright.sourceintelligence.util.TestDataProvider;

import java.util.*;

import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
class SourceApiControllerTest {

    private MockMvc mockMvc;

    @InjectMocks
    private SourceApiController sourceApiController;

    @Mock
    private SourceService sourceService;

    @Mock
    private SearchService searchService;

    @Mock
    private SourceHistoryService sourceHistoryService;


    @Mock
    private CommonUtilService commonUtilService;

    @Mock
    private HttpServletRequest httpServletRequest;

    @Mock
    private UserInfo userInfo;

    @BeforeEach
    public void setup() {
        JacksonTester.initFields(this, new ObjectMapper());
        // MockMvc standalone approach
        mockMvc =
                MockMvcBuilders.standaloneSetup(sourceApiController)
                        .setControllerAdvice(new GlobalApiExceptionHandler())
                        .build();

        userInfo = new UserInfo();
        userInfo.setRoles(List.of(UserRoles.RESEARCH_ANALYST.getRole()));
        userInfo.setRoles(Collections.singletonList("ROLE_CREATE_SOURCE"));
    }

    @Test
    void createSourceOrganizationTest() throws Exception {
        SourceRequestDTO sourceRequestDTO = new SourceRequestDTO();
        SourceOrganizationDTO sourceOrganizationDTO = sourceRequestDTO.getSourceOrganizationDTO();
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);

//        when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);

        ResponseEntity<SourceOrganizationDTO> response = sourceApiController.createSourceOrganization(sourceRequestDTO,
                mockRequest);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        verify(sourceService, times(1)).createSource(eq(sourceOrganizationDTO), any());
    }

    @Test
    void updateSourceOrganizationTest() throws Exception {
        SourceOrganizationDTO sourceOrganizationDTO = TestDataProvider.getSourceOrganizationDTO();
        String hon = TestDataProvider.getHon();
        assertNotNull("SourceOrganizationDTO should not be null", sourceOrganizationDTO);
        sourceOrganizationDTO.setHon(hon);
        SourceRequestDTO sourceRequestDTO = new SourceRequestDTO();
        sourceRequestDTO.setSourceOrganizationDTO(sourceOrganizationDTO);
        //when(commonUtilService.getUserInfo(any())).thenReturn(TestDataProvider.getUserInfo());
        mockMvc.perform(MockMvcRequestBuilders
                        .put(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + "/" + hon)
                        .content(new ObjectMapper().writeValueAsString(sourceRequestDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk());
    }

    //    @Test
    void updateSourceOrganizationTest_WhenDuplicateExists() throws Exception {
        SourceOrganizationDTO sourceOrganizationDTO = TestDataProvider.getSourceOrganizationDTO();
        String hon = TestDataProvider.getHon();
        sourceOrganizationDTO.setHon(hon);
        when(commonUtilService.getUserInfo(any())).thenReturn(TestDataProvider.getUserInfo());
        //when(sourceOrganizationHistoryService.getPossibleDuplicateSources(any())).thenReturn(TestDataProvider.getSourceOrganizationEntity());
        mockMvc.perform(MockMvcRequestBuilders
                        .put(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + "/" + hon)
                        .content(new ObjectMapper().writeValueAsString(sourceOrganizationDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void getSourceOrganizationTest() throws Exception {
        String hon = TestDataProvider.getHon();

        mockMvc.perform(MockMvcRequestBuilders
                        .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + "/" + hon)
                        .param("mode", "VIEW")
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().isOk());
    }

    @Test
    void updateVerificationDataTest() throws Exception {
        String hon = TestDataProvider.getHon();

        VerificationRequest verificationRequest = new VerificationRequest();
        verificationRequest.setLastVerificationDate(new Date());
        AutoMatchResponseDTO mockResponse = new AutoMatchResponseDTO();
        when(sourceService.incrementUsedCount(eq(hon), any())).thenReturn(mockResponse);

        mockMvc.perform(MockMvcRequestBuilders
                        .put(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + "/" + hon + VERIFY)
                        .content(new ObjectMapper().writeValueAsString(verificationRequest))
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk());
    }


    @Test
    void assignApproveManagerToSource_directTest() {
        ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();

        ResponseObject mockResponse = new ResponseObject();
        mockResponse.setStatus("SUCCESS");

        when(sourceService.assignApproveManagerToSource(any(ApprovalRequestDTO.class)))
                .thenReturn(mockResponse);

        ResponseEntity<ResponseObject> response =
                sourceApiController.assignApproveManagerToSource(approvalRequestDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("SUCCESS", response.getBody().getStatus());
    }


    @Test
    void updateFlagForPriorityTest() throws Exception {
        String hon = TestDataProvider.getHon();
        Double version = 1.0;
        when(sourceService.updateFlagForPriority(hon, version)).thenReturn(true);
        mockMvc.perform(MockMvcRequestBuilders
                        .put(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + "/" + hon + "/version/" + version + "/flag")
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk());
    }

    @Test
    void updateVerificationData_BadRequestTest() throws Exception {
        String hon = TestDataProvider.getHon();
        VerificationRequest verificationRequest = new VerificationRequest();
        verificationRequest.setLastVerificationDate(new Date());
        mockMvc.perform(MockMvcRequestBuilders
                        .put(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION + "/" + hon + VERIFY)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getSourceOrganizationsByHonIdsTest() throws Exception {
        List<String> honIds = new ArrayList<>();
        honIds.add(TestDataProvider.getHon());
        honIds.add(TestDataProvider.getHon());
        mockMvc.perform(MockMvcRequestBuilders
                        .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATIONS)
                        .content(new ObjectMapper().writeValueAsString(honIds))
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .accept(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk());
    }


}