package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.APPROVAL_WORKFLOW;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.CHANGE_LOG;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.HISTORY;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.SOURCE_ORGANIZATION;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.SOURCE_ORGANIZATION_AUTOCOMPLETE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.hireright.sourceintelligence.api.ApiConstants.ApiPath;
import com.hireright.sourceintelligence.api.dto.DateRange;
import com.hireright.sourceintelligence.api.dto.SearchResponseDTO;
import com.hireright.sourceintelligence.api.dto.UserInfo;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogFilters;
import com.hireright.sourceintelligence.api.dto.history.Location;
import com.hireright.sourceintelligence.api.dto.history.SearchHistoryFilter;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.ChangeLogActivity;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.exception.GlobalApiExceptionHandler;
import com.hireright.sourceintelligence.service.CommonUtilService;
import com.hireright.sourceintelligence.service.SearchHistoryService;
import com.hireright.sourceintelligence.util.TestDataProvider;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ExtendWith(MockitoExtension.class)
class SearchHistoryApiControllerTest {

  private MockMvc mockMvc;

  @InjectMocks
  private SearchHistoryApiController searchHistoryApiController;

  @Mock
  private SearchHistoryService searchHistoryService;

  @Mock
  private CommonUtilService commonUtilService;


  @BeforeEach
  public void setup() {
    JacksonTester.initFields(this, new ObjectMapper());
    // MockMvc standalone approach
    mockMvc =
            MockMvcBuilders.standaloneSetup(searchHistoryApiController)
                    .setControllerAdvice(new GlobalApiExceptionHandler())
                    .build();
  }


  @Test
  void autocompleteFiltersTest_NotFound() throws Exception {
    mockMvc.perform(MockMvcRequestBuilders
                    .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + SOURCE_ORGANIZATION_AUTOCOMPLETE + ApiPath.SEARCH)
                    .param("searchKey", "Pedro Tores School")
                    .param("startPage", "1")
                    .param("pageSize", "10")
                    .accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isNotFound());
  }


  @Test
  void sourceOrganizationsByFiltersNotFound() throws Exception {
    mockMvc.perform(MockMvcRequestBuilders
                    .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH+ SOURCE_ORGANIZATION )
                    .content(new ObjectMapper().writeValueAsString(new SearchHistoryFilter()))
                    .param("searchPhrase", "Pedro Tores School")
                    .param("startPage", "1")
                    .param("pageSize", "10")
                    .accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isNotFound());
  }
  @Test
  void getFiltersForSourceOrganizationsWithReseacherRoleTest() throws Exception {

    mockMvc.perform(MockMvcRequestBuilders
                    .get(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH+ APPROVAL_WORKFLOW +SOURCE_ORGANIZATION +  "/filters")
                    .param("organizationName", "Pedro Tores School")
                    .param("hon",TestDataProvider.getHon())
                    .accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isNotFound());
  }


  @Test
  void changeLogsByFiltersTest() throws Exception {
    when(searchHistoryService.getChangeLogsByFilters(any()))
            .thenReturn(TestDataProvider.getSearchListHistoryDTO());
    ChangeLogFilters changeLogFilters = new ChangeLogFilters();
    DateRange dateRange = new DateRange();

    String instantExpected = "2014-12-22T10:15:30Z";
    Clock clock = Clock.fixed(Instant.parse(instantExpected), ZoneId.of("UTC"));
    Instant instant = Instant.now(clock);

    dateRange.setEndDate(instant);
    dateRange.setStartDate(instant);
    changeLogFilters.setDateRange(dateRange);
    changeLogFilters.setActivities(Arrays.asList(ChangeLogActivity.NEW_RECORD.getChangeLogActivity(),ChangeLogActivity.DETAILS_CHANGED
            .getChangeLogActivity(),ChangeLogActivity.ARCHIVED.getChangeLogActivity()));
    JavaTimeModule module = new JavaTimeModule();
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(module);
    mockMvc.perform(MockMvcRequestBuilders
                    .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH+ APPROVAL_WORKFLOW +SOURCE_ORGANIZATION + CHANGE_LOG)
                    .param("organizationName", "Pedro Tores School")
                    .param("organizationType",OrganizationType.EDUCATION.toString())
                    .content(objectMapper.writeValueAsString(changeLogFilters))
                    .param("startPage", "1")
                    .param("pageSize", "10")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isOk());
  }

  //TODO ravi changes
  @Test
  void changeLogsByFilters_ValidInput_ReturnsOk() {

    String hon = "hon456";
    String instantExpected = "2014-12-22T10:15:30Z";
    Clock clock = Clock.fixed(Instant.parse(instantExpected), ZoneId.of("UTC"));

    Instant instant = Instant.now(clock);
    DateRange dateRange = new DateRange();
    dateRange.setEndDate(instant);
    dateRange.setStartDate(instant);
    ChangeLogFilters changeLogFilters = new ChangeLogFilters();
    changeLogFilters.setActivities(Arrays.asList(
            ChangeLogActivity.NEW_RECORD.getChangeLogActivity(),
            ChangeLogActivity.DETAILS_CHANGED.getChangeLogActivity(),
            ChangeLogActivity.ARCHIVED.getChangeLogActivity()));
    changeLogFilters.setDateRange(dateRange);

    SearchResponseDTO mockResponse = new SearchResponseDTO();
    mockResponse.setTotalItems(10L);

    Mockito.when(searchHistoryService.getChangeLogsByFilters(any()))
            .thenReturn(mockResponse);


    ResponseEntity<SearchResponseDTO> responseEntity = searchHistoryApiController
            .changeLogsByFilters(changeLogFilters);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(10L, Long.parseLong(responseEntity.getHeaders().getFirst("X-SourceIntelligence-total-count")));
  }


  @Test
  void changeLogsByFilters_EmptyActivities_ReturnsOk() {
    // Mocking
    String instantExpected = "2014-12-22T10:15:30Z";
    Clock clock = Clock.fixed(Instant.parse(instantExpected), ZoneId.of("UTC"));

    Instant instant = Instant.now(clock);
    DateRange dateRange = new DateRange();
    dateRange.setEndDate(instant);
    dateRange.setStartDate(instant);
    ChangeLogFilters changeLogFilters = new ChangeLogFilters();
    changeLogFilters.setDateRange(dateRange);
    changeLogFilters.setOrganizationType(OrganizationType.EDUCATION);
    changeLogFilters.setStartPage(1);
    changeLogFilters.setPageSize(10);

    SearchResponseDTO mockResponse = new SearchResponseDTO();
    mockResponse.setTotalItems(5L);

    when(searchHistoryService.getChangeLogsByFilters(any()))
            .thenReturn(mockResponse);

    // Test
    ResponseEntity<SearchResponseDTO> responseEntity = searchHistoryApiController
            .changeLogsByFilters(changeLogFilters);

    // Assertions
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(5L, Long.parseLong(responseEntity.getHeaders().getFirst("X-SourceIntelligence-total-count")));
  }

  @Test
  void changeLogsByFilters_NullChangeLogFilters_ReturnsBadRequest() {
    // Test with null ChangeLogFilters
    Assertions.assertThrows(NullPointerException.class, () -> {
      searchHistoryApiController.changeLogsByFilters(null);
    });

  }


  @Test
  void changeLogByFiltersNotFound() throws Exception {
    mockMvc.perform(MockMvcRequestBuilders
                    .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH+ SOURCE_ORGANIZATION )
                    .content(new ObjectMapper().writeValueAsString(new ChangeLogFilters()))
                    .param("searchPhrase", "Pedro Tores School")
                    .param("startPage", "1")
                    .param("pageSize", "10")
                    .accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isNotFound());
  }
  //TODO end the code
  @Test
  void ChangeLogByFilters_badParam() throws Exception {
    mockMvc.perform(MockMvcRequestBuilders
                    .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH+ APPROVAL_WORKFLOW +SOURCE_ORGANIZATION + CHANGE_LOG)
                    .param("startPage", "1")
                    .param("pageSize", "10")
                    .accept(MediaType.APPLICATION_JSON_VALUE)
                    .contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isBadRequest());

    mockMvc.perform(MockMvcRequestBuilders
                    .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH+ APPROVAL_WORKFLOW +SOURCE_ORGANIZATION
                            + CHANGE_LOG)
                    .param("organizationName", "")
                    .param("startPage", "1")
                    .param("pageSize", "10")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isBadRequest());
  }

  //@Test
  void ChangeLogByFilters_badRequest_StartDateMissing() throws Exception {
    mockMvc.perform(MockMvcRequestBuilders
                    .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + APPROVAL_WORKFLOW + SOURCE_ORGANIZATION
                            + CHANGE_LOG)
                    .param("organizationName", "")
                    .param("startPage", "1")
                    .param("pageSize", "10")
                    .content(new ObjectMapper().writeValueAsString(new ChangeLogFilters()))
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isBadRequest());

    ChangeLogFilters changeLogFilters = new ChangeLogFilters();
    DateRange dateRange = new DateRange();
    String instantExpected = "2014-12-22T10:15:30Z";
    Clock clock = Clock.fixed(Instant.parse(instantExpected), ZoneId.of("UTC"));
    Instant instant = Instant.now(clock);
    dateRange.setEndDate(instant);
    changeLogFilters.setDateRange(dateRange);
    JavaTimeModule module = new JavaTimeModule();
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(module);

    mockMvc.perform(MockMvcRequestBuilders
                    .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + APPROVAL_WORKFLOW + SOURCE_ORGANIZATION
                            + CHANGE_LOG)
                    .param("organizationName", "")
                    .param("startPage", "1")
                    .param("pageSize", "10")
                    .content(objectMapper.writeValueAsString(changeLogFilters))
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isBadRequest());
  }

  //@Test
  void ChangeLogByFilters_badRequest_ActivityMissing() throws Exception {

    ChangeLogFilters changeLogFilters = new ChangeLogFilters();
    DateRange dateRange = new DateRange();
    String instantExpected = "2014-12-22T10:15:30Z";
    Clock clock = Clock.fixed(Instant.parse(instantExpected), ZoneId.of("UTC"));
    Instant instant = Instant.now(clock);

    dateRange.setEndDate(instant);
    dateRange.setStartDate(instant);
    changeLogFilters.setDateRange(dateRange);
    JavaTimeModule module = new JavaTimeModule();
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(module);

    mockMvc.perform(MockMvcRequestBuilders
                    .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH + APPROVAL_WORKFLOW + SOURCE_ORGANIZATION
                            + CHANGE_LOG)
                    .param("organizationName", "")
                    .param("startPage", "1")
                    .param("pageSize", "10")
                    .content(objectMapper.writeValueAsString(changeLogFilters))
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isBadRequest());
  }

  //@Test
  void changeLogByFiltersTest_UnAuthorized() throws Exception {
    UserInfo userInfo = TestDataProvider.getUserInfo();
    userInfo.setRoles(Arrays.asList("ResearchAnalyst"));
    //when(commonUtilService.getUserInfo(any())).thenReturn(userInfo);
    when(commonUtilService.isResearchAnalyst(any())).thenReturn(true);
    mockMvc.perform(MockMvcRequestBuilders
                    .post(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH+ APPROVAL_WORKFLOW +SOURCE_ORGANIZATION + CHANGE_LOG)
                    .param("organizationName", "Pedro Tores School")
                    .content(new ObjectMapper().writeValueAsString(new ChangeLogFilters()))
                    .param("startPage", "1")
                    .param("pageSize", "10")
                    .contentType(MediaType.APPLICATION_JSON_VALUE)
                    .accept(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(status().isUnauthorized());
  }
}
