package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.rds.VendorResponseDTO;
import com.hireright.sourceintelligence.service.RDSService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RDSApiControllerTest {

    @Mock
    private RDSService rdsService;

    @InjectMocks
    private RDSApiController rdsApiController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    void testGetVendorsList_ReturnsExpectedResponse() {
        // Arrange
        VendorResponseDTO mockResponse = new VendorResponseDTO();
        when(rdsService.getVendorList()).thenReturn(mockResponse);

        // Act
        ResponseEntity<VendorResponseDTO> response = rdsApiController.getVendorsList();

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(mockResponse, response.getBody());
        verify(rdsService, times(1)).getVendorList();
    }

}
