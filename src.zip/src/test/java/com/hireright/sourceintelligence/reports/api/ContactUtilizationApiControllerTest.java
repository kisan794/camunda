package com.hireright.sourceintelligence.reports.api;


import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.ContactUtilizationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ContactUtilizationApiControllerTest {

    @InjectMocks
    private ContactUtilizationApiController reportsApiController;

    @Mock
    private ContactUtilizationService contactUtilizationService;

    @Test
    void testGetAutoMatch() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        ReportResponseDTO mockResponse = new ReportResponseDTO();
        when(contactUtilizationService.getContactUtilization(requestDTO)).thenReturn(mockResponse);

        ResponseEntity<ReportResponseDTO> response = reportsApiController.getContactUtilization(requestDTO);

        assertNotNull(response, "Response should not be null");
        assertEquals(HttpStatus.OK, response.getStatusCode(), "Status should be 200 OK");
        assertEquals(mockResponse, response.getBody(), "Response body should match the mock response");
    }
}
