package com.hireright.sourceintelligence.reports.service;

import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.entity.ResponseReport;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.GenericResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.impl.AutoMatchServiceImpl;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.aggregation.Aggregation;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AutoMatchServiceImplTest {

    @InjectMocks
    private AutoMatchServiceImpl autoMatchService;

    @Mock
    private ReportMapper reportMapper;

    @Mock
    private CustomSourceRepository<Reports> customSourceRepository;

    @Mock
    private CountryRegionMappingUtils countryRegionMappingUtils;

    @Test
    void getAutoMatchReport_shouldReturnEmptyResponse_whenNoRegionAndEmptyResultList() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setStartPage(1);
        requestDTO.setBatchSize(10);
        requestDTO.setSort("createdDate");
        requestDTO.setOrder("desc");
        requestDTO.setRegion(null);

        ReportSearchResult mockResult = new ReportSearchResult();
        mockResult.setResponseReportList(Collections.emptyList());
        mockResult.setTotal(0);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockResult);

        ReportResponseDTO response = autoMatchService.getAutoMatchReport(requestDTO);

        assertNotNull(response);
        assertEquals(0, response.getTotalItems());
        assertEquals(1, response.getCurrentPage());
        assertNotNull(response.getMeta());
        assertNotNull(response.getResponse());
        assertTrue(response.getResponse().isEmpty());

        verify(customSourceRepository).reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
        verifyNoInteractions(countryRegionMappingUtils);
        verifyNoInteractions(reportMapper);
    }

    @Test
    void getAutoMatchReport_shouldCallCountryMapping_whenRegionProvided() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setStartPage(1);
        requestDTO.setBatchSize(10);
        requestDTO.setSort("createdDate");
        requestDTO.setOrder("desc");
        requestDTO.setRegion("APAC");

        when(countryRegionMappingUtils.findDistinctCountriesByRegion("APAC"))
                .thenReturn(List.of("India", "Japan"));

        ReportSearchResult mockResult = new ReportSearchResult();
        mockResult.setResponseReportList(Collections.emptyList());
        mockResult.setTotal(0);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockResult);

        ReportResponseDTO response = autoMatchService.getAutoMatchReport(requestDTO);

        assertNotNull(response);
        assertEquals(0, response.getTotalItems());
        assertTrue(response.getResponse().isEmpty());

        verify(countryRegionMappingUtils).findDistinctCountriesByRegion("APAC");
        verify(customSourceRepository).reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
        verifyNoInteractions(reportMapper);
    }

    @Test
    void getAutoMatchReport_shouldMapResponse_whenResultListNotEmpty() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setStartPage(1);
        requestDTO.setBatchSize(5);
        requestDTO.setSort("createdDate");
        requestDTO.setOrder("desc");

        ResponseReport rr = new ResponseReport();
        ReportSearchResult mockResult = new ReportSearchResult();
        mockResult.setResponseReportList(List.of(rr));
        mockResult.setTotal(1);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockResult);

        when(reportMapper.toDTOList(anyList()))
                .thenReturn(List.of(new GenericResponseDTO()));

        ReportResponseDTO response = autoMatchService.getAutoMatchReport(requestDTO);

        assertNotNull(response);
        assertEquals(1, response.getTotalItems());
        assertEquals(1, response.getResponse().size());

        verify(customSourceRepository).reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
        verify(reportMapper).toDTOList(anyList());
    }

    @Test
    void getAutoMatchReport_shouldPropagateException_fromRepository() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setStartPage(1);
        requestDTO.setBatchSize(10);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenThrow(new RuntimeException("Database error"));

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> autoMatchService.getAutoMatchReport(requestDTO));

        assertEquals("Database error", ex.getMessage());
        verify(customSourceRepository).reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
    }
}