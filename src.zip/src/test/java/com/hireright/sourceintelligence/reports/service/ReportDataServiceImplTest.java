package com.hireright.sourceintelligence.reports.service;

import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.ReportsDTO;
import com.hireright.sourceintelligence.reports.service.impl.ReportDataServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReportDataServiceImplTest {

    @InjectMocks
    private ReportDataServiceImpl reportDataService;

    @Mock
    private CustomSourceRepository<Reports> customSourceRepository;

    @Mock
    private ReportMapper reportMapper;

    @Test
    void testCreateData_Success() {
        // Arrange
        ReportsDTO reportsDTO = new ReportsDTO();
        Reports mockReports = new Reports();

        when(reportMapper.dtoToEntity(any(ReportsDTO.class))).thenReturn(mockReports);

        // Act
        reportDataService.createData(reportsDTO);

        // Assert
        verify(reportMapper, times(1)).dtoToEntity(any(ReportsDTO.class));
        verify(customSourceRepository, times(1)).create(any(Reports.class), eq(Reports.class), eq("reports"));
    }
}
