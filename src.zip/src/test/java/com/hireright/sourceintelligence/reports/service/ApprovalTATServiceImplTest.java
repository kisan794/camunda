package com.hireright.sourceintelligence.reports.service;

import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.entity.ResponseReport;
import com.hireright.sourceintelligence.reports.domain.entity.TATReport;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.GenericResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.impl.ApprovalTATServiceImpl;
import com.hireright.sourceintelligence.reports.service.impl.ReportsQueryBuilder;
import com.hireright.sourceintelligence.service.impl.QueryBuilder;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.aggregation.*;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApprovalTATServiceImplTest {

    @InjectMocks
    private ApprovalTATServiceImpl approvalTATService;

    @Mock
    private ReportMapper reportMapper;

    @Mock
    private CustomSourceRepository<Reports> customSourceRepository;

    @Mock
    private CountryRegionMappingUtils countryRegionMappingUtils;

    private ReportsRequestDTO baseRequest() {
        ReportsRequestDTO dto = new ReportsRequestDTO();
        dto.setStartPage(1);
        dto.setBatchSize(10);
        dto.setSort("");
        dto.setOrder("asc");
        dto.setRegion(null);
        return dto;
    }

    private static ResponseReport rr(String status, Instant created, String action) {
        ResponseReport r = new ResponseReport();
        r.setApprovalStatus(status);
        r.setCreatedDate(created);
        r.setAction(action);
        return r;
    }

    private static TATReport tat(List<ResponseReport> data) {
        TATReport t = new TATReport();
        t.setData(data);
        return t;
    }

    @Test
    void testGetApprovalAverageTAT_WithEmptyResponse() {
        // Arrange
        ReportsRequestDTO requestDTO = baseRequest();

        ReportSearchResult mockResult = new ReportSearchResult();
        mockResult.setTatResponseReportList(Collections.emptyList());
        mockResult.setTotal(0);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockResult);

        // Act
        ReportResponseDTO response = approvalTATService.getApprovalAverageTAT(requestDTO);

        // Assert
        assertNotNull(response);
        assertNotNull(response.getResponse());
        assertTrue(response.getResponse().isEmpty());

        assertEquals(0, response.getTotalItems());
        assertEquals(QueryBuilder.getTotalPages(0, requestDTO.getBatchSize()), response.getTotalPages());
        assertEquals(requestDTO.getStartPage(), response.getCurrentPage());

        verify(customSourceRepository).reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
        verifyNoInteractions(reportMapper);
        verifyNoInteractions(countryRegionMappingUtils);
    }

    @Test
    void testGetApprovalAverageTAT_WithRegion_ShouldCallCountryMapping() {
        // Arrange
        ReportsRequestDTO requestDTO = baseRequest();
        requestDTO.setRegion("APAC");

        when(countryRegionMappingUtils.findDistinctCountriesByRegion("APAC"))
                .thenReturn(List.of("India", "Japan"));

        ReportSearchResult mockResult = new ReportSearchResult();
        mockResult.setTatResponseReportList(Collections.emptyList());
        mockResult.setTotal(0);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockResult);

        // Act
        ReportResponseDTO response = approvalTATService.getApprovalAverageTAT(requestDTO);

        // Assert
        assertNotNull(response);
        verify(countryRegionMappingUtils).findDistinctCountriesByRegion("APAC");
        verify(customSourceRepository).reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
        verifyNoInteractions(reportMapper);
    }

    @Test
    void testGetApprovalAverageTAT_WithSortProvided_ShouldGoThroughSortingFacet_AndReturnMappedResponse() {

        ReportsRequestDTO requestDTO = baseRequest();
        requestDTO.setSort("lastActive");
        requestDTO.setOrder("desc");

        Instant t0 = Instant.parse("2025-01-01T10:00:00Z");
        Instant t1 = Instant.parse("2025-01-01T10:10:00Z");
        Instant t2 = Instant.parse("2025-01-01T10:20:00Z");
        Instant t3 = Instant.parse("2025-01-01T10:30:00Z");

        List<ResponseReport> data = new ArrayList<>();
        data.add(rr(ApprovalStatus.PENDING_APPROVAL.getStatus(), t0, "CREATE"));
        data.add(rr(ApprovalStatus.IN_PROGRESS.getStatus(), t1, ""));
        data.add(rr(ApprovalStatus.ONHOLD.getStatus(), t2, ""));
        data.add(rr(ApprovalStatus.APPROVED.getStatus(), t3, "CREATE"));

        ReportSearchResult mockResult = new ReportSearchResult();
        mockResult.setTatResponseReportList(List.of(tat(data)));
        mockResult.setTotal(1);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockResult);

        when(reportMapper.toDTOList(anyList()))
                .thenReturn(List.of(new GenericResponseDTO()));

        try (MockedStatic<ReportsQueryBuilder> mocked = mockStatic(ReportsQueryBuilder.class)) {

            Criteria c1 = mock(Criteria.class);
            Criteria c2 = mock(Criteria.class);

            MatchOperation match1 = mock(MatchOperation.class);
            MatchOperation match2 = mock(MatchOperation.class);
            ProjectionOperation proj = mock(ProjectionOperation.class);
            GroupOperation group = mock(GroupOperation.class);
            SortOperation sortOp = mock(SortOperation.class);
            FacetOperation facetWithSort = mock(FacetOperation.class);
            ProjectionOperation finalProj = mock(ProjectionOperation.class);

            mocked.when(() -> ReportsQueryBuilder.queryBuilderForApprovalTat(eq(requestDTO), any()))
                    .thenReturn(c1);
            mocked.when(() -> ReportsQueryBuilder.matchOperation(eq(c1)))
                    .thenReturn(match1);

            mocked.when(ReportsQueryBuilder::queryBuilderForTatFilter)
                    .thenReturn(c2);
            mocked.when(() -> ReportsQueryBuilder.matchOperation(eq(c2)))
                    .thenReturn(match2);

            mocked.when(ReportsQueryBuilder::excludeProjection)
                    .thenReturn(proj);
            mocked.when(ReportsQueryBuilder::approvalTATGroupOperation)
                    .thenReturn(group);

            mocked.when(() -> ReportsQueryBuilder.buildSortOperationForTAT(eq("lastActive"), eq("desc")))
                    .thenReturn(sortOp);

            mocked.when(() -> ReportsQueryBuilder.facetOperationWithSorting(eq(sortOp), eq(requestDTO.getStartPage()), eq(requestDTO.getBatchSize())))
                    .thenReturn(facetWithSort);

            mocked.when(() -> ReportsQueryBuilder.facetOperation(eq(requestDTO.getStartPage()), eq(requestDTO.getBatchSize())))
                    .thenReturn(mock(FacetOperation.class));

            mocked.when(() -> ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline(anyString()))
                    .thenReturn(finalProj);

            // Act
            ReportResponseDTO response = approvalTATService.getApprovalAverageTAT(requestDTO);

            // Assert
            assertNotNull(response);
            assertNotNull(response.getResponse());
            assertEquals(1, response.getResponse().size());

            assertEquals(1, response.getTotalItems());
            assertEquals(QueryBuilder.getTotalPages(1, requestDTO.getBatchSize()), response.getTotalPages());
            assertEquals(requestDTO.getStartPage(), response.getCurrentPage());

            verify(customSourceRepository)
                    .reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
            verify(reportMapper).toDTOList(anyList());

            mocked.verify(() -> ReportsQueryBuilder.facetOperationWithSorting(eq(sortOp), eq(requestDTO.getStartPage()), eq(requestDTO.getBatchSize())));
        }
    }

    @Test
    void testGetApprovalAverageTAT_DataSize1_ShouldNotAddToResponse_ButCoverBranch() {
        // Arrange
        ReportsRequestDTO requestDTO = baseRequest();
        requestDTO.setSort(""); // non-sorting path

        Instant t0 = Instant.parse("2025-01-01T10:00:00Z");
        List<ResponseReport> single = List.of(rr(ApprovalStatus.PENDING_APPROVAL.getStatus(), t0, "CREATE"));

        ReportSearchResult mockResult = new ReportSearchResult();
        mockResult.setTatResponseReportList(List.of(tat(single)));
        mockResult.setTotal(1);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockResult);

        // Act
        ReportResponseDTO response = approvalTATService.getApprovalAverageTAT(requestDTO);

        // Assert
        assertNotNull(response);
        assertTrue(response.getResponse().isEmpty());
        assertEquals(0, response.getTotalItems());

        verify(customSourceRepository).reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
        verifyNoInteractions(reportMapper);
    }

    @Test
    void testGetApprovalAverageTAT_WithException() {
        // Arrange
        ReportsRequestDTO requestDTO = baseRequest();

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenThrow(new RuntimeException("Database error"));

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> approvalTATService.getApprovalAverageTAT(requestDTO));

        assertEquals("Database error", ex.getMessage());
    }
}