package com.hireright.sourceintelligence.reports.service;

import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.*;
import com.hireright.sourceintelligence.reports.service.impl.ReportsQueryBuilder;
import com.hireright.sourceintelligence.reports.service.impl.SourceInformationServiceImpl;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.aggregation.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SourceInformationServiceImplTest {

    @InjectMocks
    private SourceInformationServiceImpl sourceInformationService;

    @Mock
    private ReportMapper reportMapper;

    @Mock
    private CustomSourceRepository<Reports> customSourceRepository;

    @Mock
    private CountryRegionMappingUtils countryRegionMappingUtils;


    @Test
    void getSourceInformation_shouldThrow_whenOperatorRoleEmpty() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setOperatorRole("");

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> sourceInformationService.getSourceInformation(requestDTO));

        assertEquals("Operator role cannot be null or empty", ex.getMessage());
        verifyNoInteractions(customSourceRepository);
        verifyNoInteractions(countryRegionMappingUtils);
    }

    @Test
    void getSourceInformation_shouldThrow_whenOperatorRoleInvalid() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setOperatorRole("SomethingElse");

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> sourceInformationService.getSourceInformation(requestDTO));

        assertEquals("Invalid operator role: SomethingElse", ex.getMessage());
        verifyNoInteractions(customSourceRepository);
        verifyNoInteractions(countryRegionMappingUtils);
    }

    @Test
    void getSourceInformation_originator_shouldReturnResponse_whenNoRegion_andNoFlatList() {
        // Arrange
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setOperatorRole("Originator");
        requestDTO.setStartPage(1);
        requestDTO.setBatchSize(10);
        requestDTO.setSort("operator_name");
        requestDTO.setOrder("asc");
        requestDTO.setRegion(null);

        ReportSearchResult mockResult = new ReportSearchResult();
        mockResult.setTotal(5);
        mockResult.setOperatorReportFlatList(Collections.emptyList());

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockResult);

        try (MockedStatic<ReportsQueryBuilder> mocked = mockStatic(ReportsQueryBuilder.class)) {

            Criteria criteria = mock(Criteria.class);
            MatchOperation matchOp = mock(MatchOperation.class);
            GroupOperation groupOp = mock(GroupOperation.class);
            SortOperation sortOp = mock(SortOperation.class);
            ProjectionOperation finalProj = mock(ProjectionOperation.class);

            mocked.when(() -> ReportsQueryBuilder.queryBuilderForSourceInformationAndTat(eq(requestDTO), isNull()))
                    .thenReturn(criteria);

            mocked.when(() -> ReportsQueryBuilder.matchOperation(eq(criteria)))
                    .thenReturn(matchOp);

            mocked.when(ReportsQueryBuilder::operatorRoleGroupOperation)
                    .thenReturn(groupOp);

            mocked.when(() -> ReportsQueryBuilder.buildSortOperationForOperator(eq("operator_name"), eq("asc")))
                    .thenReturn(sortOp);

            mocked.when(ReportsQueryBuilder::operatorRoleFinalProjection)
                    .thenReturn(finalProj);

            // Act
            ReportResponseDTO response = sourceInformationService.getSourceInformation(requestDTO);

            // Assert
            assertNotNull(response);
            assertEquals(5, response.getTotalItems());
            assertEquals(1, response.getCurrentPage());
            assertNotNull(response.getResponse());
            assertTrue(response.getResponse().isEmpty(), "Empty flat list => empty response");

            verify(customSourceRepository, times(1))
                    .reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
            verifyNoInteractions(countryRegionMappingUtils);
            verifyNoInteractions(reportMapper);
        }
    }

    @Test
    void getSourceInformation_originator_shouldMapFlatList_andManualSortTotal() {
        // Arrange
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setOperatorRole("Originator");
        requestDTO.setStartPage(1);
        requestDTO.setBatchSize(10);
        requestDTO.setSort("total");
        requestDTO.setOrder("desc");
        requestDTO.setRegion("APAC");

        when(countryRegionMappingUtils.findDistinctCountriesByRegion("APAC"))
                .thenReturn(List.of("India", "Japan"));

        OperatorReportFlatDTO f1 = OperatorReportFlatDTO.builder()
                .operatorName("A")
                .addedNew(1).addedInProgress(0).addedOnHold(0).addedCancelled(0).addedCompleted(0)
                .changedNew(0).changedInProgress(0).changedOnHold(0).changedCancelled(0).changedCompleted(0)
                .archivedNew(0).archivedInProgress(0).archivedOnHold(0).archivedCancelled(0).archivedCompleted(0)
                .deletedNew(0).deletedInProgress(0).deletedOnHold(0).deletedCancelled(0).deletedCompleted(0)
                .build();

        OperatorReportFlatDTO f2 = OperatorReportFlatDTO.builder()
                .operatorName("B")
                .addedNew(2).addedInProgress(0).addedOnHold(0).addedCancelled(0).addedCompleted(0)
                .changedNew(0).changedInProgress(0).changedOnHold(0).changedCancelled(0).changedCompleted(0)
                .archivedNew(0).archivedInProgress(0).archivedOnHold(0).archivedCancelled(0).archivedCompleted(0)
                .deletedNew(0).deletedInProgress(0).deletedOnHold(0).deletedCancelled(0).deletedCompleted(0)
                .build();

        ReportSearchResult mockResult = new ReportSearchResult();
        mockResult.setTotal(2);
        mockResult.setOperatorReportFlatList(List.of(f1, f2));

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockResult);

        try (MockedStatic<ReportsQueryBuilder> mocked = mockStatic(ReportsQueryBuilder.class)) {

            Criteria criteria = mock(Criteria.class);
            MatchOperation matchOp = mock(MatchOperation.class);
            GroupOperation groupOp = mock(GroupOperation.class);
            SortOperation sortOp = mock(SortOperation.class);
            ProjectionOperation finalProj = mock(ProjectionOperation.class);

            mocked.when(() -> ReportsQueryBuilder.queryBuilderForSourceInformationAndTat(eq(requestDTO), anyList()))
                    .thenReturn(criteria);

            mocked.when(() -> ReportsQueryBuilder.matchOperation(eq(criteria)))
                    .thenReturn(matchOp);

            mocked.when(ReportsQueryBuilder::operatorRoleGroupOperation)
                    .thenReturn(groupOp);

            mocked.when(() -> ReportsQueryBuilder.buildSortOperationForOperator(eq("total"), eq("desc")))
                    .thenReturn(sortOp);

            mocked.when(ReportsQueryBuilder::operatorRoleFinalProjection)
                    .thenReturn(finalProj);

            // Act
            ReportResponseDTO response = sourceInformationService.getSourceInformation(requestDTO);

            // Assert
            assertNotNull(response);
            assertEquals(2, response.getTotalItems());
            assertEquals(1, response.getCurrentPage());
            assertNotNull(response.getResponse());
            assertEquals(2, response.getResponse().size());

            GenericResponseDTO first = response.getResponse().get(0);
            GenericResponseDTO second = response.getResponse().get(1);

            assertEquals("B", first.getOperatorName());
            assertEquals(2, first.getTotal());
            assertEquals("A", second.getOperatorName());
            assertEquals(1, second.getTotal());

            verify(countryRegionMappingUtils).findDistinctCountriesByRegion("APAC");
            verify(customSourceRepository).reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
            verifyNoMoreInteractions(countryRegionMappingUtils);
        }
    }

    @Test
    void getSourceInformation_reviewer_shouldReturnResponse_andManualSortTotal() {
        // Arrange
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setOperatorRole("Reviewer");
        requestDTO.setStartPage(1);
        requestDTO.setBatchSize(10);
        requestDTO.setSort("Total");
        requestDTO.setOrder("desc");
        requestDTO.setRegion("EMEA");

        when(countryRegionMappingUtils.findDistinctCountriesByRegion("EMEA"))
                .thenReturn(List.of("UK"));

        ReviewerReportDTO r1 = ReviewerReportDTO.builder()
                .researcherName("A").newCount(1).inProgress(0).onHold(0).cancelled(0).completed(0).build(); // total 1
        ReviewerReportDTO r2 = ReviewerReportDTO.builder()
                .researcherName("B").newCount(3).inProgress(0).onHold(0).cancelled(0).completed(0).build(); // total 3

        ReportSearchResult mockResult = new ReportSearchResult();
        mockResult.setTotal(2);
        mockResult.setReviewerReportList(new ArrayList<>(List.of(r1, r2)));

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(mockResult);
        try (MockedStatic<ReportsQueryBuilder> mocked = mockStatic(ReportsQueryBuilder.class)) {

            Criteria criteria = mock(Criteria.class);
            MatchOperation matchOp = mock(MatchOperation.class);
            GroupOperation groupOp = mock(GroupOperation.class);
            SortOperation sortOp = mock(SortOperation.class);
            ProjectionOperation finalProj = mock(ProjectionOperation.class);

            mocked.when(() -> ReportsQueryBuilder.queryBuilderForReviewerRole(eq(requestDTO), anyList()))
                    .thenReturn(criteria);

            mocked.when(() -> ReportsQueryBuilder.matchOperation(eq(criteria)))
                    .thenReturn(matchOp);

            mocked.when(ReportsQueryBuilder::reviewerRoleGroupOperation)
                    .thenReturn(groupOp);
            mocked.when(() -> ReportsQueryBuilder.buildSortOperationForReviewer(eq("Total"), eq("desc")))
                    .thenReturn(sortOp);

            mocked.when(ReportsQueryBuilder::reviewerRoleFinalProjection)
                    .thenReturn(finalProj);

            // Act
            ReportResponseDTO response = sourceInformationService.getSourceInformation(requestDTO);

            // Assert
            assertNotNull(response);
            assertEquals(2, response.getTotalItems());
            assertEquals(2, response.getResponse().size());

            assertEquals("B", response.getResponse().get(0).getResearcherName());
            assertEquals(3, response.getResponse().get(0).getTotal());

            assertEquals("A", response.getResponse().get(1).getResearcherName());
            assertEquals(1, response.getResponse().get(1).getTotal());

            verify(countryRegionMappingUtils).findDistinctCountriesByRegion("EMEA");
            verify(customSourceRepository).reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
            mocked.verify(() -> ReportsQueryBuilder.buildSortOperationForReviewer(eq("Total"), eq("desc")));
        }
    }

    @Test
    void getSourceInformation_originatorAndReviewer_shouldMergeActionAndStatus_andPaginate() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setOperatorRole("Originator & Reviewer");
        requestDTO.setStartPage(1);
        requestDTO.setBatchSize(10);
        requestDTO.setSort("researcher_name");
        requestDTO.setOrder("asc");
        requestDTO.setRegion(null);
        ReportSearchResult actionResult = new ReportSearchResult();
        OperatorReviewerReportDTO a1 = OperatorReviewerReportDTO.builder()
                .researcherName("John")
                .hon("HON1")
                .added(2).changed(1).archived(0).deleted(0)
                .build();
        actionResult.setOperatorReviewerReportList(List.of(a1));
        ReportSearchResult statusResult = new ReportSearchResult();
        OperatorReviewerReportDTO s1 = OperatorReviewerReportDTO.builder()
                .researcherName("John")
                .hon("HON1")
                .newCount(1).inProgress(1).onHold(0).cancelled(0).completed(0)
                .build();
        statusResult.setOperatorReviewerReportList(List.of(s1));

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenReturn(actionResult)
                .thenReturn(statusResult);

        ReportResponseDTO response = sourceInformationService.getSourceInformation(requestDTO);

        assertNotNull(response);
        assertEquals(1, response.getResponse().size());

        GenericResponseDTO row = response.getResponse().get(0);
        assertEquals("John", row.getResearcherName());
        assertEquals(2, row.getAdded());
        assertEquals(1, row.getChanged());
        assertEquals(1, row.getNewCount());
        assertEquals(1, row.getInProgress());
        assertEquals(5, row.getTotal());
        verify(customSourceRepository, times(2))
                .reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
        verifyNoInteractions(countryRegionMappingUtils);
    }

    @Test
    void getSourceInformation_shouldPropagateRepositoryException_forOriginator() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setOperatorRole("Originator");
        requestDTO.setStartPage(1);
        requestDTO.setBatchSize(10);

        when(customSourceRepository.reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class)))
                .thenThrow(new RuntimeException("Database error"));

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> sourceInformationService.getSourceInformation(requestDTO));

        assertEquals("Database error", ex.getMessage());
        verify(customSourceRepository).reportCustomAggregate(any(Aggregation.class), anyString(), eq(ReportSearchResult.class));
    }
}