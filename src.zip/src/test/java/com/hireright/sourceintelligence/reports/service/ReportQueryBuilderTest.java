package com.hireright.sourceintelligence.reports.service;

import com.hireright.sourceintelligence.api.dto.DateRange;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.impl.ReportsQueryBuilder;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import java.time.Instant;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ReportsQueryBuilderTest {

    @Test
    void testQueryBuilder_WithValidInputs() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        requestDTO.setOrganizationName("TestOrg");
        requestDTO.setOperatorName("TestOperator");
        requestDTO.setOperatorRole("Admin");
        DateRange dateRange = new DateRange();
        dateRange.setStartDate(Instant.now().minusSeconds(1));
        dateRange.setEndDate(Instant.now().plusSeconds(1));
        requestDTO.setDateRange(dateRange);

        Criteria criteria = ReportsQueryBuilder.queryBuilder(requestDTO);
        assertNotNull(criteria, "Criteria should not be null");
    }

    @Test
    void testQueryBuilder_WithNullInputs() {
        ReportsRequestDTO requestDTO = new ReportsRequestDTO();
        Criteria criteria = ReportsQueryBuilder.queryBuilder(requestDTO);
        assertNotNull(criteria, "Criteria should be initialized");
    }

    @Test
    void testMatchOperation() {
        Criteria criteria = new Criteria("field").is("value");
        MatchOperation matchOperation = ReportsQueryBuilder.matchOperation(criteria);
        assertNotNull(matchOperation, "Match operation should not be null");
    }

    @Test
    void testSkipOperation() {
        SkipOperation skipOperation = ReportsQueryBuilder.skipOperation(2, 10);
        assertNotNull(skipOperation, "Skip operation should not be null");
    }

    @Test
    void testLimitOperation() {
        LimitOperation limitOperation = ReportsQueryBuilder.limitOperation(10);
        assertNotNull(limitOperation, "Limit operation should not be null");
    }

    @Test
    void testCountOperation() {
        CountOperation countOperation = ReportsQueryBuilder.countOperation();
        assertNotNull(countOperation, "Count operation should not be null");
    }

    @Test
    void testFacetOperation() {
        FacetOperation facetOperation = ReportsQueryBuilder.facetOperation(1, 10);
        assertNotNull(facetOperation, "Facet operation should not be null");
    }

    @Test
    void testFinalProjectionWithTotalCountInPipeline() {
        String responseAs = "responseReportList";
        ProjectionOperation projectionOperation =
                ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline(responseAs);

        assertNotNull(projectionOperation, "Projection operation should not be null");
    }

    @Test
    void testContactUtilizationGroupOperation() {
        GroupOperation groupOperation = ReportsQueryBuilder.contactUtilizationGroupOperation();
        assertNotNull(groupOperation, "Group operation should not be null");
    }
    @Test
    void testPrivateConstructor() throws Exception {
        Constructor<ReportsQueryBuilder> constructor = ReportsQueryBuilder.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        InvocationTargetException thrown = assertThrows(InvocationTargetException.class, constructor::newInstance);
        assertTrue(thrown.getCause() instanceof IllegalStateException);
        assertEquals("Utility class", thrown.getCause().getMessage());
    }

    @Test
    void testApprovalTATGroupOperation() {
        GroupOperation groupOperation = ReportsQueryBuilder.approvalTATGroupOperation();
        assertNotNull(groupOperation, "Group operation should not be null");
    }


    @Test
    void testAutoMatchGroupOperation() {
        GroupOperation groupOperation = ReportsQueryBuilder.autoMatchGroupOperation();
        assertNotNull(groupOperation, "Group operation should not be null");
    }
}
