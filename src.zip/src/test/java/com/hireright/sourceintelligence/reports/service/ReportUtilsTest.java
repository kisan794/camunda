package com.hireright.sourceintelligence.reports.service;
import com.hireright.sourceintelligence.reports.dto.MetaDTO;
import com.hireright.sourceintelligence.reports.service.impl.ReportUtils;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class ReportUtilsTest {

    @Test
    void testGetMetaDataByReport_WithValidReportType_CONTACT_UTILIZATION() {
        List<MetaDTO> metaData = ReportUtils.getMetaDataByReport("contact-utilization");
        assertNotNull(metaData, "Meta data list should not be null");
        assertFalse(metaData.isEmpty(), "Meta data list should not be empty");
    }

    @Test
    void testGetMetaDataByReport_WithValidReportType_AUTO_MATCH() {
        List<MetaDTO> metaData = ReportUtils.getMetaDataByReport("auto-match");
        assertNotNull(metaData, "Meta data list should not be null");
        assertFalse(metaData.isEmpty(), "Meta data list should not be empty");
    }

    @Test
    void testGetMetaDataByReport_WithInvalidReportType() {
        List<MetaDTO> metaData = ReportUtils.getMetaDataByReport("INVALID_TYPE");
        assertNotNull(metaData, "Meta data list should not be null");
    }

    @Test
    void testConvertToReadableFormat() throws Exception {
        java.lang.reflect.Method method = ReportUtils.class.getDeclaredMethod("convertToReadableFormat", String.class);
        method.setAccessible(true);
        String result = (String) method.invoke(null, "TEST_STRING");
        assertEquals("TEST STRING", result, "Should convert underscore to space");
    }

    @Test
    void testPrivateConstructor() throws Exception {
        Constructor<ReportUtils> constructor = ReportUtils.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        InvocationTargetException thrown = assertThrows(InvocationTargetException.class, constructor::newInstance);
        assertTrue(thrown.getCause() instanceof IllegalStateException);
        assertEquals("Utility class", thrown.getCause().getMessage());
    }
}
