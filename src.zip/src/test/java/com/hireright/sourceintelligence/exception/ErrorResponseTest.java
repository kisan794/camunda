package com.hireright.sourceintelligence.exception;

import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ErrorResponseTest {

    @Test
    void noArgsCtorAndSettersGetters() {
        ErrorResponse er = new ErrorResponse();
        assertNull(er.getErrors());
        assertFalse(er.isSuccess());

        List<ErrorRecord> list = Collections.emptyList();
        er.setErrors(list);
        er.setSuccess(true);

        assertSame(list, er.getErrors());
        assertTrue(er.isSuccess());
    }

    @Test
    void allArgsConstructor() {
        List<ErrorRecord> list = Collections.emptyList();
        ErrorResponse er = new ErrorResponse(list, false);

        assertEquals(list, er.getErrors());
        assertFalse(er.isSuccess());
    }

    @Test
    void builderBuildsCorrectly() {
        List<ErrorRecord> list = Collections.emptyList();
        ErrorResponse er = ErrorResponse.builder()
                .errors(list)
                .success(true)
                .build();

        assertEquals(list, er.getErrors());
        assertTrue(er.isSuccess());
    }

    @Test
    void equalsAndHashCode() {
        List<ErrorRecord> list = Collections.emptyList();

        ErrorResponse a = ErrorResponse.builder().errors(list).success(true).build();
        ErrorResponse b = ErrorResponse.builder().errors(list).success(true).build();
        ErrorResponse c = ErrorResponse.builder().errors(list).success(false).build();

        assertEquals(a, a);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        assertNotEquals(a, c);
        assertNotEquals(null, a);
        assertNotEquals("not-an-error-response", a);
    }


    @Test
    void equalsWithNullVsEmptyErrors() {
        ErrorResponse withNullErrors = new ErrorResponse(null, true);
        ErrorResponse withEmptyErrors = new ErrorResponse(Collections.emptyList(), true);

        assertNotEquals(withNullErrors, withEmptyErrors);
    }

    @Test
    void toStringContainsFields() {
        ErrorResponse er = ErrorResponse.builder()
                .errors(Collections.emptyList())
                .success(true)
                .build();

        String s = er.toString();
        assertNotNull(s);
        assertTrue(s.contains("ErrorResponse"));
        assertTrue(s.contains("errors"));
        assertTrue(s.contains("success"));
    }

    @Test
    void serializableRoundTrip() throws Exception {
        ErrorResponse original = new ErrorResponse(Collections.emptyList(), true);

        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        try (ObjectOutputStream oos = new ObjectOutputStream(bout)) {
            oos.writeObject(original);
        }

        ErrorResponse restored;
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bout.toByteArray()))) {
            restored = (ErrorResponse) ois.readObject();
        }

        assertEquals(original, restored);
        assertEquals(original.getErrors(), restored.getErrors());
        assertEquals(original.isSuccess(), restored.isSuccess());
    }
}
