package com.hireright.sourceintelligence.exception;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Path;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
class ApiValidationErrorTest {

    @Test
    void coversAllArgsCtor_setters_getters_equals_hashCode_toString() {
        Object rejected = 123;
        ApiValidationError a = new ApiValidationError("Obj", "field", rejected, "msg");
        a.setObject("Obj");
        a.setField("field");
        a.setRejectedValue(rejected);
        a.setMessage("msg");
        assertEquals("Obj", a.getObject());
        assertEquals("field", a.getField());
        assertEquals(rejected, a.getRejectedValue());
        assertEquals("msg", a.getMessage());
        ApiValidationError b = new ApiValidationError("Obj", "field", rejected, "msg");
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
        String ts = a.toString();
        assertNotNull(ts);
        assertTrue(ts.contains("Obj"));
        assertTrue(ts.contains("field"));
        b.setMessage("different");
        assertNotEquals(a, b);
    }

    @Test
    void constructor_withFieldError_setsAllFields() {
        String objectName = "userRequest";
        String field = "email";
        Object rejectedValue = "not-an-email";
        String defaultMessage = "must be a well-formed email address";

        FieldError fieldError = new FieldError(
                objectName,
                field,
                rejectedValue,
                false,
                null,
                null,
                defaultMessage
        );
        ApiValidationError ave = new ApiValidationError(fieldError);
        assertEquals(objectName, ave.getObject());
        assertEquals(field, ave.getField());
        assertEquals(rejectedValue, ave.getRejectedValue());
        assertEquals(defaultMessage, ave.getMessage());
    }

    @Test
    void constructor_withConstraintViolation_setsAllFields() {
        class DummyRoot {}

        @SuppressWarnings("unchecked")
        ConstraintViolation<DummyRoot> cv = (ConstraintViolation<DummyRoot>) mock(ConstraintViolation.class);

        when(cv.getRootBeanClass()).thenReturn(DummyRoot.class);
        Path mockPath = mock(Path.class);
        when(mockPath.toString()).thenReturn("address.zip");
        when(cv.getPropertyPath()).thenReturn(mockPath);

        when(cv.getInvalidValue()).thenReturn("ABCDE");
        when(cv.getMessage()).thenReturn("must match \\d{5}");
        ApiValidationError ave = new ApiValidationError(cv);
        assertEquals("DummyRoot", ave.getObject());
        assertEquals("address.zip", ave.getField());
        assertEquals("ABCDE", ave.getRejectedValue());
        assertEquals("must match \\d{5}", ave.getMessage());
    }


    @Test
    void addValidationError_withGlobalErrors_updatesObjectAndMessage() {
        FieldError initial = new FieldError(
                "orderRequest",
                "quantity",
                -1,
                false,
                null,
                null,
                "must be greater than or equal to 1"
        );
        ApiValidationError ave = new ApiValidationError(initial);
        assertEquals("orderRequest", ave.getObject());
        assertEquals("quantity", ave.getField());
        assertEquals(-1, ave.getRejectedValue());
        assertEquals("must be greater than or equal to 1", ave.getMessage());
        ObjectError global1 = new ObjectError("orderRequest", "order total cannot be negative");
        ObjectError global2 = new ObjectError("paymentDetails", "payment method not supported");

        ave.addValidationError(Arrays.asList(global1, global2));
        assertEquals("paymentDetails", ave.getObject());
        assertEquals("payment method not supported", ave.getMessage());
        assertEquals("quantity", ave.getField());
        assertEquals(-1, ave.getRejectedValue());
    }
}
