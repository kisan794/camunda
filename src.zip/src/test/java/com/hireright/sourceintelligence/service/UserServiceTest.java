package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.exception.ServiceException;
import com.hireright.sourceintelligence.service.impl.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @InjectMocks
    private UserServiceImpl userServiceImpl;
    @Mock
    private CommonUtilService commonUtilService;


    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(userServiceImpl, "uasUsersURL", "http://localhost:8088/test");
    }


    @Test
    void getUserAccountServiceUsers_With_Exception_Test() {

        assertThatExceptionOfType(ServiceException.class).isThrownBy(() -> userServiceImpl.getUserAccountServiceUsers(""));
    }
}
