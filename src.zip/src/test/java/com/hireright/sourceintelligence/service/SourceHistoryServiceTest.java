package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.service.impl.SourceHistoryServiceImpl;
import com.hireright.sourceintelligence.util.TestDataProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class SourceHistoryServiceTest {

    @InjectMocks
    private SourceHistoryServiceImpl sourceOrganizationHistoryService;

    @Mock
    private SourceMapper sourceMapper;

    @Mock
    private SourceService sourceService;

    @Mock
    private CustomSourceRepository<Source> customSourceRepository;

    @BeforeEach
    void setUp() {
    }

    @Test
    void getSourcesByHonAndApprovalStatusAndVersionLessThanOrderByVersionDescTest() {
        List<Source> orgEntity = TestDataProvider.getSourceOrganizationHistoryEntities();

        when(customSourceRepository.findByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc(
                anyString(), any(ApprovalStatus.class), anyDouble(), eq(Source.class), anyString()))
                .thenReturn(orgEntity);

        when(sourceMapper.toSourceDTOList(orgEntity))
                .thenReturn(List.of(new SourceOrganizationDTO()));

        assertThatNoException().isThrownBy(() ->
                sourceOrganizationHistoryService
                        .getSourcesByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc(
                                "OUEMP-083022-VGYQHF5", ApprovalStatus.APPROVED, 1.0));
    }

    @Test
    void getSourcesByHonAndApprovalStatusOrderByVersionDescTest() {
        when(sourceMapper.toSourceDTOList(anyList())).thenReturn(List.of());
        when(customSourceRepository.findByHon(anyString(), eq(Source.class), anyString())).thenReturn(List.of());
        when(customSourceRepository.findByHonAndApprovalStatusOrderByVersionDesc(anyString(), any(), eq(Source.class), anyString()))
                .thenReturn(List.of());

        assertThatNoException().isThrownBy(() ->
                sourceOrganizationHistoryService.getSourcesByHonAndApprovalStatusOrderByVersionDesc(
                        "OUEMP-083022-VGYQHF5", ApprovalStatus.APPROVED));
    }

    @Test
    void getSourcesByHonAndApprovalStatusOrderByVersion_Source_Test() {
        List<Source> orgEntity = TestDataProvider.getSourceOrganizationHistoryEntities();
        when(customSourceRepository.findByHon(anyString(), eq(Source.class), anyString())).thenReturn(orgEntity);
        when(customSourceRepository.findByHonAndApprovalStatusOrderByVersionDesc(anyString(), any(), eq(Source.class), anyString()))
                .thenReturn(List.of());
        when(sourceMapper.toSourceDTOList(anyList())).thenReturn(List.of(new SourceOrganizationDTO()));

        assertThatNoException().isThrownBy(() ->
                sourceOrganizationHistoryService.getSourcesByHonAndApprovalStatusOrderByVersionDesc(
                        "OUEMP-083022-VGYQHF5", ApprovalStatus.APPROVED));
    }

    @Test
    void getSourcesByHonAndApprovalStatusOrderByVersion_Hon_Test() {
        List<Source> orgEntity = TestDataProvider.getSourceOrganizationHistoryEntities();
        when(customSourceRepository.findByHon(anyString(), eq(Source.class), anyString())).thenReturn(orgEntity);
        when(customSourceRepository.findByHonAndApprovalStatusOrderByVersionDesc(anyString(), any(), eq(Source.class), anyString()))
                .thenReturn(orgEntity);
        when(sourceMapper.toSourceDTOList(anyList())).thenReturn(List.of(new SourceOrganizationDTO()));

        assertThatNoException().isThrownBy(() ->
                sourceOrganizationHistoryService.getSourcesByHonAndApprovalStatusOrderByVersionDesc(
                        "OUEMP-083022-VGYQHF5", ApprovalStatus.APPROVED));
    }

    @Test
    void getSourceOrganizationsForDiffTest() {
        Source sourceOrganizationHistory = TestDataProvider.getSourceOrganizationHistoryEntity();
        when(customSourceRepository.findOneByHonAndVersion(anyString(), anyDouble(), eq(Source.class), anyString()))
                .thenReturn(sourceOrganizationHistory);

        when(sourceMapper.entitySourceToDTO(any(Source.class)))
                .thenReturn(new SourceOrganizationDTO());

        assertThatNoException().isThrownBy(() ->
                sourceOrganizationHistoryService.getSourcesForDiff(
                        "OUEMP-083022-VGYQHF5", 1.0, "CURRENT"));
    }

    @Test
    void getSourceOrganizationsForDiffTest_SourceType() {
        List<Source> sourceOrganizationList = TestDataProvider.getSourceOrganizationList();

        when(customSourceRepository.findByHonAndVersionInOrderByVersionDesc(
                anyString(), any(Double[].class), eq(Source.class), anyString()))
                .thenReturn(sourceOrganizationList);

        when(sourceMapper.toSourceDTOList(sourceOrganizationList))
                .thenReturn(List.of(new SourceOrganizationDTO(), new SourceOrganizationDTO()));

        assertThatNoException().isThrownBy(() ->
                sourceOrganizationHistoryService.getSourcesForDiff(
                        "OUEMP-083022-VGYQHF5", 1.0, "PREVIOUS"));
    }

    @Test
    void getSourceOrganizationsForDiffTest_SourceType_Previous() {
        List<Source> approved = List.of(new Source());

        when(customSourceRepository.findByHonAndVersionInOrderByVersionDesc(
                anyString(), any(Double[].class), eq(Source.class), anyString()))
                .thenReturn(approved);

        when(sourceMapper.toSourceDTOList(approved))
                .thenReturn(List.of(new SourceOrganizationDTO()));

        assertThatNoException().isThrownBy(() ->
                sourceOrganizationHistoryService.getSourcesForDiff(
                        "OUEMP-083022-VGYQHF5", 1.0, "PREVIOUS"));
    }


    @Test
    void getSourceOrganizationHistoryByHonAndVersionTest() {
        Source sourceOrganizationHistory = TestDataProvider.getSourceOrganizationHistoryEntity();

        when(customSourceRepository.findOneByHonAndVersion(anyString(), anyDouble(), eq(Source.class), anyString()))
                .thenReturn(sourceOrganizationHistory);

        when(sourceMapper.entitySourceToDTO(any(Source.class)))
                .thenReturn(new SourceOrganizationDTO());

        assertThatNoException().isThrownBy(() ->
                sourceOrganizationHistoryService.getSourceByHonAndVersion("OUEMP-083022-VGYQHF5", 1.0));
    }

    @Test
    void getSourceOrganizationHistoryByHonAndVersionTest_ResourceNotFound() {
        when(customSourceRepository.findOneByHonAndVersion(anyString(), anyDouble(), eq(Source.class), anyString()))
                .thenReturn(null);

        assertThatExceptionOfType(ResourceNotFoundException.class).isThrownBy(() ->
                sourceOrganizationHistoryService.getSourceByHonAndVersion("OUEMP-083022-VGYQHF5", 1.0));
    }

    @Test
    void getSourceHistoryByHonAndVersionVersionTest() {
        when(customSourceRepository.findOneByHonAndVersion(anyString(), anyDouble(), eq(Source.class), anyString()))
                .thenReturn(new Source());

        when(sourceMapper.entitySourceToDTO(any(Source.class)))
                .thenReturn(new SourceOrganizationDTO());

        assertThatNoException().isThrownBy(() ->
                sourceOrganizationHistoryService.getSourceByHonAndVersion("OUEMP-083022-VGYQHF5", 3.0));
    }

    @Test
    void getSourceHistoryByHonAndVersionResourceNotFoundTest() {
        when(customSourceRepository.findOneByHonAndVersion(anyString(), anyDouble(), eq(Source.class), anyString()))
                .thenReturn(null);

        assertThatExceptionOfType(ResourceNotFoundException.class).isThrownBy(() ->
                sourceOrganizationHistoryService.getSourceByHonAndVersion("OUEMP-083022-VGYQHF5", 3.0));
    }
}
