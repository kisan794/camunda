package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.api.dto.CycleResult;
import com.hireright.sourceintelligence.domain.entity.UserCycle;
import com.hireright.sourceintelligence.domain.repository.UserCycleRepository;
import com.hireright.sourceintelligence.service.impl.UserCycleEvaluator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.Method;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

class UserCycleEvaluatorTest {

    @Mock
    UserCycleRepository userCycleRepository;

    @InjectMocks
    UserCycleEvaluator evaluator;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    private UserCycle cycle(int trust, int threshold, int auto, int manual) {
        UserCycle c = new UserCycle();
        c.setTrustScore(trust);
        c.setRegionThreshold(threshold);
        c.setAutoQuota(auto);
        c.setManualQuota(manual);
        c.setCycleSize(10);
        return c;
    }

    @Test
    void manualPath_existingCycle_decrementsManual() {
        UserCycle existing = cycle(50, 40, 5, 2);
        when(userCycleRepository.findByUserIdAndRegion("u1", "US"))
                .thenReturn(Optional.of(existing));

        CycleResult res = evaluator.processRequest("u1", "US", 50, 40);


        assertThat(res.getCycle().getManualQuota()).isEqualTo(1);
        assertThat(res.getCycle().getAutoQuota()).isEqualTo(5);
    }

    @Test
    void autoPath_existingCycle_decrementsAuto() {
        UserCycle existing = cycle(60, 50, 3, 0);
        when(userCycleRepository.findByUserIdAndRegion("u2", "EU"))
                .thenReturn(Optional.of(existing));

        CycleResult res = evaluator.processRequest("u2", "EU", 60, 50);

        // auto path → auto quota drops by 1; manual stays 0
        assertThat(res.getCycle().getAutoQuota()).isEqualTo(2);
        assertThat(res.getCycle().getManualQuota()).isZero();
    }

    @Test
    void resetsWhenScoresChange() {

        UserCycle existing = cycle(40, 30, 0, 0);
        when(userCycleRepository.findByUserIdAndRegion("u3", "APAC"))
                .thenReturn(Optional.of(existing));

        CycleResult res = evaluator.processRequest("u3", "APAC", 70, 60);

        assertThat(res.getCycle().getTrustScore()).isEqualTo(70);
        assertThat(res.getCycle().getRegionThreshold()).isEqualTo(60);
        // after reset, quotas recalculated -> non-negative and sum to cycleSize
        assertThat(res.getCycle().getAutoQuota() + res.getCycle().getManualQuota())
                .isEqualTo(9);
    }

    @Test
    void initializesWhenNotFound() {
        when(userCycleRepository.findByUserIdAndRegion("u4", "CA"))
                .thenReturn(Optional.empty());

        CycleResult res = evaluator.processRequest("u4", "CA", 80, 70);

        assertThat(res.getCycle().getUserId()).isEqualTo("u4");
        assertThat(res.getCycle().getRegion()).isEqualTo("CA");
        assertThat(res.getCycle().getAutoQuota() + res.getCycle().getManualQuota())
                .isEqualTo(9);
    }

    @Test
    void autoScore_zeroTrustAndRegion_resultsInZeroAutoQuota() {
        when(userCycleRepository.findByUserIdAndRegion("u5", "UK"))
                .thenReturn(Optional.empty());

        CycleResult res = evaluator.processRequest("u5", "UK", 0, 0);

        assertThat(res.getCycle().getAutoQuota()).isZero();
        assertThat(res.getCycle().getManualQuota()).isEqualTo(9);
    }

    @Test
    void autoScore_bothHundred_resultsInFullAutoQuota() {
        UserCycle existing = cycle(100, 100, 10, 0);
        when(userCycleRepository.findByUserIdAndRegion("u6", "IN"))
                .thenReturn(Optional.of(existing));

        CycleResult res = evaluator.processRequest("u6", "IN", 100, 100);

        assertThat(res.getCycle().getAutoQuota()).isEqualTo(9);
        assertThat(res.getCycle().getManualQuota()).isZero();
    }

    @Test
    void roundToNearest10_boundsAndRounding() throws Exception {

        Method m = UserCycleEvaluator.class.getDeclaredMethod("roundToNearest10", int.class);
        m.setAccessible(true);

        int negative = (Integer) m.invoke(evaluator, -5);
        int aboveHundred = (Integer) m.invoke(evaluator, 105);
        int roundDown = (Integer) m.invoke(evaluator, 44);
        int roundUp = (Integer) m.invoke(evaluator, 46);
        assertThat(negative).isZero();
        assertThat(aboveHundred).isEqualTo(100);
        assertThat(roundDown).isEqualTo(40);
        assertThat(roundUp).isEqualTo(50);
    }
}
