package com.hireright.sourceintelligence.service;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.FIRSTNAME;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.USERNAME;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.ORGANIZATION_NAME;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.ROLES;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.LASTNAME;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import com.hireright.sourceintelligence.api.dto.HighlightDTO;
import com.hireright.sourceintelligence.api.dto.HitText;
import com.hireright.sourceintelligence.api.dto.KeyMatchDTO;
import com.hireright.sourceintelligence.api.dto.SearchPayload;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hireright.sourceintelligence.domain.entity.FieldValueInfo;
import com.hireright.sourceintelligence.exception.ServiceException;
import com.hireright.sourceintelligence.service.impl.CommonUtilServiceImpl;
import com.hireright.sourceintelligence.service.impl.QueryBuilder;
import com.hireright.sourceintelligence.util.Helper;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DefaultCommonUtilServiceTest {

  @InjectMocks
  private CommonUtilServiceImpl commonUtilService;


  @Mock
  private HttpServletRequest httpServletRequest;

  @Mock
  private Base64 base64;

  @Test
  void convertJsonToPOJOTest() {
    String json = "[\"somestring1\",\"somestring2\"]";
    assertThatNoException()
        .isThrownBy(() -> commonUtilService.convertJsonToPOJO(json, ArrayList.class));
  }

  @Test
  void convertJsonToPOJOTest_ParseFailed() {
    assertThatExceptionOfType(ServiceException.class)
        .isThrownBy(() -> commonUtilService.convertJsonToPOJO("{{Test//", SearchPayload.class));
  }

  @Test
  void getDateAsString_Test() {
    assertThatNoException()
        .isThrownBy(() -> commonUtilService.getDateAsString(new Date(), "MM/dd/YYYY"));
  }

  @Test
  void convertBytesToPOJOTest() {
    String json = "[\"somestring1\",\"somestring2\"]";
    assertThatNoException()
        .isThrownBy(() -> commonUtilService.convertBytesToPOJO(json.getBytes(), ArrayList.class));
  }

  @Test
  void convertBytesToPOJOTest_ParseFailed() {
    String abc = "{{Test//";
    byte[] byteArr = abc.getBytes();
    assertThatExceptionOfType(ServiceException.class)
        .isThrownBy(() -> commonUtilService.convertBytesToPOJO(byteArr, SearchPayload.class));
  }

  @Test
  void getBase64Decoder_Test() {
    String password = "password";
    Base64.getEncoder().encode(password.getBytes(StandardCharsets.UTF_8));
    assertThatNoException()
        .isThrownBy(() -> commonUtilService.base64decoder(password));
  }

  @Test
  void setIfNotNullAndEmpty_Test() {
    List<String> test = new ArrayList<>();
    assertThatNoException()
        .isThrownBy(() -> commonUtilService.setIfNotNullAndEmpty("test", test::add));
  }

  @Test
  void getUserInfoTest() {
    HttpServletRequest request = mock(HttpServletRequest.class);

    // Only mock the actually used headers
    when(request.getHeader(USERNAME)).thenReturn("username");

    assertThatNoException().isThrownBy(() -> commonUtilService.getUserInfo(request));
  }


  @Test
  void isResearchAnalystTest() {
    List<String> roles = new ArrayList<>();
    roles.add("[\"ResearchAnalyst\"]");
    assertThatNoException().isThrownBy(() -> commonUtilService.isResearchAnalyst(roles));
  }

  @Test
  void  getTopFiveCategorySearchesTest(){
    Map<String,List<KeyMatchDTO>> mapOfCategorySearch = new HashMap<>();
    KeyMatchDTO keyMatchDTO = new KeyMatchDTO();
    keyMatchDTO.setKey(ORGANIZATION_NAME);
    keyMatchDTO.setScore(Float.parseFloat("2.0"));
    KeyMatchDTO keyMatchDTO_One = new KeyMatchDTO();
    keyMatchDTO_One.setKey(ORGANIZATION_NAME);
    keyMatchDTO_One.setScore(Float.parseFloat("2.0"));
    mapOfCategorySearch.put(ORGANIZATION_NAME,Arrays.asList(keyMatchDTO,keyMatchDTO_One));
    assertThatNoException().isThrownBy(() -> commonUtilService.getTopFiveCategorySearches(mapOfCategorySearch));
  }

  @Test
  void  categorizeMatchedValuesFromHighlightedObjectTest_whenCategorySearchMapIsEmpty(){
    HighlightDTO highlightDTO = new HighlightDTO();
    highlightDTO.setScore(Float.parseFloat("2.0"));
    highlightDTO.setPath(ORGANIZATION_NAME);
    highlightDTO.setTexts(Arrays.asList(new HitText(ORGANIZATION_NAME,"Pedro")));
    assertThatNoException().isThrownBy(() -> commonUtilService.categorizeMatchedValuesFromHighlightedObject(ORGANIZATION_NAME,new FieldValueInfo("pedro",true,"","","","",""),new HashMap<>(),highlightDTO));
  }

  @Test
  void  categorizeMatchedValuesFromHighlightedObjectTest(){
    HighlightDTO highlightDTO = new HighlightDTO();
    highlightDTO.setScore(Float.parseFloat("2.0"));
    highlightDTO.setPath(ORGANIZATION_NAME);
    highlightDTO.setTexts(Arrays.asList(new HitText(ORGANIZATION_NAME,"Pedro")));
    Map<String,List<KeyMatchDTO>> mapOfCategorySearch = new HashMap<>();
    KeyMatchDTO keyMatchDTO = new KeyMatchDTO();
    keyMatchDTO.setKey(ORGANIZATION_NAME);
    keyMatchDTO.setScore(Float.parseFloat("2.0"));
    KeyMatchDTO keyMatchDTO_One = new KeyMatchDTO();
    keyMatchDTO_One.setKey(ORGANIZATION_NAME);
    keyMatchDTO_One.setScore(Float.parseFloat("2.0"));
    List<KeyMatchDTO> keyMatchDTOS = new ArrayList<>();
    keyMatchDTOS.add(keyMatchDTO_One);
    keyMatchDTOS.add(keyMatchDTO);
    mapOfCategorySearch.put(ORGANIZATION_NAME,keyMatchDTOS);
    assertThatNoException().isThrownBy(() -> commonUtilService.categorizeMatchedValuesFromHighlightedObject(ORGANIZATION_NAME,new FieldValueInfo("pedro",true,"","","","",""),mapOfCategorySearch,highlightDTO));
  }

  @Test
  void getTotalPagesTest(){
    assertThatNoException().isThrownBy(() -> QueryBuilder.getTotalPages(2,2));
  }

  @Test
  void facetOperationTest(){
    assertThatNoException().isThrownBy(() -> QueryBuilder.facetOperation(1,2));
  }

  @Test
  void finalProjectionWithTotalCountInPipelineTest(){
    assertThatNoException().isThrownBy(() -> QueryBuilder.finalProjectionWithTotalCountInPipeline());
  }
}
