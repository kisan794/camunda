package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.AutocompleteSearchDTO;
import com.hireright.sourceintelligence.api.dto.HighlightDTO;
import com.hireright.sourceintelligence.api.dto.KeyMatchDTO;
import com.hireright.sourceintelligence.api.dto.UserInfo;
import com.hireright.sourceintelligence.domain.entity.FieldValueInfo;
import com.hireright.sourceintelligence.domain.enums.UserRoles;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.USERNAME;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class CommonUtilServiceImplTest {

    private CommonUtilServiceImpl commonUtilService;

    @BeforeEach
    void setUp() {
        commonUtilService = new CommonUtilServiceImpl();
    }

    @Test
    void convertJsonToPOJO_shouldConvertSuccessfully() {
        TestPojo result = commonUtilService.convertJsonToPOJO(
                "{\"name\":\"Lazy\",\"age\":10}",
                TestPojo.class
        );

        assertNotNull(result);
        assertEquals("Lazy", result.getName());
        assertEquals(10, result.getAge());
    }

    @Test
    void convertJsonToPOJO_shouldThrowExceptionForInvalidJson() {
        assertThrows(Exception.class,
                () -> commonUtilService.convertJsonToPOJO("{invalid-json}", TestPojo.class));
    }

    @Test
    void convertBytesToPOJO_shouldConvertSuccessfully() {
        byte[] source = "{\"name\":\"Farmer\",\"age\":20}".getBytes(StandardCharsets.UTF_8);

        TestPojo result = commonUtilService.convertBytesToPOJO(source, TestPojo.class);

        assertNotNull(result);
        assertEquals("Farmer", result.getName());
        assertEquals(20, result.getAge());
    }

    @Test
    void convertBytesToPOJO_shouldThrowExceptionForInvalidBytes() {
        byte[] invalidBytes = "not-a-valid-json".getBytes(StandardCharsets.UTF_8);

        assertThrows(Exception.class,
                () -> commonUtilService.convertBytesToPOJO(invalidBytes, TestPojo.class));
    }

    @Test
    void getDateAsString_shouldFormatDate() throws Exception {
        Date date = new SimpleDateFormat("yyyy-MM-dd").parse("2026-03-16");

        String result = commonUtilService.getDateAsString(date, "dd/MM/yyyy");

        assertEquals("16/03/2026", result);
    }

    @Test
    void base64decoder_shouldDecodeString() {
        String encoded = Base64.getEncoder().encodeToString("test-user".getBytes(StandardCharsets.UTF_8));

        String result = commonUtilService.base64decoder(encoded);

        assertEquals("test-user", result);
    }

    @Test
    void getUserInfo_shouldReturnDecodedUsername() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        String encodedUsername = Base64.getEncoder().encodeToString("john.doe".getBytes(StandardCharsets.UTF_8));

        when(request.getHeader(USERNAME)).thenReturn(encodedUsername);

        UserInfo userInfo = commonUtilService.getUserInfo(request);

        assertNotNull(userInfo);
        assertEquals("john.doe", userInfo.getUsername());
        assertEquals("john.doe", userInfo.getPrimaryUserName());
    }

    @Test
    void isResearchAnalyst_shouldReturnTrueWhenOnlyResearchAnalystRolePresent() {
        List<String> roles = List.of(UserRoles.RESEARCH_ANALYST.getRole());

        boolean result = commonUtilService.isResearchAnalyst(roles);

        assertTrue(result);
    }

    @Test
    void isResearchAnalyst_shouldReturnFalseWhenRolesAreEmpty() {
        assertFalse(commonUtilService.isResearchAnalyst(Collections.emptyList()));
    }

    @Test
    void isResearchAnalyst_shouldReturnFalseWhenMultipleRolesPresent() {
        List<String> roles = List.of(
                UserRoles.RESEARCH_ANALYST.getRole(),
                UserRoles.MANAGER.getRole()
        );

        boolean result = commonUtilService.isResearchAnalyst(roles);

        assertFalse(result);
    }

    @Test
    void setIfNotNullAndEmpty_shouldSetValueWhenValueIsNotEmpty() {
        AtomicReference<String> holder = new AtomicReference<>();

        commonUtilService.setIfNotNullAndEmpty("hello", holder::set);

        assertEquals("hello", holder.get());
    }

    @Test
    void setIfNotNullAndEmpty_shouldNotSetValueWhenValueIsNull() {
        AtomicReference<String> holder = new AtomicReference<>("initial");

        commonUtilService.setIfNotNullAndEmpty(null, holder::set);

        assertEquals("initial", holder.get());
    }

    @Test
    void setIfNotNullAndEmpty_shouldNotSetValueWhenValueIsEmptyString() {
        AtomicReference<String> holder = new AtomicReference<>("initial");

        commonUtilService.setIfNotNullAndEmpty("", holder::set);

        assertEquals("initial", holder.get());
    }

    @Test
    void getTopFiveCategorySearches_shouldReturnCategorySearches() {
        Map<String, List<KeyMatchDTO>> input = new LinkedHashMap<>();

        List<KeyMatchDTO> universityMatches = new ArrayList<>();
        universityMatches.add(buildKeyMatch("ABC University", false, "false", "India", "KA", "Bengaluru", "HON1", 1.2F));
        universityMatches.add(buildKeyMatch("XYZ University", true, "true", "USA", "CA", "LA", "HON2", 2.3F));

        List<KeyMatchDTO> employerMatches = new ArrayList<>();
        employerMatches.add(buildKeyMatch("Acme Corp", false, "false", "India", "MH", "Mumbai", "HON3", 3.4F));

        input.put("UNIVERSITY", universityMatches);
        input.put("EMPLOYER", employerMatches);

        List<AutocompleteSearchDTO> result = commonUtilService.getTopFiveCategorySearches(input);

        assertNotNull(result);
        assertEquals(2, result.size());

        AutocompleteSearchDTO first = result.get(0);
        assertEquals("UNIVERSITY", first.getCategory());
        assertEquals(2, first.getMatches().size());
        assertEquals("ABC University", first.getMatches().get(0).getValue());
        assertEquals("HON1", first.getMatches().get(0).getHon());

        AutocompleteSearchDTO second = result.get(1);
        assertEquals("EMPLOYER", second.getCategory());
        assertEquals(1, second.getMatches().size());
        assertEquals("Acme Corp", second.getMatches().get(0).getValue());
    }

    @Test
    void categorizeMatchedValuesFromHighlightedObject_shouldAddToExistingCategory() {
        Map<String, List<KeyMatchDTO>> map = new HashMap<>();
        map.put("ORG", new ArrayList<>(List.of(
                buildKeyMatch("Existing", false, "false", "India", "KA", "Bengaluru", "HON0", 0.5F)
        )));

        FieldValueInfo info = buildFieldValueInfo("New Value", false, "false", "India", "KA", "Bengaluru", "HON1");
        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setScore(9.9F);

        Map<String, List<KeyMatchDTO>> result =
                commonUtilService.categorizeMatchedValuesFromHighlightedObject("ORG", info, map, highlightDTO);

        assertEquals(2, result.get("ORG").size());

        KeyMatchDTO added = result.get("ORG").get(1);
        assertEquals("New Value", added.getKey());
        assertEquals("HON1", added.getHon());
        assertEquals(9.9F, added.getScore());
    }

    @Test
    void categorizeMatchedValuesFromHighlightedObject_shouldCreateNewCategory() {
        Map<String, List<KeyMatchDTO>> map = new HashMap<>();

        FieldValueInfo info = buildFieldValueInfo("Fresh Value", true, "true", "USA", "TX", "Dallas", "HON9");
        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setScore(7.7F);

        Map<String, List<KeyMatchDTO>> result =
                commonUtilService.categorizeMatchedValuesFromHighlightedObject("NEW_CAT", info, map, highlightDTO);

        assertTrue(result.containsKey("NEW_CAT"));
        assertEquals(1, result.get("NEW_CAT").size());

        KeyMatchDTO added = result.get("NEW_CAT").get(0);
        assertEquals("Fresh Value", added.getKey());
        assertEquals("HON9", added.getHon());
        assertEquals(7.7F, added.getScore());
    }

    @Test
    void categorizeMatchedValues_shouldAddToExistingCategory() {
        Map<String, List<KeyMatchDTO>> map = new HashMap<>();
        map.put("CATEGORY", new ArrayList<>(List.of(
                buildKeyMatch("Existing", false, "false", "India", "KA", "Bengaluru", "HON0", 0F)
        )));

        FieldValueInfo info = buildFieldValueInfo("Added Value", false, "true", "India", "TN", "Chennai", "HON5");

        Map<String, List<KeyMatchDTO>> result =
                commonUtilService.categorizeMatchedValues("CATEGORY", info, map);

        assertEquals(2, result.get("CATEGORY").size());

        KeyMatchDTO added = result.get("CATEGORY").get(1);
        assertEquals("Added Value", added.getKey());
        assertEquals("HON5", added.getHon());
        assertEquals(0F, added.getScore());
    }

    @Test
    void categorizeMatchedValues_shouldCreateNewCategory() {
        Map<String, List<KeyMatchDTO>> map = new HashMap<>();

        FieldValueInfo info = buildFieldValueInfo("Only Value", true, "false", "UK", "LN", "London", "HON7");

        Map<String, List<KeyMatchDTO>> result =
                commonUtilService.categorizeMatchedValues("BRAND_NEW", info, map);

        assertTrue(result.containsKey("BRAND_NEW"));
        assertEquals(1, result.get("BRAND_NEW").size());

        KeyMatchDTO added = result.get("BRAND_NEW").get(0);
        assertEquals("Only Value", added.getKey());
        assertEquals("HON7", added.getHon());
        assertEquals(0F, added.getScore());
    }

    @Test
    void isQualityAnalystOnly_shouldReturnTrueForQualityAnalystWithoutSupervisorAndManager() {
        List<String> roles = List.of(UserRoles.QUALITY_ANALYST.getRole());

        boolean result = commonUtilService.isQualityAnalystOnly(roles);

        assertTrue(result);
    }

    @Test
    void isQualityAnalystOnly_shouldReturnFalseWhenRolesAreEmpty() {
        assertFalse(commonUtilService.isQualityAnalystOnly(Collections.emptyList()));
    }

    @Test
    void isQualityAnalystOnly_shouldReturnFalseWhenSupervisorAlsoPresent() {
        List<String> roles = List.of(
                UserRoles.QUALITY_ANALYST.getRole(),
                UserRoles.SUPERVISOR.getRole()
        );

        boolean result = commonUtilService.isQualityAnalystOnly(roles);

        assertFalse(result);
    }

    @Test
    void isQualityAnalystOnly_shouldReturnFalseWhenManagerAlsoPresent() {
        List<String> roles = List.of(
                UserRoles.QUALITY_ANALYST.getRole(),
                UserRoles.MANAGER.getRole()
        );

        boolean result = commonUtilService.isQualityAnalystOnly(roles);

        assertFalse(result);
    }

    private FieldValueInfo buildFieldValueInfo(String value,
                                               Boolean outOfBusiness,
                                               String doNotContact,
                                               String country,
                                               String state,
                                               String city,
                                               String hon) {
        FieldValueInfo info = new FieldValueInfo();
        info.setValue(value);
        info.setOutOfBusiness(outOfBusiness);
        info.setDoNotContact(doNotContact);
        info.setCountry(country);
        info.setState(state);
        info.setCity(city);
        info.setHon(hon);
        return info;
    }

    private KeyMatchDTO buildKeyMatch(String key,
                                      Boolean outOfBusiness,
                                      String doNotContact,
                                      String country,
                                      String state,
                                      String city,
                                      String hon,
                                      Float score) {
        KeyMatchDTO dto = new KeyMatchDTO();
        dto.setKey(key);
        dto.setOutOfBusiness(outOfBusiness);
        dto.setDoNotContact(doNotContact);
        dto.setCountry(country);
        dto.setState(state);
        dto.setCity(city);
        dto.setHon(hon);
        dto.setScore(score);
        return dto;
    }

    public static class TestPojo {
        private String name;
        private int age;

        public TestPojo() {
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }
    }
}