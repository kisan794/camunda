package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchSourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.AutoMatchMapper;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.impl.AutoMatchQueryBuilder;
import com.hireright.sourceintelligence.service.impl.DistanceAlgorithm;
import com.hireright.sourceintelligence.service.impl.USRegionAutoMatchServiceImpl;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import com.hireright.sourceintelligence.util.Helper;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.query.Criteria;

import java.util.*;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.NO_AUTO_MATCH_ES;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.NO_AUTO_MATCH_JARO;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.NO_AUTO_MATCH_MS;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.INTERNAL_SERVER_ERROR;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.JaroFields.ORG_ALIAS;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.JaroFields.ORG_NAME;
import static com.hireright.sourceintelligence.util.TestDataProvider.testData;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class USRegionAutoMatchServiceImplTest {

    @Mock private ElasticsearchService elasticsearchService;
    @Mock private CustomSourceRepository<Source> customSourceRepository;
    @Mock private SourceMapper sourceMapper;
    @Mock private AutoMatchMapper autoMatchMapper;
    @Mock private DistanceAlgorithm distanceAlgorithm;
    @Mock private ReportDataUtils reportDataUtils;

    @InjectMocks
    private USRegionAutoMatchServiceImpl autoMatchService;

    private AutoMatchDTO testInput;
    private static MockedStatic<Helper> helperStatic;

    @BeforeAll
    static void openHelperStatic() {
        helperStatic = mockStatic(Helper.class);
        helperStatic.when(() -> Helper.getIndexName(any())).thenReturn("idx");
        helperStatic.when(() -> Helper.getCollectionName(any(), any())).thenReturn("coll");
        helperStatic.when(() -> Helper.convertToTitleCase(anyString()))
                .thenAnswer(inv -> inv.getArgument(0, String.class));
    }

    @AfterAll
    static void closeHelperStatic() {
        helperStatic.close();
    }

    @BeforeEach
    void setUp() {
        testInput = testData();
    }

    @AfterEach
    void resetHelperStatic() {
        helperStatic.reset();
        helperStatic.when(() -> Helper.getIndexName(any())).thenReturn("idx");
        helperStatic.when(() -> Helper.getCollectionName(any(), any())).thenReturn("coll");
        helperStatic.when(() -> Helper.convertToTitleCase(anyString()))
                .thenAnswer(inv -> inv.getArgument(0, String.class));
    }

    @Test
    void testAutoMatch_noElasticSearchResults() {
        when(elasticsearchService.autoMatchSearch(any(), any()))
                .thenReturn(Collections.emptyList());

        AutoMatchResponseDTO response = autoMatchService.autoMatch(testInput);

        assertEquals(NO_AUTO_MATCH_ES, response.getError());
    }

    @Test
    void testAutoMatch_nullJaroResult() {
        when(elasticsearchService.autoMatchSearch(any(), any()))
                .thenReturn(List.of(new ElasticsearchSource()));
        when(distanceAlgorithm.jaroWinklerAlgorithm(any(), any())).thenReturn(null);

        AutoMatchResponseDTO response = autoMatchService.autoMatch(testInput);

        assertEquals(NO_AUTO_MATCH_JARO, response.getError());
    }

    @Test
    void testAutoMatch_noOrgNameOrAlias() {
        when(elasticsearchService.autoMatchSearch(any(), any()))
                .thenReturn(List.of(new ElasticsearchSource()));
        when(distanceAlgorithm.jaroWinklerAlgorithm(any(), any()))
                .thenReturn(Collections.emptyMap());

        AutoMatchResponseDTO response = autoMatchService.autoMatch(testInput);

        assertEquals(NO_AUTO_MATCH_JARO, response.getError());
    }

    @Test
    void testAutoMatch_internalServerError() {
        when(elasticsearchService.autoMatchSearch(any(), any()))
                .thenThrow(new RuntimeException("Unexpected"));

        AutoMatchResponseDTO response = autoMatchService.autoMatch(testInput);

        assertEquals(INTERNAL_SERVER_ERROR, response.getServerError());
    }

    @MockitoSettings(strictness = Strictness.LENIENT)
    @Test
    void testAutoMatch_success_withOrgNameAndAlias() {
        Map<String, String> jw = Map.of(ORG_NAME, "Acme University", ORG_ALIAS, "Acme U");
        when(elasticsearchService.autoMatchSearch(any(), any()))
                .thenReturn(List.of(new ElasticsearchSource()));
        when(distanceAlgorithm.jaroWinklerAlgorithm(any(), any()))
                .thenReturn(jw);
        try (MockedStatic<AutoMatchQueryBuilder> qb = mockStatic(AutoMatchQueryBuilder.class)) {
            qb.when(() -> AutoMatchQueryBuilder.autoMatchUSRegion(any(), anyString()))
                    .thenReturn(Aggregation.newAggregation(
                            Aggregation.match(Criteria.where("_id").exists(true))
                    ));
            Source src = mock(Source.class);
            when(src.getHon()).thenReturn("HON-ORG-ALIAS");
            when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                    .thenReturn(List.of(src));

            AutoMatchSourceDTO dto = new AutoMatchSourceDTO();
            dto.setHon("HON-ORG-ALIAS");
            when(autoMatchMapper.toAutoMatchDTO(any())).thenReturn(dto);

            // Act
            AutoMatchResponseDTO response = autoMatchService.autoMatch(testInput);
            assertNotNull(response.getSource(), "Auto-matched source should not be null");
            assertNull(response.getError(), "Error should be null for successful match");
            assertEquals("HON-ORG-ALIAS", response.getSource().getHon(), "HON code should match the mocked source");
        }
    }


    @MockitoSettings(strictness = Strictness.LENIENT)
    @Test
    void testAutoMatch_success_withOnlyOrgName() {
        Map<String, String> jw = Map.of(ORG_NAME, "Globex Corp");

        when(elasticsearchService.autoMatchSearch(any(), any()))
                .thenReturn(List.of(new ElasticsearchSource()));

        when(distanceAlgorithm.jaroWinklerAlgorithm(any(), any()))
                .thenReturn(jw);

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("_id").exists(true))
        );

        try (MockedStatic<AutoMatchQueryBuilder> qb = mockStatic(AutoMatchQueryBuilder.class)) {
            qb.when(() -> AutoMatchQueryBuilder.autoMatchUSRegion(any(AutoMatchDTO.class), anyString()))
                    .thenReturn(aggregation);

            Source src = mock(Source.class);
            when(src.getHon()).thenReturn("HON-1");

            when(customSourceRepository.aggregate(any(Aggregation.class), anyString(), eq(Source.class)))
                    .thenReturn(List.of(src));

            AutoMatchSourceDTO dto = new AutoMatchSourceDTO();
            dto.setHon("HON-1");
            when(autoMatchMapper.toAutoMatchDTO(any(Source.class))).thenReturn(dto);

            AutoMatchResponseDTO response = autoMatchService.autoMatch(testInput);

            assertNotNull(response);
            assertNotNull(response.getSource(), "Auto-matched source should not be null");
            assertNull(response.getError(), "Error should be null for successful match");
            assertEquals("HON-1", response.getSource().getHon(), "HON code should match the mocked source");
        }
    }


    @MockitoSettings(strictness = Strictness.LENIENT)
    @Test
    void testAutoMatch_success_withOnlyOrgAlias() {
        Map<String, String> jw = Map.of(ORG_ALIAS, "Initech");

        when(elasticsearchService.autoMatchSearch(any(), any()))
                .thenReturn(List.of(new ElasticsearchSource()));

        when(distanceAlgorithm.jaroWinklerAlgorithm(any(), any()))
                .thenReturn(jw);

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("_id").exists(true))
        );

        try (MockedStatic<AutoMatchQueryBuilder> qb = mockStatic(AutoMatchQueryBuilder.class)) {
            qb.when(() -> AutoMatchQueryBuilder.autoMatchUSRegion(any(AutoMatchDTO.class), anyString()))
                    .thenReturn(aggregation);

            Source src = mock(Source.class);
            when(src.getHon()).thenReturn("HON-ALIAS");

            when(customSourceRepository.aggregate(any(Aggregation.class), anyString(), eq(Source.class)))
                    .thenReturn(List.of(src));

            AutoMatchSourceDTO dto = new AutoMatchSourceDTO();
            dto.setHon("HON-ALIAS");
            when(autoMatchMapper.toAutoMatchDTO(any(Source.class))).thenReturn(dto);

            AutoMatchResponseDTO response = autoMatchService.autoMatch(testInput);

            assertNotNull(response);
            assertNotNull(response.getSource(), "Auto-matched source should not be null");
            assertNull(response.getError(), "Error should be null for successful match");
            assertEquals("HON-ALIAS", response.getSource().getHon(), "HON code should match the mocked source");
        }
    }


    @Test
    void testAutoMatch_mongoReturnsEmptyResults() {
        when(elasticsearchService.autoMatchSearch(any(), any()))
                .thenReturn(List.of(new ElasticsearchSource()));

        when(distanceAlgorithm.jaroWinklerAlgorithm(any(), any()))
                .thenReturn(Map.of(ORG_NAME, "Acme"));

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("_id").exists(true))
        );

        try (MockedStatic<AutoMatchQueryBuilder> qb = mockStatic(AutoMatchQueryBuilder.class)) {
            qb.when(() -> AutoMatchQueryBuilder.autoMatchUSRegion(any(AutoMatchDTO.class), anyString()))
                    .thenReturn(aggregation);

            when(customSourceRepository.aggregate(any(Aggregation.class), anyString(), eq(Source.class)))
                    .thenReturn(Collections.emptyList());

            AutoMatchResponseDTO response = autoMatchService.autoMatch(testInput);

            assertNotNull(response);
            assertEquals(NO_AUTO_MATCH_MS, response.getError());
        }
    }

    @MockitoSettings(strictness = Strictness.LENIENT)
    @Test
    void testAutoMatch_educationCityIsTitleCased() {
        testInput.setSourceType(OrganizationType.EDUCATION.getType());
        testInput.setCity("new york");

        helperStatic.when(() -> Helper.convertToTitleCase("new york"))
                .thenReturn("New York");
        helperStatic.when(() -> Helper.getCollectionName(anyString(), anyString()))
                .thenReturn("test_collection");

        lenient().when(elasticsearchService.autoMatchSearch(any(), any()))
                .thenReturn(List.of(new ElasticsearchSource()));

        lenient().when(distanceAlgorithm.jaroWinklerAlgorithm(any(), any()))
                .thenReturn(Map.of(ORG_NAME, "NYU"));

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("_id").exists(true))
        );

        try (MockedStatic<AutoMatchQueryBuilder> qb = mockStatic(AutoMatchQueryBuilder.class)) {
            qb.when(() -> AutoMatchQueryBuilder.autoMatchUSRegion(any(AutoMatchDTO.class), anyString()))
                    .thenReturn(aggregation);

            Source src = mock(Source.class);
            when(src.getHon()).thenReturn("HON-EDU");

            lenient().when(customSourceRepository.aggregate(any(Aggregation.class), anyString(), eq(Source.class)))
                    .thenReturn(List.of(src));

            AutoMatchSourceDTO dto = new AutoMatchSourceDTO();
            dto.setHon("HON-EDU");
            lenient().when(autoMatchMapper.toAutoMatchDTO(any(Source.class))).thenReturn(dto);

            AutoMatchResponseDTO response = autoMatchService.autoMatch(testInput);

            assertNotNull(response);
            assertNotNull(response.getSource(), "Auto-matched source should not be null");
            assertEquals("HON-EDU", response.getSource().getHon());
            assertEquals("New York", testInput.getCity(), "City should be title-cased");
        }
    }



    @Test
    void testGetters_shouldReturnInjectedDependencies() {
        assertEquals(elasticsearchService, autoMatchService.getElasticsearchService());
        assertEquals(customSourceRepository, autoMatchService.getCustomSourceRepository());
        assertEquals(sourceMapper, autoMatchService.getSourceMapper());
        assertEquals(autoMatchMapper, autoMatchService.getAutoMatchMapper());
        assertEquals(distanceAlgorithm, autoMatchService.getDistanceAlgorithm());
        assertEquals(reportDataUtils, autoMatchService.getReportDataUtils());
    }

    /**
     * Common happy-path stubs (ES hit, Jaro result, one Mongo result, mapping),
     * then executes the given successPath which provides the Aggregation builder stub.
     */
    private void runHappyPath(Map<String, String> jaroResult, Runnable successPath) {
        when(elasticsearchService.autoMatchSearch(any(), any()))
                .thenReturn(List.of(new ElasticsearchSource()));
        when(distanceAlgorithm.jaroWinklerAlgorithm(any(), any()))
                .thenReturn(jaroResult);

        Source src = mock(Source.class);
        when(src.getHon()).thenReturn("HON-1");
        when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                .thenReturn(List.of(src));

        AutoMatchSourceDTO dto = new AutoMatchSourceDTO();
        dto.setHon("HON-1");
        when(autoMatchMapper.toAutoMatchDTO(any())).thenReturn(dto);

        successPath.run();
    }
}
