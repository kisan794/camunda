package com.hireright.sourceintelligence.service;
import com.hireright.sourceintelligence.api.dto.AddressDTO;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.service.impl.AddressServiceImpl;
import com.hireright.sourceintelligence.util.TestDataProvider;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DefaultAddressServiceTest {


    @InjectMocks
    private AddressServiceImpl addressService;


    @Mock
    private SourceService sourceService;

    @Mock
    private SourceMapper sourceMapper;

    @Test
    void updateAddressTest() {
        AddressDTO addressDTO = TestDataProvider.getAddressDTO();
        SourceOrganizationDTO orgEntity = TestDataProvider.getSourceOrganizationDTO();
        //orgEntity.setId(TestDataProvider.getDummyObjectId());
        when(sourceService.getSourceByHon(anyString())).thenReturn(orgEntity);
        assertThatNoException().isThrownBy(() -> addressService.updateAddress(addressDTO, TestDataProvider.getUserInfo()));
    }

    @Test
    void updateAddressTest_ShouldThrowServiceExceptionOne() {
        AddressDTO addressDTO = TestDataProvider.getAddressDTO();
        addressDTO.setHon(null);
        final var userInfo = TestDataProvider.getUserInfo();

        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> addressService.updateAddress(addressDTO, userInfo));

    }

    @Test
    void updateAddressTest_ShouldThrowServiceExceptionTwo() {
        AddressDTO addressDTO = TestDataProvider.getAddressDTO();
        SourceOrganizationDTO orgEntity = TestDataProvider.getSourceOrganizationDTO();
        orgEntity.setStatus(SourceOrganizationStatus.INACTIVE);
        when(sourceService.getSourceByHon(anyString())).thenReturn(orgEntity);

        final var userInfo = TestDataProvider.getUserInfo();

        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> addressService.updateAddress(addressDTO, userInfo));

    }
}