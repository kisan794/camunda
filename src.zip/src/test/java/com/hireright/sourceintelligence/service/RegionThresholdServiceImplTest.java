package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.v2.dto.RegionThresholdDTO;
import com.hireright.sourceintelligence.domain.entity.RegionThreshold;
import com.hireright.sourceintelligence.domain.repository.RegionThresholdRepository;
import com.hireright.sourceintelligence.service.impl.RegionThresholdServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.APROVAL_REGION_THRESHOLD;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RegionThresholdServiceImplTest {

    private RegionThresholdRepository regionThresholdRepository;
    private RegionThresholdServiceImpl regionThresholdService;

    @BeforeEach
    void setUp() {
        regionThresholdRepository = mock(RegionThresholdRepository.class);
        regionThresholdService = new RegionThresholdServiceImpl(regionThresholdRepository);
    }

    private RegionThreshold createMockRegionThreshold() {
        RegionThreshold threshold = new RegionThreshold();
        threshold.setEMEA(10);
        threshold.setLATAM(20);
        threshold.setCANADA(30);
        threshold.setAPAC(40);
        threshold.setAUSTRALIA(50);
        threshold.setINDIA(60);
        threshold.setUS(70);
        return threshold;
    }

    @Test
    void testGetRegions_ReturnsThresholdDTO() {
        RegionThreshold mockThreshold = createMockRegionThreshold();

        when(regionThresholdRepository.findByThresholdType(APROVAL_REGION_THRESHOLD))
                .thenReturn(mockThreshold);

        RegionThresholdDTO result = regionThresholdService.getRegions();

        assertNotNull(result);
        assertEquals(10, result.getEMEA());
        assertEquals(20, result.getLATAM());
        assertEquals(30, result.getCANADA());
        assertEquals(40, result.getAPAC());
        assertEquals(50, result.getAUSTRALIA());
        assertEquals(60, result.getINDIA());
        assertEquals(70, result.getUS());

        verify(regionThresholdRepository).findByThresholdType(APROVAL_REGION_THRESHOLD);
    }

    @Test
    void testGetRegions_WhenThresholdNotFound_ThrowsException() {
        when(regionThresholdRepository.findByThresholdType(APROVAL_REGION_THRESHOLD))
                .thenReturn(null);

        assertThrows(RuntimeException.class, () -> regionThresholdService.getRegions());

        verify(regionThresholdRepository).findByThresholdType(APROVAL_REGION_THRESHOLD);
        verifyNoMoreInteractions(regionThresholdRepository);
    }

    @Test
    void testGetRegionByType_ReturnsDTO() {
        RegionThreshold mockThreshold = createMockRegionThreshold();

        when(regionThresholdRepository.findByThresholdType("custom"))
                .thenReturn(mockThreshold);

        RegionThresholdDTO result = regionThresholdService.getRegionByType("custom");

        assertNotNull(result);
        assertEquals(10, result.getEMEA());
        assertEquals(20, result.getLATAM());
        assertEquals(30, result.getCANADA());
        assertEquals(40, result.getAPAC());
        assertEquals(50, result.getAUSTRALIA());
        assertEquals(60, result.getINDIA());
        assertEquals(70, result.getUS());

        verify(regionThresholdRepository).findByThresholdType("custom");
    }

    @Test
    void testGetRegionByType_WhenThresholdNotFound_ThrowsException() {
        when(regionThresholdRepository.findByThresholdType("custom"))
                .thenReturn(null);

        assertThrows(RuntimeException.class, () -> regionThresholdService.getRegionByType("custom"));

        verify(regionThresholdRepository).findByThresholdType("custom");
        verifyNoMoreInteractions(regionThresholdRepository);
    }

    @Test
    void testUpdateRegionThreshold_UpdatesSuccessfully() {
        RegionThreshold mockExisting = createMockRegionThreshold();

        when(regionThresholdRepository.findByThresholdType(APROVAL_REGION_THRESHOLD))
                .thenReturn(mockExisting);

        RegionThresholdDTO updatedDTO = new RegionThresholdDTO(11, 21, 31, 41, 51, 61, 71);

        RegionThreshold saved = new RegionThreshold();
        saved.setEMEA(11);
        saved.setLATAM(21);
        saved.setCANADA(31);
        saved.setAPAC(41);
        saved.setAUSTRALIA(51);
        saved.setINDIA(61);
        saved.setUS(71);

        when(regionThresholdRepository.save(any(RegionThreshold.class))).thenReturn(saved);

        RegionThresholdDTO result = regionThresholdService.updateRegionThreshold(updatedDTO);

        assertNotNull(result);
        assertEquals(11, result.getEMEA());
        assertEquals(21, result.getLATAM());
        assertEquals(31, result.getCANADA());
        assertEquals(41, result.getAPAC());
        assertEquals(51, result.getAUSTRALIA());
        assertEquals(61, result.getINDIA());
        assertEquals(71, result.getUS());

        assertEquals(11, mockExisting.getEMEA());
        assertEquals(21, mockExisting.getLATAM());
        assertEquals(31, mockExisting.getCANADA());
        assertEquals(41, mockExisting.getAPAC());
        assertEquals(51, mockExisting.getAUSTRALIA());
        assertEquals(61, mockExisting.getINDIA());
        assertEquals(71, mockExisting.getUS());

        verify(regionThresholdRepository).findByThresholdType(APROVAL_REGION_THRESHOLD);
        verify(regionThresholdRepository).save(mockExisting);
    }

    @Test
    void testUpdateRegionThreshold_WhenInputIsNull_ThrowsException() {
        when(regionThresholdRepository.findByThresholdType(APROVAL_REGION_THRESHOLD))
                .thenReturn(createMockRegionThreshold());

        assertThrows(RuntimeException.class, () -> regionThresholdService.updateRegionThreshold(null));

        verify(regionThresholdRepository).findByThresholdType(APROVAL_REGION_THRESHOLD);
        verify(regionThresholdRepository, never()).save(any());
    }

    @Test
    void testUpdateRegionThreshold_WhenExistingThresholdNotFound_ThrowsNullPointerException() {
        RegionThresholdDTO updatedDTO = new RegionThresholdDTO(11, 21, 31, 41, 51, 61, 71);

        when(regionThresholdRepository.findByThresholdType(APROVAL_REGION_THRESHOLD))
                .thenReturn(null);

        assertThrows(NullPointerException.class,
                () -> regionThresholdService.updateRegionThreshold(updatedDTO));

        verify(regionThresholdRepository).findByThresholdType(APROVAL_REGION_THRESHOLD);
        verify(regionThresholdRepository, never()).save(any());
    }
}