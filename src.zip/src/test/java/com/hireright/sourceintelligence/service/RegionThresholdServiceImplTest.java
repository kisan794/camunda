package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.v2.dto.RegionThresholdDTO;
import com.hireright.sourceintelligence.domain.entity.RegionThreshold;
import com.hireright.sourceintelligence.domain.repository.RegionThresholdRepository;
import com.hireright.sourceintelligence.service.impl.RegionThresholdServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.APROVAL_REGION_THRESHOLD;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RegionThresholdServiceImplTest {

    private RegionThresholdRepository regionThresholdRepository;
    private RegionThresholdServiceImpl regionThresholdService;

    @BeforeEach
    void setUp() {
        regionThresholdRepository = mock(RegionThresholdRepository.class);
        regionThresholdService = new RegionThresholdServiceImpl(regionThresholdRepository);
    }

    private RegionThreshold createMockRegionThreshold() {
        RegionThreshold threshold = new RegionThreshold();
        threshold.setEMEA(10);
        threshold.setLATAM(20);
        threshold.setCANADA(30);
        threshold.setAPAC(40);
        threshold.setAUSTRALIA(50);
        threshold.setINDIA(60);
        threshold.setUS(70);
        return threshold;
    }

    @Test
    void testGetRegions_ReturnsThresholdDTO() {
        RegionThreshold mockThreshold = createMockRegionThreshold();

        when(regionThresholdRepository.findByThresholdType("approval"))
                .thenReturn(mockThreshold);

        RegionThresholdDTO result = regionThresholdService.getRegions();

        assertNotNull(result);
        assertEquals(10, result.getEMEA());
        assertEquals(20, result.getLATAM());
        assertEquals(30, result.getCANADA());
        assertEquals(40, result.getAPAC());
        assertEquals(50, result.getAUSTRALIA());
        assertEquals(60, result.getINDIA());
        assertEquals(70, result.getUS());

        verify(regionThresholdRepository, times(1))
                .findByThresholdType("approval");
    }


    @Test
    void testGetRegionByType_ReturnsDTO() {
        RegionThreshold mockThreshold = createMockRegionThreshold();

        when(regionThresholdRepository.findByThresholdType("custom"))
                .thenReturn(mockThreshold);

        RegionThresholdDTO result = regionThresholdService.getRegionByType("custom");

        assertNotNull(result);
        assertEquals(10, result.getEMEA());
    }


    @Test
    void testUpdateRegionThreshold_UpdatesSuccessfully() {
        RegionThreshold mockExisting = createMockRegionThreshold();

        when(regionThresholdRepository.findByThresholdType("approval")).thenReturn(mockExisting);

        RegionThresholdDTO updatedDTO = new RegionThresholdDTO(11, 21, 31, 41, 51, 61, 71);

        RegionThreshold saved = new RegionThreshold();
        saved.setEMEA(11);
        saved.setLATAM(21);
        saved.setCANADA(31);
        saved.setAPAC(41);
        saved.setAUSTRALIA(51);
        saved.setINDIA(61);
        saved.setUS(71);

        when(regionThresholdRepository.save(any(RegionThreshold.class))).thenReturn(saved);

        RegionThresholdDTO result = regionThresholdService.updateRegionThreshold(updatedDTO);

        assertEquals(11, result.getEMEA());
        assertEquals(71, result.getUS());

        verify(regionThresholdRepository).findByThresholdType("approval");
        verify(regionThresholdRepository).save(mockExisting);
    }

}
