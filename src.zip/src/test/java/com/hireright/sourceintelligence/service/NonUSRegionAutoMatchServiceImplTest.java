package com.hireright.sourceintelligence.service;
import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchSourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.mapper.AutoMatchMapper;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.impl.DistanceAlgorithm;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.service.impl.NonUSRegionAutoMatchServiceImpl;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.util.TestDataProvider.testData;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class NonUSRegionAutoMatchServiceImplTest {

 @Mock
 private CustomSourceRepository<Source> customSourceRepository;

 @Mock
 private SourceMapper sourceMapper;

 @Mock
 private AutoMatchMapper autoMatchMapper;

 @Mock
 private ElasticsearchService elasticsearchService;

 @Mock
 private DistanceAlgorithm distanceAlgorithm;
 @Mock
 private ReportDataUtils reportDataUtils;


 @InjectMocks
 private NonUSRegionAutoMatchServiceImpl autoMatchService;

 @Test
 void testAutoMatch_noElasticSearchResults() {
  AutoMatchDTO input = testData();

  when(elasticsearchService.nonUSAutoMatchSearch(any(), any())).thenReturn(Collections.emptyList());

  AutoMatchResponseDTO response = autoMatchService.autoMatch(input);

  assertEquals(NO_AUTO_MATCH_ES, response.getError());
 }

 @Test
 void testAutoMatch_duplicateOrNoMatchFromDistanceAlgorithm() {
  AutoMatchDTO input = testData();
  input.setSourceName("Some School");
  input.setCity("Libby");

  ElasticsearchSource s1 = new ElasticsearchSource();
  s1.setOrganizationName("ABC School");
  s1.setCity("Libby");

  ElasticsearchSource s2 = new ElasticsearchSource();
  s2.setOrganizationName("XYZ School");
  s2.setCity("Libby");

  List<ElasticsearchSource> esResults = List.of(s1, s2);

  when(elasticsearchService.nonUSAutoMatchSearch(any(), any())).thenReturn(esResults);

  AutoMatchResponseDTO response = autoMatchService.autoMatch(input);

  assertEquals(NO_AUTO_MATCH_DUPLICATE, response.getError());
 }


 @Test
 void testAutoMatch_noMatchInMongo() {
  AutoMatchDTO input = testData();
  List<ElasticsearchSource> esResults = List.of(new ElasticsearchSource());

  when(elasticsearchService.nonUSAutoMatchSearch(any(), any())).thenReturn(esResults);
  when(customSourceRepository.findByHonAndStatus(any(), any(), eq(Source.class), any())).thenReturn(Collections.emptyList());

  AutoMatchResponseDTO response = autoMatchService.autoMatch(input);

  assertEquals(NO_AUTO_MATCH_MS, response.getError());
 }


 @Test
 void testAutoMatch_elasticsearchReturnsNull() {
  AutoMatchDTO input = testData();

  when(elasticsearchService.nonUSAutoMatchSearch(any(), any())).thenReturn(null);

  AutoMatchResponseDTO response = autoMatchService.autoMatch(input);

  assertEquals(NO_AUTO_MATCH_ES, response.getError());
 }

 @Test
 void testAutoMatch_nullMongoResponse() {
  AutoMatchDTO input = testData();
  List<ElasticsearchSource> esResults = List.of(new ElasticsearchSource());

  when(elasticsearchService.nonUSAutoMatchSearch(any(), any())).thenReturn(esResults);
  when(customSourceRepository.findByHonAndStatus(any(), any(), eq(Source.class), any())).thenReturn(null);

  AutoMatchResponseDTO response = autoMatchService.autoMatch(input);

  assertEquals(NO_AUTO_MATCH_MS, response.getError());
 }

 @Test
 void testAutoMatch_successfulMatch() {
  AutoMatchDTO input = testData();
  List<ElasticsearchSource> esResults = List.of(new ElasticsearchSource());
  esResults.get(0).setHon("HON123");
  Source source = new Source();
  source.setHon("HON123");
  List<Source> sources = List.of(source);
  AutoMatchSourceDTO dto = new AutoMatchSourceDTO();

  when(elasticsearchService.nonUSAutoMatchSearch(any(), any())).thenReturn(esResults);
  when(customSourceRepository.findByHonAndStatus(any(), any(), eq(Source.class), any())).thenReturn(sources);
  when(autoMatchMapper.toAutoMatchDTO(any())).thenReturn(dto);

  AutoMatchResponseDTO response = autoMatchService.autoMatch(input);

  assertNotNull(response);
  assertEquals(dto, response.getSource());
  assertNull(response.getError());
  verify(autoMatchMapper).toAutoMatchDTO(source);



 }

 @Test
 void testFindExactSource_exactMatchFound() throws Exception {
  AutoMatchDTO input = new AutoMatchDTO();
  input.setSourceName("Oxford University");
  input.setCity("London");

  ElasticsearchSource es1 = new ElasticsearchSource();
  es1.setOrganizationName("Oxford University");
  es1.setHon("HON123");
  es1.setCity("London");

  ElasticsearchSource es2 = new ElasticsearchSource();
  es2.setOrganizationName("Cambridge University");
  es2.setHon("HON456");
  es2.setCity("London");

  List<ElasticsearchSource> searchList = List.of(es1, es2);

  var method = NonUSRegionAutoMatchServiceImpl.class
          .getDeclaredMethod("findExactSource", AutoMatchDTO.class, List.class);
  method.setAccessible(true);

  Object result = method.invoke(autoMatchService, input, searchList);

  assertEquals("HON123", result);
 }

 @Test
 void testFindExactSource_duplicateMatchReturnsEmpty() throws Exception {
  AutoMatchDTO input = new AutoMatchDTO();
  input.setSourceName("ABC School");
  input.setCity("Libby");

  ElasticsearchSource es1 = new ElasticsearchSource();
  es1.setOrganizationName("abc school");
  es1.setHon("HON111");
  es1.setCity("Libby"); // must not be null

  ElasticsearchSource es2 = new ElasticsearchSource();
  es2.setOrganizationName("ABC School");
  es2.setHon("HON222");
  es2.setCity("Libby"); // must not be null

  List<ElasticsearchSource> searchList = List.of(es1, es2);

  var method = NonUSRegionAutoMatchServiceImpl.class
          .getDeclaredMethod("findExactSource", AutoMatchDTO.class, List.class);
  method.setAccessible(true);

  // Act
  Object result = method.invoke(autoMatchService, input, searchList);

  // Assert
  assertEquals("", result, "Expected empty HON when duplicates found");
 }



 @Test
 void testAutoMatch_internalServerError() {
  AutoMatchDTO input = testData();

  when(elasticsearchService.nonUSAutoMatchSearch(any(), any())).thenThrow(new RuntimeException("Unexpected"));

  AutoMatchResponseDTO response = autoMatchService.autoMatch(input);

  assertEquals(INTERNAL_SERVER_ERROR, response.getServerError());
 }
}

