package com.hireright.sourceintelligence.service;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.ShardStatistics;
import co.elastic.clients.elasticsearch.core.*;
import co.elastic.clients.elasticsearch.core.search.Hit;
import co.elastic.clients.elasticsearch.core.search.HitsMetadata;
import co.elastic.clients.elasticsearch.indices.ElasticsearchIndicesClient;
import co.elastic.clients.transport.endpoints.BooleanResponse;
import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.ElasticsearchDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.impl.DistanceAlgorithm;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchMapper;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;

import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import co.elastic.clients.elasticsearch.indices.ExistsRequest;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ElasticsearchServiceTest {

    @InjectMocks
    private ElasticsearchService elasticsearchService;

    @Mock
    private ElasticsearchMapper elasticsearchMapper;

    @Mock
    private DistanceAlgorithm distanceAlgorithm;



    @Mock
    private ElasticsearchClient elasticsearchClient;

    @Mock
    private ElasticsearchIndicesClient indicesClient;

    @BeforeEach
    void setUp() throws IOException {
        lenient().when(elasticsearchClient.indices()).thenReturn(indicesClient);
        BooleanResponse booleanResponse = mock(BooleanResponse.class);
        when(booleanResponse.value()).thenReturn(true);
        when(indicesClient.exists((ExistsRequest) any())).thenReturn(booleanResponse);
    }


    @Test
    void testCreateSource_IndexExists_AddsSource() throws IOException {
        Source source = new Source();
        source.setOrganizationType(OrganizationType.EDUCATION);
        source.setHon("123");

        ElasticsearchSource esSource = new ElasticsearchSource();
        esSource.setHon("123");

        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);
        BooleanResponse booleanResponse = mock(BooleanResponse.class);
        when(booleanResponse.value()).thenReturn(true);
        when(indicesClient.exists(any(Function.class))).thenReturn(booleanResponse);

        when(elasticsearchClient.indices()).thenReturn(indicesClient);
        elasticsearchService.createSource(source);
        verify(elasticsearchClient).create(any(Function.class));
    }



    @Test
    void testUpdateSourcePartial_shouldUpdateDocument() throws IOException {
        String indexName = "test_index";
        String docId = "HON123";
        Map<String, Object> updatedFields = Map.of("city", "Delhi");

        UpdateResponse<ElasticsearchSource> updateResponse = mock(UpdateResponse.class);
        when(elasticsearchClient.update(any(Function.class), eq(ElasticsearchSource.class)))
                .thenReturn(updateResponse);
        elasticsearchService.updateSourcePartial(indexName, docId, updatedFields);
        verify(elasticsearchClient).update(any(Function.class), eq(ElasticsearchSource.class));
    }


    @SuppressWarnings("unchecked")
    @Test
    void testGetSourceById_shouldReturnSource() throws IOException {
        GetResponse<ElasticsearchSource> mockResponse = mock(GetResponse.class);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class)))
                .thenReturn(mockResponse);
        GetResponse<ElasticsearchSource> result = elasticsearchService.getSourceById("test_index", "HON123");
        assertNotNull(result);
        verify(elasticsearchClient).get(any(Function.class), eq(ElasticsearchSource.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testGetSourceById_shouldReturnResponse() throws IOException {

        GetResponse<ElasticsearchSource> response = mock(GetResponse.class);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class)))
                .thenReturn(response);
        GetResponse<ElasticsearchSource> result = elasticsearchService.getSourceById("index", "HON123");
        assertNotNull(result);
        verify(elasticsearchClient).get(any(Function.class), eq(ElasticsearchSource.class));
    }


    @Test
    void testSmartSearch_textBoxExact() throws IOException {
        // Arrange
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setOrganizationName("Test Org");
        String indexName = "test_index";

        ElasticsearchSource source = new ElasticsearchSource();
        source.setHon("H123");

        Hit<ElasticsearchSource> realHit = new Hit.Builder<ElasticsearchSource>()
                .id("H123")
                .index(indexName)
                .score(350.0)
                .source(source)
                .build();

        HitsMetadata<ElasticsearchSource> hitsMetadata = new HitsMetadata.Builder<ElasticsearchSource>()
                .hits(List.of(realHit))
                .maxScore(350.0)
                .build();

        ShardStatistics shards = new ShardStatistics.Builder()
                .total(1).successful(1).skipped(0).failed(0)
                .build();

        SearchResponse<ElasticsearchSource> response = new SearchResponse.Builder<ElasticsearchSource>()
                .took(5)
                .timedOut(false)
                .shards(shards)
                .hits(hitsMetadata)
                .build();
        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenReturn(response);

        // Act
        Set<String> result = elasticsearchService.smartSearch(dto, indexName, false);

        // Assert
        assertNotNull(result);
        assertTrue(result.contains("H123"));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testUpdateStatusForSourceIndex_shouldAddSourceIfNotExists() throws IOException {
        ElasticsearchMapper mockMapper = mock(ElasticsearchMapper.class);
        ElasticsearchClient mockClient = mock(ElasticsearchClient.class);
        ElasticsearchIndicesClient mockIndices = mock(ElasticsearchIndicesClient.class);
        DistanceAlgorithm mockAlgo = mock(DistanceAlgorithm.class);
        ElasticsearchService service = new ElasticsearchService(mockMapper, mockClient, mockAlgo);
        Source source = new Source();
        source.setHon("HON123");
        source.setOrganizationType(OrganizationType.EDUCATION);

        ElasticsearchSource esSource = new ElasticsearchSource();
        esSource.setHon("HON123");
        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("");
        when(mockClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);
        when(mockMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);
        BooleanResponse boolResponse = mock(BooleanResponse.class);
        when(boolResponse.value()).thenReturn(true);
        when(mockIndices.exists(any(Function.class))).thenReturn(boolResponse);
        when(mockClient.indices()).thenReturn(mockIndices);
        service.updateStatusForSourceIndex(source, "ACTIVE", "APPROVED");
        verify(mockClient).create(any(Function.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testUpdateStatusForSourceIndex_shouldUpdateStatusIfExists() throws IOException {
        // Arrange
        Source source = new Source();
        source.setHon("HON123");
        source.setOrganizationType(OrganizationType.EDUCATION);

        ElasticsearchSource esSource = new ElasticsearchSource();
        esSource.setHon("HON123");

        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("HON123");
        when(getResponse.source()).thenReturn(esSource);

        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);
        elasticsearchService.updateStatusForSourceIndex(source, "ACTIVE", "APPROVED");
        verify(elasticsearchClient).update(any(Function.class), eq(ElasticsearchSource.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testDropDownSearch_shouldReturnResults() throws IOException {
        // Arrange
        ElasticsearchDTO dto = new ElasticsearchDTO();

        ElasticsearchSource hitSource = new ElasticsearchSource();
        hitSource.setHon("HON123");

        Hit<ElasticsearchSource> hit = mock(Hit.class);
        when(hit.source()).thenReturn(hitSource);

        List<Hit<ElasticsearchSource>> hitList = List.of(hit);

        HitsMetadata<ElasticsearchSource> hitsMetadata = mock(HitsMetadata.class);
        when(hitsMetadata.hits()).thenReturn(hitList);

        SearchResponse<ElasticsearchSource> response = mock(SearchResponse.class);
        when(response.hits()).thenReturn(hitsMetadata);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenReturn(response);

        // Act
        List<ElasticsearchSource> result = elasticsearchService.dropDownSearch(dto, "index");

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("HON123", result.get(0).getHon());
        verify(elasticsearchClient).search(any(Function.class), eq(ElasticsearchSource.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testSearch_shouldReturnResults() throws IOException {
        Query query = mock(Query.class);
        String index = "test_index";
        int size = 10;

        ElasticsearchSource mockSource = new ElasticsearchSource();
        Hit<ElasticsearchSource> mockHit = mock(Hit.class);
        when(mockHit.source()).thenReturn(mockSource);
        List<Hit<ElasticsearchSource>> hits = List.of(mockHit);

        HitsMetadata<ElasticsearchSource> mockHitsMetadata = mock(HitsMetadata.class);
        when(mockHitsMetadata.hits()).thenReturn(hits);

        SearchResponse<ElasticsearchSource> mockResponse = mock(SearchResponse.class);
        when(mockResponse.hits()).thenReturn(mockHitsMetadata);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenReturn(mockResponse);

        List<ElasticsearchSource> result = elasticsearchService.search(query, index, size);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(mockSource, result.get(0));
        verify(elasticsearchClient).search(any(Function.class), eq(ElasticsearchSource.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testUpdateSourceIndex_shouldUpdateIfDocumentExists() throws IOException, IllegalAccessException {
        // Arrange
        Source source = new Source();
        source.setHon("HON123");
        source.setOrganizationType(OrganizationType.EDUCATION);

        ElasticsearchSource esSource = new ElasticsearchSource();
        esSource.setHon("HON123");

        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn("HON123");
        when(getResponse.source()).thenReturn(esSource);

        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);

        // Act
        elasticsearchService.updateSourceIndex(source);

        // Assert
        verify(elasticsearchClient).update(any(Function.class), eq(ElasticsearchSource.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testUpdateSourceIndex_shouldAddIfDocumentDoesNotExist() throws IOException, IllegalAccessException {
        // Arrange
        Source source = new Source();
        source.setHon("HON123");
        source.setOrganizationType(OrganizationType.EDUCATION);

        ElasticsearchSource esSource = new ElasticsearchSource();
        esSource.setHon("HON123");

        GetResponse<ElasticsearchSource> getResponse = mock(GetResponse.class);
        when(getResponse.id()).thenReturn(""); // Simulate document not found
        when(elasticsearchMapper.sourceToSearchSourceMapping(source)).thenReturn(esSource);
        when(elasticsearchClient.get(any(Function.class), eq(ElasticsearchSource.class))).thenReturn(getResponse);

        // Act
        elasticsearchService.updateSourceIndex(source);

        // Assert
        verify(elasticsearchClient).create(any(Function.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testGetSourceByHon_shouldReturnSearchResponse() throws IOException {
        // Arrange
        String indexName = "test_index";
        String hon = "HON123";
        SearchResponse<ElasticsearchSource> mockResponse = mock(SearchResponse.class);

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenReturn(mockResponse);

        // Act
        SearchResponse<ElasticsearchSource> result = elasticsearchService.getSourceByHon(indexName, hon);

        // Assert
        assertNotNull(result);
        verify(elasticsearchClient).search(any(Function.class), eq(ElasticsearchSource.class));
    }
    @SuppressWarnings("unchecked")
    @Test
    void testGetSourceByHon_shouldReturnNullOnException() throws IOException {
        // Arrange
        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenThrow(new IOException("Simulated failure"));

        // Act
        SearchResponse<ElasticsearchSource> result = elasticsearchService.getSourceByHon("index", "HON123");

        // Assert
        assertNull(result);
    }

    @Test
    void testAutoMatchSearch_shouldReturnMatchedResults() {
        // Arrange
        AutoMatchDTO autoMatchDTO = new AutoMatchDTO();
        String index = "test_index";

        ElasticsearchSource mockSource = new ElasticsearchSource();
        mockSource.setHon("HON123");

        List<ElasticsearchSource> mockList = List.of(mockSource);

        ElasticsearchService spyService = spy(elasticsearchService);
        doReturn(mockList).when(spyService).search(any(Query.class), eq(index), eq(15));

        // Act
        List<ElasticsearchSource> result = spyService.autoMatchSearch(autoMatchDTO, index);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("HON123", result.get(0).getHon());
    }

    @Test
    void testNonUSAutoMatchSearch_shouldReturnMatchedResults() {
        // Arrange
        AutoMatchDTO autoMatchDTO = new AutoMatchDTO();
        String index = "test_index";

        ElasticsearchSource mockSource = new ElasticsearchSource();
        mockSource.setHon("HON456");

        List<ElasticsearchSource> mockList = List.of(mockSource);

        ElasticsearchService spyService = spy(elasticsearchService);
        doReturn(mockList).when(spyService).search(any(Query.class), eq(index), eq(25));

        // Act
        List<ElasticsearchSource> result = spyService.nonUSAutoMatchSearch(autoMatchDTO, index);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("HON456", result.get(0).getHon());
    }



    @Test
    void testSmartSearch_shouldUseJaroLogicWhenScoreLow() throws IOException {
        // Arrange
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setOrganizationName("Test Org");
        String index = "test_index";

        ElasticsearchSource source = new ElasticsearchSource();
        source.setHon("H999");

        Hit<ElasticsearchSource> hit = new Hit.Builder<ElasticsearchSource>()
                .id("H999")
                .index(index)
                .score(150.0) // < 300, triggers Jaro logic
                .source(source)
                .build();

        HitsMetadata<ElasticsearchSource> hitsMetadata = new HitsMetadata.Builder<ElasticsearchSource>()
                .hits(List.of(hit))
                .maxScore(150.0)
                .build();

        ShardStatistics shards = new ShardStatistics.Builder()
                .total(1).successful(1).skipped(0).failed(0)
                .build();

        SearchResponse<ElasticsearchSource> mockResponse = new SearchResponse.Builder<ElasticsearchSource>()
                .took(5)
                .timedOut(false)
                .shards(shards)
                .hits(hitsMetadata)
                .build();
        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenReturn(mockResponse);

        Set<String> mockHonSet = Set.of("H999");
        when(distanceAlgorithm.smartSearchJaroWinklerAlgorithmWithText(anyString(), anyList(), anyString()))
                .thenReturn(mockHonSet);

        // Act
        Set<String> result = elasticsearchService.smartSearch(dto, index, false);

        // Assert
        assertNotNull(result);
        assertTrue(result.contains("H999"));
        verify(distanceAlgorithm).smartSearchJaroWinklerAlgorithmWithText(anyString(), anyList(), anyString());
    }


    @Test
    void testSmartSearch_shouldUseDropDownLogicWhenDropDownSelected() throws IOException {
        // Arrange
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setOrganizationName("DropDown Org");
        String index = "test_index";

        ElasticsearchSource source = new ElasticsearchSource();
        source.setHon("DROPDOWN123");

        Hit<ElasticsearchSource> hit = new Hit.Builder<ElasticsearchSource>()
                .id("DROPDOWN123")
                .index(index)
                .score(400.0)
                .source(source)
                .build();

        HitsMetadata<ElasticsearchSource> hitsMetadata = new HitsMetadata.Builder<ElasticsearchSource>()
                .hits(List.of(hit))
                .maxScore(400.0)
                .build();

        ShardStatistics shards = new ShardStatistics.Builder()
                .total(1).successful(1).skipped(0).failed(0)
                .build();

        SearchResponse<ElasticsearchSource> response = new SearchResponse.Builder<ElasticsearchSource>()
                .took(3)
                .timedOut(false)
                .shards(shards)
                .hits(hitsMetadata)
                .build();

        when(elasticsearchClient.search(any(Function.class), eq(ElasticsearchSource.class)))
                .thenReturn(response);
        Set<String> result = elasticsearchService.smartSearch(dto, index, true);

        // Assert
        assertNotNull(result);
        assertTrue(result.contains("DROPDOWN123"));
    }

    @Test
    void testGetUpdatedFields_onlyChangedFieldsIncluded() throws IllegalAccessException {
        ElasticsearchSource oldSource = new ElasticsearchSource();
        oldSource.setCity(Collections.singletonList("Mumbai"));
        oldSource.setHon("H123");

        ElasticsearchSource newSource = new ElasticsearchSource();
        newSource.setCity(Collections.singletonList("Delhi"));
        newSource.setHon("H123");

        Map<String, Object> result = elasticsearchService.getUpdatedFields(newSource, oldSource);

        assertTrue(result.containsKey("city"));
        assertEquals(Collections.singletonList("Delhi"), result.get("city"));
        assertFalse(result.containsKey("hon"));
    }

    // Add more tests for:
    // - updateSourceIndex
    // - getUpdatedFields
    // - smartSearch, dropDownSearch, autoMatchSearch

}