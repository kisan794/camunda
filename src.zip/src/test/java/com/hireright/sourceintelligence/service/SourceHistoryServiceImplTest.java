package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogResponse;
import com.hireright.sourceintelligence.api.dto.history.ChangelogResponseDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.service.impl.SourceHistoryServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.CURRENT;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.PREVIOUS;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SourceHistoryServiceTest {

    private static final String EMP_HON = "EMP123";

    @InjectMocks
    private SourceHistoryServiceImpl sourceHistoryService;

    @Mock
    private SourceMapper sourceMapper;

    @Mock
    private CustomSourceRepository<Source> customSourceRepository;

    @Test
    void constructor_shouldCreateInstance() {
        SourceHistoryServiceImpl service = new SourceHistoryServiceImpl(sourceMapper, customSourceRepository);
        assertNotNull(service);
    }

    @Test
    void getSourcesByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc_shouldReturnMappedList() {
        List<Source> histories = List.of(new Source(), new Source());
        List<SourceOrganizationDTO> mapped = List.of(new SourceOrganizationDTO(), new SourceOrganizationDTO());

        when(customSourceRepository.findByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc(
                eq(EMP_HON), eq(ApprovalStatus.APPROVED), eq(2.0), eq(Source.class), anyString()))
                .thenReturn(histories);
        when(sourceMapper.toSourceDTOList(histories)).thenReturn(mapped);

        List<SourceOrganizationDTO> result =
                sourceHistoryService.getSourcesByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc(
                        EMP_HON, ApprovalStatus.APPROVED, 2.0);

        assertEquals(2, result.size());
        assertSame(mapped, result);
    }

    @Test
    void getSourcesByHonAndApprovalStatusOrderByVersionDesc_shouldReturnEmpty_whenBothCurrentAndHistoryAreEmpty() {
        when(customSourceRepository.findByHon(eq(EMP_HON), eq(Source.class), anyString()))
                .thenReturn(new LinkedList<>());
        when(customSourceRepository.findByHonAndApprovalStatusOrderByVersionDesc(eq(EMP_HON), any(), eq(Source.class), anyString()))
                .thenReturn(new ArrayList<>());
        when(sourceMapper.toSourceDTOList(anyList())).thenReturn(new ArrayList<>());

        List<SourceOrganizationDTO> result =
                sourceHistoryService.getSourcesByHonAndApprovalStatusOrderByVersionDesc(EMP_HON, ApprovalStatus.APPROVED);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getSourcesByHonAndApprovalStatusOrderByVersionDesc_shouldReturnMappedList_whenOnlyCurrentExists() {
        LinkedList<Source> current = new LinkedList<>();
        current.add(new Source());

        when(customSourceRepository.findByHon(eq(EMP_HON), eq(Source.class), anyString()))
                .thenReturn(current);
        when(customSourceRepository.findByHonAndApprovalStatusOrderByVersionDesc(eq(EMP_HON), any(), eq(Source.class), anyString()))
                .thenReturn(new ArrayList<>());
        when(sourceMapper.toSourceDTOList(anyList())).thenReturn(List.of(new SourceOrganizationDTO()));

        List<SourceOrganizationDTO> result =
                sourceHistoryService.getSourcesByHonAndApprovalStatusOrderByVersionDesc(EMP_HON, ApprovalStatus.APPROVED);

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void getSourcesByHonAndApprovalStatusOrderByVersionDesc_shouldReturnMappedList_whenCurrentAndHistoryExist() {
        LinkedList<Source> current = new LinkedList<>();
        current.add(new Source());

        List<Source> history = List.of(new Source(), new Source());

        when(customSourceRepository.findByHon(eq(EMP_HON), eq(Source.class), anyString()))
                .thenReturn(current);
        when(customSourceRepository.findByHonAndApprovalStatusOrderByVersionDesc(eq(EMP_HON), any(), eq(Source.class), anyString()))
                .thenReturn(history);
        when(sourceMapper.toSourceDTOList(anyList()))
                .thenReturn(List.of(new SourceOrganizationDTO(), new SourceOrganizationDTO(), new SourceOrganizationDTO()));

        List<SourceOrganizationDTO> result =
                sourceHistoryService.getSourcesByHonAndApprovalStatusOrderByVersionDesc(EMP_HON, ApprovalStatus.APPROVED);

        assertNotNull(result);
        assertEquals(3, result.size());
    }

    @Test
    void getSourceByHonAndVersion_shouldReturnFromHistory_whenFoundInHistory() {
        Source historySource = new Source();
        SourceOrganizationDTO dto = new SourceOrganizationDTO();

        when(customSourceRepository.findOneByHonAndVersion(eq(EMP_HON), eq(1.0), eq(Source.class), contains("history")))
                .thenReturn(historySource);
        when(sourceMapper.entitySourceToDTO(historySource)).thenReturn(dto);

        SourceOrganizationDTO result = sourceHistoryService.getSourceByHonAndVersion(EMP_HON, 1.0);

        assertNotNull(result);
        assertSame(dto, result);
        verify(customSourceRepository, never())
                .findOneByHonAndVersion(eq(EMP_HON), eq(1.0), eq(Source.class), argThat(name -> !name.contains("history")));
    }

    @Test
    void getSourceByHonAndVersion_shouldReturnFromCurrent_whenNotFoundInHistoryButFoundInCurrent() {
        Source currentSource = new Source();
        SourceOrganizationDTO dto = new SourceOrganizationDTO();

        when(customSourceRepository.findOneByHonAndVersion(eq(EMP_HON), eq(2.0), eq(Source.class), contains("history")))
                .thenReturn(null);
        when(customSourceRepository.findOneByHonAndVersion(eq(EMP_HON), eq(2.0), eq(Source.class), argThat(name -> !name.contains("history"))))
                .thenReturn(currentSource);
        when(sourceMapper.entitySourceToDTO(currentSource)).thenReturn(dto);

        SourceOrganizationDTO result = sourceHistoryService.getSourceByHonAndVersion(EMP_HON, 2.0);

        assertNotNull(result);
        assertSame(dto, result);
    }

    @Test
    void getSourceByHonAndVersion_shouldThrow_whenNotFoundInHistoryAndCurrent() {
        when(customSourceRepository.findOneByHonAndVersion(eq(EMP_HON), eq(3.0), eq(Source.class), contains("history")))
                .thenReturn(null);
        when(customSourceRepository.findOneByHonAndVersion(eq(EMP_HON), eq(3.0), eq(Source.class), argThat(name -> !name.contains("history"))))
                .thenReturn(null);

        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> sourceHistoryService.getSourceByHonAndVersion(EMP_HON, 3.0));
    }

    @Test
    void getSourcesForDiff_shouldReturnCurrentAndPreviousDtos_forCurrentType() {
        Source current = new Source();
        current.setHon(EMP_HON);
        current.setVersion(5.0);

        Source previous = new Source();
        previous.setHon(EMP_HON);
        previous.setVersion(4.0);

        SourceOrganizationDTO currentDto = new SourceOrganizationDTO();
        currentDto.setVersion(5.0);

        SourceOrganizationDTO previousDto = new SourceOrganizationDTO();
        previousDto.setVersion(4.0);

        when(customSourceRepository.findOneByHonAndVersion(
                eq(EMP_HON), eq(5.0), eq(Source.class), argThat(name -> !name.contains("history"))))
                .thenReturn(current);

        when(customSourceRepository.findOneByHonAndVersion(
                eq(EMP_HON), eq(4.0), eq(Source.class), contains("history")))
                .thenReturn(previous);

        when(sourceMapper.entitySourceToDTO(same(current))).thenReturn(currentDto);
        when(sourceMapper.entitySourceToDTO(same(previous))).thenReturn(previousDto);

        List<SourceOrganizationDTO> result = sourceHistoryService.getSourcesForDiff(EMP_HON, 5.0, CURRENT);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(5.0, result.get(0).getVersion());
        assertEquals(4.0, result.get(1).getVersion());
        assertSame(currentDto, result.get(0));
        assertSame(previousDto, result.get(1));
    }

    @Test
    void getSourcesForDiff_shouldIncludeNulls_forCurrentType_whenSourcesMissing() {
        when(customSourceRepository.findOneByHonAndVersion(eq(EMP_HON), eq(5.0), eq(Source.class), argThat(name -> !name.contains("history"))))
                .thenReturn(null);
        when(customSourceRepository.findOneByHonAndVersion(eq(EMP_HON), eq(4.0), eq(Source.class), contains("history")))
                .thenReturn(null);

        List<SourceOrganizationDTO> result = sourceHistoryService.getSourcesForDiff(EMP_HON, 5.0, CURRENT);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertNull(result.get(0));
        assertNull(result.get(1));
    }

    @Test
    void getSourcesForDiff_shouldReturnMappedList_forPreviousType_whenHistoryExists() {
        List<Source> approvedHistory = List.of(new Source(), new Source());
        List<SourceOrganizationDTO> mapped = List.of(new SourceOrganizationDTO(), new SourceOrganizationDTO());

        when(customSourceRepository.findByHonAndVersionInOrderByVersionDesc(
                eq(EMP_HON), any(Double[].class), eq(Source.class), contains("history")))
                .thenReturn(approvedHistory);
        when(sourceMapper.toSourceDTOList(approvedHistory)).thenReturn(mapped);

        List<SourceOrganizationDTO> result = sourceHistoryService.getSourcesForDiff(EMP_HON, 5.0, PREVIOUS);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertSame(mapped, result);
    }

    @Test
    void getSourcesForDiff_shouldReturnEmpty_forPreviousType_whenNoHistoryExists() {
        when(customSourceRepository.findByHonAndVersionInOrderByVersionDesc(
                eq(EMP_HON), any(Double[].class), eq(Source.class), contains("history")))
                .thenReturn(new ArrayList<>());

        List<SourceOrganizationDTO> result = sourceHistoryService.getSourcesForDiff(EMP_HON, 5.0, PREVIOUS);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void getChangeLogByHon_shouldReturnEmpty_whenNoLatestActiveVersionExists() {
        when(customSourceRepository.findByHonOrderByLastModifiedDateDesc(eq(EMP_HON), eq(Source.class), anyString()))
                .thenReturn(new LinkedList<>());

        ChangeLogResponse result = sourceHistoryService.getChangeLogByHon(EMP_HON, ApprovalStatus.APPROVED);

        assertNotNull(result);
        assertNotNull(result.getActiveSources());
        assertTrue(result.getActiveSources().isEmpty());
    }

    @Test
    void getChangeLogByHon_shouldUseApprovedLatestVersion_andPopulateActiveAndSubVersions() {
        LinkedList<Source> latestList = new LinkedList<>();
        Source latest = new Source();
        latest.setHon(EMP_HON);
        latest.setVersion(2.0);
        latest.setApprovalStatus(ApprovalStatus.APPROVED);
        latestList.add(latest);

        Source activeV2A = new Source();
        activeV2A.setHon(EMP_HON);
        activeV2A.setVersion(2.0);

        Source activeV2B = new Source();
        activeV2B.setHon(EMP_HON);
        activeV2B.setVersion(2.1);

        List<Source> activeFor2 = List.of(activeV2A, activeV2B);

        Source subV1 = new Source();
        subV1.setHon(EMP_HON);
        subV1.setVersion(1.0);

        SourceOrganizationDTO dto1 = new SourceOrganizationDTO();
        dto1.setVersion(2.0);

        SourceOrganizationDTO dto2 = new SourceOrganizationDTO();
        dto2.setVersion(2.1);

        SourceOrganizationDTO dto3 = new SourceOrganizationDTO();
        dto3.setVersion(1.0);

        when(customSourceRepository.findByHonOrderByLastModifiedDateDesc(eq(EMP_HON), eq(Source.class), anyString()))
                .thenReturn(latestList);

        when(customSourceRepository.findByHonAndVersionAndApprovalStatus(eq(EMP_HON), eq(2.0), eq(Source.class), contains("history")))
                .thenReturn(activeFor2);
        when(customSourceRepository.findByHonAndVersionAndApprovalStatus(eq(EMP_HON), eq(1.0), eq(Source.class), contains("history")))
                .thenReturn(new ArrayList<>());

        when(customSourceRepository.getHistoryByHonAndVersion(eq(EMP_HON), eq(1.0), eq(Source.class), contains("history")))
                .thenReturn(List.of(subV1));
        when(customSourceRepository.getHistoryByHonAndVersion(eq(EMP_HON), eq(0.0), eq(Source.class), contains("history")))
                .thenReturn(new ArrayList<>());

        when(sourceMapper.entitySourceToDTO(same(activeV2A))).thenReturn(dto1);
        when(sourceMapper.entitySourceToDTO(same(activeV2B))).thenReturn(dto2);
        when(sourceMapper.toSourceDTOList(eq(List.of(subV1)))).thenReturn(List.of(dto3));

        ChangeLogResponse result = sourceHistoryService.getChangeLogByHon(EMP_HON, ApprovalStatus.APPROVED);

        assertNotNull(result);
        assertNotNull(result.getActiveSources());
        assertEquals(2, result.getActiveSources().size());

        ChangelogResponseDTO first = result.getActiveSources().get(0);
        ChangelogResponseDTO second = result.getActiveSources().get(1);

        assertSame(dto1, first.getSourceDTO());
        assertSame(dto2, second.getSourceDTO());
        assertNotNull(second.getVersions());
        assertEquals(1, second.getVersions().size());
        assertSame(dto3, second.getVersions().get(0));
    }

    @Test
    void getChangeLogByHon_shouldIncreaseLatestVersion_whenLatestIsNotApproved_andFallbackToCurrentCollection() {
        LinkedList<Source> latestList = new LinkedList<>();
        Source latest = new Source();
        latest.setHon(EMP_HON);
        latest.setVersion(2.0);
        latest.setApprovalStatus(ApprovalStatus.REJECTED);
        latestList.add(latest);

        Source currentV3 = new Source();
        currentV3.setHon(EMP_HON);
        currentV3.setVersion(3.0);

        Source subV2 = new Source();
        subV2.setHon(EMP_HON);
        subV2.setVersion(2.0);

        SourceOrganizationDTO currentDto = new SourceOrganizationDTO();
        currentDto.setVersion(3.0);

        SourceOrganizationDTO subDto = new SourceOrganizationDTO();
        subDto.setVersion(2.0);

        when(customSourceRepository.findByHonOrderByLastModifiedDateDesc(eq(EMP_HON), eq(Source.class), anyString()))
                .thenReturn(latestList);

        when(customSourceRepository.findByHonAndVersionAndApprovalStatus(eq(EMP_HON), eq(3.0), eq(Source.class), contains("history")))
                .thenReturn(new ArrayList<>());
        when(customSourceRepository.findByHonAndVersionAndApprovalStatus(eq(EMP_HON), eq(3.0), eq(Source.class), argThat(name -> !name.contains("history"))))
                .thenReturn(List.of(currentV3));

        when(customSourceRepository.getHistoryByHonAndVersion(eq(EMP_HON), eq(2.0), eq(Source.class), contains("history")))
                .thenReturn(List.of(subV2));

        when(customSourceRepository.findByHonAndVersionAndApprovalStatus(eq(EMP_HON), eq(2.0), eq(Source.class), contains("history")))
                .thenReturn(new ArrayList<>());

        when(customSourceRepository.getHistoryByHonAndVersion(eq(EMP_HON), eq(1.0), eq(Source.class), contains("history")))
                .thenReturn(new ArrayList<>());
        when(customSourceRepository.getHistoryByHonAndVersion(eq(EMP_HON), eq(1.0), eq(Source.class), argThat(name -> !name.contains("history"))))
                .thenReturn(new ArrayList<>());

        when(sourceMapper.entitySourceToDTO(same(currentV3))).thenReturn(currentDto);
        when(sourceMapper.toSourceDTOList(eq(List.of(subV2)))).thenReturn(List.of(subDto));

        ChangeLogResponse result = sourceHistoryService.getChangeLogByHon(EMP_HON, ApprovalStatus.APPROVED);

        assertNotNull(result);
        assertNotNull(result.getActiveSources());
        assertFalse(result.getActiveSources().isEmpty());

        ChangelogResponseDTO first = result.getActiveSources().get(0);
        assertSame(currentDto, first.getSourceDTO());
        assertNotNull(first.getVersions());
        assertEquals(1, first.getVersions().size());
        assertSame(subDto, first.getVersions().get(0));
    }

    @Test
    void getChangeLogByHon_shouldBreakAfterFallbackToCurrentCollectionForSubVersions() {
        LinkedList<Source> latestList = new LinkedList<>();
        Source latest = new Source();
        latest.setHon(EMP_HON);
        latest.setVersion(1.0);
        latest.setApprovalStatus(ApprovalStatus.APPROVED);
        latestList.add(latest);

        Source currentSub = new Source();
        currentSub.setHon(EMP_HON);
        currentSub.setVersion(0.0);

        SourceOrganizationDTO currentSubDto = new SourceOrganizationDTO();
        currentSubDto.setVersion(0.0);

        when(customSourceRepository.findByHonOrderByLastModifiedDateDesc(eq(EMP_HON), eq(Source.class), anyString()))
                .thenReturn(latestList);

        when(customSourceRepository.findByHonAndVersionAndApprovalStatus(eq(EMP_HON), eq(1.0), eq(Source.class), contains("history")))
                .thenReturn(new ArrayList<>());

        when(customSourceRepository.getHistoryByHonAndVersion(eq(EMP_HON), eq(0.0), eq(Source.class), contains("history")))
                .thenReturn(new ArrayList<>());
        when(customSourceRepository.getHistoryByHonAndVersion(eq(EMP_HON), eq(0.0), eq(Source.class), argThat(name -> !name.contains("history"))))
                .thenReturn(List.of(currentSub));

        when(sourceMapper.toSourceDTOList(eq(List.of(currentSub)))).thenReturn(List.of(currentSubDto));

        ChangeLogResponse result = sourceHistoryService.getChangeLogByHon(EMP_HON, ApprovalStatus.APPROVED);

        assertNotNull(result);
        assertNotNull(result.getActiveSources());
        assertTrue(result.getActiveSources().isEmpty());
    }
}