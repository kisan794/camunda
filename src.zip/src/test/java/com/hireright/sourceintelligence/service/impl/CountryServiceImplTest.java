package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.rds.CountryDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryRegionDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryRegionResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.CountryResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.LanguageDTO;
import com.hireright.sourceintelligence.api.dto.rds.LanguageResponseDTO;
import com.hireright.sourceintelligence.domain.entity.Country;
import com.hireright.sourceintelligence.domain.entity.CountryRegion;
import com.hireright.sourceintelligence.domain.entity.Language;
import com.hireright.sourceintelligence.domain.mapper.CountryMapper;
import com.hireright.sourceintelligence.domain.mapper.LanguageMapper;
import com.hireright.sourceintelligence.domain.repository.CountryRegionRepository;
import com.hireright.sourceintelligence.domain.repository.CountryRepository;
import com.hireright.sourceintelligence.domain.repository.LanguageRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CountryServiceImplTest {

    @Mock
    private CountryRepository countryRepository;

    @Mock
    private CountryRegionRepository countryRegionRepository;

    @Mock
    private LanguageRepository languageRepository;

    @Mock
    private CountryMapper countryMapper;

    @Mock
    private LanguageMapper languageMapper;

    @InjectMocks
    private CountryServiceImpl countryService;

    @Captor
    private ArgumentCaptor<Pageable> pageableCaptor;

    @BeforeEach
    void setUp() {
        assertNotNull(countryService);
    }

    @Test
    void getCountries_shouldReturnResponseWithMappedDataAndMetadata() {
        int startIndex = 2;
        int batchSize = 5;

        Country country = new Country();
        List<Country> countries = List.of(country);
        Page<Country> countryPage = new PageImpl<>(countries);
        CountryDTO countryDTO = CountryDTO.builder().build();
        List<CountryDTO> countryDTOs = List.of(countryDTO);

        when(countryRepository.findAll(org.mockito.ArgumentMatchers.any(Pageable.class))).thenReturn(countryPage);
        when(countryMapper.entityToDTOList(countries)).thenReturn(countryDTOs);

        CountryResponseDTO response = countryService.getCountries(startIndex, batchSize);

        assertNotNull(response);
        assertEquals(countryDTOs, response.getData());
        assertNotNull(response.getMetadata());
        assertEquals(1L, response.getMetadata().getTotalSize());
        assertEquals(startIndex, response.getMetadata().getStartIndex());
        assertEquals(batchSize, response.getMetadata().getBatchSize());
        assertEquals("/country/?startIndex=2&batchSize=5", response.getMetadata().getLink());

        verify(countryRepository).findAll(pageableCaptor.capture());
        Pageable pageable = pageableCaptor.getValue();
        assertEquals(1, pageable.getPageNumber());
        assertEquals(5, pageable.getPageSize());

        verify(countryMapper).entityToDTOList(countries);
    }

    @Test
    void getCountries_shouldUseZeroPageNumberWhenStartIndexIsLessThanOne() {
        int startIndex = 0;
        int batchSize = 10;

        List<Country> countries = Collections.emptyList();
        Page<Country> countryPage = new PageImpl<>(countries);
        List<CountryDTO> countryDTOs = Collections.emptyList();

        when(countryRepository.findAll(org.mockito.ArgumentMatchers.any(Pageable.class))).thenReturn(countryPage);
        when(countryMapper.entityToDTOList(countries)).thenReturn(countryDTOs);

        CountryResponseDTO response = countryService.getCountries(startIndex, batchSize);

        assertNotNull(response);
        assertEquals(countryDTOs, response.getData());
        assertEquals(0L, response.getMetadata().getTotalSize());
        assertEquals(startIndex, response.getMetadata().getStartIndex());
        assertEquals(batchSize, response.getMetadata().getBatchSize());
        assertEquals("/country/?startIndex=0&batchSize=10", response.getMetadata().getLink());

        verify(countryRepository).findAll(pageableCaptor.capture());
        Pageable pageable = pageableCaptor.getValue();
        assertEquals(0, pageable.getPageNumber());
        assertEquals(10, pageable.getPageSize());

        verify(countryMapper).entityToDTOList(countries);
    }

    @Test
    void getCountryRegions_shouldReturnResponseWithMappedDataAndMetadata() {
        int countryId = 101;
        int startIndex = 3;
        int batchSize = 4;

        CountryRegion countryRegion = new CountryRegion();
        List<CountryRegion> regions = List.of(countryRegion);
        Page<CountryRegion> regionPage = new PageImpl<>(regions);
        CountryRegionDTO regionDTO = CountryRegionDTO.builder().build();
        List<CountryRegionDTO> regionDTOs = List.of(regionDTO);

        when(countryRegionRepository.findByCountryId(org.mockito.ArgumentMatchers.eq(countryId),
                org.mockito.ArgumentMatchers.any(Pageable.class))).thenReturn(regionPage);
        when(countryMapper.entityToRegionDTOList(regions)).thenReturn(regionDTOs);

        CountryRegionResponseDTO response = countryService.getCountryRegions(countryId, startIndex, batchSize);

        assertNotNull(response);
        assertEquals(regionDTOs, response.getData());
        assertNotNull(response.getMetadata());
        assertEquals(1L, response.getMetadata().getTotalSize());
        assertEquals(startIndex, response.getMetadata().getStartIndex());
        assertEquals(batchSize, response.getMetadata().getBatchSize());
        assertEquals("/country_region?countryId=101&batchSize=4&startIndex=3", response.getMetadata().getLink());

        verify(countryRegionRepository).findByCountryId(org.mockito.ArgumentMatchers.eq(countryId), pageableCaptor.capture());
        Pageable pageable = pageableCaptor.getValue();
        assertEquals(2, pageable.getPageNumber());
        assertEquals(4, pageable.getPageSize());

        verify(countryMapper).entityToRegionDTOList(regions);
    }

    @Test
    void getCountryRegions_shouldUseZeroPageNumberWhenStartIndexIsNegative() {
        int countryId = 999;
        int startIndex = -1;
        int batchSize = 6;

        List<CountryRegion> regions = Collections.emptyList();
        Page<CountryRegion> regionPage = new PageImpl<>(regions);
        List<CountryRegionDTO> regionDTOs = Collections.emptyList();

        when(countryRegionRepository.findByCountryId(org.mockito.ArgumentMatchers.eq(countryId),
                org.mockito.ArgumentMatchers.any(Pageable.class))).thenReturn(regionPage);
        when(countryMapper.entityToRegionDTOList(regions)).thenReturn(regionDTOs);

        CountryRegionResponseDTO response = countryService.getCountryRegions(countryId, startIndex, batchSize);

        assertNotNull(response);
        assertEquals(regionDTOs, response.getData());
        assertEquals(0L, response.getMetadata().getTotalSize());
        assertEquals(startIndex, response.getMetadata().getStartIndex());
        assertEquals(batchSize, response.getMetadata().getBatchSize());
        assertEquals("/country_region?countryId=999&batchSize=6&startIndex=-1", response.getMetadata().getLink());

        verify(countryRegionRepository).findByCountryId(org.mockito.ArgumentMatchers.eq(countryId), pageableCaptor.capture());
        Pageable pageable = pageableCaptor.getValue();
        assertEquals(0, pageable.getPageNumber());
        assertEquals(6, pageable.getPageSize());

        verify(countryMapper).entityToRegionDTOList(regions);
    }

    @Test
    void getLanguages_shouldReturnResponseWithMappedDataAndMetadata() {
        int startIndex = 4;
        int batchSize = 7;

        Language language = new Language();
        List<Language> languages = List.of(language);
        Page<Language> languagePage = new PageImpl<>(languages);
        LanguageDTO languageDTO = LanguageDTO.builder().build();
        List<LanguageDTO> languageDTOs = List.of(languageDTO);

        when(languageRepository.findAll(org.mockito.ArgumentMatchers.any(Pageable.class))).thenReturn(languagePage);
        when(languageMapper.entityToDTOList(languages)).thenReturn(languageDTOs);

        LanguageResponseDTO response = countryService.getLanguages(startIndex, batchSize);

        assertNotNull(response);
        assertEquals(languageDTOs, response.getData());
        assertNotNull(response.getMetadata());
        assertEquals(1L, response.getMetadata().getTotalSize());
        assertEquals(startIndex, response.getMetadata().getStartIndex());
        assertEquals(batchSize, response.getMetadata().getBatchSize());
        assertEquals("/language?startIndex=4&batchSize=7", response.getMetadata().getLink());

        verify(languageRepository).findAll(pageableCaptor.capture());
        Pageable pageable = pageableCaptor.getValue();
        assertEquals(3, pageable.getPageNumber());
        assertEquals(7, pageable.getPageSize());

        verify(languageMapper).entityToDTOList(languages);
    }

    @Test
    void getLanguages_shouldUseZeroPageNumberWhenStartIndexIsLessThanOne() {
        int startIndex = 0;
        int batchSize = 3;

        List<Language> languages = Collections.emptyList();
        Page<Language> languagePage = new PageImpl<>(languages);
        List<LanguageDTO> languageDTOs = Collections.emptyList();

        when(languageRepository.findAll(org.mockito.ArgumentMatchers.any(Pageable.class))).thenReturn(languagePage);
        when(languageMapper.entityToDTOList(languages)).thenReturn(languageDTOs);

        LanguageResponseDTO response = countryService.getLanguages(startIndex, batchSize);

        assertNotNull(response);
        assertEquals(languageDTOs, response.getData());
        assertEquals(0L, response.getMetadata().getTotalSize());
        assertEquals(startIndex, response.getMetadata().getStartIndex());
        assertEquals(batchSize, response.getMetadata().getBatchSize());
        assertEquals("/language?startIndex=0&batchSize=3", response.getMetadata().getLink());

        verify(languageRepository).findAll(pageableCaptor.capture());
        Pageable pageable = pageableCaptor.getValue();
        assertEquals(0, pageable.getPageNumber());
        assertEquals(3, pageable.getPageSize());

        verify(languageMapper).entityToDTOList(languages);
    }
}