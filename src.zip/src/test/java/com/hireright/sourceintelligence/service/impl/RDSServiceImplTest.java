package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.rds.VendorResponseDTO;
import com.hireright.sourceintelligence.api.dto.rds.VendorsDTO;
import com.hireright.sourceintelligence.domain.entity.Vendors;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.RDSMapper;
import com.hireright.sourceintelligence.domain.repository.VendorsRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class RDSServiceImplTest {

    @Mock
    private VendorsRepository vendorsRepository;

    @Mock
    private RDSMapper rdsMapper;

    @InjectMocks
    private RDSServiceImpl rdsService;

    private AutoCloseable closeable;

    @BeforeEach
    void setUp() {
        closeable = MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetVendorList() {
        // Arrange
        Vendors eduVendor = new Vendors();
        Vendors empVendor = new Vendors();

        VendorsDTO eduDTO = new VendorsDTO();
        VendorsDTO empDTO = new VendorsDTO();

        List<Vendors> educationVendors = List.of(eduVendor);
        List<Vendors> employmentVendors = List.of(empVendor);

        List<VendorsDTO> mappedEducation = List.of(eduDTO);
        List<VendorsDTO> mappedEmployment = List.of(empDTO);

        when(vendorsRepository.findByOrganizationTypeOrderByVendorAsc(OrganizationType.EDUCATION.getType())).thenReturn(educationVendors);
        when(vendorsRepository.findByOrganizationTypeOrderByVendorAsc(OrganizationType.EMPLOYMENT.getType())).thenReturn(employmentVendors);
        when(rdsMapper.toVendorsDTOList(educationVendors)).thenReturn(mappedEducation);
        when(rdsMapper.toVendorsDTOList(employmentVendors)).thenReturn(mappedEmployment);

        // Act
        VendorResponseDTO response = rdsService.getVendorList();

        // Assert

        assertEquals(mappedEducation, response.getEducation());
        assertEquals(mappedEmployment, response.getEmployment());

        verify(vendorsRepository, times(1)).findByOrganizationTypeOrderByVendorAsc(OrganizationType.EDUCATION.getType());
        verify(vendorsRepository, times(1)).findByOrganizationTypeOrderByVendorAsc(OrganizationType.EMPLOYMENT.getType());
        verify(rdsMapper, times(2)).toVendorsDTOList(anyList());

    }
}
