package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchMapper;
import com.mongodb.BasicDBObject;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class ElasticsearchMapperTest {

    private ElasticsearchMapper elasticsearchMapper;

    @BeforeEach
    void setUp() {
        elasticsearchMapper = new ElasticsearchMapper();
    }

    @Test
    void testSourceToSearchSourceMapping_WithApprovedSource_ShouldMapBasicFields() {
        Source source = new Source();
        source.setApprovalStatus(ApprovalStatus.APPROVED);
        source.setHon("HON123");
        source.setOrganizationName("Test Org");
        source.setCountry("USA");
        source.setState("California");
        source.setCity("San Francisco");
        source.setPostalCode("94107");
        source.setStatus(SourceOrganizationStatus.ACTIVE);

        JSONObject payloadJson = new JSONObject();
        payloadJson.put("departmentName", "Engineering");
        payloadJson.put("website", "https://test.org");

        JSONArray addressArray = new JSONArray();
        JSONObject address = new JSONObject();
        address.put("line", "123 Market St");
        addressArray.put(address);
        payloadJson.put("address", addressArray);

        BasicDBObject payload = BasicDBObject.parse(payloadJson.toString());
        source.setPayload(payload);

        ElasticsearchSource result = elasticsearchMapper.sourceToSearchSourceMapping(source);

        assertNotNull(result);
        assertEquals("HON123", result.getHon());
        assertEquals("Test Org", result.getOrganizationName());
        assertEquals("California", result.getState());
        assertEquals("san francisco", result.getCity());
        assertEquals("94107", result.getPostalCode());
        assertEquals("ACTIVE", result.getStatus());
        assertEquals("Engineering", result.getDepartment());
        assertEquals("https://test.org", result.getWebsite());
        assertEquals("123 Market St", result.getAddressLine());
    }

    @Test
    void testSourceToSearchSourceMapping_WithAliasesAndTrimmedValues() {
        Source source = new Source();
        source.setApprovalStatus(ApprovalStatus.APPROVED);
        source.setHon(" HON123 ");
        source.setOrganizationName(" Org Inc ");
        source.setCountry(" USA ");
        source.setState(" California ");
        source.setCity("  New York ");
        source.setPostalCode(" 10001 ");
        source.setStatus(SourceOrganizationStatus.ACTIVE);

        Alias alias1 = new Alias(" Alias1 ", "en");
        Alias alias2 = new Alias(" Alias2 ", "en");
        source.setOrganizationAlias(new Alias[]{alias1, alias2});

        JSONObject payloadJson = new JSONObject();
        payloadJson.put("departmentName", " Engineering ");
        payloadJson.put("website", " WWW.EXAMPLE.COM ");
        payloadJson.put("address", new JSONArray().put(new JSONObject().put("line", " 123 Elm Street ")));

        source.setPayload(BasicDBObject.parse(payloadJson.toString()));

        ElasticsearchSource result = elasticsearchMapper.sourceToSearchSourceMapping(source);

        assertEquals(List.of("Alias1", "Alias2"), result.getOrganizationAlias());
        assertEquals("new york", result.getCity());
        assertEquals("engineering", result.getDepartment().toLowerCase());
        assertEquals("www.example.com", result.getWebsite());
        assertEquals("123 Elm Street", result.getAddressLine());
    }


    @Test
    void testSourceToSearchSourceMapping_WithFullContactInfo() {
        Source source = new Source();
        source.setApprovalStatus(ApprovalStatus.APPROVED);
        source.setHon("HON456");
        source.setOrganizationName("TestOrg");
        source.setCountry("India");
        source.setStatus(SourceOrganizationStatus.ACTIVE);

        JSONObject phoneCommInfo = new JSONObject()
                .put("type", "phoneNumber").put("value", "123456789");
        JSONObject phoneComm = new JSONObject()
                .put("communicationInfo", new JSONArray().put(phoneCommInfo));
        JSONObject phoneContact = new JSONObject()
                .put("type", "contactPhones")
                .put("communication", new JSONArray().put(phoneComm));

        JSONObject emailCommInfo = new JSONObject()
                .put("type", "address").put("value", "test@example.com");
        JSONObject emailComm = new JSONObject()
                .put("communicationInfo", new JSONArray().put(emailCommInfo));
        JSONObject emailContact = new JSONObject()
                .put("type", "contactEmails")
                .put("communication", new JSONArray().put(emailComm));

        JSONObject contactDetails = new JSONObject()
                .put("contactDetails", new JSONArray().put(phoneContact).put(emailContact));
        JSONArray contactsArray = new JSONArray().put(contactDetails);

        JSONObject payload = new JSONObject();
        payload.put("contacts", contactsArray);

        source.setPayload(BasicDBObject.parse(payload.toString()));

        ElasticsearchSource result = elasticsearchMapper.sourceToSearchSourceMapping(source);

        assertNotNull(result.getPhoneNumber());
        assertNotNull(result.getEmail());
        assertTrue(result.getEmail().get(0).contains("test@example.com"));
    }

    @Test
    void testSourceToSearchSourceMapping_withEmailContact() {
        Source source = getBasicApprovedSource();
        JSONObject payload = buildEmailPayload("john@example.com");
        source.setPayload(BasicDBObject.parse(payload.toString()));

        ElasticsearchSource result = elasticsearchMapper.sourceToSearchSourceMapping(source);
        assertEquals(List.of("john@example.com"), result.getEmail());
    }

    @Test
    void testSourceToSearchSourceMapping_withFaxWithoutExtension() {
        Source source = getBasicApprovedSource();
        JSONObject payload = buildCommunicationPayload("contactFaxes", "456", "91", "80", "");
        source.setPayload(BasicDBObject.parse(payload.toString()));

        ElasticsearchSource result = elasticsearchMapper.sourceToSearchSourceMapping(source);

        assertNotNull(result.getFaxNumber(), "Fax list should not be null");
        assertFalse(result.getFaxNumber().isEmpty(), "Fax list should not be empty");
        String withCc = "+9180456";
        String noCc  = "+80456";

        boolean matches = result.getFaxNumber().stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .anyMatch(f ->
                        f.equals(withCc) || f.startsWith(withCc + ":") ||
                                f.equals(noCc)  || f.startsWith(noCc  + ":")
                );

        assertTrue(matches, "Expected a fax like +9180456 or +80456 (optionally with :extension), but got: " + result.getFaxNumber());
    }

    @Test
    void testSourceToSearchSourceMapping_withPhoneExtension() {
        Source source = getBasicApprovedSource();
        JSONObject payload = buildCommunicationPayload("contactPhones", "123", "91", "80", "1001");
        source.setPayload(BasicDBObject.parse(payload.toString()));

        ElasticsearchSource result = elasticsearchMapper.sourceToSearchSourceMapping(source);
        assertNotNull(result.getPhoneNumber());
        assertTrue(result.getPhoneNumber().get(1).contains(":1001"));
    }

    @Test
    void testSourceToSearchSourceMapping_withEmptyContactsArray() {
        Source source = getBasicApprovedSource();
        JSONObject payload = new JSONObject();
        payload.put("contacts", new JSONArray());
        source.setPayload(BasicDBObject.parse(payload.toString()));

        ElasticsearchSource result = elasticsearchMapper.sourceToSearchSourceMapping(source);
        assertNull(result.getPhoneNumber());
        assertNull(result.getEmail());
    }
    @Test
    void testSourceToSearchSourceMapping_withEmptyAddressLine() {
        Source source = getBasicApprovedSource();
        JSONObject payload = new JSONObject();
        JSONArray addressArray = new JSONArray();
        JSONObject address = new JSONObject();
        address.put("line", "");
        addressArray.put(address);
        payload.put("address", addressArray);
        source.setPayload(BasicDBObject.parse(payload.toString()));
        ElasticsearchSource result = elasticsearchMapper.sourceToSearchSourceMapping(source);
        assertEquals("", result.getAddressLine());
    }


    @Test
    void testSourceToSearchSourceMapping_withEmptyAliasNames() {
        Source source = getBasicApprovedSource();
        Alias[] aliases = {new Alias(null, "en"), new Alias("", "en")};
        source.setOrganizationAlias(aliases);
        JSONObject emptyPayload = new JSONObject();
        source.setPayload(BasicDBObject.parse(emptyPayload.toString()));

        ElasticsearchSource result = elasticsearchMapper.sourceToSearchSourceMapping(source);

        assertNotNull(result.getOrganizationAlias());
        assertTrue(result.getOrganizationAlias().isEmpty());
    }


    @Test
    void testSourceToSearchSourceMapping_WithNonApprovedSource_ShouldReturnEmpty() {
        Source source = new Source();
        source.setApprovalStatus(ApprovalStatus.REJECTED);

        ElasticsearchSource result = elasticsearchMapper.sourceToSearchSourceMapping(source);

        assertNotNull(result);
        assertNull(result.getHon());
        assertNull(result.getOrganizationName());
        assertNull(result.getCity());
    }
    private Source getBasicApprovedSource() {
        Source source = new Source();
        source.setApprovalStatus(ApprovalStatus.APPROVED);
        source.setHon("HON123");
        source.setOrganizationName("TestOrg");
        source.setCountry("USA");
        source.setStatus(SourceOrganizationStatus.ACTIVE);
        return source;
    }
    private JSONObject buildCommunicationPayload(String contactType, String number, String countryCode, String areaCode, String extension) {
        JSONObject info1 = new JSONObject().put("type", "phoneNumber").put("value", number);
        JSONObject info2 = new JSONObject().put("type", "phoneCountryCode").put("value", countryCode);
        JSONObject info3 = new JSONObject().put("type", "areaCode").put("value", areaCode);
        JSONObject info4 = new JSONObject().put("type", "extension").put("value", extension);

        JSONArray infoArray = new JSONArray(List.of(info1, info2, info3, info4));
        JSONObject comm = new JSONObject().put("communicationInfo", infoArray);
        JSONArray commArray = new JSONArray(List.of(comm));

        JSONObject contactDetail = new JSONObject().put("type", contactType).put("communication", commArray);
        JSONArray contactDetails = new JSONArray(List.of(contactDetail));
        JSONObject contact = new JSONObject().put("contactDetails", contactDetails);
        JSONArray contacts = new JSONArray(List.of(contact));

        JSONObject payload = new JSONObject();
        payload.put("contacts", contacts);
        return payload;
    }
    private JSONObject buildEmailPayload(String email) {
        JSONObject info = new JSONObject().put("type", "address").put("value", email);
        JSONArray infoArray = new JSONArray(List.of(info));
        JSONObject comm = new JSONObject().put("communicationInfo", infoArray);
        JSONArray commArray = new JSONArray(List.of(comm));

        JSONObject contactDetail = new JSONObject().put("type", "contactEmails").put("communication", commArray);
        JSONArray contactDetails = new JSONArray(List.of(contactDetail));
        JSONObject contact = new JSONObject().put("contactDetails", contactDetails);
        JSONArray contacts = new JSONArray(List.of(contact));

        JSONObject payload = new JSONObject();
        payload.put("contacts", contacts);
        return payload;
    }

}