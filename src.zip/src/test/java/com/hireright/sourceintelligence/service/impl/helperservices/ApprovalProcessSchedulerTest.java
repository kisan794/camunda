package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.constants.ApplicationConstants;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.service.impl.MongoSearchService;
import com.hireright.sourceintelligence.service.impl.MongoSourceService;
import com.hireright.sourceintelligence.util.Helper;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static com.hireright.sourceintelligence.service.impl.SearchConstants.ReportActions.AUTO_REJECTED;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ReportActions.ON_HOLD_AUTO_REJECTED;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApprovalProcessSchedulerTest {

    @Mock
    private MongoSearchService mongoSearchService;

    @Mock
    private MongoSourceService mongoSourceService;
    @Mock
    private ReportDataUtils reportDataUtils;

    @InjectMocks
    private ApprovalProcessScheduler scheduler;

    @Captor
    private ArgumentCaptor<Source> sourceCaptor;

    private String eduOrgType;
    private String empOrgType;

    @BeforeEach
    void setUp() {
        eduOrgType = ApplicationConstants.EDUCATION_COLLECTION_PREFIX + ApplicationConstants.SOURCE_COLLECTION_SUFFIX;
        empOrgType = ApplicationConstants.EMPLOYMENT_COLLECTION_PREFIX + ApplicationConstants.SOURCE_COLLECTION_SUFFIX;
        lenient().doNothing().when(reportDataUtils).reportData(
                any(Source.class),
                nullable(String.class),
                anyString(),
                anyInt(),
                anyString(),
                anyDouble(),
                anyDouble(),
                anyString()
        );
    }
    @Test
    void runInProgressSources_whenNoResults_shouldNotUpdateOrInsertOrReport() {
        when(mongoSearchService.findAllSourcesWithInProgress(anyString()))
                .thenReturn(Collections.emptyList());

        scheduler.runInProgressSources();
        verify(mongoSearchService, times(2)).findAllSourcesWithInProgress(anyString());

        verifyNoInteractions(mongoSourceService);
        verifyNoInteractions(reportDataUtils);
    }

    @Test
    void runInProgressSources_whenPendingExists_shouldRejectUpdateInsertAndReport() {
        Source eduSource = new Source();
        eduSource.setHon(ApplicationConstants.HON_EDUCATION_PREFIX + "123");
        eduSource.setId(new ObjectId());

        Source empSource = new Source();
        empSource.setHon(ApplicationConstants.HON_EMPLOYMENT_PREFIX + "123");
        empSource.setId(new ObjectId());
        when(mongoSearchService.findAllSourcesWithInProgress(eduOrgType))
                .thenReturn(List.of(eduSource));
        when(mongoSearchService.findAllSourcesWithInProgress(empOrgType))
                .thenReturn(List.of(empSource));

        when(mongoSourceService.findSourceByHonAndApprovalStatuses(anyString(), anyList()))
                .thenReturn(new Source());

        scheduler.runInProgressSources();

        verify(mongoSourceService, times(2)).updateById(sourceCaptor.capture(), anyString());
        for (Source s : sourceCaptor.getAllValues()) {
            assertEquals(ApplicationConstants.UNASSIGNED, s.getAssignedId());
            assertEquals(ApplicationConstants.UNASSIGNED, s.getAssignedTo());
            assertEquals(ApprovalStatus.REJECTED, s.getApprovalStatus());
            assertEquals("Rejected by Scheduler", s.getSystemComments());
            assertEquals(SourceOrganizationStatus.INACTIVE, s.getStatus());
        }

        String eduHistory = Helper.getCollectionName(
                eduSource.getHon(), ApplicationConstants.SOURCE_HISTORY_COLLECTION_SUFFIX);
        String empHistory = Helper.getCollectionName(
                empSource.getHon(), ApplicationConstants.SOURCE_HISTORY_COLLECTION_SUFFIX);

        verify(mongoSourceService).insert(same(eduSource), eq(eduHistory));
        verify(mongoSourceService).insert(same(empSource), eq(empHistory));

        verify(reportDataUtils, times(2)).reportData(
                any(Source.class),
                nullable(String.class),
                eq(ApplicationConstants.SIDB_APPROVAL_FLOW),
                eq(0),
                eq(AUTO_REJECTED),
                anyDouble(),
                anyDouble(),
                eq(ApplicationConstants.APPROVAL_FLOW)
        );
    }

    @Test
    void runInProgressSources_whenNoPending_shouldOnlySetCommonFields_updateInsertAndReport() {
        Source eduSource = new Source();
        eduSource.setHon(ApplicationConstants.HON_EDUCATION_PREFIX + "555");
        eduSource.setId(new ObjectId());

        Source empSource = new Source();
        empSource.setHon(ApplicationConstants.HON_EMPLOYMENT_PREFIX + "555");
        empSource.setId(new ObjectId());
        when(mongoSearchService.findAllSourcesWithInProgress(eduOrgType))
                .thenReturn(List.of(eduSource));
        when(mongoSearchService.findAllSourcesWithInProgress(empOrgType))
                .thenReturn(List.of(empSource));

        when(mongoSourceService.findSourceByHonAndApprovalStatuses(anyString(), anyList()))
                .thenReturn(null);

        scheduler.runInProgressSources();

        verify(mongoSourceService, times(2)).updateById(sourceCaptor.capture(), anyString());
        for (Source s : sourceCaptor.getAllValues()) {
            assertEquals(ApprovalStatus.PENDING_APPROVAL, s.getApprovalStatus());
            assertEquals(ApplicationConstants.UNASSIGNED, s.getAssignedId());
            assertEquals(ApplicationConstants.UNASSIGNED, s.getAssignedTo());
            assertNotEquals(ApprovalStatus.REJECTED, s.getApprovalStatus());
            assertNull(s.getSystemComments());
        }

        verify(reportDataUtils, times(2)).reportData(
                any(Source.class),
                nullable(String.class),
                eq(ApplicationConstants.SIDB_APPROVAL_FLOW),
                eq(0),
                eq(AUTO_REJECTED),
                anyDouble(),
                anyDouble(),
                eq(ApplicationConstants.APPROVAL_FLOW)
        );
    }

    @Test
    void runOnHoldTask_whenNoResults_shouldNotUpdateOrInsertOrReport() {
        when(mongoSearchService.findAllSourcesWithOnHold(anyString()))
                .thenReturn(Collections.emptyList());

        scheduler.runOnHoldTask();

        verify(mongoSearchService, times(2)).findAllSourcesWithOnHold(anyString());
        verifyNoInteractions(mongoSourceService);
        verifyNoInteractions(reportDataUtils);
    }

    @Test
    void runOnHoldTask_whenPendingExists_shouldRejectAndPersist() {
        Source eduSource = new Source();
        eduSource.setHon(ApplicationConstants.HON_EDUCATION_PREFIX + "123");
        eduSource.setId(new ObjectId());

        Source empSource = new Source();
        empSource.setHon(ApplicationConstants.HON_EMPLOYMENT_PREFIX + "123");
        empSource.setId(new ObjectId());


        when(mongoSearchService.findAllSourcesWithOnHold(eduOrgType))
                .thenReturn(List.of(eduSource));
        when(mongoSearchService.findAllSourcesWithOnHold(empOrgType))
                .thenReturn(List.of(empSource));

        when(mongoSourceService.findSourceByHonAndApprovalStatuses(anyString(), anyList()))
                .thenReturn(new Source());

        scheduler.runOnHoldTask();

        verify(mongoSourceService, times(2)).updateById(sourceCaptor.capture(), anyString());
        for (Source s : sourceCaptor.getAllValues()) {
            assertEquals(ApprovalStatus.REJECTED, s.getApprovalStatus());
            assertEquals("Rejected by Scheduler", s.getSystemComments());
            assertEquals(SourceOrganizationStatus.INACTIVE, s.getStatus());

            assertEquals(ApplicationConstants.UNASSIGNED, s.getAssignedId());
            assertEquals(ApplicationConstants.UNASSIGNED, s.getAssignedTo());
        }

        String eduHistory = Helper.getCollectionName(
                eduSource.getHon(), ApplicationConstants.SOURCE_HISTORY_COLLECTION_SUFFIX);
        String empHistory = Helper.getCollectionName(
                empSource.getHon(), ApplicationConstants.SOURCE_HISTORY_COLLECTION_SUFFIX);

        verify(mongoSourceService).insert(same(eduSource), eq(eduHistory));
        verify(mongoSourceService).insert(same(empSource), eq(empHistory));

        verify(reportDataUtils, times(2)).reportData(
                any(Source.class),
                nullable(String.class),
                eq(ApplicationConstants.SIDB_APPROVAL_FLOW),
                eq(0),
                eq(ON_HOLD_AUTO_REJECTED),
                anyDouble(),
                anyDouble(),
                eq(ApplicationConstants.APPROVAL_FLOW)
        );
    }

    @Test
    void runOnHoldTask_whenNoPending_shouldOnlySetCommonFields_updateInsertAndReport() {
        Source eduSource = new Source();
        eduSource.setHon(ApplicationConstants.HON_EDUCATION_PREFIX + "777");
        eduSource.setId(new ObjectId());

        Source empSource = new Source();
        empSource.setHon(ApplicationConstants.HON_EMPLOYMENT_PREFIX + "777");
        empSource.setId(new ObjectId());

        when(mongoSearchService.findAllSourcesWithOnHold(eduOrgType))
                .thenReturn(List.of(eduSource));
        when(mongoSearchService.findAllSourcesWithOnHold(empOrgType))
                .thenReturn(List.of(empSource));

        when(mongoSourceService.findSourceByHonAndApprovalStatuses(anyString(), anyList()))
                .thenReturn(null);

        scheduler.runOnHoldTask();

        verify(mongoSourceService, times(2)).updateById(sourceCaptor.capture(), anyString());
        for (Source s : sourceCaptor.getAllValues()) {
            assertEquals(ApprovalStatus.PENDING_APPROVAL, s.getApprovalStatus());
            assertEquals(ApplicationConstants.UNASSIGNED, s.getAssignedId());
            assertEquals(ApplicationConstants.UNASSIGNED, s.getAssignedTo());
            assertNull(s.getSystemComments());
        }

        verify(reportDataUtils, times(2)).reportData(
                any(Source.class),
                nullable(String.class),
                eq(ApplicationConstants.SIDB_APPROVAL_FLOW),
                eq(0),
                eq(ON_HOLD_AUTO_REJECTED),
                anyDouble(),
                anyDouble(),
                eq(ApplicationConstants.APPROVAL_FLOW)
        );
    }

    @Test
    void lombokGeneratedMethods_shouldBeCovered() {
        assertSame(mongoSearchService, scheduler.getMongoSearchService());
        assertSame(mongoSourceService, scheduler.getMongoSourceService());
        assertSame(reportDataUtils, scheduler.getReportDataUtils());
        MongoSearchService otherSearch = mock(MongoSearchService.class);
        MongoSourceService otherSource = mock(MongoSourceService.class);
        ReportDataUtils otherReport = mock(ReportDataUtils.class);

        scheduler.setMongoSearchService(otherSearch);
        scheduler.setMongoSourceService(otherSource);
        scheduler.setReportDataUtils(otherReport);

        assertSame(otherSearch, scheduler.getMongoSearchService());
        assertSame(otherSource, scheduler.getMongoSourceService());
        assertSame(otherReport, scheduler.getReportDataUtils());
        ApprovalProcessScheduler s1 =
                new ApprovalProcessScheduler(otherSearch, otherSource, otherReport);
        ApprovalProcessScheduler s2 =
                new ApprovalProcessScheduler(otherSearch, otherSource, otherReport);

        assertTrue(s1.canEqual(s2));
        assertEquals(s1, s2);
        assertEquals(s1.hashCode(), s2.hashCode());
        assertNotEquals(null, s1);
        assertNotEquals("not-a-scheduler", s1);
        s2.setMongoSearchService(mock(MongoSearchService.class));
        assertNotEquals(s1, s2);
        String ts = s1.toString();
        assertNotNull(ts);
        assertTrue(ts.contains("ApprovalProcessScheduler"),
                "toString should contain class name");
    }
}