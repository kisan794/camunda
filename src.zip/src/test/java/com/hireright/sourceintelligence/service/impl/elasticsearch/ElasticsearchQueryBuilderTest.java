package com.hireright.sourceintelligence.service.impl.elasticsearch;

import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.ElasticsearchDTO;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ElasticsearchQueryBuilderTest {

    @Test
    void testSmartSearchQuery_withMustAndShould() {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setCountry("USA");
        dto.setCity("New York");
        dto.setOrganizationName("Test Org");
        dto.setApprovalStatus("APPROVED");
        dto.setDepartment("Engineering");
        dto.setAddressLine("123 Test St");
        dto.setPhoneNumber("1234567890");

        var query = ElasticsearchQueryBuilder.smartSearchQuery(dto, false);
        assertNotNull(query);
        assertThat(query.toString()).contains("USA", "new york", "Test Org", "Engineering", "123 Test St");
    }


    @Test
    void testSmartSearchQuery_onlyMust() {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setCountry("USA");

        var query = ElasticsearchQueryBuilder.smartSearchQuery(dto, false);
        assertNotNull(query);
        assertThat(query.toString()).contains("USA");
    }

    @Test
    void testSmartSearchQuery_onlyShould() {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setOrganizationName("Only Org");

        var query = ElasticsearchQueryBuilder.smartSearchQuery(dto, true);
        assertNotNull(query);
        assertThat(query.toString()).contains("Only Org");
    }

    @Test
    void testSmartSearchQuery_nullResult() {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        var query = ElasticsearchQueryBuilder.smartSearchQuery(dto, false);
        assertThat(query).isNull();
    }

    @Test
    void testDropDownSearchQuery_basic() {
        ElasticsearchDTO dto = new ElasticsearchDTO();
        dto.setOrganizationName("Dropdown Org");

        var query = ElasticsearchQueryBuilder.dropDownSearchQuery(dto);
        assertNotNull(query);
        assertThat(query.toString()).contains("Dropdown Org");
    }

    @Test
    void testAutoMatchQuery_US() {
        AutoMatchDTO dto = new AutoMatchDTO();
        dto.setCountry("USA");
        dto.setSourceType("EDUCATION");
        dto.setState("CA");
        dto.setCity("San Jose");
        dto.setSourceName("US Org");

        var query = ElasticsearchQueryBuilder.autoMatchQuery(dto);
        assertNotNull(query);
        assertThat(query.toString()).contains("USA", "san jose", "US Org");
    }


    @Test
    void testAutoMatchQuery_EMEA() {
        AutoMatchDTO dto = new AutoMatchDTO();
        dto.setCountry("Germany");
        dto.setSourceType("EDUCATION");
        dto.setState("Berlin");
        dto.setCity("Berlin");
        dto.setSourceName("EMEA Org");

        var query = ElasticsearchQueryBuilder.nonUSAutoMatchQuery(dto);
        assertNotNull(query);
        assertThat(query.toString()).contains("Germany", "EMEA Org");
    }

    @Test
    void testAutoMatchQuery_noSourceName() {
        AutoMatchDTO dto = new AutoMatchDTO();
        dto.setCountry("India");
        dto.setSourceType("EMPLOYMENT");
        dto.setState("Delhi");
        dto.setCity("Delhi");
        var query = ElasticsearchQueryBuilder.nonUSAutoMatchQuery(dto);
        assertNotNull(query);
        assertThat(query.toString()).contains("India");
    }
}
