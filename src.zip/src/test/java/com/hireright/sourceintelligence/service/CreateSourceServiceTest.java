package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.CycleResult;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.UIActionsDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.service.impl.MongoSourceService;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.service.impl.helperservices.*;

import com.mongodb.DBObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.util.ReflectionTestUtils;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.ACTION_SAVE;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.AUTO_APPOVED;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.APPROVED;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.PENDING_APPROVAL;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CreateSourceServiceTest {

    @InjectMocks
    private CreateSourceService createSourceService;

    @Mock
    private SourceMapper sourceMapper;
    @Mock
    private MongoSourceService mongoSourceService;
    @Mock
    private ReportDataUtils reportDataUtils;
    @Mock
    private CountryRegionMappingUtils countryRegionMappingUtils;
    @Mock
    private ElasticsearchService elasticsearchService;
    @Mock
    private SourceUtils sourceUtils;

    private SourceOrganizationDTO sourceOrganizationDTO;
    private UIActionsDTO uiActionsDTO;
    private Source source;

    @BeforeEach
    void setUp() {
        sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setOrganizationType(OrganizationType.EDUCATION);
        sourceOrganizationDTO.setOrganizationName("TestOrg");
        sourceOrganizationDTO.setCountry("USA");
        sourceOrganizationDTO.setRegion("US");

        uiActionsDTO = new UIActionsDTO();
        uiActionsDTO.setUserAction("save");
        uiActionsDTO.setUserName("testUser");
        uiActionsDTO.setUserEmail("test@user.com");
        uiActionsDTO.setUserTrustScore(100);

        source = new Source();
        source.setOrganizationName("TestOrg");
        source.setOrganizationType(OrganizationType.EDUCATION);
        source.setPayload(mock(DBObject.class));
    }

    @Test
    void testCreateSource_RegionNotFound_ThrowsException() {
        lenient().when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);
        lenient().when(mongoSourceService.isHonExists(anyString())).thenReturn(false);
        lenient().when(mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO)).thenReturn(null);
        lenient().when(countryRegionMappingUtils.getRegionByCountry("USA")).thenReturn("US");
        lenient().when(sourceUtils.isEligibleForAutoApproval(100, "US")).thenReturn(false);

        sourceOrganizationDTO.setRegion(null);

        assertThrows(RuntimeException.class, () ->
                createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO));
    }

    @Test
    void testCreateSource_saveAndUse_shouldSetUsedCountAndLastUsedDate() throws Exception {
        uiActionsDTO.setUserAction("Save And Use");
        uiActionsDTO.setUserTrustScore(90);
        uiActionsDTO.setUserEmail("test@example.com");
        uiActionsDTO.setUserName("TestUser");

        sourceOrganizationDTO.setOrganizationAlias(new Alias[]{});
        ReflectionTestUtils.setField(createSourceService, "shardLocation", "US");

        DBObject payload = mock(DBObject.class);
        source.setPayload(payload);

        Source insertedSource = new Source();
        insertedSource.setApprovalStatus(APPROVED);
        insertedSource.setPayload(mock(DBObject.class));
        insertedSource.setOrganizationType(OrganizationType.EDUCATION);
        insertedSource.setOrganizationName("TestOrg");
        insertedSource.setVersion(1);
        insertedSource.setTempVersion(0);

        when(sourceMapper.dtoToEntitySource(any())).thenReturn(source);
        when(mongoSourceService.isHonExists(anyString())).thenReturn(false);
        when(mongoSourceService.getPossibleDuplicateSources(any())).thenReturn(null);
        when(countryRegionMappingUtils.getRegionByCountry(anyString())).thenReturn("US");
        when(sourceUtils.checkForAutoApproval(anyInt(), anyString(), anyString()))
                .thenReturn(new CycleResult(AUTO_APPOVED, null));
        when(mongoSourceService.insert(any(), anyString())).thenReturn(insertedSource);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(sourceOrganizationDTO);

        createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO);
        verify(reportDataUtils).reportData(
                any(),
                eq("Create"),
                any(),
                eq(0),
                any(),
                anyDouble(),
                anyDouble(),
                any()
        );

        verify(reportDataUtils, never()).reportData(
                any(),
                eq("UsedCount"),
                any(),
                anyInt(),
                any(),
                anyDouble(),
                anyDouble(),
                any()
        );

    }


    @Test
    void testCreateSource_shouldCreateSource_withoutAutoApproval() throws Exception {
        uiActionsDTO.setUserAction(ACTION_SAVE);
        uiActionsDTO.setUserTrustScore(50);
        uiActionsDTO.setUserEmail("test@example.com");
        uiActionsDTO.setUserName("TestUser");

        ReflectionTestUtils.setField(createSourceService, "shardLocation", "US");

        sourceOrganizationDTO.setOrganizationAlias(new Alias[]{});
        sourceOrganizationDTO.setOrganizationType(OrganizationType.EDUCATION);
        sourceOrganizationDTO.setOrganizationName("TestOrg");
        sourceOrganizationDTO.setCountry("US");
        sourceOrganizationDTO.setRegion("US");

        Source orgEntity = new Source();
        orgEntity.setOrganizationType(OrganizationType.EDUCATION);
        orgEntity.setOrganizationName("TestOrg");
        orgEntity.setPayload(new com.mongodb.BasicDBObject());

        when(sourceMapper.dtoToEntitySource(any())).thenReturn(orgEntity);
        when(mongoSourceService.isHonExists(anyString())).thenReturn(false);
        when(mongoSourceService.getPossibleDuplicateSources(any())).thenReturn(null);
        when(countryRegionMappingUtils.getRegionByCountry(anyString())).thenReturn("US");
        when(sourceUtils.checkForAutoApproval(anyInt(), anyString(), anyString()))
                .thenReturn(new CycleResult("MANUAL_REVIEW", null));

        Source inserted = new Source();
        inserted.setApprovalStatus(PENDING_APPROVAL);
        inserted.setOrganizationType(OrganizationType.EDUCATION);
        inserted.setOrganizationName("TestOrg");
        inserted.setPayload(new com.mongodb.BasicDBObject());
        inserted.setVersion(0.0);
        inserted.setTempVersion(1.0);

        when(mongoSourceService.insert(any(), anyString())).thenReturn(inserted);
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(sourceOrganizationDTO);

        SourceOrganizationDTO result = createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO);

        assertNotNull(result);

        verify(reportDataUtils).reportData(
                any(),
                eq("Create"),
                any(),
                eq(0),
                any(),
                anyDouble(),
                anyDouble(),
                any()
        );

        verify(reportDataUtils, never()).reportData(
                any(),
                eq("UsedCount"),
                any(),
                anyInt(),
                any(),
                anyDouble(),
                anyDouble(),
                any()
        );
    }




    @Test
    void testCreateSource_DuplicateSource_ThrowsException() {
        SourceOrganizationDTO duplicateDTO = new SourceOrganizationDTO();
        duplicateDTO.setHon("duplicateHon");

        lenient().when(sourceMapper.dtoToEntitySource(sourceOrganizationDTO)).thenReturn(source);
        lenient().when(mongoSourceService.isHonExists(anyString())).thenReturn(false);
        lenient().when(mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO)).thenReturn(duplicateDTO);

        assertThrows(RuntimeException.class, () ->
                createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO));
    }


    @Test
    void testCreateSource_HonExists_ThrowsException() {
        lenient().when(mongoSourceService.isHonExists(anyString())).thenReturn(true);

        assertThrows(RuntimeException.class, () ->
                createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO));
    }
}