package com.hireright.sourceintelligence.service;
import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.entity.MongoSearchResult;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import com.hireright.sourceintelligence.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.service.impl.CommonSearchImpl;
import com.hireright.sourceintelligence.util.TestDataProvider;
import com.mongodb.BasicDBObject;
import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.*;

import static com.hireright.sourceintelligence.api.ApiConstants.HON;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CommonServiceImplTest {

    @InjectMocks
    private CommonSearchImpl commonSearchImpl;
    @Mock
    CustomSourceRepository<Source> customSourceRepository;
    @Mock
    private CommonUtilService commonUtilService;
//
//    @Mock
//    private SourceMapper sourceMapper;
//
//    @Mock
//    private SearchMapper searchMapper;

    @Test
    void getSourceOrganizationsByFiltersTest() {

        SearchDTO searchDTO = TestDataProvider.getSearchDTO();
        searchDTO.setOrganizationType(null);
        searchDTO.setSourceOrganizationStatus(null);
        searchDTO.setHon(null);

        Map<String, Set<String>> searchFilters = getSearchFilterForSourceHistoryList();
        List<ApprovalStatus> approvalStatuses = Arrays.stream(ApprovalStatus.values()).toList();

        when(customSourceRepository.customAggregate(any(), any(), any())).thenReturn(TestDataProvider.getMongoSearchHistoryResult());
        assertThatNoException().isThrownBy(()->commonSearchImpl.getSourceOrganizationsByFilters(searchDTO,searchFilters, approvalStatuses,"ASC","sort",""));

    }

    @Test
    void getSourceOrganizationsByFilters_Without_Sort_Test() {
        SearchDTO searchDTO = SearchDTO.builder().build();
        MongoSearchResult mongoSearchResult = new MongoSearchResult();
        when(customSourceRepository.customAggregate(any(), any(), any()))
                .thenReturn(mongoSearchResult);

        // Precompute args (S5778) with the correct types
        Map<String, Set<String>> searchFilters = new HashMap<>();
        List<ApprovalStatus> approvalStatuses = new ArrayList<>();
        String order = "";
        String sort = "";
        String collectionName = "";

        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> commonSearchImpl.getSourceOrganizationsByFilters(
                        searchDTO, searchFilters, approvalStatuses, order, sort, collectionName
                ));
    }

    @Test
    void getAutocompletedFilters_With_Organization_Alias_Name_Test() {

        Map<String,String> searchFilters = new HashMap<>();
        searchFilters.put("test","test");

        Alias[] orgAlias = new Alias[]{new Alias("Google", "en-US"), new Alias("Google.com", "en-US")};
        List<Source> sourceList = new ArrayList<>();
        Source sourceOrganization = new Source();
        sourceOrganization.setHon(TestDataProvider.getHon());
        sourceOrganization.setOrganizationName("google");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("California city" );
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("California");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);

        sourceOrganization.setPayload(BasicDBObject.parse("{\"lastModified\": \"2020-01-16T03:11:07+0200\"," +
                "\"country\": \"USA\",\"state\": \"New York\",\"created\": \"2020-01-16T03:11:07+0200\"," +
                "\"lastApproverClass\": \"OPERATOR\" ,\"usedCount\": 30}"));

        Document doc = new Document();
        doc.put("doNotContact","fieldName");
        List<Object> additionalInfo = new ArrayList<>();
        additionalInfo.add(doc);

        sourceOrganization.getPayload().put("addionalInfo", additionalInfo);

        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setPath(ORGANIZATION_NAME);
        highlightDTO.setScore(Float.parseFloat("2.000"));
        highlightDTO.setTexts(List.of(new HitText("hit", "google")));
        sourceOrganization.setHighlight(List.of(highlightDTO));

        sourceList.add(sourceOrganization);
        sourceOrganization.setOrganizationType(OrganizationType.EDUCATION);
        when(customSourceRepository.aggregate(any(), any(), eq(Source.class))).thenReturn(sourceList);
        assertThatNoException().isThrownBy(()->commonSearchImpl.getAutocompletedFilters("",false, new HashMap<>(),""));

    }

    @Test
    void getAutocompletedFilters_With_Organization_Name_Test() {
        Map<String,String> searchFilters = new HashMap<>();
        searchFilters.put("test","test");
        Source sourceOrganization = getSourceOrganizationEntityTwo();
        sourceOrganization.setOrganizationType(OrganizationType.EDUCATION);
        List<Source> sourceOrganizations = List.of(sourceOrganization);
        when(customSourceRepository.aggregate(any(), any(), eq(Source.class))).thenReturn(sourceOrganizations);
        assertThatNoException().isThrownBy(()->commonSearchImpl.getAutocompletedFilters("",false, searchFilters,""));

    }

    @Test
    void getAutocompletedFilters_With_City_Test() {
        Map<String,String> searchFilters = new HashMap<>();
        searchFilters.put("test","test");
        Source sourceOrganization = getSourceOrganizationEntityThree();
        sourceOrganization.setOrganizationType(OrganizationType.EDUCATION);
        List<Source> sourceOrganizations = List.of(sourceOrganization);
        when(customSourceRepository.aggregate(any(), any(), eq(Source.class))).thenReturn(sourceOrganizations);
        assertThatNoException().isThrownBy(()->commonSearchImpl.getAutocompletedFilters("",false, searchFilters,""));

    }

    @Test
    void getAutocompletedFilters_With_State_Test() {
        Map<String,String> searchFilters = new HashMap<>();
        searchFilters.put("test","test");
        Source sourceOrganization = getSourceOrganizationEntityFour();
        sourceOrganization.setOrganizationType(OrganizationType.EDUCATION);
        List<Source> sourceOrganizations = List.of(sourceOrganization);
        when(customSourceRepository.aggregate(any(), any(), eq(Source.class))).thenReturn(sourceOrganizations);
        assertThatNoException().isThrownBy(()->commonSearchImpl.getAutocompletedFilters("", false, searchFilters,""));

    }

    @Test
    void getAutocompletedFilters_With_Country_Test() {
        Map<String,String> searchFilters = new HashMap<>();
        searchFilters.put("test","test");
        Source sourceOrganization = getSourceOrganizationEntityFive();
        sourceOrganization.setOrganizationType(OrganizationType.EDUCATION);
        List<Source> sourceOrganizations = List.of(sourceOrganization);
        when(customSourceRepository.aggregate(any(), any(), eq(Source.class))).thenReturn(sourceOrganizations);
        assertThatNoException().isThrownBy(()->commonSearchImpl.getAutocompletedFilters("",false, searchFilters,""));

    }

    @Test
    void getAutocompletedFilters_With_Postal_Code_Test() {
        Map<String,String> searchFilters = new HashMap<>();
        searchFilters.put("test","test");
        Source sourceOrganization = getSourceOrganizationEntitySix();
        sourceOrganization.setOrganizationType(OrganizationType.EDUCATION);
        List<Source> sourceOrganizations = List.of(sourceOrganization);
        when(customSourceRepository.aggregate(any(), any(), eq(Source.class))).thenReturn(sourceOrganizations);
        assertThatNoException().isThrownBy(()->commonSearchImpl.getAutocompletedFilters("", false, searchFilters,""));

    }

    @Test
    void getAutocompletedFiltersTest() {
        Map<String,String> searchFilters = new HashMap<>();
        searchFilters.put("test","test");
        Source sourceOrganization = getSourceOrganizationEntitySix();
        sourceOrganization.setOrganizationType(OrganizationType.EDUCATION);
        List<Source> sourceOrganizations = List.of(sourceOrganization);
        sourceOrganization.setPayload(BasicDBObject.parse("{\"lastModified\": \"2020-01-16T03:11:07+0200\"," +
                "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\"," +
                "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
        when(customSourceRepository.aggregate(any(), any(), eq(Source.class))).thenReturn(sourceOrganizations);
        assertThatNoException().isThrownBy(()->commonSearchImpl.getAutocompletedFilters("",false, searchFilters,""));

    }

    @Test
    void getAutocompletedFilters_Resource_Not_Found_Test() {
        when(customSourceRepository.aggregate(any(), any(), eq(Source.class)))
                .thenThrow(new InvalidRequestException("Unknown Input, provide proper input details"));
        Map<String, String> mutableSearchFilters = new HashMap<>();
        mutableSearchFilters.put("filterKey", "filterValue");
        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> commonSearchImpl.getAutocompletedFilters(
                        "validQuery",
                        false,
                        mutableSearchFilters,
                        "validShardLocation"
                ));
    }

    private Source getSourceOrganizationEntityOne() {
        Alias[] orgAlias = new Alias[]{new Alias("Google", "en-US"), new Alias("Google.com", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setHon(TestDataProvider.getHon());
        sourceOrganization.setOrganizationName("google");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("California city" );
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("California");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);

        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setPath(ORGANIZATION_ALIAS_NAME);
        highlightDTO.setScore(Float.parseFloat("2.000"));
        highlightDTO.setTexts(List.of(new HitText("hit", "google")));
        sourceOrganization.setHighlight(List.of(highlightDTO));
        return sourceOrganization;
    }

    private Source getSourceOrganizationEntityTwo() {
        Alias[] orgAlias = new Alias[]{new Alias("Google", "en-US"), new Alias("Google.com", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setHon(TestDataProvider.getHon());
        sourceOrganization.setOrganizationName("google");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("California city" );
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("California");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);

        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setPath(ORGANIZATION_NAME);
        highlightDTO.setScore(Float.parseFloat("2.000"));
        highlightDTO.setTexts(List.of(new HitText("hit", "google")));
        sourceOrganization.setHighlight(List.of(highlightDTO));
        return sourceOrganization;
    }

    private Source getSourceOrganizationEntityThree() {
        Alias[] orgAlias = new Alias[]{new Alias("Google", "en-US"), new Alias("Google.com", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setHon(TestDataProvider.getHon());
        sourceOrganization.setOrganizationName("google");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("California city" );
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("California");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);

        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setPath(CITY);
        highlightDTO.setScore(Float.parseFloat("2.000"));
        highlightDTO.setTexts(List.of(new HitText("hit", "google")));
        sourceOrganization.setHighlight(List.of(highlightDTO));
        return sourceOrganization;
    }

    private Source getSourceOrganizationEntityFour() {
        Alias[] orgAlias = new Alias[]{new Alias("Google", "en-US"), new Alias("Google.com", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setHon(TestDataProvider.getHon());
        sourceOrganization.setOrganizationName("google");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("California city" );
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("California");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);

        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setPath(STATE);
        highlightDTO.setScore(Float.parseFloat("2.000"));
        highlightDTO.setTexts(List.of(new HitText("hit", "google")));
        sourceOrganization.setHighlight(List.of(highlightDTO));
        return sourceOrganization;
    }

    private Source getSourceOrganizationEntityFive() {
        Alias[] orgAlias = new Alias[]{new Alias("Google", "en-US"), new Alias("Google.com", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setHon(TestDataProvider.getHon());
        sourceOrganization.setOrganizationName("google");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("California city" );
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("California");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);

        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setPath(COUNTRY);
        highlightDTO.setScore(Float.parseFloat("2.000"));
        highlightDTO.setTexts(List.of(new HitText("hit", "google")));
        sourceOrganization.setHighlight(List.of(highlightDTO));
        return sourceOrganization;
    }

    private Source getSourceOrganizationEntitySix() {
        Alias[] orgAlias = new Alias[]{new Alias("Google", "en-US"), new Alias("Google.com", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setHon(TestDataProvider.getHon());
        sourceOrganization.setOrganizationName("google");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("California city" );
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("California");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);

        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setPath(POSTAL_CODE);
        highlightDTO.setScore(Float.parseFloat("2.000"));
        highlightDTO.setTexts(List.of(new HitText("hit", "google")));
        sourceOrganization.setHighlight(List.of(highlightDTO));
        return sourceOrganization;
    }

    private Map<String, Set<String>>  getSearchFilterForSourceHistoryList(){
        Map<String, Set<String>> searchFilter = new HashMap<>();
        Set<String> organizationTypes = new HashSet<>();
        Arrays.stream(OrganizationType.values()).forEach(x-> organizationTypes.add(x.toString()));

        searchFilter.put(ORGANIZATION_NAME,Set.of("pedro"));
        searchFilter.put(HON,Set.of("OUEDU-090122-3O2WXF5"));

        Set<String> assignees = new HashSet<>();
        assignees.add("Unassigned");
        searchFilter.put(ASSIGNED_TO,assignees);

        Set<String> regions = new HashSet<>();
        regions.add("APAC");
        searchFilter.put(STATE,regions);

        Set<String> countries = new HashSet<>();
        countries.add("USA");
        searchFilter.put(COUNTRY,countries);

        return searchFilter;
    }

}
