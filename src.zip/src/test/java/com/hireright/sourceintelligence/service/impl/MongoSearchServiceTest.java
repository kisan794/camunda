package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.SmartSearchDTO;
import com.hireright.sourceintelligence.api.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.mapper.SourceDTOMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.LimitOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.query.Criteria;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class MongoSearchServiceTest {

    private MongoSearchService mongoSearchService;
    private SourceDTOMapper sourceDTOMapper;
    @SuppressWarnings("unchecked")
    private CustomSourceRepository<Source> customSourceRepository;

    @BeforeEach
    void setUp() {
        sourceDTOMapper = mock(SourceDTOMapper.class);
        customSourceRepository = mock(CustomSourceRepository.class);
        mongoSearchService = new MongoSearchService(sourceDTOMapper, customSourceRepository);
    }

    @Test
    void testSmartSearchExecution_withoutStaticMocks() throws Exception {
        SmartSearchDTO smartSearchDTO = new SmartSearchDTO();
        smartSearchDTO.setOrganizationType("EDUCATION");

        Criteria criteria = Criteria.where("status").is("ACTIVE");
        List<Source> mockSources = List.of(new Source());

        when(customSourceRepository.aggregate(any(Aggregation.class), anyString(), eq(Source.class)))
                .thenReturn(mockSources);

        Method method = MongoSearchService.class.getDeclaredMethod(
                "smartSearchExecution", Criteria.class, SmartSearchDTO.class
        );
        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<Source> result = (List<Source>) method.invoke(mongoSearchService, criteria, smartSearchDTO);
        assertThat(result).isNotNull().hasSize(1);
    }

    @Test
    void testGetSmartSearchResponseByHonIds_withoutStaticMocks() throws Exception {
        Map<String, String> smartSearchFields = new HashMap<>();
        smartSearchFields.put("status", "ACTIVE");
        smartSearchFields.put("approvalStatus", "APPROVED");
        smartSearchFields.put("payload.relationships.relationship", "parent");

        Set<String> honIds = new HashSet<>(List.of("HON1", "HON2"));

        Criteria criteria = Criteria.where("hon").in(honIds);
        criteria.and("status").is("ACTIVE");
        criteria.and("approvalStatus").is("APPROVED");
        criteria.and("payload.relationships.relationship").in(List.of("parent"));

        MatchOperation matchOperation = Aggregation.match(criteria);
        SortOperation sortOperation = Aggregation.sort(Sort.by(Sort.Direction.DESC, "totalCount"));
        LimitOperation limitOperation = Aggregation.limit(10);
        Aggregation aggregation = Aggregation.newAggregation(matchOperation, limitOperation, sortOperation);

        Source source1 = new Source();
        Source source2 = new Source();

        SourceDTO dto1 = new SourceDTO();
        dto1.setHon("HON1");
        dto1.setUsedCount(2);

        SourceDTO dto2 = new SourceDTO();
        dto2.setHon("HON2");
        dto2.setUsedCount(1);

        List<Source> sourceList = List.of(source1, source2);
        List<SourceDTO> sourceDTOs = List.of(dto1, dto2);

        when(customSourceRepository.aggregate(any(Aggregation.class), anyString(), eq(Source.class)))
                .thenReturn(sourceList);
        when(sourceDTOMapper.entityToSourceList(sourceList)).thenReturn(sourceDTOs);

        Method method = MongoSearchService.class.getDeclaredMethod(
                "getSmartSearchResponseByHonIds", Map.class, String.class, Set.class
        );
        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<SourceDTO> result = (List<SourceDTO>) method.invoke(
                mongoSearchService, smartSearchFields, "collection", honIds
        );
        assertThat(result).isNotNull().hasSize(2);
        assertThat(result.get(0).getUsedCount()).isGreaterThanOrEqualTo(result.get(1).getUsedCount());
    }

    @Test
    void testGetSmartSearchResponseByHonIds_returnsEmptyWhenNoResults() throws Exception {
        Map<String, String> smartSearchFields = Map.of("status", "ACTIVE");
        Set<String> honIds = Set.of("H1");

        when(customSourceRepository.aggregate(any(Aggregation.class), anyString(), eq(Source.class)))
                .thenReturn(Collections.emptyList());

        Method method = MongoSearchService.class.getDeclaredMethod(
                "getSmartSearchResponseByHonIds", Map.class, String.class, Set.class
        );
        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<SourceDTO> result = (List<SourceDTO>) method.invoke(
                mongoSearchService, smartSearchFields, "collection", honIds
        );

        assertThat(result).isNotNull().isEmpty();
        verifyNoInteractions(sourceDTOMapper);
    }

    @Test
    void testGetSmartSearchResponseByHonIds_parallelBranchAndSorted() throws Exception {
        Map<String, String> smartSearchFields = new HashMap<>();
        smartSearchFields.put("payload.relationships.relationship", "parent");
        List<Source> manySources = new ArrayList<>();
        for (int i = 0; i < 11; i++) {
            manySources.add(new Source());
        }
        when(customSourceRepository.aggregate(any(Aggregation.class), anyString(), eq(Source.class)))
                .thenReturn(manySources);
        AtomicInteger counter = new AtomicInteger(0);
        when(sourceDTOMapper.toSourceDTO(any(Source.class))).thenAnswer(inv -> {
            SourceDTO dto = new SourceDTO();
            dto.setHon("H" + counter.get());
            dto.setUsedCount(counter.getAndIncrement());
            return dto;
        });

        Method method = MongoSearchService.class.getDeclaredMethod(
                "getSmartSearchResponseByHonIds", Map.class, String.class, Set.class
        );
        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<SourceDTO> result = (List<SourceDTO>) method.invoke(
                mongoSearchService, smartSearchFields, "collection", Set.of("H1", "H2")
        );

        assertThat(result).hasSize(11);
        for (int i = 0; i < result.size() - 1; i++) {
            assertThat(result.get(i).getUsedCount()).isGreaterThanOrEqualTo(result.get(i + 1).getUsedCount());
        }
        verify(sourceDTOMapper, times(11)).toSourceDTO(any(Source.class));
        verify(sourceDTOMapper, never()).entityToSourceList(anyList());
    }

    @Test
    void testGetDropDownListForRAM_returnsList() throws Exception {
        List<String> orgNames = new ArrayList<>(Arrays.asList("Org1", "Org2"));
        Document nested = new Document("orgNames", orgNames);
        List<Document> results = new ArrayList<>();
        results.add(nested);
        Document root = new Document("results", results);

        when(customSourceRepository.aggregateDocument(any(Aggregation.class), anyString()))
                .thenReturn(root);

        Method method = MongoSearchService.class.getDeclaredMethod(
                "getDropDownListForRAM", String.class,
                com.hireright.sourceintelligence.domain.enums.OrganizationType.class
        );
        method.setAccessible(true);
        @SuppressWarnings("unchecked")
        List<String> orgs = (List<String>) method.invoke(
                mongoSearchService, "acme",
                com.hireright.sourceintelligence.domain.enums.OrganizationType.EDUCATION
        );

        assertThat(orgs).containsExactly("Org1", "Org2");
    }


    @Test
    void testGetDropDownListForRAM_handlesEmptyAndMissing() throws Exception {
        Method method = MongoSearchService.class.getDeclaredMethod(
                "getDropDownListForRAM",
                String.class,
                com.hireright.sourceintelligence.domain.enums.OrganizationType.class
        );
        method.setAccessible(true);
        when(customSourceRepository.aggregateDocument(any(Aggregation.class), anyString()))
                .thenReturn(new Document());
        Object r1 = method.invoke(
                mongoSearchService,
                "x",
                com.hireright.sourceintelligence.domain.enums.OrganizationType.EDUCATION
        );
        assertThat(r1).isNull();
        List<Document> results = new ArrayList<>();
        results.add(new Document("orgNames", new ArrayList<String>()));
        Document withEmpty = new Document("results", results);

        when(customSourceRepository.aggregateDocument(any(Aggregation.class), anyString()))
                .thenReturn(withEmpty);
        Object r2 = method.invoke(
                mongoSearchService,
                "y",
                com.hireright.sourceintelligence.domain.enums.OrganizationType.EDUCATION
        );
        assertThat(r2).isNull();
    }

}
