package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.service.impl.AddressServiceImpl;
import com.hireright.sourceintelligence.util.TestDataProvider;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.ArgumentCaptor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.json.JSONArray;
import org.json.JSONObject;

@ExtendWith(MockitoExtension.class)
class AddressServiceImplTest {

	@Mock
	private SourceService sourceService;

	@Mock
	private SearchService searchService;

	@InjectMocks
	private AddressServiceImpl addressService;

	private AddressDTO validAddressDTO;
	private AddressDTO invalidAddressDTO;

	private UserInfo userInfo;

	@BeforeEach
	void setUp() {
		validAddressDTO = TestDataProvider.getAddressDTO();
		validAddressDTO.setHon(TestDataProvider.getHon());

		invalidAddressDTO = TestDataProvider.getAddressDTO();

		userInfo = TestDataProvider.getUserInfo();

	}

	@Test
	void testUpdateAddress_Successful() {
		String hon = "hon456";
		AddressDTO addressDTO = new AddressDTO();
		addressDTO.setHon(hon);
		addressDTO.setAddress(new JSONArray("[{" +
				"\"useCode\":\"current\", \"availablePeriod\": {\"start\":\"\",\"end\":\"\"}, " +
				"\"city\":\"LongBeach\", \"countrySubDivisions\": [{\"type\":\"country\",\"value\":\"USA\"}," +
				"{\"type\":\"state\",\"value\":\"California\"}], \"geoLocation\":{}, \"countryCode\":\"US\"," +
				"\"line\":\"\", \"reportedDate\":\"\", \"postalCode\":\"\"}]"));

		SourceOrganizationDTO sourceDto = new SourceOrganizationDTO();
		sourceDto.setStatus(SourceOrganizationStatus.ACTIVE);
		sourceDto.setPayload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\", \"country\": \"USA\", \"state\": \"California\", \"created\": \"2020-01-16T03:11:07+0200\", \"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
		when(sourceService.getSourceByHon(hon)).thenReturn(sourceDto);
		addressService.updateAddress(addressDTO, userInfo);
		ArgumentCaptor<SourceOrganizationDTO> sourceCaptor = ArgumentCaptor.forClass(SourceOrganizationDTO.class);
		ArgumentCaptor<UIActionsDTO> uiActionsCaptor = ArgumentCaptor.forClass(UIActionsDTO.class);
		verify(sourceService, times(1)).updateSource(sourceCaptor.capture(), uiActionsCaptor.capture());
		assertEquals("Save", uiActionsCaptor.getValue().getUserAction());
	}
	@Test
	void testUpdateAddress_MissingHON() {

		String hon = "hon456";
		AddressDTO addressDTO = new AddressDTO();
		addressDTO.setHon(hon);

		SourceOrganizationDTO sourceDto = sourceService.getSourceByHon(validAddressDTO.getHon());

		assertThrows(RuntimeException.class, () -> addressService.updateAddress(invalidAddressDTO, null));

	}

	@Test
	void testGetOrganizationAddressListByHon() {
		// Arrange
		SearchDTO searchDTO = TestDataProvider.getSearchDTO();
		SearchResponseDTO responseDTO = new SearchResponseDTO();

		when(searchService.getSourceOrganizationAddressByHon(eq(searchDTO))).thenReturn(responseDTO);

		// Act
		SearchResponseDTO result = addressService.getAddressListByHon(searchDTO);

		// Assert
		assertSame(responseDTO, result);
		verify(searchService, times(1)).getSourceOrganizationAddressByHon(eq(searchDTO));
		verifyNoInteractions(sourceService);
	}

	private SourceOrganizationDTO createActiveSourceDTO() {
		SourceOrganizationDTO sourceDto = new SourceOrganizationDTO();
		sourceDto.setStatus(SourceOrganizationStatus.ACTIVE);

		return sourceDto;
	}
}
