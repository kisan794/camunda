package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.service.impl.AutoMatchQueryBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.data.mongodb.core.aggregation.Aggregation;

import static org.junit.jupiter.api.Assertions.*;

class AutoMatchQueryBuilderTest {

    private AutoMatchDTO createTestDTO() {
        AutoMatchDTO dto = new AutoMatchDTO();
        dto.setSourceName("Test University");
        dto.setCountry("USA");
        dto.setState("CA");
        dto.setCity("Los Angeles");
        dto.setSourceType(OrganizationType.EDUCATION.getType());
        return dto;
    }

    @Test
    void testAutoMatchUSRegionForOrgAlias() {
        AutoMatchDTO dto = createTestDTO();
        Aggregation aggregation = AutoMatchQueryBuilder.autoMatchUSRegionForOrgAlias(dto);
        assertNotNull(aggregation);
        System.out.println("US Region For Org Alias Aggregation: " + aggregation);
    }


    @Test
    void testAutoMatchUSRegionForOrg() {
        AutoMatchDTO dto = createTestDTO();
        Aggregation aggregation = AutoMatchQueryBuilder.autoMatchUSRegionForOrg(dto);
        assertNotNull(aggregation);
        System.out.println("US Region For Org Aggregation: " + aggregation);
    }

    @Test
    void testAutoMatchUSRegionForOrg_withNonEducationType() {
        AutoMatchDTO dto = createTestDTO();
        dto.setSourceType("EMPLOYMENT");
        Aggregation aggregation = AutoMatchQueryBuilder.autoMatchUSRegionForOrg(dto);
        assertNotNull(aggregation);
    }


    @Test
    void testAutoMatchUSRegionForOrgAlias_withEmptyCityAndState() {
        AutoMatchDTO dto = new AutoMatchDTO();
        dto.setSourceName("Alias University");
        dto.setCountry("USA");
        dto.setSourceType("EDUCATION");
        dto.setCity("");
        dto.setState(null);

        Aggregation aggregation = AutoMatchQueryBuilder.autoMatchUSRegionForOrgAlias(dto);
        assertNotNull(aggregation);
    }

    @Test
    void testAutoMatchUSRegion_withEmptyCityAndState() {
        AutoMatchDTO dto = new AutoMatchDTO();
        dto.setSourceName("Secondary Org");
        dto.setCountry("USA");
        dto.setSourceType("EDUCATION");
        dto.setCity(null);
        dto.setState("");

        Aggregation aggregation = AutoMatchQueryBuilder.autoMatchUSRegion(dto, "secondaryCollection");
        assertNotNull(aggregation);
    }

    @Test
    void testAutoMatchUSRegion() {
        AutoMatchDTO dto = createTestDTO();
        Aggregation aggregation = AutoMatchQueryBuilder.autoMatchUSRegion(dto, "sourceCollection");


        assertNotNull(aggregation, "Aggregation should not be null");
        System.out.println("Generated Aggregation: " + aggregation);
    }

}
