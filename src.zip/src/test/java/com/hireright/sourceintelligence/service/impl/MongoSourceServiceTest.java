package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.domain.entity.RegionThreshold;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.domain.repository.RegionThresholdRepository;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.mongodb.core.query.Update;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.EMPLOYMENT_COLLECTION_PREFIX;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.SOURCE_COLLECTION_SUFFIX;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class MongoSourceServiceTest {

    private CustomSourceRepository<Source> customSourceRepository;
    private RegionThresholdRepository regionThresholdRepository;
    private SourceMapper sourceMapper;
    private ElasticsearchService elasticsearchService;
    private ReportDataUtils reportDataUtils;

    private MongoSourceService mongoSourceService;


    @BeforeEach
    void setup() {
        customSourceRepository = mock(CustomSourceRepository.class);
        regionThresholdRepository = mock(RegionThresholdRepository.class);
        sourceMapper = mock(SourceMapper.class);
        elasticsearchService = mock(ElasticsearchService.class);
        reportDataUtils = mock(ReportDataUtils.class);

        mongoSourceService = new MongoSourceService(
                customSourceRepository,
                regionThresholdRepository,
                sourceMapper,
                elasticsearchService,
                reportDataUtils
        );
    }



    @Test
    void testInsert_shouldCallCreate() {
        Source source = new Source();
        when(customSourceRepository.create(any(Source.class), eq(Source.class), eq("collection")))
                .thenReturn(source);

        Source result = mongoSourceService.insert(source, "collection");
        assertThat(result).isNotNull();
        verify(customSourceRepository).create(any(Source.class), eq(Source.class), eq("collection"));
    }

    @Test
    void testUpdate_shouldCallUpdate() {
        Source source = new Source();
        when(customSourceRepository.update(anyString(), anyString(), any(Source.class), eq(Source.class), eq("collection")))
                .thenReturn(true);

        boolean updated = mongoSourceService.update("field", "value", source, "collection");
        assertThat(updated).isTrue();
    }

    @Test
    void testPatch_shouldCallPatch() {
        Update update = new Update();
        mongoSourceService.patch("field", "value", update, "collection");

        verify(customSourceRepository).patch("field", "value", update, "collection");
    }




    @Test
    void testGetPossibleDuplicateSources_shouldReturnMappedDTO() {
        SourceOrganizationDTO input = new SourceOrganizationDTO();
        input.setOrganizationType(OrganizationType.EDUCATION);
        input.setOrganizationName("Test Org");
        input.setPayload(new JSONObject());

        Source source = new Source();
        SourceOrganizationDTO mappedDTO = new SourceOrganizationDTO();

        when(customSourceRepository.findByQuery(any(), eq(Source.class), anyString()))
                .thenReturn(List.of(source));
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(mappedDTO);

        SourceOrganizationDTO result = mongoSourceService.getPossibleDuplicateSources(input);
        assertThat(result).isNotNull();
    }


    @Test
    void testGetPossibleDuplicateSources_shouldReturnNullIfEmpty() {
        SourceOrganizationDTO input = new SourceOrganizationDTO();
        input.setOrganizationType(OrganizationType.EMPLOYMENT);
        input.setOrganizationName("Test Org");
        input.setPayload(new JSONObject());

        when(customSourceRepository.findByQuery(any(), eq(Source.class), anyString()))
                .thenReturn(Collections.emptyList());

        SourceOrganizationDTO result = mongoSourceService.getPossibleDuplicateSources(input);
        assertThat(result).isNull();
    }

    @Test
    void testIsHonExists_shouldReturnTrue() {
        String hon = "OUEMP123";

        when(customSourceRepository.isHonExists(eq(hon), eq(Source.class), anyString()))
                .thenReturn(true);

        boolean exists = mongoSourceService.isHonExists(hon);
        assertThat(exists).isTrue();

        verify(customSourceRepository).isHonExists(eq(hon), eq(Source.class), anyString());
    }


    @Test
    void testFindSourceHistoryByHon_shouldReturnSource() {
        String hon = "OUEDU123";
        Source source = new Source();
        String collectionName = "education_source_history";
        when(customSourceRepository.findLatestByHon(hon, Source.class, collectionName))
                .thenReturn(source);

        Source result = mongoSourceService.findSourceHistoryByHon(hon);

        assertThat(result).isEqualTo(source);
    }


    @Test
    void testFindSourceByHon_shouldReturnSource() {
        String hon = "OUEMP123";
        Source source = new Source();
        String collectionName = EMPLOYMENT_COLLECTION_PREFIX + SOURCE_COLLECTION_SUFFIX;
        when(customSourceRepository.findOneByHon(hon, Source.class, collectionName))
                .thenReturn(source);

        Source result = mongoSourceService.findSourceByHon(hon);

        assertThat(result).isEqualTo(source);
    }

    @Test
    void testGetThresholdForRegion_shouldThrowExceptionWhenFieldNotPresent() {
        RegionThreshold threshold = new RegionThreshold();
        when(regionThresholdRepository.findByThresholdType(any()))
                .thenReturn(threshold);


        assertThatThrownBy(() -> mongoSourceService.getThresholdForRegion("INVALID_REGION"))
                .isInstanceOf(Exception.class);
    }

    @Test
    void testFindSourceByHon_shouldThrowException() {
        String hon = "EMPLOYMENT_123";

        when(customSourceRepository.findOneByHon(eq(hon), eq(Source.class), anyString()))
                .thenThrow(new RuntimeException("DB error"));

        assertThatThrownBy(() -> mongoSourceService.findSourceByHon(hon))
                .isInstanceOf(Exception.class);
    }

    @Test
    void testFindSourceHistoryByHon_shouldThrowException() {
        String hon = "EMPLOYMENT_456";

        when(customSourceRepository.findLatestByHon(eq(hon), eq(Source.class), anyString()))
                .thenThrow(new RuntimeException("DB error"));

        assertThatThrownBy(() -> {
            Method method = MongoSourceService.class.getDeclaredMethod("findSourceHistoryByHon", String.class);
            method.setAccessible(true);
            method.invoke(mongoSourceService, hon);
        }).isInstanceOf(InvocationTargetException.class);
    }

    @Test
    void testGetPossibleDuplicateSources_shouldReturnDTOWhenResultExists() {
        SourceOrganizationDTO input = new SourceOrganizationDTO();
        input.setOrganizationType(OrganizationType.EMPLOYMENT);
        input.setOrganizationName("Test Company");
        input.setPayload(new JSONObject());

        Source source = new Source();
        when(customSourceRepository.findByQuery(any(), eq(Source.class), anyString()))
                .thenReturn(List.of(source));
        when(sourceMapper.entitySourceToDTO(any())).thenReturn(new SourceOrganizationDTO());

        SourceOrganizationDTO result = mongoSourceService.getPossibleDuplicateSources(input);
        assertThat(result).isNotNull();
    }







    @Test
    void testGetThresholdForRegion_shouldReturnThreshold() throws Exception {
        RegionThreshold threshold = new RegionThreshold();
        Field field = RegionThreshold.class.getDeclaredField("US");
        field.setAccessible(true);
        field.set(threshold, 90);

        when(regionThresholdRepository.findByThresholdType(any()))
                .thenReturn(threshold);


        int result = mongoSourceService.getThresholdForRegion("us");
        assertThat(result).isEqualTo(90);
    }
}
