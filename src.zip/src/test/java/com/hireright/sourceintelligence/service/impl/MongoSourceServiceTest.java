package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.DeleteRequestDTO;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.domain.entity.RegionThreshold;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.domain.repository.RegionThresholdRepository;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import org.bson.types.ObjectId;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.DELETE;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.SIDB_ORIGIN;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.SOURCE_COLLECTION_SUFFIX;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.SOURCE_HISTORY_COLLECTION_SUFFIX;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.Threshold.THRESHOLD_VALUE;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class MongoSourceServiceTest {

    private CustomSourceRepository<Source> customSourceRepository;
    private RegionThresholdRepository regionThresholdRepository;
    private SourceMapper sourceMapper;
    private ElasticsearchService elasticsearchService;
    private ReportDataUtils reportDataUtils;

    private MongoSourceService mongoSourceService;

    @BeforeEach
    void setup() {
        customSourceRepository = mock(CustomSourceRepository.class);
        regionThresholdRepository = mock(RegionThresholdRepository.class);
        sourceMapper = mock(SourceMapper.class);
        elasticsearchService = mock(ElasticsearchService.class);
        reportDataUtils = mock(ReportDataUtils.class);

        mongoSourceService = new MongoSourceService(
                customSourceRepository,
                regionThresholdRepository,
                sourceMapper,
                elasticsearchService,
                reportDataUtils
        );
    }

    @Test
    void testInsert_shouldSetIdNullAndCallCreate() {
        Source source = new Source();
        source.setId(new ObjectId());

        when(customSourceRepository.create(any(Source.class), eq(Source.class), eq("collection")))
                .thenReturn(source);

        Source result = mongoSourceService.insert(source, "collection");

        assertThat(result).isNotNull();

        ArgumentCaptor<Source> captor = ArgumentCaptor.forClass(Source.class);
        verify(customSourceRepository).create(captor.capture(), eq(Source.class), eq("collection"));
        assertThat(captor.getValue().getId()).isNull();
    }

    @Test
    void testUpdate_shouldSetIdNullAndCallUpdate() {
        Source source = new Source();
        source.setId(new ObjectId());

        when(customSourceRepository.update(anyString(), anyString(), any(Source.class), eq(Source.class), eq("collection")))
                .thenReturn(true);

        Boolean result = mongoSourceService.update("field", "value", source, "collection");

        assertThat(result).isTrue();

        ArgumentCaptor<Source> captor = ArgumentCaptor.forClass(Source.class);
        verify(customSourceRepository).update(eq("field"), eq("value"), captor.capture(), eq(Source.class), eq("collection"));
        assertThat(captor.getValue().getId()).isNull();
    }

    @Test
    void testUpdate_shouldReturnFalse() {
        Source source = new Source();

        when(customSourceRepository.update(anyString(), anyString(), any(Source.class), eq(Source.class), eq("collection")))
                .thenReturn(false);

        Boolean result = mongoSourceService.update("field", "value", source, "collection");

        assertThat(result).isFalse();
    }

    @Test
    void testUpdateById_shouldCallRepository() {
        Source source = new Source();
        ObjectId id = new ObjectId();
        source.setId(id);

        mongoSourceService.updateById(source, "collection");

        verify(customSourceRepository).updateByQuery(any(Query.class), eq(source), eq(Source.class), eq("collection"));
    }

    @Test
    void testPatch_shouldCallPatch() {
        Update update = new Update();

        mongoSourceService.patch("field", "value", update, "collection");

        verify(customSourceRepository).patch("field", "value", update, "collection");
    }

    @Test
    void testFindSourceByHon_shouldReturnSource() {
        String hon = "OUEMP123";
        Source source = new Source();

        when(customSourceRepository.findOneByHon(eq(hon), eq(Source.class), anyString()))
                .thenReturn(source);

        Source result = mongoSourceService.findSourceByHon(hon);

        assertThat(result).isEqualTo(source);
    }

    @Test
    void testFindSourceByHon_shouldThrowException() {
        String hon = "OUEMP123";

        when(customSourceRepository.findOneByHon(eq(hon), eq(Source.class), anyString()))
                .thenThrow(new RuntimeException("DB error"));

        assertThatThrownBy(() -> mongoSourceService.findSourceByHon(hon))
                .isInstanceOf(Exception.class);
    }

    @Test
    void testFindSourceHistoryByHon_shouldReturnSource() {
        String hon = "OUEDU123";
        Source source = new Source();

        when(customSourceRepository.findLatestByHon(eq(hon), eq(Source.class), anyString()))
                .thenReturn(source);

        Source result = mongoSourceService.findSourceHistoryByHon(hon);

        assertThat(result).isEqualTo(source);
    }

    @Test
    void testFindSourceHistoryByHon_shouldThrowException() {
        String hon = "OUEDU123";

        when(customSourceRepository.findLatestByHon(eq(hon), eq(Source.class), anyString()))
                .thenThrow(new RuntimeException("DB error"));

        assertThatThrownBy(() -> mongoSourceService.findSourceHistoryByHon(hon))
                .isInstanceOf(Exception.class);
    }

    @Test
    void testGetPossibleDuplicateSources_shouldReturnMappedDTO() {
        SourceOrganizationDTO input = new SourceOrganizationDTO();
        input.setOrganizationType(OrganizationType.EDUCATION);
        input.setOrganizationName("Test Org");
        input.setPayload(new JSONObject());

        Source source = new Source();
        SourceOrganizationDTO mappedDTO = new SourceOrganizationDTO();

        when(customSourceRepository.findByQuery(any(), eq(Source.class), anyString()))
                .thenReturn(List.of(source));
        when(sourceMapper.entitySourceToDTO(source)).thenReturn(mappedDTO);

        SourceOrganizationDTO result = mongoSourceService.getPossibleDuplicateSources(input);

        assertThat(result).isEqualTo(mappedDTO);
    }

    @Test
    void testGetPossibleDuplicateSources_shouldReturnNullWhenNoData() {
        SourceOrganizationDTO input = new SourceOrganizationDTO();
        input.setOrganizationType(OrganizationType.EMPLOYMENT);
        input.setOrganizationName("Test Org");
        input.setPayload(new JSONObject());

        when(customSourceRepository.findByQuery(any(), eq(Source.class), anyString()))
                .thenReturn(Collections.emptyList());

        SourceOrganizationDTO result = mongoSourceService.getPossibleDuplicateSources(input);

        assertThat(result).isNull();
    }

    @Test
    void testGetPossibleDuplicateSources_shouldThrowWhenDataAccessException() {
        SourceOrganizationDTO input = new SourceOrganizationDTO();
        input.setOrganizationType(OrganizationType.EMPLOYMENT);
        input.setOrganizationName("Test Org");
        input.setPayload(new JSONObject());

        when(customSourceRepository.findByQuery(any(), eq(Source.class), anyString()))
                .thenThrow(new DataAccessResourceFailureException("db down"));

        assertThatThrownBy(() -> mongoSourceService.getPossibleDuplicateSources(input))
                .isInstanceOf(Exception.class);
    }

    @Test
    void testGetThresholdForRegion_shouldReturnThreshold() throws Exception {
        RegionThreshold threshold = new RegionThreshold();
        Field field = RegionThreshold.class.getDeclaredField("US");
        field.setAccessible(true);
        field.set(threshold, 90);

        when(regionThresholdRepository.findByThresholdType(THRESHOLD_VALUE))
                .thenReturn(threshold);

        int result = mongoSourceService.getThresholdForRegion("us");

        assertThat(result).isEqualTo(90);
    }

    @Test
    void testGetThresholdForRegion_shouldThrowExceptionWhenFieldNotPresent() {
        RegionThreshold threshold = new RegionThreshold();
        when(regionThresholdRepository.findByThresholdType(THRESHOLD_VALUE))
                .thenReturn(threshold);

        assertThatThrownBy(() -> mongoSourceService.getThresholdForRegion("INVALID_REGION"))
                .isInstanceOf(Exception.class);
    }

    @Test
    void testIsHonExists_shouldReturnTrue() {
        String hon = "OUEMP123";

        when(customSourceRepository.isHonExists(eq(hon), eq(Source.class), anyString()))
                .thenReturn(true);

        boolean result = mongoSourceService.isHonExists(hon);

        assertThat(result).isTrue();
    }

    @Test
    void testIsHonExists_shouldReturnFalse() {
        String hon = "OUEMP123";

        when(customSourceRepository.isHonExists(eq(hon), eq(Source.class), anyString()))
                .thenReturn(false);

        boolean result = mongoSourceService.isHonExists(hon);

        assertThat(result).isFalse();
    }

    @Test
    void testHardDeleteSource_shouldReturnZeroWhenNoActiveSourceFound() throws Exception {
        String hon = "OUEMP123";
        when(customSourceRepository.findByHon(eq(hon), eq(Source.class), anyString()))
                .thenReturn(Collections.emptyList());

        long result = mongoSourceService.hardDeleteSource(hon, mock(DeleteRequestDTO.class, RETURNS_DEEP_STUBS));

        assertThat(result).isZero();
        verify(elasticsearchService, never()).deleteSourceByHon(anyString());
        verify(customSourceRepository, never()).deleteByQuery(any(), eq(Source.class), anyString());
    }

    @Test
    void testHardDeleteSource_shouldDeleteActiveAndHistorySources() throws Exception {
        String hon = "OUEMP123";

        Source active1 = new Source();
        active1.setVersion(1.0);
        active1.setTempVersion(1.1);

        Source active2 = new Source();
        active2.setVersion(2.0);
        active2.setTempVersion(2.1);

        Source history = new Source();

        DeleteRequestDTO deleteRequestDTO = mock(DeleteRequestDTO.class, RETURNS_DEEP_STUBS);
        when(deleteRequestDTO.getUiAction().getUserName()).thenReturn("tester");
        when(deleteRequestDTO.getUiAction().getUserEmail()).thenReturn("tester@mail.com");
        when(deleteRequestDTO.getReason()).thenReturn("cleanup");

        String sourceCollectionName = com.hireright.sourceintelligence.util.Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
        String historyCollectionName = com.hireright.sourceintelligence.util.Helper.getCollectionName(hon, SOURCE_HISTORY_COLLECTION_SUFFIX);

        when(customSourceRepository.findByHon(eq(hon), eq(Source.class), eq(sourceCollectionName)))
                .thenReturn(List.of(active1, active2));
        when(customSourceRepository.findByHon(eq(hon), eq(Source.class), eq(historyCollectionName)))
                .thenReturn(List.of(history));
        when(customSourceRepository.deleteByQuery(any(Query.class), eq(Source.class), eq(historyCollectionName)))
                .thenReturn(1L);
        when(customSourceRepository.deleteByQuery(any(Query.class), eq(Source.class), eq(sourceCollectionName)))
                .thenReturn(2L);

        long result = mongoSourceService.hardDeleteSource(hon, deleteRequestDTO);

        assertThat(result).isEqualTo(2L);

        assertThat(active1.getAssignedTo()).isEqualTo("tester");
        assertThat(active1.getAssignedId()).isEqualTo("tester@mail.com");
        assertThat(active2.getAssignedTo()).isEqualTo("tester");
        assertThat(active2.getAssignedId()).isEqualTo("tester@mail.com");

        verify(reportDataUtils, times(2)).reportData(
                any(Source.class),
                eq(DELETE),
                eq(SIDB_ORIGIN),
                eq(0),
                eq("cleanup"),
                anyDouble(),
                anyDouble(),
                eq(DELETE)
        );

        verify(elasticsearchService).deleteSourceByHon(hon);
        verify(customSourceRepository).deleteByQuery(any(Query.class), eq(Source.class), eq(historyCollectionName));
        verify(customSourceRepository).deleteByQuery(any(Query.class), eq(Source.class), eq(sourceCollectionName));
    }

    @Test
    void testHardDeleteSource_shouldDeleteOnlyActiveWhenHistoryNotFound() throws Exception {
        String hon = "OUEMP123";

        Source active = new Source();
        active.setVersion(1.0);
        active.setTempVersion(1.1);

        DeleteRequestDTO deleteRequestDTO = mock(DeleteRequestDTO.class, RETURNS_DEEP_STUBS);
        when(deleteRequestDTO.getUiAction().getUserName()).thenReturn("tester");
        when(deleteRequestDTO.getUiAction().getUserEmail()).thenReturn("tester@mail.com");
        when(deleteRequestDTO.getReason()).thenReturn("cleanup");

        when(customSourceRepository.findByHon(eq(hon), eq(Source.class), contains(SOURCE_COLLECTION_SUFFIX)))
                .thenReturn(List.of(active));
        when(customSourceRepository.findByHon(eq(hon), eq(Source.class), contains(SOURCE_HISTORY_COLLECTION_SUFFIX)))
                .thenReturn(Collections.emptyList());
        when(customSourceRepository.deleteByQuery(any(Query.class), eq(Source.class), contains(SOURCE_COLLECTION_SUFFIX)))
                .thenReturn(1L);

        long result = mongoSourceService.hardDeleteSource(hon, deleteRequestDTO);

        assertThat(result).isEqualTo(1L);
        verify(customSourceRepository, never()).deleteByQuery(any(Query.class), eq(Source.class), contains(SOURCE_HISTORY_COLLECTION_SUFFIX));
        verify(elasticsearchService).deleteSourceByHon(hon);
    }

    @Test
    void testDelete_shouldCallRepository() {
        Source source = new Source();

        when(customSourceRepository.delete(source, Source.class, "collection"))
                .thenReturn(1L);

        long result = mongoSourceService.delete(source, "collection");

        assertThat(result).isEqualTo(1L);
    }

    @Test
    void testDeleteSourceById_shouldCallRepository() {
        ObjectId id = new ObjectId();

        mongoSourceService.deleteSourceById(id, "collection");

        verify(customSourceRepository).deleteById(id, Source.class, "collection");
    }

    @Test
    void testFindSourceByHonAndApprovalStatus_shouldReturnSource() {
        String hon = "OUEMP123";
        Source source = new Source();

        when(customSourceRepository.findOneByHonAndApprovalStatus(eq(hon), eq(ApprovalStatus.APPROVED.getStatus()), eq(Source.class), anyString()))
                .thenReturn(source);

        Source result = mongoSourceService.findSourceByHonAndApprovalStatus(hon, ApprovalStatus.APPROVED);

        assertThat(result).isEqualTo(source);
    }

    @Test
    void testFindSourceByHonAndApprovalStatus_shouldReturnNullOnException() {
        String hon = "OUEMP123";

        when(customSourceRepository.findOneByHonAndApprovalStatus(eq(hon), eq(ApprovalStatus.APPROVED.getStatus()), eq(Source.class), anyString()))
                .thenThrow(new RuntimeException("error"));

        Source result = mongoSourceService.findSourceByHonAndApprovalStatus(hon, ApprovalStatus.APPROVED);

        assertThat(result).isNull();
    }

    @Test
    void testFindSourceByHonAndApprovalStatuses_shouldReturnSource() {
        String hon = "OUEMP123";
        List<String> statuses = List.of("APPROVED", "PENDING");
        Source source = new Source();

        when(customSourceRepository.findOneByHonAndApprovalStatuses(eq(hon), eq(statuses), eq(Source.class), anyString()))
                .thenReturn(source);

        Source result = mongoSourceService.findSourceByHonAndApprovalStatuses(hon, statuses);

        assertThat(result).isEqualTo(source);
    }

    @Test
    void testFindSourceByHonAndApprovalStatuses_shouldReturnNullOnException() {
        String hon = "OUEMP123";
        List<String> statuses = List.of("APPROVED", "PENDING");

        when(customSourceRepository.findOneByHonAndApprovalStatuses(eq(hon), eq(statuses), eq(Source.class), anyString()))
                .thenThrow(new RuntimeException("error"));

        Source result = mongoSourceService.findSourceByHonAndApprovalStatuses(hon, statuses);

        assertThat(result).isNull();
    }

    @Test
    void testGetSourceListByHonAndApprovalStatuses_shouldReturnList() {
        String hon = "OUEMP123";
        List<String> statuses = List.of("APPROVED", "PENDING");
        List<Source> sources = List.of(new Source(), new Source());

        when(customSourceRepository.findByHonAndApprovalStatuses(eq(hon), eq(statuses), eq(Source.class), anyString()))
                .thenReturn(sources);

        List<Source> result = mongoSourceService.getSourceListByHonAndApprovalStatuses(hon, statuses);

        assertThat(result).hasSize(2);
    }

    @Test
    void testGetSourceListByHonAndApprovalStatuses_shouldReturnEmptyListOnException() {
        String hon = "OUEMP123";
        List<String> statuses = List.of("APPROVED", "PENDING");

        when(customSourceRepository.findByHonAndApprovalStatuses(eq(hon), eq(statuses), eq(Source.class), anyString()))
                .thenThrow(new RuntimeException("error"));

        List<Source> result = mongoSourceService.getSourceListByHonAndApprovalStatuses(hon, statuses);

        assertThat(result).isEmpty();
    }

    @Test
    void testFindSourceByHonOrderByLastModifiedBy_shouldReturnSource() {
        String hon = "OUEMP123";
        Source source = new Source();

        when(customSourceRepository.findSourceByHonOrderByLastModifiedBy(eq(hon), eq(Source.class), anyString()))
                .thenReturn(source);

        Source result = mongoSourceService.findSourceByHonOrderByLastModifiedBy(hon);

        assertThat(result).isEqualTo(source);
    }

    @Test
    void testFindSourceByHonOrderByLastModifiedBy_shouldThrowException() {
        String hon = "OUEMP123";

        when(customSourceRepository.findSourceByHonOrderByLastModifiedBy(eq(hon), eq(Source.class), anyString()))
                .thenThrow(new RuntimeException("error"));

        assertThatThrownBy(() -> mongoSourceService.findSourceByHonOrderByLastModifiedBy(hon))
                .isInstanceOf(Exception.class);
    }

    @Test
    void testUpdateByIdWithCustomFields_shouldReturnTrue() {
        Query query = new Query();
        Update update = new Update();

        when(customSourceRepository.updateFieldsByQuery(query, update, Source.class, "collection"))
                .thenReturn(true);

        Boolean result = mongoSourceService.updateByIdWithCustomFields(query, update, "collection");

        assertThat(result).isTrue();
    }

    @Test
    void testUpdateByIdWithCustomFields_shouldReturnFalse() {
        Query query = new Query();
        Update update = new Update();

        when(customSourceRepository.updateFieldsByQuery(query, update, Source.class, "collection"))
                .thenReturn(false);

        Boolean result = mongoSourceService.updateByIdWithCustomFields(query, update, "collection");

        assertThat(result).isFalse();
    }

    @Test
    void testInsertSourceHistory_shouldMapAndInsertHistory() {
        Source entityFromDb = new Source();
        entityFromDb.setOrganizationName("Org");
        entityFromDb.setOrganizationType(OrganizationType.EMPLOYMENT);

        SourceOrganizationDTO dto = new SourceOrganizationDTO();
        dto.setOrganizationType(OrganizationType.EMPLOYMENT);

        Source mappedHistory = new Source();
        mappedHistory.setOrganizationType(OrganizationType.EMPLOYMENT);

        Source inserted = new Source();
        inserted.setOrganizationName("Org");

        when(sourceMapper.entitySourceToDTO(entityFromDb)).thenReturn(dto);
        when(sourceMapper.dtoToEntitySource(dto)).thenReturn(mappedHistory);
        when(customSourceRepository.create(any(Source.class), eq(Source.class), anyString())).thenReturn(inserted);

        mongoSourceService.insertSourceHistory(entityFromDb);

        verify(sourceMapper).entitySourceToDTO(entityFromDb);
        verify(sourceMapper).dtoToEntitySource(dto);
        verify(customSourceRepository).create(any(Source.class), eq(Source.class), contains(SOURCE_HISTORY_COLLECTION_SUFFIX));
    }

    @Test
    void testFindSourceById_shouldReturnSource() {
        ObjectId id = new ObjectId();
        Source source = new Source();

        when(customSourceRepository.findById(id, Source.class, "collection"))
                .thenReturn(source);

        Source result = mongoSourceService.findSourceById(id, "collection");

        assertThat(result).isEqualTo(source);
    }

    @Test
    void testIsSourceExistsInHistoryByHonAndVersion_shouldReturnTrue() {
        String hon = "OUEMP123";
        double version = 1.0;

        when(customSourceRepository.findByQuery(any(Query.class), eq(Source.class), anyString()))
                .thenReturn(List.of(new Source()));

        boolean result = mongoSourceService.isSourceExistsInHistoryByHonAndVersion(hon, version);

        assertThat(result).isTrue();
    }

    @Test
    void testIsSourceExistsInHistoryByHonAndVersion_shouldReturnFalse() {
        String hon = "OUEMP123";
        double version = 1.0;

        when(customSourceRepository.findByQuery(any(Query.class), eq(Source.class), anyString()))
                .thenReturn(Collections.emptyList());

        boolean result = mongoSourceService.isSourceExistsInHistoryByHonAndVersion(hon, version);

        assertThat(result).isFalse();
    }
}