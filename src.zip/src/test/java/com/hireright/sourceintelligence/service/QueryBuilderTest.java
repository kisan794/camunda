package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogFilters;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.service.impl.QueryBuilder;
import com.hireright.sourceintelligence.service.impl.SearchConstants;
import org.bson.Document;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class QueryBuilderTest {


    @Test
    void testBuildMatch() {
        Criteria criteria = Criteria.where("city").is("New York");
        MatchOperation operation = QueryBuilder.buildMatch(criteria);
        assertNotNull(operation);
    }

    @Test
    void testBuildDuplicateSearchDocument() {
        Criteria criteria = QueryBuilder.buildDuplicateSearchDocument("DuplicateOrg");
        assertNotNull(criteria);
    }

    @Test
    void testGetSortPropertyMapped() {
        String result = QueryBuilder.getSortPropertyMapped("organizationName");
        assertEquals("organizationName", result);
    }

    @Test
    void testBuildDocumentForChangeLog() {
        ChangeLogFilters filters = new ChangeLogFilters();
        filters.setOrganizationName("TestOrg");
        filters.setHon("HON123");
        filters.setActivities(Arrays.asList("CREATE", "UPDATE"));
        filters.setDateRange(null);

        Criteria criteria = QueryBuilder.buildDocumentForChangeLog(filters);
        assertNotNull(criteria);
    }

    @Test
    void testSearchQuery() {
        SearchDTO dto = SearchDTO.builder()
                .hon("HON123")
                .searchText("OrgText")
                .country("India")
                .organizationType(OrganizationType.EDUCATION)
                .sourceOrganizationStatus(SourceOrganizationStatus.ACTIVE)
                .build();

        org.springframework.data.mongodb.core.query.Query query = QueryBuilder.searchQuery(dto);
        assertNotNull(query);
    }


    @Test
    void testBuildDocumentForApprovalManager() {
        SearchFilter filter = new SearchFilter();
        filter.setSearchKey("test");
        filter.setSearchField("organizationName");
        filter.setStatuses(List.of(ApprovalStatus.PENDING_APPROVAL));
        filter.setAssignees(List.of(new ApproverDTO("John Doe", "john@example.com","")));

        DateRange range = new DateRange();
        range.setStartDate(Instant.now().minus(30, ChronoUnit.DAYS));
        range.setEndDate(Instant.now());
        filter.setDateRange(range);

        Criteria criteria = QueryBuilder.buildDocumentForApprovalManager(filter);
        assertNotNull(criteria);
    }

    @Test
    void testQueryCriteriaForNonArrayFields() {
        JSONObject payload = new JSONObject();
        payload.put("departmentName", "Engineering");

        SourceOrganizationDTO dto = SourceOrganizationDTO.builder()
                .organizationName("TestOrg")
                .country("USA")
                .state("CA")
                .city("LA")
                .postalCode("90001")
                .payload(payload)
                .build();

        List<Criteria> criteriaList = QueryBuilder.queryCriteriaForNonArrayFields(dto);
        assertFalse(criteriaList.isEmpty());
    }

    @Test
    void testQueryCriteriaForArrayFields() {
        Alias alias1 = new Alias("AliasOne", "en");
        Alias alias2 = new Alias("AliasTwo", "en");
        SourceOrganizationDTO dto = SourceOrganizationDTO.builder()
                .organizationAlias(new Alias[]{alias1, alias2})
                .build();

        List<Criteria> criteriaList = new ArrayList<>();
        QueryBuilder.queryCriteriaForArrayFields(dto, criteriaList);
        assertFalse(criteriaList.isEmpty());
    }

    @Test
    void testCountOperation() {
        assertNotNull(QueryBuilder.countOperation());
    }

    @Test
    void testLimitOperation() {
        Object value = QueryBuilder.limitOperation(5).toDocument(Aggregation.DEFAULT_CONTEXT).get("$limit");
        assertEquals(5L, value);
    }


    @Test
    void testSkipOperation() {
        assertEquals(5L, QueryBuilder.skipOperation(2, 5).toDocument(Aggregation.DEFAULT_CONTEXT).get("$skip"));
    }

    @Test
    void testGetTotalPages() {
        assertEquals(5, QueryBuilder.getTotalPages(25, 5)); // 25/5 = 5 pages
        assertEquals(5, QueryBuilder.getTotalPages(21, 5)); // 21/5 = 4.2 → 5 pages
        assertEquals(1, QueryBuilder.getTotalPages(1, 5));  // Less than 1 page = 1
        assertEquals(0, QueryBuilder.getTotalPages(0, 5));  // No items = 0 pages
    }


    @Test
    void testBuildCriteriaForSmartSearchSuggestions() {
        Map<String, String> input = new HashMap<>();
        input.put("country", "USA");
        input.put("state", "California");
        input.put("city", "Los Angeles");
        input.put("APPROVED", "APPROVED"); // ApprovalStatus
        input.put("ACTIVE", "ACTIVE");     // SourceOrgStatus
        Criteria result = QueryBuilder.buildCriteriaForSmartSearchSuggestions(input);
        assertNotNull(result);
    }

    @Test
    void testBuildSortOperationWithSortAndOrder() {
        SortOperation result = QueryBuilder.buildSortOperation("organizationName", "asc");
        assertNotNull(result);
    }

    @Test
    void testBuildDocumentForApprovalManager_rejectedStatus() {
        SearchFilter filter = new SearchFilter();
        filter.setStatuses(List.of(ApprovalStatus.REJECTED));
        Criteria result = QueryBuilder.buildDocumentForApprovalManager(filter);
        assertNotNull(result);
    }

    @Test
    void testBuildDocumentForApprovalManager_multipleStatuses() {
        SearchFilter filter = new SearchFilter();
        filter.setStatuses(List.of(ApprovalStatus.REJECTED, ApprovalStatus.APPROVED));
        Criteria result = QueryBuilder.buildDocumentForApprovalManager(filter);
        assertNotNull(result);
    }

    @Test
    void testBuildDocumentForApprovalManager_defaultsApplied() {
        SearchFilter filter = new SearchFilter(); // all fields null/empty
        Criteria result = QueryBuilder.buildDocumentForApprovalManager(filter);
        assertNotNull(result);
    }

    @Test
    void testGetSortPropertyMapped_cases() {
        assertEquals("payload.usedCount", QueryBuilder.getSortPropertyMapped("validated"));
        assertEquals("last_modified_date", QueryBuilder.getSortPropertyMapped("Last_Modified_Date"));
        assertEquals("payload.departmentName", QueryBuilder.getSortPropertyMapped("Department_Name"));
        assertEquals("payload.addressLine", QueryBuilder.getSortPropertyMapped(SearchConstants.SearchFields.LOCATION)); // Fix
        assertEquals("last_modified_date", QueryBuilder.getSortPropertyMapped("unknown_sort")); // default case
    }


    @Test
    void testGetSortPropertyMapped_moreCases() {
        assertEquals("last_modified_date", QueryBuilder.getSortPropertyMapped("unknown"));
        assertEquals("flagPriority", QueryBuilder.getSortPropertyMapped("flagPriority"));
        assertEquals("last_modified_date", QueryBuilder.getSortPropertyMapped("Last_Modified_Date"));
        assertEquals("last_modified_date", QueryBuilder.getSortPropertyMapped("LOCATION"));
        assertEquals("assignedTo", QueryBuilder.getSortPropertyMapped("Assigned_To"));
        assertEquals("approvalStatus", QueryBuilder.getSortPropertyMapped("Approval_Status"));
        assertEquals("createdBy", QueryBuilder.getSortPropertyMapped("Created_By"));
    }

    @Test
    void testAggregateWithMatch() {
        MatchOperation match = QueryBuilder.buildMatch(Criteria.where("city").is("NY"));
        FacetOperation facet = QueryBuilder.facetOperation(1, 10);
        ProjectionOperation projection = QueryBuilder.finalProjectionWithTotalCountInPipeline();

        Aggregation agg = QueryBuilder.aggregateWithMatch(match, facet, projection);
        Document doc = agg.toDocument("collectionName", Aggregation.DEFAULT_CONTEXT); // this line triggers the lambda
        assertNotNull(doc);
    }
    @Test
    void testSearchQuery_withNullStatus() {
        SearchDTO dto = SearchDTO.builder()
                .hon("HON123")
                .searchText("Text")
                .organizationType(OrganizationType.EDUCATION)
                .country("US")
                .build(); // no sourceOrganizationStatus

        var query = QueryBuilder.searchQuery(dto);
        assertNotNull(query);
    }




    @Test
    void testBuildSortOperation_flagPriority() {
        SortOperation result = QueryBuilder.buildSortOperation("flagPriority", "desc");
        assertNotNull(result);
    }
    @Test
    void testSmartSearchProjection() {
        ProjectionOperation operation = QueryBuilder.smartSearchProjection();
        assertNotNull(operation);
    }

    @Test
    void testGetSortOrderDirection() {
        assertEquals(org.springframework.data.domain.Sort.Direction.ASC, QueryBuilder.getSortOrderDirection("asc"));
        assertEquals(org.springframework.data.domain.Sort.Direction.DESC, QueryBuilder.getSortOrderDirection("desc"));
    }
}
