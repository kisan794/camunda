package com.hireright.sourceintelligence.service;
import com.hireright.sourceintelligence.api.dto.DateRange;
import com.hireright.sourceintelligence.api.dto.SearchResponseDTO;
import com.hireright.sourceintelligence.api.dto.UserInfo;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogFilters;
import com.hireright.sourceintelligence.domain.entity.MongoSearchResult;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.service.impl.CommonSearchImpl;
import com.hireright.sourceintelligence.service.impl.SearchHistoryServiceImpl;
import com.hireright.sourceintelligence.util.TestDataProvider;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.time.Instant;
import java.util.*;

import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.POSTAL_CODE;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.STATUS;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class SearchHistoryServiceTest {


    @InjectMocks
    private SearchHistoryServiceImpl searchHistoryServiceImpl;
    @Mock
    private CustomSourceRepository<Source> customSourceRepository;

    @Mock
    private SourceMapper sourceMapper;

    @Mock
    private CommonSearchImpl commonSearchImpl;


    @Test
    void getAutocompletedFiltersTest() {
        assertThatNoException().isThrownBy(() -> searchHistoryServiceImpl.getAutocompletedFilters(OrganizationType.EDUCATION,null,null));
    }

//    @Test
//    void getSourceOrganizationsByFiltersTest() {
//        UserInfo userInfo = TestDataProvider.getUserInfo();
//
//        when(customSourceRepository.customAggregate(any(), any(), any())).thenReturn(TestDataProvider.getMongoSearchHistoryResult());
//        Map<String, Set<String>> searchFilters = TestDataProvider.getSearchFilterForSourceHistoryList();
//        List<ApprovalStatus> approvalStatuses = Arrays.stream(ApprovalStatus.values()).toList();
//        assertThatNoException().isThrownBy(() -> searchHistoryServiceImpl.getSourceOrganizationsByFilters(OrganizationType.EDUCATION,searchFilters,approvalStatuses,1,10,userInfo));
//    }

//    @Test
//    void getSourceOrganizationsByFiltersTest_WhenUserIsManager() {
//        UserInfo userInfo = TestDataProvider.getUserInfo();
//        userInfo.setRoles(Arrays.asList("Manager"));
//        when(customSourceRepository.customAggregate(any(), any(), any())).thenReturn(TestDataProvider.getMongoSearchHistoryResult());
//        Map<String, Set<String>> searchFilters = TestDataProvider.getSearchFilterForSourceHistoryList();
//
//        List<ApprovalStatus> approvalStatuses = Arrays.stream(ApprovalStatus.values()).toList();
//        assertThatNoException().isThrownBy(() -> searchHistoryServiceImpl.getSourceOrganizationsByFilters(OrganizationType.EDUCATION,searchFilters,approvalStatuses,1,10,userInfo));
//    }

    @Test
    void getSourceOrganizationsByFiltersTest_WhenSearchListIsEmptyAndUserIsManager() {
        UserInfo userInfo = TestDataProvider.getUserInfo();
        userInfo.setRoles(Arrays.asList("Manager"));
        when(customSourceRepository.customAggregate(any(), any(), any())).thenReturn(TestDataProvider.getMongoSearchHistoryResult());
        Map<String, Set<String>> searchFilters = new HashMap<>();

        List<ApprovalStatus> approvalStatuses = new ArrayList<>();
        assertThatNoException().isThrownBy(() -> searchHistoryServiceImpl.getSourceOrganizationsByFilters(OrganizationType.EDUCATION,searchFilters,approvalStatuses,1,10,userInfo));
    }

//    @Test
//    void getSourceOrganizationsByFiltersTest_ResourceNotFound() {
//        MongoSearchResult mongoSearchResults = MongoSearchResult.builder()
//                .organizationList(new ArrayList<>())
//                .total(0).build();
//
//        when(customSourceRepository.customAggregate(any(), any(), any())).thenReturn(mongoSearchResults);
//        Map<String, Set<String>> searchFilters = TestDataProvider.getSearchFilterForSourceHistoryList();
//        UserInfo userInfo = TestDataProvider.getUserInfo();
//        List<ApprovalStatus> approvalStatuses = Arrays.stream(ApprovalStatus.values()).toList();
//        assertThatExceptionOfType(ResourceNotFoundException.class).isThrownBy(()  -> searchHistoryServiceImpl.getSourceOrganizationsByFilters(OrganizationType.EDUCATION,searchFilters,approvalStatuses,1,10,userInfo));
//    }

//    @Test
//    void getSourceOrganizationsByFiltersTest_ServiceExceptionOnSearchOnNonIndexedField() {
//        List<MongoSearchResult> mongoSearchResults = new ArrayList<>();
//        mongoSearchResults.add(TestDataProvider.getMongoSearchHistoryResult());
//
//        Map<String, Set<String>> searchFilter = new HashMap<>();
//        //non indexed field
//        searchFilter.put(STATUS, Set.of("ACTIVE"));
//        UserInfo userInfo = TestDataProvider.getUserInfo();
//        List<ApprovalStatus> approvalStatuses = new ArrayList<>();
//        assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(()  -> searchHistoryServiceImpl.getSourceOrganizationsByFilters(OrganizationType.EDUCATION,searchFilter,approvalStatuses,1,10,userInfo));
//    }
//
//    @Test
//    void getSourceOrganizationsByFiltersTest_WhenSearchFilterEmpty() {
//        List<MongoSearchResult> mongoSearchResults = new ArrayList<>();
//        mongoSearchResults.add(TestDataProvider.getMongoSearchHistoryResult());
//        when(customSourceRepository.customAggregate(any(), any(), any())).thenReturn(TestDataProvider.getMongoSearchHistoryResult());
//        UserInfo userInfo = TestDataProvider.getUserInfo();
//        List<ApprovalStatus> approvalStatuses = new ArrayList<>();
//        assertThatNoException().isThrownBy(() -> searchHistoryServiceImpl.getSourceOrganizationsByFilters(OrganizationType.EDUCATION,new HashMap<>(),approvalStatuses,1,10,userInfo));
//    }

//    @Test
//    void getChangeLogsByFiltersTest() {
//        List<MongoSearchResult> mongoSearchResults = new ArrayList<>();
//        mongoSearchResults.add(TestDataProvider.getMongoSearchHistoryResult());
//        when(customSourceRepository.customAggregate(any(), any(), any())).thenReturn(TestDataProvider.getMongoSearchHistoryResult());
//        DateRange dateRange = new DateRange();
//        dateRange.setEndDate(Instant.now());
//        dateRange.setStartDate(Instant.now());
//        Map<String, Set<String>> searchFilters = TestDataProvider.getSearchFilterForChangeLog();
//        assertThatNoException().isThrownBy(() -> searchHistoryServiceImpl.getChangeLogsByFilters(OrganizationType.EDUCATION,searchFilters,1,10,dateRange));
//    }


    @Test
    void changeLogsByFiltersTest_ShouldReturnEmptyResponseWhenNoResultsFound() {
        MongoSearchResult mongoSearchResults = MongoSearchResult.builder()
                .organizationList(new ArrayList<>())
                .total(0)
                .build();

        ChangeLogFilters searchFilters = TestDataProvider.getSearchFilterForChangeLogObject();
        DateRange dateRange = new DateRange();
        dateRange.setEndDate(Instant.now());
        dateRange.setStartDate(Instant.now());

        searchFilters.setOrganizationType(OrganizationType.EDUCATION);

        lenient().when(customSourceRepository.queryCount(any(), anyString(), eq(Source.class)))
                .thenReturn(0L);
        lenient().when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                .thenReturn(Collections.emptyList());

        SearchResponseDTO result = searchHistoryServiceImpl.getChangeLogsByFilters(searchFilters);

        assertNotNull(result, "Result should not be null");
        assertTrue(result.getSourceList().isEmpty(), "Source list should be empty");
        assertEquals(0L, result.getTotalItems(), "Total items should be 0");
        assertEquals(0, result.getTotalPages(), "Total pages should be 0");
    }


    @Test
    void getChangeLogsByFiltersTest_ShouldReturnEmptyResponseWhenNoResultsFound() {
        ChangeLogFilters searchFilters = TestDataProvider.getSearchFilterForChangeLogObject();

        MongoSearchResult mockSearchResult = new MongoSearchResult();
        mockSearchResult.setOrganizationList(Collections.emptyList());
        searchFilters.setOrganizationType(OrganizationType.EDUCATION);

        lenient().when(customSourceRepository.queryCount(any(), anyString(), eq(Source.class)))
                .thenReturn(0L);
        lenient().when(customSourceRepository.aggregate(any(), anyString(), eq(Source.class)))
                .thenReturn(Collections.emptyList());

        SearchResponseDTO result = searchHistoryServiceImpl.getChangeLogsByFilters(searchFilters);

        assertNotNull(result);
        assertEquals(0, result.getTotalItems());
        assertEquals(0, result.getTotalPages());
        assertTrue(result.getSourceList().isEmpty());
    }


    //@Test
    void getChangeLogsByFiltersTest_WhenSearchFilterEmpty() {
        lenient().when(customSourceRepository.customAggregate(any(), any(), any()))
                .thenReturn(TestDataProvider.getMongoSearchHistoryResult());
        DateRange dateRange = new DateRange();
        dateRange.setEndDate(Instant.now());
        dateRange.setStartDate(Instant.now());
        ChangeLogFilters changeLogFilters = new ChangeLogFilters();
        changeLogFilters.setPageSize(10);
        changeLogFilters.setStartPage(1);
        //changeLogFilters.setOrganizationType(OrganizationType.EDUCATION);
        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> searchHistoryServiceImpl.getChangeLogsByFilters(
                        changeLogFilters
                ));
    }
}