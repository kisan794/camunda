package com.hireright.sourceintelligence.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class RequestLoggingFilterConfigTest {


    @Test
    void requestLogFilterTest() {
        RequestLoggingFilterConfig requestLoggingFilterConfig = new RequestLoggingFilterConfig();
        CommonsRequestLoggingFilter  commonsRequestLoggingFilter = requestLoggingFilterConfig.requestLogFilter();
        assertThat(commonsRequestLoggingFilter).isNotNull();
    }
}