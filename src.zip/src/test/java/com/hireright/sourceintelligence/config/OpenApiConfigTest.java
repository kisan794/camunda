package com.hireright.sourceintelligence.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThatNoException;

@ExtendWith(MockitoExtension.class)
public class OpenApiConfigTest {

    @InjectMocks
   private OpenApiConfig openApiConfig;

    @Test
    void apiV1Test() {

        assertThatNoException().isThrownBy(() ->openApiConfig.apiV1());
    }

    @Test
    void apiV2Test() {

        assertThatNoException().isThrownBy(() ->openApiConfig.apiV2());
    }
}
