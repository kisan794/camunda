package com.hireright.sourceintelligence.config;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.*;
import org.mockito.MockitoAnnotations;
import org.springframework.web.client.RestClientException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HttpClientConfigTest {

    private static HttpServer server;
    private static int port;

    private HttpClientConfig httpClientConfig;

    @org.mockito.Mock
    private MultipartFile file;

    @BeforeAll
    static void startServer() throws IOException {
        server = HttpServer.create(new InetSocketAddress(0), 0);
        port = server.getAddress().getPort();
        server.createContext("/get", new SimpleHandler("GET", "ok-get"));
        server.createContext("/delete", new SimpleHandler("DELETE", "ok-delete"));
        server.start();
    }

    @AfterAll
    static void stopServer() {
        if (server != null) server.stop(0);
    }

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        httpClientConfig = new HttpClientConfig();
    }

    @Test
    void restClientPost_shouldThrowRestClientException() throws IOException {
        String url = "http://dummy.url/upload";
        String documentMeta = "meta";

        when(file.getBytes()).thenReturn("file-content".getBytes());
        when(file.getOriginalFilename()).thenReturn("test.txt");

        assertThrows(RestClientException.class,
                () -> HttpClientConfig.restClientPost(url, file, documentMeta));
    }

    @Test
    void recover_shouldReturnFailureMessage() {
        RestClientException exception = new RestClientException("Failed");
        String result = httpClientConfig.recover(exception, "http://url", file, "docMeta");
        assertEquals("Upload failed after retries!", result);
    }

    @Test
    void get_shouldReturnResponseBody() throws Exception {
        String url = "http://localhost:" + port + "/get";
        String body = HttpClientConfig.get(url);
        assertEquals("ok-get", body);
    }

    @Test
    void delete_shouldReturnResponseBody() throws Exception {
        String url = "http://localhost:" + port + "/delete";
        String body = HttpClientConfig.delete(url);
        assertEquals("ok-delete", body);
    }


    private static class SimpleHandler implements HttpHandler {
        private final String expectedMethod;
        private final String responseBody;

        SimpleHandler(String expectedMethod, String responseBody) {
            this.expectedMethod = expectedMethod;
            this.responseBody = responseBody;
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestMethod().equalsIgnoreCase(expectedMethod)) {
                exchange.sendResponseHeaders(405, -1);
                exchange.close();
                return;
            }
            byte[] bytes = responseBody.getBytes();
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        }
    }
}
