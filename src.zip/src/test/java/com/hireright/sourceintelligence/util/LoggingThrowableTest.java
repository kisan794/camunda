package com.hireright.sourceintelligence.util;

import com.hireright.sourceintelligence.constants.ErrorConstants;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import com.hireright.sourceintelligence.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.exception.ServiceException;
import org.junit.jupiter.api.Test;

import static com.hireright.sourceintelligence.util.LoggingThrowable.*;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

class LoggingThrowableTest {
@Test
void testlogAndThrowServiceException() {
    assertThatExceptionOfType(ServiceException.class)
            .isThrownBy(() -> {logAndThrowServiceException(ErrorConstants.SEARCH_TEXT_MISSING, null);});
}

    @Test
    void testlogAndThrowServiceExceptionTwo() {
        Exception exception =  new Exception("test");
        assertThatExceptionOfType(ServiceException.class)
                .isThrownBy(() -> {logAndThrowServiceException(ErrorConstants.SEARCH_TEXT_MISSING,exception);});
    }
    @Test
    void testlogAndThrowInvalidRequest() {
        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> {logAndThrowInvalidRequest(ErrorConstants.SEARCH_TEXT_MISSING, null);});
    }

    @Test
    void testlogAndThrowInvalidRequestTwo() {
        Exception exception =  new Exception("test");
        assertThatExceptionOfType(InvalidRequestException.class)
                .isThrownBy(() -> {logAndThrowInvalidRequest(ErrorConstants.SEARCH_TEXT_MISSING,exception);});
    }
    @Test
    void testlogAndThrowInternalServiceException() {
        assertThatExceptionOfType(ServiceException.class)
                .isThrownBy(() -> {logAndThrowInternalServiceException(ErrorConstants.SEARCH_TEXT_MISSING, null);});
    }

    @Test
    void testlogAndThrowInternalServiceExceptionTwo() {
        Exception exception =  new Exception("test");
        assertThatExceptionOfType(ServiceException.class)
                .isThrownBy(() -> {logAndThrowInternalServiceException(ErrorConstants.SEARCH_TEXT_MISSING,exception);});
    }


    @Test
    void testlogAndThrowResourceNotFound() {
        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> {logAndThrowResourceNotFound(ErrorConstants.SEARCH_TEXT_MISSING, null);});
    }

    @Test
    void testlogAndThrowResourceNotFoundTwo() {
        Exception exception =  new Exception("test");
        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> {logAndThrowResourceNotFound(ErrorConstants.SEARCH_TEXT_MISSING, exception);});
    }
    @Test
    void logAndThrowResourceNotFoundTest() {
        assertThatExceptionOfType(ResourceNotFoundException.class).isThrownBy(() -> logAndThrowResourceNotFound(ErrorConstants.SEARCH_TEXT_MISSING, null));
    }
    @Test
    void testlogAndThrowInternalResourceNotFound() {
        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> {logAndThrowInternalResourceNotFound(ErrorConstants.SEARCH_TEXT_MISSING, null);});
    }

    @Test
    void testlogAndThrowInternalResourceNotFoundTwo() {
        Exception exception =  new Exception("test");
        assertThatExceptionOfType(ResourceNotFoundException.class)
                .isThrownBy(() -> {logAndThrowInternalResourceNotFound(ErrorConstants.SEARCH_TEXT_MISSING, exception);});
    }

    @Test
    void logAndThrowInternalResourceNotFoundTest() {
        assertThatExceptionOfType(ResourceNotFoundException.class).isThrownBy(() -> logAndThrowInternalResourceNotFound(ErrorConstants.SEARCH_TEXT_MISSING, null));
    }
}