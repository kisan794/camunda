package com.hireright.sourceintelligence.util;

import static com.hireright.sourceintelligence.api.ApiConstants.HON;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.SearchOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogFilters;
import com.hireright.sourceintelligence.api.dto.history.Location;
import com.hireright.sourceintelligence.api.dto.history.SearchHistoryFilter;
import com.hireright.sourceintelligence.domain.entity.*;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.ChangeLogActivity;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SortOrder;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.mongodb.BasicDBObject;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.json.JSONArray;
import org.json.JSONObject;
import org.mapstruct.factory.Mappers;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class TestDataProvider {

    private static SourceMapper sourceMapper;

    public static SourceOrganizationDTO getSourceOrganizationDTO() {
        Alias[] orgAlias = new Alias[]{new Alias("AMZ", "en-US"),
                new Alias("Amazon Services Inc.", "en-US")};
        return SourceOrganizationDTO.builder()
                .hon(TestDataProvider.getHon())
                .organizationName("amazon")
                .organizationType(OrganizationType.EMPLOYMENT)
                .city("Long Beach")
                .country("USA")
                .state("California")
                .region("AMERICAS")
                .status(SourceOrganizationStatus.ACTIVE)
                .version(1.0)
                .organizationAlias(orgAlias)
                .reviewRequired("yes")
                .payload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\",\"country\": \"Germany\"," +
                        "\"state\": \"NorthEast\",\"created\": \"2020-01-16T03:11:07+0200\",\"lastApproverClass\": " +
                        "\"OPERATOR\",\"usedCount\": 30}"))
                .build();
    }

    public static SourceOrganizationDTO getSourceOrganizationHistoryDTO() {
        Alias[] orgAlias = new Alias[]{new Alias("AMZ", "en-US"),
                new Alias("Amazon Services Inc.", "en-US")};
        return SourceOrganizationDTO.builder()
                .hon(TestDataProvider.getHon())
                .organizationName("amazon")
                .organizationType(OrganizationType.EMPLOYMENT)
                .city("Long Beach")
                .country("USA")
                .region("AMERICAS")
                .state("California")
                .outOfBusiness(false)
                .status(SourceOrganizationStatus.ACTIVE)
                .approvalStatus(ApprovalStatus.APPROVED)
                .version(1.0)
                .organizationAlias(orgAlias)
                .requestedBy("requester")
                .payload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\",\"country\": \"Germany\"," +
                        "\"state\": \"NorthEast\",\"created\": \"2020-01-16T03:11:07+0200\",\"lastApproverClass\": " +
                        "\"OPERATOR\",\"usedCount\": 30}"))
                .build();
    }

    public static SourceOrganizationDTO getSourceOrganizationHistoryDTOTwo() {
        Alias[] orgAlias = new Alias[]{new Alias("AMZ", "en-US"),
                new Alias("Amazon Services Inc.", "en-US")};
        return SourceOrganizationDTO.builder()
                .hon(TestDataProvider.getHon())
                .organizationName("amazon")
                .organizationType(OrganizationType.EMPLOYMENT)
                .city("Long Beach")
                .country("USA")
                .state("California")
                .region("AMERICAS")
                .outOfBusiness(false)
                .status(SourceOrganizationStatus.ACTIVE)
                .approvalStatus(ApprovalStatus.APPROVED)
                .version(1.0)
                .organizationAlias(orgAlias)
                .requestedBy("requester")
                .payload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\",\"country\": \"Germany\"," +
                        "\"state\": \"NorthEast\",\"created\": \"2020-01-16T03:11:07+0200\",\"lastApproverClass\": " +
                        "\"OPERATOR\",\"usedCount\": 30,\"departmentName\": \"HR\",\"departmentAliases\": [\n" +
                        "      {\n" +
                        "        \"name\": \"HR\",\n" +
                        "        \"language\": \"en-US\"\n" +
                        "      },\n" +
                        "      {\n" +
                        "        \"name\": \"MECH\",\n" +
                        "        \"language\": \"en-US\"\n" +
                        "      }\n" +
                        "    ]}"))
                .build();
    }

    public static SourceOrganizationDTO getSourceOrganizationDTOTwo() {
        Alias[] orgAlias = new Alias[]{new Alias("Amazon", "en-US"), new Alias("Amazon Services Inc.", "en-US")};
        return SourceOrganizationDTO.builder()
                .hon(TestDataProvider.getHon())
                .organizationName("amazon56")
                .organizationType(OrganizationType.EMPLOYMENT)
                .city("New York")
                .country("USA")
                .region("AMERICAS")
                .state("NY")
                .status(SourceOrganizationStatus.ACTIVE)
                .version(1.0)
                .reviewRequired("yes")
                .organizationAlias(orgAlias)
                .payload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\",\"country\": \"USA\"," +
                        "\"state\": \"NorthEast\",\"created\": \"2020-01-16T03:11:07+0200\",\"lastApproverClass\": " +
                        "\"OPERATOR\", \"usedCount\": 30 }"))
                .build();
    }

    public static Source getSourceOrganizationEntity() {
        Alias[] orgAlias = new Alias[]{new Alias("AMZ", "en-US"), new Alias("Amazon Services Inc.", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setId(TestDataProvider.getDummyObjectId());
        sourceOrganization.setVersion(1.0);
        sourceOrganization.setHon(TestDataProvider.getHon());
        sourceOrganization.setCreatedDate(new Date().toInstant());
        sourceOrganization.setCreatedBy("Bob Smith");
        sourceOrganization.setOrganizationName("amazon56");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("Long Beach");
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("California");
        sourceOrganization.setReviewRequired("yes");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);
        //sourceOrganization.setLocation(com.hireright.common.enums.Location.US.getValue());
        sourceOrganization.setPayload(BasicDBObject.parse("{\"lastModified\": \"2020-01-16T03:11:07+0200\"," +
                "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\"," +
                "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
        return sourceOrganization;
    }

    public static Source getSourceEntity() {
        Alias[] orgAlias = new Alias[]{new Alias("AMZ", "en-US"), new Alias("Amazon Services Inc.", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setId(TestDataProvider.getDummyObjectId());
        sourceOrganization.setVersion(1.0);
        sourceOrganization.setHon(TestDataProvider.getHon());
        sourceOrganization.setCreatedDate(new Date().toInstant());
        sourceOrganization.setCreatedBy("Bob Smith");
        sourceOrganization.setOrganizationName("amazon56");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("Long Beach");
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("California");
        sourceOrganization.setReviewRequired("yes");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);
        //sourceOrganization.setLocation(com.hireright.common.enums.Location.US.getValue());
        sourceOrganization.setPayload(BasicDBObject.parse("{\"lastModified\": \"2020-01-16T03:11:07+0200\"," +
                "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\"," +
                "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
        return sourceOrganization;
    }

    public static Source getSourceOrganizationEntityTwo() {
        Alias[] orgAlias = new Alias[]{new Alias("AWS", "en-US"), new Alias("amazon.com", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setOrganizationName("amazon56");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("New York City");
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("NY");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);
        sourceOrganization.setPayload(BasicDBObject.parse("{\"lastModified\": \"2020-01-16T03:11:07+0200\"," +
                "\"country\": \"USA\",\"state\": \"New York\",\"created\": \"2020-01-16T03:11:07+0200\"," +
                "\"lastApproverClass\": \"OPERATOR\" ,\"usedCount\": 30}"));
        return sourceOrganization;
    }

    public static Source getSourceOrganizationEntityThree() {
        Alias[] orgAlias = new Alias[]{new Alias("Google", "en-US"), new Alias("Google.com", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setHon(TestDataProvider.getHon());
        sourceOrganization.setOrganizationName("google");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("California city" );
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("California");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);

        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setPath(ORGANIZATION_ALIAS);
        highlightDTO.setScore(Float.parseFloat("2.000"));
        highlightDTO.setTexts(Arrays.asList(new HitText("hit","google")));
        sourceOrganization.setHighlight(Arrays.asList(highlightDTO));
        sourceOrganization.setPayload(BasicDBObject.parse("{" +
                "\"departmentName\": \"HR\",\n" +
                "\"addressLine\": \"123 Main Street\",\n" +
                "\"lastCleanUpDate\": \"2022-05-17T22:02:08.345+0000\",\n" +
                "\"contactDetails\": [\n" +
                "{\n" +
                "    \"comments\": \"\",\n" +
                "    \"followUpAllowed\": \"false\",\n" +
                "    \"priority\": 2,\n" +
                "    \"type\": \"contactPhones\",\n" +
                "    \"followUpAllowedAfter\": \"\",\n" +
                "    \"turnAroundTime\": \"\",\n" +
                "    \"version\": \"1\",\n" +
                "    \"followUpAllowedAfterTimeUnit\": \"hours\",\n" +
                "    \"surChargeAmount\": \"\",\n" +
                "    \"name\": \"\",\n" +
                "    \"paymentMethod\": \"\",\n" +
                "    \"turnAroundTimeUnit\": \"hours\",\n" +
                "    \"surChargeCurrency\": \"USD\",\n" +
                "    \"communication\": [\n" +
                "        {\n" +
                "            \"communicationInfo\": [\n" +
                "                {\n" +
                "\"type\": \"country\",\n" +
                "\"value\": \"USA\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"countryCode\",\n" +
                "\"value\": \"US\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"currency\",\n" +
                "\"value\": \"USD\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"phoneCountryCode\",\n" +
                "\"value\": \"1\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"extension\",\n" +
                "\"value\": \"\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"phoneNumber\",\n" +
                "\"value\": \"458-9551\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"areaCode\",\n" +
                "\"value\": \"502\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"countryID\",\n" +
                "\"value\": \"1\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"useCode\": \"Default\",\n" +
                "            \"contactTimeFrom\": \"\",\n" +
                "            \"contactTimeZone\": \"\",\n" +
                "            \"name\": \"\",\n" +
                "            \"recipient\": \"\",\n" +
                "            \"comment\": \"\",\n" +
                "            \"department\": \"\",\n" +
                "            \"contactTimeTo\": \"\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"communicationInfo\": [\n" +
                "                {\n" +
                "\"type\": \"country\",\n" +
                "\"value\": \"USA\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"countryCode\",\n" +
                "\"value\": \"US\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"currency\",\n" +
                "\"value\": \"USD\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"phoneCountryCode\",\n" +
                "\"value\": \"1\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"extension\",\n" +
                "\"value\": \"\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"phoneNumber\",\n" +
                "\"value\": \"485-3011\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"areaCode\",\n" +
                "\"value\": \"502\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"countryID\",\n" +
                "\"value\": \"1\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"useCode\": \"Default\",\n" +
                "            \"contactTimeFrom\": \"\",\n" +
                "            \"contactTimeZone\": \"\",\n" +
                "            \"name\": \"\",\n" +
                "            \"recipient\": \"\",\n" +
                "            \"comment\": \"Dist Phone\",\n" +
                "            \"department\": \"\",\n" +
                "            \"contactTimeTo\": \"\"\n" +
                "        }\n" +
                "    ]\n" +
                "},\n" +
                "{\n" +
                "    \"comments\": \"\",\n" +
                "    \"followUpAllowed\": \"false\",\n" +
                "    \"priority\": 3,\n" +
                "    \"type\": \"contactFaxes\",\n" +
                "    \"followUpAllowedAfter\": \"\",\n" +
                "    \"turnAroundTime\": \"\",\n" +
                "    \"version\": \"1\",\n" +
                "    \"followUpAllowedAfterTimeUnit\": \"hours\",\n" +
                "    \"surChargeAmount\": \"\",\n" +
                "    \"name\": \"\",\n" +
                "    \"paymentMethod\": \"\",\n" +
                "    \"turnAroundTimeUnit\": \"hours\",\n" +
                "    \"surChargeCurrency\": \"USD\",\n" +
                "    \"communication\": [\n" +
                "        {\n" +
                "            \"communicationInfo\": [\n" +
                "                {\n" +
                "\"type\": \"country\",\n" +
                "\"value\": \"USA\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"countryCode\",\n" +
                "\"value\": \"US\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"currency\",\n" +
                "\"value\": \"USD\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"phoneCountryCode\",\n" +
                "\"value\": \"1\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"extension\",\n" +
                "\"value\": \"\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"phoneNumber\",\n" +
                "\"value\": \"454-8411\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"areaCode\",\n" +
                "\"value\": \"502\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"countryID\",\n" +
                "\"value\": \"1\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"faxValidationProcess\",\n" +
                "\"value\": \"02/07/2020\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"useCode\": \"Default\",\n" +
                "            \"contactTimeFrom\": \"\",\n" +
                "            \"contactTimeZone\": \"\",\n" +
                "            \"name\": \"\",\n" +
                "            \"recipient\": \"\",\n" +
                "            \"comment\": \"\",\n" +
                "            \"department\": \"\",\n" +
                "            \"contactTimeTo\": \"\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"communicationInfo\": [\n" +
                "                {\n" +
                "\"type\": \"country\",\n" +
                "\"value\": \"USA\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"countryCode\",\n" +
                "\"value\": \"US\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"currency\",\n" +
                "\"value\": \"USD\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"phoneCountryCode\",\n" +
                "\"value\": \"1\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"extension\",\n" +
                "\"value\": \"\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"phoneNumber\",\n" +
                "\"value\": \"485-3991\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"areaCode\",\n" +
                "\"value\": \"502\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"countryID\",\n" +
                "\"value\": \"1\"\n" +
                "                },\n" +
                "                {\n" +
                "\"type\": \"faxValidationProcess\",\n" +
                "\"value\": \"02/07/2020\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"useCode\": \"Default\",\n" +
                "            \"contactTimeFrom\": \"\",\n" +
                "            \"contactTimeZone\": \"\",\n" +
                "            \"name\": \"\",\n" +
                "            \"recipient\": \"\",\n" +
                "            \"comment\": \"\",\n" +
                "            \"department\": \"\",\n" +
                "            \"contactTimeTo\": \"\"\n" +
                "        }\n" +
                "    ]\n" +
                "},\n" +
                "{\n" +
                "    \"comments\": \"\",\n" +
                "    \"followUpAllowed\": \"false\",\n" +
                "    \"priority\": 1,\n" +
                "    \"type\": \"contactEmails\",\n" +
                "    \"followUpAllowedAfter\": \"\",\n" +
                "    \"turnAroundTime\": \"\",\n" +
                "    \"version\": \"1\",\n" +
                "    \"followUpAllowedAfterTimeUnit\": \"days\",\n" +
                "    \"surChargeAmount\": \"\",\n" +
                "    \"name\": \"\",\n" +
                "    \"paymentMethod\": \"\",\n" +
                "    \"turnAroundTimeUnit\": \"days\",\n" +
                "    \"surChargeCurrency\": \"USD\",\n" +
                "    \"communication\": [\n" +
                "        {\n" +
                "            \"communicationInfo\": [\n" +
                "                {\n" +
                "\"type\": \"address\",\n" +
                "\"value\": \" records@ahsrockets.org\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"useCode\": \"Default\",\n" +
                "            \"contactTimeFrom\": \"\",\n" +
                "            \"contactTimeZone\": \"\",\n" +
                "            \"name\": \"\",\n" +
                "            \"recipient\": \"\",\n" +
                "            \"comment\": \"\",\n" +
                "            \"department\": \"\",\n" +
                "            \"contactTimeTo\": \"\"\n" +
                "        }\n" +
                "    ]\n" +
                "}\n" +
                "                ]\n" +
                "            }}"));
        return sourceOrganization;
    }

    public static List<Source> getSourceOrganizationsForAutocompleteSearch(){
        List<Source> sourceOrganizations = new ArrayList<>();
        Source sourceOrganization = new Source();
        sourceOrganization.setOrganizationName("Acc");
        sourceOrganization.setCity("Acc Long city");
        sourceOrganization.setCountry("Access");
        sourceOrganization.setState("Acc State");
        sourceOrganization.setHighlight(Arrays.asList(new HighlightDTO(Float.parseFloat("2.0"),ORGANIZATION_NAME,Arrays.asList(new HitText("hit","Acc"))),
                new HighlightDTO(Float.parseFloat("1.0"),CITY,Arrays.asList(new HitText("hit","Acc"))),
                new HighlightDTO(Float.parseFloat("1.0"),COUNTRY,Arrays.asList(new HitText("hit","Acc"))),
                new HighlightDTO(Float.parseFloat("1.0"),STATE,Arrays.asList(new HitText("hit","Acc"))),
                new HighlightDTO(Float.parseFloat("1.0"),ORGANIZATION_ALIAS,Arrays.asList(new HitText("hit","Acc")))));

        Source sourceOrganization_one = new Source();
        sourceOrganization_one.setOrganizationName("Accenture");
        sourceOrganization_one.setPostalCode("30045");
        sourceOrganization_one.setHighlight(Arrays.asList(new HighlightDTO(Float.parseFloat("3.0"),ORGANIZATION_NAME,Arrays.asList(new HitText("hit","Accenture"))),
                new HighlightDTO(Float.parseFloat("3.0"),POSTAL_CODE,Arrays.asList(new HitText("hit","300")))));

        Source sourceOrganizationAlias = new Source();
        Alias alias[] = new Alias[1];
        alias[0] = new Alias("Accenture","");
        sourceOrganizationAlias.setOrganizationAlias(alias);
        sourceOrganizationAlias.setHighlight(Arrays.asList(new HighlightDTO(Float.parseFloat("2.0"),ORGANIZATION_ALIAS_NAME,Arrays.asList(new HitText("hit","Accenture")))));
        sourceOrganizations.add(sourceOrganizationAlias);
        sourceOrganizations.add(sourceOrganization);
        sourceOrganizations.add(sourceOrganization_one);
        return sourceOrganizations;
    }


    public static List<Source> getSourceOrganizationHistoryForAutocompleteSearch(){
        List<Source> sourceOrganizationHistories = new ArrayList<>();
        Source sourceOrganizationHistory = new Source();
        sourceOrganizationHistory.setHon("OUEDU-032322-SA38HJM");
        sourceOrganizationHistory.setOrganizationName("Acc");
        sourceOrganizationHistory.setCity("Acc Long city");
        sourceOrganizationHistory.setCountry("Access");
        sourceOrganizationHistory.setState("Acc State");
        sourceOrganizationHistory.setHighlight(Arrays.asList(new HighlightDTO(Float.parseFloat("2.0"),ORGANIZATION_NAME,Arrays.asList(new HitText("hit","Acc"))),
                new HighlightDTO(Float.parseFloat("1.0"),HON,Arrays.asList(new HitText("hit","OUEDU-032322-SA38HJM")))));

        Source sourceOrganization_one = new Source();
        sourceOrganization_one.setOrganizationName("Accenture");
        sourceOrganization_one.setPostalCode("30045");
        sourceOrganization_one.setHighlight(Arrays.asList(new HighlightDTO(Float.parseFloat("3.0"),ORGANIZATION_NAME,Arrays.asList(new HitText("hit","Accenture")))));
        sourceOrganizationHistories.add(sourceOrganizationHistory);
        sourceOrganizationHistories.add(sourceOrganization_one);
        return sourceOrganizationHistories;
    }

    public static List<Source> getIllegalSourceOrganizationHistoryForAutocompleteSearch(){
        List<Source> sourceOrganizationHistories = new ArrayList<>();
        Source sourceOrganizationHistory = new Source();
        sourceOrganizationHistory.setOrganizationName("Acc");
        sourceOrganizationHistory.setHighlight(Arrays.asList(new HighlightDTO(Float.parseFloat("1.0"),STATUS,Arrays.asList(new HitText("hit","Acc")))));
        sourceOrganizationHistories.add(sourceOrganizationHistory);
        return sourceOrganizationHistories;
    }


    public static String getHon() {
        return HonGenerator.createHon(OrganizationType.EDUCATION);
    }

    public static String getSourceId() {
        return HonGenerator.createHon(OrganizationType.EDUCATION)+":1";
    }

    public static List<SourceOrganizationDTO> getSourceOrganizationDTOList() {
        List<SourceOrganizationDTO> sourceOrganizationDTOList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            sourceOrganizationDTOList.add(getSourceOrganizationDTO());
            sourceOrganizationDTOList.add(getSourceOrganizationDTOTwo());
        }
        return sourceOrganizationDTOList;
    }

    public static List<Source> getSourceOrganizationList() {
        List<Source> sourceOrganizationList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            sourceOrganizationList.add(getSourceOrganizationEntity());
            sourceOrganizationList.add(getSourceOrganizationEntityTwo());
        }
        return sourceOrganizationList;
    }

    public static SearchDTO getSearchDTO() {
        return SearchDTO.builder()
                .hon(getHon())
                .sort(SortOrder.ASC)
                .organizationType(OrganizationType.EMPLOYMENT)
                .batchSize(5)
                .startIndex(1)
                .build();
    }

    public static SearchResponseDTO getOrganizationNamesDTO() {
        return SearchResponseDTO.builder()
                .sourceList(getSearchOrganizationDto())
                .organizationType(OrganizationType.EDUCATION)
                .currentPage(1)
                .totalItems(10)
                .totalPages(2)
                .build();
    }

    public static AddressDTO getAddressDTO() {
        AddressDTO addressDTO = new AddressDTO();
        addressDTO.setHon("OUEDU-032322-SA38HJM");
        addressDTO.setAddress(new JSONArray("[" +
                "{" +
                "\"useCode\":\"current\"," +
                "\"availablePeriod\":" +
                "{\"start\":\"\",\"end\":\"\"}," +
                "\"city\":\"LongBeach\"," +
                "\"countrySubDivisions\":" +
                "[" +
                "{\"type\":\"country\",\"value\":\"USA\"}," +
                "{\"type\":\"state\",\"value\":\"California\"}" +
                "]," +
                "\"geoLocation\":{}," +
                "\"countryCode\":\"US\"," +
                "\"line\":\"\"," +
                "\"reportedDate\":\"\",\"postalCode\":\"\"" +
                "}" +
                "]"));
        return addressDTO;
    }

    public static ContactDTO getContactDTO() {
        ContactDTO contactDTO = new ContactDTO();
        contactDTO.setHon("OUEDU-032322-SA38HJM");
        contactDTO.setContacts(new JSONArray(
                "[" +
                        "{" +
                        "\"validatedFlag\":\"\"," +
                        "\"lastValidatedDateTime\":\"\"," +
                        "\"purpose\":\"Default\"," +
                        "\"purposeRule\":[" + "{" + "\"name\":\"ragu125\"," + "\"value\":\"ragu125\"" + "}" + "]," +
                        "\"contactDetails\":[" +
                        "{" +
                        "\"comments\":\"\"," +
                        "\"followUpAllowed\":\"False\"," +
                        "\"priority\":1," +
                        "\"type\":\"contactPhones\"," +
                        "\"followUpAllowedAfter\":\"\"," +
                        "\"turnAroundTime\":\"\"," +
                        "\"version\":\"1\", " +
                        "\"followUpAllowedAfterTimeUnit\":\"hours\"," +
                        "\"surChargeAmount\":\"\"," +
                        "\"name\":\"\"," +
                        "\"paymentMethod\":\"\"," +
                        "\"turnAroundTimeUnit\":\"hours\"," +
                        "\"surChargeCurrency\":\"USD\"," +
                        "\"communication\":[" +
                        "{" + "\"communicationInfo\":[]," + "\"useCode\":\"Default\"," + "\"contactTimeFrom\":\"\"," +
                        "\"contactTimeZone\":\"\"," + "\"name\":\"\"," + "\"recipient\":\"\"," + "\"comment\":\"\"," +
                        "\"department\":\"\"," + "\"contactTimeTo\":\"\"" + "}" + "]" + "}" +
                        "]" +
                        "}" +
                        "]"
        ));
        return contactDTO;
    }

    public static Source getSourceOrganizationWithInvalidPayload() {
        Alias[] orgAlias = new Alias[]{new Alias("Google", "en-US"),
                new Alias("Google.com", "en-US")};
        Source sourceOrganization = new Source();
        sourceOrganization.setOrganizationName("google");
        sourceOrganization.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganization.setCity("California");
        sourceOrganization.setCountry("USA");
        sourceOrganization.setState("CA");
        sourceOrganization.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganization.setOrganizationAlias(orgAlias);
        sourceOrganization.setPayload(BasicDBObject.parse("{" +
                "\"addressLine\": \"123 Main Street\",\n" +
                "\"lastCleanUpDate\": \"2022-05-17T22:02:08.345+0000\",\n" +
                "\"contactDetails\": \"\"}"));
        return sourceOrganization;
    }

    public static SearchListDTO getSearchListDTO() {
        return SearchListDTO.builder()
                .organizations(Arrays.asList(new SearchOrganizationDTO()))
                .currentPage(1)
                .totalItems(10)
                .totalPages(2)
                .build();
    }

    public static SearchResponseDTO getSearchListHistoryDTO() {
        return SearchResponseDTO.builder()
                .sourceList(Arrays.asList(new SourceOrganizationDTO()))
                .currentPage(1)
                .totalItems(10)
                .totalPages(2)
                .build();
    }



    public static MongoSearchResult getMongoSearchResult() {
        return MongoSearchResult.builder()
                .organizationList(Arrays.asList(getSourceOrganizationEntityThree()))
                .total(1).build();
    }

    public static MongoSearchResult getMongoSearchHistoryResult() {
        return MongoSearchResult.builder()
                .organizationList(Arrays.asList(getSourceOrganizationEntity()))
                .total(1).build();
    }

    public static MongoSearchResult getMongoSearchResultWithInvalidPayload() {
        return MongoSearchResult.builder()
                .organizationList(Arrays.asList(getSourceOrganizationWithInvalidPayload()))
                .total(1).build();
    }

    public static List<AutocompleteSearchDTO> getAutocompleteSearchDto() {
        List<AutocompleteSearchDTO> autocompleteSearchDTOList = new ArrayList<>();
        //ALias
        AutocompleteSearchDTO autocompleteSearchDTO_2 = new AutocompleteSearchDTO();
        autocompleteSearchDTO_2.setCategory(ORGANIZATION_ALIAS);
        List<FieldValueInfo> matches_2 = new ArrayList<>();
        matches_2.add(new FieldValueInfo("AMZ",true,"","","","",""));
        matches_2.add(new FieldValueInfo("AMZ",true,"","","","",""));
        autocompleteSearchDTO_2.setMatches(matches_2);
        autocompleteSearchDTOList.add(autocompleteSearchDTO_2);

        //OrgName
        AutocompleteSearchDTO autocompleteSearchDTO_1 = new AutocompleteSearchDTO();
        autocompleteSearchDTO_1.setCategory(ORGANIZATION_NAME);
        List<FieldValueInfo> matches = new ArrayList<>();
        matches.add(new FieldValueInfo("Accenture",true,"","","","",""));
        autocompleteSearchDTO_1.setMatches(matches);

        return autocompleteSearchDTOList;
    }

    public static List<SourceOrganizationDTO> getSearchOrganizationDto() {
        sourceMapper = Mappers.getMapper(SourceMapper.class);
        List<SourceOrganizationDTO> searchOrganizationDTOS = sourceMapper.toSourceDTOList(Arrays.asList(getSourceOrganizationEntityThree()));
        return searchOrganizationDTOS;
    }

    public static List<SearchFilter> getAllSearchFilters(){
        List<SearchFilter> searchFilters = new ArrayList<>();
        searchFilters.add(SearchFilter.builder().searchField(ORGANIZATION_NAME).searchKey("Pedro Institute").build());
        searchFilters.add(SearchFilter.builder().searchField(ORGANIZATION_ALIAS_NAME).searchKey("Pedro").build());
        searchFilters.add(SearchFilter.builder().searchField(CITY).searchKey("c city").build());
        searchFilters.add(SearchFilter.builder().searchField(COUNTRY).searchKey("US").build());
        searchFilters.add(SearchFilter.builder().searchField(STATE).searchKey("California").build());
        searchFilters.add(SearchFilter.builder().searchField(POSTAL_CODE).searchKey("52033").build());
        return searchFilters;
    }

    public static Map<String, String> getSearchFiltersForSourceMatching(){
        Map<String, String> searchFilters = new HashMap<>();
        searchFilters.put(ORGANIZATION_NAME,"Google");
        searchFilters.put(CITY,"california city");
        searchFilters.put(COUNTRY,"USA");
        searchFilters.put(STATE,"California");
        return searchFilters;
    }

    public static ObjectId getDummyObjectId()
    {
        return new ObjectId();
    }

    public static Map<String, Set<String>>  getSearchFilterForChangeLog(){
        Map<String, Set<String>> searchFilter = new HashMap<>();
        Set<String> logFlag = new HashSet<>();
        logFlag.add(ChangeLogActivity.NEW_RECORD.getChangeLogActivity());
        logFlag.add(ChangeLogActivity.ARCHIVED.getChangeLogActivity());
        logFlag.add(ChangeLogActivity.DETAILS_CHANGED.getChangeLogActivity());
        searchFilter.put(LOG_FLAG, logFlag);

        searchFilter.put(ORGANIZATION_NAME,Set.of("pedro"));
        searchFilter.put(HON,Set.of("OUEDU-090122-3O2WXF5"));
        return searchFilter;
    }

    public static ChangeLogFilters getSearchFilterForChangeLogObject(){
        ChangeLogFilters searchFilter = new ChangeLogFilters();
        List<String> logFlag = new ArrayList<>();
        logFlag.add(ChangeLogActivity.NEW_RECORD.getChangeLogActivity());
        logFlag.add(ChangeLogActivity.ARCHIVED.getChangeLogActivity());
        logFlag.add(ChangeLogActivity.DETAILS_CHANGED.getChangeLogActivity());
        searchFilter.setActivities(logFlag);

        searchFilter.setOrganizationName("pedro");
        searchFilter.setOrganizationType(OrganizationType.EDUCATION);
        searchFilter.setPageSize(10);
        searchFilter.setStartPage(1);
        return searchFilter;
    }

    public static Map<String, Set<String>>  getSearchFilterForSourceHistoryList(){
        Map<String, Set<String>> searchFilter = new HashMap<>();
        Set<String> organizationTypes = new HashSet<>();
        Arrays.stream(OrganizationType.values()).forEach(x-> organizationTypes.add(x.toString()));
        searchFilter.put(ORGANIZATION_TYPE, organizationTypes);

        searchFilter.put(ORGANIZATION_NAME,Set.of("pedro"));
        searchFilter.put(HON,Set.of("OUEDU-090122-3O2WXF5"));

        Set<String> assignees = new HashSet();
        assignees.add("Unassigned");
        searchFilter.put(ASSIGNED_TO,assignees);

        Set<String> regions = new HashSet();
        regions.add("APAC");
        searchFilter.put(STATE,regions);

        Set<String> countries = new HashSet();
        countries.add("USA");
        searchFilter.put(COUNTRY,countries);

        return searchFilter;
    }

    public static List<ApprovalStatus> getApprovalStatuses () {
        return  Arrays.stream(ApprovalStatus.values()).toList();
    }

        public static SearchHistoryFilter getSearchHistoryFilter () {
        SearchHistoryFilter searchHistoryFilter = new SearchHistoryFilter();
        searchHistoryFilter.setStatuses(Arrays.stream(ApprovalStatus.values()).toList());
        searchHistoryFilter.setVerificationTypes(Arrays.stream(OrganizationType.values()).toList());
        Set<String> assignees = new HashSet();
        assignees.add("Unassigned");
        Set<String> regions = new HashSet();
        regions.add("APAC");
        Set<String> countries = new HashSet();
        countries.add("USA");
        searchHistoryFilter.setAssignees(assignees);
        Location location = new Location();
        location.setRegions(regions);
        location.setCountries(countries);
        searchHistoryFilter.setLocations(location);
        return searchHistoryFilter;
    }

    public static Source getSourceOrganizationHistoryEntity() {
        Alias[] orgAlias = new Alias[]{new Alias("AMZ", "en-US"), new Alias("Amazon Services Inc.", "en-US")};
        Source sourceOrganizationHistory = new Source();
        sourceOrganizationHistory.setId(TestDataProvider.getDummyObjectId());
        sourceOrganizationHistory.setHon(TestDataProvider.getHon());
        sourceOrganizationHistory.setCreatedDate(new Date().toInstant());
        sourceOrganizationHistory.setCreatedBy("Bob Smith");
        sourceOrganizationHistory.setOrganizationName("amazon56");
        sourceOrganizationHistory.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganizationHistory.setCity("Long Beach");
        sourceOrganizationHistory.setCountry("USA");
        sourceOrganizationHistory.setState("California");
        //sourceOrganizationHistory.setFlagPriority(true);
        sourceOrganizationHistory.setAssignedTo("Unassigned");
        sourceOrganizationHistory.setApprovedBy("abc");
        //sourceOrganizationHistory.setApprovalStatus(ApprovalStatus.APPROVED);
        sourceOrganizationHistory.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganizationHistory.setOrganizationAlias(orgAlias);
        sourceOrganizationHistory.setRequestedBy("username");
        sourceOrganizationHistory.setLastModifiedDate(Instant.now());
        //sourceOrganizationHistory.setLogFlag("Details changed");
        sourceOrganizationHistory.setAssignedId("username");
        sourceOrganizationHistory.setRequesterId("username");
        //sourceOrganizationHistory.setLocation(com.hireright.common.enums.Location.US.getValue());
        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setPath(ORGANIZATION_ALIAS);
        highlightDTO.setScore(Float.parseFloat("2.000"));
        highlightDTO.setTexts(Arrays.asList(new HitText("hit","google")));
        sourceOrganizationHistory.setHighlight(Arrays.asList(highlightDTO));
        sourceOrganizationHistory.setPayload(BasicDBObject.parse("{\"lastModified\": \"2020-01-16T03:11:07+0200\"," +
                "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\"," +
                "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
        return sourceOrganizationHistory;
    }

    public static List<Source> getSourceOrganizationHistoryEntities() {
        Alias[] orgAlias = new Alias[]{new Alias("AMZ", "en-US"), new Alias("Amazon Services Inc.", "en-US")};
        Source sourceOrganizationHistory = new Source();
        sourceOrganizationHistory.setId(TestDataProvider.getDummyObjectId());
        sourceOrganizationHistory.setHon(TestDataProvider.getHon());
        sourceOrganizationHistory.setCreatedDate(new Date().toInstant());
        sourceOrganizationHistory.setCreatedBy("Bob Smith");
        sourceOrganizationHistory.setOrganizationName("amazon56");
        sourceOrganizationHistory.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganizationHistory.setCity("Long Beach");
        sourceOrganizationHistory.setCountry("USA");
        sourceOrganizationHistory.setState("California");
        //sourceOrganizationHistory.setFlagPriority(true);
        sourceOrganizationHistory.setAssignedTo("Unassigned");
        sourceOrganizationHistory.setApprovedBy("abc");
        sourceOrganizationHistory.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganizationHistory.setOrganizationAlias(orgAlias);
        sourceOrganizationHistory.setVersion(1.0);
        //sourceOrganizationHistory.setApprovalStatus(ApprovalStatus.APPROVED);
        HighlightDTO highlightDTO = new HighlightDTO();
        highlightDTO.setPath(ORGANIZATION_ALIAS);
        highlightDTO.setScore(Float.parseFloat("2.000"));
        highlightDTO.setTexts(Arrays.asList(new HitText("hit","google")));
        sourceOrganizationHistory.setHighlight(Arrays.asList(highlightDTO));
        sourceOrganizationHistory.setPayload(BasicDBObject.parse("{\"lastModified\": \"2020-01-16T03:11:07+0200\"," +
                "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\"," +
                "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));


        Alias[] orgAlias_two = new Alias[]{new Alias("AMZ", "en-US"), new Alias("Amazon Services Inc.", "en-US")};
        Source sourceOrganizationHistory_two = new Source();
        sourceOrganizationHistory_two.setId(TestDataProvider.getDummyObjectId());
        sourceOrganizationHistory_two.setHon(TestDataProvider.getHon());
        sourceOrganizationHistory_two.setCreatedDate(new Date().toInstant());
        sourceOrganizationHistory_two.setCreatedBy("Bob Smith");
        sourceOrganizationHistory_two.setOrganizationName("amazon56");
        sourceOrganizationHistory_two.setOrganizationType(OrganizationType.EMPLOYMENT);
        sourceOrganizationHistory_two.setCity("Long Beach");
        sourceOrganizationHistory_two.setCountry("USA");
        sourceOrganizationHistory_two.setState("California");
        //sourceOrganizationHistory_two.setFlagPriority(true);
        sourceOrganizationHistory_two.setAssignedTo("Unassigned");
        sourceOrganizationHistory_two.setApprovedBy("abc");
        sourceOrganizationHistory_two.setVersion(2.0);
        sourceOrganizationHistory_two.setStatus(SourceOrganizationStatus.ACTIVE);
        sourceOrganizationHistory_two.setOrganizationAlias(orgAlias_two);
        //sourceOrganizationHistory_two.setApprovalStatus(ApprovalStatus.APPROVED);
        HighlightDTO highlightDTO_two = new HighlightDTO();
        highlightDTO_two.setPath(ORGANIZATION_ALIAS);
        highlightDTO_two.setScore(Float.parseFloat("2.000"));
        highlightDTO_two.setTexts(Arrays.asList(new HitText("hit","google")));
        sourceOrganizationHistory_two.setHighlight(Arrays.asList(highlightDTO_two));
        sourceOrganizationHistory_two.setPayload(BasicDBObject.parse("{\"lastModified\": \"2020-01-16T03:11:07+0200\"," +
                "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\"," +
                "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));


        return Arrays.asList(sourceOrganizationHistory,sourceOrganizationHistory_two);
    }

    public static UserInfo getUserInfo(){
        return  UserInfo.builder()
                .username("username")
                .primaryUserName("primaryName")
                .roles(Arrays.asList("QualityAnalyst"))
                .build();
    }

    public static UIActionsDTO getUIActionsDTO(){
        return  UIActionsDTO.builder()
                .userAction("Save")
                .userTrustScore(99)
                .userEmail("madhavi.e@hireright.com")
                .userName("Madhavi E")
                .build();
    }

    public static AutoMatchDTO testData(){
        AutoMatchDTO inputData = new AutoMatchDTO();
        inputData.setSourceType("EDUCATION");
        inputData.setSourceName("Libby High School");
        inputData.setCity("Libby");
        inputData.setCountry("USA");
        inputData.setState("Montana");
        return inputData;
    }
}
