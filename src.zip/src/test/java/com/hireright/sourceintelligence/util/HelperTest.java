package com.hireright.sourceintelligence.util;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import com.hireright.sourceintelligence.exception.InvalidRequestException;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNoException;

@ExtendWith(MockitoExtension.class)
public class HelperTest {

    @Test
    void prepareSearchFiltersTest() {
        assertThatNoException().isThrownBy(()-> Helper.prepareSearchFilters("","city","country","state"));
    }

    @Test
    void prepareSearchFiltersCityTest() {
        assertThatNoException().isThrownBy(()-> Helper.prepareSearchFilters("","","country","state"));
    }

    @Test
    void prepareSearchFiltersStateTest() {
        assertThatNoException().isThrownBy(()-> Helper.prepareSearchFilters("","city","country",""));
    }

    @Test
    void prepareSearchFiltersCountryTest() {
        assertThatNoException().isThrownBy(()-> Helper.prepareSearchFilters("","","country",""));
    }

    @Test
    void validateThresholdLimitTest() {
        assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(()-> Helper.validateThresholdLimit(2.0));
    }

    @Test
    void getCollectionNameTest() {
        assertThatExceptionOfType(InvalidRequestException.class).isThrownBy(()-> Helper.getCollectionName("emp","test"));
    }
}
