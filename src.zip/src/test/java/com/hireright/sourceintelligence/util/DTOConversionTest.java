package com.hireright.sourceintelligence.util;


import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.v2.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.mapper.SourceV2Mapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DTOConversionTest {

    @Mock
    private SourceV2Mapper sourceV2Mapper;

    @InjectMocks
    private DTOConversion dtoConversion;

    @Test
    void convertV2DtoV1DtoTest() {
        SourceDTO source = new SourceDTO();
        source.setPayload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\","
                + "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\","
                + "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
        JSONArray addressArray = new JSONArray();

        JSONObject address = new JSONObject();
        address.put("countryCode", "123");
        address.put("state", "state");
        address.put("city", "Los Angeles");
        address.put("zipCode", "90001");
        address.put("country", "USA");
        addressArray.put(address);
        JSONArray additionalInfo = new JSONArray();
        additionalInfo.put("addionalInfo");

        source.getPayload().put("addionalInfo", additionalInfo);
        source.getPayload().put("address", addressArray);
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setHon("honId");
        sourceOrganizationDTO.setPayload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\","
                + "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\","
                + "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
        when(sourceV2Mapper.sourceDTOtoSourceOrganizationDTO(any())).thenReturn(sourceOrganizationDTO);
        assertThatNoException()
                .isThrownBy(() ->dtoConversion.convertV2DtoToV1Dto(source));

    }

    @Test
    void convertV1DtoToV2DtoTest() {
        SourceDTO source = new SourceDTO();
        source.setPayload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\","
                + "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\","
                + "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));

        JSONArray additionalInfo = new JSONArray();
        additionalInfo.put("addionalInfo");

        source.getPayload().put("addionalInfo", additionalInfo);
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setHon("honId");
        sourceOrganizationDTO.setPayload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\","
                + "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\","
                + "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
        sourceOrganizationDTO.getPayload().put("addionalInfo", additionalInfo);
        when(sourceV2Mapper.sourceOrganizationDTOtoSourceDTO(any())).thenReturn(source);
        assertThatNoException()
                .isThrownBy(() ->dtoConversion.convertV1DtoToV2Dto(sourceOrganizationDTO));

    }

    @Test
    void convertV1ListToV2ListTest() {
        List<SourceOrganizationDTO> sourceV1List = new ArrayList<>();
        List<SourceDTO> sourceDTOList = new ArrayList<>();
        SourceDTO source = new SourceDTO();
        source.setPayload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\","
                + "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\","
                + "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));

        JSONArray additionalInfo = new JSONArray();
        additionalInfo.put("addionalInfo");

        source.getPayload().put("addionalInfo", additionalInfo);
        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setHon("honId");
        sourceOrganizationDTO.setPayload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\","
                + "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\","
                + "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
        sourceV1List.add(sourceOrganizationDTO);
        sourceDTOList.add(source);
        when(sourceV2Mapper.toSourceDTOList(any())).thenReturn(sourceDTOList);
        assertThatNoException()
                .isThrownBy(() ->dtoConversion.convertV1ListToV2List(sourceV1List));

    }

    @Test
    void convertV1ListToV2ListWthEmptySourceListTest() {
        List<SourceOrganizationDTO> sourceV1List = new ArrayList<>();
        List<SourceDTO> sourceDTOList = new ArrayList<>();
        SourceDTO source = new SourceDTO();
        source.setPayload(null);

        SourceOrganizationDTO sourceOrganizationDTO = new SourceOrganizationDTO();
        sourceOrganizationDTO.setHon("honId");
        sourceOrganizationDTO.setPayload(new JSONObject("{\"lastModified\": \"2020-01-16T03:11:07+0200\","
                + "\"country\": \"USA\",\"state\": \"California\",\"created\": \"2020-01-16T03:11:07+0200\","
                + "\"lastApproverClass\": \"OPERATOR\", \"usedCount\": 30}"));
        sourceV1List.add(sourceOrganizationDTO);
        sourceDTOList.add(source);
        when(sourceV2Mapper.toSourceDTOList(any())).thenReturn(sourceDTOList);
        assertThatNoException()
                .isThrownBy(() ->dtoConversion.convertV1ListToV2List(sourceV1List));

    }


}