package com.hireright.sourceintelligence.util;

import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import org.junit.jupiter.api.Test;

import java.util.HashMap;

import static com.hireright.sourceintelligence.util.HonGenerator.getDurstenfeldShuffle;
import static org.junit.jupiter.api.Assertions.*;
import static org.assertj.core.api.Assertions.assertThat;

class HonGeneratorTest {

    @Test
    void getUniqueStringTest() {

        HashMap<String, Integer> map = new HashMap<>(10000000);
        for (int i = 0; i < 1000000; i++) {
            String key = getDurstenfeldShuffle();
            // log.info("i is " + i + " " + key);
            try {
                map.put(key,i);
            } catch (Exception e) {
                fail("Unique Fail: Key is : " + key);
            }
        }
        assertThat(map).isNotEmpty();
    }

    @Test
    void createHonTest() {

        String hon = HonGenerator.createHon(OrganizationType.EDUCATION);
        assertThat(hon)
                .isNotEmpty()
                .contains("OUEDU");
        hon = HonGenerator.createHon(OrganizationType.EMPLOYMENT);
        assertThat(hon)
                .isNotEmpty()
                .contains("OUEMP");
    }

    @Test
    void getCurrentDateAsMMDDYYFormat() {
        assertThat(HonGenerator.getCurrentDateAsMMDDYYFormat()).isNotEmpty();
    }
}