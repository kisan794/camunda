/*
 * @(#)$RCSfile: StringAssert.java,v $Revision: 1.3 $ $Date: 2007/10/25 15:02:46 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/tests/junit/StringAssert.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev		2007-01-18	created
 * 	A.Solntsev		2007-08-27	Added methods assertContains(), assertStartsWith(), assertEndsWith()
 */
package hireright.tests.junit;

import junit.framework.Assert;

/**
 * @author asolntsev
 * @since Feb 13, 2007
 * @version $Revision: 1.3 $ $Date: 2007/10/25 15:02:46 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/tests/junit/StringAssert.java,v $
 */
public class StringAssert
{
	public static void assertInteger(String sInteger) throws AssertionError
	{
		try
		{
			Integer.parseInt(sInteger);
			// It'a all right, sInteger contains valid integer number
		}
		catch (NumberFormatException nfe)
		{
			throw new AssertionError(nfe);
		}
	}

	public static void assertEqualsIgnoreCase(String sExpected, String sExisting)
	{
		Assert.assertTrue("Expected: '" + sExpected + "', but received: '" + sExisting + "'",
				sExpected.equalsIgnoreCase(sExisting));
	}

	public static void assertContains(String sSubstring, String sActual)
	{
		if (sSubstring == null && sActual == null)
			return;

		if (sActual == null)
		{
			throw new AssertionError("String is expected to contain " + sSubstring +
				", but received: null");
		}
		if (sSubstring == null)
			return;

		if (sActual.indexOf(sSubstring) == -1)
		{
			throw new AssertionError("String is expected to contain " + sSubstring +
				", but received: " + sActual);
		}
	}

	public static void assertStartsWith(String sSubstring, String sActual)
	{
		if (sSubstring == null && sActual == null)
			return;

		if (sActual == null)
		{
			throw new AssertionError("String is expected to start with " + sSubstring +
				", but received: null");
		}
		if (sSubstring == null)
			return;

		if (!sActual.startsWith(sSubstring))
		{
			throw new AssertionError("Strrng is expected to start with " + sSubstring +
				", but received: " + sActual);
		}
	}

	public static void assertEndsWith(String sSubstring, String sActual)
	{
		if (sSubstring == null && sActual == null)
			return;

		if (sActual == null)
		{
			throw new AssertionError("String is expected to end with " + sSubstring +
				", but received: null");
		}
		if (sSubstring == null)
			return;

		if (!sActual.endsWith(sSubstring))
		{
			throw new AssertionError("Strrng is expected to end with " + sSubstring +
				", but received: " + sActual);
		}
	}
}
