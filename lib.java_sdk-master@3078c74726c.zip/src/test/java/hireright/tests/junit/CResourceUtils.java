package hireright.tests.junit;

import java.net.URL;

import junit.framework.TestCase;

/**
 * 
 * @author asolntsev
 * @version $Revision: 1.3 $, $Date: 2008/06/06 07:32:24 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/tests/junit/CResourceUtils.java,v $
 */
public class CResourceUtils
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
	
	/**
	 *
	 * @param sFilePath for example, "/hireright/sdk/html/parser/some_file.xml"
	 * @return absolute URL for file containing requested resource
	 * @throws AssertionFailedError null if no such resource found
	 */
	public static URL getResource(String sFilePath)
	{
		String sFileUrl = sFilePath;
		URL fileUrl = CResourceUtils.class.getResource(sFileUrl);
		TestCase.assertNotNull("File " + sFilePath + " is not found", fileUrl);

		return fileUrl;
	}

	public static URL getResource(Class testClass, String sFileName)
	{
		String sFilePath;
		if (testClass.getPackage() == null)
			sFilePath = "/" + sFileName;
		else
		{
			String sClassName = testClass.getPackage().getName();
			sFilePath = "/" + sClassName.replaceAll("\\.", "/") + "/" + sFileName;
		}


		return getResource(sFilePath);
	}

}
