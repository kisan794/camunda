/*
 * @(#)$RCSfile: NumberAssert.java,v $Revision: 1.2 $ $Date: 2007/10/25 15:02:33 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/tests/junit/NumberAssert.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-08-28	created
 */
package hireright.tests.junit;

/**
 * @author Andrei Solntsev
 * @since Aug 28, 2007
 * @version $Revision: 1.2 $ $Date: 2007/10/25 15:02:33 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/tests/junit/NumberAssert.java,v $
 */
public class NumberAssert
{
	public static void assertGreater(int greater, int lesser) throws AssertionError
	{
		if (lesser >= greater)
		{
			throw new AssertionError("Number " + greater + " is expected to be greater than " + lesser);
		}
	}

	public static void assertGreater(String sMessage, int greater, int lesser) throws AssertionError
	{
		if (lesser >= greater)
		{
			throw new AssertionError(sMessage + " [" + greater + " <= " + lesser + " ]");
		}
	}

	public static void assertGreaterOrEqual(int greater, int lesser) throws AssertionError
	{
		if (lesser > greater)
		{
			throw new AssertionError("Number " + greater + " is expected to be greater or equal than " + lesser);
		}
	}

	public static void assertGreaterOrEqual(String sMessage, int greater, int lesser) throws AssertionError
	{
		if (lesser > greater)
		{
			throw new AssertionError(sMessage + " [" + greater + " < " + lesser + " ]");
		}
	}
}
