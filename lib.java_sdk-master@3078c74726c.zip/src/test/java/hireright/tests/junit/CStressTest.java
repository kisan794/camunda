/*
 * @(#)$RCSfile: CStressTest.java,v $ $Revision: 1.7 $ $Date: 2010/03/11 21:42:02 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/tests/junit/CStressTest.java,v $ 
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Andrei Solntsev		2006-05-xx	Created
 *	Andrei Solntsev		2007-02-13	Does not extend CDBTestCase
 *	A.Solntsev				2010-03-05	Use log4j instead of commons-logging.
 */
package hireright.tests.junit;

import java.io.Serializable;
import java.sql.Connection;

import org.apache.log4j.Logger;

import hireright.sdk.db.CConnection;
import hireright.sdk.db.CCurrentThreadConnection;

/**
 * Utilities for running stress tests which consume a lot of memory and CPU.
 * Typically these are not standard JUnit test.
 *
 * --- Under construction ---
 *
 * @author Andrei Solntsev
 * @since 2006
 */
public abstract class CStressTest implements Serializable
{
	private static final Logger log = Logger.getLogger(CStressTest.class);
	
	// private String m_sTestName;
	private int m_nSize = 0;
	private int m_nOutput = 1;

	protected CStressTest(@SuppressWarnings("unused") String sTestName, int size, int output)
	{
		// m_sTestName = sTestName;
		m_nSize = size;
		m_nOutput = output;
	}

	protected final void setSize(int size)
	{
		m_nSize = size;
	}

	protected final Connection getConnection()
	{
		return CCurrentThreadConnection.getConnection();
	}

	@SuppressWarnings("unused")
	protected void setUp() throws Exception
	{
		// override if needed
	}

	@SuppressWarnings("unused")
	protected void tearDown() throws Exception
	{
		// override if needed
	}

	public void runTest() throws Exception
	{
		Connection conn = CConnection.initThreadLocalConnection();
		setUp();

		log.info("Steps \t" + "Free mem." + " \t/\t " +	"Total mem.");
		try
		{
			for (int i=0; i<m_nSize; i++)
			{
				if (m_nOutput > 0 && i % m_nOutput == 0)
				{
					dumpMemory(String.valueOf(i));
				}
				iteration();
			}
		}
		finally
		{
			CConnection.closeConnection(conn);
			CCurrentThreadConnection.unbind();
		}

		tearDown();

		System.gc();
		dumpMemory("ALL");
	}

	protected abstract void iteration() throws Exception;



	private void dumpMemory(String sState)
	{
		long free = Runtime.getRuntime().freeMemory() / 1024;

		long total = Runtime.getRuntime().maxMemory() / 1024;

		log.info(" " + sState + " \t" +
				formatMemory(free)  + " \t/\t " +	formatMemory(total));
	}

	private String toString(int n, int len, char c)
	{
		return fixlength(String.valueOf(n), len, c);
	}

	private String fixlength(String s, int len, char c)
	{
		final StringBuilder sb = new StringBuilder(len);
		for (int i=s.length(); i<len; i++)
			sb.append(c);
		sb.append( s );
		return sb.toString();
	}

	private String formatMemory(long lMemorySize)
	{
		String sRes = toString( (int) (lMemorySize / 1024), 2, ' ')
					+ "." + toString( (int) (lMemorySize % 1024), 3, '0');

		return sRes;
	}
}