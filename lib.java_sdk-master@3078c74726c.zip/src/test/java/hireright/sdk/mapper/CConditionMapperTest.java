package hireright.sdk.mapper;
/*
 * Copyright 2001-2021 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *
 *  D.Shchur        2021-06-11  Created.
 */

import junit.framework.TestCase;

import java.util.LinkedHashMap;
import java.util.function.Function;

public class CConditionMapperTest extends TestCase
{
	
	public void testEmptyMap() {
		CConditionMapper<Object, String> mapper = CConditionMapperBuilder.<Object, String>builder()
			.build();
		
		assertNull(mapper.getMatchFor(new Object()));
	}
	
	public void testDefaultValue() {
		CConditionMapper<Object, String> mapper = CConditionMapperBuilder.<Object, String>builder()
			.withDefaultValue("defaultValue")
			.build();
		
		assertEquals("defaultValue", mapper.getMatchFor(new Object()));
	}
	
	public void testObjectMapping() {
		Object entry = new Object();
		
		CConditionMapper<Object, String> mapper = CConditionMapperBuilder.<Object, String>builder()
			.put(entry, "entry")
			.build();
		
		assertEquals("entry", mapper.getMatchFor(entry));
		assertNull(mapper.getMatchFor(new Object()));
	}
	
	public void testObjectMappingInSpecialOrder() {
		//mapper should return first matching
		Integer entry = new Integer(4);
		
		CConditionMapper<Number, String> mapper = CConditionMapperBuilder.<Number, String>builder()
			.put(4, "another four")
			.put(entry, "four")
			.build();
		
		assertEquals("another four", mapper.getMatchFor(entry));
		assertNull(mapper.getMatchFor(4L));
	}
	
	public void testFunctionMapping() {
		CConditionMapper<Integer, String> mapper = CConditionMapperBuilder.<Integer, String>builder()
			.put(integer -> integer > 2, "bigger than 2")
			.build();
		
		assertEquals("bigger than 2", mapper.getMatchFor(3));
		assertNull(mapper.getMatchFor(1));
	}
	
	public void testFunctionMappingInSpecialOrder() {
		CConditionMapper<Integer, String> mapper = CConditionMapperBuilder.<Integer, String>builder()
			.put(integer -> integer > 9, "bigger than 9")
			.put(integer -> integer > 8, "bigger than 8")
			.put(integer -> integer > 7, "bigger than 7")
			.put( 7, "It's 7")
			.put(integer -> integer > 6, "bigger than 6")
			.put(integer -> integer > 5, "bigger than 5")
			.put(integer -> integer > 4, "bigger than 4")
			.build();
		
		assertEquals("bigger than 8", mapper.getMatchFor(9));
		assertEquals("It's 7", mapper.getMatchFor(7));
		assertEquals("bigger than 5", mapper.getMatchFor(6));
		assertNull(mapper.getMatchFor(1));
	}
	
	public void testFunctionMappingInSpecialOrder2() {
		CConditionMapper<Integer, String> mapper = CConditionMapperBuilder.<Integer, String>builder()
			.put(integer -> integer > 4, "bigger than 4")
			.put(integer -> integer > 5, "bigger than 5")
			.put(integer -> integer > 6, "bigger than 6")
			.put( 7, "It's 7")
			.put(integer -> integer > 7, "bigger than 7")
			.put(integer -> integer > 8, "bigger than 8")
			.put(integer -> integer > 9, "bigger than 9")
			.build();
		
		assertEquals("bigger than 4", mapper.getMatchFor(9));
		assertEquals("bigger than 4", mapper.getMatchFor(7));
		assertEquals("bigger than 4", mapper.getMatchFor(6));
		assertNull(mapper.getMatchFor(1));
	}
	
	public void testMappingInTheBegging() {
		CConditionMapper<Integer, String> mapper = CConditionMapperBuilder.<Integer, String>builder()
			.put(integer -> integer > 9, "bigger than 9")
			.put(integer -> integer > 8, "bigger than 8")
			.put(integer -> integer > 7, "bigger than 7")
			.put( 7, "It's 7")
			.put(integer -> integer > 6, "bigger than 6")
			.put(integer -> integer > 5, "bigger than 5")
			.build();
		
		mapper.addFirst(integer -> integer > 4, "bigger than 4");
		
		assertEquals("bigger than 4", mapper.getMatchFor(9));
		assertEquals("bigger than 4", mapper.getMatchFor(7));
		assertEquals("bigger than 4", mapper.getMatchFor(6));
		assertNull(mapper.getMatchFor(1));
	}
	
	public void testMappingInTheEnd() {
		CConditionMapper<Integer, String> mapper = CConditionMapperBuilder.<Integer, String>builder()
			.put(integer -> integer > 9, "bigger than 9")
			.put(integer -> integer > 8, "bigger than 8")
			.put(integer -> integer > 7, "bigger than 7")
			.put( 7, "It's 7")
			.put(integer -> integer > 6, "bigger than 6")
			.put(integer -> integer > 5, "bigger than 5")
			.build();
		
		LinkedHashMap<Function<Integer, Boolean>, String> additionalMapping = new LinkedHashMap<>();
		additionalMapping.put(integer -> integer > 3, "bigger than 3");
		additionalMapping.put(integer -> integer == 3, "It's 3");
		
		mapper.addLast(additionalMapping);
		
		assertEquals("bigger than 8", mapper.getMatchFor(9));
		assertEquals("bigger than 3", mapper.getMatchFor(5));
		assertEquals("It's 3", mapper.getMatchFor(3));
		assertNull(mapper.getMatchFor(1));
	}
}
