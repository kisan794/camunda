/*
 * Copyright 2001-2022 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *
 * Y.Banadyseu	2022-07-07 HRG-156300: created.
 */
package hireright.sdk.db2;

import javax.persistence.Entity;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Entity
public class CEntityJavaxWithLambda {
	private String field;
	
	public String getField() {
		return field;
	}
	
	public void setField(String field) {
		this.field = field;
	}
	
	public List<String> getFieldsFilled() {
		List<String> tmp = new ArrayList<>();
		tmp.add("1");
		tmp.add("2");

		return tmp.stream().filter(i -> i.equals("1")).collect(Collectors.toList());
	}
}
