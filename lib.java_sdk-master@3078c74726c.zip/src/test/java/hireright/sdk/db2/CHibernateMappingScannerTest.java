/*
 * Copyright 2001-2022 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *
 * Y.Banadyseu	2022-07-07 HRG-156300: created.
 */
package hireright.sdk.db2;

import junit.framework.TestCase;
import java.util.List;
import java.util.stream.Collectors;

public class CHibernateMappingScannerTest  extends TestCase {
	private static final String BASE_PACKAGE = "hireright.sdk.db2";
	private static final int REAL_COUNT_ENTITIES = 3;
	
	public void testEntitiesMapping() {
		CHibernateMappingScanner scanner = new CHibernateMappingScanner(BASE_PACKAGE);
		List<CHibernateMappingScanner.CHibernateMappingItem> items = scanner.scan();
		assertEquals(REAL_COUNT_ENTITIES, items.size());
		
		List<Class<?>> testClasses = items
			.stream()
			.filter(CHibernateMappingScanner.CHibernateMappingItem::isClass)
			.map(CHibernateMappingScanner.CHibernateMappingItem::getClazz)
			.collect(Collectors.toList());
		
		assertTrue(testClasses.contains(CEntityJavaxWithLambda.class));
		assertTrue(testClasses.contains(CEntityHibernateWithLambda.class));
		
		List<String> testRecourses = items
			.stream()
			.filter(CHibernateMappingScanner.CHibernateMappingItem::isNotClass)
			.map(i -> i.getURL().toString())
			.collect(Collectors.toList());
		
		assertTrue(testRecourses
			.stream()
			.anyMatch(i -> i.contains("CEntityXmlResourceWithLambda")));
	}
}
