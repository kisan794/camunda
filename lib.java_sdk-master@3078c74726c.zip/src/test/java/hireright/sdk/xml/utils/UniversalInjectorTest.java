/*
 * @(#)$RCSfile: UniversalInjectorTest.java,v $Revision: 1.2 $ $Date: 2007/09/14 09:19:23 $ $Author: asolntsev $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-01-18	created
 */
package hireright.sdk.xml.utils;

import java.io.IOException;

import junit.framework.TestCase;

import hireright.sdk.util.CFileContent;
import hireright.sdk.xml.parser.XMLObjectException;

/**
 * @author asolntsev
 * @since May 4, 2007
 * @version $Revision: 1.2 $ $Date: 2007/09/14 09:19:23 $ $Author: asolntsev $
 */
public class UniversalInjectorTest extends TestCase
{
	public void testParseXml_FIXME() throws IOException, XMLObjectException
	{
		String sSampleXML = CFileContent.getContent(
			getClass().getClassLoader().getResource(
			"hireright/sdk/xml/utils/test_UniversalInjector.xml"));

		UniversalInjector injector = new UniversalInjector();

		// injector.parseOutput(sSampleXML);
		//assertNotNull(injector.getOutputRootNode());
	}
}
