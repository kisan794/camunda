/*
 * @(#)$RCSfile: XMLValidatorTest.java,v $Revision: 1.5 $ $Date: 2011/01/20 21:24:09 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/xml/utils/XMLValidatorTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 *	A.Solntsev			2007-01-18	created
 *	A.Solntsev			2008-09-01	using test-server instead of (hardcoded) production
 *	A.Solntsev			2008-12-29	Now unit tests do not depend on AS resources (use only local files)
 */
package hireright.sdk.xml.utils;

import hireright.sdk.util.CFileContent;

import java.io.IOException;

import junit.framework.TestCase;

/**
 * @author asolntsev
 * @since Mar 9, 2007
 * @version $Revision: 1.5 $ $Date: 2011/01/20 21:24:09 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/xml/utils/XMLValidatorTest.java,v $
 */
public class XMLValidatorTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	public void testInvalidXSD() throws IOException
	{
		String sInvalidXML = CFileContent.getContent(
			getClass().getClassLoader().getResource(
			"hireright/sdk/xml/utils/invalid_xml.xml"));

		String sXsdUrl = //GeneralSettings.getHttpResRoot() +  "/designs/n-age/" +
				//"cingular/employment_application/3-0/xsd/personal_information.xsd";
			getClass().getClassLoader().getResource(
				"hireright/sdk/xml/utils/xsd/personal_information.xsd").toString();
			
		assertFalse(XMLValidator.validate(sInvalidXML, sXsdUrl));
	}
}
