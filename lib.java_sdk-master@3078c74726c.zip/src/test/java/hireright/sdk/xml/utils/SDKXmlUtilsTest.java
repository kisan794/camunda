package hireright.sdk.xml.utils;
import junit.framework.TestCase;
import org.w3c.dom.Document;

/**
 * Junit-test for class SDKXmlUtils
 * 
 * @author	Andrei Solntsev
 * @date		2005-04-07
 * @since		java_sdk_v2-5-22_jdk14
 */
public class SDKXmlUtilsTest extends TestCase
{
	Document doc = null;
	
	String sBody =
		"<Person>" +
		"	<Action>Applicant.Create</Action>"+
		"	<CandidateRecordInfo>"+
		"		<Id valid=\"true\">"+
		"			<IdValue>9392929</IdValue>"+
		"		</Id>"+
		"	</CandidateRecordInfo>"+
		"	<ContactInfo>"+
		"		<PersonName>"+
		"			<FormattedName>Jill Candidate</FormattedName>" +
		"			<GivenName prefix=\"sd\">my given name</GivenName>"+
		"		</PersonName>"+
		"	</ContactInfo>"+
		"</Person>";

	String sXPath = "Person/ContactInfo/PersonName/GivenName";
	String sXPath2 = "Person/ContactInfo/PersonName[FormattedName!='']/GivenName";
	
	public SDKXmlUtilsTest()
	{
		super("UTest for class SDKXmlUtils");
	}
	
	public void setUp()
	{
		doc = SDKXmlUtils.buildDocument(sBody);
		assertNotNull(doc);

		//assertEquals(sBody, SDKXmlUtils.serializeDocument(doc));
	}
	
	public void test_getNodeValueByPath()
	{
		assertEquals("my given name", SDKXmlUtils.getNodeValueByPath(doc, sXPath));
		assertEquals("my given name", SDKXmlUtils.getNodeValueByPath(doc, sXPath2));
		assertNull(SDKXmlUtils.getNodeValueByPath(doc, sXPath + sXPath2));
	}

	public void test_setNodeValueByPath()
	{
		assertTrue(SDKXmlUtils.setNodeValueByPath(doc, sXPath, "his given name"));
		assertEquals("his given name", SDKXmlUtils.getNodeValueByPath(doc, sXPath));
		
		assertTrue(SDKXmlUtils.setNodeValueByPath(doc, sXPath2, "their given name"));
		assertEquals("their given name", SDKXmlUtils.getNodeValueByPath(doc, sXPath2));
		
		assertFalse(SDKXmlUtils.setNodeValueByPath(doc, sXPath + sXPath2, "our given name"));
		assertFalse(SDKXmlUtils.setNodeValueByPath(doc, sXPath + sXPath2, null));
	}
	
	public void test_getAttributeByPath()
	{
		assertEquals("sd", SDKXmlUtils.getAttributeByPath(doc, sXPath, "prefix"));
		assertEquals("true", SDKXmlUtils.getAttributeByPath(doc, "/Person/CandidateRecordInfo/Id", "valid"));
		assertNull(SDKXmlUtils.getAttributeByPath(doc, "/PersoN/CandidateRecordInfo/Id", "valid"));
	}
	
	public void test_getDOMNodeValue()
	{
		assertEquals("Applicant.Create", SDKXmlUtils.getDOMNodeValue(doc, "Action"));
		assertEquals("9392929", SDKXmlUtils.getDOMNodeValue(doc, "IdValue"));
		assertNull(SDKXmlUtils.getDOMNodeValue(doc, "ActioN"));
	}

	public void test_getDOMNode()
	{
		assertNotNull(SDKXmlUtils.getDOMNode(doc, "Action"));
		assertNotNull(SDKXmlUtils.getDOMNode(doc, "IdValue"));
		assertNull(SDKXmlUtils.getDOMNodeValue(doc, "ActioN"));
	}
}