/*
 * @(#)$RCSfile: RegexpFileFilterTest.java,v $Revision: 1.5 $ $Date: 2009/09/11 13:47:35 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/io/RegexpFileFilterTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 *	A.Solntsev			2007-09-09		created
 *	A.Solntsev			2007-09-21		Added test-cases for Unix paths
 *	A.Solntsev			2009-02-03		Added optional parameter rootFolder
 */
package hireright.sdk.io;

import java.io.File;
import java.io.FilenameFilter;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

/**
 * @author asolntsev
 * @since Sep 9, 2007
 * @version $Revision: 1.5 $ $Date: 2009/09/11 13:47:35 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/io/RegexpFileFilterTest.java,v $
 */
public class RegexpFileFilterTest extends TestCase
{
	/*
	public void testSimpleRegexp()
	{
		FilenameFilter filter = new RegexpFileFilter("*.class");
		assertTrue(filter.accept(new File("."), "RegexpFileFilterTest.class"));
	}*/

	/**
	 * TODO I don't understand what this method tests... :( 
	 * 
	 * Is it useful at all?
	 */
	public void testMatches()
	{
		ClassLoader cl = Thread.currentThread().getContextClassLoader();// RegexpFileFilter.class.getClass().getClassLoader();
		while (cl != null)
		{
			if (cl instanceof URLClassLoader)
				break;
			cl = cl.getParent();
		}

		if (cl == null)
			return;
		
		FilenameFilter filter = new RegexpFileFilter("**/RegexpFileFilter.class");

		URLClassLoader urlCL = (URLClassLoader) cl;
		URL[] urls = urlCL.getURLs();

		List<File> foundFiles = new ArrayList<File>();

		URL urlCodeSource;
		for (int i=0; i<urls.length; i++)
		{
			urlCodeSource = urls[i];
			File fCodeSource = new File(urlCodeSource.getPath());
			if (fCodeSource.canRead() && fCodeSource.isDirectory())
			{
				File[] list = fCodeSource.listFiles(filter);
				if (list == null || list.length == 0)
					continue;

				/*assertTrue("Expected to find 2-3 folders, but received: " + list, list.length > 1);
				assertEquals("common", list[0].getName());
				assertEquals("designs", list[1].getName());
				// assertEquals("hireright", list[2].getName());
				foundFiles.add(list[0]);
				foundFiles.add(list[1]);
				// foundFiles.add(list[2]);
				*/
				break;
			}
		}

		// assertFalse(foundFiles.isEmpty());
	}

	private static String urlToFile(URL u)
	{
		StringBuffer result = new StringBuffer(10);
		if (u.getAuthority() != null && u.getAuthority().length() > 0)
		{
			result.append("//");
			result.append(u.getAuthority());
		}

		if (u.getPath() != null)
		{
			String sFilePath = u.getPath();
			while (sFilePath.startsWith("/"))
				sFilePath = sFilePath.substring(1);

			result.append(sFilePath);
		}
		return result.toString();
	}

	public void test_unixDir()
	{
		String sDir = "/export/home/special/continuum/data/continuum-working-directory/6/components.service.sdk/target/classes/hireright/objects/service";

		RegexpFileFilter filter = new RegexpFileFilter("**/*.hbm.xml");

		assertTrue( filter.accept(new File(sDir), sDir + "/VerificationSubject.hbm.xml") );
	}

	public void testUnixName()
	{
		RegexpFileFilter filter = new RegexpFileFilter(
				new File("export/home/special/continuum/data/continuum/working-directory/23/java_sdk/target/test-classes"), "/hireright/**/*.class");
		
		assertTrue(filter.accept(
				new File("export/home/special/continuum/data/continuum/working-directory/23/java_sdk/target/test-classes/hireright/sdk/io"), 
				"RegexpFileFilterTest.class") );
	}
	
	public void testThisClass()
	{
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		URL urlClassesFolder = cl.getResource("");
		URL urlThisClass = cl.getResource("hireright/sdk/io/RegexpFileFilterTest.class");
		
		File classesFolder = new File(urlToFile(urlClassesFolder));
		String sThisClass = urlToFile(urlThisClass);
		File fThisClass = new File(sThisClass);
		File parentFolder = fThisClass.getParentFile();	// .getParentFile();
		if (!parentFolder.isDirectory())
		{
			// This class is loaded from JAR, not folder. This test is useless is this case.
			return;
		}

		RegexpFileFilter filter1 = new RegexpFileFilter("**/*.classes");
		assertFalse( "Filter " + filter1 + " should accept file {" + parentFolder + ", " + fThisClass.getName() + ")",
				filter1.accept(parentFolder, fThisClass.getName()) );

		RegexpFileFilter filter2 = new RegexpFileFilter("**/*.class");
		assertTrue( "Filter " + filter2 + " should accept file {" + parentFolder + ", " + fThisClass.getName() + ")",
				filter2.accept(parentFolder, fThisClass.getName()) );
		
		RegexpFileFilter filter3 = new RegexpFileFilter("**/hireright/**/*.class");
		assertTrue( "Filter " + filter3 + " should accept file {" + parentFolder + ", " + fThisClass.getName() + ")",
				filter3.accept(parentFolder, fThisClass.getName()) );
		
		RegexpFileFilter filter4 = new RegexpFileFilter(classesFolder, "/hireright/**/*.class");
		assertTrue( "Filter " + filter4 + " should accept file {" + parentFolder + ", " + fThisClass.getName() + ")",
				filter4.accept(parentFolder, fThisClass.getName()) );
	}
}
