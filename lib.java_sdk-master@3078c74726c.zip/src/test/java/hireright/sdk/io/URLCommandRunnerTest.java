/*
 * @(#)$RCSfile: URLCommandRunnerTest.java,v $ $Revision: 1.4 $ $Date: 2009/02/09 12:38:14 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/io/URLCommandRunnerTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev		2008-11-18	Created
 *	A.Solntsev		2009-01-22	2 sec -> 4 sec (sometimes this test failed on CI server)
 *	A.Solntsev		2009-02-03	Read local file instead of google.com
 */
package hireright.sdk.io;

import hireright.tests.junit.CResourceUtils;

import java.net.URL;

import junit.framework.TestCase;

/**
 * @author  Vladimir Lazarev
 * @version $Revision: 1.4 $ $Date: 2009/02/09 12:38:14 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/io/URLCommandRunnerTest.java,v $
 */
public class URLCommandRunnerTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	public void testRunUrl() throws InterruptedException
	{
		URL unexpectedErrorUrl = CResourceUtils.getResource("/designs/general/xhtml/error.xhtml");
		assertNotNull(unexpectedErrorUrl);
		
		URLCommandRunner runner = new URLCommandRunner();
		assertTrue("Failed to load local file in 2 seconds, got error: " + runner.getLastError(),
				runner.executeRequest(unexpectedErrorUrl.toString(), 2000));	// "http://www.google.com"
		
		assertTrue("Reading local file should not contain Http headers", runner.getHeaders().isEmpty() );
		assertTrue("Local file does not contain file path 'projects_src/lib/java_sdk/src/test/resources/designs/general/xhtml/error.xhtml'",
				new String(runner.getContent()).indexOf("projects_src/lib/java_sdk/src/test/resources/designs/general/xhtml/error.xhtml") > -1 );
		assertNull("Error occurred while reading local file '/designs/general/xhtml/error.xhtml': " 
				+ runner.getLastError(), runner.getLastError());
	}
}
