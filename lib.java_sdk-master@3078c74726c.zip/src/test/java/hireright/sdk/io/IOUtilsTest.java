/*
 * @(#)$RCSfile: IOUtilsTest.java,v $Revision: 1.3 $ $Date: 2008/06/19 12:06:24 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/io/IOUtilsTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2008-05-08	created
 *	A.Solntsev			2008-06-16	Added function removeDuplicatedSlashes()
 */
package hireright.sdk.io;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import junit.framework.TestCase;

/**
 * @author asolntsev
 * @since Aug 30, 2007
 * @version $Revision: 1.3 $ $Date: 2008/06/19 12:06:24 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/io/IOUtilsTest.java,v $
 */
public class IOUtilsTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
	
	public void testCloseSilently()
	{
		IOUtils.closeSilently( new ByteArrayInputStream(new byte[100]) );
		IOUtils.closeSilently( new InputStreamReader( new ByteArrayInputStream(new byte[100]) ) );
		
		IOUtils.closeSilently( new ByteArrayOutputStream() );
		IOUtils.closeSilently( new PrintWriter( new ByteArrayOutputStream() ) );
	}
	
	public void test_removeDuplicatedSlashes()
	{
		assertNull(IOUtils.removeDuplicatedSlashes(null));
		assertEquals("", IOUtils.removeDuplicatedSlashes(""));
		assertEquals("abc", IOUtils.removeDuplicatedSlashes("abc"));
		assertEquals("http://usa.com", IOUtils.removeDuplicatedSlashes("http://usa.com"));
		assertEquals("http://usa.com/index.html", IOUtils.removeDuplicatedSlashes("http://usa.com//index.html"));
	}
	
	public void testPrintText()
	{
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		IOUtils.printText( out, "Bruce Willis rules" );
		assertEquals("Bruce Willis rules", out.toString());
	}
	
	public void testReadText() throws IOException
	{
		ByteArrayInputStream in = new ByteArrayInputStream( "Bruce Willis rules".getBytes() );
		assertEquals("Bruce Willis rules", IOUtils.readText( in ));
	}
	
	public void testReadBytes() throws IOException
	{
		ByteArrayInputStream in = new ByteArrayInputStream( "Bruce Willis rules".getBytes() );
		assertEquals("Bruce Willis rules", new String(IOUtils.readBytes( in )));
	}
	
	public void testPost_TODO()
	{
		// TODO: Post some content to google.com, hireright.com or whatever site
	}
}
