/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	msuhhoruki	2017-10-02	Created
 */
package hireright.sdk.time;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.TestCase;

public class CTDateTest extends TestCase
{
	public void testValueOf()
		throws ParseException
	{
		String sControlDate = "2010-10-20";
		Date date = new SimpleDateFormat("yyyy-MM-dd").parse(sControlDate);
		CTDate tdate = CTDate.valueOf(date);
		assertEquals(tdate.getYear(), Integer.valueOf(2010));
		assertEquals(tdate.getMonth(), Integer.valueOf(10));
		assertEquals(tdate.getDay(), Integer.valueOf(20));
		assertEquals(tdate.getTDate(), sControlDate);
		assertEquals(tdate.getDate().getTime(), date.getTime());
	}
}
