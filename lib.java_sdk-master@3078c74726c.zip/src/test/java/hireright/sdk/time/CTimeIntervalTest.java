/*
 * @(#)$RCSfile: CTimeIntervalTest.java,v $ $Revision: 1.3 $ $Date: 2014/03/15 07:35:15 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/time/CTimeIntervalTest.java,v $
 *
 * Copyright 2001-2012 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	A.Tanasenko		14.12.2012		Created
 */
package hireright.sdk.time;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.TestCase;

/**
 * @author atanasenko
 *
 */
public class CTimeIntervalTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
	
	public void testNormalize()
	{
		// leap year
		CTimeInterval interval = CTimeInterval.parseInterval("60 days");
		assertEquals("2 months", interval.normalizeAdd(parseDate("2012-01-15")).toString());
		assertEquals("2 months", interval.normalizeAdd(parseDate("2012-01-31")).toString());
		
		// non-leap year
		interval = CTimeInterval.parseInterval("59 days");
		assertEquals("2 months", interval.normalizeAdd(parseDate("2014-01-15")).toString());
		assertEquals("2 months", interval.normalizeAdd(parseDate("2014-01-31")).toString());
		
		
		interval = CTimeInterval.parseInterval("61 days");
		assertEquals("2 months 2 days", interval.normalizeAdd(parseDate("2014-01-15")).toString());
		assertEquals("2 months 2 days", interval.normalizeAdd(parseDate("2014-01-31")).toString());
		
		assertEquals("2 months 2 days", interval.normalizeAdd(parseDate("2014-02-15")).toString());
		assertEquals("2 months 2 days", interval.normalizeAdd(parseDate("2014-02-28")).toString());
		assertEquals("2 months", interval.normalizeAdd(parseDate("2014-03-01")).toString());
	}
	
	public void testBidirectional()
	{
		CTimeInterval interval = CTimeInterval.parseInterval("60 days");
		Date date1 = parseDate("2012-01-31");
		Date date2 = interval.addTo(date1);
		
		assertEquals(date1, interval.subtractFrom(date2));
	}
	
	public void testDiff()
	{
		Date date1 = parseDate("2012-01-31");
		Date date2 = parseDate("2012-03-31");
		
		assertEquals("2 months", CTimeInterval.diff(date1, date2).toString());
	}
	
	public void testCompareTo()
	{
		CTimeInterval interval6m = CTimeInterval.parseInterval("6 months");
		CTimeInterval interval6m_another = CTimeInterval.parseInterval("6 months");
		CTimeInterval interval6m1d = CTimeInterval.parseInterval("6 months 1 day");
		CTimeInterval interval6m28d = CTimeInterval.parseInterval("6 months 28 days");
		CTimeInterval interval12m = CTimeInterval.parseInterval("11 months");

		int nCompareTo6m_6m = interval6m.compareTo(interval6m_another);
		int nCompareTo6m_6m1d = interval6m.compareTo(interval6m1d);
		int nCompareTo6m1d_6m = interval6m1d.compareTo(interval6m);
		int nCompareTo6m_6m28d = interval6m.compareTo(interval6m28d);
		int nCompareTo6m28d_6m = interval6m28d.compareTo(interval6m);
		int nCompareTo6m_12m = interval6m.compareTo(interval12m);
		int nCompareTo12m_6m = interval12m.compareTo(interval6m);

		int nCompareTo6m_6m_sub = interval6m.compareTo(interval6m_another, new Date(), false);
		int nCompareTo6m_6m1d_sub = interval6m.compareTo(interval6m1d, new Date(), false);
		int nCompareTo6m1d_6m_sub = interval6m1d.compareTo(interval6m, new Date(), false);
		int nCompareTo6m_6m28d_sub = interval6m.compareTo(interval6m28d, new Date(), false);
		int nCompareTo6m28d_6m_sub = interval6m28d.compareTo(interval6m, new Date(), false);
		int nCompareTo6m_12m_sub = interval6m.compareTo(interval12m, new Date(), false);
		int nCompareTo12m_6m_sub = interval12m.compareTo(interval6m, new Date(), false);

		assertEquals(0, nCompareTo6m_6m);
		assertTrue(nCompareTo6m_6m1d < 0);
		assertTrue(nCompareTo6m1d_6m > 0);
		assertTrue(nCompareTo6m_6m28d < 0);
		assertTrue(nCompareTo6m28d_6m > 0);
		assertTrue(nCompareTo6m_12m < 0);
		assertTrue(nCompareTo12m_6m > 0);
		
		assertEquals(0, nCompareTo6m_6m_sub);
		assertTrue(nCompareTo6m_6m1d_sub < 0);
		assertTrue(nCompareTo6m1d_6m_sub > 0);
		assertTrue(nCompareTo6m_6m28d_sub < 0);
		assertTrue(nCompareTo6m28d_6m_sub > 0);
		assertTrue(nCompareTo6m_12m_sub < 0);
		assertTrue(nCompareTo12m_6m_sub > 0);
	}
	
	private Date parseDate(String date)
	{
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		try
		{
			return df.parse(date);
		}
		catch (ParseException e)
		{
			throw new IllegalArgumentException(e);
		}
	}

}
