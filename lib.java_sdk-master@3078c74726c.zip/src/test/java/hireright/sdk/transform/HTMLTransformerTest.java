/*
 * @(#)$RCSfile: HTMLTransformerTest.java,v $ $Revision: 1.5 $ $Date: 2011/01/20 21:23:51 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/transform/HTMLTransformerTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev			2006-10-03	Created
 *	A.Solntsev			2007-06-25	Added testing of cached XSLTs' loading time
 *	A.Solntsev			2008-10-24	Performance improvement: read local file instead of remote XSLT
 *	A.Solntsev			2008-10-31	System.currentTimeMillis() replaced by System.nanoTime()
 */
package hireright.sdk.transform;
import hireright.sdk.util.CFileContent;
import hireright.sdk.util.CStringUtils;

import java.io.IOException;
import java.io.StringWriter;
import java.net.URL;

import javax.xml.transform.TransformerException;

import junit.framework.TestCase;

/**
 *
 * @author Andrei Solntsev
 * @since 2006-10-03
 * @version $Revision: 1.5 $ $Date: 2011/01/20 21:23:51 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/transform/HTMLTransformerTest.java,v $
 */
public class HTMLTransformerTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	private URL urlXml;
	private URL urlXslt;
	
	@Override
	public void setUp() throws Exception
	{
		super.setUp();
		
		urlXml = getClass().getClassLoader().getResource("designs/n-age/base/xml/personal_information.xml");
		urlXslt = getClass().getClassLoader().getResource("designs/n-age/base/xsl2/personal_information.xslt");
	}
	
	private static void assertContains(String sString, String sSubString)
	{
		assertTrue("String should contain substring '" + sSubString +
			"', but received: " + CStringUtils.truncate(sString, 50),
			sString.indexOf(sSubString) > -1);
	}

	public void test_xslt() throws TransformerException, IOException
	{
		//String sUrl = //"http://clee2.hireright.com:8080/common/Mip2-phaseI-4ESB.xsl";
			// "http://ows01.hireright.com/designs/n-age/base/xsl2/personal_information.xslt";
		//	GeneralSettings.getHttpResRoot() + "/designs/n-age/base/xsl2/personal_information.xslt";
		//urlXml = new URL(sUrl);

		String sXml = CFileContent.getContent(urlXml);
		
		HTMLTransformer xslt = new HTMLTransformer(urlXslt);		// new URL(sUrl)
		assertEquals(urlXslt.toString(), xslt.getXsltUrl());

		StringWriter out = new StringWriter(1024);
		xslt.transform(sXml, out);

		String sResult = out.toString();
		assertNotNull(sResult);

		assertContains(sResult, "<html><head><META http-equiv=");
		assertContains(sResult, "scripts/utils_personal.js");
		assertContains(sResult, "</form></center></body></html>");
	}

	public void test_cache() throws TransformerException
	{
		// String sUrl = GeneralSettings.getHttpResRoot() + "/designs/n-age/base/xsl2/desired_position.xslt";

		long start = System.nanoTime();
		HTMLTransformer xslt = new HTMLTransformer(urlXslt);
		assertEquals(urlXslt.toString(), xslt.getXsltUrl());
		long end = System.nanoTime();

		long start2 = System.nanoTime();
		HTMLTransformer xslt2 = new HTMLTransformer(urlXslt);
		assertEquals(urlXslt.toString(), xslt2.getXsltUrl());
		long end2 = System.nanoTime();

		assert(end-start > 0);
		assert(end2-start2 > 0);
		
		// It doesn't always work for local file. :( 
		// assertTrue( "Loading a cached XSLT (" + (end2-start2) + " ms.) should work faster than non-cached (" + (end-start) + " ms.)", (end2-start2) <= (end-start) );
	}
}
