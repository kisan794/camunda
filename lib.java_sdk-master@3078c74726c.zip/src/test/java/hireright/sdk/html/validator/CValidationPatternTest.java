/*
 * @(#)$RCSfile: CValidationPatternTest.java,v $ $Revision: 1.2 $ $Date: 2008/09/05 10:14:45 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/validator/CValidationPatternTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev				2008-08-27	Created
 */
package hireright.sdk.html.validator;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $ $Date: 2008/09/05 10:14:45 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/validator/CValidationPatternTest.java,v $
 */
@Test
public class CValidationPatternTest
{
	public void testMatch()
	{
		CValidationPattern p = new CValidationPattern("a.*b");
		Assert.assertEquals( "a.*b", p.getPatternString());
		Assert.assertFalse( p.isInverted() );
		Assert.assertTrue( p.matches( "ab" ) );
		Assert.assertTrue( p.matches( "aab" ) );
		Assert.assertTrue( p.matches( "abb" ) );
		Assert.assertTrue( p.matches( "a.b" ) );
		Assert.assertTrue( p.matches( "a*b" ) );
		
		Assert.assertFalse( p.matches( "a" ) );
		Assert.assertFalse( p.matches( "b" ) );
		Assert.assertFalse( p.matches( "abc" ) );
	}
	
	public void testMatchInverted()
	{
		CValidationPattern p = new CValidationPattern("a.*b", true);
		Assert.assertEquals( "a.*b", p.getPatternString());
		Assert.assertTrue( p.isInverted() );
		
		Assert.assertFalse( p.matches( "ab" ) );
		Assert.assertFalse( p.matches( "aab" ) );
		Assert.assertFalse( p.matches( "abb" ) );
		Assert.assertFalse( p.matches( "a.b" ) );
		Assert.assertFalse( p.matches( "a*b" ) );
		
		Assert.assertTrue( p.matches( "a" ) );
		Assert.assertTrue( p.matches( "b" ) );
		Assert.assertTrue( p.matches( "abc" ) );
	}
}
