/*
 * @(#)$RCSfile: CElementValidationResultTest.java,v $ $Revision: 1.2 $ $Date: 2008/09/05 10:09:21 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/validator/CElementValidationResultTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev				2008-08-27	Created
 */
package hireright.sdk.html.validator;

import org.testng.annotations.Test;
import org.testng.Assert;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $ $Date: 2008/09/05 10:09:21 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/validator/CElementValidationResultTest.java,v $
 */
@Test
public class CElementValidationResultTest 
{
	public void testStatus()
	{
		CElementValidationResult res = new CElementValidationResult(2);
		Assert.assertEquals(2, res.getStatus());
		Assert.assertNull( res.getMessage() );
	}
	
	public void testStatusAndMessage()
	{
		CElementValidationResult res = new CElementValidationResult(3, "msg");
		Assert.assertEquals(3, res.getStatus());
		Assert.assertEquals("m" + "s" + "g", res.getMessage() );
	}
}
