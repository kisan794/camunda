/*
 * @(#)$RCSfile: XML2PropertiesTest.java,v $ $Revision: 1.2 $ $Date: 2009/12/18 07:14:15 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/utils/XML2PropertiesTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev				2009-12-09	Created
 */
package hireright.sdk.html.utils;

import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.util.CProperties;
import junit.framework.TestCase;

/**
 * @author asolntsev
 * @version $Revision: 1.2 $ $Date: 2009/12/18 07:14:15 $ $Author: cvsroot $
 */
public class XML2PropertiesTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	public void testParseEmptyXml()
	{
		XMLObject xml = new XMLObject("<properties/>");
		CProperties properties = XML2Properties.buildProperties( xml.getNode( "properties" ) );
		assertEquals( 0, properties.size() );
	}
	
	public void testParseXml()
	{
		XMLObject xml = new XMLObject("<properties>" +
				"<property name=\"a\">val1</property>" +
				"<property name=\"b\">val2</property>" +
				"</properties>");
		
		CProperties properties = XML2Properties.buildProperties( xml.getNode( "properties" ) );
		assertEquals( 2, properties.size() );
		assertEquals( "val1", properties.getProperty( "a" ) );
		assertEquals( "val2", properties.getProperty( "b" ) );
	}
}
