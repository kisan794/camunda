/*
 * @(#)$RCSfile: XHTMLCacheTest.java,v $Revision: 1.4 $ $Date: 2011/01/20 21:24:00 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/utils/XHTMLCacheTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-11-08	created
 *	A.Solntsev			2008-12-29	Now unit tests do not depend on AS resources (use only local files)
 */
package hireright.sdk.html.utils;

import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLObjectException;
import hireright.tests.junit.CResourceUtils;

import java.net.URL;

import junit.framework.TestCase;

/**
 * @author asolntsev
 * @since Nov 8, 2007
 * @version $Revision: 1.4 $ $Date: 2011/01/20 21:24:00 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/utils/XHTMLCacheTest.java,v $
 */
public class XHTMLCacheTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	public void testDisplayableError() throws XMLObjectException
	{
		final String sXhtml;
		// URL unexpectedErrorUrl = CResourceUtils.getResource(getClass(), "/designs/general/xhtml/error.xhtml");
		//URL unexpectedErrorUrl = new URL(GeneralSettings.getHttpResRoot() + "/designs/general/" + "xhtml/" + "error.xhtml");
		URL unexpectedErrorUrl = CResourceUtils.getResource("/designs/general/xhtml/error.xhtml");

		{
			XMLObject xml = new XMLObject(unexpectedErrorUrl);
			assertEquals("Error", xml.getNode("title").getText());
			assertEquals("Content-Type", xml.getNode("meta").getAttribText("http-equiv"));
		}

		{
			XHTMLInjector injector = XHTMLCache.getXHTMLInjector(unexpectedErrorUrl.toString());
			final long logId = 12345;
			injector.injectValue("logId", String.valueOf(logId));
			injector.replaceInAttribute("mailto", "href", "logId", String.valueOf(logId));

			sXhtml = injector.toString(true);
			assertNotNull(sXhtml);
		}

		{
			XMLObject xml = new XMLObject(sXhtml);
			assertEquals("Error", xml.getNode("title").getText());
			assertEquals("Content-Type", xml.getNode("meta").getAttribText("http-equiv"));
		}
	}
}
