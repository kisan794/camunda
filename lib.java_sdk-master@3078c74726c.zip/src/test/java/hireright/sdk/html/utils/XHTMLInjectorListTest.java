/*
 * @(#)$RCSfile: XHTMLInjectorListTest.java,v $Revision: 1.2 $ $Date: 2007/11/30 09:28:25 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/utils/XHTMLInjectorListTest.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			Nov 16, 2007	created
 */
package hireright.sdk.html.utils;

import junit.framework.TestCase;

import hireright.sdk.html.parser.XMLObjectException;
import hireright.sdk.html.utils.XHTMLInjector;

/**
 * @author asolntsev
 * @since Nov 16, 2007
 * @version $Revision: 1.2 $ $Date: 2007/11/30 09:28:25 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/utils/XHTMLInjectorListTest.java,v $
 */
public class XHTMLInjectorListTest extends TestCase
{
	private static final String ID_DATA = "data";
	private static final String ID_COUNTRY_LIST = "country_list";
	private static final String ID_COUNTRY_ID = "country_id";
	private static final String ID_COUNTRY_NAME = "country_name";

	private static final String XML_MVR_DATA =
        "<mvr_data id=\""+ID_DATA+"\">" +
			"<country_list id=\"" + ID_COUNTRY_LIST + "\">" +
				"<country_id id=\"" + ID_COUNTRY_ID + "\" />" +
				"<country_name id=\"" + ID_COUNTRY_NAME + "\" />" +
			"</country_list>" +
        "</mvr_data>";

	private static void assertNumberOfSections(final XHTMLInjector injector, final int count)
	{
		assertEquals(count, injector.getOutputXMLObject().getAttributesCount("id", ID_COUNTRY_LIST));
		assertEquals(count, injector.getOutputXMLObject().getAttributesCount("id", ID_COUNTRY_ID));
		assertEquals(count, injector.getOutputXMLObject().getAttributesCount("id", ID_COUNTRY_NAME));
	}

	public void test_injectList() throws XMLObjectException
	{
		XHTMLInjector injector = new XHTMLInjector(XML_MVR_DATA);
		assertEquals(XML_MVR_DATA, injector.toString());
		assertNumberOfSections(injector, 1);

		{
			injector.dublicateBranch(ID_DATA, ID_COUNTRY_LIST, ID_COUNTRY_LIST);
			injector.injectValueLast(ID_COUNTRY_ID, "1");
			injector.injectValueLast(ID_COUNTRY_NAME, "USA");
		}

		{
			injector.dublicateBranch(ID_DATA, ID_COUNTRY_LIST, ID_COUNTRY_LIST);
			injector.injectValueLast(ID_COUNTRY_ID, "23");
			injector.injectValueLast(ID_COUNTRY_NAME, "Canada");
		}

		String temp1 = injector.toString();
		assertNumberOfSections(injector, 3);
		injector.removeOutNodeFirst(ID_COUNTRY_LIST);
		String temp2 = injector.toString();
		assertNumberOfSections(injector, 2);

		{
			String sXmlWithIDs = injector.toString();
			assertTrue(sXmlWithIDs.indexOf("USA") > -1);
			assertTrue(sXmlWithIDs.indexOf("Canada") > -1);
			assertTrue(sXmlWithIDs.indexOf("id=\"") > -1);	// attributes "id"
		}

		injector.removeOutAttributes(XHTMLInjector.ID_ATTRIBUTE);
		{
			String sXmlWithIDs = injector.toString();
			assertTrue(sXmlWithIDs.indexOf("USA") > -1);
			assertTrue(sXmlWithIDs.indexOf("Canada") > -1);
			assertEquals(-1, sXmlWithIDs.indexOf("id=\""));	// attributes "id"
		}
	}
}
