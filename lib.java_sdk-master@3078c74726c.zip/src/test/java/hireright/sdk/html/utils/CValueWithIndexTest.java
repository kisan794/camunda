/*
 * @(#)$RCSfile: CValueWithIndexTest.java,v $ $Revision: 1.6 $ $Date: 2007/09/14 09:18:16 $ $Author: asolntsev $
 *
 * Copyright 2004-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	Andrei Solntsev		2004-10-14	Created.
 */
package hireright.sdk.html.utils;
import java.io.Serializable;

import junit.framework.TestCase;

/**
 * JUnit-test for class hireright.sdk.html.utils.CValueWithIndex
 * This class gets string like "edu_name2", parses it and
 * returns separately "edu_name" and 2.
 */
public class CValueWithIndexTest extends TestCase implements Serializable
{
	/**
   * Positive case
   *  Input:  string with single index, "abc1"
   *  Expected result: "abc" + 1
   */
  public void test_one_index()
	{
		CValueWithIndex test = new CValueWithIndex("abc1");
		assertTrue(test.hasIndex());
		assertEquals(test.getValue(), "abc");
		assertEquals(test.getIndex(), 1);
	}
  
	/**
   * Negative case
   *  Input:  string without index, "xyz"
   *  Expected result:  Method hasIndex() returns false.
   *                    Method test.getIndex() behaviour is undefined.
   */
	public void testNoIndex()
	{
		CValueWithIndex test = new CValueWithIndex("xyz");
		assertFalse(test.hasIndex());
		assertEquals(test.getValue(), "xyz");
	}

	/**
   * Positive case
   *  Input:  string with two indecies, "abc2_3"
   *  Expected result: "abc" + 2 + "_" + 3
   */
	public void test_two_indecies()
	{
		CValueWithIndex test = new CValueWithIndex("abc2_3");
		assertTrue(test.hasIndex());
		assertEquals(test.getValue(), "abc2_");
		assertEquals(test.getIndex(), 3);

		String cutUnderscore = test.getValue().substring(0, test.getValue().length()-1);
		CValueWithIndex test2 = new CValueWithIndex(cutUnderscore);
		assertTrue(test2.hasIndex());
		assertEquals(test2.getValue(), "abc");
		assertEquals(test2.getIndex(), 2);
	}

	/**
   * Positive case
   *  Input:  only index without any string, "12345"
   *  Expected result: "" + 12345
   */
	public void test_only_index()
	{
		CValueWithIndex test = new CValueWithIndex("12345");
		assertTrue(test.hasIndex());
		assertEquals(test.getValue(), "");
		assertEquals(test.getIndex(), 12345);
	}
}