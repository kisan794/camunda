/*
 * @(#)$RCSfile: CValueWithIndeciesTest.java,v $ $Revision: 1.5 $ $Date: 2007/09/14 09:18:14 $ $Author: asolntsev $
 *
 * Copyright 2004-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	2004-10-14	A.Solntsev	created
 */
package hireright.sdk.html.utils;
import java.io.Serializable;

import junit.framework.TestCase;
import junitx.framework.ArrayAssert;	// @see http://junit-addons.sourceforge.net/

/**
 * 
 * @author Andrei Solntsev
 */
public class CValueWithIndeciesTest extends TestCase implements Serializable
{

	public void test_empty_value()
	{
		CValueWithIndecies test = new CValueWithIndecies("");
		assertEquals(test.getValue(), "");
		assertEquals(test.getIndecies().length, 0);
	}
	
	public void test_no_indecies()
	{
		CValueWithIndecies test = new CValueWithIndecies("abcde");
		assertEquals(test.getValue(), "abcde");
		assertEquals(test.getIndecies().length, 0);
	}

	public void test_one_index()
	{
		CValueWithIndecies test = new CValueWithIndecies("abcde2");
		assertEquals(test.getValue(), "abcde");
		ArrayAssert.assertEquals(test.getIndecies(), new int[] {2});
	}

	public void test_two_indecies()
	{
		CValueWithIndecies test = new CValueWithIndecies("abcde4_3");
		assertEquals(test.getValue(), "abcde");
		ArrayAssert.assertEquals(test.getIndecies(), new int[] {3, 4});
	}

	public void test_three_indecies()
	{
		CValueWithIndecies test = new CValueWithIndecies("abcde10_28_76");
		assertEquals(test.getValue(), "abcde");
		ArrayAssert.assertEquals(test.getIndecies(), new int[] {76, 28, 10});
	}

	public void test_four_indecies()
	{
		CValueWithIndecies test = new CValueWithIndecies("abcde11_22_33_44");
		assertEquals(test.getValue(), "abcde");
		ArrayAssert.assertEquals(test.getIndecies(), new int[] {44, 33, 22, 11});
	}

	public void test_empty_value_four_indecies()
	{
		CValueWithIndecies test = new CValueWithIndecies("111_22222_333333_444444");
		assertEquals(test.getValue(), "");
		ArrayAssert.assertEquals(test.getIndecies(), new int[] {444444, 333333, 22222, 111});
	}
}