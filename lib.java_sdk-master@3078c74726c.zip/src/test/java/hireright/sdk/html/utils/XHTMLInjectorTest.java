/*
 * @(#)$RCSfile: XHTMLInjectorTest.java,v $ $Revision: 1.9 $ $Date: 2009/09/11 13:47:48 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/utils/XHTMLInjectorTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev		2006-11-06	Created
 *	A.Solntsev		2007-11-19	Fixed & updated
 *	A.Solntsev		2008-02-19	Added test-case testInjectAttribute()
 *	M.Elshin			2008-02-29	Tests for a new method injectAttribute(String, String, int, String) were added.
 *	A.Solntsev		2008-08-25	Bugfix in XHTMLInjector (infinite loop in method removeOutNodes)
 *	A.Solntsev		2009-03-12	Method testRemoveOutNodesConcurrent() is now multi-threaded
 */
package hireright.sdk.html.utils;

import junit.framework.TestCase;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.Set;
import java.util.concurrent.CountDownLatch;

import com.google.common.collect.Sets;

import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLObjectException;
import hireright.sdk.html.parser.XMLTreeNode;

/**
 * Unit test for class hireright.sdk.html.utils.XHTMLInjector
 *
 * @author Andrei Solntsev
 * @since Nov 6, 2006
 * @version $Revision: 1.9 $ $Date: 2009/09/11 13:47:48 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/utils/XHTMLInjectorTest.java,v $
 */
public class XHTMLInjectorTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	private static final String HEADER = "<?xml version=\"1.0\"?>";
	private static final String NODE = "<node id=\"index\">x</node>";
	private static final String DATA_NODE_START = "<data_node id=\"data_node\">";
	private static final String DATA_NODE_END = "</data_node>";
		
	private static final String XML_TEMPLATE =
		HEADER +
		DATA_NODE_START +
		NODE + 
		DATA_NODE_END;

	private static void duplicateTenNodes(XHTMLInjector injector)
	{
		for (int i=1; i<=10; i++)
		{
			injector.dublicateBranch("data_node", "index", "index"+i);
			assertTrue(injector.injectValueLast("index"+i, "node"+i));
			assertEquals("node"+i, injector.getNodeLast("index"+i).getValue());
		}

		injector.removeOutFirstDummyNode("index");
	}
	public void testDublicateBranch() throws XMLObjectException
	{
		XHTMLInjector injector = new XHTMLInjector(XML_TEMPLATE);
		duplicateTenNodes(injector);

		String sXML = injector.toString(true);
		assertNotNull(sXML);

		{
			XMLObject xml = new XMLObject(sXML);
			assertNotNull(xml);
			assertEquals("XML should contain 10 'node' elements, but received: " + xml, 10, xml.getNodesCount("node"));

			for (int i=1; i<=10; i++)
			{
				assertNotNull("Node 'index"+i+"' is not found", xml.getNodeByAttribute("id", "index" + i));
				assertNotNull("Node 'index"+(i+1)+"' is not found", xml.getNodeByAttribute("id", i+1));
				assertEquals("node"+i, xml.getNodeByAttribute("id", "index" + i).getValue());
				// assertEquals("node"+(i+1), xml.getNodeByAttribute("id", i+1).getValue());	// order of nodes is not defined
			}
		}
	}
	
	public void testInjectAttribute() throws XMLObjectException
	{
		XHTMLInjector injector = new XHTMLInjector(XML_TEMPLATE);
		assertEquals(NODE, injector.getOutputXMLObject().getNode( "node" ).toString());
		injector.injectAttribute( "index", "attr_name", "attr_value" );
		assertEquals("<node id=\"index\" attr_name=\"attr_value\">x</node>", injector.getOutputXMLObject().getNode( "node" ).toString());
		
		injector.injectAttribute( "index", "attr_name", "another_value", false );
		assertEquals("<node id=\"index\" attr_name=\"another_value\">x</node>", injector.getOutputXMLObject().getNode( "node" ).toString());
		
		injector.injectAttribute( "index", "attr_name", "_appended_value", true );
		assertEquals("<node id=\"index\" attr_name=\"another_value_appended_value\">x</node>", injector.getOutputXMLObject().getNode( "node" ).toString());
		
		injector.injectAttribute( "index", "attr_name", 2, "new_value");
		assertEquals("<node id=\"index\" attr_name=\"another_value_appended_value\">x</node>", injector.getOutputXMLObject().getNode( "node" ).toString());

		injector.injectAttribute( "index", "attr_name", 1, "new_value");
		assertEquals("<node id=\"index\" attr_name=\"new_value\">x</node>", injector.getOutputXMLObject().getNode( "node" ).toString());
	}
	
	public void testReplaceAttribute() throws XMLObjectException
	{
		// Replace attribute 'id="data_node"' value
		XHTMLInjector injector = new XHTMLInjector(XML_TEMPLATE);
		injector.replaceInAttribute("data_node", "id", "data_", "xujata_");
		assertEquals("<data_node id=\"xujata_node\">"+NODE+DATA_NODE_END, injector.getOutputXMLObject().getNode( "data_node" ).toString());
		
		assertNull( injector.getOutputXMLObject().getNodeByAttribute("id", "data_node") );
		assertNotNull( injector.getOutputXMLObject().getNodeByAttribute("id", "xujata_node") );
		
		// Replace back. Check that hash arrays are updated.
		injector.replaceInAttribute("xujata_node", "id", "xujata_", "data_");
		assertEquals(DATA_NODE_START+NODE+DATA_NODE_END, injector.getOutputXMLObject().getNode( "data_node" ).toString());
		
		assertNotNull( injector.getOutputXMLObject().getNodeByAttribute("id", "data_node") );
		assertNull( injector.getOutputXMLObject().getNodeByAttribute("id", "xujata_node") );
	}
	
	public void testInjectAttributeLast() throws XMLObjectException
	{
		XHTMLInjector injector = new XHTMLInjector(XML_TEMPLATE);
		injector.injectAttributeLast("data_node", "id2", "babah");
		assertEquals("<data_node id=\"data_node\" id2=\"babah\">"+NODE+DATA_NODE_END, 
				injector.getOutputXMLObject().getNode( "data_node" ).toString());
		
		// replace value
		injector.injectAttributeLast("data_node", "id2", "scuko");
		assertEquals("<data_node id=\"data_node\" id2=\"scuko\">"+NODE+DATA_NODE_END, 
				injector.getOutputXMLObject().getNode( "data_node" ).toString());
		
		// append value
		injector.injectAttributeLast("data_node", "id2", "nah", true);
		assertEquals("<data_node id=\"data_node\" id2=\"scukonah\">"+NODE+DATA_NODE_END, 
				injector.getOutputXMLObject().getNode( "data_node" ).toString());
	}
	
	public void testReplaceInValue() throws XMLObjectException
	{
		XHTMLInjector injector = new XHTMLInjector(XML_TEMPLATE);
		injector.replaceInValue("index", "x", "XXX");
		assertEquals(DATA_NODE_START + NODE.replaceAll(">x<", ">XXX<") +DATA_NODE_END,
				injector.getOutputXMLObject().getNode( "data_node" ).toString());
	}
	
	public void testReplaceInValueLast() throws XMLObjectException
	{
		XHTMLInjector injector = new XHTMLInjector(XML_TEMPLATE);
		injector.replaceInValueLast("index", "x", "XXX");
		assertEquals(DATA_NODE_START + NODE.replaceAll(">x<", ">XXX<") +DATA_NODE_END,
				injector.getOutputXMLObject().getNode( "data_node" ).toString());
	}
	
	public void testRemoveOutNodes() throws XMLObjectException
	{
		XHTMLInjector injector = new XHTMLInjector(XML_TEMPLATE);
		injector = new XHTMLInjector(injector.getInputXmlObject());
		assertEquals(XML_TEMPLATE, injector.toString());
		
		XMLTreeNode node1 = injector.getOutputXMLObject().getNodeByAttribute("id", "index");
		assertNotNull( node1 );
		
		injector.removeOutNodes("index");
		assertEquals(HEADER + "<data_node id=\"data_node\" />", injector.toString());
		
		XMLTreeNode node2 = injector.getOutputXMLObject().getNodeByAttribute("id", "index");
		assertNull( node2 );
	}
	
	public void testRemoveOutNodesConcurrent() throws Throwable
	{
		final XHTMLInjector injector = new XHTMLInjector(XML_TEMPLATE);
		
		final Set<Throwable> exceptions = Sets.newConcurrentHashSet();
		
		final CountDownLatch latch = new CountDownLatch(10);
		
		for (int i=0; i<10; i++)
		{
			Thread t = new Thread()
			{
				@Override
				public void run()
				{
					XHTMLInjector inj2 = new XHTMLInjector(injector.getInputXmlObject());
					XHTMLInjector inj3 = new XHTMLInjector(injector.getInputXmlObject());
					XHTMLInjector inj4 = new XHTMLInjector(injector.getInputXmlObject());
					XHTMLInjector inj5 = new XHTMLInjector(injector.getInputXmlObject());
					
					
					assertEquals(XML_TEMPLATE, injector.toString());
					
					{
						inj2.removeOutNodes("index");
						// assertEquals(XML_TEMPLATE.replaceFirst(" id=\"index\"", ""), inj2.toString());
						assertEquals(HEADER + "<data_node id=\"data_node\" />", inj2.toString());	
					}
					
					assertEquals(XML_TEMPLATE, injector.toString());
					
					{
						inj3.removeOutNodes("data_node2");
						inj3.removeOutNodes("data_node");
						assertEquals(HEADER, inj3.toString());
					}
					
					assertEquals(XML_TEMPLATE, injector.toString());
					
					{
						inj4.removeOutNodes("data_node");
						inj4.removeOutNodes("index");
						assertEquals(HEADER, inj4.toString());
					}
					
					assertEquals(XML_TEMPLATE, injector.toString());
					
					{
						inj5.removeOutNodes("data_node");
						inj5.removeOutNodes("index");
						inj5.removeOutNodes("data_node");
						inj5.removeOutNodes("index");
						assertEquals(HEADER, inj5.toString());
					}
					
					assertEquals(XML_TEMPLATE, injector.toString());
					
					latch.countDown();
				}
			};
			t.setUncaughtExceptionHandler(new UncaughtExceptionHandler()
			{
				@Override
				public void uncaughtException(Thread t, Throwable e)
				{
					exceptions.add(e);
				}
			});
			t.start();
		}
		
		latch.await();
		
		if(!exceptions.isEmpty())
		{
			throw exceptions.iterator().next();
		}
		
		{
			duplicateTenNodes(injector);
		}
		
		
	}
}
