/*
 * @(#)$RCSfile: XMLUtilsTest.java,v $ $Revision: 1.7 $ $Date: 2011/11/18 10:22:12 $ $Author: cvsroot $
 *
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Andrei Solntsev		2006-06-19	Created
 *	A.Solntsev			2006-09-10	test_replace_null_string_FIXME()
 *	E.Kapustin			2011-04-25	Added testDecodeWebTextData().
 *	K.Ovchinnikov		2011-11-08	Added testDecodeMultilineWebTextData().
 */
package hireright.sdk.html.utils;
import java.io.Serializable;

import junit.framework.TestCase;

/**
 * JUnit-test for class hireright.sdk.html.utils.XMLUtils
 * 
 * @author Andrei Solntsev
 * @since java_sdk_v2-6-14
 */
public class XMLUtilsTest extends TestCase implements Serializable
{
	public XMLUtilsTest()
	{
		super(XMLUtils.class.getName());
	}
	
	public void test_replace()
	{
		assertEquals("xy345", XMLUtils.replace("12345", "12", "xy"));
	}
	
	public void test_replace_empty_string()
	{
		assertEquals("", XMLUtils.replace("", "12", "xy"));
	}
	
	public void test_replace_null_string_FIXME()
	{
		// assertEquals(null, XMLUtils.replace(null, "12", "xy"));	// FAILS!  FIXME!
		assertEquals("abc", XMLUtils.replace("abc", null, "xy"));
	}
	
	public void test_replace_no_matches()
	{
		assertEquals("1", XMLUtils.replace("1", "2", "3"));
	}
	
	public void test_replace_many_matches()
	{
		assertEquals("2222", XMLUtils.replace("1111", "1", "2"));
		assertEquals("2222", XMLUtils.replace("1122", "1", "2"));
		assertEquals("1133", XMLUtils.replace("1122", "2", "3"));
		assertEquals("1133", XMLUtils.replace("1122", "2", "3"));
		assertEquals("1342", XMLUtils.replace("1122", "12", "34"));
	}
	
	public void test_encodeTextData()
	{
		assertEquals(null, XMLUtils.encodeTextData(null));
		assertEquals("", XMLUtils.encodeTextData(""));
		assertEquals("12345", XMLUtils.encodeTextData("12345"));
		
		assertEquals("<", XMLUtils.encodeTextData("&lt;"));
		assertEquals(">", XMLUtils.encodeTextData("&gt;"));
		assertEquals("<>", XMLUtils.encodeTextData("&lt;&gt;"));
		assertEquals("<XXX>", XMLUtils.encodeTextData("&lt;XXX&gt;"));
		assertEquals("<<<<<", XMLUtils.encodeTextData("&lt;&lt;&lt;&lt;&lt;"));
		
		assertEquals("'ABC'", XMLUtils.encodeTextData("&apos;ABC&apos;"));
		assertEquals("-'ABC'", XMLUtils.encodeTextData("-&apos;ABC&apos;"));
		assertEquals("'ABC'+", XMLUtils.encodeTextData("&apos;ABC&apos;+"));
		assertEquals("-'ABC'+", XMLUtils.encodeTextData("-&apos;ABC&apos;+"));
		assertEquals("\"XYZ&", XMLUtils.encodeTextData("&quot;XYZ&amp;"));
		
		assertEquals("123&4567890", XMLUtils.encodeTextData("123&4567890"));
		assertEquals("123&456", XMLUtils.encodeTextData("123&456"));
	}
	
	public void test_decodeTextData()
	{
		assertEquals(null, XMLUtils.decodeTextData(null));
		assertEquals("", XMLUtils.decodeTextData(""));
		assertEquals("12345", XMLUtils.decodeTextData("12345"));
		
		assertEquals("&lt;", XMLUtils.decodeTextData("<"));
		assertEquals("&gt;", XMLUtils.decodeTextData(">"));
		assertEquals("&lt;&gt;", XMLUtils.decodeTextData("<>"));
		assertEquals("&lt;XXX&gt;", XMLUtils.decodeTextData("<XXX>"));
		assertEquals("&lt;&lt;&lt;&lt;&lt;", XMLUtils.decodeTextData("<<<<<"));
		
		assertEquals("&apos;ABC&apos;", XMLUtils.decodeTextData("'ABC'"));
		assertEquals("-&apos;ABC&apos;", XMLUtils.decodeTextData("-'ABC'"));
		assertEquals("&apos;ABC&apos;+", XMLUtils.decodeTextData("'ABC'+"));
		assertEquals("-&apos;ABC&apos;+", XMLUtils.decodeTextData("-'ABC'+"));
		assertEquals("&quot;XYZ&amp;", XMLUtils.decodeTextData("\"XYZ&"));
		
		assertEquals("123&amp;4567890", XMLUtils.decodeTextData("123&4567890"));
		assertEquals("123&amp;456", XMLUtils.decodeTextData("123&456"));

		assertEquals("123&amp;nbsp;456", XMLUtils.decodeTextData("123&nbsp;456"));
	}
	
	public void testDecodeWebTextData()
	{
		assertEquals("123&amp;456", XMLUtils.decodeTextData("123&456", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("123456&amp;", XMLUtils.decodeTextData("123456&", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("123456&amp;&amp;", XMLUtils.decodeTextData("123456&&", XMLUtils.SPECIFIC_WEB_BROW));
		
		assertEquals("&lt;", XMLUtils.decodeTextData("<", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("&gt;", XMLUtils.decodeTextData(">", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("&lt;&gt;", XMLUtils.decodeTextData("<>", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("&lt;XXX&gt;", XMLUtils.decodeTextData("<XXX>", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("&lt;&lt;&lt;&lt;&lt;", XMLUtils.decodeTextData("<<<<<", XMLUtils.SPECIFIC_WEB_BROW));

		assertEquals("123&#160;456", XMLUtils.decodeTextData("123&#160;456", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("123&nbsp;456", XMLUtils.decodeTextData("123&nbsp;456", XMLUtils.SPECIFIC_WEB_BROW));

		assertEquals("123&amp;456", XMLUtils.decodeTextData("123&amp;456", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("123&amp;&amp;456", XMLUtils.decodeTextData("123&&amp;456", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("123&lt;456", XMLUtils.decodeTextData("123&lt;456", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("123&gt;456", XMLUtils.decodeTextData("123&gt;456", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("123&apos;456", XMLUtils.decodeTextData("123&apos;456", XMLUtils.SPECIFIC_WEB_BROW));
		assertEquals("123&quot;456", XMLUtils.decodeTextData("123&quot;456", XMLUtils.SPECIFIC_WEB_BROW));
	}
	
	public void testDecodeMultilineWebTextData()
	{
		String multilineText = "First&#160;line\r\n" +
								"Second line&#160;\n" +
								"&#160;Third line";
		assertEquals(multilineText, XMLUtils.decodeTextData(multilineText, XMLUtils.SPECIFIC_WEB_BROW));
	}
}