/*
 * @(#)$RCSfile: CHttpParametersStorageTest.java,v $ $Revision: 1.8 $ $Date: 2012/07/27 07:43:10 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/utils/CHttpParametersStorageTest.java,v $
 *
 * Copyright 2004-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Andrei Solntsev		2004-09-27	Created.
 *	Andrei Solntsev		2007-02-16	Fixed. Now unit test seems to work correctly.
 */
package hireright.sdk.html.utils;
import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLTreeNode;

import java.io.Serializable;

import junit.framework.TestCase;

/**
 * Unit-test for class hireright.sdk.html.utils.CHttpParametersSet
 *
 * @author Andrei Solntsev
 * @since Feb 16, 2007
 * @version $Revision: 1.8 $ $Date: 2012/07/27 07:43:10 $ $Author: cvsroot $
 */
public class CHttpParametersStorageTest extends TestCase implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	public static String STR_EMPTY_XML = "<data_node></data_node>";
	public static String STR_EDU_NAME =
			"<data_node>"+
			"		<education index=\"1\">" +
			"				<edu_name/>" +
			"		</education>"+
			"</data_node>";

	public static String STR_EDU_ADDRESSES =
			"<data_node>" +

			"		<education index=\"1\">" +
			"			<address index=\"1\">" +
			"				<edu_city>city1-1</edu_city>" +
			"				<edu_street/>" +
			"			</address>" +
			"			<address index=\"2\">" +
			"				<edu_city>city1-2</edu_city>" +
			"			</address>" +
			"		</education>" +

			"		<education index=\"2\">" +
			"			<address index=\"1\">" +
			"				<edu_city>city2-1</edu_city>" +
			"			</address>" +
			"			<address index=\"3\">" +
			"				<edu_city>city2-3</edu_city>" +
			"			</address>" +
			"		</education>" +

			"</data_node>";
	
	public static String STR_WITH_NAMES =
			"<data_node>" +

			"		<education index=\"1\">" +
			"			<address index=\"1\">" +
			"				<edu_city immutable=\"true\" name=\"immutable\">old_value</edu_city>" +
			"				<edu_street/>" +
			"			</address>" +
			"			<address index=\"2\">" +
			"				<edu_city immutable=\"bla\" name=\"immutablebla\">old_value</edu_city>" +
			"			</address>" +
			"		</education>" +

			"		<education index=\"2\">" +
			"			<address index=\"1\">" +
			"				<edu_city name=\"mutable\">old_value</edu_city>" +
			"			</address>" +
			"			<address index=\"3\">" +
			"				<edu_city>city2-3</edu_city>" +
			"			</address>" +
			"		</education>" +

			"</data_node>";


	private XMLObject EMPTY_XML;
	private XMLObject XML_EDU_NAME;
	private XMLObject XML_EDU_ADDRESSES;
	private XMLObject XML_WITH_NAMES;

	@Override
	public void setUp() throws Exception
	{
		super.setUp();
		EMPTY_XML = XMLObject.parseValidXml(STR_EMPTY_XML);
		XML_EDU_NAME = XMLObject.parseValidXml(STR_EDU_NAME);
		XML_EDU_ADDRESSES = XMLObject.parseValidXml(STR_EDU_ADDRESSES);
		XML_WITH_NAMES = XMLObject.parseValidXml(STR_WITH_NAMES);

	}

	private IHttpParametersStorage getStorage(XMLObject xml)
	{
		XMLObject clone = new XMLObject(xml);
		return new CHttpParametersStorage(clone);
	}


	public void testEmptyXML()
	{
		IHttpParametersStorage storage = getStorage(EMPTY_XML);
		try
		{
			storage.putParameter("edu_name", "My first school");
		}
		catch (Exception e) {}

		String szTemp = storage.toString();
		assertNotNull(szTemp);
		assertTrue(szTemp.indexOf("edu_name") > 5);

		assertNull(storage.getData().getRootNode().getChildNodeByTag("edu_name"));
		assertEquals("My first school", XMLUtils.nodeValue(storage.getData().getNode("data_node").getChildNodeByTag("edu_name"), ""));
	}

	public void testEduName()
	{
		IHttpParametersStorage storage = getStorage(XML_EDU_NAME);
		try
		{
			// "edu_name" should occur in <data_node>
			storage.putParameter("edu_name", "My first school");
		}
		catch (Exception e) {}
		String szTemp = storage.toString();
		assertNotNull(szTemp);
		assertTrue(szTemp.indexOf("edu_name") > 5);

		assertNull(storage.getData().getRootNode().getChildNodeByTag("edu_name"));
		assertNull(storage.getData().getNode("data_node").getChildNodeByTag("edu_name"));
	}

	public void testEduName_withIndex()
	{
		IHttpParametersStorage storage = getStorage(XML_EDU_NAME);
		try
		{
			// "edu_name1" should occur in <education index="1">
			storage.putParameter("edu_name1", "My first school");
		}
		catch (Exception e) {}
		String szTemp = storage.toString();
		assertNotNull(szTemp);
		assertTrue(szTemp.indexOf("edu_name") > 5);

		assertNull(storage.getData().getRootNode().getChildNodeByTag("edu_name"));
		assertNull(storage.getData().getNode("data_node").getChildNodeByTag("edu_name"));

		XMLTreeNode newNode = storage.getData().getNode("data_node").getChildNodeByTag("education").getChildNodeByTag("edu_name");
		assertEquals("My first school", XMLUtils.nodeValue(newNode, ""));
	}

	protected static void assertNoNode(IHttpParametersStorage storage, String sPath)
	{
		assertNull("XML should NOT contain node /" + sPath, storage.getNodeByPath(sPath));
	}

	protected static void assertNodeValue(IHttpParametersStorage storage, String sPath, String sExpectedValue)
	{
		String sReceivedValue = XMLUtils.nodeValue(storage.getNodeByPath(sPath), "");

		assertEquals("Node '/" + sPath + "' has wrong value.", sExpectedValue, sReceivedValue);
	}

	public void test2Indexes_but1index()
	{
		IHttpParametersStorage storage = getStorage(XML_EDU_ADDRESSES);
		storage.putParameter("edu_city1", "Tallinn");	// Should not go anywhere!

		String szTemp = storage.toString();
		assertNotNull(szTemp);
		assertTrue("XML.toString should contain substring 'edu_city'", szTemp.indexOf("edu_city") > 5);

		assertNoNode(storage, "edu_city");
		assertNoNode(storage, "data_node/edu_city");
		assertNoNode(storage, "data_node/education[1]/edu_city");

		assertNodeValue(storage, "data_node/education/address/edu_city", "Tallinn");
		assertNodeValue(storage, "data_node/education[1]/address[1]/edu_city", "Tallinn");
		assertNodeValue(storage, "data_node/education[1]/address[2]/edu_city", "city1-2");

		assertNoNode(storage, "data_node/education[2]/edu_city");
		assertNodeValue(storage, "data_node/education[2]/address[1]/edu_city", "city2-1");
		assertNodeValue(storage, "data_node/education[2]/address[2]/edu_city", "city2-3");
	}

	public void test2Indexes_with2indexes()
	{
		IHttpParametersStorage storage = getStorage(XML_EDU_ADDRESSES);

		{
			storage.putParameter("edu_city1_1", "my city 1-1");
			storage.putParameter("edu_city1_2", "my city 1-2");
			storage.putParameter("edu_city2_1", "my city 2-1");
			storage.putParameter("edu_city2_3", "my city 2-3");
			storage.putParameter("edu_city2_2", "my city 2-2");
		}

		String szTemp2 = storage.toString();
		assertNotNull(szTemp2);
		assertTrue(szTemp2.indexOf("edu_city") > 5);

		assertNodeValue(storage, "data_node/education[1]/address[1]/edu_city", "my city 1-1");
		assertNodeValue(storage, "data_node/education[1]/address[2]/edu_city", "my city 1-2");
		assertNodeValue(storage, "data_node/education[2]/address[1]/edu_city", "my city 2-1");
		assertNodeValue(storage, "data_node/education[2]/address[2]/edu_city", "my city 2-2");
		assertNodeValue(storage, "data_node/education[2]/address[3]/edu_city", "my city 2-3");
	}
	
	/**
	 * Node having attribute immutable="true" stays on unmodified
	 * Node without immutable="true" modifies
	 */
	public void testImmutableNodesStayUnmodified() 
	{
		IHttpParametersStorage storage = getStorage(XML_WITH_NAMES);	
		{
			storage.putParameter("mutable", "new_value");
			storage.putParameter("immutable", "new_value");
			storage.putParameter("immutablebla", "new_value");
		}
		
		assertNodeValue(storage, "data_node/education[1]/address[1]/edu_city", "old_value");
		assertNodeValue(storage, "data_node/education[1]/address[2]/edu_city", "new_value");
		assertNodeValue(storage, "data_node/education[2]/address[1]/edu_city", "new_value");
		
	}

	public void test_getParameterCount_FIXME()
	{
		IHttpParametersStorage storage = getStorage(XML_EDU_ADDRESSES);
		// String sXML = storage.toString();

		// assertEquals(	storage.getParameterCount("data_node"), 1); // Doesn't work because "data_node" has a special meaning
		assertEquals(	2,	storage.getParameterCount("education"));

		// assertEquals(	4,	storage.getParameterCount("address"));
		// assertEquals(	4,	storage.getParameterCount("edu_city"));
		// assertEquals(	1,	storage.getParameterCount("edu_street"));
	}

	public void test_getParameter()
	{
		IHttpParametersStorage storage = getStorage(XML_EDU_ADDRESSES);
		// String sXML = storage.toString();

		assertEquals("city1-1", XMLUtils.nodeValue(storage.getParameter("edu_city", 1), ""));
		assertEquals("city1-2", XMLUtils.nodeValue(storage.getParameter("edu_city", 2), ""));
		assertEquals("city2-1", XMLUtils.nodeValue(storage.getParameter("edu_city", 3), ""));
		assertEquals("city2-3", XMLUtils.nodeValue(storage.getParameter("edu_city", 4), ""));
	}
}