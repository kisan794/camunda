/*
 * @(#)$RCSfile: CURLRewriterTest.java,v $ $Revision: 1.2 $ $Date: 2009/07/10 09:26:45 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/utils/CURLRewriterTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History
 *	A.Solntsev				2009-07-09	Created
 */
package hireright.sdk.html.utils;

import junit.framework.TestCase;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $ $Date: 2009/07/10 09:26:45 $ $Author: asolntsev $
 */
public class CURLRewriterTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: asolntsev $";
	
	private String html = "<body><a href=\"/oseserv/mvc_controller?event=show_xxx\">show XXX</a></body>";
	private String htmlInjected = "<body><a href=\"/oseserv/mvc_controller;jsessionid=12345?event=show_xxx\">show XXX</a></body>";
	
	public void testInjectSessionKey()
	{
		assertEquals(htmlInjected, CURLRewriter.addSessionKeys(html, "12345", "mvc_controller"));
	}
	
	public void testInjectSessionKeyAndLinkId()
	{
		String html2Injected = "<body><a href=\"/oseserv/mvc_controller;jsessionid=12345;linkId=67890?event=show_xxx\">show XXX</a></body>";
		assertEquals(html2Injected, CURLRewriter.addSessionKeys(html, "12345;linkId=67890", "mvc_controller"));
	}
}
