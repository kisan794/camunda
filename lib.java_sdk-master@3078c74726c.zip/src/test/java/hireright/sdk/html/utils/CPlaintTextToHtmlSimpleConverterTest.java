/*
 *
 * Copyright 2001-2019 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	V.Ozernov		2019-04-25	HIVPE-76233 Created
 */
package hireright.sdk.html.utils;

import junit.framework.TestCase;

/**
 * 
 */
public class CPlaintTextToHtmlSimpleConverterTest extends TestCase
{
	private static final String[][] TEXTS_TO_TEST = new String[][] {
		new String[] {
				"Do you need more assistance?\n" 
				+ "HireRight is happy to help. Please contact:\n" 
				+ "   -  customerservice@hireright.com \n"
				+ "   - (866) 521-6995 toll free in the U.S. and Canada 5 days a week from Sunday 3 p.m. until Friday 6 p.m. PST.\n" 
				+ "   - Additional global toll free numbers can be found at www.hireright.com/customer-service. "
				+ "Help is available between Sunday 11 p.m. GMT to Saturday 2 a.m. GMT."
				,
				"Do you need more assistance?<br/>"
				+ "HireRight is happy to help. Please contact:<br/>"
				+ "   -  <a href=\"mailto:customerservice@hireright.com\">customerservice@hireright.com</a> <br/>"
				+ "   - (866) 521-6995 toll free in the U.S. and Canada 5 days a week from Sunday 3 p.m. until Friday 6 p.m. PST.<br/>"
				+ "   - Additional global toll free numbers can be found at <a href=\"http://www.hireright.com/customer-service\">www.hireright.com/customer-service</a>. "
				+ "Help is available between Sunday 11 p.m. GMT to Saturday 2 a.m. GMT."
		},
		new String[] {
				"If you need support, HireRight Customer Service is available 5 days a week "
				+ "from Sunday 3 p.m. until Friday 7 p.m. \"Pacific Standard Time\" by phone & fax "
				+ "(toll free in the U.S.) at <866> 521-6995, or by a toll call elsewhere at +1 <949> 428-5804.\n" 
				+ "\n"
				+ "Additional HireRight toll free numbers from many countries: http://www.hireright.com/Contact-Us.aspx#tab2"
				,
				"If you need support, HireRight Customer Service is available 5 days a week "
				+ "from Sunday 3 p.m. until Friday 7 p.m. &quot;Pacific Standard Time&quot; by phone &amp; fax "
				+ "(toll free in the U.S.) at &lt;866&gt; 521-6995, or by a toll call elsewhere at +1 &lt;949&gt; 428-5804.<br/>"
				+ "<br/>"
				+ "Additional HireRight toll free numbers from many countries: <a href=\"http://www.hireright.com/Contact-Us.aspx#tab2\">http://www.hireright.com/Contact-Us.aspx#tab2</a>"
		}
	}; 
			
	
	public void testConvert()
	{
		for(String[] pair : TEXTS_TO_TEST)
		{
			String sHtml = CPlaintTextToHtmlSimpleConverter.convert(pair[0]);
			String sExpectedHtml = pair[1];
			assertEquals(sExpectedHtml, sHtml);
		}
	}
}
