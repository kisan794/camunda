/*
 * @(#)$RCSfile: CProperties2XMLTest.java,v $ $Revision: 1.2 $ $Date: 2009/12/18 07:14:32 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/utils/CProperties2XMLTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev				2009-12-09	Created
 */
package hireright.sdk.html.utils;

import hireright.sdk.util.CProperties;
import junit.framework.TestCase;

/**
 * @author asolntsev
 * @version $Revision: 1.2 $ $Date: 2009/12/18 07:14:32 $ $Author: cvsroot $
 */
public class CProperties2XMLTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	public void testEmptyProperties()
	{
		CProperties p = new CProperties();
		String xml = CProperties2XML.toXML( p, CProperties2XML.VERSION_1_0 );
		// assertEquals( "<properties />", xml ); // I believe it would be correct!
		assertEquals( "", xml ); // Strange behaviour of this class :( 
	}
	
	public void testToXml()
	{
		CProperties p = new CProperties();
		p.setProperty( "a", "b" );
		String xml10 = CProperties2XML.toXML( p, CProperties2XML.VERSION_1_0 );
		assertEquals( "<properties><property name=\"a\">b</property></properties>", xml10 );
		
		String xml11 = CProperties2XML.toXML( p, CProperties2XML.VERSION_1_1 );
		assertEquals( "<Properties><Property name=\"a\">b</Property></Properties>", xml11 );
	}
}
