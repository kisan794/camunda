/*
 * @(#)$RCSfile: TreeNodeAttribTest.java,v $Revision: 1.2 $ $Date: 2007/11/30 09:28:06 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/parser/TreeNodeAttribTest.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			Nov 9, 2007	created
 */
package hireright.sdk.html.parser;

import junit.framework.TestCase;

/**
 * @author asolntsev
 * @since Nov 9, 2007
 * @version $Revision: 1.2 $ $Date: 2007/11/30 09:28:06 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/parser/TreeNodeAttribTest.java,v $
 */
public class TreeNodeAttribTest extends TestCase
{
	public void testConstructor()
	{
		TreeNodeAttrib attr = new TreeNodeAttrib("name", "value");
		assertEquals("name", attr.getXMLTag());
		assertEquals("name", attr.getName());
		assertEquals("value", attr.getText());
		assertEquals(XMLConsts.TYPE_ATTRIBUTE, attr.getType());
		assertEquals("value", attr.getValue());
		assertEquals("name=\"value\"", attr.toString());
	}

	public void testClone()
	{
		TreeNodeAttrib attr = new TreeNodeAttrib("name", "value");
		TreeNodeAttrib attr2 = (TreeNodeAttrib) attr.dublicate();

		assertEquals("name=\"value\"", attr.toString());
		assertEquals("name=\"value\"", attr2.toString());
	}
}
