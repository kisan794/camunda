/*
 * @(#)$RCSfile: TreeNodeTest.java,v $Revision: 1.2 $ $Date: 2007/11/30 09:27:58 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/parser/TreeNodeTest.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-11-19	created
 */
package hireright.sdk.html.parser;

import junit.framework.TestCase;

/**
 * @author asolntsev
 * @since Nov 19, 2007
 * @version $Revision: 1.2 $ $Date: 2007/11/30 09:27:58 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/parser/TreeNodeTest.java,v $
 */
public class TreeNodeTest extends TestCase
{
	/*private static TreeNode createTwoNodesTree()
	{
		TreeNode root = new StringTreeNode("root");
		assertEquals("root", root.toString());
		TreeNode child = new StringTreeNode("c");
		assertEquals("c", child.toString());
		root.addChildNode(child);
		// assertEquals("rc", root.toString());

		return root;
	}*/

	public void test_singleNode()
	{
		TreeNode root = new StringTreeNode("root");
		assertEquals("root", root.toString());
		assertNull(root.getChildTreeNode());
		assertNull(root.getNextNode());
		assertNull(root.getParent());
		assertNull(root.getPrevious());
		assertSame(root, root.getRoot());
	}

	private static void assertTwoNodes(TreeNode root, TreeNode child)
	{
		assertRoot(root, child);

		{
			assertNull(child.getChildTreeNode());
			assertNull(child.getNextNode());
			assertSame(root, child.getParent());
			assertNull(child.getPrevious());
			assertSame(root, child.getRoot());
		}
	}

	public void test_twoNodes()
	{
		TreeNode root = new StringTreeNode("root");
		assertEquals("root", root.toString());
		TreeNode child = new StringTreeNode("c");
		assertEquals("c", child.toString());
		root.addChildNode(child);
		// assertEquals("rc", root.toString());

		assertTwoNodes(root, child);
	}

	private static void assertRoot(TreeNode root, TreeNode child)
	{
		assertSame(child, root.getChildTreeNode());
		assertNull(root.getNextNode());
		assertNull(root.getParent());
		assertNull(root.getPrevious());
		assertSame(root, root.getRoot());
	}

	private static void assertThreeNodes(TreeNode root, TreeNode left, TreeNode right)
	{
		assertRoot(root, left);

		{
			assertNull(left.getChildTreeNode());
			assertSame(right, left.getNextNode());
			assertSame(root, left.getParent());
			assertNull(left.getPrevious());
			assertSame(root, left.getRoot());
		}

		{
			assertNull(right.getChildTreeNode());
			assertNull(right.getNextNode());
			assertSame(root, right.getParent());
			assertSame(left, right.getPrevious());
			assertSame(root, right.getRoot());
		}
	}

	public void test_addTwoNodes()
	{
		TreeNode root = new StringTreeNode("root");
		assertEquals("root", root.toString());

		TreeNode left = new StringTreeNode("left");
		assertEquals("left", left.toString());
		root.addChildNode(left);

		TreeNode right = new StringTreeNode("right");
		assertEquals("right", right.toString());
		root.addChildNode(right);

		assertThreeNodes(root, left, right);
	}

	public void test_addNodeTail()
	{
		TreeNode root = new StringTreeNode("root");
		assertEquals("root", root.toString());

		TreeNode left = new StringTreeNode("left");
		assertEquals("left", left.toString());
		root.addChildNode(left);

		TreeNode right = new StringTreeNode("right");
		assertEquals("right", right.toString());
		root.addChildNodeTail(right);

		assertThreeNodes(root, left, right);
	}

	public void test_addNodeHead_TODO()
	{
		TreeNode root = new StringTreeNode("root");
		assertEquals("root", root.toString());

		TreeNode right = new StringTreeNode("right");
		assertEquals("right", right.toString());
		root.addChildNodeHead(right);

		TreeNode left = new StringTreeNode("left");
		assertEquals("left", left.toString());
		root.addChildNodeHead(left);

		// assertThreeNodes(root, left, right);
	}

	public void test_threeNodesDeleteLeft()
	{
		TreeNode root = new StringTreeNode("root");
		assertEquals("root", root.toString());

		TreeNode left = new StringTreeNode("left");
		assertEquals("left", left.toString());
		root.addChildNode(left);

		TreeNode right = new StringTreeNode("right");
		assertEquals("right", right.toString());
		root.addChildNode(right);

		assertRoot(root, left);
		root.removeChild(left);
		assertRoot(root, right);

		{
			assertNull(left.getChildTreeNode());
			assertNull(left.getNextNode());
			assertNull(left.getParent());
			assertNull(left.getPrevious());
			// assertNull(left.getRoot());	 returns "this" for single node
		}

		{
			assertNull("Right node should not have child node, but received: " + right.getChildTreeNode(), right.getChildTreeNode());
			assertNull("Right node should not have next node, but received: " + right.getNextNode(), right.getNextNode());
			assertSame(root, right.getParent());
			assertNull("Right node should not have previous node, but received: " + right.getPrevious(), right.getPrevious());
			assertSame(root, right.getRoot());
		}
	}

	public void test_threeNodesDeleteRight()
	{
		TreeNode root = new StringTreeNode("root");
		assertEquals("root", root.toString());

		TreeNode left = new StringTreeNode("left");
		assertEquals("left", left.toString());
		root.addChildNode(left);

		TreeNode right = new StringTreeNode("right");
		assertEquals("right", right.toString());
		root.addChildNode(right);

		assertRoot(root, left);
		root.removeChild(right);
		assertRoot(root, left);

		{
			assertNull("Left node should not have child node, but received: " + left.getChildTreeNode(), left.getChildTreeNode());
			assertNull("Left node should not have next node, but received: " + left.getNextNode(), left.getNextNode());
			assertSame(root, left.getParent());
			assertNull("Left node should not have previous node, but received: " + left.getPrevious(), left.getPrevious());
			assertSame(root, left.getRoot());
		}

		{
			assertNull(right.getChildTreeNode());
			assertNull(right.getNextNode());
			assertNull(right.getParent());
			assertNull(right.getPrevious());
			// assertNull(right.getRoot());	 returns "this" for single node
		}
	}

	private static final class StringTreeNode extends TreeNode
	{
		private final String m_sLabel;
		public StringTreeNode(String sLabel)
		{
			m_sLabel = sLabel;
		}

		public String toString()
		{
			return m_sLabel;
		}
		
		public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
		{
			out.print(m_sLabel);
		}
	}
}
