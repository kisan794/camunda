/*
 * @(#)$RCSfile: XMLObjectTest.java,v $ $Revision: 1.9 $ $Date: 2009/12/18 07:13:16 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/parser/XMLObjectTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev			2006-06-06	created unit test
 *	A.Solntsev			2007-11-19	Much more tests
 *	A.Solntsev			2008-10-24	All methods renamed to CamelCase
 *	A.Solntsev			2009-03-12	Removed method release() (not used anywhere)
 */
package hireright.sdk.html.parser;
import hireright.sdk.util.CClass;

import java.io.InputStream;
import java.io.PrintStream;

import com.google.common.collect.Sets;

import junit.framework.AssertionFailedError;
import junit.framework.TestCase;

/**
 * Unit test for old XML parser (hireright.sdk.html.parser.XMLObject)
 *
 * @author Andrei Solntsev
 * @since java_sdk_v2-6-13
 * @version $Revision: 1.9 $ $Date: 2009/12/18 07:13:16 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/parser/XMLObjectTest.java,v $
 */
public class XMLObjectTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	public XMLObjectTest()
	{
		super(XMLObject.class.getName());
	}

	private static XMLObject parse(String sFileName) throws XMLObjectException
	{
		String sFileUrl = "/hireright/sdk/html/parser/" + sFileName;
		InputStream in = XMLObjectTest.class.getResourceAsStream(sFileUrl);
		assertNotNull("File " + sFileUrl + " is not found", in);

		XMLObject xml = new XMLObject( in, sFileUrl );
		return xml;
	}

	public void testSimpleXml() throws XMLObjectException
	{
		final XMLObject xml = parse("simple.xml");
		assertNotNull(xml);

		{
			String sXml = xml.toString();
			assertEquals("<first_name id=\"fname\">Johny</first_name>", sXml);
		}

		final XMLTreeNode fName = xml.getNode("first_name");

		{
			assertNotNull(fName);
			assertEquals("Johny", fName.getText());
			assertEquals("fname", fName.getAttribText("id"));
			assertSame(fName, xml.getNode("first_name", 1));
		}

		{
			XMLTreeNode fNameByPath = xml.getNodeByPath("first_name");
			assertSame(fName, fNameByPath);
		}

		{
			assertEquals(1, xml.getAttributesCount("id"));
			assertEquals(1, xml.getAttributesCount("id", "fname"));
			assertEquals(0, xml.getAttributesCount("id", ""));
			assertEquals("fname", xml.getAttributeValue("id", 1));
			assertNull(xml.getAttributeValue("id", 2));
			assertSame(fName, xml.getNodeByAttribute("id"));
			assertSame(fName, xml.getNodeByAttribute("id", 1));
			assertNull(xml.getNodeByAttribute("id", 2));
			assertSame(fName, xml.getNodeByAttribute("id", "fname"));
			assertNull(xml.getNodeByAttribute("id", ""));
			assertSame(fName, xml.getNodeByAttribute("id", "fname", 1));
			assertNull(xml.getNodeByAttribute("id", "fname", 2));
			assertEquals(1, xml.getNodesCount("first_name"));
			assertEquals(0, xml.getNodesCount("id"));
			assertEquals(0, xml.getNodesCount("fname"));
		}
	}

	public void testGetNodeByTagAttribute() throws XMLObjectException
	{
		final XMLObject xml = parse("simple.xml");
		final XMLTreeNode fName = xml.getNode("first_name");

		assertSame(fName, xml.getNodeByTagAttribute("first_name", "id", "fname"));
		assertNull(xml.getNodeByTagAttribute("first_name", "id", "fname2"));
		assertNull(xml.getNodeByTagAttribute("first_name2", "id", "fname"));
		assertNull(xml.getNodeByTagAttribute("first_name", "id2", "fname"));
		assertNull(xml.getNodeByTagAttribute("first_name", "id2", null));
		assertNull(xml.getNodeByTagAttribute("first_name", null, "fname"));
		assertNull(xml.getNodeByTagAttribute("", "id", "fname"));
		assertNull(xml.getNodeByTagAttribute(null, "id", "fname"));
	}

	public void testEmptyAttributeValue() throws XMLObjectException
	{
		final XMLObject xml = parse("empty_attribute_value.xml");
		assertNotNull(xml);

		{
			String sXml = xml.toString();
			assertEquals("<first_name id=\"fname\" value=\"\">Johny</first_name>", sXml);
		}

		final XMLTreeNode fName = xml.getNode("first_name");

		{
			assertNotNull(fName);
			assertEquals("Johny", fName.getText());
			assertEquals("fname", fName.getAttribText("id"));
			assertSame(fName, xml.getNode("first_name", 1));
		}

		{
			assertEquals(1, xml.getAttributesCount("id"));
			assertEquals("fname", xml.getAttributeValue("id", 1));
			assertNull(xml.getAttributeValue("id", 2));
			assertSame(fName, xml.getNodeByAttribute("id"));
		}

		{
			assertEquals(1, xml.getAttributesCount("value"));
			assertEquals("", xml.getAttributeValue("value", 1));
			assertNull(xml.getAttributeValue("value", 2));
			assertSame(fName, xml.getNodeByAttribute("value"));
		}
	}

	public void testCopyConstructor() throws XMLObjectException
	{
		XMLObject xml = parse("simple.xml");
		assertNotNull(xml);
		assertEquals(1, xml.getAttributesCount("id"));

		XMLObject copy = new XMLObject(xml);
		assertEquals(xml.toString(), copy.toString());
		assertEquals(1, copy.getAttributesCount("id"));

		{
			assertNotSame(xml.getAttribute("id", 1), copy.getAttribute("id", 1));
			assertEquals(xml.getAttributeValue("id", 1), copy.getAttributeValue("id", 1));
		}

		{
			XMLTreeNode fName = copy.getNode("first_name");
			assertNotNull(fName);
			assertEquals("Johny", fName.getText());
			assertEquals("fname", fName.getAttribText("id"));
		}
	}

	public void testCopyRemoveAttr() throws XMLObjectException
	{
		XMLObject xml = parse("simple.xml");
		assertNotNull(xml);

		XMLObject copy = new XMLObject(xml);
		assertEquals(xml.toString(), copy.toString());

		{
			copy.removeAllAttributes("id");
			assertEquals("<first_name id=\"fname\">Johny</first_name>", xml.toString());
			assertEquals("<first_name>Johny</first_name>", copy.toString());
		}
	}

	public void testRemoveAllNodes() throws XMLObjectException
	{
		XMLObject xml = parse("simple.xml");
		assertNotNull(xml);

		xml.removeNode("first_name");
		assertEquals("", xml.toString());

		{
			XMLTreeNode fName = xml.getNode("first_name");
			assertNull("After removing node XMLObject should not have " +
					"node 'first_name', but received: '" + fName + "'", fName);

			assertNull(xml.getAttribute("id", 1));
			assertEquals(0, xml.getAttributesCount("id"));
		}
	}

	public void testRemoveNodeByIndex() throws XMLObjectException
	{
		XMLObject xml = parse("simple.xml");
		assertNotNull(xml);

		xml.removeNode("first_name", 1);
		assertEquals("", xml.toString());

		{
			XMLTreeNode fName = xml.getNode("first_name");
			assertNull("After removing node XMLObject should not have " +
					"node 'first_name', but received: '" + fName + "'", fName);
		}
	}

	public void testRemoveNodeByAttribute() throws XMLObjectException
	{
		XMLObject xml = parse("simple.xml");
		assertNotNull(xml);
		xml.removeNodesByAttribute("id", "fname");
		assertEquals("", xml.toString());

		{
			XMLTreeNode fName = xml.getNode("first_name");
			assertNull("After removing node XMLObject should not have " +
					"node 'first_name', but received: '" + fName + "'", fName);
		}
	}

	public void testAddRemoveAttribute() throws XMLObjectException
	{
		XMLObject xml = parse("simple.xml");
		XMLTreeNode fName = xml.getNode("first_name");
		fName.addAttribNode("name", "attrName");
		fName.addAttribNode("src", "http://");
		assertEquals("<first_name id=\"fname\" name=\"attrName\" src=\"http://\">Johny</first_name>", xml.toString());

		xml.removeAllAttributes("id");
		assertEquals("<first_name name=\"attrName\" src=\"http://\">Johny</first_name>", xml.toString());
	}

	public void testRemoveAttribute() throws XMLObjectException
	{
		XMLObject xml = parse("simple.xml");
		assertNotNull(xml);

		xml.removeAttribute("id");
		assertEquals("<first_name>Johny</first_name>", xml.toString());

		{
			XMLTreeNode fName = xml.getNode("first_name");
			assertNotNull(fName);
			assertEquals("Johny", fName.getText());
			assertNull(fName.getAttribNode("id"));
			assertNull(fName.getAttribText("id"));
		}

		{
			assertEquals(0, xml.getAttributesCount("id"));
			assertEquals(0, xml.getAttributesCount("id", "fname"));
			assertEquals(0, xml.getAttributesCount("id", ""));
			assertNull(xml.getAttributeValue("id", 1));
			assertNull(xml.getAttributeValue("id", 2));
			assertNull(xml.getNodeByAttribute("id"));
			assertNull(xml.getNodeByAttribute("id", 1));
			assertNull(xml.getNodeByAttribute("id", 2));
			assertNull(xml.getNodeByAttribute("id", "fname"));
			assertNull(xml.getNodeByAttribute("id", ""));
			assertNull(xml.getNodeByAttribute("id", "fname", 1));
			assertNull(xml.getNodeByAttribute("id", "fname", 2));
			assertEquals(1, xml.getNodesCount("first_name"));
			assertEquals(0, xml.getNodesCount("id"));
			assertEquals(0, xml.getNodesCount("fname"));
		}
	}

	public void testRemoveAllAttributes() throws XMLObjectException
	{
		XMLObject xml = parse("simple.xml");
		assertNotNull(xml);

		xml.removeAllAttributes("id");
		assertEquals("<first_name>Johny</first_name>", xml.toString());
	}

	public void testNotClosedTag()
	{
		try
		{
			XMLObject xml = parse("not_closed_tag.xml");
			throw new AssertionFailedError("XML Parser should throw exception on invalid xml " +
					"not_closed_tag.xml; parsed XML: " + xml.toString());
		}
		catch (XMLObjectException xmle)
		{
			assertEquals( "Tag is not closed: projectGroup/projectGroup2", xmle.getMessage());
		}
	}

	public void testNotClosedAttribute_TODO()
	{
		try
		{
			XMLObject xml = parse("not_closed_attribute.xml");
			String sTemp = xml.toString();

			// TODO
			throw new AssertionFailedError("XML Parser should throw exception on invalid xml " +
				"not_closed_attribute.xml, but received: " + sTemp);
		}
		catch (XMLObjectException xmle)
		{
			// assertEquals( "Attribute is not closed", xmle.getMessage());
			assertEquals( "Tag projects/projectGroup/project is not closed", xmle.getMessage());
		}
	}

	public void testDuplicateAttribute_TODO()
	{
		try
		{
			XMLObject xml = parse("duplicate_attribute.xml");
			xml.toString();

			// TODO
			//throw new AssertionFailedError("XML Parser should throw exception on invalid xml " +
			//	"duplicate_attribute.xml, but received: " + sTemp);
		}
		catch (XMLObjectException xmle)
		{
			assertEquals( "Duplicate attribute versionNumber", xmle.getMessage());
		}
	}

	public void testMixedNode_TODO() 
	{
		//XMLObject xml = parse("mixed_node.xml");
		//assertEquals("Some text before tag" + "Some text after tag", xml.getNode("version").getText());
	}

	public void testEmptyXml() throws XMLObjectException
	{
		XMLObject xml = parse("empty.xml");
		assertEquals("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", xml.toString());
	}

	public void testParsingCorrectnessNodeByNode() throws XMLObjectException
	{
		//id=\"1\"
		String sXml = "<data_node><first_name>Pjotr</first_name><middle_name /><last_name suffix=\"jr.\" /></data_node>";
		// System.out.println(sXml);
		XMLObject xml = new XMLObject(sXml);

		XMLTreeNode root = xml.getRootNode();
		assertEquals("ROOT", root.getXMLTag());
		assertEquals("", root.getText());

		XMLTreeNode data_node = root.getChildNode();
		assertEquals("data_node", data_node.getXMLTag());
		assertEquals("", data_node.getText());

		XMLTreeNode first_name = data_node.getChildNode();
		assertEquals("first_name", first_name.getXMLTag());
		assertEquals("Pjotr", first_name.getText());

		assertEquals(sXml, xml.toString());
	}

	public void testParsingCorrectness() throws XMLObjectException
	{
		XMLObject xml = parse("Issue.xml");
		// assertEquals("1.0", xml.getAttribute("version", 1));

		assertEquals(2, xml.getAttributesCount("nr"));
		
		assertEquals(Sets.newHashSet("1", "2"),
				Sets.newHashSet(xml.getAttribute("nr", 1).getText(), xml.getAttribute("nr", 2).getText()));

		assertEquals(Sets.newHashSet("1", "2"),
				Sets.newHashSet(xml.getAttributeValue("nr", 1), xml.getAttributeValue("nr", 2)));
		
		assertEquals(1, xml.getNodesCount("Issue"));
		assertEquals(1, xml.getNodesCount("Data"));
		assertEquals(1, xml.getNodesCount("Matches"));
		assertEquals(2, xml.getNodesCount("Match"));
		assertEquals(2, xml.getNodesCount("Text"));
		assertEquals(2, xml.getNodesCount("Actors"));

		XMLTreeNode node = xml.getNodeByTagAttribute("Match", "nr", "2");
		assertEquals("Closed connection passed to procedure. Call me jesli chto.",
				node.getChildNodeByTag("Text").getText());
		assertEquals("another@email.com",
				node.getChildNodeByTag("Actors").getText());
	}

	private static void assertEmptyXml(XMLObject xml)
	{
		assertEquals("", xml.toString());

		assertNull(xml.getNode("first_name"));
		assertNull(xml.getNode("first_name", 1));
		assertNull(xml.getNode("id"));
		assertEquals(0, xml.getNodesCount("first_name"));

		assertNull(xml.getAttribute("id", 1));
		assertEquals(0, xml.getAttributesCount("id"));
		assertNull(xml.getAttributeValue("id", 1));

		assertNull(xml.getNodeByAttribute("id"));
		assertNull(xml.getNodeByAttribute("id", 1));
	}

	public void testMergeXMLObjects() throws XMLObjectException
	{
		final String sJohnXml = "<first_name id=\"fname\">Johny</first_name>";
		final String sBillXml = "<first_name id=\"fname\">Billy</first_name>";
		XMLObject john = new XMLObject(sJohnXml);
		XMLObject bill = new XMLObject(sBillXml);
		XMLObject list = new XMLObject("<employers/>");

		list.getNode("employers").addChildNodeTail(john.getNode("first_name"));
		list.getNode("employers").addChildNodeTail(bill.getNode("first_name"));

		assertEmptyXml(john);
		assertEmptyXml(bill);

		assertEquals("<employers>"+sJohnXml+sBillXml+"</employers>", list.toString());
		assertEquals(2, list.getNodesCount("first_name"));
		assertEquals(2, list.getAttributesCount("id"));
	}

	private static String formatMemorySize(long bytes)
	{
		if (bytes < 0)
			return ""+bytes;

		long megaBytes = bytes >> 20;
		long kiloBytes = (bytes >> 10) % 1024;

		return megaBytes + "." + kiloBytes;
	}

	public void test_hugeXml() throws XMLObjectException, InterruptedException
	{
		testHugeXml("projects.xml", false, true);
	}

	/*
	 * Results of unmodified parser (old classes):
	 * 	Parsing took 1812 ms.
	 * 	Serialization took 1031 ms.
	 * 	Used memory 13948264 bytes
	 *
	 * BufferedReader (1024):
	 * Parsing took 1640 ms.
	 * Serialization took 1157 ms.
	 * Used memory 164520 bytes
	 */
	public static void testHugeXml(String sFileName, boolean verbose, boolean testSerialization) throws XMLObjectException, InterruptedException
	{
		final PrintStream log = System.out;
		
		System.gc();
		Thread.sleep(1000);
		long freemem1 = Runtime.getRuntime().freeMemory();
		long start = System.currentTimeMillis();
		XMLObject xml = parse(sFileName);
		long parsed = System.currentTimeMillis();
		long freemem2 = Runtime.getRuntime().freeMemory();

		int nXmlLength = xml.toString(true).trim().length();
		long serialized = System.currentTimeMillis();

		// assertNotNull("Serilaized XML should not be null", sXML);
		assertTrue("Serilaized XML should be quite long. Instead, it has length " + nXmlLength,
				nXmlLength > 1024);

		assertTrue("Parsing should not take longer than 300 seconds. But it took "
				+ (parsed - start) + " ms. ", (parsed - start) < 1000*300);

		assertTrue("Serialization should not take longer than 300 seconds. But it took "
				+ (serialized - parsed) + " ms. ", (serialized - parsed) < 1000*300);

		assertTrue("Parsed XML should not raise more than 300 MB of memory. But it raised ~"
				+ formatMemorySize(freemem1 - freemem2) + " MB. ",
				(freemem1 - freemem2) < 300 * 1024 * 1024);

		if (verbose)
		{
			log.println("Parsing took " + (parsed - start) + " ms. ");
			log.println("Serialization took " + (serialized - parsed) + " ms. ");
			log.println("Used memory " + formatMemorySize(freemem1 - freemem2) + " MB ");
			// System.out.println("Get Root node: " + XMLTreeNode.totalGetRootNode + " ms. ");
			// System.out.println("Get XML Object: " + XMLTreeNode.totalGetXmlObject + " ms. ");
		}

		System.gc();
		Thread.sleep(500);

		if (testSerialization)
		{
			String serializedXmlObject = CClass.checkSerializable(xml, (int) (1.5*nXmlLength));
			assertNotNull("Failed to serialize XMLObject", serializedXmlObject);

			if (verbose)
				log.println("Object size: " + formatMemorySize(serializedXmlObject.length()) + " MB");

			assertTrue("Serilaized XML Object should not raise more than 12 MB of memory. But it raised ~"
					+ formatMemorySize(serializedXmlObject.length()) + " MB. ",
					serializedXmlObject.length() < 12 * 1024 * 1024);

			xml = null;

			System.gc();
			Thread.sleep(500);
		}
	}

	public static void main(String[] args) throws XMLObjectException, InterruptedException
	{
		//test_hugeXml("projects.big.xml", true, true);	// for time measurement
		testHugeXml("projects.xml", true, false);  // for profiling
	}
}
