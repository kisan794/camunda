/*
 * @(#)$RCSfile: XMLTreeNodeTest.java,v $Revision: 1.7 $ $Date: 2009/04/07 12:00:53 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/parser/XMLTreeNodeTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 *	A.Solntsev		2007-11-19	created
 *	A.Solntsev		2008-11-18	Added test-cases for equals() and hashCode()
 *	A.Solntsev		2009-01-15	Added method getChildNodesByTag(final String xmlTag) for convenient for-loops
 */
package hireright.sdk.html.parser;

import hireright.sdk.html.utils.XHTMLInjector;
import junit.framework.TestCase;

/**
 * @author asolntsev
 * @since Nov 19, 2007
 * @version $Revision: 1.7 $ $Date: 2009/04/07 12:00:53 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/parser/XMLTreeNodeTest.java,v $
 */
public class XMLTreeNodeTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
	private static final String XML_TEMPLATE =
		"<?xml version=\"1.0\"?>" +
		"<data_node id=\"data_node\">" +
		"	<node id=\"index\">&nbsp;</node>" +
		"</data_node>";
	
	private XMLObject xml1Man, xml3Men;
	private XMLTreeNode xml3MenRoot;
	
	@Override
	public void setUp() throws Exception
	{
		super.setUp();
		xml1Man = new XMLObject("<data_node/>");
		xml1Man.getNode("data_node").addChildNode("first_name", "John");
		
		xml3Men = new XMLObject("<data_node/>");
		{
			XMLTreeNode root = xml3Men.getNode("data_node");
			root.addAttribNode("num", "1");
			root.addAttribNode("source", getClass().getName()+".setUp()");
			XMLTreeNode fn1 = root.addChildNode("first_name", "John1"); fn1.addAttribNode("id", "1");
			XMLTreeNode fn2 = root.addChildNode("first_name", "John2"); fn2.addAttribNode("id", "2");
			XMLTreeNode fn3 = root.addChildNode("first_name", "John3"); fn3.addAttribNode("id", "3");
		}
		
		xml3MenRoot = xml3Men.getNode("data_node");
	}

	public void test_addChildNode() 
	{
		assertEquals("<data_node><first_name>John</first_name></data_node>", xml1Man.toString());
	}
	
	public void testAddChildNodeAsXMLObject() throws XMLObjectException 
	{
		XMLObject xml = new XMLObject("<man><fname>Jon</fname></man>");
		XMLObject temp = new XMLObject("<lname>Bon Jovi</lname>");
		XMLTreeNode lname = temp.getNode("lname");
		
		xml.getNode("man").addChildNodeTail(lname);
		assertEquals("<man><fname>Jon</fname><lname>Bon Jovi</lname></man>", xml.toString());
	}
	
	public void test_addChildNodeCData() throws XMLObjectException
	{
		XMLObject xml = new XMLObject("<data_node/>");
		xml.getNode("data_node").addChildNode("first_name", "John", XMLConsts.TYPE_CDATA);

		assertEquals("<data_node><first_name><![CDATA[John]]></first_name></data_node>", xml.toString());
	}
	
	public void testNodeDublicateBranch_TODO() throws XMLObjectException
	{
		XHTMLInjector xmlObject = new XHTMLInjector(XML_TEMPLATE);

		XMLTreeNode dataNode = xmlObject.getNodeByAttribute("id", "data_node");
		XMLTreeNode node = xmlObject.getNodeByAttribute("id", "index");
		for (int i=0; i<10; i++)
		{
			dataNode.dublicateBranch(node, i); // >>>>> (2003) Zavisajet <<<<<
			dataNode.getChildNodeByTag("node").setText("node"+i);
		}

		String sXML = xmlObject.toString(true);
		assertNotNull(sXML);
	}
	
	public void testEqualsAndHashCode()
	{
		XMLTreeNode a = new XMLTreeNode("aa");
		XMLTreeNode a2 = new XMLTreeNode("a" + "a");
		assertEquals(a, a2);
		assertEquals(a.hashCode(), a2.hashCode());
	}
	
	public void testEqualsAndHashCodeForEmptyTags()
	{
		XMLTreeNode a = new XMLTreeNode();
		XMLTreeNode a2 = new XMLTreeNode();
		assertEquals(a, a2);
		assertEquals(a.hashCode(), a2.hashCode());
	}
	
	public void testEqualsAndHashCodeForNullTags()
	{
		XMLTreeNode a = new XMLTreeNode(null);
		XMLTreeNode a2 = new XMLTreeNode(null);
		assertEquals(a, a2);
		assertEquals(a.hashCode(), a2.hashCode());
	}
	
	public void testGetChildNodeByTag()
	{
		assertNull( xml3MenRoot.getChildNodeByTag("first_name", 0) );
		assertEquals( "John1", xml3MenRoot.getChildNodeByTag("first_name", 1).getText() );
		assertEquals( "John2", xml3MenRoot.getChildNodeByTag("first_name", 2).getText() );
		assertEquals( "John3", xml3MenRoot.getChildNodeByTag("first_name", 3).getText() );
		assertNull( xml3MenRoot.getChildNodeByTag("first_name", 4) );
		assertNull( xml3MenRoot.getChildNodeByTag("first_name", 5) );
		
		assertEquals(3, xml3MenRoot.getChildNodesListByTag("first_name").size());
		xml3MenRoot.removeChildNode("first_name");
		assertEquals(2, xml3MenRoot.getChildNodesListByTag("first_name").size());
		xml3MenRoot.removeChildNode("first_name");
		assertEquals(1, xml3MenRoot.getChildNodesListByTag("first_name").size());
		xml3MenRoot.removeChildNode("first_name");
		assertEquals(0, xml3MenRoot.getChildNodesListByTag("first_name").size());
		xml3MenRoot.removeChildNode("first_name");
		assertEquals(0, xml3MenRoot.getChildNodesListByTag("first_name").size());
	}
	
	public void testGetChildNodesByTag()
	{
		int i=1;
		for ( XMLTreeNode node : xml3MenRoot.getChildNodesByTag("first_name") )
		{
			assertEquals("John"+i, node.getText());
			i++;
		}
	}
	
	public void testRemoveNodesByAttribute()
	{
		assertEquals(3, xml3MenRoot.getChildNodesListByTag("first_name").size());
		xml3Men.removeNodesByAttribute("id", "1");
		assertEquals(2, xml3MenRoot.getChildNodesListByTag("first_name").size());
		xml3Men.removeNodesByAttribute("id", "2");
		assertEquals(1, xml3MenRoot.getChildNodesListByTag("first_name").size());
		xml3Men.removeNodesByAttribute("id", "3");
		assertEquals(0, xml3MenRoot.getChildNodesListByTag("first_name").size());
	}
	
	public void testRemovAttribNode()
	{
		assertEquals(3, xml3MenRoot.getChildNodesListByTag("first_name").size());
		xml3MenRoot.getChildNodeByTag("first_name", 1).removeAttribNode("id");
		xml3MenRoot.getChildNodeByTag("first_name", 1).removeAttribNode("id");
		xml3MenRoot.getChildNodeByTag("first_name", 2).removeAttribNode("id");
		
		assertEquals(3, xml3MenRoot.getChildNodesListByTag("first_name").size());
	}
}
