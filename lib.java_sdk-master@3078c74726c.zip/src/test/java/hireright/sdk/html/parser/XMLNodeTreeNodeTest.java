/*
 * @(#)$RCSfile: XMLNodeTreeNodeTest.java,v $Revision: 1.2 $ $Date: 2007/11/30 09:28:15 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/parser/XMLNodeTreeNodeTest.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			Nov 9, 2007	created
 */
package hireright.sdk.html.parser;

import junit.framework.TestCase;

/**
 * @author asolntsev
 * @since Nov 9, 2007
 * @version $Revision: 1.2 $ $Date: 2007/11/30 09:28:15 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/html/parser/XMLNodeTreeNodeTest.java,v $
 */
public class XMLNodeTreeNodeTest extends TestCase
{
	public void testConstructor()
	{
		XMLNodeTreeNode text = new XMLNodeTreeNode("name", "value");
		assertEquals("name", text.getXMLTag());
		assertEquals("value", text.getText());
		assertEquals(XMLConsts.TYPE_NODE, text.getType());
		assertEquals("value", text.getValue());
		assertEquals("<name>value</name>", text.toString());
	}

	public void testClone()
	{
		XMLNodeTreeNode text = new XMLNodeTreeNode("name", "value");
		XMLNodeTreeNode text2 = (XMLNodeTreeNode) text.dublicate();

		assertEquals("<name>value</name>", text.toString());
		assertEquals("<name>value</name>", text2.toString());
	}
}
