/*
 * @(#)$RCSfile: CHTTPPosterTest.java,v $ $Revision: 1.6 $ $Date: 2015/05/09 08:54:19 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/net/CHTTPPosterTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev			2009-04-06	Created
 *	A.Solntsev			2009-08-28	Removed testPostToRemoteService(): it often break compilation
 */
package hireright.sdk.net;

import hireright.tests.junit.CResourceUtils;

import java.net.URL;

import junit.framework.TestCase;

/**
 *
 * @author Andrei Solntsev
 * @version $Revision: 1.6 $, $Date: 2015/05/09 08:54:19 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/net/CHTTPPosterTest.java,v $
 */
public class CHTTPPosterTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	public static boolean isWindows()
	{
		return System.getProperty("os.name" ).startsWith( "Windows" );
	}
	
	public void testPostToLocalFileUrl() throws CHTTPPosterException
	{
		URL url = CResourceUtils.getResource("/designs/general/xhtml/error.xhtml");
		// String url = "file:///D:/CVS/projects_src/workspaces/generic_webapp/projects/sdk_webpayment/pom.xml";
		CHTTPPoster poster = new CHTTPPoster();
		poster.setData( "TEST DATA" );
		poster.publish( url.toString(), 2000 );
		if (isWindows() && !url.toString().startsWith("jar:"))
			assertEquals(3698, poster.getContentLength());
		else if(poster.getResponseContent() != null && poster.getResponseContent().contains("/usr/local/cvsroot_shared/"))
			assertEquals(3705, poster.getContentLength());
		else
			assertEquals(3698, poster.getContentLength());
	}
	
	public void testPostToRemoteService() throws CHTTPPosterException
	{
		/*
		String url = "http://idc-jboss01.hireright.com:6800/transform/pdf_convert";	// FIXME Hardcode!!!
		CHTTPPoster poster = new CHTTPPoster();
		poster.setData( "TEST DATA" );
		poster.publish( url, 2000 );
		assertEquals(56, poster.getContentLength());
		assertEquals("NO FO document in request body (length < 10 characters)", poster.getResponseContent().trim());
		assertEquals("text/plain", poster.getResponseContentType());
		*/
	}
}
