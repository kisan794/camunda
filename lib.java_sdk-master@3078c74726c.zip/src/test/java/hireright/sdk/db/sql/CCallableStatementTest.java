/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	V.Ozernov				2017-09-04		HIVPE-2252 Created
 */

package hireright.sdk.db.sql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

public class CCallableStatementTest extends TestCase
{
	@SuppressWarnings("serial")
	class CCallableStatementMock extends CCallableStatement
	{
		private final Map<Integer, ISqlValue> m_assignedInputSqlValues = new HashMap<Integer, ISqlValue>();
		private final Map<Integer, Integer> m_registeredOutputSqlTypes = new HashMap<Integer, Integer>();
		
		public CCallableStatementMock(String sStatement)
		{
			super(sStatement);
		}
		
		@Override
		protected void prepareCall(Connection connection, String sJdbcCompatibleStatement) throws SQLException
		{
		}
		
		@Override
		protected void doExecute(CallableStatement callableStatement) throws SQLException
		{
		}
		
		@Override
		protected void doSetValueToCallableStatement(ISqlValue value, CallableStatement callableStatement, int nIndex) 
				throws SQLException
		{
			m_assignedInputSqlValues.put(Integer.valueOf(nIndex), value);
		}
		
		@Override
		protected void doRegisterOutParameter(CallableStatement callableStatement, int nIndex, int nSqlType)
				throws SQLException
		{
			m_registeredOutputSqlTypes.put(Integer.valueOf(nIndex), Integer.valueOf(nSqlType));
		}
		
		@Override
		public int getOutParameterIndexInStatement(String sParameterName)
		{
			return super.getOutParameterIndexInStatement(sParameterName);
		}
		
		@Override
		protected String getJdbcCompatibleStatement()
		{
			return super.getJdbcCompatibleStatement();
		}

		public ISqlValue getAssignedInputSqlValue(int nIndex)
		{
			return m_assignedInputSqlValues.get(Integer.valueOf(nIndex));
		}
		
		public int getRegisteredOutputSqlType(int nIndex)
		{
			return m_registeredOutputSqlTypes.get(Integer.valueOf(nIndex)).intValue();
		}
	}
	
	public void testQuestionMarkStatementAndNumericBinding() throws CCallableStatementException
	{
		final String sStateIn = 
				"{ ? = call sdk_address.get_countryName(?) }";
		final String sStateJdbc = 
				"{ ? = call sdk_address.get_countryName(?) }";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.registerOutParameter(1, Types.VARCHAR);
		cs.setInteger(2, 100);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertEquals(cs.getRegisteredOutputSqlType(1), Types.VARCHAR);
		assertEquals(cs.getOutParameterIndexInStatement("1"), 1);
		assertEquals(cs.getAssignedInputSqlValue(2).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(2).getValue(), Integer.valueOf(100));
	}
	
	public void testQuestionMarkStatementAndSeqCallBinding() throws CCallableStatementException
	{
		final String sStateIn = 
				"{ ? = call sdk_address.get_countryName(?) }";
		final String sStateJdbc = 
				"{ ? = call sdk_address.get_countryName(?) }";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.registerOutParameter("CountryName", Types.VARCHAR);
		cs.setInteger("CountryID", 100);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertEquals(cs.getRegisteredOutputSqlType(1), Types.VARCHAR);
		assertEquals(cs.getOutParameterIndexInStatement("CountryName"), 1);
		assertEquals(cs.getAssignedInputSqlValue(2).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(2).getValue(), Integer.valueOf(100));
	}

	public void testNumericParameterStatementAndNumericBinding() throws CCallableStatementException
	{
		final String sStateIn = 
				"{ :2 = call sdk_address.get_countryName(:1) }";
		final String sStateJdbc = 
				"{ ? = call sdk_address.get_countryName(?) }";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.registerOutParameter(2, Types.VARCHAR);
		cs.setInteger(1, 100);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertEquals(cs.getRegisteredOutputSqlType(1), Types.VARCHAR);
		assertEquals(cs.getOutParameterIndexInStatement("2"), 1);
		assertEquals(cs.getAssignedInputSqlValue(2).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(2).getValue(), Integer.valueOf(100));
	}
	
	public void testNumericParameterStatementAndSeqCallBinding() throws CCallableStatementException
	{
		final String sStateIn = 
				"{ :1 = call sdk_address.get_countryName(:2) }";
		final String sStateJdbc = 
				"{ ? = call sdk_address.get_countryName(?) }";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.registerOutParameter("CountryName", Types.VARCHAR);
		cs.setInteger("CountryID", 100);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertEquals(cs.getRegisteredOutputSqlType(1), Types.VARCHAR);
		assertEquals(cs.getOutParameterIndexInStatement("CountryName"), 1);
		assertEquals(cs.getAssignedInputSqlValue(2).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(2).getValue(), Integer.valueOf(100));
	}

	public void testNamedParameterStatementAndNumericBinding() throws CCallableStatementException
	{
		final String sStateIn = 
				"{ :countryName = call sdk_address.get_countryName(:countryID) }";
		final String sStateJdbc = 
				"{ ? = call sdk_address.get_countryName(?) }";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.registerOutParameter(1, Types.VARCHAR);
		cs.setInteger(2, 100);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertEquals(cs.getRegisteredOutputSqlType(1), Types.VARCHAR);
		assertEquals(cs.getOutParameterIndexInStatement("1"), 1);
		assertEquals(cs.getAssignedInputSqlValue(2).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(2).getValue(), Integer.valueOf(100));
	}
	
	public void testNamedParameterStatementAndSeqCallBinding() throws CCallableStatementException
	{
		final String sStateIn = 
				"{ :countryName = call sdk_address.get_countryName(:countryID) }";
		final String sStateJdbc = 
				"{ ? = call sdk_address.get_countryName(?) }";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.registerOutParameter("myCountryName", Types.VARCHAR);
		cs.setInteger("myCountryID", 100);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertEquals(cs.getRegisteredOutputSqlType(1), Types.VARCHAR);
		assertEquals(cs.getOutParameterIndexInStatement("myCountryName"), 1);
		assertEquals(cs.getAssignedInputSqlValue(2).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(2).getValue(), Integer.valueOf(100));
	}

	public void testNamedParameterStatementAndNameBinding() throws CCallableStatementException
	{
		final String sStateIn = 
				"{ :countryName = call sdk_address.get_countryName(:countryID) }";
		final String sStateJdbc = 
				"{ ? = call sdk_address.get_countryName(?) }";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.setInteger("countryID", 100);
		cs.registerOutParameter("countryName", Types.VARCHAR);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertEquals(cs.getRegisteredOutputSqlType(1), Types.VARCHAR);
		assertEquals(cs.getOutParameterIndexInStatement("countryName"), 1);
		assertEquals(cs.getAssignedInputSqlValue(2).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(2).getValue(), Integer.valueOf(100));
	}

	public void testPlSqlStatement() throws CCallableStatementException
	{
		final String sStateIn = 
				"DECLARE \n" +
				"	sCountryName VARCHAR2(128) := NULL; \n" +
				"BEGIN" +
				 "	sCountryName := sdk_address.get_countryName(:CountryID); \n" +
				 "	:CountryName := sCountryName; \n" +
				 "END;";
		final String sStateJdbc = 
				"DECLARE \n" +
				"	sCountryName VARCHAR2(128) := NULL; \n" +
				"BEGIN" +
				 "	sCountryName := sdk_address.get_countryName(?); \n" +
				 "	? := sCountryName; \n" +
				 "END;";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.setInteger("CountryID", 100);
		cs.registerOutParameter("CountryName", Types.VARCHAR);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertEquals(cs.getRegisteredOutputSqlType(2), Types.VARCHAR);
		assertEquals(cs.getOutParameterIndexInStatement("CountryName"), 2);
		assertEquals(cs.getAssignedInputSqlValue(1).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(1).getValue(), Integer.valueOf(100));
	}

	public void testPlSqlStrangeCharactersStatement() throws CCallableStatementException
	{
		final String sStateIn = 
				"DECLARE \n" +
				"	sCountryName VARCHAR2(128) := NULL; \n" +
				"BEGIN" +
				 "	sCountryName := sdk_address.get_countryName(:CountryID$); \n" +
				 "	:CountryName# := sCountryName; \n" +
				 "END;";
		final String sStateJdbc = 
				"DECLARE \n" +
				"	sCountryName VARCHAR2(128) := NULL; \n" +
				"BEGIN" +
				 "	sCountryName := sdk_address.get_countryName(?); \n" +
				 "	? := sCountryName; \n" +
				 "END;";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.setInteger("CountryID$", 100);
		cs.registerOutParameter("CountryName#", Types.VARCHAR);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertEquals(cs.getRegisteredOutputSqlType(2), Types.VARCHAR);
		assertEquals(cs.getOutParameterIndexInStatement("CountryName#"), 2);
		assertEquals(cs.getAssignedInputSqlValue(1).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(1).getValue(), Integer.valueOf(100));
	}

	public void testPlSqlLargeStatement() throws CCallableStatementException
	{
		final String sStateIn = 
				"DECLARE\n" +
						" recServicePrice bdk_service_price_calc.trecServicePrice;\n" +
						" recPostalAddress sdk_postal_address.trecPostalAddress;\n"+
						" sCountryCode	VARCHAR(3);\n"+
						"BEGIN \n" +
						" sCountryCode := :sCountryCode;\n"+
						" IF LENGTH(sCountryCode) = 3 THEN\n"+
						"   sCountryCode := sdk_location.get_countryCodeA2ByA3(sCountryCode);\n"+
						" END IF;\n"+
						" recPostalAddress.country_code := sCountryCode;\n"+
						" recPostalAddress.region1 := :sRegion1;\n"+
						" recPostalAddress.region2 := :sRegion2;\n"+
						" recPostalAddress.municipality := :sMunicipality;\n"+
						" recPostalAddress.postal_code := :sPostalCode;\n"+
						" recServicePrice := bdk_service_price_calc.get_servicePrice(" +
						"                    :nCustomerID," +
						"                    :nServiceID," +
						"                    :nService#," +
						"                    :nIsPackaged," +
						"                    :nPackageID," +
						"                    recPostalAddress," +
						"                    :sCampaignCode);\n"+

						" :nPrice := recServicePrice.nBasePrice;\n" +
						" :nSurcharge := recServicePrice.nSurcharge;\n" +
						" :nDiscountAmount := recServicePrice.recAppliedDiscount.nDiscountAmount;\n"+
						" :nDiscountPercent := recServicePrice.recAppliedDiscount.nDiscountPercent;\n"+
						" :nCampaignObjectUsageID := recServicePrice.recAppliedDiscount.nCampaignObjectUsageID;\n"+
						" :sPostalCode := recPostalAddress.postal_code;\n"+
						"END;\n";
		final String sStateJdbc = 
				"DECLARE\n" +
						" recServicePrice bdk_service_price_calc.trecServicePrice;\n" +
						" recPostalAddress sdk_postal_address.trecPostalAddress;\n"+
						" sCountryCode	VARCHAR(3);\n"+
						"BEGIN \n" +
						" sCountryCode := ?;\n"+
						" IF LENGTH(sCountryCode) = 3 THEN\n"+
						"   sCountryCode := sdk_location.get_countryCodeA2ByA3(sCountryCode);\n"+
						" END IF;\n"+
						" recPostalAddress.country_code := sCountryCode;\n"+
						" recPostalAddress.region1 := ?;\n"+
						" recPostalAddress.region2 := ?;\n"+
						" recPostalAddress.municipality := ?;\n"+
						" recPostalAddress.postal_code := ?;\n"+
						" recServicePrice := bdk_service_price_calc.get_servicePrice(" +
						"                    ?," +
						"                    ?," +
						"                    ?," +
						"                    ?," +
						"                    ?," +
						"                    recPostalAddress," +
						"                    ?);\n"+
						" ? := recServicePrice.nBasePrice;\n" +
						" ? := recServicePrice.nSurcharge;\n" +
						" ? := recServicePrice.recAppliedDiscount.nDiscountAmount;\n"+
						" ? := recServicePrice.recAppliedDiscount.nDiscountPercent;\n"+
						" ? := recServicePrice.recAppliedDiscount.nCampaignObjectUsageID;\n"+
						" ? := recPostalAddress.postal_code;\n"+
						"END;\n";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.setString("sCountryCode", "USA");
		cs.setString("sRegion1", "CA");
		cs.setString("sRegion2", "Orange");
		cs.setString("sMunicipality", "Irvine");
		cs.setString("sPostalCode", "12345");
		cs.setInteger("nCustomerID", 46234746);
		cs.setInteger("nServiceID", 500);
		cs.setInteger("nService#", 1);
		cs.setInteger("nIsPackaged", 0);
		cs.setInteger("nPackageID", null);
		cs.setString("sCampaignCode", "AAA");
		cs.registerOutParameter("nPrice", Types.DECIMAL);
		cs.registerOutParameter("nSurcharge", Types.DECIMAL);
		cs.registerOutParameter("nDiscountAmount", Types.DECIMAL);
		cs.registerOutParameter("nDiscountPercent", Types.DECIMAL);
		cs.registerOutParameter("nCampaignObjectUsageID", Types.INTEGER);
		cs.registerOutParameter("sPostalCode", Types.VARCHAR);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertEquals(cs.getAssignedInputSqlValue(1).getSqlType(), Types.VARCHAR);
		assertEquals(cs.getAssignedInputSqlValue(1).getValue(), "USA");
		assertEquals(cs.getAssignedInputSqlValue(2).getSqlType(), Types.VARCHAR);
		assertEquals(cs.getAssignedInputSqlValue(2).getValue(), "CA");
		assertEquals(cs.getAssignedInputSqlValue(3).getSqlType(), Types.VARCHAR);
		assertEquals(cs.getAssignedInputSqlValue(3).getValue(), "Orange");
		assertEquals(cs.getAssignedInputSqlValue(4).getSqlType(), Types.VARCHAR);
		assertEquals(cs.getAssignedInputSqlValue(4).getValue(), "Irvine");
		assertEquals(cs.getAssignedInputSqlValue(5).getSqlType(), Types.VARCHAR);
		assertEquals(cs.getAssignedInputSqlValue(5).getValue(), "12345");
		assertEquals(cs.getAssignedInputSqlValue(6).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(6).getValue(), Integer.valueOf(46234746));
		assertEquals(cs.getAssignedInputSqlValue(7).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(7).getValue(), Integer.valueOf(500));
		assertEquals(cs.getAssignedInputSqlValue(8).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(8).getValue(), Integer.valueOf(1));
		assertEquals(cs.getAssignedInputSqlValue(9).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(9).getValue(), Integer.valueOf(0));
		assertEquals(cs.getAssignedInputSqlValue(10).getSqlType(), Types.INTEGER);
		assertEquals(cs.getAssignedInputSqlValue(10).getValue(), null);
		assertEquals(cs.getAssignedInputSqlValue(11).getSqlType(), Types.VARCHAR);
		assertEquals(cs.getAssignedInputSqlValue(11).getValue(), "AAA");
		assertEquals(cs.getRegisteredOutputSqlType(12), Types.DECIMAL);
		assertEquals(cs.getOutParameterIndexInStatement("nPrice"), 12);
		assertEquals(cs.getRegisteredOutputSqlType(13), Types.DECIMAL);
		assertEquals(cs.getOutParameterIndexInStatement("nSurcharge"), 13);
		assertEquals(cs.getRegisteredOutputSqlType(14), Types.DECIMAL);
		assertEquals(cs.getOutParameterIndexInStatement("nDiscountAmount"), 14);
		assertEquals(cs.getRegisteredOutputSqlType(15), Types.DECIMAL);
		assertEquals(cs.getOutParameterIndexInStatement("nDiscountPercent"), 15);
		assertEquals(cs.getRegisteredOutputSqlType(16), Types.INTEGER);
		assertEquals(cs.getOutParameterIndexInStatement("nCampaignObjectUsageID"), 16);
		assertEquals(cs.getRegisteredOutputSqlType(17), Types.VARCHAR);
		assertEquals(cs.getOutParameterIndexInStatement("sPostalCode"), 17);
	}

	public void testNoParameterStatement() throws CCallableStatementException
	{
		final String sStateIn = 
				"{ call sdk_address.get_countryName() }";
		final String sStateJdbc = 
				"{ call sdk_address.get_countryName() }";
		
		CCallableStatementMock cs = new CCallableStatementMock(sStateIn);
		cs.execute();
		
		assertEquals(cs.getJdbcCompatibleStatement(), sStateJdbc);
		assertNull(cs.getAssignedInputSqlValue(1));
	}
}
