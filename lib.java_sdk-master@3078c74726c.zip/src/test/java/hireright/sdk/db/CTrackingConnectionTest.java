/*
 * @(#)$RCSfile: CTrackingConnectionTest.java,v $ $Revision: 1.3.4.2.4.1 $ $Date: 2015/07/06 11:19:46 $ $Author: atanasenko $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	atanasenko	3. juuni 2015	Created
 */
package hireright.sdk.db;

import java.util.Set;

import junit.framework.TestCase;

public class CTrackingConnectionTest extends TestCase {
	
	public void testTrackedKeywords() {
		
		assertTrue(register("select updated from bla").isEmpty());
		assertTrue(register("select inserted from bla").isEmpty());
		assertTrue(register("select insert_something from bla").isEmpty());
		assertTrue(register("select something_update from bla").isEmpty());
		
		assertFalse(register("update bla").isEmpty());
		assertFalse(register("select something;update bla").isEmpty());
		assertFalse(register("select something; update bla").isEmpty());
		assertFalse(register("insert bla").isEmpty());
		assertFalse(register("select something;insert bla").isEmpty());
		assertFalse(register("select something;insert bla").isEmpty());
		assertFalse(register("select something; insert bla").isEmpty());
		
		assertFalse(register("bla sdk_state_machine.change_instState(").isEmpty());
		assertFalse(register("sdk_state_machine.change_instState").isEmpty());
		assertFalse(register("bla sdk_state_machine.change_instState asdf").isEmpty());
		assertFalse(register("\tsdk_state_machine.change_instState\n").isEmpty());
		
		assertTrue(register("bla sdk_state_machine.change_instStates").isEmpty());
		
	}
	
	private static Set<String> register(String ... statements) {
		CTrackingConnection conn = new CTrackingConnection(null);
		if(statements != null) {
			for(String stmt: statements) {
				conn.registerStatement(stmt, 0);
			}
		}
		return conn.getUncommittedStatements();
	}
	
}
