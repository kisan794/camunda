/*
 * @(#)$RCSfile: CTraceLogTest.java,v $ $Revision: 1.5 $ $Date: 2007/09/14 09:17:33 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Solntsev		2005-03-31	created
 *  A.Solntsev		2006-04-18	Method CTraceLog.truncate() moved to class CStringUtils.
 *  A.Solntsev		2006-05-19	CLOB and BLOB are lazy-loaded
 *  A.Solntsev		2006-11-10	Moved to package hireright.objects.logs
 */
package hireright.sdk.debug;
public final class CTraceLogTest 
{
	public CTraceLogTest()
	{
	}
}