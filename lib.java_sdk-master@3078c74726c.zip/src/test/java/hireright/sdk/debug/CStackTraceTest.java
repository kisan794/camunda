/*
 * @(#)$RCSfile: CStackTraceTest.java,v $ $Revision: 1.6 $ $Date: 2007/09/14 09:17:30 $ $Author: asolntsev $
 *
 * Copyright 2005-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Solntsev		2005-04-01	created
 *  A.Solntsev		2005-07-23	Added test case "OutOfMemoryException".
 *  A.Solntsev		2006-09-10	Fixed check for class name ("(Unknown Source)")
 */
package hireright.sdk.debug;
import java.io.Serializable;

import junit.framework.TestCase;

/**
 * Unit-test for testing class CStackTrace.
 */
public class CStackTraceTest extends TestCase implements Serializable
{
	public CStackTraceTest()
	{
		super("CStackTrace Unit-test");
	}
	
	public void testStackTraceException()
	{
		String stack = CStackTrace.getStackTrace(new Exception("test exception"));
		//System.out.println("\n" + stack + "\n");
		
		String sMsg = "java.lang.Exception: test exception";
		String sMethodName = "testStackTraceException";
		
		assertNotNull(stack);
		assertTrue("Stack Trace should starts with words '" + sMsg
				+"', but it starts with " + stack.substring(0, sMsg.length()),
				stack.startsWith(sMsg));
		
		assertTrue("Stack trace should contain name of method in which the exception occurred",
				stack.indexOf(sMethodName) > sMsg.length());
		
		assertTrue("Stack trace should contain name of class in which the exception occurred",
				stack.indexOf("CStackTraceTest.java") > stack.indexOf(sMethodName) + sMethodName.length() ||
				stack.indexOf("(Unknown Source)") < stack.indexOf(sMethodName) + sMethodName.length()+3);
	}

	public void testStackTrace()
	{
		String stack = CStackTrace.getStackTrace();
		//System.out.println("\n" + stack + "\n");
		
		String sMethodName = "testStackTrace";
		assertNotNull("Stack Trace must notbe null", stack);
		assertTrue("Stack Trace should starts with words '" + CStackTrace.MESSAGE_STACK_TRACE
				+"', but it starts with " + stack.substring(0, CStackTrace.MESSAGE_STACK_TRACE.length()),
				stack.startsWith(CStackTrace.MESSAGE_STACK_TRACE));
		
		assertTrue("Stack trace should contain name of method in which the exception occurred", 
				stack.indexOf(sMethodName) > CStackTrace.MESSAGE_STACK_TRACE.length());
		
		assertTrue("Stack trace should contain name of class in which the exception occurred",
				stack.indexOf("CStackTraceTest.java") > stack.indexOf(sMethodName) + sMethodName.length() ||
				stack.indexOf("(Unknown Source)") < stack.indexOf(sMethodName) + sMethodName.length()+3);
	}
	
	public void testErrorSource()
	{
		String sStackTrace = "---------\n" +
			"java.io.FileNotFoundException: http://localhost:8080//designs/n-age/hr/xsl2/recruiter_review.xslt\n" +
			"	at sun.net.www.protocol.http.HttpURLConnection.getInputStream(HttpURLConnection.java:798)\n" +
			"	at java.net.URL.openStream(URL.java:913)\n" +
			"	at oracle.xml.parser.v2.XMLReader.openURL(XMLReader.java:2133)\n" +
			"	at oracle.xml.parser.v2.XMLReader.pushXMLReader(XMLReader.java:206)\n" +
			"	at oracle.xml.parser.v2.XMLParser.parse(XMLParser.java:148)\n" +
			"	at oracle.xml.jaxp.JXSAXTransformerFactory.newTemplates(JXSAXTransformerFactory.java:325)\n" +
			"	at hireright.sdk.transform.HTMLTransformer.getCachedTransformer(HTMLTransformer.java:137)\n" +
			"	at hireright.sdk.transform.HTMLTransformer.<init>(HTMLTransformer.java:57)\n" +
			" ... ";
		String sErrorSource = "sun.net.www.protocol.http.HttpURLConnection.getInputStream(HttpURLConnection.java:798)";
	
		assertEquals(sErrorSource, CStackTrace.getExceptionSource(sStackTrace));
	}
	
	public void testOutOfMemory()
	{
		String sStackTrace = "java.lang.OutOfMemoryException";
		assertEquals("java.lang", CStackTrace.getExceptionSource(sStackTrace));
	}
}