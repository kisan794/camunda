/*
 * @(#)$RCSfile: CFEMailTest.java,v $ $Revision: 1.4 $ $Date: 2008/12/19 13:10:20 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/format_util/CFEMailTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * A.Solntsev		2007-09-25	created
 * A.Solntsev		2008-04-22	Added more tests (test coverage is now 100%)
 * A.Solovyev		2008-12-09	Apostroph is added in tested email's in methods test_checkValidEmail() and test_parseValidEmail().
 */
package hireright.sdk.format_util;
import junit.framework.TestCase;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.4 $, $Date: 2008/12/19 13:10:20 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/format_util/CFEMailTest.java,v $
 */
public class CFEMailTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	private static final String sInvalidEmail = "somebody@somehost~.com";
	private static final String sDuplicatedDoggieEmail = "somebody@somehost.fi@sdef";

	public CFEMailTest()
	{
		super(CFEMail.class.getName());
	}

	public void test_parseNull()
	{
		CFEMail fEmail = new CFEMail(null);
		assertFalse(fEmail.isValid());
	}

	public void test_parseEmptyString()
	{
		CFEMail fEmail = new CFEMail("");
		assertFalse(fEmail.isValid());
	}

	public void test_parseSpaces()
	{
		CFEMail fEmail = new CFEMail("   ");
		assertFalse(fEmail.isValid());
	}

	public void test_parseValidEmail()
	{
		CFEMail fEmail = new CFEMail("some'body@somehost.fi");
		assertTrue(fEmail.isValid());
		assertEquals( "some'body@somehost.fi", fEmail.toString() );
	}
	
	public void test_parseInvalidEmail()
	{
		CFEMail fEmail = new CFEMail(sInvalidEmail);
		assertFalse(fEmail.isValid());
	}
	
	public void test_parseduplicatedDoggieEmail()
	{
		CFEMail fEmail = new CFEMail(sDuplicatedDoggieEmail);
		assertFalse(fEmail.isValid());
	}
	
	public void test_getXmlTag()
	{
		CFEMail fEmail = new CFEMail("somebody@somehost.fi");
		assertEquals( "e-mail", fEmail.getXMLTag().getXMLTag() );
	}

	public void test_checkValidEmail() throws CInvalidEmailException
	{
		CFEMail.checkEmailSyntax("some'body@somehost.fi");
	}

	public void test_checkEmptyEmail()
	{
		try
		{
			CFEMail.checkEmailSyntax("");
			fail("Method checkEmailSyntax() should throw CInvalidEmailException on input ''");
		}
		catch (CInvalidEmailException e)
		{
			// This is expected behaviour
		}
	}
	
	public void test_checkInvalidEmail()
	{
		try
		{
			CFEMail.checkEmailSyntax(sInvalidEmail);
			fail("Method checkEmailSyntax() should throw CInvalidEmailException on input '" + sInvalidEmail + "'");
		}
		catch (CInvalidEmailException e)
		{
			// This is expected behaviour
		}
	}
	
	public void test_checkDuplicatedDoggie()
	{
		try
		{
			CFEMail.checkEmailSyntax(sDuplicatedDoggieEmail);
			fail("Method checkEmailSyntax() should throw CInvalidEmailException on input '" + sDuplicatedDoggieEmail + "'");
		}
		catch (CInvalidEmailException e)
		{
			// This is expected behaviour
		}
	}
}