/*
 * @(#)$RCSfile: ThreadSafeDateFormatTest.java,v $ $Revision: 1.5 $ $Date: 2009/03/20 10:33:27 $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/format_util/ThreadSafeDateFormatTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev		2008-11-13	Created
 *	A.Solntsev		2009-03-12	Removed useless test testThreadUnsafeParserThrowsNumberFormatException()
 */
package hireright.sdk.format_util;

import hireright.sdk.util.CCounter;
import hireright.sdk.util.CSynchronizedCounter;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import junit.framework.AssertionFailedError;
import junit.framework.TestCase;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.5 $, $Date: 2009/03/20 10:33:27 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/format_util/ThreadSafeDateFormatTest.java,v $
 */
public class ThreadSafeDateFormatTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss SSS";
	
	private final ThreadSafeDateFormat safeFormatter = new ThreadSafeDateFormat(DATE_FORMAT);
	private final DateFormat unsafeFormatter = new SimpleDateFormat(DATE_FORMAT);
	
	private static boolean manualRun = false;
	
	private static final String judgmentDayStr = "1998-08-27T01:02:03 000";
	Date judgmentDay;
	
	@SuppressWarnings("deprecation")
	@Override
	public void setUp() throws Exception
	{
		super.setUp();
		judgmentDay = new Date(98,7,27,1,2,3);
	}
	
	public void testSingleThread() throws ParseException
	{
		assertEquals(judgmentDay, safeFormatter.parse(judgmentDayStr));
		assertEquals(safeFormatter.format(judgmentDay), judgmentDayStr);
		
		assertEquals(judgmentDay, unsafeFormatter.parse(judgmentDayStr));
		assertEquals(unsafeFormatter.format(judgmentDay), judgmentDayStr);
	}
	
	public void testThreadSafeParserInConucrrentThreads() throws InterruptedException
	{
		int errors = runMultipleThreads(safeFormatter, 100, 100);
		assertEquals("ThreadSafeDateFormat should work correctly in multi-threaded environvent, but received " +
				+ errors + " errors", 0, errors);
	}
	
	public void testThreadUnsafeParserThrowsNumberFormatException() throws InterruptedException
	{
		if (manualRun)
		{
			try
			{
				int errors = runMultipleThreads(unsafeFormatter, 100, 100);
				assertTrue("SimpleDateFormat should throw NumberFormatException, " +
						"but worked correctly in " + (100-errors) + " of 100 threads", errors > 0);
			}
			catch (NumberFormatException e)
			{
				// This is expected behaviour
			}
		}
	}
	
	private int runMultipleThreads(final DateFormat formatter, 
			final int threadsCount, final int testsPerThread) throws InterruptedException
	{
		final CCounter activeThreads = new CSynchronizedCounter("activeThreads");
		final CCounter errors = new CSynchronizedCounter("errors");

		for (int i=0; i<threadsCount; i++)
		{
			new Thread()
			{
				@Override
				public void run()
				{
					activeThreads.inc();
					try
					{
						for (int j=0; j<testsPerThread; j++)
						{
							assertEquals(judgmentDay, formatter.parse(judgmentDayStr));
							assertEquals(formatter.format(judgmentDay), judgmentDayStr);

							Thread.sleep((int) (10*Math.random())); 
						}
					}
					catch (ParseException e) {errors.inc();}
					catch (NumberFormatException e) {errors.inc();}
					catch (AssertionFailedError e) {errors.inc();}
					catch (ArrayIndexOutOfBoundsException e) {errors.inc();}
					catch (InterruptedException e) {return;}
					finally
					{
						activeThreads.dec();
					}
				}
			}.start();
		}
		
		Thread.sleep(10);
		
		while (activeThreads.getCount() > 0)
		{
			Thread.sleep(20);
		}
		
		return errors.getCount();
	}
	
}
