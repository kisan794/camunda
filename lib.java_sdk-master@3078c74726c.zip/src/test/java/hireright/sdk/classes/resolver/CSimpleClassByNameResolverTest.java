/*
 * @(#)$RCSfile: CSimpleClassByNameResolverTest.java,v $ $Revision: 1.3 $ $Date: 2009/11/20 11:28:51 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/classes/resolver/CSimpleClassByNameResolverTest.java,v $
 * 
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 * 
 * This software is the confidential and proprietary information of HireRight,
 * Inc. Use is subject to license terms.
 * 
 * History: 
 *	A.Solntsev		2008-04-22	created (test coverage is 100%)
 *	A.Solntsev		2009-10-12	Migrated to JUnit 4
 */
package hireright.sdk.classes.resolver;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.fail;
import hireright.sdk.util.CSystemConfigurationException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

/**
 * 
 * @author Andrei Solntsev
 * @version $Revision: 1.3 $, $Date: 2009/11/20 11:28:51 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/classes/resolver/CSimpleClassByNameResolverTest.java,v $
 */
public class CSimpleClassByNameResolverTest
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
	
	@Test
	public void empty()
	{
		CSimpleClassByNameResolver resolver = new CSimpleClassByNameResolver();
		assertNull( resolver.resolve( "class1" ) );
		assertNull( resolver.resolve( "" ) );
		assertNull( resolver.resolve( null ) );
	}
	
	@Test
	public void addClass()
	{
		CSimpleClassByNameResolver resolver = new CSimpleClassByNameResolver();
		resolver.addClass( "map", "java.util.HashMap" );
		resolver.addClass( "list", "java.util.ArrayList" );
		
		assertNull( resolver.resolve( "class1" ) );
		assertSame(HashMap.class, resolver.resolve( "map" ) );
		assertSame(ArrayList.class, resolver.resolve( "list" ) );
	}
	
	@Test
	public void constructor()
	{
		Map<String, String> mapping = new HashMap<String, String>();
		mapping.put( "map", "java.util.HashMap" );
		mapping.put( "list", "java.util.ArrayList" );
		
		CSimpleClassByNameResolver resolver = new CSimpleClassByNameResolver(mapping);
		assertNull( resolver.resolve( "class1" ) );
		assertSame(HashMap.class, resolver.resolve( "map" ) );
		assertSame(ArrayList.class, resolver.resolve( "list" ) );
	}
	
	@Test(expected=CSystemConfigurationException.class)
	public void classNotFoundException()
	{
		CSimpleClassByNameResolver resolver = new CSimpleClassByNameResolver();
		resolver.addClass( "map", "java.util.HashMap" );
		
		resolver.addClass( "list", "java.util.ArrayList666" );
			
		Class<?> unexistingClass = resolver.resolve( "list" );
		fail("Trying to resolve unexisting class should throw CSystemConfigurationException, but received: " + unexistingClass);		
	}
}
