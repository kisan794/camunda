/*
 * @(#)$RCSfile: CFileContentTest.java,v $ $Revision: 1.6 $ $Date: 2010/01/08 08:52:14 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CFileContentTest.java,v $
 *
 * Copyright 2005-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	A.Solntsev			2005-04-14	created.
 * 	A.Solntsev			2006-09-09	Standard JUnit test
 */
package hireright.sdk.util;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

import junit.framework.TestCase;
import hireright.sdk.util.CFileContent;

/**
 * Unit test for class CFileContent
 * 
 * @author Andrei Solntsev
 * @since 2005-04-14
 */
public class CFileContentTest extends TestCase implements Serializable
{
	public CFileContentTest(String sTestName)
	{
		super(sTestName);
	}
	
	public void testNotFound()
	{
		try
		{
			String sFileContent = CFileContent.getText(new File("./non-existing-file"), 1024);
			
			throw new AssertionError("Should throw IOException for nonexisting file, " +
					"but the following content was read: " + sFileContent);
		}
		catch (Exception ioe)
		{
			// It's all right
			return;
		}
	}
	
	public void testFileContent() throws IOException
	{
		String sFileContent = "ABCDEFGHIJK_1234567890/*'@";
		File tempFile = createFile(sFileContent);
		
		String sReadContent = CFileContent.getText(tempFile).trim();
		assertEquals("Read content shoulw be equal to original content", sFileContent, sReadContent);
	}
	
	public void testInputStreamContent() throws IOException
	{
		String sFileContent = "ABCDEFGHIJK_1234567890/*'@";
		File tempFile = createFile(sFileContent);
		
		String sReadContent = CFileContent.getText( new FileReader(tempFile), 8 ).trim();
		assertEquals("Read content shoulw be equal to original content", sFileContent, sReadContent);
	}
	
	public void testUrlContent() throws IOException
	{
		String sFileContent = "ABCDEFGHIJK_1234567890/*'@";
		File tempFile = createFile(sFileContent);
		
		String sReadContent = CFileContent.getContent("file:////" + tempFile.getCanonicalPath()).trim();
		assertEquals("Read content shoulw be equal to original content", sFileContent, sReadContent);
	}
	
	public static File createFile(String sFileContent) throws IOException
	{
		File f = File.createTempFile("CFileContent", "Test", null);
		f.deleteOnExit();

		FileWriter wr = new FileWriter(f);
		wr.write(sFileContent);
		wr.flush();
		wr.close();
		
		return f;
	}
}