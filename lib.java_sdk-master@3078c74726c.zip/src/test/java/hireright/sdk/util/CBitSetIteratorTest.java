/*
 * @(#)$RCSfile: CBitSetIteratorTest.java,v $ $Revision: 1.6 $ $Date: 2009/03/20 10:33:33 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CBitSetIteratorTest.java,v $
 *
 * Copyright 2005-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	2005-06-27 	A.Solntsev			Created
 *	2008-02-05	A.Solntsev			Added test-case with null parameter
 *	2009-03-12	A.Solntsev			Using generics: implements Iterator<Integer>
 */
package hireright.sdk.util;
import java.io.Serializable;
import java.util.BitSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;
import junit.framework.TestCase;

/**
 * Unit test for class CBitSetIterator.
 * 
 * @author Andrei Solntsev
 * @since 2005-06-27, java_sdk_v2-5-27
 * @version $Revision: 1.6 $ $Date: 2009/03/20 10:33:33 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CBitSetIteratorTest.java,v $
 */
public class CBitSetIteratorTest extends TestCase implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	public CBitSetIteratorTest()
	{
		super("Unit test for class " + CBitSetIterator.class.getName());
	}
	
	public void test_3_numbers()
	{
		BitSet bs = new BitSet();
		bs.set(2);
		bs.set(5);
		bs.set(20);
		
		Iterator<Integer> it = new CBitSetIterator(bs);
		assertEquals(it.next(), new Integer(2));
		assertEquals(it.next(), new Integer(5));
		assertEquals(it.next(), new Integer(20));
		assertFalse(it.hasNext());
	}

	public void test_1_number()
	{
		BitSet bs = new BitSet();
		bs.set(666);
		
		Iterator<Integer> it = new CBitSetIterator(bs);
		assertEquals(it.next(), new Integer(666));
		assertFalse(it.hasNext());
	}
	
	public void testNoSuchElementException()
	{
		Iterator<Integer> it = new CBitSetIterator(new BitSet());
		try
		{
			Object obj = it.next();
			fail("Method next() should throw NoSuchElementException if iterator has no more elements, but it returned: " + obj);
		}
		catch (NoSuchElementException e)
		{
			// It's expected behaviour
		}
		
		assertFalse(it.hasNext());
	}

	public void test_0_numbers()
	{
		BitSet bs = new BitSet();
		
		Iterator<Integer> it = new CBitSetIterator(bs);
		assertFalse(it.hasNext());
	}
	
	public void test_null()
	{
		Iterator<Integer> it = new CBitSetIterator(null);
		assertFalse(it.hasNext());
	}
	
	public void test_createBitSet()
	{
		Set<Integer> modules = new HashSet<Integer>();
		modules.add(new Integer(12));
		modules.add(new Integer(23));
		modules.add(new Integer(34));
		modules.add(new Integer(45));
		
		BitSet bs = CBitSetIterator.createBitSet(modules);
		assertTrue(bs.get(12));
		assertTrue(bs.get(23));
		assertTrue(bs.get(34));
		assertTrue(bs.get(45));
		
		assertFalse(bs.get(0));
		assertFalse(bs.get(1));
		assertFalse(bs.get(5));
		assertFalse(bs.get(666));
	}
}