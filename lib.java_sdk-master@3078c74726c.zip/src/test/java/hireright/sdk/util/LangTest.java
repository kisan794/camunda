/*
 * @(#)$RCSfile: LangTest.java,v $ $Revision: 1.4 $ $Date: 2015/11/02 20:16:12 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/LangTest.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev				2009-10-21	created
 *	A.Solntsev				2010-01-07	Added method cast
 */
package hireright.sdk.util;

import static hireright.sdk.util.Lang.cast;
import static hireright.sdk.util.Lang.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class LangTest
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";

	@Test
	public void hashFromNull()
	{
		assertEquals( 0, Lang.hashCode( null ) );
	}
	
	@Test
	public void hashIsPositive()
	{
		assertTrue( Lang.hashCode( "Ja molodoj" ) > 0 );
	}
	
	@Test
	public void simpleEqual()
	{
		assertTrue( Lang.equal( "AA", "A"+"A") );
		assertTrue( Lang.equal( Integer.valueOf(2), Integer.valueOf(1+1)) );
	}
	
	@Test
	public void equalNull()
	{
		assertTrue( Lang.equal( null, null) );
		assertFalse( Lang.equal( "A", null) );
		assertFalse( Lang.equal( null, "A") );
	}
	
	@Test
	public void decode()
	{
		assertEquals( "11", Lang.decode( "aa", "aa", "11", "--") );
		assertEquals( "--", Lang.decode( "AA", "aa", "11", "--") );
		assertEquals( "--", Lang.decode( null, "aa", "11", "--") );
		
		assertEquals( "1", Lang.decode( "a", "a", "1", "b", "2", "c", "3", "none") );
		assertEquals( "2", Lang.decode( "b", "a", "1", "b", "2", "c", "3", "none") );
		assertEquals( "3", Lang.decode( "c", "a", "1", "b", "2", "c", "3", "none") );
		assertEquals( "none", Lang.decode( "d", "a", "1", "b", "2", "c", "3", "none") );
	}
	
	@Test
	public void decodeNull()
	{
		assertEquals( "NL", Lang.decode( null, null, "NL", "--") );
		assertNull( "NL", Lang.decode( null, null, null, "--") );		
	}
	
	@Test
	public void testAssertNotNull()
	{
		List nonGenericList = new ArrayList();
		assertNotNull(nonGenericList).add( "a" );
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testAssertNotNullThrowsException()
	{
		List nullObject = null;
		assertNotNull(nullObject).add( "a" );
	}
	
	@Test
	public void testCast()
	{
		List nonGenericList = new ArrayList();
		nonGenericList.add( "a" );
		
		List<String> genericList = cast(nonGenericList);
		assertEquals(1, genericList.size());
	}
	
	@Test
	public void nvlTest() {
		
		assertTrue(Lang.nvl(Boolean.TRUE, null));
		assertFalse(Lang.nvl(Boolean.FALSE, null));
		assertTrue(Lang.nvl(Boolean.TRUE, Boolean.FALSE));
		assertFalse(Lang.nvl(Boolean.FALSE, Boolean.TRUE));
		assertTrue(Lang.nvl((Boolean)null, Boolean.TRUE));
		assertFalse(Lang.nvl((Boolean)null, Boolean.FALSE));
		
		assertEquals("abc", Lang.nvl((CharSequence)"abc", new StringBuilder("def")));
	}
}
