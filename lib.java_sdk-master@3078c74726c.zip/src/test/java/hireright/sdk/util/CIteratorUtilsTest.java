/*
 * @(#)$RCSfile: CIteratorUtilsTest.java,v $ $Revision: 1.2 $ $Date: 2008/09/05 10:57:49 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CIteratorUtilsTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Solntsev			2008-08-27	created test-cases for ALL methods in class CIteratorUtils
 */
package hireright.sdk.util;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import junit.framework.TestCase;
import junitx.framework.ArrayAssert;

/**
 * @author Andrei Solntsev
 * @since java_sdk_v2-6-5
 * @version $Revision: 1.2 $ $Date: 2008/09/05 10:57:49 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CIteratorUtilsTest.java,v $
 */
public class CIteratorUtilsTest extends TestCase
{
	private List<Integer> NUMBERS;
	private List<String> STRINGS;
	
	@Override
	public void setUp() throws Exception
	{
		super.setUp();
		NUMBERS = Arrays.asList(new Integer[] {5, 4, 3, 2, 1});
		STRINGS = Arrays.asList(new String[] {"a", "b", "c", "d", "e"});
	}
	
	public void test_collectListFromEnumeration()
	{
		Vector<String> v = new Vector<String>(STRINGS);
		List<String> strings = CIteratorUtils.collectList(v.elements());
		assertEquals( STRINGS, strings );
	}
	
	public void test_collectListFromIterator()
	{
		List<Integer> numbers = CIteratorUtils.collectList(NUMBERS.iterator());
		assertEquals( NUMBERS, numbers );
	}
	
	public void test_collectSortedFromIterator()
	{
		Set<Integer> numbers = CIteratorUtils.collectSorted(NUMBERS.iterator());
		assertEquals( new TreeSet<Integer>(NUMBERS), numbers );
	}
	
	public void test_collectSortedFromEnumeration()
	{
		Vector<String> v = new Vector<String>(STRINGS);
		Set<String> strings = CIteratorUtils.collectSorted(v.elements());
		assertEquals( new TreeSet<String>(STRINGS), strings );
	}

	public void test_collectArrayFromEnumeration()
	{
		Vector<String> v = new Vector<String>(STRINGS);
		String[] strings = new String[1];
		strings = CIteratorUtils.collectArray(v.elements(), strings);
		
		assertEquals( STRINGS, Arrays.asList( strings ));
		ArrayAssert.assertEquals( STRINGS.toArray(), strings );
	}
	
	public void test_collectArrayFromIterator()
	{
		Object[] numbers = CIteratorUtils.collectArray(NUMBERS.iterator());
		assertEquals( NUMBERS, Arrays.asList( numbers ));
		ArrayAssert.assertEquals( NUMBERS.toArray(), numbers );
	}
	
	public void test_collectArrayFromIteratorToArray()
	{
		Object[] numbers = CIteratorUtils.collectArray(NUMBERS.iterator(), new Integer[]{});
		assertEquals( NUMBERS, Arrays.asList( numbers ));
		ArrayAssert.assertEquals( NUMBERS.toArray(), numbers );
	}
}
