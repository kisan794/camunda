/*
 * @(#)$RCSfile: CStringUtilsTest.java,v $ $Revision: 1.14 $ $Date: 2010/02/18 21:29:44 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CStringUtilsTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Solntsev			2005-12-04	created
 *   A.Solntsev			2006-02-08	Added methods substringBefore(), trim(), truncate().
 *   A.Solntsev			2006-05-08	Added method testRepace()
 *   A.Solntsev			2006-05-08	Added methods testDecode(), testArrayToString()
 *   A.Solntsev			2006-09-11	Added method testDecodeCaseInsensitive()
 *   A.Solntsev			2006-11-03	Added method testReplaceWholeWord()
 *   M.Abdulganejev		2007-10-29	Added methods testIsNumber(), testIsBoolean()
 *   A.Solntsev			2008-03-28	Added method listToString()
 *   E.Shatohhin		2008-05-12	Added method testToStringByPattern()
 *   A.Solntsev			2008-11-14	Added methods testPadLeft(), testPadRight().
 *   V.Ozernov			2020-09-30	HRG-129108 Added testIsPureASCII()
 *   A.Naboyshchikov	2022-06-03	HRG-201053: added testHasHtmlTags(..)
 */
package hireright.sdk.util;

import java.io.Serializable;
import java.util.Arrays;

import junit.framework.TestCase;

/**
 * Unit test for class hireright.sdk.util.CStringUtils
 * 
 * @author Andrei Solntsev
 * @version $Revision: 1.14 $ $Date: 2010/02/18 21:29:44 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CStringUtilsTest.java,v $
 */
public class CStringUtilsTest extends TestCase implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.14 $ $Author: cvsroot $";

	public CStringUtilsTest()
	{
		super("Unit test for class " + CStringUtils.class);
	}

	public void testNvl()
	{
		assertEquals("", CStringUtils.nvl(null));
		assertEquals("", CStringUtils.nvl(null, ""));
		assertEquals("", CStringUtils.nvl(null, CStringUtils.EMPTY_STRING));
		
		assertSame("abc", CStringUtils.nvl("abc"));
		assertSame("abc", CStringUtils.nvl("abc", "xyz"));
		assertEquals("abc", CStringUtils.nvl(null, "abc"));
	}

	public void testIsEmpty()
	{
		assertTrue(CStringUtils.isEmpty(null));
		assertTrue(CStringUtils.isEmpty(""));
		assertTrue(CStringUtils.isEmpty(CStringUtils.EMPTY_STRING));
		
		assertTrue(CStringUtils.isEmpty("   "));
		assertTrue(CStringUtils.isEmpty("										"));
		
		assertFalse(CStringUtils.isEmpty("null"));
		assertFalse(CStringUtils.isEmpty("-"));
	}

	public void testTruncate()
	{
		assertEquals("", CStringUtils.truncate("abcde", 0));
		assertEquals("a", CStringUtils.truncate("abcde", 1));
		assertEquals("ab", CStringUtils.truncate("abcde", 2));
		assertEquals("abc", CStringUtils.truncate("abcde", 3));
		assertEquals("abcd", CStringUtils.truncate("abcde", 4));
		assertEquals("abcde", CStringUtils.truncate("abcde", 5));
		assertEquals("abcde", CStringUtils.truncate("abcde", 6));
		
		assertEquals("a", CStringUtils.truncate("abcdefg", 1));
		assertEquals("", CStringUtils.truncate("abcdefg", 0));
		assertNull(CStringUtils.truncate(null, 2));
	}

	public void testTruncateBigString()
	{
		// Construct a very big string (32000 symbols)
		String sSampleString = "1234567890";
		StringBuffer sBigString = new StringBuffer(32000);
		for (int i=0; i<3200; i++)
		{
			sBigString.append(sSampleString);
		}
		assertEquals(sSampleString, CStringUtils.truncate(sBigString.toString(), sSampleString.length()));
		assertEquals("", CStringUtils.truncate(sBigString.toString(), 0));
	}

	public void testReplace()
	{
		assertEquals("", CStringUtils.replace("", "a", "b"));
		assertEquals("b", CStringUtils.replace("a", "a", "b"));
		assertEquals("bbb", CStringUtils.replace("aaa", "a", "b"));
		assertEquals("bbbbbbbb", CStringUtils.replace("abababab", "a", "b"));
	}

	public void testReplaceWholeWord()
	{
		assertEquals("", CStringUtils.replaceWholeWord("", "a", "b"));
		assertEquals("b", CStringUtils.replaceWholeWord("a", "a", "b"));
		assertEquals("aaa", CStringUtils.replaceWholeWord("aaa", "a", "b"));
		assertEquals("abababab", CStringUtils.replaceWholeWord("abababab", "a", "b"));
		
		assertEquals("BEGIN bb cc", CStringUtils.replaceWholeWord("aa bb cc", "aa", "BEGIN"));
		assertEquals("aa bb END", CStringUtils.replaceWholeWord("aa bb cc", "cc", "END"));
		
		assertEquals("_ :2 :10 :100 :010", 
				CStringUtils.replaceWholeWord("_ :1 :10 :100 :010", "1", "2"));
		
		assertEquals("_ :1 :TEN :100 :010", 
				CStringUtils.replaceWholeWord("_ :1 :10 :100 :010", "10", "TEN"));
	}

	/**
	 * Test method decode() with 1 match
	 * @since java_sdk_v2-6-9
	 */
	public void testDecode1()
	{
		assertEquals("empty", CStringUtils.decode("", "", "empty", "not empty"));
		assertEquals("not empty", CStringUtils.decode(" ", "", "empty", "not empty"));
	}

	/**
	 * Test method decode() with 2 matches
	 * @since java_sdk_v2-6-9
	 */
	public void testDecode2()
	{
		assertEquals("unknown", CStringUtils.decode("", ",", "comma", ".", "dot", "unknown"));
		assertEquals("unknown", CStringUtils.decode(" ", ",", "comma", ".", "dot", "unknown"));
		assertEquals("comma", CStringUtils.decode(",", ",", "comma", ".", "dot", "unknown"));
		assertEquals("dot", CStringUtils.decode(".", ",", "comma", ".", "dot", "unknown"));
		assertEquals("unknown", CStringUtils.decode(",.", ",", "comma", ".", "dot", "unknown"));
	}

	/**
	 * Test method decode() with 3 matches
	 * @since java_sdk_v2-6-9
	 */
	public void testDecode3()
	{
		assertEquals("unknown", CStringUtils.decode("", "a", "AAA", "b", "BBB", "c", "CCC", "unknown"));
		assertEquals("unknown", CStringUtils.decode(" ", "a", "AAA", "b", "BBB", "c", "CCC", "unknown"));
		assertEquals("AAA", CStringUtils.decode("a", "a", "AAA", "b", "BBB", "c", "CCC", "unknown"));
		assertEquals("BBB", CStringUtils.decode("b", "a", "AAA", "b", "BBB", "c", "CCC", "unknown"));
		assertEquals("CCC", CStringUtils.decode("c", "a", "AAA", "b", "BBB", "c", "CCC", "unknown"));
		assertEquals("unknown", CStringUtils.decode("abc", "a", "AAA", "b", "BBB", "c", "CCC", "unknown"));
		assertEquals("unknown", CStringUtils.decode("unknown", "a", "AAA", "b", "BBB", "c", "CCC", "unknown"));
	}

	/**
	 * Test method decode() with 4 matches
	 * @since java_sdk_v2-6-9
	 */
	public void testDecode4()
	{
		assertEquals("unknown", CStringUtils.decode("", "a", "AAA", "b", "BBB", "c", "CCC", "d", "DDD", "unknown"));
		assertEquals("unknown", CStringUtils.decode(" ", "a", "AAA", "b", "BBB", "c", "CCC", "d", "DDD", "unknown"));
		assertEquals("AAA", CStringUtils.decode("a", "a", "AAA", "b", "BBB", "c", "CCC", "d", "DDD", "unknown"));
		assertEquals("BBB", CStringUtils.decode("b", "a", "AAA", "b", "BBB", "c", "CCC", "d", "DDD", "unknown"));
		assertEquals("CCC", CStringUtils.decode("c", "a", "AAA", "b", "BBB", "c", "CCC", "d", "DDD", "unknown"));
		assertEquals("DDD", CStringUtils.decode("d", "a", "AAA", "b", "BBB", "c", "CCC", "d", "DDD", "unknown"));
		assertEquals("unknown", CStringUtils.decode("abcd", "a", "AAA", "b", "BBB", "c", "CCC", "d", "DDD", "unknown"));
		assertEquals("unknown", CStringUtils.decode("unknown", "a", "AAA", "b", "BBB", "c", "CCC", "d", "DDD", "unknown"));
	}

	public void testDecodeCaseInsensitive()
	{
		assertEquals("aaa", CStringUtils.decode("a", "A", "aaa", "B", "bbb", "unknown"));
		assertEquals("BBB", CStringUtils.decode("B", "a", "AAA", "b", "BBB", "c", "CCC", "unknown"));
		assertEquals("DDD", CStringUtils.decode("d", "A", "AAA", "B", "BBB", "C", "CCC", "D", "DDD", "unknown"));
	}

	/**
	 * @since java_sdk_v2-6-9
	 */
	public void testArrayToString()
	{
		assertEquals("{}", CStringUtils.arrayToString(new String[] {}));
		assertEquals("", CStringUtils.arrayToString(new String[] {}, ",")); //?
		assertEquals("{a}", CStringUtils.arrayToString(new String[] {"a"}));
		assertEquals("a,", CStringUtils.arrayToString(new String[] {"a"}, ","));
		assertEquals("{b, c}", CStringUtils.arrayToString(new String[] {"b", "c"}));
		assertEquals("b,c,", CStringUtils.arrayToString(new String[] {"b", "c"}, ","));
		// assertEquals("{1, 2, 3}", CStringUtils.arrayToString(new Integer[] {new Integer(1), new Integer(2), new Integer(3)}));
	}

	public void testObjectArrayToString()
	{
		assertEquals("{}", CStringUtils.arrayToString(new Object[] {}));
		assertEquals("", CStringUtils.arrayToString(new Object[] {}, ","));
		assertEquals("{a}", CStringUtils.arrayToString(new Object[] {"a"}));
		assertEquals("a,", CStringUtils.arrayToString(new Object[] {"a"}, ","));
		assertEquals("{b, c}", CStringUtils.arrayToString(new Object[] {"b", "c"}));
		assertEquals("b,c,", CStringUtils.arrayToString(new Object[] {"b", "c"}, ","));
		assertEquals("{1, 2, 3}", CStringUtils.arrayToString(new Object[] {new Integer(1), new Integer(2), new Integer(3)}));
		assertEquals("1,2,3,", CStringUtils.arrayToString(new Object[] {new Integer(1), new Integer(2), new Integer(3)}, ","));
	}

	public void testListToString()
	{
		assertEquals("", CStringUtils.listToString( Arrays.asList(new String[] {}) ));
		assertEquals("a", CStringUtils.listToString( Arrays.asList(new String[] {"a"}) ));
		assertEquals("b, c", CStringUtils.listToString( Arrays.asList(new String[] {"b", "c"}) ));
		assertEquals("1, 2, 3", CStringUtils.listToString( Arrays.asList(new Integer[] {new Integer(1), new Integer(2), new Integer(3)}) ));
	}

	public void testIsNumber()
	{
		assertTrue(CStringUtils.isNumber("1222222"));
		assertFalse(CStringUtils.isNumber("d19d59952"));
		assertFalse(CStringUtils.isNumber("19d59952*-"));
		assertFalse(CStringUtils.isNumber("CocaCola is pure evil"));
		
		assertTrue(CStringUtils.isNumber("-1959952"));
		assertTrue(CStringUtils.isNumber("+1959952", true));
		assertTrue(CStringUtils.isNumber("-1959952", true));
		assertTrue(CStringUtils.isNumber("1959952", true));
		assertFalse(CStringUtils.isNumber("?d19d59952", true));
		
		assertFalse(CStringUtils.isNumber(""));
		
	}

	public void testIsBoolean()
	{
		assertTrue(CStringUtils.isBoolean("true"));
		assertTrue(CStringUtils.isBoolean("false"));
		assertFalse(CStringUtils.isBoolean("yes"));
		assertFalse(CStringUtils.isBoolean("no"));
		assertFalse(CStringUtils.isBoolean(""));
		assertFalse(CStringUtils.isBoolean("TruE"));
	}

	public void testToStringByPattern()
	{
		final String test1 = "Object";
		
		Object obj = new Object() 
		{
			@SuppressWarnings("unused")
			public String getValue()
			{
				return test1;
			}
		};
		
		assertEquals( test1, CStringUtils.toStringByPattern( obj, "$Value" ) );
		assertEquals( test1, CStringUtils.toStringByPattern( obj, "$value" ) );
		assertEquals( "Some Object here", CStringUtils.toStringByPattern( obj, "Some $value here" ) );
		assertEquals( "!@#%^&*()_+", CStringUtils.toStringByPattern( obj, "!@#%^&*()_+" ) );
	}

	public void testPadLeft()
	{
		assertEquals("", CStringUtils.padLeft("", '_', 0));
		assertEquals("_", CStringUtils.padLeft("", '_', 1));
		
		assertEquals("_123", CStringUtils.padLeft("123", '_', 4));
		assertEquals("123", CStringUtils.padLeft("123", '_', 3));
		assertEquals("123", CStringUtils.padLeft("123", '_', 2));
	}

	public void testPadRight()
	{
		assertEquals("", CStringUtils.padRight("", '_', 0));
		assertEquals("_", CStringUtils.padRight("", '_', 1));
		
		assertEquals("123_", CStringUtils.padRight("123", '_', 4));
		assertEquals("123", CStringUtils.padRight("123", '_', 3));
		assertEquals("123", CStringUtils.padRight("123", '_', 2));
	}

	public void testInvertString()
	{
		assertEquals("12345", CStringUtils.invert("54321"));
		assertEquals("", CStringUtils.invert(""));
		assertEquals(null, CStringUtils.invert(null));
	}

	public void testEscapeHtml()
	{
		assertEquals(null, CStringUtils.escapeHTML(null));
		assertEquals("", CStringUtils.escapeHTML(""));
		assertEquals("12345", CStringUtils.escapeHTML("12345"));
		assertEquals("&lt;Person&gt;", CStringUtils.escapeHTML("<Person>"));
		assertEquals("some value &#39; value &quot; and &amp;", CStringUtils.escapeHTML("some value \' value \" and &"));
		assertEquals("&amp;amp;", CStringUtils.escapeHTML("&amp;"));
	}

	public void testUnescapeHtml()
	{
		assertEquals(null, CStringUtils.unescapeHTML(null));
		assertEquals("", CStringUtils.unescapeHTML(""));
		assertEquals("12345", CStringUtils.unescapeHTML("12345"));
		assertEquals("<Person>", CStringUtils.unescapeHTML("&lt;Person&gt;"));
		assertEquals("some value \' value \" and &", CStringUtils.unescapeHTML("some value &#39; value &quot; and &amp;"));
		assertEquals("&amp;", CStringUtils.unescapeHTML("&amp;amp;"));
	}

	public void testEquals()
	{
		assertTrue(CStringUtils.equals("&amp;","&amp;"));
		assertTrue(CStringUtils.equals(null,null));
		assertFalse(CStringUtils.equals(" ",null));
		assertFalse(CStringUtils.equals(null," "));
	}

	public void testEqualsOrEmptyIgnoreCase()
	{
		assertTrue(CStringUtils.equalsOrEmptyIgnoreCase("&amp;","&amp;"));
		assertTrue(CStringUtils.equalsOrEmptyIgnoreCase("&AMP;","&amp;"));
		assertTrue(CStringUtils.equalsOrEmptyIgnoreCase(null,null));
		assertTrue(CStringUtils.equalsOrEmptyIgnoreCase("",null));
		assertTrue(CStringUtils.equalsOrEmptyIgnoreCase(null," "));
	}

	public void testStripXMLUnsupportedChars()
	{
		assertEquals("<text>ABC</text>", CStringUtils.stripXMLUnsupportedChars("<text>AB\u0019C</text>"));
		assertEquals("<node></node>", CStringUtils.stripXMLUnsupportedChars("<node></node>"));
	}

	public void testIsValidXmlNCName()
	{
		assertTrue(CStringUtils.isValidXmlNCName("latin"));
		assertTrue(CStringUtils.isValidXmlNCName("Ø"));
		assertFalse(CStringUtils.isValidXmlNCName("×"));
		assertFalse(CStringUtils.isValidXmlNCName("ovÃ¡"));
	}

	public void testReplaceNonAsciiCharsWithEntities()
	{
		assertEquals(
				"&#25105;&#30495;&#30340;&#38656;&#35201;&#23545;&#27492;&#36827;&#34892;&#21333;&#20803;&#27979;&#35797;&#21527;",
				CStringUtils.replaceNonAsciiCharsWithEntities("我真的需要对此进行单元测试吗")
		);
		assertEquals(
				"Hello, I'm a friendly ASCII string.",
				CStringUtils.replaceNonAsciiCharsWithEntities("Hello, I'm a friendly ASCII string.")
		);
		assertEquals(
				".&#477;pnp &#387;u&#305;&#633;&#647;s &#305;&#305;&#596;s&#592; u&#592; &#654;ll&#592;&#647;o&#647; &#623;,&#305;.",
				CStringUtils.replaceNonAsciiCharsWithEntities(".ǝpnp ƃuıɹʇs ııɔsɐ uɐ ʎllɐʇoʇ ɯ,ı.")
		);
	}

	public void testIsPureASCII()
	{
			assertTrue(CStringUtils.isPureASCII("<SchoolName>aabb</SchoolName>"));
			assertFalse(CStringUtils.isPureASCII("<SchoolName>aa«bb</SchoolName>"));
	}
	
	public void testHasHtmlTags()
	{
		assertTrue(CStringUtils.hasHtmlTags("Additional HireRight <a href=\"http://www.hireright.com/Contact-Us.aspx#tab2\">toll free numbers</a> from many countries."));
		assertFalse(CStringUtils.hasHtmlTags("10 > 9 but 10 < 11"));
	}
	
	public void testIsEmail()
	{
		assertTrue(CStringUtils.isEmail("applicant.email@hireright.nn"));
		assertFalse(CStringUtils.isEmail("Applicant Name"));
	}
}
