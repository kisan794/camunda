/*
 * @(#)$RCSfile: CParametersTest.java,v $ $Revision: 1.4 $ $Date: 2009/02/20 10:25:02 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CParametersTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev			2008-08-29	Created unit-tests
 *	A.Solntsev			2009-01-11	Added metod testSetParameter()
 */
package hireright.sdk.util;

import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;
import junitx.framework.ListAssert;

/**
 * Unit test for class CParameters
 *
 * @author Andrei Solntsev
 * @version $Revision: 1.4 $ $Date: 2009/02/20 10:25:02 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CParametersTest.java,v $
 */
public class CParametersTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	private CParameters params;
	private String paramsString;
	
	@Override
	public void setUp() throws Exception
	{
		super.setUp();
		params = new CParameters();
		params.addParameter( "a", "b1" );
		params.addParameter( "a", "b2" );
		params.addParameter( "c", "b2" );
		
		paramsString = "a=b1\na=b2\nc=b2\n";
	}
	
	public void testSizeCountsEqualParameters()
	{
		assertEquals( 3, params.size() );
	}
	
	public void testEmptyObjectSizeIsNull()
	{
		assertEquals( 0, new CParameters().size() );
	}
	
	public void testEquals()
	{
		assertEquals( params, params );
		assertEquals( params, new CParameters(params) );
		assertEquals( new CParameters(params), new CParameters(params) );
	}
	
	public void testEmptyObjectEquals()
	{
		assertEquals( new CParameters(), new CParameters() );
		assertEquals( new CParameters(), new CParameters("") );
		assertEquals( new CParameters(new CParameters()), new CParameters() );
	}
	
	public void testToString()
	{
		assertEquals("", new CParameters().toString());
		assertEquals(paramsString, params.toString());
	}
	
	public void testParse()
	{
		CParameters p2 = new CParameters(params.toString());
		assertEquals( params, p2 );
	}
	
	public void testParseAlternativeDelimiters()
	{
		String sParams = "key1/val1-key2/val2-key3/val1-key1/val2";
		CParameters p3 = new CParameters(sParams, "-", "/");
		// assertEquals(sParams, p3.toString());
		ListAssert.assertEquals(Arrays.asList( new String[] {"val1", "val2"} ), p3.getParameterValues( "key1" ));
		ListAssert.assertEquals(Arrays.asList( new String[] {"val2"} ), p3.getParameterValues( "key2" ));
		ListAssert.assertEquals(Arrays.asList( new String[] {"val1"} ), p3.getParameterValues( "key3" ));
	}
	
	public void testSetParameterObjectValues()
	{
		List<Object> values = Arrays.asList( new Object[] {new Integer(2), new Double(3), new String("4")} );
		CParameters p = new CParameters();
		p.setParameter( "key", values );
		assertEquals("key=2\nkey=3.0\nkey=4\n", p.toString());
	}
	
	public void testChangeParameterValueSingle()
	{
		params.changeParameterValue( "c", "b2", "b3" );
		assertEquals("a=b1\na=b2\nc=b3\n", params.toString());
	}
	
	public void testChangeParameterValueMultiple()
	{
		params.changeParameterValue( "a", "b2", "b3" );
		assertEquals("a=b1\na=b3\nc=b2\n", params.toString());
	}
	
	public void testSetParameter()
	{
		params.setParameter("a=x");
		params.setParameter("b=y");
		assertEquals("a=b1\na=b2\na=x\nc=b2\nb=y\n", params.toString());
	}
	
	public void testChangeParameterValueUnexistingKey()
	{
		String sPreviousValue = params.toString();
		params.changeParameterValue( "unexistingParam", "b2", "newValue" );
		assertEquals(sPreviousValue + "unexistingParam=newValue\n", params.toString());
	}
	
	public void testChangeParameterValueUnexistingValue()
	{
		String sPreviousValue = params.toString();
		params.changeParameterValue( "c", "unexistingValue", "jakrevedko" );
		assertEquals(sPreviousValue, params.toString());
	}

	public void testRemoveAllParametersByName()
	{
		params.removeAllParametersByName("a");
		assertEquals( "c=b2\n", params.toString() );
	}
	
	public void testRemoveAllParametersByNameUnexisting()
	{
		params.removeAllParametersByName("unexistingParam");
		assertEquals( paramsString, params.toString() );
	}
	
	public void testClear()
	{
		params.clear();
		assertEquals( "", params.toString() );
	}	
}
