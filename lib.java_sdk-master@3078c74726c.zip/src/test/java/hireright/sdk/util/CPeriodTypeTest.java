/*
 * @(#)$RCSfile: CPeriodTypeTest.java,v $Revision: 1.3 $ $Date: 2008/09/05 10:15:24 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CPeriodTypeTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-01-18	created
 * 	A.Solntsev			2007-02-22	Added tests for HOUR, MINUTE, CPeriodType.FIVE_MINUTES
 */
package hireright.sdk.util;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;

import junit.framework.TestCase;

/**
 * @author asolntsev
 * @since Jan 18, 2007
 * @version $Revision: 1.3 $ $Date: 2008/09/05 10:15:24 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CPeriodTypeTest.java,v $
 */
public class CPeriodTypeTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: asolntsev $";
	
	public CPeriodTypeTest()
	{
		super(CPeriodType.class.getName());
	}

	public void testEquals()
	{
		assertSame(CPeriodType.MINUTE, CPeriodType.valueOf("MINUTE"));
		assertSame(CPeriodType.FIVE_MINUTES, CPeriodType.valueOf("FIVE_MINUTES"));
		assertSame(CPeriodType.HOUR, CPeriodType.valueOf("HOUR"));
		assertSame(CPeriodType.DAY, CPeriodType.valueOf("DAY"));
		assertSame(CPeriodType.MONTH, CPeriodType.valueOf("MONTH"));
		assertSame(CPeriodType.YEAR, CPeriodType.valueOf("YEAR"));
	}

	public void testSerialize() throws IOException, ClassNotFoundException
	{
		assertSame(CPeriodType.MINUTE, serialize(CPeriodType.MINUTE));
		assertSame(CPeriodType.FIVE_MINUTES, serialize(CPeriodType.FIVE_MINUTES));
		assertSame(CPeriodType.HOUR, serialize(CPeriodType.HOUR));
		assertSame(CPeriodType.DAY, serialize(CPeriodType.DAY));
		assertSame(CPeriodType.MONTH, serialize(CPeriodType.MONTH));
		assertSame(CPeriodType.YEAR, serialize(CPeriodType.YEAR));
	}

	public void testBeginningOfMinute()
	{
		assertEquals(new Date(86, 11, 30, 15, 38),
			CPeriodType.MINUTE.getBeginningOfPeriod(  new Date(86, 11, 30, 15, 38, 23)  ));
		assertEquals(new Date(80, 1, 1, 1, 1),
			CPeriodType.MINUTE.getBeginningOfPeriod(  new Date(80, 1, 1, 1, 1, 1)  ));
	}

	public void testEndOfMinute()
	{
		assertEquals(new Date(96, 12, 30, 15, 39),
			CPeriodType.MINUTE.getEndOfPeriod(  new Date(96, 12, 30, 15, 38, 23)  ));
		assertEquals(new Date(90, 1, 1, 1, 2),
			CPeriodType.MINUTE.getEndOfPeriod(  new Date(90, 1, 1, 1, 1, 1)  ));
		assertEquals(new Date(69, 12, 31, 15, 39),
			CPeriodType.MINUTE.getEndOfPeriod(  new Date(69, 12, 31, 15, 38, 14)  ));
	}

	public void testBeginningOf5Minutes()
	{
		assertEquals(new Date(86, 11, 30, 15, 35),
			CPeriodType.FIVE_MINUTES.getBeginningOfPeriod(  new Date(86, 11, 30, 15, 38, 23)  ));
		assertEquals(new Date(80, 1, 1, 1, 0),
			CPeriodType.FIVE_MINUTES.getBeginningOfPeriod(  new Date(80, 1, 1, 1, 1, 1)  ));
	}

	public void testEndOf5Minutes()
	{
		assertEquals(new Date(96, 12, 30, 15, 40),
			CPeriodType.FIVE_MINUTES.getEndOfPeriod(  new Date(96, 12, 30, 15, 38, 23)  ));
		assertEquals(new Date(90, 1, 1, 1, 5),
			CPeriodType.FIVE_MINUTES.getEndOfPeriod(  new Date(90, 1, 1, 1, 1, 1)  ));
		assertEquals(new Date(69, 12, 31, 15, 40),
			CPeriodType.FIVE_MINUTES.getEndOfPeriod(  new Date(69, 12, 31, 15, 38, 14)  ));
	}

	public void testBeginningOfHour()
	{
		assertEquals(new Date(86, 11, 30, 15, 0),
			CPeriodType.HOUR.getBeginningOfPeriod(  new Date(86, 11, 30, 15, 38, 23)  ));
		assertEquals(new Date(80, 1, 1, 1, 0),
			CPeriodType.HOUR.getBeginningOfPeriod(  new Date(80, 1, 1, 1, 1, 1)  ));
	}

	public void testEndOfHour()
	{
		assertEquals(new Date(96, 12, 30, 16, 0),
			CPeriodType.HOUR.getEndOfPeriod(  new Date(96, 12, 30, 15, 38, 23)  ));
		assertEquals(new Date(90, 1, 1, 2, 0),
			CPeriodType.HOUR.getEndOfPeriod(  new Date(90, 1, 1, 1, 1, 1)  ));
		assertEquals(new Date(69, 12, 31, 16, 0),
			CPeriodType.HOUR.getEndOfPeriod(  new Date(69, 12, 31, 15, 38, 14)  ));
	}

	public void testBeginningOfDay()
	{
		assertEquals(new Date(86, 11, 30),
			CPeriodType.DAY.getBeginningOfPeriod(  new Date(86, 11, 30, 15, 38, 23)  ));
		assertEquals(new Date(80, 1, 1),
			CPeriodType.DAY.getBeginningOfPeriod(  new Date(80, 1, 1, 1, 1, 1)  ));
	}

	public void testEndOfDay()
	{
		assertEquals(new Date(96, 12, 31),
			CPeriodType.DAY.getEndOfPeriod(  new Date(96, 12, 30, 15, 38, 23)  ));
		assertEquals(new Date(90, 1, 2),
			CPeriodType.DAY.getEndOfPeriod(  new Date(90, 1, 1, 1, 1, 1)  ));
		assertEquals(new Date(70, 1, 1),
			CPeriodType.DAY.getEndOfPeriod(  new Date(69, 12, 31, 15, 38, 14)  ));
	}

	public void testBeginningOfMonth()
	{
		assertEquals(new Date(86, 8, 1),
			CPeriodType.MONTH.getBeginningOfPeriod(  new Date(86, 8, 30, 15, 38, 15)  ));
		assertEquals(new Date(80, 1, 1),
			CPeriodType.MONTH.getBeginningOfPeriod(  new Date(80, 1, 1, 1, 1, 1)  ));
	}

	public void testEndOfMonth()
	{
		assertEquals(new Date(96, 8, 1),
			CPeriodType.MONTH.getEndOfPeriod(  new Date(96, 7, 30, 15, 38, 26)  ));
		assertEquals(new Date(90, 2, 1),
			CPeriodType.MONTH.getEndOfPeriod(  new Date(90, 1, 1, 1, 1, 1)  ));
		assertEquals(new Date(70, 0, 1),
			CPeriodType.MONTH.getEndOfPeriod(  new Date(69, 11, 31, 15, 38, 45)  ));
	}

	public void testBeginningOfYear()
	{
		assertEquals(new Date(86, 0, 1),
			CPeriodType.YEAR.getBeginningOfPeriod(  new Date(86, 7, 30, 15, 38, 15)  ));
		assertEquals(new Date(80, 0, 1),
			CPeriodType.YEAR.getBeginningOfPeriod(  new Date(80, 1, 1, 1, 1, 1)  ));
	}

	public void testEndOfYear()
	{
		assertEquals(new Date(97, 0, 1),
			CPeriodType.YEAR.getEndOfPeriod(  new Date(96, 11, 30, 15, 38, 35)  ));
		assertEquals(new Date(91, 0, 1),
			CPeriodType.YEAR.getEndOfPeriod(  new Date(90, 1, 1, 1, 1, 1)  ));
		assertEquals(new Date(70, 0, 1),
			CPeriodType.YEAR.getEndOfPeriod(  new Date(69, 11, 31, 15, 38, 56)  ));
	}


	protected static Serializable serialize(Serializable object) throws IOException, ClassNotFoundException
	{
		return CClass.deserialize(CClass.serialize(object));
	}

	public void testDate()
	{
		Date middleOfDay = new Date(96, 12, 30, 15, 38, 23);
		Date beginningOfDay = new Date(middleOfDay.getYear(), middleOfDay.getMonth(),
			middleOfDay.getDate());

		assertEquals(new Date(96, 12, 30), beginningOfDay);
	}
}
