/*
 * @(#)$RCSfile: CMultiSetTest.java,v $ $Revision: 1.5 $ $Date: 2008/09/05 10:57:57 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CMultiSetTest.java,v $
 *
 * Copyright 2005-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev				2005-06-27 	Created
 *	A.Solntsev				2008-08-28 	using generics
 */
package hireright.sdk.util;
import java.io.Serializable;
import java.util.Iterator;
import junit.framework.TestCase;

/**
 * Unit test for class hireright.sdk.util.CMultiSet
 * 
 * @author Andrei Solntsev
 * @since 2005-06-27
 */
public class CMultiSetTest extends TestCase implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: asolntsev $";
	
	protected CMultiSet<String> set;
	public CMultiSetTest()
	{
		super("Unit test for class " + CMultiSet.class.getName());
	}
	
	public void setUp() throws Exception
	{
		super.setUp();
		
		set = new CMultiSet<String>();
		set.put("a");
		set.put("b");
		set.put("a");
		set.put("c");
	}
	
	protected void tearDown() throws Exception
	{
		if (set != null)
		{
			set.clear();
			set = null;
		}
		
		super.tearDown();
	}
	
	public void testPut()
	{
		assertEquals(2, set.getArity("a"));
		assertEquals(1, set.getArity("b"));
		assertEquals(1, set.getArity("c"));
	}
	
	public void testRemove()
	{
		set.remove("a");
		assertEquals(1, set.getArity("a"));

		set.remove("b");
		assertEquals(0, set.getArity("b"));

		set.remove("b");
		set.remove("b");
		set.remove("b");
		assertEquals(0, set.getArity("b"));

		set.put("b");
		assertEquals(1, set.getArity("b"));

		assertEquals(1, set.getArity("c"));
	}
	
	public void testClear()
	{
		assertFalse(set.isEmpty());
		assertTrue(set.containsObject("a"));
		set.clear();
		assertTrue(set.isEmpty());
		assertFalse(set.containsObject("a"));
		assertEquals(0, set.getArity("a"));
	}
	
	public void testListObjects()
	{
		Iterator<String> it = set.listObjects();
		assertTrue("a".equals(it.next()));
		assertTrue("b".equals(it.next()));
		assertTrue("c".equals(it.next()));
		assertFalse(it.hasNext());
	}
}