/*
 * @(#)$RCSfile: CCounterTest.java,v $ $Revision: 1.2 $ $Date: 2009/10/23 08:14:53 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CCounterTest.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev		2009-10-21	created
 */
package hireright.sdk.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CCounterTest
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: asolntsev $";
	
	@Test
	public void inc()
	{
		CCounter c = new CCounter("testInc");
		assertEquals(0, c.getCount());
		c.inc(); assertEquals(1, c.getCount());
		c.inc(); assertEquals(2, c.getCount());
		c.dec(); assertEquals(1, c.getCount());
		c.dec(); assertEquals(0, c.getCount());
		c.dec(); assertEquals(-1, c.getCount());
	}
	
	@Test
	public void incLoop()
	{
		CCounter c = new CCounter("testIncLoop", 0, 3);
		assertEquals(0, c.getCount());
		c.inc(); assertEquals(1, c.getCount());
		c.inc(); assertEquals(2, c.getCount());
		c.inc(); assertEquals(3, c.getCount());
		c.inc(); assertEquals(0, c.getCount());
		c.dec(); assertEquals(-1, c.getCount());
	}
}
