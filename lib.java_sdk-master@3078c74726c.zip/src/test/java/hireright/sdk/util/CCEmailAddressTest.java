/*
 * @(#)$RCSfile: CCEmailAddressTest.java,v $ $Revision: 1.2 $ $Date: 2013/12/13 08:15:11 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CCEmailAddressTest.java,v $
 *
 * Copyright 2008-2013 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  M. Suhhoruki	2013-12-02	Created.
 *  
 */
package hireright.sdk.util;

import java.util.HashSet;
import java.util.Set;

import junit.framework.TestCase;

public final class CCEmailAddressTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	public CCEmailAddressTest(String sTestName)
	{
		super(sTestName);
	}
	
	public void testEquals()
	{
		CEmailAddress email1 = CEmailAddress.valueOf("abc@domain.com");
		CEmailAddress email2 = new CEmailAddress("abc", "domain.com");
		assertTrue(email1.equals(email2));
		assertTrue(CEmailAddress.isEqual("abc@domain.com", "abc@domain.com"));
		
		CEmailAddress email3 = CEmailAddress.valueOf("abc@domain.com");
		CEmailAddress email4 = new CEmailAddress("abc", "Domain.Com");
		assertTrue(email3.equals(email4));
		assertTrue(CEmailAddress.isEqual("abc@domain.com", "abc@Domain.Com"));
	}
	
	public void testHashCode()
	{
		Set<CEmailAddress> set = new HashSet<CEmailAddress>();
		CEmailAddress email1 = CEmailAddress.valueOf("abc@domain.com");
		CEmailAddress email2 = CEmailAddress.valueOf("abc@DOMAIN.com");
		
		set.add(email1);
		set.add(email2);
		assertTrue(set.size() == 1);
		
		CEmailAddress email3 = CEmailAddress.valueOf("ABC@DOMAIN.com");
		set.add(email3);
		assertTrue(set.size() == 2);
	}
	
	public void testNotEquals()
	{
		CEmailAddress email1 = CEmailAddress.valueOf("abc@domain.com");
		CEmailAddress email2 = new CEmailAddress("abC", "domain.com");
		assertFalse(email1.equals(email2));
		assertFalse(CEmailAddress.isEqual("abc@domain.com", "abC@domain.com"));
	}
	
	public void testNull()
	{
		CEmailAddress email = CEmailAddress.valueOf(null);
		assertNull(email);
	}
}