/*
 * @(#)$RCSfile: ArraySortTest.java,v $ $Revision: 1.2 $ $Date: 2008/11/21 11:30:32 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/ArraySortTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:	
 *	A.Solntsev		2006-11-14	Created
 */
package hireright.sdk.util;

import junit.framework.TestCase;
import junitx.framework.ArrayAssert;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $, $Date: 2008/11/21 11:30:32 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/ArraySortTest.java,v $
 */
public class ArraySortTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	public void testSortEmptyArray()
	{
		Integer[] emptyArray = new Integer[] {};
		ArraySort<Integer> arraySort = new ArraySort<Integer>( new NaturalComparer<Integer>());
		arraySort.sort(emptyArray);
		
		assertEquals(0, emptyArray.length);
	}
	
	public void testSortSingleElementArray()
	{
		Integer number = new Integer(1234567);
		Integer[] array = new Integer[] { number };
		ArraySort<Integer> arraySort = new ArraySort<Integer>( new NaturalComparer<Integer>());
		arraySort.sort(array);
		
		assertEquals(1, array.length);
		assertSame(number, array[0]);
	}
	
	public void testSort()
	{
		Integer[] array = new Integer[] { 10,9,8,7,6,5,4,3,2,1 };
		ArraySort<Integer> arraySort = new ArraySort<Integer>( new NaturalComparer<Integer>());
		arraySort.sort(array);
		
		assertEquals(10, array.length);
		ArrayAssert.assertEquals(new Integer[] {1,2,3,4,5,6,7,8,9,10}, array);
	}
}
