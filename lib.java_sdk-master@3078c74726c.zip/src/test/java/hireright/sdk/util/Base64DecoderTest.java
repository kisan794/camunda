/*
 * @(#)$RCSfile: Base64DecoderTest.java,v $ $Revision: 1.3 $ $Date: 2007/09/14 09:18:40 $ $Author: asolntsev $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2005-06-27	A.Solntsev		Created
 * 	2006-09-09	A.Solntsev		Standard JUnit test
 */
package hireright.sdk.util;
import java.io.Serializable;
import junit.framework.TestCase;

/**
 * Unit test for classes
 *  - hireright.sdk.util.Base64Decoder
 *  - hireright.sdk.util.Base64Encoder
 * 
 * @author Andrei Solntsev
 */
public class Base64DecoderTest extends TestCase implements Serializable
{
	public static final String sBase64 = "JVBERi0xLjQKJeLjz9MKMiAwIG9iago8PC9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9MZW5ndGggMTUxMAo+PgpzdHJlYW0K"
		+"eJyFV01z2zYQvftX7LgXe4ZWJLd13PbkKnKqmcZpJTkzmdEFJEERCUkwACiX/fV9C5CUKLvx6GCJBPbj7Xu7629nv2/Ofryh2+kNbdKzKV3NbvnLm/"
		+"sZza5pk51d0OXmy+HFxda99nm3XM///Lh+XC3o7uEdzT8+rBcPG/47X6welg/v/aPHD4uVf798+LRYb5bv7zbLT4uxr+HcavHXx9VmPX67yZWlTJsy"
		+"oqdcJTm1uiGb66ZIyUiRUiKMzJqiaCPKhaVYyopqo/cqlSk57c/HMhGNlbRO8idR3Wud2pN8L87nuqxF1Z5vL6kULWx/a6R1NNeVbUppaCVrbZwlUaV"
		+"vtKFltcdrtRNO7eXzU5nRJYmxk6Q/ZPwhVe1I7GSVtBPa5GzDB0BPqiiIo+UftkHK4fz2wiI2qwtZtIwIybIudFvKyl2NHRlZCIfs68bU2ko7Gb8+qfW"
		+"z2F/PzocYS9KxE6qCJ5/uH8rIldrlLsL9ZBI9g3g4wCAXOvFBCkfXs+mUPsASrZ2REvfXjXKSfppOYcrs4SKi+R39cn0z+8mD1aLsFUcATJ1Igp2xv9v"
		+"p9AoGrq7f3swmdDfG0voa+8vwqiomGHLVbFMYrgy+gjmGklwYdmAiQq2kEcUp1nXj/NWIammsrkRxuKQAYmIjKnUKtDIq1N6XvQJvjUyVI+vwA88CB1xb"
		+"S8sHj0Ia+3M5AOPgj+FXVVI0KUCKG0fQA1XawVepnNfAr72zLvkILEoU4rQyaYxyLVVNGXOKicGl6nmOiTapRVoy+YrbdRMXKgF8jWGb45chFs4yQbJFR"
		+"KkJSXcHI5Jpk/jMEEH/cOxwD+QyFQ4xGgemEwit+LGlXBYpmoI2XwE7gilrWdlwZXA1VAQgj12gRWTS2j6KTBooUeIKMoMdBAw0JFTax4G4XRKqdMyXjkO+"
		+"CORyCd12KI/9nZYsbg96CfKpgRMUwfLrAA5poFiNQWhHyA5PUkCCCL29sT9ue6rj8Bcdk6jrYkDUIFKjm12OI2DpXsknL3u4M9LWukoZDMjc5cFCLdA"
		+"KOTC8hsvTvtYVIaJKIp9Y89fMKFlxDYT1bHMMLuhmuIowxRDKvon5y8e8UBWU45pQaW3GDjVwNiSSbw2whH6S11rcPfzNRaHgs1ICuFqPHHw2SNWwDj"
		+"wws7e3N5Pra6ac4458uDJnLqMRssgYWi4nw+bPZaqQp9VWPS1CIxnVe0KfOxOisLrjBAnAX7fBN888GEV8KAYaVwwp+4EB2oLTY2c9C7rqcnOpRcunObh"
		+"EW+dbStocGGC56J7uiAvU6JoeWssQ5A98KVOBeCfa8aqCsht/q2IxYB40UA0kRRjOxs9J8lIUrMC48E0J5iIuPrwCouK3AUsPBPguMW/GzgTSL0th2r4qD"
		+"AwbcLKQda4rOTlSEq8AzgTkQ5iVhPr3cOZjwEIg/6kL0UvDG3P6mXaO+xjP4USnXuKD8Ce0zHz0AT3WWg9LnxPkLpLET/WgUOAhX2Jyf/GwtnCTD08pa0BA"
		+"i8bS1Z7G5f4+8ZlnPA9iyYnsAO6YZ5LO1wd0PzMiHkdLj14YfOJeKKgnDJDVsLncJe78tKPKGr782mEbAZUD7NnP9DhZT+aTg8Zubmfbi932cnuRbC+"
		+"DFHKBLYN9GV9Ep4f1S6SpCi1h7CxVNim0bUwYl3y3Eg4/Pe8sMpT9c3XYZTp1CJ66Tvp5orNABBPSPm2j3X7BGR/k+13IX1+dX/50G/R3bS8DUsPKGz"
		+"ZgTsn3Mb9LhO7xbsDHv+YNjrNl+vIDr/sSK5HaBdjGfmJZ6KeIZ5u/hXr44kBwwnpch1W224bVaF88WXT9DKBUZqzKE3HHeo+O0DnoN2Dlx+qXpgqM8"
		+"WOobEcjbLz/QoysEy+mAxIvLE5s3TOgKP5/isPVCxPTS/VJIf+Oe+Hfi6O4TzAEwCw8OJFDq4QdkWHiso9D+Gg2GYcW9W0Dc69Q//JerYMGu02eoQ/"
		+"TAsZO03uOO71amV5noT0d5cKIjpFcbM7+PvsPdlrXJAplbmRzdHJlYW0KZW5kb2JqCjQgMCBvYmoKPDwvVHlwZSAvUGFnZQovQ29udGVudHMgMiAwI"
		+"FIKL1BhcmVudCAzIDAgUgovUmVzb3VyY2VzIDw8L1Byb2NTZXQgWy9QREYgL1RleHQgL0ltYWdlQiAvSW1hZ2VDIC9JbWFnZUldCi9Gb250IDw8L0Y"
		+"xIDEgMCBSCj4+Cj4+Ci9NZWRpYUJveCBbMCAwIDU5NSA4NDJdCj4+CmVuZG9iago1IDAgb2JqCjw8L0ZpbHRlciAvRmxhdGVEZWNvZGUKL0xlbmd0a"
		+"CAzNzEKPj4Kc3RyZWFtCnicXZLPTsMwDMbvfQofQRpjAwlx5p/EEakvkDVua0ji4CQdfXucbsDGKantfr/Pdj6bh7a5vYP7zR20ttnA1fa+Xq5ftrC"
		+"9gbZvLvJoMlAPeUR4ZB9NmGEkwQQeV0AZvJlB8LNgymCg45CKR9FQZNFIsNcsegCFSUtoMJkm/K27bN//sBc/P+245EXfJLDYU0Bbg5NGelVDHx3PH"
		+"kO+EnQmazYWiZzUlS1CYVjsdlwkIXAPfj7n/Ams4RVKsCgpq1VYuvXzYk+zsCfnwMToZk0Jl2FcnM0nFlaQecHhV9bPc1BE8ZSrwd0MzuxXCnOYklI"
		+"FJ/5QdwKdCR26U6wW62lrIwYSDbV/h6ojtV6tZqxoJZ/jTpdk6vDVNnlcQztSgidKneNUBOtatPAA04l63WRQaRooGKdDNl9oVxBHztxxJMXzv1Whwy"
		+"4LB+qOAsuodgiTcWSXNVX8YaPpOFh9KlpxfC2HoZxYXlfCc9u8Nd9vDeI5CmVuZHN0cmVhbQplbmRvYmoKNiAwIG9iago8PC9UeXBlIC9QYWdlCi9Db2"
		+"50ZW50cyA1IDAgUgovUGFyZW50IDMgMCBSCi9SZXNvdXJjZXMgPDwvUHJvY1NldCBbL1BERiAvVGV4dCAvSW1hZ2VCIC9JbWFnZUMgL0ltYWdlSV0KL0"
		+"ZvbnQgPDwvRjEgMSAwIFIKPj4KPj4KL01lZGlhQm94IFswIDAgNTk1IDg0Ml0KPj4KZW5kb2JqCjEgMCBvYmoKPDwvVHlwZSAvRm9udAovQmFzZUZvbn"
		+"QgL0hlbHZldGljYQovU3VidHlwZSAvVHlwZTEKL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcKPj4KZW5kb2JqCjMgMCBvYmoKPDwvQ291bnQgMgov"
		+"VHlwZSAvUGFnZXMKL0tpZHMgWzQgMCBSIDYgMCBSXQo+PgplbmRvYmoKNyAwIG9iago8PC9UeXBlIC9DYXRhbG9nCi9QYWdlcyAzIDAgUgo+Pgplbm"
		+"RvYmoKOCAwIG9iago8PC9DcmVhdGlvbkRhdGUgKEQ6MjAwNTA2MTUxMzE3NTAtMDUnMDAnKQovUHJvZHVjZXIgKGlUZXh0IGJ5IGxvd2FnaWUuY29"
		+"tIFwocjEuMDJiO3AxMjhcKSkKL01vZERhdGUgKEQ6MjAwNTA2MTUxMzE3NTAtMDUnMDAnKQo+PgplbmRvYmoKeHJlZgowIDkKMDAwMDAwMDAwMCA2"
		+"NTUzNSBmIAowMDAwMDAyMzc3IDAwMDAwIG4gCjAwMDAwMDAwMTUgMDAwMDAgbiAKMDAwMDAwMjQ3MyAwMDAwMCBuIAowMDAwMDAxNTk3IDAwMDAw"
		+"IG4gCjAwMDAwMDE3NjYgMDAwMDAgbiAKMDAwMDAwMjIwOCAwMDAwMCBuIAowMDAwMDAyNTM1IDAwMDAwIG4gCjAwMDAwMDI1ODMgMDAwMDAgbiAKd"
		+"HJhaWxlcgo8PC9JRCBbPDQwNmVhMmRiYmY1MTlkMzU0YTkzNWY4MDUwZTc3MGY0Pjw0MDZlYTJkYmJmNTE5ZDM1NGE5MzVmODA1MGU3NzBmND5d"
		+"Ci9Sb290IDcgMCBSCi9TaXplIDkKL0luZm8gOCAwIFIKPj4Kc3RhcnR4cmVmCjI3MjcKJSVFT0YK";
	
	public Base64DecoderTest()
	{
	}
	
	public void testDecode() 
	{
		byte[] bDecodedData = Base64Decoder.decode(sBase64);
		String sDecodedData = new String(bDecodedData);
		
		assertTrue("Decoded data should be shorter than encoded", sDecodedData.length() < sBase64.length());
		assertTrue("Decoded data should be a valid PDF and start with '%PDF-1.4'", sDecodedData.startsWith("%PDF-1.4"));
		assertTrue("Decoded data should be a valid PDF and end with '%%EOF'", sDecodedData.trim().endsWith("%%EOF"));
		assertTrue("Decoded data should be a valid PDF of length 1510", sDecodedData.indexOf("/Length 1510") > 5);
	}
	
	public void testEncodeBytes()
	{
		byte[] bDecodedData = Base64Decoder.decode(sBase64);
		String sEncodedData = Base64Encoder.encode(bDecodedData);
		
		assertEquals(sBase64, sEncodedData);
	}
	
	public void testEncodeCharacters()
	{
		byte[] bDecodedData = Base64Decoder.decode(sBase64);
		String sEncodedData = Base64Encoder.encode(bytesToChars(bDecodedData));
		
		assertEquals(sBase64, sEncodedData);
	}
	
	protected static char[] bytesToChars(byte[] rawBytes)
	{
		char[] rawChars = new char[rawBytes.length];
		for (int i=0; i < rawBytes.length; i++) 
			rawChars[i] = (char) rawBytes[i];
		
		return rawChars;
	}

	protected static byte[] charsToBytes(char[] rawChars)
	{
		byte[] rawBytes = new byte[rawChars.length];
		for (int i=0; i < rawChars.length; i++) 
			rawBytes[i] = (byte) rawChars[i];
		
		return rawBytes;
	}
	
	/*
	public static void saveFile(String sFileName, byte[] bytes) throws IOException
	{
		saveFile(sFileName, new String(bytes));
	}
	
	public static void saveFile(String sFileName, String sFileContent) throws IOException
	{
		File f = new File(sFileName);
		if (!f.exists())
			f.createNewFile();

		FileWriter wr = new FileWriter(f);
		wr.write(sFileContent);
		wr.flush();
		wr.close();
	}
	*/
}