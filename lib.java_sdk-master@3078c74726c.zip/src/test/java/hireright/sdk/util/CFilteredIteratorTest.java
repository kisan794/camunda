/*
* @(#)$RCSfile: CFilteredIteratorTest.java,v $ $Revision: 1.5 $ $Date: 2008/09/05 10:07:31 $ $Author: asolntsev $
* $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CFilteredIteratorTest.java,v $
 *
 * Copyright 2005-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Solntsev			2005-05-20	created
 *   A.Solntsev			2005-09-01	Added test cases for findFirst(), filterCollection().
 *   A.Solntsev			2006-01-18	Added test cases for method notNull().
 *   A.Solntsev			2008-08-26	Using generics
 */
package hireright.sdk.util;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;
import junitx.framework.ListAssert;


/**
 * Iterator that selects only those objects in given Iterator,
 * which match to given filter.
 * 
 * @author	Andrei Solntsev
 * @date		2005-05-20
 * @version $Revision: 1.5 $ $Date: 2008/09/05 10:07:31 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CFilteredIteratorTest.java,v $
 */
public class CFilteredIteratorTest extends TestCase implements Serializable
{
	public CFilteredIteratorTest()
	{
		super("Unit test for class CFilteredIterator");
	}
	
	public void test_EmptyIterator()
	{
		List<Object> empty = new ArrayList<Object>(1);
		Iterator<Object> it = new CFilteredIterator<Object>(empty, IFilter.ACCEPT);
		
		assertFalse(it.hasNext());
	}

	public void test_SingleElement()
	{
		List<Integer> singleElement = new ArrayList<Integer>(1);
		singleElement.add(new Integer(1));
		Iterator<Integer> it = new CFilteredIterator<Integer>(singleElement, IFilter.ACCEPT);
		
		assertTrue(it.hasNext());
		assertEquals(new Integer(1), it.next());
		assertFalse(it.hasNext());
	}

	public void test_TwoElements()
	{
		List<Integer> twoElements = new ArrayList<Integer>(2);
		twoElements.add(new Integer(1));
		twoElements.add(new Integer(2));
		Iterator<Integer> it = new CFilteredIterator<Integer>(twoElements.iterator(), (IFilter<Integer>) IFilter.ACCEPT);
		
		assertTrue(it.hasNext());
		assertEquals(new Integer(1), it.next());
		assertEquals(new Integer(2), it.next());
		assertFalse(it.hasNext());
	}

	public void test_negativeFilter()
	{
		List<Integer> twoElements = new ArrayList<Integer>(2);
		twoElements.add(new Integer(1));
		twoElements.add(new Integer(2));
		Iterator<Integer> it = new CFilteredIterator<Integer>(twoElements.iterator(), IFilter.NEGATE);
		
		assertFalse(it.hasNext());
	}

	public void test_realFilter()
	{
		IFilter filter = new IFilter()
		{
			public boolean accept(Object obj){return ((Integer) obj).intValue() == 2;}
		};

		List<Integer> twoElements = new ArrayList<Integer>(3);
		twoElements.add(new Integer(1));
		twoElements.add(new Integer(2));
		twoElements.add(new Integer(3));
		Iterator<Integer> it = new CFilteredIterator<Integer>(twoElements, filter);
		
		assertTrue(it.hasNext());
		assertEquals(new Integer(2), it.next());
		assertFalse(it.hasNext());
	}
	
	public void test_findFirst()
	{
		List<String> origList = Arrays.asList(new String[]{null,null,null,"4",null,"6",null,"8",null,"10"});
		String firstNotNull = CFilteredIterator.findFirst(origList.iterator(), (IFilter<String>) IFilter.NOT_NULL);
		assertEquals("4", firstNotNull);
	}

	public void test_findFirstInEmptyList()
	{
		List<String> origList = Arrays.asList(new String[]{});
		String firstNotNull = CFilteredIterator.findFirst(origList.iterator(), (IFilter<String>) IFilter.NOT_NULL);
		assertNull(firstNotNull);
	}

	public void test_findFirstNotFound()
	{
		List<String> origList = Arrays.asList(new String[]{"1","2","3","4","5","6","7","8","9","10"});
		String notFound = CFilteredIterator.findFirst(origList.iterator(), (IFilter<String>) IFilter.NEGATE);
		assertNull(notFound);
	}
	
	public void test_filterCollection()
	{
		List<String> origList = Arrays.asList(new String[]{"1","2","3","4","5","6","7","8","9","10"});
		IFilter isOdd = new IFilter()
		{
			public boolean accept(Object obj)
			{
				Integer n = new Integer( (String) obj);
				return n.intValue() % 2 != 0;
			}
		};
		
		List<String> oddNumbers1 = CFilteredIterator.filterCollection(origList, isOdd);
		List<String> oddNumbers2 = CFilteredIterator.filterCollection(origList.iterator(), isOdd);
		List<String> expectedList = Arrays.asList(new String[]{"1","3","5","7","9"});
		
		ListAssert.assertEquals(expectedList, oddNumbers1);
		ListAssert.assertEquals(expectedList, oddNumbers2);
	}

	public void test_filterEmptyCollection()
	{
		List<String> origList = Arrays.asList(new String[]{});
		
		List<String> filteredList1 = CFilteredIterator
			.filterCollection(origList.iterator(), IFilter.ACCEPT);

		List<String> filteredList2 = CFilteredIterator
			.filterCollection(origList.iterator(), IFilter.ACCEPT);

		List<String> expectedList = Collections.emptyList();
		ListAssert.assertEquals(expectedList, filteredList1);
		ListAssert.assertEquals(expectedList, filteredList2);
	}
	
	public void test_filterNullElements()
	{
		List<String> origList = Arrays.asList(new String[]{null,"2",null,"4",null,"6",null,"8",null,"10"});
		
		List<String> notNulls1 = CFilteredIterator.filterCollection(origList, (IFilter<String>) IFilter.NOT_NULL);
		List<String> notNulls2 = CFilteredIterator.filterCollection(origList.iterator(), (IFilter<String>) IFilter.NOT_NULL);
		Iterator<String> notNulls3 = CFilteredIterator.notNull(origList.iterator());
		
		List<String> expectedList = Arrays.asList(new String[]{"2","4","6","8","10"});
		ListAssert.assertEquals(expectedList, notNulls1);
		ListAssert.assertEquals(expectedList, notNulls2);
		ListAssert.assertEquals(expectedList, CIteratorUtils.collectList(notNulls3));
	}
}