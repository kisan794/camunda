/*
 * @(#)$RCSfile: CPropertiesTest.java,v $ $Revision: 1.8 $ $Date: 2009/02/20 10:25:59 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CPropertiesTest.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	2005-03-04	A.Solntsev		created
 *  2005-10-20	A.Solntsev		Added test-case testPrefixKeysIterator()
 *  2006-05-16	A.Solntsev		Added methods CProperties(Map keyValues), getSortedKeys().
 *  2006-09-09	A.Solntsev		Added test-cases for getKeyValues(), constructor CProperties(Map).
 *  2008-05-19	A.Solntsev		Added testGetMap()
 *  2016-10-10	M.Suhhoruki		Added testDeserialization(), testParse()
 */
package hireright.sdk.util;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Sets;

import junit.framework.TestCase;
import junitx.framework.ArrayAssert;	// @see http://junit-addons.sourceforge.net/

/**
 * Unit test for class hireright.sdk.util.CProperties
 * 
 * @author Andrei Solntsev
 * @since 2005-03-04
 * @version $Revision: 1.8 $ $Date: 2009/02/20 10:25:59 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CPropertiesTest.java,v $
 */
public class CPropertiesTest extends TestCase implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	private CProperties m_properties;
	
	public CPropertiesTest(String sTestName)
	{
		super(sTestName);
	}
	
	public void setUp() throws Exception
	{
		super.setUp();
		
		m_properties = new CProperties();
		m_properties.setProperty("c3", "CCC");
		m_properties.setProperty("b2", "BBB");
		m_properties.setProperty("a1", "AAA");		
	}
	
	public void tearDown() throws Exception
	{
		if (m_properties != null)
		{
			m_properties.clear();
			m_properties = null;
		}
		
		super.tearDown();
	}
	
	public void testKeys()
	{
		String[] keys = m_properties.getKeys();
		ArrayAssert.assertEquals(keys, new String[] {"a1", "b2", "c3"});
	}
	
	public void testValues()
	{
		Set<Object> values = Sets.newHashSet(m_properties.getValues());
		assertEquals(Sets.newHashSet("AAA", "BBB", "CCC"), values);
	}
	
	public void testKeyValues()
	{
		Set<Entry<String, Object>> entries = Sets.newHashSet( m_properties.getKeyValues());
		
		assertEquals(ImmutableMap.builder()
					.put("a1", "AAA")
					.put("b2", "BBB")
					.put("c3", "CCC")
					.build().entrySet(), entries);
	}
	
	public void testSetProperty()
	{
		CProperties prop = new CProperties()
				.setProperty("b2", "BBB")
				.setProperty("c3", "CCC")
				.setProperty("a1", "AAA");
		ArrayAssert.assertEquals(m_properties.getKeys(), prop.getKeys());
	}
	
	public void testCopyConstructor()
	{
		CProperties prop = new CProperties(m_properties);
		assertNotSame(prop, m_properties);
		assertEquals(prop, m_properties);
		
		assertEquals(prop.getProperty("a1"), m_properties.getProperty("a1"));
		assertEquals(prop.getProperty("b1"), m_properties.getProperty("b1"));
		assertEquals(prop.getProperty("c1"), m_properties.getProperty("c1"));
		assertEquals(prop.getKeys().length, m_properties.getKeys().length);
	}
	
	public void testKeysIterator()
	{
		Set<String> keys = Sets.newHashSet(m_properties.getKeysIterator());
		assertEquals(Sets.newHashSet("a1", "b2", "c3"), keys);
	}

	public void testPrefixKeysIterator()
	{
		{
			Iterator it = m_properties.getKeysIterator("a");
			assertEquals("a1", it.next());
			assertFalse(it.hasNext());
		}
		
		{
			Iterator it = m_properties.getKeysIterator("b");
			assertEquals("b2", it.next());
			assertFalse(it.hasNext());
		}
		
		{
			Iterator it = m_properties.getKeysIterator("c");
			assertEquals("c3", it.next());
			assertFalse(it.hasNext());
		}
	
		{
			Iterator it = m_properties.getKeysIterator("d");
			assertFalse(it.hasNext());
		}
	}
	
	public void testEquals()
	{
		CProperties properties = new CProperties();
		properties.setProperty("c3", "CCC");
		properties.setProperty("a1", "AAA");
		properties.setProperty("b2", "BBB");
		
		assertEquals(properties, m_properties);
		properties.setProperty("d4", "DDD");
		assertFalse(properties.equals(m_properties));
	}
	
	public void testHashCode()
	{
		CProperties properties = new CProperties(m_properties);
		assertEquals(properties.hashCode(), m_properties.hashCode());
		assertTrue(properties.hashCode() > 0);
	}
	
	public void testSetNullProperty()
	{
		assertEquals("AAA", m_properties.getProperty("a1"));
		m_properties.setProperty("a1", null);
		assertEquals("AAA", m_properties.getProperty("a1"));
	}
	
	public void testSortedKeys()
	{
		Iterator it = m_properties.getSortedKeys();
		assertEquals("a1", it.next());
		assertEquals("b2", it.next());
		assertEquals("c3", it.next());
	}
	
	public void testMap()
	{
		HashMap map = new HashMap();
		map.put("a1", new Integer(1));
		map.put("b2", Boolean.TRUE);
		map.put(new Integer(3), "value3");
		map.put(Boolean.FALSE, "value_false");
		map.put("d4", null);
		
		CProperties prop = new CProperties(map);
		assertEquals("For non-string values, method toString() must be called", "1", prop.getProperty("a1"));
		assertEquals("For non-string values, method toString() must be called", "true", prop.getProperty("b2"));
		
		assertNull("Non-string keys must be ignored", prop.getProperty("3"));
		assertNull("Non-string keys must be ignored", prop.getProperty("false"));
		
		assertNull("?", prop.getProperty("d4"));
	}
	
	public void testGetMap()
	{
		Map map = m_properties.getMap();
		
		assertEquals( "CCC", map.get("c3") );
		assertEquals( "BBB", map.get("b2") );
		assertEquals( "AAA", map.get("a1") );		
	}
	
	/**
	 * Tests compatibility between deserializer (ws_collectionengine) and serializers (ws_eventengine and some obscure processes)
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public void testDeserialization()
		throws ClassNotFoundException, IOException
	{
		String sProperties = "rO0ABXNyAB5oaXJlcmlnaHQuc2RrLnV0aWwuQ1Byb3BlcnRpZXPuv/K87yyZAwIAA0wADG1fcHJvcGVydGllc3QAD0xqYXZhL3V0aWwvTWFwO0wADm1fc3pEZWxpbWl0ZXJzdAASTGphdmEvbGFuZy9TdHJpbmc7TAAVbV9zektleVZhbHVlU2VwYXJhdG9ycQB+AAJ4cHNyABFqYXZhLnV0aWwuSGFzaE1hcAUH2sHDFmDRAwACRgAKbG9hZEZhY3RvckkACXRocmVzaG9sZHhwP0AAAAAAAAx3CAAAABAAAAABdAAEbmFtZXQABXZhbHVleHQAAQp0AAE9";
		ByteArrayInputStream bis = new ByteArrayInputStream(Base64Decoder.decode(sProperties));
		ObjectInputStream istream = new ObjectInputStream(bis);
		CProperties p = (CProperties) istream.readObject();
		istream.close();
		
		assertEquals("value", p.getProperty("name"));
		assertEquals(p.size(), 1);
	}
	
	public void testParse()
	{
		String s = "n1=v1\nn2= v2  \ngrgjerig=ooo";
		CProperties p = CProperties.valueOf(s, true);
		assertEquals("v1", p.getProperty("n1"));
		assertEquals("v2", p.getProperty("n2"));
		assertEquals("ooo", p.getProperty("grgjerig"));
		
		p = CProperties.valueOf(s, false);
		assertEquals("v1", p.getProperty("n1"));
		assertEquals(" v2  ", p.getProperty("n2"));
		assertEquals("ooo", p.getProperty("grgjerig"));
	}
	
	/*
	public static void main(String[] args)
	{
    //junit.textui.TestRunner.run(CPropertiesTest.class);
    junit.swingui.TestRunner.run(CPropertiesTest.class);
	}
	*/
}