/*
 * @(#)$RCSfile: CClassTest.java,v $ $Revision: 1.6 $ $Date: 2009/01/09 10:51:03 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CClassTest.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2007-01-06	A.Solntsev		Created
 *	2007-02-13	A.Solntsev		Added method testCompareMapsOrder()
 *	2007-12-18	A.Solntsev		Added method test_classVersion()
 */
package hireright.sdk.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.6 $ $Date: 2009/01/09 10:51:03 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/test/java/hireright/sdk/util/CClassTest.java,v $
 */
public class CClassTest extends TestCase
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	private static void assertCompareEqual(Object a, Object b)
	{
		Map<?,?> diff = CClass.compare(a, b, 1);
		assertTrue(diff == null || diff.isEmpty());
	}

	private static void assertCompare(Object a, Object b, String sDifferentMembername)
	{
		Map<?,?> diff = CClass.compare(a, b, 1);
		assertNotNull(diff);
		assertFalse(diff.isEmpty());
		assertEquals(1, diff.size());

		Object key = diff.keySet().iterator().next();
		assertEquals(sDifferentMembername, key);
	}

	public void testCompareAtomicObjects()
	{
		assertCompareEqual("abc", "abc");
		assertCompareEqual("", "");
		assertCompareEqual(new Integer(2), new Integer(2));
		assertCompareEqual(Boolean.TRUE, Boolean.TRUE);
		assertCompareEqual(new int[] {1, 2, 3}, new int[] {1, 2, 3});

		assertCompare("abc", "xxxyyyzzz", "");
		assertCompare("", " ", "");
		assertCompare(new Integer(2), new Integer(3), "");
		assertCompare(Boolean.TRUE, Boolean.FALSE, "");
		assertCompare(new int[] {1, 2, 3}, new int[] {4, 5, 6}, ".elem#0");
	}

	public void testCompareMaps()
	{
		Map<String, String> a = new HashMap<String, String>();
		a.put("key1", "value1");

		Map<String, String> b = new HashMap<String, String>();
		b.put("key1", "value1");

		assertCompareEqual(a, b);

		a.put("key2", "value2");
		b.put("key2", "value2");
		assertCompareEqual(a, b);

		b.put("key3", "value3");
		assertCompare(a, b, "");
	}

	
	public void testCompareMapsOrder() throws IOException, ClassNotFoundException
	{
		HashMap<String, String> a = new HashMap<String, String>();
		a.put("key1", "value1");
		a.put("key2", "value2");
		a.put("key3", "value3");

		@SuppressWarnings("unchecked")
		Map<String, String> b = (Map<String, String>) CClass.deserialize(CClass.serialize(a));
		
		a.remove("key2");
		a.put("key2", "value2");

		assertCompareEqual(a, b);
	}

	public void testCompare()
	{
		CLocation a = new CLocation(1, "CA", "ORANGE");
		CLocation b = new CLocation(1, "CA", "ORANGE");
		CLocation c = new CLocation(1, "CA", "IRVINE");
		CLocation d = new CLocation(1, "QUEBEQ", "IRVINE");
		CLocation e = new CLocation(2, "QUEBEQ", "IRVINE");

		assertCompareEqual(a, b);
		assertCompare(b, c, ".m_strCountyName");
		assertCompare(c, d, ".m_strRegionName");
		assertCompare(d, e, ".m_nCountryID");
	}

	public void test_classVersion()
	{
		assertEquals("$Revision: 1.6 $", CClass.getClassVersion( ClassVersionPublic.class ));
		assertEquals("$Revision: 1.6 $", CClass.getClassVersion( ClassVersionPublic.class.getName() ));
		assertEquals("$Revision: 1.6 $", CClass.getClassVersion( ClassVersionDefault.class ));
		assertEquals("$Revision: 1.6 $", CClass.getClassVersion( ClassVersionProtected.class ));
		assertEquals("$Revision: 1.6 $", CClass.getClassVersion( ClassVersionPrivate.class ));
		
		assertEquals("$Revision: 1.6 $", CClass.getClassVersion( ClassVersionPrivateInner.class ));
		assertEquals("$Revision: 1.6 $", CClass.getClassVersion( ClassVersionPrivateInner.class.getName() ));
	}
	
	class ClassVersionPrivateInner
	{
		@SuppressWarnings("unused")
		private static final String CLASS_VERSION = "$Revision: 1.6 $";
	}
}

class ClassVersionPublic
{
	public static final String CLASS_VERSION = "$Revision: 1.6 $";
}

class ClassVersionDefault
{
	static final String CLASS_VERSION = "$Revision: 1.6 $";
}

class ClassVersionProtected
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $";
}

class ClassVersionPrivate
{
	@SuppressWarnings("unused")
	private static final String CLASS_VERSION = "$Revision: 1.6 $";
}
