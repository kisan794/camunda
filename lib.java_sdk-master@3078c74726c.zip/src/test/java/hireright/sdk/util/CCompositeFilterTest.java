/*
* @(#)$RCSfile: CCompositeFilterTest.java,v $ $Revision: 1.3 $ $Date: 2007/09/14 09:18:48 $ $Author: asolntsev $
 *
 * Copyright 2005-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Solntsev			2006-04-26	created
 */
package hireright.sdk.util;

import java.io.Serializable;

import junit.framework.TestCase;

/**
 * Unit tests for composte filters: AND, OR, XOR
 * 
 * @author Andrei Solntsev
 * @since java_sdk_v2-6-8
 */
public class CCompositeFilterTest extends TestCase implements Serializable
{
	private final IFilter containsDigits = new IFilter()
	{
		public boolean accept(Object obj)
		{
			return
				(obj != null) &&
				(obj instanceof String) && 
				((String) obj).matches(".*\\d+.*");
		}
	};
	
	private final IFilter containsLetters = new IFilter()
	{
		public boolean accept(Object obj)
		{
			return
				(obj != null) &&
				(obj instanceof String) && 
				((String) obj).matches(".*[a-zA-Z]+.*");
		}
	};
	
	public void setUp()
	{
		assertFalse(containsDigits.accept(null));
		assertFalse(containsDigits.accept("qwetre"));
		assertTrue(containsDigits.accept("1234"));
		assertTrue(containsDigits.accept("qwe1234tre"));
		
		assertFalse(containsLetters.accept(null));
		assertFalse(containsLetters.accept("1234"));
		assertTrue(containsLetters.accept("qwe1234tre"));
		assertTrue(containsLetters.accept("qwetre"));
	}
	
	public void testAnd()
	{
		IFilter AND = CCompositeFilter.AND(containsDigits, containsLetters);
		assertFalse(AND.accept(null));
		assertFalse(AND.accept("abcde"));
		assertFalse(AND.accept("12867"));
		assertTrue(AND.accept("6a"));
	}
	
	public void testOr()
	{
		IFilter OR = CCompositeFilter.OR(containsDigits, containsLetters);
		assertFalse(OR.accept(null));
		assertTrue(OR.accept("abcde"));
		assertTrue(OR.accept("12867"));
		assertTrue(OR.accept("6a"));
	}
	
	public void testXOr()
	{
		IFilter XOR = CCompositeFilter.XOR(containsDigits, containsLetters);
		assertFalse(XOR.accept(null));
		assertTrue(XOR.accept("abcde"));
		assertTrue(XOR.accept("12867"));
		assertFalse(XOR.accept("6a"));
	}
}
