/*
 * @(#)$RCSfile: GeneralSettingsMBean.java,v $ $Revision: 1.5 $ $Date: 2009/04/24 14:33:05 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/settings/GeneralSettingsMBean.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev				2008-10-02	created
 *	A.Solntsev				2009-04-20	Removed methods getAppRoot(), getApplicationRoot()
 */
package hireright.settings;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.5 $ $Date: 2009/04/24 14:33:05 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/settings/GeneralSettingsMBean.java,v $
 */
public class GeneralSettingsMBean implements GeneralSettingsMBeanMBean
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	public GeneralSettingsMBean()
	{
	}
	
	public String getProperty(String name)
	{
		return GeneralSettings.getInstance().getJavaSetting(name);
	}
	
	public void setProperty(String name, String value)
	{
		GeneralSettings.getInstance().setCustomSetting(name, value);
	}
	
	public void refresh()
	{
		GeneralSettings.reloadSettings();
	}
	
	public String getServerType()
	{
		return GeneralSettings.getServerType();
	}
	
	public void setServerType(String sServerType)
	{
		GeneralSettings.getInstance().setServerType(sServerType);
	}
	
	public boolean isTestServer()
	{
		return GeneralSettings.isTestServer();
	}
	
	public void setTestServer(boolean bTestServer)
	{
		GeneralSettings.getInstance().setTestServer(bTestServer);
	}
	
	public boolean isTrackJdbcConnections()
	{
		return GeneralSettings.isTrackJdbcConnections();
	}
	
	public void setTrackJdbcConnections(boolean bDoTrack)
	{
		GeneralSettings.getInstance().setTrackJdbcConnections(bDoTrack);
	}
	
	public boolean isDoForceSerialization()
	{
		return GeneralSettings.doForceSerialization();
	}
	
	public void setDoForceSerialization(boolean doForceSerialization)
	{
		GeneralSettings.getInstance().setDoForceSerialization(doForceSerialization);
	}
	
	public boolean isDoCheckSerialization()
	{
		return GeneralSettings.doCheckSerialization();
	}
	
	public void setDoCheckSerialization(boolean doCheckSerialization)
	{
		GeneralSettings.getInstance().setDoCheckSerialization(doCheckSerialization);
	}
	
	public String getXmlResPathUrl()
	{
		return GeneralSettings.getXmlResPathUrl();
	}

	public String getResourceRoot()
	{
		return GeneralSettings.getHttpResRoot();
	}
}
