/*
 * @(#)$RCSfile: GeneralSettings.java,v $ $Revision: 1.34 $ $Date: 2015/03/28 08:35:33 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/settings/GeneralSettings.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2003.01.28 A.Nesterov	added support for settings reloading
 * 	2003.02.26 A.Nesterov	Added automatic settings reloading
 * 	2005.02.01	I.Suits		removed debugLogsEnabled() method, added readTraceLogLevel()
 * 							removed DEBUG_LOGS_ENABLED and TRACE_LEVEL parameters reading from JAVA_SETTINGS
 *  2005-02-09	A.Solntsev	New method loadProperty() is used for safe loading from table JAVA_SETTINGS.
 *  2005-03-30	A.Solntsev	Method readTraceLogLevel() is more safe.
 *  2005-06-23	A.Solntsev	Added methods loadBooleanProperty(), loadIntegerProperty().
 *  2005-08-03	A.Solntsev	LogTrace Level moved to class CLogTraceSettings.
 *  2005-08-05	A.Solntsev	"error.xhtml" moved to class MVCSettings.
 *  2005-08-15	A.Solntsev	Now entire table JAVA SETTINGS is loaded at once.
 *  2006-06-04	A.Solntsev	Classes IsSettings, GUISettings, MVCSettings moved upper.
 *  2006-05-07	A.Solntsev	Property "MAX_CONNECTIONS" is not used anymore. Added method setCustomSettings().
 *  2006-08-03	A.Solntsev	Now class doesn't depend on hireright.sdk.* (except CConnection)
 *  2006-11-06	A.Solntsev	Added properties "FORCE_SERIALIZATION" and "CHECK_SERIALIZATION"
 *  2006-11-22	A.Solntsev	Now doesn't use ThreadLocal connection
 *  2007-01-23	A.Solntsev	m_bForceSerialization is false by default
 *  2007-11-13	A.Solntsev	getConnection() -> getNonTrackingConnection()
 *	2007-12-06	A.Solntsev	m_bCheckSerialization is "false" by default
 *	2008-03-20	A.Solntsev	Added method getAppRoot(). Probably it will be removed later (when F5 is configured properly).
 *	2008-10-01	A.Solntsev	Enabling JMX: implements GeneralSettingsMBean
 *	2009-04-07	D.Pivovarov	Added a bunch of new setting names for chat
 *	2009-04-20	A.Solntsev	Removed methods getAppRoot(), getApplicationRoot()
 *	2009-08-28	A.Solntsev	m_customJavaSettings is now ThreadLocal (safe running of unit-tests inside container)
 *	2010-01-26	A.Solntsev	Custom settings are deprecated now
 *	2010-03-05	A.Solntsev	Table JAVA_SETTINGS is not required until it's really used. Many methods 
 *													return default values if the table is not available.
 *	2010-08-17	E.Shatohhin	Clam AV settings
 *	2013-10-29	M.Suhhoruki	TRACK_JDBC_CONNENCTIONS renamed to TRACK_JDBC_CONN.
 *											TRACK_JDBC_CONNENCTIONS - used by old code (with buggy CTrackingConnection java_sdk<3.49)
 *											TRACK_JDBC_CONN - used by new code (CTrackingConnection java_sdk>=3.49)
 *											This allows to enable CTrackingConnection for new code and disable old tracking code.
 *	2015-03-04	M.Suhhoruki	Added newInstance(), getSettings()
 *	2017-07-02	S.Ignatov	added dms availability check
 *
 */
package hireright.settings;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CRuntimeException;
import hireright.sdkex.log4j.CLogsSettings;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

/**
 * GeneralSettings class
 *
 * <pre>
 *  NOTE:	To implement settings reloading in derived classes, please declare in every child class
 *  		a member variable as "private static ChildClass m_instance = new ChildClass();"
 *  		and call all required settings loading routines inside method public void OnReloadSettings();.
 *
 *          Any classes that do not require any settings reloading must be declared abstract or
 *          implemented as described above with empry method public void OnReloadSettings();
 * </pre>
 *
 * @author	Aleksander Nesterov
 * @version$Revision: 1.34 $ $Date: 2015/03/28 08:35:33 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/settings/GeneralSettings.java,v $
 */
@SuppressWarnings("serial")
public final class GeneralSettings extends Observable implements Serializable
{
	// --- Names in table JAVA_SETTINGS ---

	public static final String SETTING_NAME_RESOURCE_ROOT = "RESOURCE_ROOT";
	public static final String SETTING_NAME_SERVER_TYPE = "SERVER_TYPE";
	public static final String SETTING_NAME_TRACK_JDBC_CONNECTIONS = "TRACK_JDBC_CONN";
	public static final String SETTING_NAME_FORCE_SERIALIZATION = "FORCE_SERIALIZATION";
	public static final String SETTING_NAME_CHECK_SERIALIZATION = "CHECK_SERIALIZATION";
	
	public static final String SETTING_NAME_NEW_CHAT_URL = "NEW_CHAT_URL";
	public static final String SETTING_NAME_NEW_CHAT_ENTRY = "NEW_CHAT_ENTRY";
	public static final String SETTING_NAME_CUSTOMER_PROFILE_URL = "CUSTOMER_PROFILE_URL";
	public static final String SETTING_NAME_CUSTOMER_GUIDELINES_URL = "CUSTOMER_GUIDELINES_URL";
	public static final String SETTING_NAME_CUSTOMER_GUIDELINES_HOME_URL = "CUSTOMER_GUIDELINES_HOME_URL";
	public static final String SETTING_NAME_CLAMAV_IDMS_HOSTPORT = "CLAMAV_IDMS_HOSTPORT";
	
	protected static final String CLASS_VERSION = "$Revision: 1.34 $ $Author: cvsroot $";
	
	protected static final String COMMON_RESOURCE_PATH = "/common/";

	/**
	 * de-pre-cated?	 Use class hireright.gui.mvc.CMVCSettings
	 */
	protected static final String	DESIGN_RESOURCE_PATH = "/designs/general/";

	protected static final String	EXCEPTIONS_LOG_FILE = "exceptions.log";
	protected static final String	DEBUG_LOG_FILE = "debug.log";

	public static final String	XSL_DIR = "xsl/";
	public static final String	XML_DIR = "xml/";
	public static final String	HTML_DIR = "html/";
	public static final String	DTD_DIR = "dtd/";

	/**
	 * de-pre-cated?	Use class hireright.gui.mvc.CMVCSettings
	 */
	public static final String	XHTML_DIR = "xhtml/";

	/**
	 * Root for Http URLs for accessing static resources (html, javascript, css)
	 * E.g. "http://ows01.hireright.com"  
	 */
	private String m_sResourceRoot;

	private static final String DEFAULT_SERVER_TYPE = "PRODUCTION";
	private String m_sServerType = DEFAULT_SERVER_TYPE;
	private boolean m_bTestServer = true;	// Default is test server

	/**
	 *  DMSes that are avaliable on instance, eg there is no Liberty and Documentum in UK
	 *  Default is SUPPORTED_DMS_ALL
	 */
	private static final String SETTING_NAME_SUPPORTED_DMS = "INSTANCE_SUPPORTED_DMS";

	private static final int SUPPORTED_DMS_ALL 	 = 255; // 0b11111111;
	public static final int	SUPPORTED_DMS_LIBERTY 	 = 2;   // 0b00000010;
	public static final int	SUPPORTED_DMS_JR 	 = 4;   // 0b00000100;
	public static final int	SUPPORTED_DMS_DOCUMENTUM = 8;   // 0b00001000;
	public static final int	SUPPORTED_DMS_ORACLE     = 16;  // 0b00010000;
	public static final int	SUPPORTED_DMS_OAK				 = 32;  // 0b00100000;

	private int m_nSupportedDMS = SUPPORTED_DMS_ALL;

	private boolean m_bTrackJdbcConnections = false;
	private boolean m_bForceSerialization = false; // not needed by default
	private boolean m_bCheckSerialization = false; // not needed by default

	// Set of loaded properties (content of table JAVA_SETTINGS).
	private Map<String, String> m_javaSettings = null;

	/**
	 * Set of optional redefined properties (usually defined java.properties for running unit-tests).
	 * These values have higher priority than JAVA_SETTINGS
	 * 
	 * @deprecated It was created only for local development. Now it's not recommended to use.
	 */
	@Deprecated
	private static final ThreadLocal<Map<String, String>> m_customJavaSettings =
		new ThreadLocal<Map<String,String>>();


	/**
	 * Singleton
	 */
	private static GeneralSettings m_instance;

	public static GeneralSettings getInstance()
	{
		if (m_instance == null)
		{
			synchronized (GeneralSettings.class)
			{
				if (m_instance == null)
				{
					m_instance = new GeneralSettings();
				}
			}
		}
		return m_instance;
	}
	
	public static GeneralSettings newInstance()
	{
		return new GeneralSettings();
	}
	
	private GeneralSettings() throws SettingsLoadingException
	{
		loadSettings();
	}

	/**
	 * Override settings given in table JAVA_SETTINGS
	 *
	 * @since java_sdk_v2-6-9
	 * @param customJavaSettings any CProperties, usually read from web.xml during local development
	 * @deprecated It was created only for local development. Now it's not recommended to use. 
	 */
	@Deprecated
	public static void setCustomSettings(Map<String, String> customJavaSettings)
	{
		getInstance().setCustomJavaSettings(customJavaSettings);
	}

	@Deprecated
	public static void resetCustomSettings()
	{
		getInstance().resetCustomJavaSettings();
	}

	@Deprecated
	private final void setCustomJavaSettings(Map<String, String> customJavaSettings)
	{
		if (m_customJavaSettings.get() == null)
			m_customJavaSettings.set( new HashMap<String, String>() );
		
		m_customJavaSettings.get().putAll(customJavaSettings);

		parseSettings();
		setChanged();
		notifyObservers();
	}
	
	@Deprecated
	private final void resetCustomJavaSettings()
	{
		if (m_customJavaSettings.get() != null)
			m_customJavaSettings.get().clear();
		
		m_customJavaSettings.set( null );
		parseSettings();
		setChanged();
		notifyObservers();
	}
	
	@Deprecated
	protected void setCustomSetting(String name, String value)
	{
		if (m_customJavaSettings.get() == null)
			m_customJavaSettings.set( new HashMap<String, String>() );
		
		m_customJavaSettings.get().put(name, value);

		parseSettings();
		setChanged();
		notifyObservers();
	}

	public static void registerObserver(Observer observer)
	{
		getInstance().addObserver(observer);
	}

	/**
	 * Function returns corresponding value from table JAVA_SETTINGS or from custom Java Settings.
	 * Custom Java Settings has haigher priority then table JAVA_SETTINGS.
	 *
	 * @return null if no such property found
	 * @param sPropertyName	any string value
	 */
	public static String getProperty(String sPropertyName)
	{
		return getInstance().getJavaSetting(sPropertyName);
	}

	protected final String getJavaSetting(String sPropertyName)
	{
		if (m_customJavaSettings.get() != null && 
				m_customJavaSettings.get().containsKey(sPropertyName))
			return m_customJavaSettings.get().get(sPropertyName);

		return m_javaSettings.get(sPropertyName);
	}

	/**
	 * Function returns corresponding value from table JAVA_SETTINGS.
	 * @param sPropertyName
	 * @return Property with given name (not null)
	 *
	 * @throws java.lang.IllegalArgumentException	if property not found in table.
	 */
	public static String loadProperty(String sPropertyName)
		throws IllegalArgumentException
	{
		String sPropertyValue = getProperty(sPropertyName);
		if (sPropertyValue == null)
			throw new IllegalArgumentException("Property " + sPropertyName + " not found in Java Settings");

		return sPropertyValue;
	}

	/**
	 * This method can be called when administrator clicks button like "reset Java Settings".
	 * It reloads content of table JAVA_SETTINGS, and if it has been changed,
	 * calls all observers to reload the new data.
	 */
	public static void reloadSettings()
	{
		getInstance().loadSettings();
		CLogsSettings.reloadSettings();
	}
	
	private Map<String, String> performSelect(Connection conn, String sSelect)
	{
		Map<String, String> javaSettings = new HashMap<String, String>();

		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			stmt = conn.prepareStatement(sSelect);

			rs = stmt.executeQuery();
			while (rs.next())
			{
				javaSettings.put(rs.getString(1), rs.getString(2));
			}
			return javaSettings;
		}
		catch (SQLException sqle)
		{
			throw new RuntimeException("Failed to read java settings", sqle);
		}
		finally
		{
			if (rs != null)
			{
				try
				{
					rs.close();
					rs = null;
				}
				catch (SQLException sqle) {}
			}

			if (stmt != null)
			{
				try
				{
					stmt.close();
					stmt = null;
				}
				catch (SQLException sqle) {}
			}
		}
	}

	/**
	 * Initializes class with data
	 */
	private void loadSettings() throws SettingsLoadingException
	{
        try {
			final Map<String, String> javaSettings =
                DB.execute(() -> performSelect(DB.connection(), "SELECT name, value FROM JAVA_SETTINGS"));
			//if (m_javaSettings == null || !m_javaSettings.equals(javaSettings))
			{
				m_javaSettings = javaSettings;
				parseSettings();

				setChanged();
				notifyObservers();
			}
        } catch (Exception e) {
            throw new SettingsLoadingException(e);
        }
	}

	private void parseSettings()
	{
		// Try to load system properties prior to default initialization from DB
		m_sResourceRoot = System.getProperty(SETTING_NAME_RESOURCE_ROOT);
		if (m_sResourceRoot == null)
		{
			m_sResourceRoot = getJavaSetting(SETTING_NAME_RESOURCE_ROOT);
			if (m_sResourceRoot == null)
				throw new IllegalArgumentException("Property " + SETTING_NAME_RESOURCE_ROOT + " not found in Java Settings");
		}

		m_sServerType = getJavaSetting(SETTING_NAME_SERVER_TYPE);
		
		String sTrackJdbcConnections = getJavaSetting(SETTING_NAME_TRACK_JDBC_CONNECTIONS);
		String sForceSerialization = getJavaSetting(SETTING_NAME_FORCE_SERIALIZATION);
		String sCheckSerialization = getJavaSetting(SETTING_NAME_CHECK_SERIALIZATION);

		// Default is test server
		m_bTestServer = (m_sServerType == null || m_sServerType.charAt(0) != 'P');

		m_bTrackJdbcConnections = (sTrackJdbcConnections == null ? m_bTestServer
				: Boolean.TRUE.toString().equalsIgnoreCase(sTrackJdbcConnections));
		
		// "false" by default
		m_bForceSerialization = (sForceSerialization == null ? false
				: Boolean.TRUE.toString().equalsIgnoreCase(sForceSerialization));

		// "false" by default
		m_bCheckSerialization = (sCheckSerialization == null ? false
			: Boolean.TRUE.toString().equalsIgnoreCase(sCheckSerialization));

		String sSupportedDMS = getJavaSetting(SETTING_NAME_SUPPORTED_DMS);
		if(sSupportedDMS != null)
		{
			try
			{
				m_nSupportedDMS =  Integer.parseInt(sSupportedDMS);
			}
			catch(Exception exNumParse) {}
		}
	}

	public String getResourceRoot()
	{
		return m_sResourceRoot;
	}
	
	public static String getExceptionsLogFile()
	{
		return EXCEPTIONS_LOG_FILE;
	}

	public static String getDebugLogFile()
	{
		return DEBUG_LOG_FILE;
	}

	public static String getServerType()
	{
		try
		{
			return getInstance().m_sServerType;
		}
		catch (SettingsLoadingException e)
		{
			return DEFAULT_SERVER_TYPE;
		}
	}

	void setServerType(String sServerType)
	{
		m_sServerType = sServerType;
		parseSettings();
		setChanged();
		notifyObservers();
	}
	
	void setTestServer(boolean bTestServer)
	{
		m_bTestServer = bTestServer;
		m_sServerType = (bTestServer ? "T" : "P");
		parseSettings();
		setChanged();
		notifyObservers();
	}
	
	public static boolean isTestServer()
	{
		try
		{
			return getInstance().m_bTestServer;
		}
		catch (SettingsLoadingException e)
		{
			return true;
		}
	}
	
	void setTrackJdbcConnections(boolean bDoTrack)
	{
		setCustomSetting(SETTING_NAME_TRACK_JDBC_CONNECTIONS, String.valueOf(bDoTrack));
		parseSettings();
		setChanged();
		notifyObservers();
	}

	public static boolean isTrackJdbcConnections()
	{
		try
		{
			return getInstance().m_bTrackJdbcConnections;
		}
		catch (SettingsLoadingException e)
		{
			return false;
		}
	}
	
	void setDoForceSerialization(boolean doForceSerialization)
	{
		m_bForceSerialization = doForceSerialization;
		setChanged();
		notifyObservers();
	}
	
	public static boolean doForceSerialization()
	{
		try
		{
			return getInstance().m_bForceSerialization;
		}
		catch (SettingsLoadingException e)
		{
			return false;
		}
	}

	void setDoCheckSerialization(boolean doCheckSerialization)
	{
		m_bCheckSerialization = doCheckSerialization;
		setChanged();
		notifyObservers();
	}
	
	/**
	 * Return Clam AV Host defined in Java Settings
	 *
	 * @return Clam AV Host
	 */
	public static String getClamAvHost()
	{
		String sClhost = null;
		String sClamavHost = getProperty( SETTING_NAME_CLAMAV_IDMS_HOSTPORT );
		String[] clamavHostPort = new String[0];
		if ( sClamavHost != null )
		{
			clamavHostPort = sClamavHost.trim().split( ":" );
			if ( clamavHostPort.length > 0 )
			{
				sClhost = clamavHostPort[0];
			}
		}
		
		if ( sClhost == null || sClhost.length() < 1 )
		{
			throw new CRuntimeException( "ClamAV host is not defined" );
		}
		return sClhost;
	}

	/**
	 * Return Clam AV Port defined in Java Settings
	 *
	 * @return Clam AV Port
	 */
	public static int getClamAvPort()
	{
		String sClamavHostPort = getProperty( SETTING_NAME_CLAMAV_IDMS_HOSTPORT );
		String[] clamavHostPort = new String[0];
		if ( sClamavHostPort != null )
		{
			clamavHostPort = sClamavHostPort.trim().split( ":" );
		}
		
		int nClport = -1;
		if ( clamavHostPort.length > 1 && clamavHostPort[1] != null && clamavHostPort[1].length() > 0 )
		{
			try
			{
				nClport = Integer.parseInt( clamavHostPort[1] );
			}
			catch ( NumberFormatException ex )
			{
				throw new CRuntimeException( "Invadid format of ClamAV string '" + sClamavHostPort + "'" );
			}
		}
		
		if ( nClport <= 0 )
		{
			throw new CRuntimeException( "ClamAV port is not defined" );
		}
		return nClport;
	}

	public static boolean doCheckSerialization()
	{
		try
		{
			return getInstance().m_bCheckSerialization;
		}
		catch (SettingsLoadingException e)
		{
			return false;
		}
	}

	public static String getXmlResPathUrl()
	{
		return getInstance().getResourceRoot()  + COMMON_RESOURCE_PATH + XML_DIR;
	}

	/**
	 * check that dms is supported by instance
	 * @param nDMSToCheck one or few (combined with binary OR) of the SUPPORTED_DMS_ constants
	 */
	public static boolean isDMSSupported(int nDMSToCheck)
	{
		try
		{
			int nSupportedDMS = getInstance().m_nSupportedDMS;
			return ((nSupportedDMS & nDMSToCheck) == nDMSToCheck);
		}
		catch (SettingsLoadingException e)
		{
			return true;
		}
	}

	/*
	 * --------------- DEPRECATED METHODS --------------------
	 */

	/**
	 * Method returns a root for HTTP resources on Application Server
	 *
	 * This value is taken from table JAVA_SETTINGS - property name "RESOURCE_ROOT"
	 * @return resource root, eg. "http://localhost:8080"
	 */
	public static String getHttpResRoot()
	{
		return getInstance().getResourceRoot();
	}

	/**
	 * de-pre-cated?		Use class hireright.gui.mvc.CMVCSettings
	 * @return default design path, eg. "/designs/general"
	 */
	public static String getDefaultDesignPath()
	{
		return DESIGN_RESOURCE_PATH;
	}
	
	public Map<String, String> getSettings()
	{
		return m_javaSettings;
	}
	
	public static Map<String, String> getProperties()
	{
		if (m_customJavaSettings.get() == null || m_customJavaSettings.get().isEmpty())
			return getInstance().m_javaSettings;

		Map<String, String> settings = new HashMap<String, String>();
		settings.putAll(getInstance().m_javaSettings);
		settings.putAll(m_customJavaSettings.get());
		return settings;
	}
}

class SettingsLoadingException extends RuntimeException
{

	public SettingsLoadingException( String message )
	{
		super(message);
	}

	public SettingsLoadingException( Exception e )
	{
		super(e);
	}
	
}
