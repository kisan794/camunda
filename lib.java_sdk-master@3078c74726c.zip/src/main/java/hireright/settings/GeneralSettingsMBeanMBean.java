/*
 * @(#)$RCSfile: GeneralSettingsMBeanMBean.java,v $ $Revision: 1.3 $ $Date: 2009/04/24 14:33:01 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/settings/GeneralSettingsMBeanMBean.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev				2008-10-01	created
 *	A.Solntsev				2009-04-20	Removed methods getAppRoot(), getApplicationRoot()
 */
package hireright.settings;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.3 $ $Date: 2009/04/24 14:33:01 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/settings/GeneralSettingsMBeanMBean.java,v $
 */
public interface GeneralSettingsMBeanMBean 
{
	void refresh();
	
	String getResourceRoot();
	
	String getServerType();
	void setServerType(String sServerType);
	
	boolean isTestServer();
	void setTestServer(boolean bTestServer);
	
	boolean isTrackJdbcConnections();
	void setTrackJdbcConnections(boolean bDoTrack);
	
	boolean isDoForceSerialization();
	void setDoForceSerialization(boolean doForceSerialization);
	
	boolean isDoCheckSerialization();
	void setDoCheckSerialization(boolean doCheckSerialization);
	
	String getXmlResPathUrl();
	
	String getProperty(String name);
	void setProperty(String name, String value);
}
