/*
 * @(#)$RCSfile: IObjectHolder.java,v $ $Revision: 1.2 $ $Date: 2010/08/19 20:26:35 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/utils/IObjectHolder.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	 2010-08-04		V.Osipov		created
 */

package hireright.utils;

/**
 * Interface implements the logic of put and get methods.
 * @author Vladimir Osipov
 * @version $Revision: 1.2 $, $Date: 2010/08/19 20:26:35 $
 */
public interface IObjectHolder {

	/**
	 * This method maps the specified key to the specified value.
	 *
	 * @param szKey unique key
	 * @param oVal object to be stored
	 */
	public abstract void put(String szKey, Object oVal);

	/**
	 * This method get the specified value with help of the specified key from object.
	 * @param szKey unique key
	 * @return null if no such object found in session
	 */
	@SuppressWarnings("unchecked")
	public abstract <T extends Object> T get(String szKey);

}