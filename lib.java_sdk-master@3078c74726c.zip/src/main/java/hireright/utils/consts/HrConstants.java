/*
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Gusev			2020-03-31		Add foreign_degree_equivalency_vsid = 1299 field
 * 	V.Minakov			2000-01-11	Add new VS - 74,75,76,77,78,79
 * 	V.Minakov			2000-01-11	Add comments to VS - 74,75,76,77,78,79
 * 	Ignatov Sergei		2001-08-05	All constants from PACKAGE hr_const
 *  Sergei Prokopov		2004-05-19	Added constant for contact current employer
 *  								Moved from integrations bv_international
 * 	Aleksei Velizhanin	2005-01-03	Added constant for ASRC module.
 * 	Aleksei Velizhanin	2005-02-14	Constant for ASRC module chnged from 92 to -1. 
 * 	Aleksei Velizhanin	2005-05-13	Constant for ASRC module changed back to 92. 
 * 	S.Kocherovets		2006-05-18	Constants for one-click criminal are added. 
 *	A.Plohotnichenko	2006-05-29	Some credit and sriminal services added.
 *	A.Arekhin			2007-08-16	Added SSN Validation vsid
 *  N.Danilov 			2008-10-29  Added HAIR_VSID
 *  A.Velizhain			2009-04-28	Generic product VSIDs added
 *  N.Danilov 			2009-10-29  Added fingerprinting VSID
 *  A.Arekhin 			2009-12-08  Added health_empl_vsid, dot_compl3y_vsid, dot_drug3y_vsid
 *  A.Plohotnichenko	2009-12-31	DRIVER_EMPLOYMENT_HISTORIES_VSID, DRUG_ALCOHOL_RECORDS_VSID. 
 *  A.Arekhin				2010-03-15	crec_health_statewide_vsid. 
 *  D.Filonenko			2012-03-15	prem_educ_vsid and prem_empl_vsid.
 *  M.Kuznetsov			2012-11-26	add group type constants.
 *  S.Dubrov				2013-05-23	Added Ancillary Services group constant.
 *  A.Arekhin				2013-10-22	crec_crm_fednl_vsid.  
 *  A.Mironov				2014-01-13	bv_empl_plus_current.  
 *  A.Arekhin				2014-04-30	managed_adj_vsid.   
 *  A.Arekhin				2016-12-19	managed_adj3_vsid, self_adj3_vsid.   
 *  P.Vammus				2017-06-12	HIVPE-16313: Constant basic_disclosure added.
 *  P.Vammus				2017-11-28	HIVPE-25006: Constant ct_educational_empl_vsid added.
 *  E.Magi					2017-12-12	HIVPE-28119: add gap services
 *  E.Magi					2018-03-14	HIVPE-33995: add global id check
 *  E.Magi					2018-06-22	HIVPE-36336: add directorship search
 *  P.Vammus				2018-09-14	HIVPE-41211: Constant UK_CREDIT_VSID added.
 *  P.Vammus				2019-01-16	HIVPE-41211: Constant standard_disclosure added.
 *  P.Vammus				2019-01-16	HIVPE-59243: Constant enhanced_disclosure added.
 *  P.Vammus				2019-03-19	HIVPE-74249: Constants resume_check, cv_analysis added.
 *	Alex.Sibul				2019-05-12	HIVPE-79388: Constants animal_rights_activism_search_vsid added.
 *  Alex.Sibul				2019-04-12	HIVPE-75682: Constants cdn_provincial_crim added.
 *  A.Gribkov				2021-02-17	HRG-152573: Constants FORMS_AND_QUESTIONNAIRES added.
 */

package hireright.utils.consts;

/**
 * Class for constants.
 * 
 * @author		Vlad Zyaikin
 */
public class HrConstants
{
	public static final String WEB_REG_ID_PREFIX = "WE";
	public static final String WEB_APP_REG_ID_PREFIX = "WA";
	public static final String WEB_JB_REG_ID_PREFIX = "WJ";
	public static final String DATAENTRY_REG_ID_PREFIX = "DE";

//////////////////////////////////////////////////
// History ID (a20 in PARAMETERS table)
//////////////////////////////////////////////////
	public static final String session_hid = "SESSION_HISTORY";  // session history
	public static final String bv_educ_hid = "BV_EDUCATION";     // BV education
	public static final String bv_publ_hid = "BV_PUBLIC";        // BV public records
	public static final String bv_reports = "BV_REPORTS";       // BV reports
	public static final String rb_edu = "RB_EDUCATION";     // RB education
	public static final String rb_lic = "RB_LICENCE";       // RB licence
	public static final String rb_locat_hid = "RB_LOCATION";      // RB Location
	public static final String rb_menu_hid = "RB_MENU";          // RB Menu
	public static final String jd_match_hid = "JB_MATCHING";      // JD Skills Matching
	public static final String jd_locat_hid = "JB_LOCATION";      // JD Location
	public static final String jd_desc_hid = "JB_DESCRIPTION";   // JD Description

////////////////////////////////////////////////
// Modules ID
////////////////////////////////////////////////
	public final static int hr_mid = 1;    // HireRight Main
	public final static int de_mid = 304;  // DataEntry Tool
	public final static int bv_mid = 3;    // BV Main
	public final static int bv_educ_mid = 5;    // BV Education
	public final static int bv_empl_mid = 7;    // BV Employment
	public final static int bv_refc_mid = 9;    // BV Referense
	public final static int bv_cred_mid = 11;   // BV Credit
	public final static int bv_publ_mid = 14;   // BV Court Records

	/**
	 * Module ID for Current Employer
	 */
	public final static int bv_empl_current = 15;
	public final static int bv_empl_plus_current = 6851;

	/**
	 * Module ID for ASRC
	 */
	public final static int bv_asrc = 29;

	public final static int bv_dmvr_mid = 21;   // BV MVR
	public final static int bv_comp_mid = 23;   // BV Compensations
	public final static int bv_plic_mid = 25;   // BV Prof. License
	public final static int bv_drug_mid = 312;  // BV Drug Testing

	/**
	 * Module ID for International requests
	 */
	public final static int bv_international = 328;
	
	public final static int adj_report_mid = 316;  // Adjudication Results Report
	public final static int adj_hf_report_mid = 317;  // HardFacts Reports (if adjudication used)
	public final static int adj_status_mid = 318;  // Change Adjudication Status
	public final static int adj_fax_notif_mid = 319;  // Pending Adjudications by Fax
	public final static int adj_mail_notif_mid = 320;  // Pending Adjudications by Mail
	public final static int adj_email_notif_mid = 321;  // Pending Adjudications by Email
	public final static int adj_alien_req_mid = 323;  // Alien HardFacts Requests view
	public final static int sf_mid = 38;   // SoftFacts
	public final static int sf_test_mid = 303;  // SF Skill Tests
	public final static int sf_surveys_mid = 306;  // SF Surveys
 	public final static int sf_pro_scan = 306;  // SF ProScan - Survey
	public final static int sf_analyses_mid = 307;  // SF Analysis
 	public final static int sf_job_scan = 307;  // SF Job Scan - Analysis
	public final static int jb_main_mid = 65;   // JobBank Main
	public final static int jb_job_templ_mid = 66;   // JobTemplates
	public final static int jb_skills_mid = 81;   // JB Skills (parent=66)
	public final static int jb_mid = 83;   // JobBank
	public final static int jb_pcc_mid = 202;  // JB Pcc
	public final static int jb_appl_mid = 311;   // Applications
	public final static int jb_e_appl = 325;   // JobBank Employment Application
	public final static int jb_e_appl_view = 326;   // Alien JobBank Employment Applications View
	public final static int jb_e_appl_verify = 327;   // Alien JobBank Employment Applications Verify
	public final static int setup_mid = 85;   // Setup
	public final static int setup_users_mid = 309;  // Setup Users
	public final static int setup_questions_mid = 310;  // Setup Questions
	public final static int reg_mid = 201;  // HireRight Registration
	public final static int ot_requests_mid = 98;   // OpTool Requests
	public final static int hr_login_mid = 200;  // HireRight Login
//////////////////////////////////////////////////
// Events ID
//////////////////////////////////////////////////
	public final static int legal_login_eid = 1;    // legal login
	public final static int illegal_login_eid = 2;    // illegal login
	public final static int start_reg_eid = 3;    // start registration
	public final static int end_reg_eid = 4;    // end registration
	public final static int submit_req_eid = 7;    // submit request
	public final static int create_req_eid = 8;    // create request
	public final static int delete_req_eid = 9;    // delete request
	public final static int ssn_check_eid = 10;   // SSN check event_id
	public final static int new_user_eid = 12;   // add user
	public final static int change_user_eid = 13;   // change user
	public final static int delete_user_eid = 14;   // delete user
	public final static int delete_pcc_eid = 19;   // Delete candidate from PCC
	public final static int move_to_pcc_eid = 21;   // Move candidate to PCC
	public final static int auto_request_eid = 22;   // AutoRequest
	public final static int smatch_eid = 23;   // Skill Match Done
	public final static int srating_eid = 24;   // Skill Rating Done
	public final static int srating_pdp_eid = 25;   // Job Scan Done
	public final static int delete_job_eid = 26;   // Delete job
	public final static int delete_cand_eid = 27;   // Delete job candidate
	public final static int lock_cand_eid = 28;   // lock job candidate
	public final static int unlock_cand_eid = 29;   // unlock job candidate
	public final static int edit_templ_eid = 32;   // edit JobBank Template
	public final static int delete_templ_eid = 33;   // delete JobBank Template
	public final static int create_templ_eid = 34;   // create JobBank Template
	public final static int new_proscan_eid = 37;   // New ProScan Survey
	public final static int edit_proscan_eid = 38;   // Edit ProScan Survey
	public final static int delete_proscan_eid = 39;   // Delete ProScan Survey
	public final static int new_jda_eid = 41;   // New JDA Survey
	public final static int edit_jda_eid = 42;   // Edit JDA Survey
	public final static int delete_jda_eid = 43;   // Delete JDA Survey
	public final static int new_jobmodel_eid = 45;   // New Job Model (Info)
	public final static int edit_jobmodel_eid = 46;   // Edit Job Model (Info and source)
	public final static int del_jobmodel_eid = 47;   // Delete Job Model
	public final static int addto_jobscan_eid = 49;   // Add survey to JobScan
	public final static int delfrom_jobscan_eid = 50;   // Delete survey from JobScan
	public final static int new_team_eid = 55;   // New, edit Team (Info)
	public final static int del_team_eid = 56;   // Delete Team
	public final static int addto_team_eid = 57;   // Add survey to Team
	public final static int delfrom_team_eid = 58;   // Delete survey from Team
	public final static int new_school_eid = 51;   // add school
	public final static int new_skill_type_eid = 52;   // add skill type
	public final static int new_skill_code_eid = 53;   // add skill code
	public final static int new_skill_eid = 54;   // add skill
	public final static int change_adj_res_eid = 59;   // change Adj.Result
	public final static int user_perm_eid = 145;  // change user"s permission
	public final static int lock_subreq_eid = 160;  // lock in a subrequest
	public final static int send_subreq_eid = 161;  // send a request to a service provider
	public final static int enter_answer_eid = 162;  // enter an answer
	public final static int set_ready_eid = 163;  // set READY status
	public final static int subreq_frozen_eid = 260;  // subrequest frozen
	public final static int subreq_defrozen_eid = 261;  // subrequest defrozen
	public final static int subreq_reassign_eid = 262;  // subrequest reassigned
	public final static int new_city_eid = 400;  // Add new city
	public final static int new_county_eid = 401;  // Add new county

//////////////////////////////////////////////////
// delivery_method_ID
//////////////////////////////////////////////////
	public final static int email_dmid = 1;   // e-mail
	public final static int fax_dmid = 2;   // fax
	public final static int mail_dmid = 3;   // postal mail
//////////////////////////////////////////////////
// Customer"s Address_Type
//////////////////////////////////////////////////
	public static final String bs_adtype = "Bs";   // Business address
	public static final String ml_adtype = "Ml";   // Mailing address
	public static final String cn_adtype = "Cn";   // Contact address
	public static final String pr_adtype = "Pr";   // Principal address
////////////////////////////////////////////////
// Verification_subject_ID
////////////////////////////////////////////////
	public final static int pers_vsid = 1;   // Personal Reference
	public final static int plic_vsid = 2;   // Professional Licenses
	public final static int educ_vsid = 3;   // Education
	public final static int empl_vsid = 4;   // Employment
	public final static int dobi_vsid = 5;   // DOB inquiry
	public final static int dmvr_vsid = 6;   // MVR Report
	public final static int drug_vsid = 7;   // Drug Testing
	public final static int hair_vsid = 546; // Hair Testing
	public final static int bla_vsid  = 571; // Hair Testing
	public final static int comp_vsid = 8;   // Workers Compensation
	public final static int crec_bnk_fedrl_vsid  = 9;   // Federal Bankruptcy
	public final static int bankr_proc = 9;   // Federal Bankruptcy
	public final static int crec_crm_felny_vsid = 10;  // Criminal Felony
	public final static int criminal_rec = 10;  // Criminal Felony
	public final static int crec_crm_fedrl_vsid = 11;  // Federal Criminal
	public final static int fed_criminal_rec = 11;  // Federal Criminal
	public final static int crec_cvl_upper_vsid = 12;  // Civil Upper
	public final static int civil_action_hist = 12;  // Civil Upper
	public final static int crec_cvl_fedrl_vsid = 13;  // Federal Civil
	public final static int fed_civil_hist = 13;  // Federal Civil
	public final static int crec_cvl_lower_vsid = 14;  // Civil Lower
	public final static int crec_cvl_up_lo_vsid = 15;  // Civil Upper And Lower
	public final static int crec_crm_misdm_vsid = 16;  // Criminal Misdemeanor
	public final static int crec_crm_fl_ms_vsid = 17;  // Criminal Felony And Misdemeanor
	public final static int crec_crm_fl_ms_rapid_vsid = 3854;  // Criminal Felony And Misdemeanor Rapid
	public final static int ss_trace_vsid = 18;  // SS Trace
	public final static int empl_credit_vsid = 19;  // Employment Credit
	public final static int warrant_search_vsid = 20;  // Nationwide Warrant Search
	public final static int warrant_search = 20;  // Nationwide Warrant Search
	public final static int crec_nationwide_vsid = 20;  // Nationwide Warrant Search
	public final static int public_10_year_vsid = 21;  // 10 Years Public Records Search Surcharge
	public final static int crec_statewide_vsid = 22;  // State Wide Warrant Search
	public final static int crec_health_statewide_vsid = 25;  // Healthcare statewide search
	public final static int VS_ProScanReport = 25;  // ProScan Report (Individual)
	public final static int VS_AProScanReport = 26;  // ProScan Report (Applicant)
	public final static int VS_CProScanReport = 27;  // ProScan Report (Convert I to A)
	public final static int typing_vsid = 28;  // Typing Skill Test Report
	public final static int dba_vsid = 29;  // Oracle DBA Skill Test Report
	public final static int VS_Letter1 = 30;  // Letter 1: Generic
	public final static int VS_Letter2 = 31;  // Letter 2: Position has not been offered
	public final static int VS_Letter3 = 32;  // Letter 3: Position offered, but Applicant did not start work
	public final static int VS_JDAScanReport = 33;  // JDAScan Report
	public final static int VS_Letter4 = 34;  // Letter 4: Applicant has started work
	public final static int VS_Letter5 = 35;  // Letter 5: Consumer Report and Rights Letter
	public final static int VS_TeamScanReport = 42;  // TeamScan Report
	public final static int view_rsm_vsid = 45;  // View Resume
	public final static int VS_1_Ranking = 49;  // Calculation JobScan Ranking for one person
	public final static int rank_pdp_vsid = 50;  // JobScan - Job Dynamics Analysis on Model
	public final static int crec_crm_fednl_vsid = 50;  // Federal Criminal - National
	public final static int VS_JobModelReport = 51;  // JobModel Report
	public final static int VS_JobScanReport = 52;  // JobScan Report
	public final static int match_rsm_vsid = 53;  // JobBank - Resume Matching
	public final static int rank_rsm_vsid = 54;  // JobBank - Resume Ranking
	public final static int ssn_check_vsid = 55;  // SSN Validity Check
	public final static int degree_other_id = 13;  // OTHER degree ID
	public final static int nature_other_id = 40;  // OTHER nature ID
	public final static int crec_crm_1_vsid = 725;  // Criminal 1
	public final static int crec_crm_2_vsid = 722;  // Criminal 2
	public final static int crec_crm_1_anml_rght_vsid = 721;  // Criminal 1 w/ Animal Rights
	public final static int credit_1_vsid = 720;  // Credit 1
	public final static int credit_2_vsid = 726;  // Credit 2
	public final static int canadian_credit_vsid = 607;  // Canadian Credit Report
	public final static int VS_LetterKA74 = 74;  // Letter: Kinko"s Designation of Beneficiary
	public final static int VS_LetterKA75 = 75;  // Letter: WOTC NEI Form
	public final static int VS_LetterKA76 = 76;  // Letter: Kinko"s Payroll Direct Deposi Form
	public final static int VS_LetterKA77 = 77;  // Letter: Kinko"s Form 8850
	public final static int VS_LetterKA78 = 78;  // Letter: Kinko"s Form I-9
	public final static int VS_LetterKA79 = 79;  // Letter: Kinko"s Form W-4
	public final static int ssn_validation_vsid = 651;  // SSN Validation
	public final static int health_empl_vsid = 46;   // Healthcare Employment History
	public final static int dot_compl3y_vsid = 47;   // DOT Compliance 3y
	public final static int dot_drug3y_vsid = 48;   // DOT Drug & Alcohol 3y
	public final static int prem_educ_vsid = 551;   // Premium Education
	public final static int prem_empl_vsid = 552;   // Premium Employment
	public final static int ct_educational_empl_vsid = 122;   // CT Educational Employer Verification
	
	public final static int managed_adj_vsid = 95;   // Managed Adjudication
	public final static int self_adj_vsid = 103;   // Self Adjudication
	public final static int managed_adj3_vsid = 395;   // Managed Adjudication 3
	public final static int self_adj3_vsid = 396;   // Self Adjudication 3
	public final static int basic_disclosure = 814;   // Basic Disclosure
	public final static int standard_disclosure = 1234;   // Standard Disclosure
	public final static int enhanced_disclosure = 1235;   // Enhanced Disclosure
	public static final int DISCLOSURE_SCOTLAND_LEVEL2 = 1346;   // Disclosure Scotland - Level 2
	public final static int gap_standard = 1217; // Gap Standard
	public final static int gap_enhanced = 1218; // Gap Enhanced
	public final static int global_id_check = 1216; // Global ID Check
	public final static int directorship_search = 798; // Directorship Search
	public final static int staff_check = 1236; // Staff Check (CIFAS)
	public final static int canadian_sin_verification = 1278; // Canadian SIN Verification (CSNVF)
	public final static int vector_one = 1281; // Vector One
	public final static int FITNESS_AND_PROPRIETY_VSID = 1286;
	public final static int PROFESSIONAL_QUALIFICATION_VERIFICATION_VSID = 582;
	
	public final static int education_plus_vsid    = 551;  //Education Plus
	public final static int employment_plus_vsid   = 552;  //Employment Plus
	public final static int global_education_vsid  = 590;  //Global Education
	public final static int global_employment_vsid = 591;  //Global Employment
	public final static int education_basic_vsid   = 592;  //Education Basic
	public final static int employment_basic_vsid  = 593;  //Employment Basic
	public final static int regulated_employment_vsid = 595; // Regulated Employment
	public final static int nrma_retail_theft_db_vsid = 1229; // NRMA Retail Theft Database
	public final static int foreign_degree_equivalency_vsid = 1299; // Foreign Degree Equivalency
	public final static int global_rtw = 1310; // Global RTW
	
	
	
	/**
	 * Constant for Applicant self reported court records 
	 * verification subject.
	 */
	public final static int VS_ASRC = 92;
	
	/**
	 * Max alloowed amount of <code>VS_ASRC</code> 
	 */
	public final static int VS_ASRC_MAX_ALLOWED = 99;

	/**
	 * Country codes
	 */
	public final static String canada_country_code = "23";

	/** Right to Work */
	public static final int RIGHT_TO_WORK_VSID = 768;

	/** Prohibited Parties */ 
	public static final int PROHIBITED_PARTIES_VSID = 522;

	/** International Professional License Check */ 
	public static final int INTERNATIONAL_PROFESSIONAL_LICENSE_CHECK_VSID = 724;

	/** Indian Passport Verification */
	public static final int INDIAN_PASSPORT_VERIFICATION_VSID = 712;

	/** Global Sanctions & Enforcement */
	public static final int GLOBAL_SANCTIONS_AND_ENFORCEMENT_VSID = 614;

	/** Driving History */
	public static final int DRIVING_HISTORY_VSID = 754;

	/** CVC and Loan Default */
	public static final int CVS_AND_LOAN_DEFAULT_VSID = 756;

	/** Criminal 2 */
	public static final int CRIMINAL_2_VSID = 722;

	/** Criminal 1 (Public Information) */ 
	public static final int CRIMINAL_1_PUBLIC_INFORMATION_VSID = 725;

	/** Credit 2 */
	public static final int CREDIT_2_VSID = 726;

	/** Credit 1 */
	public static final int CREDIT_1_VSID = 720;

	/** Civil Litigation */
	public static final int CIVIL_LITIGATION_VSID = 747;

	/** Canadian Credit Report */
	public static final int CANADIAN_CREDIT_REPORT_VSID = 607;

	/** Animal Rights Non-US */
	public static final int ANIMAL_RIGHTS_NON_US_VSID = 741;

	/** Address Verification */
	public static final int ADDRESS_VERIFICATION_VSID = 757;

	/** International Financial Regulatory Body Search */
	public static final int INTL_FIN_REG_BODY_SEARCH_VSID = 1220;

	/** Fingerprinting */
	public static final int FINGERPRINTING_VSID = 734;

	/** Driver Employment Histories */
	public static final int DRIVER_EMPLOYMENT_HISTORIES_VSID = 53;

	/** Drug/Alcohol Records */
	public static final int DRUG_ALCOHOL_RECORDS_VSID = 54;
	
	/** UK Credit Check and Address Verification */
	public static final int UK_CREDIT_VSID = 1224;
	
	/** CV Analysis */
	public static final int cv_analysis = 583;
	public static final int CV_ANALYSIS_PLUS_VSID = 1283;
	
	/** Resume Check */
	public static final int resume_check = 1156;

	/** Animal Rights Activism Search */
	public static final int animal_rights_activism_search_vsid = 1284;
	
	/**CDN Provincial Criminal Check*/
	public static final int cdn_provincial_crim = 1279;

	public static final int RECORDED_JUDGMENT_SEARCH = 1092;
	public static final int STATE_AND_FEDERAL_TAX_LIEN_SEARCH = 1093;

		/** Forms And Questionnaires */
	public static final int FORMS_AND_QUESTIONNAIRES = 1326;

	/**
	 * Group types
	 */
	public final static String sgt_drugtest      = "DRUGTEST AUTOMATED";
	public final static String sgt_alcohol       = "ALCOHOLTEST AUTOMATED";
	public final static String sgt_physical      = "PHYSICALTEST AUTOMATED";
	public final static String sgt_ancillary     = "ANCILLARY SERVICES";
	public final static String sgt_dot_services  = "DOT SERVICES";
	public final static String sgt_dhs_services  = "DHS SERVICES";
	public final static String sgt_medquest  = "MEDICAL QUESTIONNAIRE";
}

