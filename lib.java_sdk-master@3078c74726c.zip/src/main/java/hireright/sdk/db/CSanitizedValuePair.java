/*
 * @(#)$RCSfile: CSanitizedValuePair.java,v $ $Revision: 1.8 $ $Date: 2015/03/28 08:24:17 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CSanitizedValuePair.java,v $
 *
 * Copyright 2001-2012 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	A.Tanasenko		23.01.2013		Created
 * 	A.Tanasenko		03.04.2013		Added length limit
 * 	A.Tanasenko		17.03.2015		Made transliteration suffix optional
 * 	V.Ozernov		2017-04-17		Transliteration is applied according given language of source strings
 * 	V.Ozernov		2017-05-03		HIVPE-15372 added compatibility with old version of data_sanitizer
 *  S.Sablin		2018-05-31		HIVPE-40785: Added getNValueOrValue method.
 */
package hireright.sdk.db;

import hireright.sdk.util.CDataSanitizer;
import hireright.sdk.util.CPropertyAccessor;
import hireright.sdk.util.CStringUtils;

import java.io.Serializable;

/**
 * This class represents a pair of values: plain value which is processed with {@link CDataSanitizer} and national value, which is written as-is.
 * If plain value is changed by CDataSanitizier (if it contains symbols that are replaced or transliterated) and there's no explicit national value,
 * then the original plain value is written as national value.
 * 
 * @author atanasenko
 *
 */
public class CSanitizedValuePair implements Serializable
{
	private static final long serialVersionUID = 1L;

	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	private static final CPropertyAccessor props = new CPropertyAccessor();
	
	private static final String TR_SUFFIX = " (*)";
	private static final int TR_SUFFIX_LENGTH = TR_SUFFIX.length();
	
	private Object m_obj;
	private String m_valueProperty;
	private String m_nvalueProperty;

	private int m_lengthLimit = -1;
	
	/**
	 * Creates a new pair of values for specified object. 
	 * 
	 * @param obj
	 * @param valueProperty property name of plain value
	 * @param nvalueProperty property name of national value
	 */
	public CSanitizedValuePair(Object obj, String valueProperty, String nvalueProperty)
	{
		m_obj = obj;
		m_valueProperty = valueProperty;
		m_nvalueProperty = nvalueProperty;
	}
	
	/**
	 * Limits the length of original value storage: if sanitized value exceeds this length, it will be trimmed.
	 * @param lengthLimit
	 * @return
	 */
	public CSanitizedValuePair withLengthLimit(int lengthLimit)
	{
		if(lengthLimit != -1 && lengthLimit <= TR_SUFFIX_LENGTH)
		{
			throw new IllegalArgumentException("Length limit must be larger than " + TR_SUFFIX_LENGTH);
		}
		m_lengthLimit = lengthLimit;
		return this;
	}
	
	/**
	 * Calls {@link #setValues(String, String)} with empty nvalue
	 * 
	 * @param value
	 */
	public void setValues(String value)
	{
		setValues(value, null);
	}
	
	/**
	 * Calls {@link #setValues(String, String, boolean)} with empty nvalue
	 * 
	 * @param value
	 */
	public void setValues(String value, boolean appendSuffixOnTransliteration)
	{
		setValues(value, null, appendSuffixOnTransliteration);
	}
	
	/**
	 * Sets both values. Uses original plain value, if it is changed by CDataSanitizer and nvalue is absent
	 * @param value
	 * @param nvalue
	 */
	public void setValues(String value, String nvalue)
	{
		setValues(value, nvalue, false);
	}
	
	/**
	 * Sets both values. Uses original plain value, if it is changed by CDataSanitizer and nvalue is absent.
	 * Transliteration performed according the given language of value. 
	 * @param value
	 * @param nvalue
	 * @param sLanguage - two-letter code of the language of value. Null or empty if it's unknown. 
	 */
	public void setValues(String value, String nvalue, String sLanguage)
	{
		setValues(value, nvalue, false, sLanguage);
	}
	
	/**
	 * Sets both values. Uses original plain value, if it is changed by CDataSanitizer and nvalue is absent.
	 * If appendSuffixOnTransliteration is set to true, appends a special suffix (*) to plain value of it gets transliterated.
	 * @param value
	 * @param nvalue
	 */
	public void setValues(String value, String nvalue, boolean appendSuffixOnTransliteration)
	{
		setValues(value, nvalue, appendSuffixOnTransliteration, CStringUtils.EMPTY_STRING);
	}
	
	/**
	 * Sets both values. Uses original plain value, if it is changed by CDataSanitizer and nvalue is absent.
	 * If appendSuffixOnTransliteration is set to true, appends a special suffix (*) to plain value of it gets transliterated.
	 * Transliteration performed according the given language of value.
	 * @param value
	 * @param nvalue
	 * @param sLanguage - two-letter code of the language of value. Null or empty if it's unknown.
	 */
	public void setValues(String value, String nvalue, boolean appendSuffixOnTransliteration, String sLanguage)
	{
		if(setValue(value, appendSuffixOnTransliteration, sLanguage) && CStringUtils.isEmpty(nvalue))
		{
			// if there's no nvalue and plain value was changed by transliteration, write original value as nvalue
			nvalue = value;
		}
		setNValue(nvalue);
	}
	
	/**
	 * Sets plain value and returns true if plain value was changed by CDataSanitizer and false otherwise.
	 * @param value
	 * @return
	 */
	public boolean setValue(String value)
	{
		return setValue(value, false);
	}
	
	/**
	 * Sets plain value and returns true if plain value was changed by CDataSanitizer and false otherwise.
	 * If appendSuffixOnTransliteration is set to true, appends a special suffix (*) to plain value of it gets transliterated. 
	 * @param value
	 * @return
	 */
	public boolean setValue(String value, boolean appendSuffixOnTransliteration)
	{
		return setValue(value, appendSuffixOnTransliteration, CStringUtils.EMPTY_STRING);
	}

	/**
	 * Sets plain value and returns true if plain value was changed by CDataSanitizer and false otherwise.
	 * If appendSuffixOnTransliteration is set to true, appends a special suffix (*) to plain value of it gets transliterated.
	 * Transliteration performed according the given language of value.
	 * @param value
	 * @param sLanguage - two-letter code of the language of value. Null or empty if it's unknown.
	 * @return
	 */
	public boolean setValue(String value, boolean appendSuffixOnTransliteration, String sLanguage)
	{
		String transliteratedValue;
		boolean disabledTransliteration = hireright.objects.rollout_feature.CRolloutFeatureCache.getInstance().isFeatureGloballyGranted("UTFINST_TRANSL_DISABLED");
		if(!disabledTransliteration)
		{
			if (CStringUtils.isEmpty(sLanguage))
			{
				transliteratedValue = CDataSanitizer.replace(value);
			}
			else
			{
				transliteratedValue = CDataSanitizer.replace(value, sLanguage);
			}
		}
		else
		{
			transliteratedValue =  value;
		}
		
		boolean transliterated = false;
		
		if(transliteratedValue != null)
		{
			transliterated = !transliteratedValue.equals(value);
			
			if(m_lengthLimit != -1)
			{
				// trim to maximum allowed length
				int lengthLimit = m_lengthLimit - (appendSuffixOnTransliteration && transliterated ? TR_SUFFIX_LENGTH : 0);
				if(transliteratedValue.length() > lengthLimit)
				{
					transliteratedValue = transliteratedValue.substring(0, lengthLimit);
				}
			}
			
			if(appendSuffixOnTransliteration && transliterated)
			{
				transliteratedValue += TR_SUFFIX;
			}
		}
		
		props.setValue(m_obj, m_valueProperty, transliteratedValue);
		
		return transliterated;
	}
	
	public String getValue()
	{
		String value = props.getValue(m_obj, m_valueProperty);
		return value != null ? removeSuffix(value) : value;
	}
	
	private static String removeSuffix(String value)
	{
		return value.endsWith(TR_SUFFIX) ? value.substring(0, value.length() - TR_SUFFIX_LENGTH) : value;
	}
	
	/**
	 * Returns true if plain value is marked as transliterated.
	 * @return
	 */
	public boolean isTransliterated()
	{
		String value = props.getValue(m_obj, m_valueProperty);
		return value != null && value.endsWith(TR_SUFFIX);
	}
	
	public void setNValue(String value)
	{
		props.setValue(m_obj, m_nvalueProperty, value);
	}
	
	public String getNValue()
	{
		return props.getValue(m_obj, m_nvalueProperty);
	}
	
	/**
	 * Formats this tuple as 'value (nvalue)' if both value and nvalue are present or as 'value' or 'nvalue' if only one of them is present
	 * 
	 * @return
	 */
	public String getFormattedValue()
	{
		StringBuilder sb = new StringBuilder();
		String value = getValue();
		String nvalue = getNValue();
		
		if(value != null && nvalue != null)
		{
			sb.append(value).append(" (").append(nvalue).append(")");
		}
		else if(value != null)
		{
			sb.append(value);
		}
		else if(nvalue != null)
		{
			sb.append(nvalue);
		}
		
		return sb.toString();
	}
	
	public String getNValueOrValue()
	{
		return CStringUtils.nvl(getNValue(), getValue());
	}
	
}
