/*
 * @(#)$RCSfile: CConnection.java,v $ $Revision: 1.30 $ $Date: 2015/11/02 20:15:49 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CConnection.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2002-09-30	M.Lukyanenko	changed for 9i Rel2 Application Server
 *  2005-05-23	A.Solntsev		Now closing InitialContext.
 *  2005-08-11	A.Solntsev		Added forced setting of NLS Parameters.
 *  2005-10-03	A.Solntsev		Added listing of binded objects if DataSource is not found.
 *  2005-10-03	A.Solntsev		JNDI name is changed to "java:comp/env/jdbc/HireRightDS".
 *  2005-10-06	A.Solntsev		Usage of CFileLog is temporarily removed due to infinite looping.
 *	2005-11-30	A.Solntsev		Added method getUrl(). Removed verbose printing error.
 *	2005-12-02	A.Solntsev		Added methods checkJNDI(), checkConnection(), getException().
 *	2006-02-27	A.Solntsev		"jdbc/HireRightDS" changed to "java:comp/env/jdbc/HireRightDS". I hope finally :)
 *	2006-04-27	A.Solntsev		Added utility method isClosed().
 *	2006-04-27	A.Solntsev		Added method initThreadLocalConnection()
 *	2006-06-13	A.Solntsev		Added method rollback()
 *	2007-02-21	A.Solntsev		Added method toProperties()
 *	2007-09-21	A.Solntsev		Added method getMaskedURL() (it's used in unit tests)
 *	2007-11-05	A.Solntsev		JNDI name is not customizable (seems to be needed in JBoss)
 *	2008-01-14	A.Solntsev		Bugfix: catch IllegalStateException in addition to SQLException.
 *	2008-10-09	A.Solntsev		Added method getConnection(boolean bTrackingConnection)
 *	2008-10-10	A.Solntsev		Fixed closing ResultSet
 *	2008-11-14	A.Solntsev		Use commons-logging instead of System.err.println
 *	2010-03-05	A.Solntsev		Use log4j instead of commons-logging.
 *	2014-04-17	M.Suhhoruki	r1.23.2 + common-logging returns!
 *	2014-05-07	A.Tanasenko		m_bExceptionPrinted flag is reset when a connection gets created successfully
 *	2014-05-07	M.Suhhoruki		Added revalidated connection
 *	2014-05-16	M.Suhhoruki		checkConnection deprecated
 *	2014-05-15	A.Tanasenko		Removed m_bExceptionPrinted flag: exceptions will always be logged
 *	2020-06-05	V.Ozernov			HRG-114082 Added second attempt to establish connection in case of "Connection reset", refactored
 *	2022-03-05	A.Dashkovskii		HRG-193766 Pool information on exception added
 *	2022-03-05	A.Dashkovskii		HRG-302070 Disable CClosableRegistry logic if we are using a connection provider
 *	2024-08-16	V.Ozernov			HRG-318608 Multitenancy support for the mode without multitenant driver
 */
package hireright.sdk.db;

import hireright.lib.logging.util.lang.ExceptionUtils;
import hireright.sdk.consts.Logical;
import hireright.sdk.db3.CHibernateWrapper;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CClosableRegistry;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.IClosable;
import hireright.sdk.util.Lang;
import hireright.settings.GeneralSettings;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.naming.Binding;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;

/**
 * @author	Maxim Lukyanenko
 * @date	2002-09-30
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CConnection.java,v $
 * @version $Revision: 1.30 $ $Date: 2015/11/02 20:15:49 $ $Author: cvsroot $
 */
public class CConnection
{
	/**
	 * JNDI name used to bind DataSource for application server and
	 * default DataSource for HireRight business components.
	 */
	public static final String JNDI_NAME_CONNECTION = "java:comp/env/jdbc/HireRightDS";

	private static final Log LOG = LogFactory.getLog(CConnection.class);
	
	private static final String JVM_PROPERTY_JNDI_NAME = "db.jndi.name";

	/**
	 * By default it's equal to {@link #JNDI_NAME_CONNECTION}.
	 * It can be customized in web.xml or by givin JVM property "db.jndi.name".
	 *
	 * It's probably need while running web application on JBoss server.
	 */
	private static String m_sJndiName = null;

	private static boolean m_bJndiChecked = false;
	
	/**
	 * We keep the last exception occurred. It can be accessed by client for
	 * logging using method getException().
	 */
	private static final ThreadLocal<Exception> m_exception = new ThreadLocal<>();
	
	/**
	 * Enables handling of "ORA-04068: existing state of packages has been discarded" errors
	 */
	private static boolean m_bUseRevalidatedConnection = true;
	
	static
	{
		String sUseRevalidatedConnection = System.getProperty("jdbc.conn.revalidated");
		m_bUseRevalidatedConnection = Lang.nvl(Logical.toBoolean(sUseRevalidatedConnection), Boolean.TRUE);
		
		String sUserLanguage = System.getProperty("user.language");
		String sUserCountry = System.getProperty("user.country");

		try
		{
			// This is workaround against NLS Parameters issue (present in Oracle 10g JDBC driver).
			// See http://www.sql.ru/forum/actualthread.aspx?tid=184458
			Locale.setDefault(new Locale(
					sUserLanguage, sUserCountry, ""));
		}
		catch (Exception e)
		{
			// TODO	Should we log it?
			LOG.warn("WARNING: failed to set default Locale to (" + sUserLanguage 
					+ ", " + sUserCountry + ") ", e);

			try
			{
				Locale.setDefault(Locale.US);
			}
			catch (Exception ex)
			{
				// TODO	Should we log it?
				LOG.warn("WARNING: failed to set default Locale to Locale.US", e);
			}
		}
	}

	/**
	 * All methods are static so no need in object instances of this class
	 */
	private CConnection()
	{
	}

	private static String getJndiName()
	{
		if (m_sJndiName == null)
		{
			m_sJndiName = System.getProperty(JVM_PROPERTY_JNDI_NAME, JNDI_NAME_CONNECTION);
		}

		return m_sJndiName;
	}

	/**
	 * Method looks up JNDI for default data source "HireRightDS".
	 * @return Connection or null if no such JNDI object is bound
	 */
	public static Connection getConnection()
	{
		return getConnection(getJndiName(), GeneralSettings.isTrackJdbcConnections());
	}
	
	public static Connection getConnection(boolean bTrackingConnection)
	{
		return getConnection(getJndiName(), bTrackingConnection);
	}

	public static Connection getNonTrackingConnection()
	{
		return CConnection.getConnection(getJndiName(), false);
	}

	/**
	 * Method gets connection from pool and puts it into current thread.
	 * Use this method in unit tests and other stuff main-methods.
	 *
	 * NB! You must explicitly unbind and close the connectino after using!
	 *
	 * @return open database connection
	 * @throws IllegalStateException if failed to establish db connection
	 * @deprecated use {@link DB}
	 */
	@Deprecated
	public static Connection initThreadLocalConnection()
	{
		Connection conn = getConnection();
		if(conn == null)
		{
			throw new IllegalStateException(
					"No DB connection\n  DataSource info - " + getDataSourceInfo(getJndiName())
			);
		}

		CCurrentThreadConnection.bind(conn);
		return conn;
	}
	
	private static String getDataSourceInfo(String jndiName)
	{
		DataSource ds = getDataSource(jndiName);
		if(ds == null)
		{
			return "DataSource = null";
		}
		if(!(ds instanceof BasicDataSource))
		{
			return "DataSource type is " + ds.getClass().getName();
		}
		try
		{
			BasicDataSource bds = (BasicDataSource)ds;
			StringBuilder sb = new StringBuilder();
			sb.append("Active connections = " + bds.getNumActive());
			sb.append(", Idle connections = " + bds.getNumIdle());
			sb.append(", local IP = " + InetAddress.getLocalHost().getHostAddress());
			return sb.toString();
		} catch(Exception e)
		{
			return "Get DataSource fail - " + e.getMessage();
		}
	}

	private static DataSource getDataSource(String sDSJndiName)
	{
		InitialContext ic = null;
		try
		{
			ic = new InitialContext();
			return (DataSource) ic.lookup(sDSJndiName);
		}
		catch (NamingException e)
		{
			m_exception.set(e);
			LOG.fatal("FATAL: failed to lookup JNDI object " + sDSJndiName, e);
			return null;
		}
		finally
		{
			if (ic != null)
				try { ic.close(); }
				catch (NamingException nex) {}
		}
	}

	/**
	 * Method looks up in JNDI DataSource object with name sDSJndiName.
	 * @param sDSJndiName	for example, "jdbc/HireRightDS", "HireRightDS", "dev05", ...
	 * @param bTrackingConnection is true, CTrackingConnection instance is returned
	 * 		(useful for detecting connection leaks)
	 * @return null if no binded DataSource found in JNDI.
	 */
	public static Connection getConnection(String sDSJndiName, boolean bTrackingConnection)
	{
		if (!m_bJndiChecked)
		{
			// Do it only when first entrance
			try
			{
				checkJNDI();
			}
			catch (NamingException ne)
			{
				m_exception.set(ne);
				LOG.fatal("FATAL ERROR: JNDI is not set up correctly", ne);
			}
			m_bJndiChecked = true;
		}

		Connection conn = null;

		DataSource ds = getDataSource(sDSJndiName);

		if (ds == null)
		{
			LOG.fatal("JNDI object " + sDSJndiName + " is not found");
			return null;
		}

		try
		{
			conn = establishConnection(ds);
			conn.setAutoCommit(false);
			
			// create hashCode/equals friendly connection object
			conn = CHashableConnection.create(conn, sDSJndiName);
			
			// track queries
			if (bTrackingConnection)
			{
				conn = CTrackingConnection.create(conn);
			}
			
			// retry query on ORA-4068
			if (m_bUseRevalidatedConnection)
			{
				conn = CRevalidatedConnection.create(conn);
			}
			
			conn = CMultitenantConnection.wrapIfNeeded(conn, sDSJndiName);
		}
		catch (SQLException e)
		{
			if(conn != null) closeConnection(conn);
			conn = null;
			m_exception.set(e);
			LOG.fatal("FATAL: Failed to establish DB Connection", e);
		}

        // (!CHibernateWrapper.isConnectionProviderSet()) Skip CClosableRegistry logic if we are using a connection provider
        // https://jira.hireright.com/browse/HRG-302070
		if(conn != null && CClosableRegistry.currentThreadInstance() != null && !CHibernateWrapper.isConnectionProviderSet())
		{
			final Connection c = conn;
			final String DSJndiName = sDSJndiName;
			CClosableRegistry.registerCurrentThread(new IClosable() {
				@Override
				public void close() {
					boolean closed;
					try {
						closed = c.isClosed();
					}
					catch (SQLException e)
					{
						closed = true;
					}
					if(!closed)
					{
						CTrackingConnection tc = CTrackingConnection.unwrap(c);
						String st = tc != null ? tc.getCreationStackTrace() : null;
						
						CProperties paramsForLogging = new CProperties();
						paramsForLogging.setProperty("resourcePath", this.getClass().getClassLoader().getResource(""));
						paramsForLogging.setProperty("sDSJndiName", DSJndiName);
						CTraceLog.addCurrentThreadParameters(paramsForLogging);
					
						LOG.error("Closing connection for you, please close it yourself" + (st != null ? "; creation stacktrace:\n" + st : ""));
						
						CConnection.closeConnection(c);
					}
				}
			});
		}
		return conn;
	}

	/**
	 * Method safely closes given connection without throwing any exceptions.
	 * Closing already closed connection does not give any effect.
	 *
	 * @param conn	database connection, may be null
	 * @return	method always returns null
	 */
	public static Connection closeConnection(Connection conn)
	{
		try
		{
			if (conn != null && !conn.isClosed())
				conn.close();
		}
		catch (SQLException sqle) { }
		catch (IllegalStateException sqle) { }
		catch (HibernateException e) { }

		return conn;
	}

	public static boolean isClosed(Connection conn)
	{
		if (conn == null)
			return true;

		try
		{
			return conn.isClosed();
		}
		catch (SQLException sqle)
		{
			return true;
		}
		catch (IllegalStateException sqle)
		{
			return true;
		}
	}

	/**
	 * <p>
	 * Method returns URL of database. <br/>
	 * NB! Returned URL mey contain username and password.
	 * </p>
	 *
	 * <p>
	 * E.g. "jdbc:oracle:thin:user1/user1@oradev02.hireright.ee:1521:db05"
	 * </p>
	 *
	 * @param conn open connection to database
	 * @return "null", if conn is null
	 */
	public static String getUrl(Connection conn)
	{
		if (conn == null)
			return "null";

		try
		{
			return conn.getMetaData().getURL();
		}
		catch (SQLException sqle)
		{
			// I guess it never happens for a valid connection.
			return "Cannot resolve DB URL";
		}
		catch (IllegalStateException sqle)
		{
			// I guess it never happens for a valid connection.
			return "Cannot resolve DB URL";
		}
	}

	/**
	 * <p>
	 * Method returns URL of database in which password is masked with "****" chanracters.
	 * </p>
	 *
	 * <p>
	 * E.g. "jdbc:oracle:thin:user1/***@oradev02.hireright.ee:1521:db05"
	 * </p>
	 * @param sDbConnectionUrl URL of any database of form "jdbc:oracle:thin:user1/password@oradev02.hireright.ee:1521:db05"
	 * @return "null", if conn is null
	 */
	public static String getMaskedUrl(String sDbConnectionUrl)
	{
		if (sDbConnectionUrl == null)
			return null;

		return sDbConnectionUrl.replaceAll("(.*\\/).*(@.*)", "$1\\*\\*\\*$2");
	}

	/**
	 * <p>
	 * Method returns URL of database in which password is masked with "****" chanracters.
	 * </p>
	 *
	 * <p>
	 * E.g. "jdbc:oracle:thin:user1/***@oradev02.hireright.ee:1521:db05"
	 * </p>
	 * @param conn open connection to database
	 * @return "null", if conn is null
	 */
	public static String getMaskedUrl(Connection conn)
	{
		return getMaskedUrl(getUrl(conn));
	}

	public static Map<String, String> toProperties(Connection conn)
	{
		if (conn == null)
			return null;

		Map<String, String> params = new HashMap<String, String>();

		try{params.put("url", conn.getMetaData().getURL());} catch (Throwable e){/*ignore*/}
		// try{params.put("dbVersion", String.valueOf( conn.getMetaData().getDatabaseMajorVersion() ));} catch (Throwable e){}
		try{params.put("driverVersion", String.valueOf( conn.getMetaData().getDriverMajorVersion() ));} catch (Throwable e){/*ignore*/}
		try{params.put("driver", conn.getMetaData().getDriverName());} catch (Throwable e){/*ignore*/}
		try{params.put("username", conn.getMetaData().getUserName());} catch (Throwable e){/*ignore*/}

		return params;
	}

	static final String sCheckStatement = "SELECT SYSDATE FROM DUAL";

	/**
	 * Method checks if given DB connection is valid.
	 * Can be used in external adapters or anywhere else.
	 *
	 * Don't call this method too frequently since it executes additional select.
	 *
	 * @param conn	database connection
	 * @return	true iff conn is null, closed, or
	 * 				method failed to execute "SELECT SYSDATE FROM DUAL"
	 * 
	 * @deprecated - Use DB pool's validation query
	 */
	@Deprecated
	public static boolean checkConnection(Connection conn)
	{
		if (conn == null)
			return false;

		PreparedStatement stmt = null;
		try
		{
			if (conn.isClosed())
				return false;

			stmt = conn.prepareStatement(sCheckStatement);
			ResultSet rs = stmt.executeQuery();
			try
			{
				if (!rs.next())
					return false;
	
				Date dt = rs.getDate(1);
				if (dt == null)
					return false;
			}
			finally
			{
				try {rs.close();} catch (Exception e) {}
			}

			return true;
		}
		catch (SQLException sqle)
		{
			return false;
		}
		catch (IllegalStateException sqle)
		{
			return false;
		}
		finally
		{
			if (stmt != null)
			{
				try {stmt.close();} catch (SQLException e2) {} catch (IllegalStateException sqle) {}
				stmt = null;
			}
		}
	}

	/**
	 * Safe rollback. It doesn't throw SQLException.
	 * @param conn
	 */
	public static void rollback(Connection conn)
	{
		if (conn == null)
			return;

		try
		{
			conn.rollback();
		}
		catch (SQLException sqle)
		{
			// do nothing
		}
		catch (IllegalStateException sqle)
		{
			// do nothing
		}
	}

	/**
	 * Method returns the last exception occurred whlie getting DB Connection.
	 *
	 * @return	null	if no errors occurred.
	 */
	public static Exception getException()
	{
		return m_exception.get();
	}

	/**
	 * Method checks if JNDI is set up correctly. If not, it's reasonable to
	 * break program execution since no DB connection will be available.
	 *
	 * @throws NamingException	if JNDI is not set up.
	 */
	private static void checkJNDI() throws NamingException
	{
		InitialContext ic = null;
		try
		{
			ic = new InitialContext();
			Context ctx = (Context) ic.lookup("java:comp/env");
			if (ctx == null)
			{
				showContext(ic);
				throw new NamingException("Context java:comp/env is not found.");
			}
		}
		catch (NamingException ne)
		{
			// JNDI is not configured correctly
			if (ic != null)
				showContext(ic);

			throw ne;
		}
		finally
		{
			if (ic != null)
				try { ic.close(); }
				catch (NamingException nex) {}
		}
	}

	private static void showContext(Context ctx) throws NamingException
	{
		LOG.info("java.naming.factory.initial=" + System.getProperty("java.naming.factory.initial"));
		LOG.info("java.naming.provider.url=" + System.getProperty("java.naming.provider.url"));
		LOG.info("jndi.properties=" + Thread.currentThread().getContextClassLoader().getResource("jndi.properties"));

		LOG.info("List of deployed data sources: ");

		int size = 0;
		NamingEnumeration<Binding> names;
		for (names = ctx.listBindings(""); names.hasMore(); size++)
		{
			Binding binding = names.next();

			// This is a weak place.
			// It would be better to use class.isInstance(DataSource.class)
			if (binding.getClassName().equals("java.io.File"))
			{
				LOG.info(binding + " (file)");	// ignore
			}
			else if (binding.getClassName().endsWith("DataSource"))
			{
				LOG.info(binding);
			}
			else
			{
				LOG.info(binding + " (ignoring)");
			}
		}
		names.close();
		LOG.info("Total bindings: " + size);
	}
	
	private static Connection establishConnection(DataSource ds) throws SQLException
	{
			long nStartTimeNano = System.nanoTime();
			try
			{
				return ds.getConnection();
			}
			catch (SQLException firstAttemptException)
			{
					// Oracle could brake the network connection if negotiations took too long
					if (isExceptionDueToNetworkConnectionReset(firstAttemptException))
					{
							long nConnectionTimeMillisec = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - nStartTimeNano);
							LOG.warn(String.format("Failed to establish DB Connection at the first attempt in %d milliseconds", nConnectionTimeMillisec),
									firstAttemptException);

							// Second attempt
							return ds.getConnection();
					}
					else
					{
							throw firstAttemptException;
					}
			}
	}
	
	private static boolean isExceptionDueToNetworkConnectionReset(SQLException exception)
	{
			try
			{
					java.net.SocketException socketException = ExceptionUtils.unwrap(exception, java.net.SocketException.class);
					return socketException != null
							&& socketException.getClass().equals(java.net.SocketException.class); // not sub-class of SocketException since its subclasses have another meaning
			}
			catch (Throwable t)
			{
					return false;
			}
	}
}
