/*
 * Copyright 2001-2024 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * V.Ozernov				2024-07-04	HRG-314131 Created
 */

package hireright.sdk.db;

public class CMultitenantDBState
{
	public static final CMultitenantDBState NOT_SUPPORTED = new CMultitenantDBState(
			null, null, null, true, false);
	
	private final Integer containerId;
	private final String containerName;
	private final String serviceName;
	private final boolean isApplicationRoot;
	private final boolean isApplicationPDB;
	
	public CMultitenantDBState(Integer containerId, String containerName, String serviceName,
			boolean isApplicationRoot, boolean isApplicationPDB)
	{
		this.containerId = containerId;
		this.containerName = containerName;
		this.serviceName = serviceName;
		this.isApplicationRoot = isApplicationRoot;
		this.isApplicationPDB = isApplicationPDB;
	}
	
	public boolean isMultitenancySupported()
	{
		return containerId != null;
	}
	
	public Integer getContainerId()
	{
		return containerId;
	}
	
	public String getContainerName()
	{
		return containerName;
	}
	
	public String getServiceName()
	{
		return serviceName;
	}
	
	public boolean isApplicationRoot()
	{
		return isApplicationRoot;
	}
	
	public boolean isApplicationPDB()
	{
		return isApplicationPDB;
	}
	
	@Override public String toString()
	{
		return "CMultitenantDBState{" +
				(containerId == null ? "NOT SUPPORTED" : (
				"containerId=" + containerId +
				", containerName=" + containerName +
				", serviceName=" + serviceName +
				", isApplicationRoot=" + isApplicationRoot +
				", isApplicationPDB=" + isApplicationPDB +
				'}'));
	}
}
