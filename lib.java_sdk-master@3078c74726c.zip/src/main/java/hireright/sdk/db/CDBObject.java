/*
 * @(#)$RCSfile: CDBObject.java,v $ $Revision: 1.24 $ $Date: 2009/12/18 07:13:35 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CDBObject.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	A.Rudenko	2002-02-20	created
 * 	A.Rudenko 	2002-10-21	moved from hireright.objects to hireright.sdk.db package
 * 	A.Solntsev	2003-05-07	added "implements java.io.Serializable"
 *  A.Solntsev	2004-09-24	added statistics about subclasses.
 *  A.Solntsev	2004-10-26	added "synchronized (htSubclasses)".
 *  A.Solntsev	2005-06-02	Added more methods for monitoring instances.
 *  A.Solntsev	2005-06-08	Added method createTableDescriptor().
 *	A.Solntsev	2006-01-11	Added static method setConnection().
 *  M.Abdulganejev	2006-02-20	java_sdk_v2-6-6: m_conn variable made transient to enable serialization(to remove it from the persistent state of an object)
 *	A.Solntsev		2006-04-27	Used CCurrentThreadConnection instead of java.sql.Connection member
 *	A.Solntsev		2006-06-20	Added methods createTableDescriptor(), setDataIntoDB( CFTable table ); 
 *	A.Solntsev		2006-08-14	Removed annoying deprecation warnings
 *	A.Solntsev		2006-10-31	Removed java.sql.Connection member
 *	A.Solntsev		2008-08-28	using generics
 *	A.Solntsev		2008-10-10	Fixed NPE in method finalize()
 *	A.Solntsev		2009-12-09	Removed method finalize()
 */
package hireright.sdk.db;

import hireright.sdk.util.CMultiSet;

import java.io.Serializable;
import java.sql.Connection;
import java.util.Date;

/**
 * Base class for DB objects classes.
 * 
 * @author Alexander Rudenko
 * @version $Revision: 1.24 $ $Date: 2009/12/18 07:13:35 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CDBObject.java,v $
 */
public class CDBObject implements IDBObject, Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.24 $ $Author: cvsroot $";

	private static final Date m_dtStarted = new Date();
	
	protected transient String m_sDbUrl;

	protected CDBObject()
	{
	}

	/**
	 * de-precated   Now CCurrentThreadConnection is used for connecting DB.
	 * 				Use empty constructor.
	 * @param conn  NOT USED
	 */
	public CDBObject(Connection conn)
	{
		this();
		m_sDbUrl = CConnection.getUrl(conn);
	}
	
	@Deprecated
	public static CMultiSet<String> getStatisticsCreated()
	{
		return null;
	}
	
	@Deprecated
	public static CMultiSet<String> getStatisticsFinalized()
	{
		return null;
	}
	
	public static Date getDateStarted()
	{
		return m_dtStarted;
	}
	
	/**
	 * de-precated Use CCurrentThreadConnection.getConnection(); instead.
	 * 				DB Object should not know about DB connection
	 * @return same as CCurrentThreadConnection.getConnection()
	 */
	public Connection getConnection()
	{
		return CCurrentThreadConnection.getConnection();

	}

	/**
	 * De-precated   This method does not take effect.
	 * @param conn NOT USED
	 */
	public void setConnection(Connection conn)
	{
		m_sDbUrl = CConnection.getUrl(conn);
	}
	
	/**
	 * This is a special hack method which actually doesn't use given connection.
	 * This is needed for eliminating Java compiler warnings about unused connection parameter 
	 * in many methods in our code.
	 * 
	 * @param conn NOT USED
	 * @since Nov 1, 2006
	 */
	protected static final void simulateUse(Connection conn)
	{
		if (conn != null) {}
	}

	/**
	 * De-precated   This method does not take effect.
	 * @param dbObject NOT USED
	 * @param conn NOT USED
	 */
	public static void setConnection(CDBObject dbObject, Connection conn)
	{
		if (dbObject != null && conn != null)
		{
			// dbObject.setConnection(conn);
		}
	}
	
	public final void getDataFromDb( CFTable table )
	{
		getDataFromDB( table );
	}
	
	/**
	 * This method must be implemented in subclasses for 
	 * using functionality of CDBObjectFactory.
	 */
	protected void getDataFromDB( CFTable table )
	{
		// This method should be abstract and should be overridden in subclasses
		if (table == null)
			throw new IllegalArgumentException("table argument should not be null");
	}
	
	/**
	 * This method must be implemented in subclasses for 
	 * using functionality of CDBObjectFactory.
	 * 
	 * @param table
	 * @return false iff setting failed.
	 * 		Usually this means that class tried to set value of invalid type to some colum.
	 * @since java_sdk_v2-6-14
	 */
	protected boolean setDataIntoDB( CFTable table )
	{
		// This method should be abstract and should be overridden in subclasses
		if (table == null)
			throw new IllegalArgumentException("table argument should not be null");
		
		return false;
	}
	
	/**
	 * @deprecated Use method without connection parameter.
	 * 
	 * @param conn  NOT USED
	 * @return @see #createTableDescriptor()
	 */
	protected CFTable createTableDescriptor(Connection conn)
	{
		m_sDbUrl = CConnection.getUrl(conn);
		return createTableDescriptor();
	}

	/**
	 * This method should be implemented in subclass if you want to use CDBObjectFactory.
	 * T O D O  This method should be abstract
	 * 
	 * @return Typically method returns something like "new CFObjectActivityGrant()".
	 * @since java_sdk_v2-6-14
	 */
	protected CFTable createTableDescriptor()
	{
		throw new UnsupportedOperationException("Method createTableDescriptor()" +
			" should be abstract and redefined in subclasses");
	}
	
	public final CFTable createCFTable()
	{
		return createTableDescriptor(null);
	}
}
