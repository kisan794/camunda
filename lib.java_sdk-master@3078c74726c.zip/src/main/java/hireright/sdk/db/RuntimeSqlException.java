/*
 * @(#)$RCSfile: RuntimeSqlException.java,v $Revision: 1.4 $ $Date: 2009/03/20 10:33:47 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/RuntimeSqlException.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 *	A.Solntsev			2007-06-04	created
 */
package hireright.sdk.db;

import java.util.Map;

/**
 * Helpter class for converting java.sql.SQLException to a runtime exception.
 *
 * @author asolntsev
 * @since Jun 4, 2007
 * @version $Revision: 1.4 $ $Date: 2009/03/20 10:33:47 $ $Author: cvsroot $
 */
public class RuntimeSqlException extends RuntimeException
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	private Map<String, Object> m_parameters;
	public RuntimeSqlException(String sMessage, Throwable cause)
	{
		super(sMessage, cause);
	}

	public RuntimeSqlException(String sMessage, Throwable cause, Map<String, Object> parameters)
	{
		super(sMessage, cause);
		m_parameters = parameters;
	}

	public RuntimeSqlException(Throwable cause)
	{
		super(cause);
	}

	@Override
	public String toString()
	{
		if (m_parameters == null)
			return super.toString();
		else
			return super.toString() + "\n" + m_parameters.toString();
	}
}
