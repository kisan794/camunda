/*
 * @(#)$RCSfile: CDBObjectIDLoader.java,v $ $Revision: 1.6 $ $Date: 2010/02/18 21:28:57 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CDBObjectIDLoader.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev		2006-06-15	Extracted some code from CDBObjectFactory; added caching objects.
 *	A.Solntsev		2007-06-22	Removed dependency on hireright.sdkex.as_cache
 *	A.Solntsev		2008-08-28	Using generics
 *	A.Solntsev		2010-02-08	Load List<T> instad of List<Serializable>
 */
package hireright.sdk.db;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

/**
 * Class for loading list of object IDs from some table's column
 *
 * @author Andrei Solntsev
 * @since 2006-06-15
 * @version $Revision: 1.6 $ $Date: 2010/02/18 21:28:57 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CDBObjectIDLoader.java,v $
 */
public class CDBObjectIDLoader
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	/**
	 * Map of (String, Cache) - (<table_name>.<column_name>, net.sf.ehcache.Cache)
	 */
	private static final Map<String, CDBObjectIDLoader> m_instances = new HashMap<String, CDBObjectIDLoader>();

	static CDBObjectIDLoader getInstance(String sTableName, String sColumnName)
	{
		String sCacheName = sTableName + "." + sColumnName;
		CDBObjectIDLoader loader = m_instances.get(sCacheName);

		if (loader == null)
		{
			synchronized (m_instances)
			{
				loader = m_instances.get(sCacheName);
				if (loader == null)
				{
					loader = new CDBObjectIDLoader(sCacheName, sTableName, sColumnName);
					m_instances.put(sCacheName, loader);
				}
			}
		}

		return loader;
	}

	static void clearCache(String sTableName, String sColumnName)
	{
		String sCacheName = sTableName + "." + sColumnName;
		CDBObjectIDLoader loader = m_instances.get(sCacheName);
		loader.m_cache.removeAll();
	}

	static void clearCache(String sTableName)
	{
		String sCacheName;
		CDBObjectIDLoader loader;
		for (Map.Entry<String, CDBObjectIDLoader> entry : m_instances.entrySet())
		{
			sCacheName = entry.getKey();
			if (sCacheName.startsWith(sTableName + "."))
			{
				loader = entry.getValue();
				loader.m_cache.removeAll();
			}
		}
	}

	private final Cache m_cache;
	private final String m_sTableName;
	private final String m_sColumnName;

	private CDBObjectIDLoader(String sCacheName, String sTableName, String sColumnName)
	{
		CacheManager cacheManager = CacheManager.create();
		Cache cache = cacheManager.getCache(sCacheName);

		if (cache == null)
		{
			// Create cache with default settings.
			cacheManager.addCache(sCacheName);
			cache = cacheManager.getCache(sCacheName);
		}

		m_cache = cache;
		m_sTableName = sTableName;
		m_sColumnName = sColumnName;
	}

	@Override
	public String toString()
	{
		return "ObjectID Loader " + m_sTableName + "." + m_sColumnName;
	}

	<T> Collection<T> loadCachedObjectIDs(Collection<T> storage, CFTable tableDescriptor,
			CSQLWhereConstructor sqlFilter, Class<? extends T> objectIdType)
	{
		String sKey = objectIdType.getName() + ":" + sqlFilter.toString(false);
		final Collection<T> result;

		Element el = m_cache.get(sKey);
		if (el == null)
		{
			result = loadObjectIDs(storage, tableDescriptor, sqlFilter, objectIdType);
			m_cache.put(new Element(sKey, result));
		}
		else
		{
			result = (Collection<T>) el.getValue();
		}

		return result;
	}

	/**
	 * Package-private method that directly loads Object IDs from database.
	 * Used in classes: this, CDBObjectFactory.
	 *
	 * @param storage
	 * @param tableDescriptor
	 * @param sqlFilter
	 * @param objectIdType
	 * @return Collection: list of object IDs loaded from database
	 */
	<T> Collection<T> loadObjectIDs(Collection<T> storage, CFTable tableDescriptor,
			CSQLWhereConstructor sqlFilter, Class<? extends T> objectIdType)
	{
		try
		{
			if (tableDescriptor.open(sqlFilter))
			{
				do
				{
					if (objectIdType == Integer.class)
						storage.add( (T) new Integer(tableDescriptor.getString(m_sColumnName)) );
					else if (objectIdType == Long.class)
						storage.add( (T) new Long(tableDescriptor.getString(m_sColumnName)) );
					else if (objectIdType == String.class)
						storage.add( (T) tableDescriptor.getString(m_sColumnName));
					else
						throw new IllegalArgumentException("Only Integers, Longs and Strings" +
								"are supported for Object IDs, but received: " + objectIdType);
				}
				while (tableDescriptor.next());
			}
		}
		catch (RuntimeException e)
		{
			storage.clear();	// Help Garbage Collector
			throw e;
		}
		finally
		{
			if (tableDescriptor != null)
			{
				tableDescriptor.close();
			}
		}

		return storage;
	}
}
