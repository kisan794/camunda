package hireright.sdk.db.sql;

public interface IField 
{
	String getColumnName();
	ISqlValue getSqlValue();
}