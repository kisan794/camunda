/*
 * @(#)$RCSfile: CCallableStatement.java,v $ $Revision: 1.15 $ $Date: 2014/05/27 21:08:10 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/sql/CCallableStatement.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2005-08-23	A.Solntsev		created
 *	2005-11-14	A.Solntsev		Added method getClob().
 *	2005-11-16	A.Solntsev		Now IN/OUT Parameters are supported.
 *	2005-12-07	A.Solntsev		Added method close().
 *								Added creation stack trace if object is not closed properly.
 *	2006-02-02	A.Solntsev		Added null-check in method setDate().
 *	2006-03-13	A.Solntsev		Class CStringUtils is used instead of CFString.
 *	2006-05-10	A.Solntsev		Used new class CCallableStatementException for enhanced logging
 *	2006-07-31	A.Solntsev		extends CClosableObject
 *	2006-11-03	A.Solntsev		Added methods setXXX(int index, value)
 *	2008-08-26	A.Solntsev		Using generics
 *	2009-03-17	A.Solntsev		StringBuffer -> StringBuilder
  *	A.Plohotnichenko	2009-06-01	setTimestamp() added.
 *	D.Onischenko	2014-05-13	getLong, setLong, getBigDecimal, setBigDecimal added.
 *	V.Ozernov			2017-09-04	HIVPE-2252 added support for JDBC-statement {?= call <procedure-name>[(<arg1>,<arg2>, ...)]}.
*/
package hireright.sdk.db.sql;
import hireright.sdk.db.CClosableObject;
import hireright.sdk.db.CCurrentThreadConnection;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IHasProperties;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Wrapper to class java.sql.CallableStatement with 2 features:
 * <ol>
 * <li>String-binded parameters.</li>
 * <li>Possibility of functional-style declarations.</li>
 * </ol>
 * 
 * Thanks to every set-method returns <code>this</code>,
 * it's possible to call set-methods in a single row: 
 * <pre><code>
 * CCallableStatement stmt =
 * 		new CCallableStatement("{begin; call xxx...; end;}")
 * 			.setString("appId", 123456)
 * 			.setInteger("domainId", "HR-APP")
 * 			.registerOutParameter("orderId", Types.VARCHAR)
 * 			.execute()
 * 			.close();
 * </code></pre>
 * 
 * You can use SQL statements in {} - braces:
 * <pre><code>
 *		String sStatement =
 *			"{:nResult = call bdk_password.is_passwordExpired(" +
 *			":sObjectClass, :sCustomerUserID, TRUNC(SYSDATE))}";
 * </code></pre>
 * or with "?":
 * <pre><code>
 * CCallableStatement stmt =
 * 		new CCallableStatement("{ ? = call sdk_address.get_countryName(?) }")
 * 			.registerOutParameter(1, Types.VARCHAR)
 * 			.setInteger(2, 100)
 * 			.execute();
 * String sCountryName = stmt.getString(1);
 * stmt.close();
 * </code></pre>
 * 
 * You can also use "DECLARE-BEGIN-END" form:
 * <pre><code>
 *		String sStatement =
 *			"BEGIN" +
 *			"	:nResult := bdk_password.is_passwordExpired(" +
 *			"			:sObjectClass, :sCustomerUserID, TRUNC(SYSDATE));" +
 *			"END;";
 *  </code></pre>
 *  
 * @date	2005-08-23
 * @author	Andrei Solntsev
 * @version $Revision: 1.15 $ $Date: 2014/05/27 21:08:10 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/sql/CCallableStatement.java,v $
 */
@SuppressWarnings("serial")
public class CCallableStatement extends CClosableObject implements IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.15 $ $Author: cvsroot $";
	/*
	 * Implementation detail:
	 * class is not Serializable since it contains non-serializable
	 * member java.sql.CallableStatement
	 */

	private static final Log LOG = LogFactory.getLog(CCallableStatement.class);
	
	/** Shift of indexes. Value of index in statement for a first parameter that is mentioned in the statement **/
	public final static int INDEX_IN_STATEMENT_FIRST = 1;
	/** RegExp pattern to find named parameters in a statement **/
	private static final Pattern PATTERN_CALLABLE_STATEMENT_NAMED_PARAM = Pattern.compile("(:[_a-zA-Z0-9.\\$#]+)");
	/** String that substitutes named parameters in a statement **/
	private static final String JDBC_COMPATIBLE_PARAM_REF = "?";

	
	/** The statement that was given by the caller **/
	private final String m_sOriginalStatement;
	/** Translated statement that is passed to JDBC **/
	private String m_sJdbcCompatibleStatement = null;
	/** User friendly statement for the logging purposes **/
	private String m_sUserFriendlyStatement = null;
	/** Wrapped object **/
	private CallableStatement m_cstmt = null;
	
	/**
	 * Registered parameters: input values and output SQL types.
	 * Key - parameter name
	 * Value - parameter object
	 */
	private Map<String, CParameter>	m_mapParameters = Collections.EMPTY_MAP;
	
	/**
	 * Call counter for binding/registering. Is used for binding by sequence number of the call.
	 * This is necessary when arbitrary names are used in the statement, but the binding is not 
	 * called by actual parameter name or by its index.
	 * Left for compatibility with the previous version of this wrapper. But "warning" is added 
	 * to trace log in such cases.
	 */
	private int m_counterBindedValue = 1;
	
	/**
	 * Instantiates CCallableStatement with the given JDBC statement 
	 * @param sStatement - JDBC statement
	 */
	public CCallableStatement(String sStatement)
	{
		super(CCallableStatement.class);
		m_sOriginalStatement = sStatement;
	}
	
	/**
	 * Execute this SQL using ThreadLocal connection.
	 * @see CCurrentThreadConnection#getConnection()
	 * @see #execute(Connection)
	 * 
	 * @return this object
	 * @throws CCallableStatementException
	 * @since java_sdk_v2-6-13
	 */
	public CCallableStatement execute() throws CCallableStatementException
	{
		return execute(CCurrentThreadConnection.getConnection());
	}
	
	/**
	 * Substitute all binded variables and execute SQL statement.
	 * After this, all values can be received via get-methods, and finally
	 * method close() MUST be executed.
	 * 
	 * @param conn
	 * @return this object
	 * @throws CCallableStatementException if any SQLException occurred
	 */
	public CCallableStatement execute(Connection connection) throws CCallableStatementException
	{
		prepareParameters();
		prepareJdbcCompatibleStatement();
		prepareUserFriendlyStatement();
		
		try
		{
			onOpened(getJdbcCompatibleStatement());
			prepareCall(connection, getJdbcCompatibleStatement());
			applyParameters(m_cstmt);
			doExecute(m_cstmt);
		}
		catch (SQLException sqlException)
		{
			throw new CCallableStatementException(sqlException, getClass().getName() + ".execute()",
					getUserFriendlyStatement(), getBindedSqlValuesAsMap());
		}

		return this;
	}
	
	protected void prepareCall(Connection connection, String sJdbcCompatibleStatement) throws SQLException
	{
		m_cstmt = connection.prepareCall(sJdbcCompatibleStatement);
	}
	
	protected void doExecute(CallableStatement callableStatement) throws SQLException
	{
		callableStatement.execute();
	}
	
	protected List<String> findNamedParameterRefsInStatement(String sStatement)
	{
		List<String> namedParameterRefs = Collections.EMPTY_LIST;
		Matcher namedParametersMatcher = PATTERN_CALLABLE_STATEMENT_NAMED_PARAM.matcher(sStatement);
		while (namedParametersMatcher.find())
		{
			String sParameterName = namedParametersMatcher.group(0).substring(1);
			if (namedParameterRefs == Collections.EMPTY_LIST)
			{
				namedParameterRefs = new LinkedList<String>();
			}
			
			namedParameterRefs.add(sParameterName);
		}

		return namedParameterRefs;
	}
	
	protected String replaceNamedParameterRefsInStatement(String sStatement)
	{
		Matcher namedParametersMatcher = PATTERN_CALLABLE_STATEMENT_NAMED_PARAM.matcher(sStatement);
		return namedParametersMatcher.replaceAll(JDBC_COMPATIBLE_PARAM_REF);
	}
	
	protected void prepareParameters()
	{
		List<String> namedParameterRefs = findNamedParameterRefsInStatement(m_sOriginalStatement);
		for (int i = 0; i < namedParameterRefs.size(); i++)
		{
			String sParameterName = namedParameterRefs.get(i);
			CParameter parameter = getParameter(sParameterName);
			if (parameter != null)
			{
				if (parameter.isOutput()
						&& !parameter.getIndexesInStatement().isEmpty())
				{
					LOG.warn("There are miltiple occurrences of named OUT parameter " + parameter.getName() 
							+ " in callable statement\n" 
							+ m_sOriginalStatement.toString() 
							+ "\nThe last is binded.");
				}
				
				parameter.addIndexInStatement(INDEX_IN_STATEMENT_FIRST + i);
			}
		}
		
		for (CParameter parameter : m_mapParameters.values())
		{
			if (parameter.getIndexesInStatement().isEmpty())
			{
				if (CStringUtils.isNumber(parameter.getName()))
				{
					parameter.addIndexInStatement(Integer.parseInt(parameter.getName()));
				}
				else
				{
					//for compatibility with the previous version
					parameter.addIndexInStatement(parameter.getBindSequenceNumber());
					LOG.warn("Cann't find parameter " + parameter.getName() + " in callable statement\n" 
							+ m_sOriginalStatement.toString() 
							+ "\nIs binded by its call sequence number.");
				}
			}
		}
	}
	
	protected void prepareJdbcCompatibleStatement()
	{
		m_sJdbcCompatibleStatement = replaceNamedParameterRefsInStatement(m_sOriginalStatement);
	}
	
	protected String getJdbcCompatibleStatement()
	{ 
		return m_sJdbcCompatibleStatement;
	}
	
	protected void prepareUserFriendlyStatement()
	{
		if (m_mapParameters.isEmpty())
		{
			m_sUserFriendlyStatement = m_sOriginalStatement;
		}
		else
		{
			StringBuilder sbReplacedStatement = new StringBuilder(m_sOriginalStatement);
			for (CParameter parameter : m_mapParameters.values())
			{
				if (parameter.isInput())
				{
					ISqlValue value = parameter.getInputSqlValue();
					CStringUtils.replaceWholeWord(sbReplacedStatement, ":" + parameter.getName(), escape(value.getValue()));
				}
			}
				
			m_sUserFriendlyStatement = sbReplacedStatement.toString();
		}
	}
	
	protected String getUserFriendlyStatement()
	{
		return m_sUserFriendlyStatement;
	}
	
	private static String escape(Object value)
	{
		if (value instanceof String)
			return escape( (String) value);
		
		return String.valueOf(value).replaceAll("'", "''"); // ?
	}
	
	private static String escape(String sValue)
	{
		return "'" + sValue.replaceAll("'", "''") + "'";
	}
	
	protected void applyParameters(CallableStatement callableStatement) throws SQLException
	{
		for (CParameter parameter : m_mapParameters.values())
		{
			if (parameter.isInput())
			{
				ISqlValue value = parameter.getInputSqlValue();
				for(Integer nParameterIndex : parameter.getIndexesInStatement())
				{
					doSetValueToCallableStatement(value, callableStatement, nParameterIndex.intValue());
				}
			}
			
			if (parameter.isOutput() && !parameter.getIndexesInStatement().isEmpty())
			{
				doRegisterOutParameter(callableStatement,
						parameter.getLastIndexInStatement().intValue(),
						parameter.getOutputSqlType());
			}
		}
	}
	
	protected void doSetValueToCallableStatement(ISqlValue value, CallableStatement callableStatement, int nIndex) 
			throws SQLException
	{
		value.setValueToCallableStatement(callableStatement, nIndex);
	}
	
	protected void doRegisterOutParameter(CallableStatement callableStatement, int nIndex, int nSqlType)
			throws SQLException
	{
		callableStatement.registerOutParameter(nIndex, nSqlType);
	}
	
	protected Map<String, ISqlValue> getBindedSqlValuesAsMap()
	{
		if (m_mapParameters.isEmpty())
		{
			return Collections.EMPTY_MAP;
		}
		
		Map<String, ISqlValue> bindedSqlValues = new HashMap<String, ISqlValue>(m_mapParameters.size());
		for (CParameter parameter : m_mapParameters.values())
		{
			if (parameter.isInput())
			{
				bindedSqlValues.put(parameter.getName(), parameter.getInputSqlValue());
			}
		}
		
		return bindedSqlValues;
	}
	
	private CParameter getParameter(String sParameterName)
	{
		return m_mapParameters.get(sParameterName); 
	}
	
	private void addParameter(CParameter parameter)
	{
		if (m_mapParameters == Collections.EMPTY_MAP)
		{
			m_mapParameters = new HashMap<String, CParameter>();
		}
		
		m_mapParameters.put(parameter.getName(), parameter);
	}
	
	/**
	 * Close SQL Statement.
	 * Multiple closes do not take effect.
	 * 
	 * Method doesn't throw SQLException (it swallows SQLException)
	 */
	public void close() 
	{
		freeMemory();
		if (m_cstmt != null)
		{
			try
			{
				m_cstmt.close();
				m_cstmt = null;
			}
			catch (SQLException sqle) {}
		}
	}

	/**
	 * Do not use this method directly.
	 * It should be called only from method finalize().
	 * 
	 * @see CClosableObject#closeSilently()
	 */
	@Override
	protected void closeSilently()
	{
		freeMemory();
		if (m_cstmt != null)
		{
			try
			{
				m_cstmt.close();
				m_cstmt = null;
			}
			catch (SQLException sqle)
			{
				// Let's ignore it silently
			}
		}
	}
	
	protected void freeMemory()
	{
		if (!m_mapParameters.isEmpty())
		{
			for (CParameter parameter : m_mapParameters.values())
			{
				parameter.clear();
			}
			
			m_mapParameters = Collections.EMPTY_MAP;
		}
	}
	
	/**
	 * Bind value of any given SQL Type.
	 * It's better to use explicit methods setString(), setInteger() etc.
	 * 
	 * @param parameterName	binded variable human-readable name, eg. "customerID"
	 * @param value value of type sqlType
	 * @param sqlType see java.sql.Types
	 * @return this
	 */
	public CCallableStatement setValue(String parameterName, Object value, int sqlType) 
	{
		bindValue(parameterName, new CSqlValue(value, sqlType));
		return this;
	}
	
	public CCallableStatement setString(String parameterName, String x) 
	{
		bindValue(parameterName, new CSqlValue(x, Types.VARCHAR));
		return this;
	}
	
	public CCallableStatement setString(int nParameterIndex, String x) 
	{
		bindValue(nParameterIndex, new CSqlValue(x, Types.VARCHAR));
		return this;
	}

	public CCallableStatement setTimestamp(String parameterName, java.util.Date x) 
	{
		java.sql.Timestamp sqlTimestamp = (x == null ? null : new Timestamp(x.getTime()));
		bindValue(parameterName, new CSqlValue(sqlTimestamp, Types.TIMESTAMP));
		return this;
	}

	public CCallableStatement setDate(String parameterName, java.util.Date x) 
	{
		Date sqlDate = (x == null ? null : new Date(x.getTime()));
		bindValue(parameterName, new CSqlValue(sqlDate, Types.DATE));
		return this;
	}
	
	public CCallableStatement setDate(int nParameterIndex, java.util.Date x) 
	{
		Date sqlDate = (x == null ? null : new Date(x.getTime()));
		bindValue(nParameterIndex, new CSqlValue(sqlDate, Types.DATE));
		return this;
	}

	public CCallableStatement setDate(String parameterName, java.sql.Date x) 
	{
		bindValue(parameterName, new CSqlValue(x, Types.DATE));
		return this;
	}
	
	private void bindValue(int nParameterIndex, CSqlValue sqlValue)
	{
		bindValue(String.valueOf(nParameterIndex), sqlValue);
	}
	
	public CCallableStatement setInteger(String parameterName, Integer x) 
	{
		bindValue(parameterName, new CSqlValue(x, Types.INTEGER));
		return this;
	}

	public CCallableStatement setInteger(String parameterName, int x) 
	{
		bindValue(parameterName, new CSqlValue(new Integer(x), Types.INTEGER));
		return this;
	}
	
	public CCallableStatement setInteger(int nParameterIndex, Integer x) 
	{
		bindValue(nParameterIndex, new CSqlValue(x, Types.INTEGER));
		return this;
	}
	
	public CCallableStatement setInteger(int nParameterIndex, int x) 
	{
		bindValue(nParameterIndex, new CSqlValue(new Integer(x), Types.INTEGER));
		return this;
	}
	
	public CCallableStatement setFloat(String parameterName, Float x) 
	{
		bindValue(parameterName, new CSqlValue(x, Types.FLOAT));
		return this;
	}
	
	public CCallableStatement setFloat(String parameterName, float x) 
	{
		bindValue(parameterName, new CSqlValue(new Float(x), Types.FLOAT));
		return this;
	}
	
	public CCallableStatement setDouble(String parameterName, Double x) 
	{
		bindValue(parameterName, new CSqlValue(x, Types.DOUBLE));
		return this;
	}
	
	public CCallableStatement setDouble(String parameterName, double x) 
	{
		bindValue(parameterName, new CSqlValue(new Double(x), Types.DOUBLE));
		return this;
	}

	public CCallableStatement setLong(int nParameterIndex, long x)
	{
		bindValue(nParameterIndex, new CSqlValue(x, Types.BIGINT));
		return this;
	}

	public CCallableStatement setLong(int nParameterIndex, Long x)
	{
		bindValue(nParameterIndex, new CSqlValue(x, Types.BIGINT));
		return this;
	}

	public CCallableStatement setLong(String parameterName, Long x)
	{
		bindValue(parameterName, new CSqlValue(x, Types.BIGINT));
		return this;
	}

	public CCallableStatement setBigDecimal(int nParameterIndex, java.math.BigDecimal x)
	{
		bindValue(nParameterIndex, new CSqlValue(x, Types.NUMERIC));
		return this;
	}

	public CCallableStatement setBigDecimal(String parameterName, java.math.BigDecimal x)
	{
		bindValue(parameterName, new CSqlValue(x, Types.NUMERIC));
		return this;
	}
	
	private void bindValue(String sParameterName, CSqlValue sqlValue)
	{
		CParameter parameter = getParameter(sParameterName);
		if (parameter == null)
		{
			parameter = CParameter.createInputParameter(sParameterName, m_counterBindedValue, sqlValue);
			addParameter(parameter);
		}
		else if (!parameter.isInput())
		{
			parameter.setAsInput(sqlValue);
		}
		else
		{
			throw new IllegalStateException("IN Parameter " + sParameterName + " is already binded");
		}
		
		m_counterBindedValue++;
	}


	public CCallableStatement registerOutParameter(String sParameterName, int nSqlType) 
	{
		doRegisterOutParameter(sParameterName, nSqlType);
		return this;
	}
	
	public CCallableStatement registerOutParameter(int nParameterIndex, int nSqlType) 
	{
		String sParameterName = String.valueOf(nParameterIndex);
		doRegisterOutParameter(sParameterName, nSqlType);
		return this;
	}
	
	private void doRegisterOutParameter(String sParameterName, int nSqlType)
	{
		CParameter parameter = getParameter(sParameterName);
		if (parameter == null)
		{
			parameter = CParameter.createOutputParameter(sParameterName, m_counterBindedValue, nSqlType);
			addParameter(parameter);
		}
		else if (!parameter.isOutput())
		{
			parameter.setAsOutput(nSqlType);
		}
		else
		{
			throw new IllegalStateException("OUT Parameter " + sParameterName + " is already registered");
		}
		
		m_counterBindedValue++;
	}	
	
	@Override
	public boolean isClosed()
	{
		return (m_cstmt == null);
	}

	public int getInt(String sParameterName) throws SQLException
	{
		return m_cstmt.getInt(getOutParameterIndexInStatement(sParameterName));
	}
	
	public int getInt(int nParameterIndex) throws SQLException
	{
		return m_cstmt.getInt(getOutParameterIndexInStatement(nParameterIndex));
	}
	
	public float getFloat(String sParameterName) throws SQLException
	{
		return m_cstmt.getFloat(getOutParameterIndexInStatement(sParameterName));
	}
	
	public float getFloat(int nParameterIndex) throws SQLException
	{
		return m_cstmt.getFloat(getOutParameterIndexInStatement(nParameterIndex));
	}

	public Date getDate(String sParameterName) throws SQLException
	{
		return m_cstmt.getDate(getOutParameterIndexInStatement(sParameterName));
	}
	
	public Date getDate(int nParameterIndex) throws SQLException
	{
		return m_cstmt.getDate(getOutParameterIndexInStatement(nParameterIndex));
	}
	
	public String getString(String sParameterName) throws SQLException
	{
		return m_cstmt.getString(getOutParameterIndexInStatement(sParameterName));
	}
	
	public String getString(int nParameterIndex) throws SQLException
	{
		return m_cstmt.getString(getOutParameterIndexInStatement(nParameterIndex));
	}
	
	public boolean getBoolean(String sParameterName) throws SQLException
	{
		return m_cstmt.getBoolean(getOutParameterIndexInStatement(sParameterName));
	}	
	public byte getByte(String sParameterName) throws SQLException
	{
		return m_cstmt.getByte(getOutParameterIndexInStatement(sParameterName));
	}	
	public double getDouble(String sParameterName) throws SQLException
	{
		return m_cstmt.getDouble(getOutParameterIndexInStatement(sParameterName));
	}	
	public long getLong(int nParameterIndex) throws SQLException
	{
		return m_cstmt.getLong(getOutParameterIndexInStatement(nParameterIndex));
	}	
	public long getLong(String sParameterName) throws SQLException
	{
		return m_cstmt.getLong(getOutParameterIndexInStatement(sParameterName));
	}
	public Object getObject(String sParameterName) throws SQLException
	{
		return m_cstmt.getObject(getOutParameterIndexInStatement(sParameterName));
	}	
	public short getShort(String sParameterName) throws SQLException
	{
		return m_cstmt.getShort(getOutParameterIndexInStatement(sParameterName));
	}	
	public java.sql.Time getTime(String sParameterName) throws SQLException
	{
		return m_cstmt.getTime(getOutParameterIndexInStatement(sParameterName));
	}	
	public Timestamp getTimestamp(String sParameterName) throws SQLException
	{
		return m_cstmt.getTimestamp(getOutParameterIndexInStatement(sParameterName));
	}	
	public Clob getClob(String sParameterName) throws SQLException
	{
		return m_cstmt.getClob(getOutParameterIndexInStatement(sParameterName));
	}	
	public java.math.BigDecimal getBigDecimal(int nParameterIndex) throws SQLException
	{
		return m_cstmt.getBigDecimal(getOutParameterIndexInStatement(nParameterIndex));
	}
	public java.math.BigDecimal getBigDecimal(String sParameterName) throws SQLException
	{
		return m_cstmt.getBigDecimal(getOutParameterIndexInStatement(sParameterName));
	}

	private int getOutParameterIndexInStatement(int nParameterIndex)
	{
		return getOutParameterIndexInStatement(String.valueOf(nParameterIndex));
	}
	
	/**
	 * @param sParameterName name of OUT registered parameter (not containing 
	 * 					semicolomn), eg. "customerID"
	 * @return int - absolute index of OUT parameter with given name
	 * @throws IllegalArgumentException if sParameterName is not a valid name;
	 * 					IllegalStateException if method() wasn't executed.
	 */
	protected int getOutParameterIndexInStatement(String sParameterName)
	{
		CParameter parameter = getParameter(sParameterName);
		if (parameter == null)
		{
			throw new IllegalArgumentException("OUT parameter " 
					+ sParameterName 
					+ " was not registered.");
		}
		else if (parameter.getIndexesInStatement().isEmpty())
		{
			throw new IllegalStateException("Index of OUT parameter "
					+ sParameterName 
					+ " in the statement is unknown.");
		}
		else
		{
			return parameter.getLastIndexInStatement().intValue();
		}
	}

	/**
	 * @return CProperties (not-null) containing all binded variables
	 * @since java_sdk_v2-6-13
	 */
	public CProperties toProperties()
	{
		return new CProperties(getBindedSqlValuesAsMap());
	}
	
	/**
	 * @return the statement with values substituted for named parameters
	 */
	public String getReplacedStatement()
	{
		return getUserFriendlyStatement();
	}

	/**
	 * Holder of IN/OUT parameter data
	 */
	private static class CParameter
	{
		/** Parameter name **/
		private final String m_sParameterName;
		/** Sequence number of the call which binded/registered this parameter **/
		private final int m_nBindSequenceNumber;
		/** SQL value of IN parameter **/
		private ISqlValue m_inputSqlValue;
		/** SQL type of OUT parameter **/
		private int m_nOutputSqlType;
		/** Indexes of the parameter in the list of all parameters mentioned in the statement **/
		private List<Integer> m_indexesInStatement = Collections.EMPTY_LIST;
		/** Parameter was binded as IN **/
		private boolean m_bIsInput = false;
		/** Parameter was registered as OUT **/
		private boolean m_bIsOutput = false;
		
		private CParameter(String sParameterName, int nBindSequenceNumber)
		{
			m_sParameterName = sParameterName;
			m_nBindSequenceNumber = nBindSequenceNumber;
		}
		
		public static CParameter createInputParameter(String sParameterName, int nBindSequenceNumber, ISqlValue inputSqlValue)
		{
			CParameter parameter = new CParameter(sParameterName, nBindSequenceNumber);
			parameter.setAsInput(inputSqlValue);
			return parameter;
		}
		
		public static CParameter createOutputParameter(String sParameterName, int nBindSequenceNumber, int nOutputSqlType)
		{
			CParameter parameter = new CParameter(sParameterName, nBindSequenceNumber);
			parameter.setAsOutput(nOutputSqlType);
			return parameter;
		}
		
		public String getName()
		{
			return m_sParameterName; 
		}
		
		public int getBindSequenceNumber()
		{
			return m_nBindSequenceNumber;
		}
		
		public List<Integer> getIndexesInStatement()
		{
			return Collections.unmodifiableList(m_indexesInStatement);
		}
		
		public Integer getLastIndexInStatement()
		{
			if (m_indexesInStatement.isEmpty())
			{
				throw new IllegalStateException("Index in statement was not assigned to parameter: " + m_sParameterName);
			}
			
			return m_indexesInStatement.get(m_indexesInStatement.size() - 1);
		}
		
		public void addIndexInStatement(int index)
		{
			if (m_indexesInStatement == Collections.EMPTY_LIST)
			{
				m_indexesInStatement = new LinkedList<Integer>();
			}
			
			m_indexesInStatement.add(Integer.valueOf(index));
		}
		
		public ISqlValue getInputSqlValue()
		{
			return m_inputSqlValue;
		}
		
		public boolean isInput()
		{
			return m_bIsInput;
		}

		public void setAsInput(ISqlValue inputSqlValue)
		{
			m_inputSqlValue = inputSqlValue;
			m_bIsInput = true;
		}
		
		public int getOutputSqlType()
		{
			return m_nOutputSqlType;
		}

		public boolean isOutput()
		{
			return m_bIsOutput;
		}

		public void setAsOutput(int nOutputSqlType)
		{
			m_nOutputSqlType = nOutputSqlType;
			m_bIsOutput = true;
		}
		
		protected void clear()
		{
			m_inputSqlValue = null;
		}
	}
}