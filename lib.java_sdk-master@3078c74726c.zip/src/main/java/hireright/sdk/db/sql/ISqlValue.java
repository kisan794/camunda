/*
 * @(#)$RCSfile: ISqlValue.java,v $ $Revision: 1.4 $ $Date: 2007/09/14 08:56:05 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2005-08-23	A.Solntsev		created
 *	2006-05-11	A.Solntsev		Added file header and javadoc
 */
package hireright.sdk.db.sql;
import java.sql.CallableStatement;
import java.sql.SQLException;

/**
 * A 'typed' value having 2 characteristics: SQL Type (varchar/numeric/int/date/lob/...) and value (java.lang.Object).
 *  
 * @author Andrei Solntsev
 * @since java_sdk_v2-5-31
 */
public interface ISqlValue 
{
	int getSqlType();
	
	Object getValue();
	
	boolean setValueToCallableStatement(CallableStatement pstmt, int nIndex)
		throws SQLException;
}