/*
 * Copyright 2001-2016 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	mkonstantinov	Nov 3, 2015	Created, extracted from enhanced_report
 */
package hireright.sdk.db.sql;

import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import hireright.sdk.db3.DB;

/**
 * 
 */
public class CPLSQLHtmlCall 
{
	private CCallableStatement m_statement;
	
	public CPLSQLHtmlCall(String procedure) 
	{
		String sqlProcedure = new StringBuilder().append(
				"DECLARE\n" +
					"idx NUMBER;\n" +
					"buffer VARCHAR2(10000);\n" +
					"output CLOB;\n" +
				"BEGIN\n" +
					
					// print html
					"HTML.RedirectPrintTo('BUFFER', 10000);\n\n")
					.append(procedure).append(";\n")
					
					// write to out clob
					.append(
					"DBMS_LOB.createtemporary(output, false);\n" +
					"idx := 1;\n" +
					"WHILE HTML.GetBufferRow(idx, buffer)\n" + 
					"LOOP\n" +
						"DBMS_LOB.writeappend(output, LENGTH(buffer), buffer);\n" +
						"idx := idx + 1;\n" +
					"END LOOP;\n" +
					":sOracleHtmlProcedureOutput := output;\n" +
					
				"END;\n").toString();
	
		m_statement = new CCallableStatement(sqlProcedure);
	}

	public CPLSQLHtmlCall setDate(String parameterName, Date x)
	{
		m_statement.setDate(parameterName, x);
		return this;
	}

	public CPLSQLHtmlCall setDouble(String parameterName, Double x)
	{
		m_statement.setDouble(parameterName, x);
		return this;
	}

	public CPLSQLHtmlCall setFloat(String parameterName, Float x)
	{
		m_statement.setFloat(parameterName, x);
		return this;
	}

	public CPLSQLHtmlCall setInteger(String parameterName, Integer x)
	{
		m_statement.setInteger(parameterName, x);
		return this;
	}

	public CPLSQLHtmlCall setString(String parameterName, String x)
	{
		m_statement.setString(parameterName, x);
		return this;
	}

	public CPLSQLHtmlCall setValue(String parameterName, Object value, int sqlType)
	{
		m_statement.setValue(parameterName, value, sqlType);
		return this;
	}
	
	public String call() throws SQLException 
	{
		return call(DB.connection());
	}
	
	public String call(Connection connection) throws SQLException
	{
		
		// register clob result
		m_statement.registerOutParameter("sOracleHtmlProcedureOutput", Types.CLOB);
		
		// execute statement
		m_statement.execute(connection);
		
		// retrieve data
		Clob resultClob = m_statement.getClob("sOracleHtmlProcedureOutput");
		String results = resultClob.getSubString(1, (int)resultClob.length());
		
		// close statement
		m_statement.close();
		
		return results;
	}
}
