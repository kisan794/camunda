/*
 * @(#)$RCSfile: CLobUtils.java,v $ $Revision: 1.15 $ $Date: 2015/11/02 20:16:28 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/sql/CLobUtils.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Solntsev		2005-08-24	extracted some code from CCLOBfield
 *  A.Solntsev		2005-10-12	removed using OracleCallableStatement
 *  A.Solntsev		2005-10-12	Added method createBlobLocator()
 *  M.Abdulganejev	2006-02-22	fixed closed CallableStatement objects calls - Oracle10g migration fixes.
 *  A.Solntsev		2006-05-15	Throw CCallableStatementException for more details
 *  A.Solntsev		2006-10-31	Added method readClob()
 *  A.Solntsev		2007-11-05	writeClob(): removed dependency on Oracle JDBC
 *  I.Lopatukhin	2010-06-03	NCHAR support added 
 *  M.Saddarov		2010-08-26	nchar check added when writing clobs
 *  V.Osipov		2010-11-23	Changed methods saveClob(): CLOB saves with help of the method setStringForClob() from jdbc driver
 *  V.Osipov		2010-11-30	Changed methods saveClob(): Added checking for OraclePreparedStatement
 */
package hireright.sdk.db.sql;
import hireright.sdk.db2.CConnectionWrapper;
import hireright.sdk.util.CStringUtils;

import java.io.Serializable;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collections;
import java.util.HashMap;

/**
 * Common code for saving CLOBs and BLOBs to database.
 *
 * @author Andrei Solntsev
 * @date 2005-08-24
 * @since java_sdk_v2-5-31
 * @version $Revision: 1.15 $ $Date: 2015/11/02 20:16:28 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/sql/CLobUtils.java,v $
 */
public class CLobUtils implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.15 $ $Author: cvsroot $";
	
	private CLobUtils()
	{
	}

	public static final int MAX_CLOB_LENGTH = 32000;

	public static Clob createTemporaryClob(Connection conn) throws CCallableStatementException
	{
		// Working principle: temporary clob is created by calling PL/SQL
		// (JDBC createTemporary call is buggy), then data is written to the
		// new clob and saved to the table using PL/SQL again

		String sSqlStatement =
			"BEGIN \n" +
			"  dbms_lob.createtemporary(:1, FALSE, dbms_lob.CALL);\n" +
			"END;\n";

		Clob clobLocator = null;
		CallableStatement cstmt = null;

		try
		{
			cstmt = conn.prepareCall(sSqlStatement);

			cstmt.registerOutParameter(1, Types.CLOB);
			cstmt.execute();

			clobLocator = cstmt.getClob(1);
			return clobLocator;
		}
		catch (SQLException sqle)
		{
			throw new CCallableStatementException(sqle, CLobUtils.class.getName() + ".createTemporaryClob()",
					sSqlStatement, Collections.EMPTY_MAP);
		}
        finally
        {
            try
            {
                if (cstmt != null)
                {
                    cstmt.close();
                    cstmt = null;
                }
            }
            catch (SQLException e)
            {
                //do nothing
            }
        }
	}

	/**
	 * Method saves given CLOB into given table's column.
	 *
	 * @param conn	open connection to database
	 * @param sTableName	Name of table where to save
	 * @param sClobFieldName	Name of field where	CLOB must be saved to
	 * @param sIDColumnName	name of column containing unique ID (usually this is id or rowid)
	 * @param id		value of column <code>sIDColumnName</code> (usually this is id or rowid)
	 * @param sClobValue	Any String of any size (Character Large Object)
	 *
	 * @throws java.sql.SQLException	If saving failed (?)
	 */
	public static void saveClob(Connection conn, String sTableName, String sClobFieldName,
		String sIDColumnName, long id, String sClobValue) throws SQLException
	{
		saveClob(conn, sTableName, sClobFieldName,
				sIDColumnName, id, sClobValue, false);
	}
	/**
	 * Method saves given CLOB into given table's column.
	 *
	 * @param conn	open connection to database
	 * @param sTableName	Name of table where to save
	 * @param sClobFieldName	Name of field where	CLOB must be saved to
	 * @param sIDColumnName	name of column containing unique ID (usually this is id or rowid)
	 * @param id		value of column <code>sIDColumnName</code> (usually this is id or rowid)
	 * @param sClobValue	Any String of any size (Character Large Object)
	 *
	 * @throws java.sql.SQLException	If saving failed (?)
	 */
	public static void saveClob(Connection conn, String sTableName, String sClobFieldName,
		String sIDColumnName, long id, String sClobValue, boolean isNChar) throws SQLException
	{
		if (CStringUtils.isEmpty(sClobValue))
		{
			// NB! Shouldn't we update CLOB to NULL in table?
			return;
		}

		// Update clob using setString 
		String sSqlStatement =
			" UPDATE " + sTableName + 
			" SET " + sClobFieldName + " = ? " +
			" WHERE "+ sIDColumnName +" = ? ";
		oracle.jdbc.OraclePreparedStatement pstmt =
				CConnectionWrapper.requireOracleStatement(
						conn.prepareStatement(sSqlStatement));

		try
		{
			if (isNChar)
			{
				pstmt.setFormOfUse(1, oracle.jdbc.OraclePreparedStatement.FORM_NCHAR);
				pstmt.setString(1, sClobValue);
			}
			else
			{
				pstmt.setStringForClob(1, sClobValue);
			}
			pstmt.setLong(2, id);
			pstmt.executeUpdate();
		}
		catch (SQLException sqle)
		{
			HashMap mapBindedVariables = new HashMap();
			mapBindedVariables.put("table", sTableName);
			mapBindedVariables.put("field.clob", sClobFieldName);
			mapBindedVariables.put("field.id", sIDColumnName);
			mapBindedVariables.put("id", Long.toString(id));
			mapBindedVariables.put("clob", sClobValue);

			throw new CCallableStatementException(sqle, CLobUtils.class.getName() + ".saveClobToTableByRowid()",
					sSqlStatement, mapBindedVariables);
		}
		finally
		{
			if (pstmt != null)
			{
				pstmt.close();
				pstmt = null;
			}
		}

	}

	/**
	 * Method saves given CLOB into given table's column.
	 *
	 * @param conn	open connection to database
	 * @param sTableName		Name of table where to save
	 * @param sClobFieldName	Name of field where	CLOB must be saved to
	 * @param sRowId			value of column <code>sIDColumnName</code> (usually this is id or rowid)
	 * @param sClobValue		Any String of any size (Character Large Object)
	 *
	 * @throws java.sql.SQLException	If saving failed (?)
	 */
	public static void saveClob(Connection conn, String sTableName, String sClobFieldName,
			String sRowId, String sClobValue) throws SQLException
	{
		saveClob(conn, sTableName, sClobFieldName,
				sRowId, sClobValue, false);
	}
	
	/**
	 * Method saves given CLOB into given table's column.
	 *
	 * @param conn	open connection to database
	 * @param sTableName		Name of table where to save
	 * @param sClobFieldName	Name of field where	CLOB must be saved to
	 * @param sRowId			value of column <code>sIDColumnName</code> (usually this is id or rowid)
	 * @param sClobValue		Any String of any size (Character Large Object)
	 *
	 * @throws java.sql.SQLException	If saving failed (?)
	 */
	public static void saveClob(Connection conn, String sTableName, String sClobFieldName,
		String sRowId, String sClobValue, boolean isNChar) throws SQLException
	{
		if (CStringUtils.isEmpty(sClobValue))
		{
			// NB! Shouldn't we update CLOB to NULL in table?
			return;
		}

		// Update clob using setString 
		String sSqlStatement =
			" UPDATE " + sTableName + 
			" SET " + sClobFieldName + " = ? " +
			" WHERE rowid = CHARTOROWID(?) ";
		oracle.jdbc.OraclePreparedStatement pstmt = 
			CConnectionWrapper.requireOracleStatement(
				conn.prepareStatement(sSqlStatement));

		try
		{
			if (isNChar)
			{
				pstmt.setFormOfUse(1, oracle.jdbc.OraclePreparedStatement.FORM_NCHAR);
				pstmt.setString(1, sClobValue);
			}
			else
			{
				pstmt.setStringForClob(1, sClobValue);
			}
		    pstmt.setString(2, sRowId);
		    pstmt.executeUpdate();
		    
		}
		catch (SQLException sqle)
		{
			HashMap mapBindedVariables = new HashMap();
			mapBindedVariables.put("table", sTableName);
			mapBindedVariables.put("field.clob", sClobFieldName);
			mapBindedVariables.put("rowid", sRowId);
			mapBindedVariables.put("clob", sClobValue);

			throw new CCallableStatementException(sqle, CLobUtils.class.getName() + ".saveClobToTableByRowid()",
					sSqlStatement, mapBindedVariables);
		}
		finally
		{
			if (pstmt != null)
			{
				pstmt.close();
				pstmt = null;
			}
		}
		
	}

	public static Blob createBlobLocator(Connection conn,
			String sTableName, String sColumnName,
			String sRowIdColumn, String sRowId) throws SQLException
	{
		String sSqlStatement =
				"DECLARE \n"+
				"		tmp_var BLOB;\n" +

				"BEGIN \n" +

				"	  UPDATE " + sTableName + " \n" +
				"		SET " + sColumnName + " = EMPTY_BLOB() \n"+
				"		 WHERE " + sRowIdColumn + " = CHARTOROWID(:1); \n" +

				"	  SELECT " + sColumnName + " \n" +
				"		INTO tmp_var \n"+
				"		FROM " + sTableName + " \n"+
				"	   WHERE " + sRowIdColumn + " = CHARTOROWID(:2); \n" +

				"	:3 := tmp_var; \n" +
				"END;\n";

		Blob blobLocator = null;
		CallableStatement cstmt = null;
		try
		{
			cstmt = conn.prepareCall(sSqlStatement);

			cstmt.setString(1, sRowId);
			cstmt.setString(2, sRowId);
			cstmt.registerOutParameter(3, Types.BLOB);
			cstmt.execute();
			blobLocator = cstmt.getBlob(3);
			cstmt.close();
		}
		catch (SQLException sqle)
		{
			HashMap mapBindedVariables = new HashMap();
			mapBindedVariables.put("table", sTableName);
			mapBindedVariables.put("field.blob", sColumnName);
			mapBindedVariables.put("field.rowid", sRowIdColumn);
			mapBindedVariables.put("rowid", sRowId);

			throw new CCallableStatementException(sqle, CLobUtils.class.getName() + ".createBlobLocator()",
					sSqlStatement, mapBindedVariables);
		}
		finally
		{
			if (cstmt != null)
			{
				try{
					cstmt.close();
				} catch (SQLException sqle) {}
				cstmt = null;
			}
		}
		return blobLocator;
	}



	public static String readClob(Connection conn, String sTableName, String sClobFieldName,
			String sIDColumnName, long id) throws SQLException
		{

		String sSqlStatement =
			"DECLARE\n" +
			"	tmp_var CLOB;\n" +
			"BEGIN \n" +
			"	SELECT " + sClobFieldName + " \n" +
			"	  INTO tmp_var \n"+
			"	  FROM " + sTableName + " \n"+
			"	 WHERE " + sIDColumnName + " = :1; \n" +
			"	:2 := tmp_var; \n" +
			"END;\n";

		CallableStatement cstmt = null;

		try
		{
			cstmt = conn.prepareCall(sSqlStatement);

			cstmt.setLong(1, id);
			cstmt.registerOutParameter(2, Types.CLOB);
			cstmt.execute();

			Clob clob = cstmt.getClob(1);
			return clob.getSubString(1, (int) clob.length());
		}
		catch (SQLException sqle)
		{
			throw new CCallableStatementException(sqle, CLobUtils.class.getName() + ".readClob()",
					sSqlStatement, Collections.EMPTY_MAP);
		}
        finally
        {
            try
            {
                if (cstmt != null)
                {
                    cstmt.close();
                    cstmt = null;
                }
            }
            catch (SQLException e)
            {
                //do nothing
            }
        }
		}
}
