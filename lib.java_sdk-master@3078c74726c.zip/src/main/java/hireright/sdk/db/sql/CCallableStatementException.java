/*
 * @(#)$RCSfile: CCallableStatementException.java,v $ $Revision: 1.5 $ $Date: 2008/11/21 11:32:14 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/sql/CCallableStatementException.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2006-05-10	A.Solntsev		Created new class CCallableStatementException for enhanced logging
 * 	2007-11-28	M.Suhhoruki		Added setID, getID
 */
package hireright.sdk.db.sql;

import hireright.sdk.util.CProperties;
import hireright.sdk.util.ILoggableException;

import java.sql.SQLException;
import java.util.Map;

/**
 * This is a wrapper to SQLException occurred while preparing/executing
 * java.sql.CallableStatement
 * 
 * This exception contains SQL Statement full text and binded variables,
 * as well as original SQLException.
 *  
 * @author Andrei Solntsev
 * @since java_sdk_v2-6-9
 * @version $Revision: 1.5 $ $Date: 2008/11/21 11:32:14 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/sql/CCallableStatementException.java,v $
 */
public class CCallableStatementException extends SQLException implements ILoggableException
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	private Long m_nID;
	private final String m_sSource;
	private final SQLException m_cause;
	private final String m_sSqlStatement;
	private final Map<String, ISqlValue> m_mapBindedVariables;
	private CProperties m_properties;
	
	/**
	 * Create exception with all the data useful for logging:
	 * 
	 * @param cause	A real SQL Exception that has happened
	 * @param sSource A class and method name where the exception happened
	 * @param sSqlStatement SQL statement that failed to execute. 
	 * 						Usually it looks like "DECLARE ... BEGIN ... END;"
	 * @param mapBindedVariables Map of name-value mappings that should be binded in this statement
	 */
	public CCallableStatementException(SQLException cause, String sSource, String sSqlStatement,
			Map<String, ISqlValue> mapBindedVariables)
	{
		m_cause = cause;
		m_sSource = sSource;
		m_sSqlStatement = sSqlStatement;
		m_mapBindedVariables = mapBindedVariables;
		m_properties = null; // lazy evaluation
	}

	/**
	 * Method returns a real SQL Exception that happened when tryng to execute Callable Statement. 
	 * Usually it looks like "DECLARE ... BEGIN ... END;"
	 * @return
	 */
	public SQLException getCauseSqlException()
	{
		return m_cause;
	}
	
	/**
	 * Method returns SQL statement that failed to execute. 
	 * Usually it looks like "DECLARE ... BEGIN ... END;"
	 * @return
	 */
	public String getSqlStatement()
	{
		return m_sSqlStatement;
	}

	/**
	 * Method returns map of name-value mappings that should be binded in this statement
	 * @return java.util.Map, probably empty
	 */
	public Map<String, ISqlValue> getBindedVariables()
	{
		return m_mapBindedVariables;
	}

	/**
	 * Method returns map of name-value mappings transformed into CProperties instance
	 * It's convinient for logging in LOG_TRACE.
	 */
	public CProperties toProperties() 
	{
		return getProperties();
	}

	/**
	 * Method returns the source of this exception - 
	 * a place where the exception happened.
	 * 
	 * Usually this is class name + method name and looks like this:
	 *  "hireright.object.application.CApplication.save()"
	 *  
	 * @return String
	 * @deprecated
	 */
	@Deprecated
	public String getSource()
	{
		return m_sSource;
	}
	
	public Throwable getException()
	{
		return getCauseSqlException();
	}

	/**
	 * Get properties of this CallableStatement.
	 * Properties should contain all binded variables used in statement. 
	 */
	public CProperties getProperties() 
	{
		if (m_properties == null)
		{
			// Lazy evaluation
			synchronized (this)
			{
				if (m_properties == null)
				{
					m_properties = new CProperties();
			
			
					ISqlValue sqlValue;
					for (Map.Entry<String, ISqlValue> entry : m_mapBindedVariables.entrySet())
					{
						sqlValue = entry.getValue();
						m_properties.setProperty(String.valueOf(entry.getKey()), sqlValue.getValue());
					}
				}
			}
		}
		
		return m_properties;
	}

	public String getData()
	{
		return getSqlStatement();
	}

	@Override
	public boolean equals(Object obj)
	{
		if (obj == null)
			return false;
		else if (obj == this)
			return true;
		else if (!(obj instanceof CCallableStatementException))
			return false;
		
		CCallableStatementException ex = (CCallableStatementException) obj;
		return m_cause.equals(ex.getCause()) &&
			this.m_sSqlStatement.equals(ex.getSqlStatement()) &&
			this.m_mapBindedVariables.equals(ex.getBindedVariables());
	}
		
	@Override
	public int hashCode() 
	{
		return 23*m_cause.hashCode() + 17*m_sSqlStatement.hashCode() + m_mapBindedVariables.hashCode();
	}

	// ------------------- Delegating methods --------------
    @Override
	public String getMessage()
    {
        return m_cause.getMessage();
    }
    
	@Override
	public Throwable getCause()
	{
		return (m_cause.getCause() != null ? m_cause.getCause() : m_cause);
	}	
    
	@Override
	public int getErrorCode()
	{
		return m_cause.getErrorCode();
	}

	@Override
	public String getLocalizedMessage()
	{
		return m_cause.getLocalizedMessage();
	}

	@Override
	public SQLException getNextException()
	{
		return m_cause.getNextException();
	}

	/**
	 * Get ID that was assigned in logging process.
	 * Returns null if ID is unsupported or exception has not been logged yet.
	 * @return ID of log record
	 */
	public Long getID()
	{
		return m_nID;
	}

	public void setID(Long nID)
	{
		m_nID = nID;
	}

	@Override
	public String getSQLState()
	{
		return m_cause.getSQLState();
	}

	@Override
	public String toString()
	{
		return m_cause.toString();
	}
}
