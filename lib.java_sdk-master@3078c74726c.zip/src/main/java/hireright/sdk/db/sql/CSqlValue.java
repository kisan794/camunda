/*
 * @(#)$RCSfile: CSqlValue.java,v $ $Revision: 1.7 $ $Date: 2015/11/02 20:15:32 $ $Author: cvsroot $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2005-08-23	A.Solntsev		created
 *	2006-02-02	A.Solntsev		Added file header
 *	2006-05-11	A.Solntsev		Added methods toString(), equals(), hashCode()
 *  2017-07-26	S.Sablin		Modified setValueToCallableStatement, fixed adding Long parameter
 */
package hireright.sdk.db.sql;
import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.sql.Date;

/**
 * A 'typed' value having 2 characteristics: SQL Type (varchar/numeric/int/date/lob/...) and value (java.lang.Object).
 *  
 * @author Andrei Solntsev
 * @since java_sdk_v2-5-31
 */
public class CSqlValue implements ISqlValue, Serializable
{
	private Object	m_value;
	private int		m_nSqlType;
	
	public CSqlValue(Object value, int nSqlType)
	{
		m_value = value;
		m_nSqlType = nSqlType;
	}
	
	public int getSqlType()
	{
		return m_nSqlType;
	}
	
	public Object getValue()
	{
		return m_value;
	}
	
	/**
	 * Returns true iff parameter can be set directly to CallableStatement.
	 * @throws java.sql.SQLException
	 * @return false if parameter is a big LOB and needs to be saved separately.
	 * @param index
	 * @param stmt
	 */
	public boolean setValueToCallableStatement(CallableStatement stmt, int index) throws SQLException
	{
		if (getValue() == null)
		{
			stmt.setNull(index, getSqlType());
			return true;
		}

		switch (getSqlType())
		{
			case Types.VARCHAR:
			case Types.CHAR:
				stmt.setString(index, getValue().toString());
				break;
			case Types.NUMERIC:
			case Types.REAL:
			case Types.DECIMAL:
			case Types.DOUBLE:
				stmt.setDouble(index, ((Number) getValue()).doubleValue());
				break;

			case Types.FLOAT:
				stmt.setFloat(index, ((Number) getValue()).floatValue());
				break;
				
			case Types.INTEGER:
				if( getValue() instanceof Long )
					stmt.setLong(index, (Long)getValue());
				else
					stmt.setInt(index, ((Integer) getValue()).intValue());
				break;

			case Types.DATE:
				stmt.setDate(index, (Date) getValue());
				break;

			case Types.TIMESTAMP:
				stmt.setTimestamp(index, (Timestamp) getValue());
				break;

			case Types.CLOB:
			case Types.NCLOB:
				/*String sClobValue = (String) getValue();
				if (sClobValue != null && sClobValue.length() > 32000)
				{
					stmt.setNull(index, Types.CLOB);
					return false;
				}
				stmt.setString(index, sClobValue);
				break;
				*/
				return false;

			case Types.BLOB:
				//stmt.setNull(index, Types.BLOB);
				return false;

			default:
				stmt.setString(index, getValue().toString());
				break;
		}
		
		return true;
	}

	/**
	 * @since java_sdk_v2-6-9
	 */
	public String toString()
	{
		switch (getSqlType())
		{
			case Types.VARCHAR:
			case Types.CHAR:
				return "String:" + getValue();
				
			case Types.NUMERIC:
			case Types.REAL:
			case Types.DECIMAL:
			case Types.DOUBLE:
				return "double:" + getValue();

			case Types.FLOAT:
				return "float:" + getValue();
				
			case Types.INTEGER:
				return "int:" + getValue();

			case Types.DATE:
				return "Date:" + getValue();

			case Types.TIMESTAMP:
				return "Timestamp:" + getValue();

			case Types.CLOB:
				return "Clob:" + getValue();
				
			case Types.NCLOB:
				return "NClob:" + getValue();

			case Types.BLOB:
				return "Blob:" + getValue();

			default:
				return "Type=" + getSqlType() + ":" + getValue();
		}
	}
	
	/**
	 * @since java_sdk_v2-6-9
	 */
	public boolean equals(Object obj)
	{
		if (obj == null)
			return false;
		else if (obj == this)
			return true;
		else if (!(obj instanceof ISqlValue))
			return false;
		
		ISqlValue val = (ISqlValue) obj;
		if (val.getSqlType() != this.getSqlType())
			return false;
		
		return (val.getValue() == null && this.getValue() == null) ||
			   (val.getValue() != null && val.getValue().equals(this.getValue()));
	}
	
	/**
	 * @since java_sdk_v2-6-9
	 */
	public int hashCode()
	{
		return getSqlType() + 37 * 
			(getValue() == null ? 0 : getValue().hashCode()); 
	}
}