/*
 * @(#)$RCSfile: CSqlCommands.java,v $ $Revision: 1.9 $ $Date: 2010/02/04 21:16:58 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/sql/CSqlCommands.java,v $
 *
 * Copyright 2005-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev		2005-08-23	created
 *	A.Solntsev		2006-11-01	Method select() return Serializable instead of Object
 *	A.Solntsev		2008-10-24	Added methods closeSilently(), executeStatement() (currently used in unit-tests)
 *	A.Solntsev		2008-10-24	Added methods without Connection parameter which return Number instead of BigDecimal
 *	A.Solntsev		2010-01-20	Code has been simplified using Java5 generics
 */
package hireright.sdk.db.sql;
import hireright.sdk.db.CCurrentThreadConnection;
import hireright.sdk.db.CSQLWhereConstructor;
import hireright.sdk.db.CSQLWhereFilter;
import hireright.sdk.db.RuntimeSqlException;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

/**
 * Wrapper for simple SQL commands like "SELECT MAX", "SELECT MIN", "SELECT AVG"
 *  
 * @author Andrei Solntsev
 * @since August 2005
 * @version $Revision: 1.9 $ $Date: 2010/02/04 21:16:58 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/sql/CSqlCommands.java,v $
 */
public class CSqlCommands implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	/**
	 * Use only static methods
	 */
	private CSqlCommands()
	{
	}

	public static void closeSilently(Statement stmt)
	{
		if (stmt != null)
		{
			try{ stmt.close(); } catch (SQLException sqle) {}
		}
	}
	
	public static void closeSilently(ResultSet rs)
	{
		if (rs != null)
		{
			try{ rs.close(); } catch (SQLException sqle) {}
		}
	}
	
	public static void executeStatement(final String sSqlStatement) throws SQLException
	{
		final Connection conn = CCurrentThreadConnection.getConnection();
		final Statement stmt = conn.createStatement();
		try
		{
			stmt.executeUpdate(sSqlStatement);
		}
		catch (SQLException e)
		{
			Logger.getLogger( CSqlCommands.class ).error( "Error while executing SQL '" + sSqlStatement + "'", e );
			throw e;
		}
		finally
		{
			closeSilently(stmt);
		}
	}

	public static Serializable select(String sColumn,
			String fromTable, CSQLWhereFilter sqlFilter)
	{
		Connection conn = CCurrentThreadConnection.getConnection();
		return select(conn, sColumn, fromTable, sqlFilter);
	}
	
	public static Serializable select(Connection conn, String sColumn,
			String fromTable, CSQLWhereFilter sqlFilter)
	{
		return selectFrom(conn, sColumn, fromTable, sqlFilter);
	}

	public static <T> T selectFrom(String sColumn,
			String fromTable, CSQLWhereFilter sqlFilter)
	{
		Connection conn = CCurrentThreadConnection.getConnection();
		return (T) selectFrom(conn, sColumn, fromTable, sqlFilter);
	}
	
	/**
	 * 
	 * @param conn
	 * @param sColumn
	 * @param fromTable
	 * @param sqlFilter
	 * @return Typically method returns String, Date or Number 
	 * @throws SQLException
	 */
	@SuppressWarnings("unchecked")
	public static <T> T selectFrom(Connection conn, String sColumn,
		String fromTable, CSQLWhereFilter sqlFilter)
	{
		StringBuffer sb = new StringBuffer()
			.append("SELECT ").append(sColumn)
			.append("  FROM ").append(fromTable);
		
		if (!sqlFilter.isEmpty())
			sb.append(" WHERE ").append(sqlFilter.getSqlClause());

		try
		{
			final PreparedStatement pstmt = sqlFilter.prepareStatement(conn, sb.toString());
			try
			{
				final ResultSet rst = pstmt.executeQuery();
				
				try
				{
					if (rst.next())
					{
						Object result = rst.getObject(1);
						if (rst.wasNull())
							result = null;
						
						return (T) result;
					}
				}
				finally
				{
					closeSilently( rst );
				}
			}
			finally
			{
				closeSilently( pstmt );
			}
		}
		catch (SQLException e)
		{
			throw new RuntimeSqlException( e );				  
		}
		
		return null;
	}

	/**
	 * @deprecated Use method without java.sql.Connection parameter
	 * @param conn NOT USED
	 * @param sColumn
	 * @param fromTable
	 * @param filter
	 * @return Typically method returns String, Date or Number
	 * @throws SQLException
	 */
	@Deprecated
	public static Serializable select(Connection conn, String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		CSQLWhereFilter sqlFilter = filter.build();
		return select(conn, sColumn,fromTable, sqlFilter);
	}
	
	public static <T> T selectFrom(String sColumn,
			String fromTable, CSQLWhereConstructor filter)
		{
			CSQLWhereFilter sqlFilter = filter.build();
			return (T) selectFrom(sColumn,fromTable, sqlFilter);
		}
	
	/**
	 * @param sColumn
	 * @param fromTable
	 * @param filter
	 * @return Typically method returns String, Date or Number
	 * @throws SQLException
	 */
	public static Serializable select(String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		CSQLWhereFilter sqlFilter = filter.build();
		return select(sColumn, fromTable, sqlFilter);
	}
	
	@Deprecated
	public static long count(@SuppressWarnings("unused") Connection conn, String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		Number result = (Number) selectFrom("COUNT(" + sColumn + ")", fromTable, filter);
		return result.longValue();
	}

	public static long count(String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		Number result = selectFrom("COUNT(" + sColumn + ")", fromTable, filter);
		return result.longValue();
	}

	@Deprecated
	public static long count(@SuppressWarnings("unused") Connection conn, String fromTable,
		CSQLWhereConstructor filter)
	{
		Number result = (Number) selectFrom("COUNT(*)", fromTable, filter);
		return result.longValue();
	}

	public static long count(String fromTable,
		CSQLWhereConstructor filter)
	{
		Number result = selectFrom("COUNT(*)", fromTable, filter);
		return result.longValue();
	}
	
	@Deprecated
	public static long count(@SuppressWarnings("unused") Connection conn, String fromTable)
	{
		Number result = selectFrom("COUNT(*)", fromTable, CSQLWhereConstructor.ALL);
		return result.longValue();
	}

	public static long count(String fromTable)
	{
		Number result = selectFrom("COUNT(*)", fromTable, CSQLWhereConstructor.ALL);
		return result.longValue();
	}
	
	@Deprecated
	public static BigDecimal min(@SuppressWarnings("unused") Connection conn, String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		return selectFrom("MIN(" + sColumn + ")", fromTable, filter);
	}

	public static Number min(String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		return selectFrom("MIN(" + sColumn + ")", fromTable, filter);
	}

	@Deprecated
	public static BigDecimal min(@SuppressWarnings("unused") Connection conn, String sColumn,
		String fromTable)
	{
		return selectFrom("MIN(" + sColumn + ")", fromTable, CSQLWhereConstructor.ALL);
	}

	/**
	 * @return null if no records found
	 * @throws SQLException
	 */
	public static Number min( String sColumn, String fromTable)
	{
		return selectFrom("MIN(" + sColumn + ")", fromTable, CSQLWhereConstructor.ALL);
	}

	@Deprecated
	public static BigDecimal max(@SuppressWarnings("unused") Connection conn, String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		return selectFrom("MAX(" + sColumn + ")", fromTable, filter);
	}

	/**
	 * @return null if no records found
	 * @throws SQLException
	 */
	public static Number max(String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		return selectFrom("MAX(" + sColumn + ")", fromTable, filter);
	}

	@Deprecated
	public static BigDecimal max(@SuppressWarnings("unused") Connection conn, String sColumn, String fromTable)
	{
		return selectFrom("MAX(" + sColumn + ")", fromTable, CSQLWhereConstructor.ALL);
	}

	/**
	 * @return null if no records found
	 * @throws SQLException
	 */
	public static Number max(String sColumn, String fromTable)
	{
		return selectFrom("MAX(" + sColumn + ")", fromTable, CSQLWhereConstructor.ALL);
	}

	@Deprecated
	public static BigDecimal average(@SuppressWarnings("unused") Connection conn, String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		return selectFrom("AVG(" + sColumn + ")", fromTable, filter);
	}

	/**
	 * @return null if no records found
	 * @throws SQLException
	 */
	public static Number average(String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		return selectFrom("AVG(" + sColumn + ")", fromTable, filter);
	}

	@Deprecated
	public static BigDecimal average(@SuppressWarnings("unused") Connection conn, String sColumn,
		String fromTable)
	{
		return selectFrom("AVG(" + sColumn + ")", fromTable, CSQLWhereConstructor.ALL);
	}

	/**
	 * @return null if no records found
	 * @throws SQLException
	 */
	public static Number average(String sColumn, String fromTable)
	{
		return selectFrom("AVG(" + sColumn + ")", fromTable, CSQLWhereConstructor.ALL);
	}

	@Deprecated
	public static BigDecimal sum(@SuppressWarnings("unused") Connection conn, String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		return selectFrom("NVL(SUM(" + sColumn + "), 0)", fromTable, filter);
	}

	public static Number sum(String sColumn,
		String fromTable, CSQLWhereConstructor filter)
	{
		return selectFrom("NVL(SUM(" + sColumn + "), 0)", fromTable, filter);
	}

	@Deprecated
	public static BigDecimal sum(Connection conn, String sColumn,
		String fromTable)
	{
		return sum(conn, sColumn, fromTable, CSQLWhereConstructor.ALL);
	}
	
	public static Number sum(String sColumn, String fromTable)
	{
		return sum(sColumn, fromTable, CSQLWhereConstructor.ALL);
	}
}