/*
 * @(#)$RCSfile: CRevalidatedConnection.java,v $ $Revision: 1.3 $ $Date: 2015/03/28 08:37:33 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CRevalidatedConnection.java,v $
 *
 * Copyright 2012 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  M. Suhhoruki		2014-05-08 created
 *  
 */
package hireright.sdk.db;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

/**
 * Factory for {@link hireright.sdk.db.CRevalidatedStatement}
 * 
 * @author msuhhoruki
 * @since java_sdk_v3-57
 */
public class CRevalidatedConnection extends CAbstractConnectionProxy
{
	public CRevalidatedConnection(Connection conn)
	{
		super(conn);
	}
	
	@Override
	public Object invoke(Object proxy, Method m, Object[] args)
		throws Throwable
	{
		Object result = null;
		try
		{
			result = m.invoke(getDelegate(), args);
			
			// wrap statements
			if ("prepareStatement".equals(m.getName()))
			{
				result = CRevalidatedStatement.create((PreparedStatement) result);
			}
			else if ("prepareCall".equals(m.getName()))
			{
				result = CRevalidatedStatement.create((CallableStatement) result);
			}
			else if ("createStatement".equals(m.getName()))
			{
				result = CRevalidatedStatement.create((Statement) result);
			}
		}
		catch (InvocationTargetException e)
		{
			Throwable cause = e.getTargetException();
			throw (cause != null) ? cause : e;
		}
		
		return result;
	}
	
	public static Connection create(Connection originalStatement)
	{
		CRevalidatedConnection stmt = new CRevalidatedConnection(originalStatement);
		
		return (Connection) Proxy.newProxyInstance(
				stmt.getClass().getClassLoader(),
				new Class<?>[] {Connection.class},
				stmt);
	}
}
