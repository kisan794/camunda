/*
 * @(#)$RCSfile: NonClosableConnection.java,v $Revision: 1.4 $ $Date: 2010/03/11 21:42:22 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/NonClosableConnection.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2008-09-16	Extracted from CSingleCommitController to a separate class
 *  A.Solntsev			2010-03-05	Use Proxy instead of CConnectionWrapper
 */
package hireright.sdk.db;

import hireright.sdk.util.FirewallProxy;

import java.sql.Connection;
import java.util.Arrays;

/**
 * Wrapper for java.sql.Connection which doesn't allo classes to close, commit or rollback this connection.
 *
 * @author Andrei Solntsev
 * @version $Revision: 1.4 $ $Date: 2010/03/11 21:42:22 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/NonClosableConnection.java,v $
 */
public class NonClosableConnection
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	public static Connection wrap(Connection connection)
	{
		return FirewallProxy.createProxy( connection, Connection.class, 
				Arrays.asList( "close", "commit", "rollback", "setAutoCommit" ) );
	}
}
