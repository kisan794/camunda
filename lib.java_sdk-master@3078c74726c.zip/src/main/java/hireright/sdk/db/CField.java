/*
 * @(#)$RCSfile: CField.java,v $ $Revision: 1.22 $ $Date: 2010/06/17 21:01:05 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CField.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov			2003-10-13	added CDBRuntimeException raising
 *	A.Solntsev		2005-08-17	Redesign
 *	A.Solntsev		2005-12-03	Added method getBlobContent().
 *	A.Solntsev		2006-04-06	implements Serializable
 *	A.Solntsev		2006-06-08	More strict checking of column types
 *	A.Solntsev		2006-09-01	Quickfix: method getExpression() is protected again
 *	A.Solntsev		2006-11-01	Methods setInteger(), setString() are public now
 *	A.Solntsev		2008-11-18	Performance improvements: all fields made final, setters removed.
 *								Added members m_sExpression, m_sExpressionUpper for re-using those values.
 *	A.Solntsev		2009-05-05	Added method isRowId()
 *	A.Solntsev		2009-07-09	Added methods getLongValue(), getNumericValue(), getCharValue(), setNumber(), setLong()
 *	A.Solntsev		2009-07-09	warnings replaced by errors
 *	A.Solntsev		2009-11-04	Method isChanged() has been made public (for using in unit tests)
 *	I.Lopatukhin		2010-06-03	NCHAR support added 
 */
package hireright.sdk.db;

import hireright.sdk.db.fields.CColumnMetaData;
import hireright.sdk.db.fields.CUnsupportedColumnType;
import hireright.sdk.db.sql.IField;
import hireright.sdk.db.sql.ISqlValue;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.IHasProperties;

import java.io.Serializable;
import java.sql.*;

/**
 * Package-private class implements a single column of relational database table.
 * Each column has a name, type, table name and value.
 * Class has a set of abstract methods for different data types.
 *
 * There are 4 known implementations (subclasses) of this class:
 * 	1. CStringField
 *  2. CIntegerField
 *  3. CNumericField
 *  4. CDateField
 *  5. CClobField
 *  6. CBlobField
 *
 * @author	Sergei Ignatov
 * @date		2001-11-14
 */
public abstract class CField implements IField, ISqlValue, Serializable, IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.22 $ $Author: cvsroot $";

	/**
	 * @serial
	 */
	private final CColumnMetaData m_columnMetaData;

	private final String m_sTableName;
	private final String m_sTableNameUpper;
	private final String m_sExpression;
	private final String m_sExpressionUpper;

	private final String			m_szDefaultValue;
	private final boolean m_isReadOnly;
	// private final boolean m_isAggregate;
	private boolean m_boolChanged;
	private boolean m_boolActive = true;

	/**
	 *	Constructor for new empty field
	 */
	protected CField(CColumnMetaData columnMetaData, String sTableName)
	{
		this(columnMetaData, sTableName, false, true);
	}

	/**
	 *	Constructor for new empty field
	 */
	protected CField(CColumnMetaData columnMetaData, String sTableName, boolean bReadOnly, boolean isActive)
	{
		assert sTableName != null : "Table name is null";

		m_columnMetaData = columnMetaData;
		m_boolChanged = false;
		m_sTableName = sTableName;
		m_sTableNameUpper = sTableName.toUpperCase();
		m_isReadOnly = bReadOnly;
		m_boolActive = isActive;
		m_szDefaultValue = null; // always null?
		// m_isAggregate = false; // always false?

		// Initialize "expression" and "expressionUpper"
		m_sExpression = (m_sTableName == null) ? getName() : m_sTableName + '.' + getName();
		m_sExpressionUpper = m_sExpression.toUpperCase();
	}

	public boolean isReadOnly()
	{
		return m_isReadOnly;
	}

	public boolean isRowId()
	{
		return false;
	}

	public int getScale()
	{
		return m_columnMetaData.getScale();
	}

	public String getColumnName()
	{
		return m_columnMetaData.getColumnName();
	}

	public String getName()
	{
		return m_columnMetaData.getColumnName();
	}

	public String getNameUpper()
	{
		return m_columnMetaData.getColumnNameUpper();
	}

	/**
	 * Method always returns true, because field can be 'not nullable', but have default value.
	 * @return true if column is not nullable (however, it can have default value)
	 */
	public boolean isNullable()
	{
		return m_columnMetaData.isNullable();
	}

	public int getLength()
	{
		return m_columnMetaData.getColumnDisplaySize();
	}

	public int getDetType()
	{
		return m_columnMetaData.getColumnType();
	}

	public int getSqlType()
	{
		return m_columnMetaData.getColumnType();
	}

	public ISqlValue getSqlValue()
	{
		return this;
	}

	public boolean isNChar() 
	{
		return m_columnMetaData.isNChar();
	}
	
	/**
	 *	COMMENT ME
	 */
	protected abstract void setParamToPrepStatement(PreparedStatement  pstmt, int nIndex) throws SQLException;

	/**
	 * Method returns true if this column was changed since last read/write operation.
	 * So, this column needs to be saved to database.
	 *
	 * @return true/false
	 */
	public final boolean isChanged()
	{
		return m_boolChanged;
	}

	/**
	 * Method returns true iff column has null-value
	 * @return true/false
	 */
	protected final boolean isNull()
	{
		return (null == getValue());
	}

	/**
	 * Abstract method returns value of this field.
	 * This can be instance of String, Integer, Float, Double, Date, Clob, Blob
	 * depending on type of column.
	 *
	 * @return null if column has null-value
	 */
	public abstract Object getValue();

	protected Number getNumericValue()
	{
		if (getValue() == null)
			return null;
		else if (getValue() instanceof Number)
			return (Number) getValue();
		else
		{
			throw new IllegalArgumentException("Reading numeric value from non-numeric " + toString());
		}
	}
	
	/**
	 * Method tries to transform this field's value to Integer.
	 * @return Integer
	 *
	 * @throws NumberFormatException if this column is not of INTEGER type and contains non-numeric data
	 */
	protected Integer getIntegerValue()
	{
		if (getValue() == null)
			return null;
		else if (getValue() instanceof Integer)
			return (Integer) getValue();
		else if (getValue() instanceof Number)
			return Integer.valueOf( ((Number) getValue()).intValue() );
		else
		{
			CTraceLog.error("Reading Integer from non-numeric column",
				getClass().getName() + ".getIntegerValue()", toProperties());

			return Integer.valueOf(getValue().toString());
		}
	}
	
	protected Long getLongValue()
	{
		if (getValue() == null)
			return null;
		else if (getValue() instanceof Long)
			return (Long) getValue();
		else if (getValue() instanceof Number)
			return Long.valueOf( ((Number) getValue()).longValue() );
		else
		{
			throw new IllegalArgumentException("Reading Long value from non-numeric " + toString());
		}
	}

	/**
	 * Method tries to transform this field's value to Double.
	 * @return Double
	 *
	 * @throws NumberFormatException if this column is not of NUMERIC type and contains non-numeric data
	 */
	protected Double getDoubleValue()
	{
		if (getValue() == null)
			return null;
		else if (getValue() instanceof Double)
			return (Double) getValue();
		else if (getValue() instanceof Number)
			return Double.valueOf( ((Number) getValue()).doubleValue() );
		else
		{
			CTraceLog.error("Reading Double from non-numeric column",
				getClass().getName() + ".getDoubleValue()", toProperties());

			return Double.valueOf(getValue().toString());
		}
	}

	/**
	 * Method tries to transform this field's value to Float.
	 * @return Float
	 *
	 * @throws NumberFormatException if this column is not of NUMERIC type and contains non-numeric data
	 */
	protected Float getFloatValue()
	{
		if (getValue() == null)
			return null;
		else if (getValue() instanceof Float)
			return (Float) getValue();
		else if (getValue() instanceof Number)
			return Float.valueOf( ((Number) getValue()).floatValue() );
		else
		{
			CTraceLog.error("Reading Float from non-numeric column",
				getClass().getName() + ".getFloatValue()", toProperties());

			return Float.valueOf(getValue().toString());
		}
	}

	/**
	 * Method should be overridden in those subclasses which contain Date value
	 * @return java.util.Date
	 *
	 * @throws CUnsupportedColumnType for non-Date columns
	 */
	protected java.util.Date getDateValue()
	{
		throw new CUnsupportedColumnType("Cannot read Date from non-Date column",
				getClass().getName() + ".getDateValue()", toProperties());
	}

	/**
	 * Method should be overridden in those subclasses which contain Date value
	 * @return java.sql.Date
	 *
	 * @throws CUnsupportedColumnType for non-Date columns
	 */
	protected java.sql.Date getSQLDateValue()
	{
		throw new CUnsupportedColumnType("Cannot read Date from non-Date column",
				getClass().getName() + ".getSQLDateValue()", toProperties());
	}

	/**
	 * Method should be overridden in those subclasses which contain Date value
	 * @return java.sql.Timestamp
	 *
	 * @throws CUnsupportedColumnType for non-Date columns
	 */
	protected java.sql.Timestamp getTimestampValue()
	{
		throw new CUnsupportedColumnType("Cannot read Timestamp from non-Timestamp column",
				getClass().getName() + ".getTimestampValue()", toProperties());
	}

	/**
	 * Method returns Clob locator on this column.
	 * Method should be overridden in those subclasses which contain CLOB value
	 *
	 * @throws CUnsupportedColumnType	if this column is not of type java.sql.Types.Clob
	 * @return instance of java.sql.Clob
	 */
	protected java.sql.Clob getClobValue()
	{
		throw new CUnsupportedColumnType("Cannot read Clob from non-Clob column",
				getClass().getName() + ".getClobValue()", toProperties());
	}

	/**
	 * Method should be overridden in those subclasses which contain BLOB value
	 *
	 * @param conn
	 * @param sTableName
	 * @param sRowIdColumn
	 * @param sRowId
	 * @return java.sql.Blob
	 *
	 * @throws CUnsupportedColumnType	for non-BLOB columns
	 */
	public Blob createBlobLocator(Connection conn, String sTableName, String sRowIdColumn, String sRowId)
	{
		throw new CUnsupportedColumnType("Cannot create BLOB locator on non-Blob column",
				getClass().getName() + ".createBlobLocator()",
				toProperties()
					.setProperty("db.url", CConnection.getUrl(conn))
					.setProperty("sTableName", sTableName)
					.setProperty("sRowIdColumn", sRowIdColumn)
					.setProperty("sRowId", sRowId));
	}

	/**
	 * Method should be overridden in those subclasses which contain BLOB value
	 * @return java.sql.Blob
	 *
	 * @throws CUnsupportedColumnType	for non-BLOB columns
	 */
	public Blob getBlobLocator()
	{
		throw new CUnsupportedColumnType("Cannot get BLOB locator on non-Blob column",
				getClass().getName() + ".getBlobLocator()", toProperties());
	}

	/**
	 * Method should be overridden in those subclasses which contain CLOB value
	 * @return java.sql.Clob
	 *
	 * @throws CUnsupportedColumnType	for non-CLOB columns
	 */
	public Clob getClobLocator()
	{
		throw new CUnsupportedColumnType("Cannot get CLOB locator on non-Clob column",
				getClass().getName() + ".getClobLocator()", toProperties());
	}

	/**
	 * Method returns Blob locator on this column.
	 * Method should be overridden in those subclasses which contain BLOB value
	 *
	 * @throws CUnsupportedColumnType	for non-BLOB columns
	 * @return instance of java.sql.Blob
	 */
	protected java.sql.Blob getBlobValue() throws UnsupportedOperationException
	{
		throw new CUnsupportedColumnType("Cannot read Blob from non-Blob column",
				getClass().getName() + ".getBlobValue()", toProperties());
	}

	/**
	 * Method returns binary content of this column (if it's of BLOB type).
	 * Method should be overridden in those subclasses which contain Date value
	 *
	 * @return array of bytes
	 * @throws CUnsupportedColumnType	for non-BLOB columns
	 * @throws SQLException	if error occurred during reading BLOB content (thrown by subclasses)
	 *
	 * see hireright.sdk.db.fields.CBLOBField#getBlobContent()
	 */
	@SuppressWarnings("unused")
	protected byte[] getBlobContent() throws SQLException
	{
		throw new CUnsupportedColumnType("Cannot read binary from non-Blob column",
				getClass().getName() + ".getBlobContent()", toProperties());
	}

	/**
	 * Method returns String-representation of this column's value.
	 * @return null if column has null-value
	 */
	protected String getStringValue()
	{
		Object value = getValue();
		return (value == null) ? null : value.toString();
	}
	
	protected Character getCharValue()
	{
		Object value = getValue();
		if (value == null) 
			return null;
		String s = value.toString();
		if (s.length() == 0)
			return null;
		else if (s.length() > 1)
			throw new IllegalArgumentException("Char value is longer than 1 character: " + s);
		return Character.valueOf( s.charAt(0) );
	}

	/**
	 * Method returns true iff column contains one of following string:
	 * "Y", "YES", "T", "TRUE"
	 * @return Boolean.True or Boolean.False
	 */
	protected final Boolean getBooleanValue()
	{
		String sValue = getStringValue().toUpperCase();

		// TODO	Change to Boolean.valueOf() when we migrate to J2SDK >= 1.4
		if (	"Y".equals(sValue) ||
				"YES".equals(sValue) ||
				"T".equals(sValue) ||
				"TRUE".equals(sValue))
			return Boolean.TRUE;
		else
			return Boolean.FALSE;
	}



	// --- Helper for setters ---
	/**
	 * If new value is not the same as old value, set `changed` attribute to true.
	 *
	 * @param oldValue	current value of this column
	 * @param	newValue	new value for this column
	 */
	protected void setChanged(Object oldValue, Object newValue)
	{
		boolean isChanged = false;
		if (newValue == null)
			isChanged = (oldValue != null);
		else if (oldValue == null)
			isChanged = true;
		//else if (oldValue instanceof Integer && newValue instanceof Integer)
		//	isChanged = !newValue.equals(oldValue);
		else
		{
			// isChanged = !newValue.equals(oldValue);
			isChanged = !isEqual(oldValue, newValue);
		}

		if (isChanged)
			setChanged(true);
	}
	
	/**
	 * Checks 2 values for equality. Both are not null.
	 * @param oldValue
	 * @param newValue
	 * @return
	 */
	protected boolean isEqual(Object oldValue, Object newValue)
	{
		return newValue.equals(oldValue);
	}

	public boolean setBoolean(Boolean boolValue)
	{
		return setString( boolValue.booleanValue()? "Y" : "N");
	}

	public boolean setBoolean(boolean boolValue)
	{
		return setString( boolValue? "Y" : "N");
	}

	// --- Setters to be overridden in subclasses---

	/**
	 * Method should be overridden in those subclasses which support String value
	 * @param szValue
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support String values
	 */
	public boolean setString(String szValue)
	{
		throw new CUnsupportedColumnType("Cannot set String value to non-string column",
				getClass().getName() + ".setString()", toProperties().setProperty("assignedValue", szValue));
	}
	
	/**
	 * Applicable for columns of type CHAR(1).
	 * 
	 * @param charValue
	 * @return
	 */
	public boolean setCharValue(Character charValue)
	{
		throw new CUnsupportedColumnType("Cannot set Character value to non-string column",
				getClass().getName() + ".setString()", toProperties().setProperty("assignedValue", charValue));
	}
	
	/**
	 * Applicable for columns of type CHAR(1).
	 * @param charValue
	 * @return
	 */
	public boolean setCharValue(char charValue)
	{
		throw new CUnsupportedColumnType("Cannot set Character value to non-string column",
				getClass().getName() + ".setString()", toProperties().setProperty("assignedValue", charValue));
	}

	/**
	 * Method should be overridden in those subclasses which support String value
	 * @param value
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support String values
	 */
	protected boolean setBlob(byte[] value)
	{
		throw new CUnsupportedColumnType("Cannot set Blob content to non-Blob column",
				getClass().getName() + ".setBlob()", toProperties().setProperty("assignedValue", value));
	}

	/**
	 * Method should be overridden in those subclasses which support Date value
	 * @param dateValue
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support Date values
	 */
	public boolean setDate(java.sql.Date dateValue)
	{
		throw new CUnsupportedColumnType("Cannot set Date to non-Date column",
				getClass().getName() + ".setDate()", toProperties().setProperty("assignedValue", dateValue));
	}

	protected boolean setNumber(Number numericValue)
	{
		throw new CUnsupportedColumnType("Cannot set Number to non-numeric column",
				getClass().getName() + ".setNumber()", toProperties().setProperty("assignedValue", numericValue));
	}
	
	/**
	 * @deprecated Use method {@link #setDouble(Double)}
	 * @param fValue
	 * @return
	 */
	@Deprecated
	protected boolean setNumber(Double fValue)
	{
		throw new CUnsupportedColumnType("Cannot set Double to non-numeric column",
				getClass().getName() + ".setNumber()", toProperties().setProperty("assignedValue", fValue));
	}
	
	/**
	 * Method should be overridden in those subclasses which support Double value
	 * @param fValue
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support Double values
	 */
	protected boolean setDouble(Double fValue)
	{
		throw new CUnsupportedColumnType("Cannot set Double to non-numeric column",
				getClass().getName() + ".setNumber()", toProperties().setProperty("assignedValue", fValue));
	}
	
	protected boolean setLong(Long lValue)
	{
		throw new CUnsupportedColumnType("Cannot set Long to non-numeric column",
				getClass().getName() + ".setLong()", toProperties().setProperty("assignedValue", lValue));
	}
	
	protected boolean setLong(long lValue)
	{
		throw new CUnsupportedColumnType("Cannot set Long to non-numeric column",
				getClass().getName() + ".setLong()", toProperties().setProperty("assignedValue", lValue));
	}

	
	/**
	 * Method should be overridden in those subclasses which support Float value
	 * @param fValue
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support Float values
	 */
	public boolean setFloat(Float fValue)
	{
		throw new CUnsupportedColumnType("Cannot set Float value to non-numeric column",
				getClass().getName() + ".setFloat()", toProperties().setProperty("assignedValue", fValue));
	}

	/**
	 * Method should be overridden in those subclasses which support Float value
	 * @param fValue
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support Float values
	 */
	protected boolean setFloat(float fValue)
	{
		throw new CUnsupportedColumnType("Cannot set Float value to non-numeric column",
			getClass().getName() + ".setFloat()", toProperties().setProperty("assignedValue", fValue));
	}

	/**
	 * Method should be overridden in those subclasses which support Integer value
	 * @param nValue
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support Integer values
	 */
	public boolean setInteger(Integer nValue)
	{
		throw new CUnsupportedColumnType("Cannot set Integer value to non-numeric column",
			getClass().getName() + ".setInteger()", toProperties().setProperty("assignedValue", nValue));
	}

	/**
	 * Method should be overridden in those subclasses which support Integer value
	 * @param nValue
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support Integer values
	 */
	public boolean setInteger(int nValue)
	{
		throw new CUnsupportedColumnType("Cannot set Integer value to non-numeric column",
			getClass().getName() + ".setInteger()", toProperties().setProperty("assignedValue", nValue));
	}

	/**
	 * Method should be overridden in those subclasses which support Date value
	 * @param dateValue
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support Date values
	 */
	public boolean setDate(java.util.Date dateValue)
	{
		throw new CUnsupportedColumnType("Cannot set Date value to non-Date column",
			getClass().getName() + ".setDate()", toProperties().setProperty("assignedValue", dateValue));
	}

	/**
	 * Method should be overridden in those subclasses which support Clob value
	 * @param sClobValue
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support Clob values
	 */
	public boolean setClob(String sClobValue)
	{
		throw new CUnsupportedColumnType("Cannot set Clob value to non-Clob column",
			getClass().getName() + ".setClob()", toProperties().setProperty("assignedValue", sClobValue));
	}

	/**
	 * Method should be overridden in those subclasses which support Clob value
	 * @param blobLocator
	 * @return false if setting failed
	 *
	 * @throws CUnsupportedColumnType	for columns that don't support blob values
	 */
	public boolean setBlob(Blob blobLocator)
	{
		throw new CUnsupportedColumnType("Cannot set Blob value to non-Blob column",
			getClass().getName() + ".setBlob()", toProperties().setProperty("assignedValue", blobLocator));
	}

	protected String getDataDefault()
	{
		return m_szDefaultValue;
	}

	protected abstract void setNull();

	@Override
	public String toString()
	{
		return "Column " + getTableName() + "." + getName() + " = " + getStringValue();
	}

	/**
	 * Method sets this field value into given CallableStatement.
	 * @param pstmt
	 * @param nIndex
	 * @return  false if setting value failed (when it happens?)
	 * @throws SQLException
	 */
	public abstract boolean setValueToCallableStatement(
		CallableStatement pstmt, int nIndex) throws SQLException;

	protected final String getTableName()
	{
		return m_sTableName;
	}

	protected String getTableNameUpper()
	{
		return m_sTableNameUpper;
	}

	public abstract void setFromRecordSet(ResultSet rst, int nIndex);

	public void setChanged(boolean param)
	{
		m_boolChanged = param;
	}

	/**
	 * NB! This method should be protected (not private or package private!),
	 * because it's overridden in subclasses which are located in another package.
	 *
	 * see hireright.sdk.db.fields.CRowidField
	 *
	 * @return comment me
	 */
	protected String getExpression()
	{
		return m_sExpression;
	}

	protected String getExpressionUpper()
	{
		return m_sExpressionUpper;
	}

	boolean isActive()
	{
		return m_boolActive;
	}

	void setActive(boolean value)
	{
		m_boolActive = value;
	}

	// === deprecated methods. Used in integrations ===
	/**
	 * @param value
	 * @return false if setting value failed (when it happens?)
	 * @deprecated	Use method setString(value);
	 */
	public boolean setValue(String value)
	{
		return setString(value);
	}

	/**
	 * @param value
	 * @return false if setting value failed (when it happens?)
	 * @deprecated	Use method setInteger(value);
	 */
	public boolean setValue(Integer value)
	{
		return setInteger(value);
	}

	/**
	 * @param value
	 * @return false if setting value failed (when it happens?)
	 * @deprecated	Use method setFloat(value);
	 */
	public boolean setValue(Float value)
	{
		return setFloat(value);
	}

	/**
	 * @param value
	 * @return false if setting value failed (when it happens?)
	 * @deprecated	Use method setDate(value);
	 */
	public boolean setValue(java.util.Date value)
	{
		return setDate(value);
	}

	/**
	 * @param value
	 * @return false if setting value failed (when it happens?)
	 * @deprecated	Use method setBoolean(value);
	 */
	public boolean setValue(Boolean value)
	{
		return setBoolean(value);
	}

	public CProperties toProperties()
	{
		return new CProperties()
			.setProperties(m_columnMetaData.toProperties())
			.setProperty("name", getTableName() + "." + getColumnName())
			.setProperty("value", getValue())
			.setProperty("isChanged", isChanged())
			.setProperty("isNull", isNull());
	}
}
