/*
 * @(#)$RCSfile: CReportsConnection.java,v $ $Revision: 1.4 $ $Date: 2007/09/14 08:55:22 $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 * 
 * History:
 *	D.Bogdel		2004-XX-XX	Created
 *	M.Abdulganejev	2006-02-15	java_sdk_v2-6-6: com.evermind.sql.DriverManagerDataSource package import removed
 */

package hireright.sdk.db;

import java.sql.*;
import javax.naming.*;
import javax.sql.*;
import oracle.jdbc.*;
import hireright.sdk.debug.CFileLog;

public class CReportsConnection
{
	public CReportsConnection() //Constructor is public just for compatibility purposes. All methods are static so no need in object instances of this class
	{
	}

	public static Connection getConnection()
	{
		Connection conn = null;
		
		try
		{
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("jdbc/HireRightReportsJDS");
			conn = ds.getConnection();
			conn.setAutoCommit(false);
		}
		catch(Exception e)
		{
			CFileLog.insert(e, "ConnectionException.log");
			conn = null;
		}
		return conn;
	}
	
	public static Connection closeConnection(Connection conn)
	{
		try
		{
			conn.close();
		}
		catch(Exception e)
		{
			
		}
		finally
		{
			conn = null;	
		}
		return conn;
	}
}