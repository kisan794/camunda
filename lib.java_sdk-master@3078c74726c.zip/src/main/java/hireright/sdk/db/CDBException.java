/*
 * @(#)$RCSfile: CDBException.java,v $ $Revision: 1.8 $ $Date: 2008/02/21 21:54:48 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CDBException.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2002-10-08	S.Ignatov		Created
 *  2002-12-21	S.Ignatov		logging extended
 *  2003-02-06	A.Keks			bugfixing
 *  2003-02-26	S.Ignatov		add to source "hireright.sdk.db." if not starts
 *  2005-08-16	A.Solntsev		Class CStackTrace is used for logging.
 *  2006-06-08	A.Solntsev		More smart logging with properties and exception cause
 *  2008-02-18	A.Solntsev		Added more constructors
 */
package hireright.sdk.db;

import hireright.sdk.debug.CStackTrace;
import java.sql.*;

import hireright.sdk.util.CException;
import hireright.sdk.util.CProperties;
import hireright.sdk.debug.CTraceLog;

/**
 * Class is a container for any DB Exceptions.
 * 
 * @author	Sergei Ignatov
 * @since	2002-10-08
 * @version $Revision: 1.8 $ $Date: 2008/02/21 21:54:48 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CDBException.java,v $
 */
public class CDBException extends CException  
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: asolntsev $";
	
	public CDBException(String sMessage, String sSource)
	{
		super(sMessage, sSource);
	}
	
	public CDBException(String sMessage, String sSource, CProperties properties)
	{
		super(sMessage, sSource, properties);
	}
	
	public CDBException(String sMessage, String sSource, Throwable cause, CProperties properties)
	{
		super(sMessage, cause, sSource, properties);
	}
	
	public CDBException(String sErrorMessage, Throwable cause, String sSource, CProperties properties, String sData)
	{
		super(sErrorMessage, cause, sSource, properties, sData);
	}
	
	/**
	 * @deprecated Use method getMessage() instead
	 * @return the same as getMessage()
	 */
	public String getMsg()
	{
		return getMessage();
	}
	
	static long logMe(CDBException e)
	{
		// This is needed only because of errors in JVM which does not prints "Caused by" in stack trace. 
		return CTraceLog.error(e, e.getSource(), e.getProperties(), e.getData());
	}

	/**
	 * @deprecated It's better to throw an exception instead of logging it in DB layer
	 * 
	 * @param sSource
	 * @param sMessage
	 * @param e
	 * @param properties
	 */
	static long logMe(String sSource, String sMessage, final Exception e, CProperties properties)
	{
		if (!sSource.startsWith("hireright.sdk.db."))
			sSource = "hireright.sdk.db." + sSource;

		if (e == null)
		{
			return CTraceLog.error(sMessage, sSource, properties);
		}
		
		String sExStackTrace = CStackTrace.getStackTrace(e);

		properties.setProperty("ex.message", e.getMessage());
		properties.setProperty("ex.class", e.getClass().getName());

		if (e instanceof SQLException)
		{
			SQLException sqle = (SQLException) e;
			
			sMessage = sMessage + "\n"+
				"message = " + sqle.getMessage() + "\n"+
				"errorCode = " + sqle.getErrorCode() + "\n";
			
			properties.setProperty("ex.code", sqle.getErrorCode());
			properties.setProperty("ex.sqlState", sqle.getSQLState());
			properties.setProperty("ex.sqlStateDesc", getSQLStateString(sqle.getSQLState()));
			
			if (sqle.getSQLState() != null)
			{
				sMessage = sMessage + "sqlState = " + sqle.getSQLState() 
					+ ": " + getSQLStateString(sqle.getSQLState()) + "\n";
			}
		}

		Exception logMe = new CDBException(sMessage, sSource, e, properties);
		return CTraceLog.error(logMe, sSource, properties, sExStackTrace);
	}

	/**
	 * @deprecated It's better to throw an exception instead of logging it in DB layer
	 * 
	 * @param sSource
	 * @param sMessage
	 * @param e
	 */
	public static void logMe(String sSource, String sMessage, Exception e)
	{
		logMe(sSource, sMessage, e, new CProperties());
	}

	public static String getSQLStateString(SQLException sqlEx)
	{
		return getSQLStateString(sqlEx.getSQLState());
	}
	
	public static String getSQLStateString(String sSQLState)
	{
		if (sSQLState == null)
			return null;
		
		int nSQLState;
		try
		{
			Integer nValue = Integer.valueOf(sSQLState, 16);
			nSQLState = nValue.intValue();
		}
		catch(Exception e)
		{
			return "";
		}

		switch(nSQLState)
		{
			case 0x00000: return "successful completion";
			case 0x01000: return "warning";
			case 0x01001: return "cursor operation conflict";
			case 0x01002: return "disconnect error";
			case 0x01003: return "null value eliminated in set function";
			case 0x01004: return "string data - right truncation";
			case 0x01005: return "insufficient item descriptor areas";
			case 0x01006: return "privilege not revoked";
			case 0x01007: return "privilege not granted";
			case 0x01008: return "implicit zero-bit padding";
			case 0x01009: return "search condition too long for info schema";
			case 0x0100A: return "query expression too long for info schema";
			case 0x02000: return "no data";
			case 0x07000: return "dynamic SQL error";
			case 0x07001: return "using clause does not match parameter specs";
			case 0x07002: return "using clause does not match target specs";
			case 0x07003: return "cursor specification cannot be executed";
			case 0x07004: return "using clause required for dynamic parameters";
			case 0x07005: return "prepared statement not a cursor specification";
			case 0x07006: return "restricted datatype attribute violation";
			case 0x07007: return "using clause required for result fields";
			case 0x07008: return "invalid descriptor count";
			case 0x07009: return "invalid descriptor index";
			case 0x08000: return "connection exception";
			case 0x08001: return "SQL client unable to establish SQL connection";
			case 0x08002: return "connection name in use";
			case 0x08003: return "connection does not exist";
			case 0x08004: return "SQL server rejected SQL connection";
			case 0x08006: return "connection failure";
			case 0x08007: return "transaction resolution unknown";
			case 0x0A000: return "feature not supported";
			case 0x0A001: return "multiple server transactions";
			case 0x21000: return "cardinality violation";
			case 0x22000: return "data exception";
			case 0x22001: return "string data - right truncation";
			case 0x22002: return "null value - no indicator parameter";
			case 0x22003: return "numeric value out of range";
			case 0x22005: return "error in assignment";
			case 0x22007: return "invalid date-time format";
			case 0x22008: return "date-time field overflow";
			case 0x22009: return "invalid time zone displacement value";
			case 0x22011: return "substring error";
			case 0x22012: return "division by zero";
			case 0x22015: return "interval field overflow";
			case 0x22018: return "invalid character value for cast";
			case 0x22019: return "invalid escape character";
			case 0x22021: return "character not in repertoire";
			case 0x22022: return "indicator overflow";
			case 0x22023: return "invalid parameter value";
			case 0x22024: return "unterminated C string";
			case 0x22025: return "invalid escape sequence";
			case 0x22026: return "string data - length mismatch";
			case 0x22027: return "trim error";
			case 0x23000: return "integrity constraint violation";
			case 0x24000: return "invalid cursor state";
			case 0x25000: return "invalid transaction state";
			case 0x26000: return "invalid SQL statement name";
			case 0x27000: return "triggered data change violation";
			case 0x28000: return "invalid authorization specification";
			case 0x2A000: return "direct SQL syntax error or access rule violation";
			case 0x2B000: return "dependent privilege descriptors still exist";
			case 0x2C000: return "invalid character set name";
			case 0x2D000: return "invalid transaction termination";
			case 0x2E000: return "invalid connection name";
			case 0x33000: return "invalid SQL descriptor name";
			case 0x34000: return "invalid cursor name";
			case 0x35000: return "invalid condition name";
			case 0x37000: return "dynamic SQL syntax error or access rule violation";
			case 0x3C000: return "ambiguous cursor name";
			case 0x3D000: return "invalid catalog name";
			case 0x3F000: return "invalid schema name";
			case 0x40000: return "transaction rollback";
			case 0x40001: return "serialization failure";
			case 0x40002: return "integrity constraint violation";
			case 0x40003: return "statement completion unknown";
			case 0x42000: return "syntax error or access rule violation";
			case 0x44000: return "with check option violation";
			case 0x60000: return "system errors";
			case 0x61000: return "resource error";
			case 0x62000: return "multi-threaded server and detached process errors";
			case 0x63000: return "Oracle*XA and two-task interface errors";
			case 0x64000: return "control file, database file, and redo file errors; archival and media recovery errors";
			case 0x65000: return "PL/SQL errors";
			case 0x66000: return "SQL*Net driver errors";
			case 0x67000: return "licensing errors";
			case 0x69000: return "SQL*Connect errors";
			case 0x72000: return "SQL execute phase errors";
			case 0x82100: return "out of memory (could not allocate)";
			case 0x82101: return "inconsistent cursor cache: unit cursor/global cursor mismatch";
			case 0x82102: return "inconsistent cursor cache: no global cursor entry";
			case 0x82103: return "inconsistent cursor cache: out of range cursor cache reference";
			case 0x82104: return "inconsistent host cache: no cursor cache available";
			case 0x82105: return "inconsistent cursor cache: global cursor not found";
			case 0x82106: return "inconsistent cursor cache: invalid Oracle cursor number";
			case 0x82107: return "program too old for runtime library";
			case 0x82108: return "invalid descriptor passed to runtime library";
			case 0x82109: return "inconsistent host cache: host reference is out of range";
			case 0x82110: return "inconsistent host cache: invalid host cache entry type";
			case 0x82111: return "heap consistency error";
			case 0x82112: return "unable to open message file";
			case 0x82113: return "code generation internal consistency failed";
			case 0x82114: return "reentrant code generator gave invalid context";
			case 0x82115: return "invalid hstdef argument";
			case 0x82116: return "first and second arguments to sqlrcn both null";
			case 0x82117: return "invalid OPEN or PREPARE for this connection";
			case 0x82118: return "application context not found";
			case 0x82119: return "connect error; can't get error text";
			case 0x82120: return "precompiler/SQLLIB version mismatch";
			case 0x82121: return "FETCHed number of bytes is odd";
			case 0x82122: return "EXEC TOOLS interface is not available";
			case 0x90000: return "debug events";
			case 0x99999: return "catch all";
		}

		return "";
	}
}