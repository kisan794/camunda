/*
 * Copyright 2001-2024 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * V.Ozernov				2024-07-04	HRG-314131 Created
 */
package hireright.sdk.db;

import hireright.sdk.consts.Logical;
import hireright.sdk.db.sql.CSqlCommands;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CClosableRegistry;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;
import org.hibernate.Hibernate;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.function.Supplier;
import java.util.regex.Pattern;

public class CMultitenantDB
{
	public static final String USER_SESSION_ATTR_DB_TENANT_CODE = "DB_TENANT_CODE";
	public static final String REQUEST_HEADER_DB_TENANT_CODE = "X-HR-DbTenantCode";
	public static final String TENANT_CODE_ROOT = null;
	
	private static CMultitenantDBState rootDbContainerState = null;
	private static final Map<Integer, String> containerIdToTenantCodeMap = new HashMap<>();
	private static final List<Integer> containerIds = Collections.synchronizedList(new ArrayList<>());
	private static final Pattern PATTERN_TENANT_CODE = Pattern.compile("^[a-zA-Z0-9_]{1,16}$");
	
	@FunctionalInterface
	public interface CallableInContainer<V> {
		V call(String targetTenantCode) throws Exception;
	}
	
	/**
	 * @return Current tenant code. E.g. "ubs" for UBS container, null for application root container.
	 * It also returns null if multitanancy is not supported by database.
	 */
	public static String getCurrentTenantCode()
	{
		if(CMultitenantAPIClient.isAPISupported())
		{
			return CMultitenantAPIClient.getCurrentTenantCode();
		}
		
		try
		{
			//No multitenancy driver available
			return getRootDbContainerState().isMultitenancySupported()
					? getCurrentTenantCodeFromDB()		//DB supports multitenancy. It's possible on ServiceMix/Camel
					: TENANT_CODE_ROOT;								//DB doesn't support multitenancy. E.g. on USI
		}
		catch(Exception e)
		{
			throw CRuntimeException.wrap(e);
		}
	}
	
	
	/**
	 * @return List of existing container ids.
	 */
	public static List<Integer> getExistingContainerIds()
	{
		if(containerIds.isEmpty())
		{
			synchronized(containerIds)
			{
				if(containerIds.isEmpty())
				{
					containerIds.addAll(loadExistingContainerIds());
				}
			}
		}
		return new ArrayList<>(containerIds);
	}
	
	@SuppressWarnings("unchecked")
	private static List<Integer> loadExistingContainerIds()
	{
		try
		{
			return DB.execute(() -> {
				DB.requestReadOnly(CConnection.JNDI_NAME_CONNECTION);
				return DB.session()
					.createSQLQuery("SELECT CON_ID FROM instance_containers")
					.addScalar("CON_ID", Hibernate.INTEGER)
					.list();
			});
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}
	}
	
	private static <T> T doSwitchIfNeededAndExecute(String targetTenantCode, Callable<T> callable) throws Exception
	{
		final String currentTenantCode = getCurrentTenantCode();
		if (CStringUtils.equalsOrEmptyIgnoreCase(targetTenantCode, currentTenantCode))
		{
			return callable.call();
		}
		else if (CMultitenantAPIClient.isAPISupported())
		{
			return CMultitenantAPIClient.doExecuteInTenantContainer(targetTenantCode, () -> doCall(callable));
		}
		else
		{
			return doExecuteInTenantContainerOnUnsupportedDriver(targetTenantCode, callable);
		}
	}
	
	private static <T> T doCall(Callable<T> callable) throws Exception
	{
		if (DB.isInitialized())
		{
			//Open new isolated DB context if DB is already initialized
			return DB.execute(() -> {
				DB.requestTransaction(CConnection.JNDI_NAME_CONNECTION);
				return callable.call();
				}, true);
		}
		else
		{
			return callable.call();
		}
	}
	
	private static <T> T doSwitchToRootIfNeededAndExecute(Callable<T> callable) throws Exception
	{
		return doSwitchIfNeededAndExecute(TENANT_CODE_ROOT, callable);
	}
	
	/**
	 * Execute a callable using connection to container of provided tenant.
	 * E.g. for tenant code "ubs" and root container "hr2" tenant container service name is "hr2ubs"
	 *
	 * @param targetTenantCode - tenant code for PDB container or null/"" for root container
	 * @param callable - to execute in the container
	 */
	public static <T> T execute(String targetTenantCode, Callable<T> callable) throws Exception
	{
		return !isSupported() ? callable.call() : doSwitchIfNeededAndExecute(targetTenantCode, callable);
	}
	
	/**
	 * Execute a function using connection to container having CON_ID provided by the given supplier.
	 * The supplier is executed in scope of application root container.
	 * If multitenancy is not supported by database then the supplier is not called.
	 *
	 * @param targetContainerIdSupplier - supplier of container ID
	 * @param callable - a callable to execute in the container. It's input is tenant container code.
	 */
	public static <T> T execute(Supplier<Integer> targetContainerIdSupplier, CallableInContainer<T> callable) throws Exception
	{
		if(!isSupported())
		{
			return callable.call(null);
		}
		else
		{
			Integer targetContainerId = doSwitchToRootIfNeededAndExecute(targetContainerIdSupplier::get);
			String targetTenantCode = targetContainerId == null || targetContainerId.equals(getRootDbContainerState().getContainerId())
					? TENANT_CODE_ROOT
					: getTenantCodeByContainerId(targetContainerId);
			
			return doSwitchIfNeededAndExecute(targetTenantCode, () -> callable.call(targetTenantCode));
		}
	}
	
	/**
	 * @return true if multitenancy is supported by DB
	 */
	public static boolean isSupported()
	{
		return getRootDbContainerState().isMultitenancySupported();
	}
	
	/**
	 * DO NOT USE IT! It can be used by a filter/framework only.
	 * Reset current tenant code.
	 */
	public static void resetTenantContext()
	{
		CMultitenantAPIClient.resetTenantContext();
	}
	
	private static synchronized CMultitenantDBState getRootDbContainerState()
	{
		if (rootDbContainerState == null)
		{
			rootDbContainerState = loadRootDbContainerState();
		}
		return rootDbContainerState;
	}
	
	private static CMultitenantDBState loadRootDbContainerState()
	{
		CMultitenantDBState state;
		try
		{
			state = CMultitenantAPIClient.isAPISupported()
					? doSwitchToRootIfNeededAndExecute(CMultitenantDB::getState)
					: getState(); //If API is not supported then we can't switch until root state is loaded
		}
		catch(Exception e)
		{
			throw CRuntimeException.wrap(e);
		}
		if (state.isMultitenancySupported() && !state.isApplicationRoot())
		{
			throw new IllegalStateException("Can't obtain state of application root DB Container: " + state);
		}
		
		return state;
	}
	
	public static String getTenantCodeByContainerId(Integer containerId)
	{
		synchronized(containerIdToTenantCodeMap)
		{
			return containerIdToTenantCodeMap.computeIfAbsent(containerId, CMultitenantDB::loadTenantCodeByContainerId);
		}
	}
	
	private static String loadTenantCodeByContainerId(Integer containerId)
	{
		try
		{
			String containerName = DB.execute(() ->
			{
				DB.requestReadOnly(CConnection.JNDI_NAME_CONNECTION);
				PreparedStatement statement = null;
				ResultSet resultSet = null;
				try
				{
					statement = DB.connection().prepareStatement("SELECT CON_ID_TO_CON_NAME(?) FROM dual");
					statement.setInt(1, containerId);
					resultSet = statement.executeQuery();
					resultSet.next();
					return CStringUtils.nvl(resultSet.getString(1)).toLowerCase();
				}
				finally
				{
					CSqlCommands.closeSilently(statement);
					CSqlCommands.closeSilently(resultSet);
				}
			});
			
			return containerName.replaceFirst(getRootDbContainerState().getContainerName(), "");
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}
	}
	
	private static CMultitenantDBState getState() throws Exception
	{
		return DB.execute(() -> {
			DB.requestReadOnly(CConnection.JNDI_NAME_CONNECTION);
			try (Statement stmt = DB.connection().createStatement();
					ResultSet resultSet = stmt.executeQuery("SELECT " +
							"SYS_CONTEXT('USERENV', 'CON_ID')," +
							"SYS_CONTEXT('USERENV', 'CON_NAME')," +
							"SYS_CONTEXT('USERENV', 'SERVICE_NAME')," +
							"SYS_CONTEXT('USERENV', 'IS_APPLICATION_ROOT')," +
							"SYS_CONTEXT('USERENV', 'IS_APPLICATION_PDB') " +
							"FROM dual")) {
				resultSet.next();
				Integer containerId = resultSet.getInt(1);
				String containerName = resultSet.getString(2);
				String serviceName = resultSet.getString(3);
				String sIsRoot = resultSet.getString(4);
				String sIsPdb = resultSet.getString(5);
				
				if (CStringUtils.isEmpty(sIsRoot) && CStringUtils.isEmpty(sIsPdb))
				{
					return CMultitenantDBState.NOT_SUPPORTED;
				}
				
				CMultitenantDBState state = new CMultitenantDBState(containerId, containerName.toLowerCase(),
						serviceName, Logical.isTrue(sIsRoot), Logical.isTrue(sIsPdb));
				
				if ((state.isApplicationRoot() && state.isApplicationPDB())
						|| (!state.isApplicationRoot() && !state.isApplicationPDB())
						|| containerId == null
						|| CStringUtils.isEmpty(containerName)
						|| CStringUtils.isEmpty(serviceName))
				{
					throw new IllegalStateException("Wrong multitenant DB configuration: " + state);
				}
				
				return state;
		}
		});
	}
	
	private static String getCurrentTenantCodeFromDB() throws Exception
	{
		return DB.execute(() -> {
			DB.requestReadOnly(CConnection.JNDI_NAME_CONNECTION);
			try(CallableStatement callableStatement = DB.connection().prepareCall(
					"{? = call bdk_instance_parameter.get_tenantCode()}"))
			{
				callableStatement.registerOutParameter(1, java.sql.Types.VARCHAR);
				callableStatement.execute();
				return callableStatement.getString(1);
			}
		});
	}
	
	/**
	 * This method is allowed to be used only if it applies to all connections of the connection pool (e.g. ServiceMix, Camel).
	 * It affects the current context of DB class if it exists, its nested contexts and future contexts until
	 * the next call of this method or the closable registry is run.
	 *
	 * @param targetTenantCode - code of tenant container or null/"" to switch to application root container
	 * @throws Exception
	 */
	public static void switchToContainerOnUnsupportedDriver(String targetTenantCode) throws Exception
	{
		if (CMultitenantAPIClient.isAPISupported())
		{
			throw new IllegalStateException("Method switchToContainerOnUnsupportedDriver() was called even though the multitenant driver is available");
		}
		
		if (!getRootDbContainerState().isMultitenancySupported())
		{
			return;
		}
		
		final String currentTenantCode = getCurrentTenantCodeFromDB();
		if (CStringUtils.equalsOrEmptyIgnoreCase(targetTenantCode, currentTenantCode))
		{
			return;
		}
		
		CMultitenantConnection.setContainerSwitcher(new CContainerSwitcher(targetTenantCode));
		CClosableRegistry.registerCurrentThread(CMultitenantConnection::resetContainerSwitcher);
		if (DB.isInitialized())
		{
			DB.execute(() -> {
				DB.requestReadOnly(CConnection.JNDI_NAME_CONNECTION);
				alterSessionSetContainer(DB.connection(), targetTenantCode);
				return null;
			});
		}
	}
	
	private static <T> T doExecuteInTenantContainerOnUnsupportedDriver(String targetTenantCode, Callable<T> callable) throws Exception
	{
		CMultitenantConnection.ContainerSwitcher previousSwitcher = CMultitenantConnection.getContainerSwitcher();
		try
		{
			CMultitenantConnection.setContainerSwitcher(new CContainerSwitcher(targetTenantCode));
			return doCall(callable);
		}
		finally
		{
			CMultitenantConnection.setContainerSwitcher(previousSwitcher);
		}
	}
	
	private static void alterSessionSetContainer(Connection connection, String tenantCode) throws SQLException
	{
		final CMultitenantDBState rootState = getRootDbContainerState();
		try (Statement statement = connection.createStatement()) {
			if (CStringUtils.isEmpty(tenantCode)) {
				statement.execute("ALTER SESSION SET "
						+ "container = " + rootState.getContainerName()
						+ " service = \"" + rootState.getServiceName() + "\"");
			}
			else {
				validateTenantCode(tenantCode);
				statement.execute("ALTER SESSION SET "
						+ "container = " + rootState.getContainerName() + tenantCode);
			}
		}
		DB.logActivity("Set tenant code " + tenantCode + " in " + connection);
	}
	
	private static void validateTenantCode(String tenantCode) {
		if (!PATTERN_TENANT_CODE.matcher(tenantCode).matches()) {
			throw new IllegalArgumentException("Wrong tenant code format");
		}
	}
	
	private static class CContainerSwitcher implements CMultitenantConnection.ContainerSwitcher
	{
		private final String targetTenantCode;
		
		CContainerSwitcher(String targetTenantCode)
		{
			this.targetTenantCode = targetTenantCode;
		}
		
		@Override
		public boolean isSupported(Connection connection, String dsJndiName)
		{
			return CConnection.JNDI_NAME_CONNECTION.equalsIgnoreCase(dsJndiName);
		}
		
		@Override
		public void switchToTenantContainer(Connection connection) throws SQLException
		{
			alterSessionSetContainer(connection, targetTenantCode);
		}
		
		@Override
		public void switchToRootContainer(Connection connection) throws SQLException
		{
			alterSessionSetContainer(connection, TENANT_CODE_ROOT);
		}
	}
}
