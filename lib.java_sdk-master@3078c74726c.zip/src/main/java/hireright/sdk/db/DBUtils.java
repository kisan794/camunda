/*
 * @(#)$RCSfile: DBUtils.java,v $ $Revision: 1.4 $ $Date: 2009/03/20 10:33:21 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/DBUtils.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	S.Ignatov		2001-11-15	Created
 *	S.Ignatov		2002-02-08	continued with group by
 *	A.Solntsev		2009-03-17	Class is deprecated
 */
package hireright.sdk.db;

import hireright.sdk.util.CStringUtils;

/**
 * @author Sergei Ignatov
 */
public class DBUtils
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	/**
	 * @deprecated Use method {@link CStringUtils#replace(String, String, String)}
	 * 
	 * @param szSource
	 * @param szParam
	 * @param szReplacement
	 * @return
	 */
	public static String replace(String szSource, String szParam, String szReplacement) 
	{
		if (szParam == null)
			return szSource;

		final String sReplacement = (szReplacement==null? "" : szReplacement);

		String szValue = szSource;
		
		int index = szValue.indexOf(szParam);
		while(index != -1)
		{
			StringBuilder szb = new StringBuilder(szValue.substring(0, index));
			szb.append(sReplacement);
			szb.append(szValue.substring(index + szParam.length()));
			szValue = szb.toString();
			index += sReplacement.length();
			index = szValue.indexOf(szParam, index);
		}
		
		return szValue;
	}
	
	public static String strFieldsArrayToStr(String[] fields)
	{
		if (fields == null || fields.length == 0)
			return "";
		
		int nCounter = fields.length;
		StringBuilder sFiledsList = new StringBuilder(fields[--nCounter]);

		while(nCounter != 0)
		{
			sFiledsList.append(", ");
			sFiledsList.append(fields[--nCounter]);
		}
			
		return sFiledsList.toString();
	}
	
	public static boolean isAggregateField(String sFieldName)
	{
		// FIX IT: just parse field name.
		if(sFieldName.indexOf(")") == -1)
			return false;
		
		final String sUpperFieldName = sFieldName.toUpperCase();
		
		if((0 <= sUpperFieldName.indexOf("COUNT(")) ||
			(0 <= sUpperFieldName.indexOf("MAX(")) ||
			(0 <= sUpperFieldName.indexOf("SUM(")) ||
			(0 <= sUpperFieldName.indexOf("AVG(")) ||
			(0 <= sUpperFieldName.indexOf("CORR(")) ||
			(0 <= sUpperFieldName.indexOf("MIN("))||
			(0 <= sUpperFieldName.indexOf("VARIANCE("))||
			(0 <= sUpperFieldName.indexOf("COVAR_POP("))||
			(0 <= sUpperFieldName.indexOf("COVAR_SAMP("))||
			(0 <= sUpperFieldName.indexOf("FIRST_VALUE("))||
			(0 <= sUpperFieldName.indexOf("LAST_VALUE("))||
			(0 <= sUpperFieldName.indexOf("STDDEV("))||
			(0 <= sUpperFieldName.indexOf("STDDEV_POP("))||
			(0 <= sUpperFieldName.indexOf("STDDEV_SAMP("))||
			(0 <= sUpperFieldName.indexOf("VAR_POP("))||
			(0 <= sUpperFieldName.indexOf("VAR_SAMP(")))
			return true;
			
		return false;
	}
}