/*
 * @(#)$RCSfile: CDBRuntimeException.java,v $ $Revision: 1.9 $ $Date: 2013/02/01 08:40:34 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CDBRuntimeException.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2002-10-08	S.Ignatov		Created
 *  2002-12-21	S.Ignatov		logging extended
 *  2003-02-06	A.Keks			bugfixing
 *  2003-02-26	S.Ignatov		add to source "hireright.sdk.db." if not starts
 *  2005-08-16	A.Solntsev		Class CStackTrace is used for logging.
 *  2006-06-08	A.Solntsev		More smart logging with properties and exception cause
 *  2008-02-18	A.Solntsev		Added more constructors
 *  2009-07-17	A.Solntsev		Enhanced error logging
 */
package hireright.sdk.db;

import java.sql.SQLException;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;

/**
 * this class intended to pass runtime exceptions from sdk.db classes.
 *
 * @author Serei Ignatov
 * @version $Revision: 1.9 $ $Date: 2013/02/01 08:40:34 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CDBRuntimeException.java,v $
 */
public class CDBRuntimeException extends CRuntimeException
{
	public final static String ERRMSG_NO_CONNECTION = "Cannot establish connection with database";
	public final static String ERRMSG_ILLEGAL_FIELD_INDEX = "Fields list has been accessed with an illegal field index";
	public final static String ERRMSG_NULL_FIELD_NAME = "Fields list has been accessed with null field name";
	public final static String ERRMSG_INVALID_FIELD_NAME = "Fields list doesn`t contain field with this name";
	public final static String ERRMSG_NULL_CONNECTION = "Null connection passed to procedure";
	public final static String ERRMSG_NULL_SOURCE_NAME = "Null data source name passed to procedure";
	public final static String ERRMSG_CLOSED_CONNECTION = "Closed connection passed to procedure";
	public final static String ERRMSG_SESSION_KILLED = "Your session has been killed";
	public final static String ERRMSG_NOT_LOGGED = "Not logged on";
	public final static String ERRMSG_NO_FIELDS = "No fields in data source";
	public final static String ERRMSG_USER_REQUESTED_CANCEL = "Timeout has occured. Please, try again in few seconds.";

	public final static int ERR_EXCEPTION_SQL_EXCEPTION	= -1;
	public final static int ERR_ILLEGAL_FIELD_INDEX	= 1;
	public final static int ERR_NULL_FIELD_NAME	= 2;
	public final static int ERR_INVALID_FIELD_NAME	= 3;
	public final static int ERR_FIELD_NAME_ALREADY_EXISTS	= 4;
	public final static int ERR_NULL_CONNECTION	= 5;
	public final static int ERR_NULL_SOURCE_NAME = 6;
	public final static int ERR_CLOSED_CONNECTION = 7;
	public final static int ERR_SESSION_KILLED = 8;
	public final static int ERR_NOT_LOGGED = 9;
	public final static int ERR_NO_FIELDS = 10;
	public final static int ERR_USER_REQUESTED_CANCEL = 11;

	public final static int ORA_00028_SESSION_KILLED = 28;
	public final static int ORA_01012_NOT_LOGGED = 1012;
	public final static int ORA_01013_USER_REQUESTED_CANCEL = 1013;

	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";

	private int m_nErrorCode;
	private SQLException m_sqlException;


	/**
	 * construct new db runtime exception with given error code.
	 */
	public CDBRuntimeException(String sMessage, int nErrorCode)
	{
		super(sMessage);
		m_nErrorCode = nErrorCode;
	}

	/**
	 * construct new db runtime exception from sql exception.
	 */
	public CDBRuntimeException(SQLException sqlException, CProperties properties)
	{
		super(sqlException, properties);
		initFromSQLException(sqlException);
	}

	public CDBRuntimeException(SQLException sqlException, CProperties properties, String sSqlClause)
	{
		super(sqlException, properties, sSqlClause);
		initFromSQLException(sqlException);
	}

	/**
	 * construct new db runtime exception from sql exception.
	 */
	public CDBRuntimeException(SQLException sqlException)
	{
		super(sqlException);
		initFromSQLException(sqlException);
	}

	public CDBRuntimeException(String sMessage, SQLException sqlException, CProperties properties, String sSqlStatement)
	{
		super(sMessage, sqlException, properties, sSqlStatement);
		initFromSQLException(sqlException);
	}

	/**
	 * construct new db runtime exception from sql exception.
	 */
	private final void initFromSQLException(SQLException sqlException)
	{
		m_sqlException = sqlException;
		switch (sqlException.getErrorCode())
		{
			case ORA_00028_SESSION_KILLED:
				m_nErrorCode = ERR_SESSION_KILLED;
				break;
			case ORA_01012_NOT_LOGGED:
				m_nErrorCode = ERR_NOT_LOGGED;
				break;
			case ORA_01013_USER_REQUESTED_CANCEL:
				m_nErrorCode = ERR_USER_REQUESTED_CANCEL;
				break;
			default:
				m_nErrorCode = sqlException.getErrorCode(); // I believe it's mot usefule than ERR_EXCEPTION_SQL_EXCEPTION;
		}
	}

	/**
	 * returns error code of this runtime exception.
	 */
	public int getErrorCode()
	{
		return m_nErrorCode;
	}

	/**
	 * returns error code mesage of this runtime exception.
	 */
	public String getErrorCodeMessage()
	{
		return getErrorCodeMessage(m_nErrorCode);
	}

	/**
	 * returns error code mesage for error code.
	 */
	public static String getErrorCodeMessage(int nErrorCode)
	{
		switch(nErrorCode)
		{
			case ERR_EXCEPTION_SQL_EXCEPTION: return "SQLException";
			case ERR_ILLEGAL_FIELD_INDEX: return ERRMSG_ILLEGAL_FIELD_INDEX;
			case ERR_NULL_FIELD_NAME: return ERRMSG_NULL_FIELD_NAME;
			case ERR_INVALID_FIELD_NAME: return ERRMSG_INVALID_FIELD_NAME;
			case ERR_NULL_CONNECTION: return ERRMSG_NULL_CONNECTION;
			case ERR_NULL_SOURCE_NAME: return ERRMSG_NULL_SOURCE_NAME;
			case ERR_CLOSED_CONNECTION: return ERRMSG_CLOSED_CONNECTION;
			case ERR_SESSION_KILLED: return ERRMSG_SESSION_KILLED;
			case ERR_NOT_LOGGED: return ERRMSG_NOT_LOGGED;
			case ERR_NO_FIELDS: return ERRMSG_NO_FIELDS;
			case ERR_USER_REQUESTED_CANCEL: return ERRMSG_USER_REQUESTED_CANCEL;
			default: return "Error is not registred";
		}
	}

	/**
	 * returns SQLException, if was created from.
	 */
	public SQLException getSQLException()
	{
		return m_sqlException;
	}

	/**
	 *  inherited methods
	 */
	@Override
	public String getMessage()
	{
		if (m_sqlException != null)
			return m_sqlException.getMessage() + ": " + super.getMessage();

		return getErrorCodeMessage() + ": " + super.getMessage();
	}

	@Override
	public String toString()
	{
		if (m_sqlException != null)
			return getErrorCode() + ": " + getErrorCodeMessage() + "\n" + m_sqlException.getMessage() + "\n" + super.getMessage();

		return getErrorCode() + ": " + getErrorCodeMessage() + "\n" + super.getMessage();
	}


}