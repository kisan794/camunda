/*
 * @(#)$RCSfile: IDataSet.java,v $ $Revision: 1.6 $ $Date: 2007/09/14 08:55:42 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  S.Ignatov			2001-11-15	created
 *	A.Solntsev		2006-05-07	Removed method CField fieldByIndex(int nIndex);
 *	A.Solntsev		2006-05-07	Removed method CField fieldByName(int nIndex);
 *	A.Solntsev		2006-07-03	Removed all methods (since not used)
 */
package hireright.sdk.db;

/**
 * @author Sergei Ignatov
 */
interface IDataSet
{
}