/*
 * @(#)$RCSfile: CRelation.java,v $ $Revision: 1.4 $ $Date: 2007/09/14 08:55:19 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2001-06-20	A.Rudenko		Created
 *	2006-11-01	A.Solntsev		implements Serializable
 */
package hireright.sdk.db;

import java.io.Serializable;

/**
 * @since June 2001
 */
public class CRelation implements Serializable
{
	private String m_szTable1;
	private String m_szTable2;
	private String m_szRelation;
	
	public CRelation(String szTableMaster, String szTableDetail, String szRelation)
	{
		super();
		m_szTable1 = szTableMaster;
		m_szTable2 = szTableDetail;
		m_szRelation = szRelation;
	}

	public String getRelationString()
	{
		return m_szRelation;
	}

	public String getRelationTable1()
	{
		return m_szTable1;
	}

	public String getRelationTable2()
	{
		return m_szTable2;
	}
}
