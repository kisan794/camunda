/*
 * @(#)$RCSfile: CAbstractStatementProxy.java,v $ $Revision: 1.2 $ $Date: 2015/11/02 20:16:25 $ $Author: cvsroot $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	atanasenko	05.06.2015	Created
 */
package hireright.sdk.db;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.sql.Statement;

/**
 * 
 */
public abstract class CAbstractStatementProxy implements InvocationHandler {
	
	private final Statement m_delegate;

	public CAbstractStatementProxy(Statement delegate) {
		this.m_delegate = delegate;
	}
	
	protected Statement getDelegate() {
		return this.m_delegate;
	}
	
	public static <T extends CAbstractStatementProxy> T unwrap(Class<T> wrapperClass, Statement stmt)
	{
		while(true)
		{
			if(!Proxy.isProxyClass(stmt.getClass()))
			{
				return null;
			}
			
			InvocationHandler h = Proxy.getInvocationHandler(stmt);
			if(!(h instanceof CAbstractStatementProxy))
			{
				return null;
			}
			CAbstractStatementProxy w = (CAbstractStatementProxy) h;
			
			if(wrapperClass.isInstance(w))
			{
				return wrapperClass.cast(w);
			}
			
			stmt = w.getDelegate();
		}
	}
	
	public static Statement unwrapAll(Statement stmt)
	{
		while(true)
		{
			if(!Proxy.isProxyClass(stmt.getClass()))
			{
				return stmt;
			}
			
			InvocationHandler h = Proxy.getInvocationHandler(stmt);
			if(!(h instanceof CAbstractStatementProxy))
			{
				return stmt;
			}
			CAbstractStatementProxy w = (CAbstractStatementProxy) h;
			
			stmt = w.getDelegate();
		}
	}
	
}
