/*
 * @(#)$RCSfile: CConnectionProvidedThread.java,v $ $Revision: 1.5 $ $Date: 2015/05/30 09:10:37 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CConnectionProvidedThread.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev			2008-03-26			created
 */
package hireright.sdk.db;

import java.util.concurrent.Callable;

import hireright.sdk.db3.DB;
import hireright.sdk.util.CRuntimeException;

/**
 * A Thread subclass which opens a DB connection at the beginning and closes it at the end.
 * It can be used for performing any operations that use DB connection in a separate thread.
 *
 * @author Andrei Solntsev
 * @version $Revision: 1.5 $ $Date: 2015/05/30 09:10:37 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CConnectionProvidedThread.java,v $
 * @deprecated Use {@link DB#execute(Runnable)} instead
 */
@Deprecated
public class CConnectionProvidedThread extends Thread
{
	private final String m_sJndiName;
	
	public CConnectionProvidedThread(Runnable target)
	{
		this(CConnection.JNDI_NAME_CONNECTION, target);
	}
	
	public CConnectionProvidedThread(String sJndiName, Runnable target)
	{
		super(target);
		m_sJndiName = sJndiName;
	}
	
	@Override
	public final void run()
	{
		try
		{
			DB.execute(new Callable<Void>(){
				@Override
				public Void call() {
					DB.setDefaultJNDIName(m_sJndiName);
					CConnectionProvidedThread.super.run();
					return null;
				}
			});
		}
		catch(RuntimeException e)
		{
			throw e;
		}
		catch(Exception e)
		{
			throw new CRuntimeException(e);
		}
	}
}
