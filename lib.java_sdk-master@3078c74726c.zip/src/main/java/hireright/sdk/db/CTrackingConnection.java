/*
 * @(#)$RCSfile: CTrackingConnection.java,v $ $Revision: 1.18 $ $Date: 2015/11/02 20:16:51 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CTrackingConnection.java,v $
 *
 * Copyright 2001-2019 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev		2005-07-21	created
 *	A.Solntsev		2006-05-17	Fixed bug with "SELECT UPDATED, * FROM PACK"
 *	A.Solntsev		2006-07-03	Added method toString()  (useful during debugging)
 *	A.Solntsev		2007-11-26	Implemented (optional) recording of current thread SQL Statements
 *	A.Solntsev		2008-03-05	Write warnings to file "FinalizationWarnings.log" instead of LOG_TRACE.
 *	A.Solntsev		2008-10-10	Added check if conenction is already closed
 *	A.Solntsev		2009-08-19	Changed WARNING to ERROR
 *  A.Solntsev		2010-03-05	Use Proxy instead of CConnectionWrapper
 *  N.Saddarov		2013-02-05	Attempt(Anton T's version) to fix ConcurrentModificationException
 *  M.Suhhoruki		2013-10-22	invoke did not call doClose, doCommit, doRollback ("Uncommitted statement!" fix)
 *  A.Tanasenko		2015-06-11	Track sql queries, show last sql on exception, warn if amount of statements is high during connection lifespan
 *  M.Kuznetsov		2019-12-05	Simplify connection registry
 */
package hireright.sdk.db;

import hireright.sdk.debug.CStackTrace;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;

/**
 * Wrapper for interface java.sql.Connection which intercepts all callings of
 * methods prepareCallableStatement(), commit(), rollback(), close() and
 * logs errors when detects some uncommitted statements.
 *
 * To distinguish SELECT statements (that don't need to be committed) from
 * commitable statements, use can add several patterns, for example "UPDATE",
 * "INSERT" or "sdk_state_machine.change_instState".
 *
 * Class has one static factory method with a set of predefined patterns.
 * @see	#create(Connection conn)
 *
 * @author Andrei Solntsev
 * @date 2005-07-21
 * @since java_sdk_v2-6-9
 * @version $Revision: 1.18 $ $Date: 2015/11/02 20:16:51 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CTrackingConnection.java,v $
 */
public class CTrackingConnection extends CAbstractConnectionProxy
{
	protected static final String CLASS_VERSION = "$Revision: 1.18 $ $Author: cvsroot $";
	
	private static final Logger LOG = Logger.getLogger(CTrackingConnection.class);
	
	private static final int STATEMENT_LOG_THRESHOLD = 1000;
	
	private static final Set<String> DEFAULT_SQL_PATTERNS = new HashSet<String>();
	static 
	{
		DEFAULT_SQL_PATTERNS.add("sdk_state_machine.init_instState".toUpperCase());
		DEFAULT_SQL_PATTERNS.add("sdk_state_machine.set_instTimeout".toUpperCase());
		DEFAULT_SQL_PATTERNS.add("sdk_state_machine.change_instState".toUpperCase());
		DEFAULT_SQL_PATTERNS.add("add_property".toUpperCase());
		DEFAULT_SQL_PATTERNS.add("set_property".toUpperCase());
		DEFAULT_SQL_PATTERNS.add("INSERT");
		DEFAULT_SQL_PATTERNS.add("UPDATE");
		DEFAULT_SQL_PATTERNS.add("DELETE");
	}
	
	private final Set<String> m_sqlKeywords;

	private final String m_sCreationStackTrace;
	private final Map<String, QueryInfo> m_allStatements;
	private final Set<String> m_uncommittedStatements;
	
	private boolean m_bIsClosed = false;
	private String m_sClosingStackTrace = null;
	
	private boolean countStatements = false; // TODO: currently unused
	
	/**
	 * Static factory method that creates instance of CTrackingConnection with
	 * set of predefined patterns.
	 *
	 * @param	originalConnection	original DB connection to which all callings
	 * 				will be actually redirected
	 * @return	newly created instance of CTrackingConnection with given
	 * 					original connection.
	 */
	public static Connection create(Connection originalConnection)
	{
		CTrackingConnection cn = new CTrackingConnection(originalConnection);
		
		return (Connection) java.lang.reflect.Proxy.newProxyInstance(
				originalConnection.getClass().getClassLoader(),
				new Class<?>[] {Connection.class},
				cn);
	}

	/**
	 * Contructor.
	 * After creating  you cann add any patterns with method addStatementPattern.
	 * Without statements patterns class has no sense.
	 *
	 * @param conn	original DB connection to which all callings
	 * 							will be actually redirected
	 */
	public CTrackingConnection(Connection conn)
	{
		super(conn);
		m_sqlKeywords =  new HashSet<String>(DEFAULT_SQL_PATTERNS);
		m_allStatements = new LinkedHashMap<String, QueryInfo>();
		m_uncommittedStatements = new LinkedHashSet<String>();
		m_sCreationStackTrace = CStackTrace.getStackTrace(
			"Instance of CTrackingConnection is created in thread '" + Thread.currentThread().getName() + "'");
	}
	
	public String getCreationStackTrace() {
		return this.m_sCreationStackTrace;
	}
	
	public Set<String> getUncommittedStatements() {
		return Collections.unmodifiableSet(this.m_uncommittedStatements);
	}
	
	protected void registerStatement(String query, long nanos)
	{
		checkIfClosed();
		
		if(query != null)
		{
			query = cleanQuery(query);
			
			QueryInfo qi = m_allStatements.remove(query);
			if(qi == null) {
				qi = new QueryInfo();
			}
			qi.count++;
			qi.totalNanos += nanos;
			
			m_allStatements.put(query, qi);
		}
		
		// Register sql statement
		if (matches(query))
		{
			m_uncommittedStatements.add(query);
		}
	}
	
	/*
	 * Replace continuous sequences of whitespaces with a single space
	 */
	private String cleanQuery(String query) {
		StringBuilder sb = new StringBuilder();
		
		int l = query.length();
		boolean ws = false;
		for(int i = 0; i < l; i++) {
			char c = query.charAt(i);
			if(Character.isWhitespace(c)) {
				if(!ws) {
					ws = true;
					sb.append(' ');
				}
			} else {
				ws = false;
				sb.append(c);
			}
		}
		
		return sb.toString().trim();
	}

	protected boolean matches(String stmt)
	{
		if (stmt == null) return false;
		
		stmt = stmt.toUpperCase();
		for (String kw : m_sqlKeywords)
		{
			int idx = 0;
			// for each occurence of keyword in statement
			while((idx = stmt.indexOf(kw, idx)) != -1) {
				// check that preceding and following chars are not alphanumeric
				char cprev = idx == 0 ? 0 : stmt.charAt(idx - 1);
				char cnext = idx + kw.length() >= stmt.length() ? 0 : stmt.charAt(idx + kw.length());
				if(!isWord(cprev) && !isWord(cnext)) {
					return true;
				}
				idx += kw.length();
			}
		}
		return false;
	}

	private boolean isWord(char ch) {
		return Character.isLetterOrDigit(ch) || "_".indexOf(ch) != -1;
	}

	private void checkIfClosed()
	{
		if (m_bIsClosed)
		{
			throw new IllegalStateException("This connection is closed, see closing stack trace: " + 
					m_sClosingStackTrace + "\nCreation stack trace: " + m_sCreationStackTrace);
		}
	}

	public Object invoke( Object proxy, Method m, Object[] args ) throws Throwable
	{
		Object result;
		try
		{
			if (LOG.isDebugEnabled())
				LOG.debug( "before method " + m.getName() );
			
			if ("close".equals( m.getName() ))
			{
				doClose();
			}
			else if ("commit".equals( m.getName() ))
			{
				doCommit();
			}
			else if ("rollback".equals( m.getName() ))
			{
				doRollback();
			}
			
			result = m.invoke(getDelegate(), args);
			result = wrap(m.getName(), args, result);
		}
		catch ( InvocationTargetException e )
		{
			throw e.getCause();
		}
		finally
		{
			if (LOG.isDebugEnabled())
				LOG.debug( "after method " + m.getName() );
		}
		return result;
	}
	
	/**
	 * Method clears internal array of uncommited statements and
	 * calls method "commit" on original connection.
	 */
	public void doCommit()
	{
		m_uncommittedStatements.clear();
		if (m_bIsClosed)
		{
			LOG.error("This connection is closed, see stack trace: " + m_sClosingStackTrace);
		}
	}

	/**
	 * Method clears internal array of uncommited statements and
	 * calls method "rollback" on original connection.
	 */
	public void doRollback()
	{
		m_uncommittedStatements.clear();
		if (m_bIsClosed)
		{
			LOG.error("This connection is closed, see stack trace: " + m_sClosingStackTrace);
		}
	}

	/**
	 * Method checks if connection has some uncommitted sql statemenmts.
	 * If has, methods 
	 * 1) writes errors to tracelog, including information about the place where these statements were called (creation stack trace).
	 * 2) rollbacks all uncommitted changes (to free DB resources and locks)
	 *
	 * Usually this method is called before closing the connection or
	 * returning it to the connection pool.
	 */
	public void checkUncommittedStatements()
	{
		if (!m_uncommittedStatements.isEmpty())
		{
			for (String sUncommittedStatement : m_uncommittedStatements)
			{
				CTraceLog.error("Uncommitted statement!\n" + sUncommittedStatement,
							getClass().getName() + ".close()", sUncommittedStatement);
			}

			m_uncommittedStatements.clear();
		}
	}
	
	private void checkStatementsCount()
	{
		int total = 0;
		for(QueryInfo qi: m_allStatements.values()) {
			total += qi.count;
		}
		
		if(total > STATEMENT_LOG_THRESHOLD) {
			
			StringBuilder sb = new StringBuilder();
			long totalTime = 0;
			for(Map.Entry<String, QueryInfo> en: m_allStatements.entrySet())
			{
				QueryInfo qi = en.getValue();
				sb.append("\n * ");
				sb.append(qi.count).append("x/").append(qi.totalNanos/(1000L*1000L)).append("ms");
				sb.append(" (").append(en.getKey()).append(")");
				
				totalTime += qi.totalNanos;
			}
			
			CTraceLog.addCurrentThreadParameters(new CProperties()
				.setProperty("queries", sb)
			);
			
			CTraceLog.warning(
				"Large number of statements executed: " + total + "x/" + (totalTime / (1000L*1000L)) + " ms total " + 
				sb.toString(), CTrackingConnection.class.getName());
		}
		
	}

	/**
	 * Method checks if connection has some uncommitted sql statements and calles
	 * methods "rollback" and "close" on the original connection.
	 */
	public void doClose()
	{
		if (!m_bIsClosed)
		{
			m_sClosingStackTrace = CStackTrace.getStackTrace(
				"Instance of CTrackingConnection is closed in thread '" + Thread.currentThread().getName() + "'") +
				"\nat" + new Date() +
				"\nwith parameters: " + CTraceLog.getCurrentThreadParameters();
		}
		
		m_bIsClosed = true;
		checkUncommittedStatements();
		if(countStatements) checkStatementsCount();
	}

	/**
	 * (For the safety) method checks if connection has some uncommitted
	 * sql statements. Additionally, method checks if connection is closed.
	 *
	 * If not, method writes warning and calls method "rollback" on original
	 * connection to free database resources.
	 *
	 * @throws java.lang.Throwable
	 */
	@Override
	protected void finalize() throws Throwable
	{
		checkUncommittedStatements();

		if (!getDelegate().isClosed())
		{
			//CTraceLog.error("Unclosed connection!" ,
			//				getClass().getName() + ".close()", m_sCreationStackTrace);
			
			CClosableObject.writeFinalizationWarning(getClass(), m_sCreationStackTrace,
					null, new CProperties());

			CConnection.rollback( getDelegate() );
			CConnection.closeConnection( getDelegate() );
		}

		m_sqlKeywords.clear();
		m_uncommittedStatements.clear();
		super.finalize();
	}

	/**
	 * Return string-representation of this connection containing DB URL.
	 * Useful during debugging.
	 *
	 * @since java_sdk_v2-6-13
	 */
	@Override
	public String toString()
	{
		if (m_uncommittedStatements != null && !m_uncommittedStatements.isEmpty())
		{
			return getClass().getName() + ": " + CConnection.getUrl(getDelegate()) + ": " +
				m_uncommittedStatements.size() + " uncommitted statements";
		}

		return getClass().getName() + ": " + CConnection.getUrl(getDelegate());
	}
	
	public static CTrackingConnection unwrap(Connection conn)
	{
		return unwrap(CTrackingConnection.class, conn);
	}
	
	private Object wrap(String name, Object[] args, Object result)
	{
		if(name.equals("prepareCall"))
		{
			return proxyStatement((Statement)result, args, CallableStatement.class);
		}
		else if(name.equals("prepareStatement"))
		{
			return proxyStatement((Statement)result, args, PreparedStatement.class);
		}
		else if(name.equals("createStatement"))
		{
			return proxyStatement((Statement)result, args, Statement.class);
		}
		
		return result;
	}
	
	private Statement proxyStatement(Statement stmt, Object[] factoryArgs, Class<? extends Statement> cl)
	{
		return (Statement) Proxy.newProxyInstance(
				stmt.getClass().getClassLoader(),
				new Class<?>[] { cl }, new TrackingStatement(stmt, factoryArgs));
	}
	
	private static Set<String> EXECUTE_METHODS = new HashSet<String>(Arrays.asList(
		"execute", 
		"executeQuery", 
		"executeUpdate"
	));
	private static Set<String> PARAM_STREAM_METHODS = new HashSet<String>(Arrays.asList(
		"setArray",
		"setAsciiStream",
		"setBlob",
		"setBytes",
		"setCharacterStream",
		"setClob",
		"setNBlob",
		"setNCharacterStream",
		"setNClob",
		"setUnicodeStream"
	));
	private static Set<String> PARAM_METHODS = new HashSet<String>(Arrays.asList(
		"setInt", 
		"setString", 
		"setDouble", 
		"setBigDecimal",
		"setBoolean",
		"setByte",
		"setDate",
		"setDouble",
		"setFloat",
		"setLong",
		"setObject",
		"setShort",
		"setRef",
		"setRowId",
		"setTime",
		"setTimestamp",
		"setURL"
	));
	
	private class TrackingStatement extends CAbstractStatementProxy
	{
		private Object[] factoryArgs;
		private List<Query> batch;
		Map<Integer, String> params;
		
		public TrackingStatement(Statement delegate, Object[] factoryArgs)
		{
			super(delegate);
			this.factoryArgs = factoryArgs;
		}
		@Override
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
		{
			String name = method.getName();
			boolean exec = false;
			
			if(EXECUTE_METHODS.contains(name))
			{
				exec = true;
				
				Query q = new Query();
				q.query = getQuery(args);
				q.params = params;
				batch = new ArrayList<Query>();
				batch.add(q);
				params = null;
			}
			else if(name.equals("addBatch"))
			{
				Query q = new Query();
				q.query = getQuery(args);
				q.params = this.params;
				
				if(batch == null) batch = new ArrayList<Query>();
				batch.add(q);
				params = null;
			}
			else if(name.equals("executeBatch"))
			{
				exec = true;
			}
			else if(name.equals("clearBatch"))
			{
				batch = null;
				params = null;
			}
			else if(PARAM_METHODS.contains(name))
			{
				addParam(getIdx(args), getValue(args));
			}
			else if(PARAM_STREAM_METHODS.contains(name))
			{
				addParam(getIdx(args), "<..>");
			}
			else if(name.equals("setNull"))
			{
				addParam(getIdx(args), "<null>");
			}
			else if(name.equals("clearParameters"))
			{
				params = null;
			}
			
			long t = System.nanoTime();
			try
			{
				return method.invoke(getDelegate(), args);
			}
			catch(InvocationTargetException e)
			{
				Throwable c = e.getCause();
				if(c instanceof SQLException)
				{
					SQLException sqle = (SQLException) c;
					if(exec)
					{
						// add query to error message
						SQLException newSqle = new SQLException(sqle.getMessage() + "\n" + buildQueryInfo(), sqle.getSQLState(), sqle.getErrorCode(), sqle.getCause());
						newSqle.setStackTrace(sqle.getStackTrace());
						newSqle.setNextException(sqle.getNextException());
						throw newSqle;
					}
				}
				throw c;
			}
			finally
			{
				if(exec && batch != null)
				{
					t = System.nanoTime() - t;
					
					long s = batch.size();
					if(s > 1) {
						t /= s;
					}
					for(Query q: batch) {
						registerStatement(q.query, t);
					}
					
					batch = null;
					params = null;
				}
			}
		}
		private String buildQueryInfo()
		{
			StringBuilder sb = new StringBuilder();
			if(batch != null)
			{
				boolean first = true;
				for(Query q: batch)
				{
					if(q == null) continue;
					
					if(first) first = false;
					else sb.append("; ");
					
					sb.append("[").append(q.query).append("]");
					if(q.params != null && !q.params.isEmpty())
					{
						boolean ffirst = true;
						sb.append(" (");
						for(String v: q.params.values())
						{
							if(ffirst) ffirst = false;
							else sb.append(", ");
							sb.append(v);
						}
						sb.append(")");
					}
					
					if(sb.length() > 1024)
					{
						sb.setLength(1024);
						sb.append("...");
					}
				}
			}
			
			return sb.toString();
		}
		
		private void addParam(Integer idx, String value)
		{
			if(params == null)
			{
				params = new TreeMap<Integer, String>();
			}
			params.put(idx,  value);
		}
		
		private String getQuery(Object[] methodArgs)
		{
			if(methodArgs == null || methodArgs.length == 0)
			{
				methodArgs = factoryArgs;
			}
			return methodArgs != null && methodArgs.length > 0 ? (String) methodArgs[0] : null;
		}
		
		private Integer getIdx(Object[] methodArgs)
		{
			return methodArgs != null && methodArgs.length > 0 ? (Integer) methodArgs[0] : null;
		}
		
		private String getValue(Object[] methodArgs)
		{
			Object value = methodArgs != null && methodArgs.length > 1 ? methodArgs[1] : null;
			if(value == null) return "<null>";
			
			String str = value.toString();
			if(str.length() > 32)
			{
				str = str.substring(0, 28) + "<..>";
			}
			return str;
		}
		
	}
	
	private static class QueryInfo {
		int count = 0;
		long totalNanos = 0;
	}
	
	private static class Query {
		String query;
		Map<Integer, String> params;
	}
}