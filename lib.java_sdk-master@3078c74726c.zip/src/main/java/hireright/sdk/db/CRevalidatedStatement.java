/*
 * @(#)$RCSfile: CRevalidatedStatement.java,v $ $Revision: 1.3 $ $Date: 2015/11/02 20:14:38 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CRevalidatedStatement.java,v $
 *
 * Copyright 2012 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  M. Suhhoruki		2014-05-08 created
 *  
 */
package hireright.sdk.db;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Handles ORA-04068 error by calling failed statement again.
 * 
 * @author msuhhoruki
 * @since java_sdk_v3-57
 */
public class CRevalidatedStatement extends CAbstractStatementProxy
{
	public CRevalidatedStatement(Statement stmt)
	{
		super(stmt);
	}

	@Override
	public Object invoke(Object proxy, Method m, Object[] args)
		throws Throwable
	{
		try
		{
			return m.invoke(getDelegate(), args);
		}
		catch (InvocationTargetException e)
		{
			Throwable cause = e.getTargetException();
			if (isInvalidatedError(cause))
			{
				/*
				 * Retry statement.
				 * DML from original call is rolled back implicitly.
				 * Other operations (DDL, HTTP calls, sequence changes are retained)
				 */
				try
				{
					return m.invoke(getDelegate(), args);
				}
				catch (InvocationTargetException e2)
				{
					Throwable cause2 = e2.getTargetException();
					throw (cause2 != null) ? cause2 : e2;
				}
			}
			
			throw (cause != null) ? cause : e;
		}
	}
	
	public static PreparedStatement create(PreparedStatement originalStatement)
	{
		CRevalidatedStatement stmt = new CRevalidatedStatement(originalStatement);
		
		return (PreparedStatement) Proxy.newProxyInstance(
				stmt.getClass().getClassLoader(),
				new Class<?>[] {PreparedStatement.class},
				stmt);
	}
	
	public static CallableStatement create(CallableStatement originalStatement)
	{
		CRevalidatedStatement stmt = new CRevalidatedStatement(originalStatement);
		
		return (CallableStatement) Proxy.newProxyInstance(
				stmt.getClass().getClassLoader(),
				new Class<?>[] {CallableStatement.class},
				stmt);
	}
	
	public static Statement create(Statement originalStatement)
	{
		CRevalidatedStatement stmt = new CRevalidatedStatement(originalStatement);
		
		return (Statement) Proxy.newProxyInstance(
				stmt.getClass().getClassLoader(),
				new Class<?>[] {Statement.class},
				stmt);
	}
	
	private boolean isInvalidatedError(Throwable cause)
	{
		return cause != null && cause instanceof SQLException
				&& ((SQLException) cause).getErrorCode() == 4068;
	}
}
