/*
 * @(#)$RCSfile: CSQLWhereConstructor.java,v $ $Revision: 1.31 $ $Date: 2015/03/28 08:24:57 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CSQLWhereConstructor.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 2003-02-20	D.Travin 	added method andToFilterUpperEqual()
 * 2003-02-25	D.Travin 	quot inside the value check added
 * 2004-01-16	S.Prokopov	Added methods andToFilterUpperLike, andToFilterUpperBegins
 * 2004-02-05	Anton Keks 	Implemented possibility to add subselects to filter
 * 2004-03-11	A.Solntsev	Method checkValue() is repaired (for empty string it gave an error)
 * 2004-05-01	Anton Keks  Added condition NOT LIKE
 * 2005-05-03	A.Solntsev	New API: now all methods return link to object itself.
 * 2005-06-23	A.Solntsev	Added predefined filter ALL.
 * 2005-08-16	A.Solntsev	Now class build a special `tricky` SQL for binding variables.
 * 2005-09-02	A.Solntsev	Added method toString(boolean buildTrickySql).
 * 2005-10-24	A.Solntsev	Added factory method firstNRows(int rows).
 * 2006-01-04	A.Solntsev	COND_UPPER_LIKE: Removed %% since it causes full table scan.
 * 2006-05-11	S.Prokopov	Moved buildSelectInValues from CFlexFieldLoader into addSelectInValues.
 * 2006-06-16	A.Solntsev	Added methods toString(), implements Serializable
 * 2007-02-08	A.Solntsev	Instance ALL is immutable
 * 2007-02-09	A.Solntsev	Added copy constructor
 * 2008-03-25	M.Elshin	Function isInsideQuotes was added. Function parseTrickSQL was updated
 * 							to skip semicolon in strings due to the fact that they are not related
 * 							to binding variables they are part of string surrounded by quotes.
 * 2008-05-29	M.Litvinov	the factory method firsNRows is enhanced
 * 2008-06-09	A.Solntsev	Added 2 synonyms: andIn() and orIn()
 * 2008-09-01	A.Solntsev	Fixed SQL filter containing apostrophes
 * 2008-09-25	A.Solntsev	generics bugfix: replaced <Object> by <?> in several methods
 * 2008-10-24	A.Solntsev	Added several methods with char parameter
 * 2009-06-15	A.Solntsev	Added several methods for convenience: andLike, andNotEquals, orLike etc.
 * 2010-02-08	A.Solntsev	Added support for DATEs in SQL filters
 * 2013-04-09	A.Tanasenko	Fixed rare bug with using CSQLWhereConstructor with parameters that contain quotes.
 * 2014-03-12   J.Bogdanov  added andEqualsIgnoreCase()
 * 2018-04-24	I.Suits		Added BIGINT to Long mapping
 */
package hireright.sdk.db;

import java.io.Serializable;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * One level sql expression constructor.
 * Examples of usage see in class CSQLWhereConstructorTest.
 *
 * @author Sergei Ignatov
 * @version "$Revision: 1.31 $, $Date: 2015/03/28 08:24:57 $, $Author: cvsroot $"
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CSQLWhereConstructor.java,v $
 */
@SuppressWarnings("serial")
public class CSQLWhereConstructor implements Serializable
{
	/** Constant with current version of this class and its author. */
	protected static final String CLASS_VERSION = "$Revision: 1.31 $ $Author: cvsroot $";

	/** define the maximum rows to be returned after the select execution */
	private final Integer m_nMaxFirstRowsToReturn;

	// --------- Public constants ---------

	/**
	 * This predefined SQL Filter contains no any conditions.
	 * Use this filter when you need to read all records.
	 */
	public static final CSQLWhereConstructor ALL = new CSQLWhereConstructor()
	{
		@Override
		protected final CSQLWhereConstructor addSectionToFilter(String sFieldName, int nCondition,
			Object value, int nOperation, boolean asIs)
		{
			throw new UnsupportedOperationException("Object CSQLWhereConstructor.ALL is immutable, " +
				"but called with parameters (" + sFieldName + ", " + nCondition + ", " +
					value + ", " + nOperation + ", " + asIs + ")");
		}
	};

	public static final String HEADER_TRICKY_FILTER = "TRICKY SQL FILTER ";

	private final List<FilterElement> m_oneLevelWhereExpression = new ArrayList<FilterElement>();

	// --------- Package-private constants ---------
	/**
	 * Oracle allows IN-Clause to have no more than 1000 items.
	 * For example this is not allowed:
	 * <pre>   <code>WHERE MY_GIELD IN ('VAL1', 'VAL2', 'VAL3', ..., 'VAL1000', 'VAL1001')</code></pre>
	 */
	static public final int MAX_IN_CLAUSE_SIZE = 1000;

	/**
	 * @deprecated	This constant is used ONLY in Management Reports,
	 * 							and actually it's not needed here.
	 * FIXME	Remove this constant.
	 */
	public static final int COND_NONE = -1;

	// Different conditions
	public static final int COND_NESTED_FILTER = -1;
	public static final int COND_EQUAL = 0;
	public static final int COND_NOT_EQUAL = 1;
	public static final int COND_GREATER = 2;
	public static final int COND_LESS = 3;
	public static final int COND_LIKE = 4;
	public static final int COND_GREATER_EQUAL = 5;
	public static final int COND_LESS_EQUAL = 6;
	public static final int COND_IN = 7;
	public static final int COND_NOT_LIKE = 8;
	public static final int COND_EQUAL_UPPER = 9;
	public static final int COND_UPPER_LIKE = 10;
	public static final int COND_UPPER_BEGINS = 11;
	public static final int COND_EQUAL_TRIM_UPPER = 12;

	// --------- Private constants ---------
	private static final int OPERATION_NULL = 0;
	private static final int OPERATION_AND = 1;
	private static final int OPERATION_OR = 2;

	enum PRINT_MODE {BINDED, TRICKY_SQL, UNBINDED}

	// --------- Inner classes ---------
	/**
	 * Filter element part.
	 * Immutable serializable class.
	 */
	private class FilterElement implements Serializable
	{
		private final String m_sFieldName;
		private final int m_nCondition;
		private final Object m_value;
		private final int m_nOperation;
		private final boolean m_bAsIs;

		FilterElement(String sFieldName, int nCondition, Object value, int nOperation, boolean asIs)
		{
			m_sFieldName = sFieldName;
			m_nCondition = nCondition;
			m_value = value;
			m_nOperation = nOperation;
			m_bAsIs = asIs;
		}

		private String getOperation()
		{
			switch (m_nOperation)
			{
				case CSQLWhereConstructor.OPERATION_AND:
					return " AND ";
				case CSQLWhereConstructor.OPERATION_OR:
					return " OR ";
				case CSQLWhereConstructor.OPERATION_NULL:
					// append nothing.
					return "";
				default:
					return "";
			}
		}

		public int getSqlType()
		{
			if (m_value instanceof Integer)
			{
				return Types.INTEGER;
			}
			else if (m_value instanceof Long)
			{
				return Types.BIGINT;
			}									
			else if (m_value instanceof Number)
			{
				return Types.NUMERIC;
			}
			else if (m_value instanceof String)
			{
				return Types.VARCHAR;
			}
			else if (m_value instanceof Date)
			{
				return Types.TIMESTAMP;
			}
			else
			{
				// ?
				return Types.VARCHAR;
			}
		}
		
		public String encodeSqlValue()
		{
			if (m_value == null)
				return "";
			else if (m_value instanceof Date)
				return String.valueOf( ((Date)m_value).getTime() );
			else
				return m_value.toString();
		}

		/**
		 * @since java_sdk_v2-6-14
		 * @return (non-tricky) String-representation of this element
		 */
		@Override
		public String toString()
		{
			StringBuilder sb = new StringBuilder();
			try
			{
				toString(sb, 1, false, null);
				return sb.toString();
			}
			finally
			{
				sb.setLength(0);
				sb = null;
			}
		}

		/**
		 * Returns condition string.
		 * @param sb
		 * @param nIndex
		 * @param bTrickySql
		 *
		 * @return string with formatted condition (this is not string !?)
		 */
		public int toString(StringBuilder sb, int nIndex, boolean bTrickySql, CSQLWhereFilter sqlFilter)
		{
			int newIndex = nIndex;
			sb.append(getOperation());

			final String sValue;
			if (m_bAsIs)
			{
				sValue = String.valueOf(m_value);
			}
			else if (m_value == null)
			{
				// do nothing.
				sValue = "";
			}
			else if (m_value instanceof CSubSelect)
			{
				CSubSelect subSelect = (CSubSelect) m_value;

				StringBuilder sbSubSelect = new StringBuilder();
				newIndex = subSelect.buildSql(sbSubSelect, nIndex, bTrickySql, sqlFilter);
				sValue = sbSubSelect.toString();
			}
			else if (m_value instanceof CSQLWhereConstructor)
			{
				CSQLWhereConstructor nestedFilter = (CSQLWhereConstructor) m_value;
				StringBuilder sbNestedFilter = new StringBuilder("(");
				newIndex = nestedFilter.buildSql(sbNestedFilter, nIndex, bTrickySql, sqlFilter);
				sbNestedFilter.append(")");
				sValue = sbNestedFilter.toString();
			}
			else
			{
				final int nSqlType = getSqlType();
				StringBuilder sbValue = new StringBuilder(":").append(nIndex);
				if (bTrickySql)
				{
					// This is the main trick designed to bind variables later.
					sbValue.append("[").append( getSqlType() ).append("][").append( encodeSqlValue() ).append("]");
				}
				sValue = sbValue.toString();
				if (sqlFilter != null)
				{
					sqlFilter.addVariable( Integer.valueOf(nIndex),
							(m_value==null ? null : encodeSqlValue()) , nSqlType );
				}

				newIndex++;
			}

			switch (m_nCondition)
			{
				case COND_EQUAL:
					if (m_value == null)
						sb.append(m_sFieldName).append(" IS NULL");
					else
						sb.append(m_sFieldName).append(" = ").append(sValue);
					break;
				case COND_NOT_EQUAL:
					if (m_value == null)
						sb.append(m_sFieldName).append(" IS NOT NULL");
					else
						sb.append(m_sFieldName).append(" != ").append(sValue);
					break;
				case COND_GREATER:
					sb.append(m_sFieldName).append(" > ").append(sValue);
					break;
				case COND_LESS:
					sb.append(m_sFieldName).append(" < ").append(sValue);
					break;
				case COND_LIKE:
					sb.append(m_sFieldName).append(" LIKE ").append(sValue);
					break;
				case COND_NOT_LIKE:
					sb.append(m_sFieldName).append(" NOT LIKE ").append(sValue);
					break;
				case COND_GREATER_EQUAL:
					sb.append(m_sFieldName).append(" >= ").append(sValue);
					break;
				case COND_LESS_EQUAL:
					sb.append(m_sFieldName).append(" <= ").append(sValue);
					break;
				case COND_IN:
					sb.append(m_sFieldName).append(" IN ").append(sValue);
					break;
				case COND_NESTED_FILTER:
					sb.append(sValue);
					break;
				case COND_EQUAL_UPPER:
					sb.append("UPPER(").append(m_sFieldName).append(") = UPPER(").append(sValue).append(")");
					break;
				case COND_UPPER_LIKE:
					sb.append("UPPER(").append(m_sFieldName).append(") LIKE ")
						.append("UPPER(").append(sValue).append(")");
					break;
				case COND_UPPER_BEGINS:
					sb.append("UPPER(").append(m_sFieldName).append(") LIKE UPPER(")
						.append(sValue).append(") || '%'");
					break;
				case COND_EQUAL_TRIM_UPPER:
					sb.append("TRIM(UPPER(").append(m_sFieldName).append(")) = TRIM(UPPER(")
						.append(sValue).append("))");
					break;
			}

			return newIndex;
		}
	}

	/**
	 * Immutable serializable class
	 */
	private class CSubSelect implements Serializable
	{
		private final String m_sSubSelectTableName;
		private final String m_sSubSelectFieldName;
		private final CSQLWhereConstructor m_cSQLSubSelect;
		CSubSelect(CSQLWhereConstructor cSQLSubSelect, String sSubSelectFieldName, String sSubSelectTableName)
		{
			m_sSubSelectTableName = sSubSelectTableName;
			m_sSubSelectFieldName = sSubSelectFieldName;
			m_cSQLSubSelect = cSQLSubSelect;
		}

		/**
		 * Internal method to build subselects
		 */
		int buildSql(StringBuilder sbSelect, int nStartIndex, boolean bTrickySql, CSQLWhereFilter sqlFilter)
		{
			sbSelect.append('(');
			sbSelect.append("SELECT ");
			sbSelect.append(m_sSubSelectFieldName);
			sbSelect.append(" FROM ");
			sbSelect.append(m_sSubSelectTableName);
			sbSelect.append(" WHERE ");

			int nIndex = m_cSQLSubSelect.buildSql(sbSelect, nStartIndex, bTrickySql, sqlFilter);

			sbSelect.append(')');
			return nIndex;
		}

		/**
		 * @since java_sdk_v2-6-14
		 * @return (non-tricky) String-representation of this sub select
		 */
		@Override
		public String toString()
		{
			final StringBuilder sb = new StringBuilder();
			buildSql(sb, 1, false, null);
			return sb.toString();
		}
	}

	/**
	 * Private constructor used in firsNRows factory method
	 * @param maxRows
	 */
	private CSQLWhereConstructor(int maxRows)
	{
		m_nMaxFirstRowsToReturn = Integer.valueOf(maxRows);
	}

	/**
	 * Empty constructor. Use add-methods to build SQL Filter
	 */
	public CSQLWhereConstructor()
	{
		super();
		m_nMaxFirstRowsToReturn = null;
	}

	/**
	 * Copy constructor
	 * @param cloneMe
	 */
	public CSQLWhereConstructor(CSQLWhereConstructor cloneMe)
	{
		m_oneLevelWhereExpression.clear();
		m_oneLevelWhereExpression.addAll(cloneMe.m_oneLevelWhereExpression);
		m_nMaxFirstRowsToReturn = cloneMe.m_nMaxFirstRowsToReturn;
	}

	protected List<FilterElement> getFirstLevelWhereExpressions()
	{
		return m_oneLevelWhereExpression;
	}

	public boolean isEmpty()
	{
		return m_oneLevelWhereExpression == null || m_oneLevelWhereExpression.isEmpty();
	}

	/**
	 * Static factory method for the most used SQL Filter.
	 * Composes a filter of form "NAME = VALUE".
	 * But you can still use add-methods to append SQL Filter.
	 * @param sFieldName
	 * @param fieldValue
	 * @return this
	 */
	public static CSQLWhereConstructor equals(String sFieldName, Object fieldValue)
	{
		return new CSQLWhereConstructor()
			.andEquals(sFieldName, fieldValue);
	}

	/**
	 * Static factory method for the most used SQL Filter.
	 * Composes a filter of form "NAME = VALUE".
	 * But you can still use add-methods to append SQL Filter.
	 * @param sFieldName
	 * @param sFieldValue
	 * @return this
	 */
	public static CSQLWhereConstructor equals(String sFieldName, String sFieldValue)
	{
		return new CSQLWhereConstructor()
			.andEquals(sFieldName, sFieldValue);
	}

	/**
	 * Static factory method for the most used SQL Filter.
	 * Composes a filter of form "NAME = VALUE".
	 * But you can still use add-methods to append SQL Filter.
	 * @param sFieldName
	 * @param nFieldValue
	 * @return this
	 */
	public static CSQLWhereConstructor equals(String sFieldName, int nFieldValue)
	{
		return new CSQLWhereConstructor()
			.andEquals(sFieldName, nFieldValue);
	}

	public static CSQLWhereConstructor equals(String sFieldName, char cFieldValue)
	{
		return new CSQLWhereConstructor()
			.andEquals(sFieldName, cFieldValue);
	}

	/**
	 * Static factory method for the most used SQL Filter.
	 * Composes a filter of form "NAME = VALUE".
	 * But you can still use add-methods to append SQL Filter.
	 * @param sFieldName
	 * @param nFieldValue
	 * @return this
	 */
	public static CSQLWhereConstructor equals(String sFieldName, Integer nFieldValue)
	{
		return new CSQLWhereConstructor()
			.andEquals(sFieldName, nFieldValue);
	}

	/**
	 * Static factory method for building SQL filter "WHERE ROWID = 'QASDGFGDFGDF'"
	 *
	 * @param sRowId	Actually this is result of Pl/Sql function `RowIdToChar(rowid)`.
	 * @return this
	 */
	public static CSQLWhereConstructor rowid(String sRowId)
	{
		return new CSQLWhereConstructor()
			.andToFilterEqual("ROWID", sRowId);
	}

	/**
	 * Clear filter.
	 * @deprecated	Such usage is dangerous. Create a new filter instead.
	 */
	public void emptyFilter()
	{
		m_oneLevelWhereExpression.clear();
	}

	/**
	 * Adds <code>AND</code> operation to filter with <code>double</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilter(String sFieldName, int nCondition, double value)
	{
		return addSectionToFilter(sFieldName, nCondition, new Double(value), OPERATION_AND);
	}

	/**
	 * Adds <code>OR</code> operation to filter with <code>double</code> value.
	 * <p>
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor orToFilter(String sFieldName, int nCondition, double value)
	{
		return addSectionToFilter(sFieldName, nCondition, new Double(value), OPERATION_OR);
	}

	/**
	 * Adds <code>AND</code> operation to filter with <code>Object</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilter(String sFieldName, int nCondition, Object value)
	{
		return addSectionToFilter(sFieldName, nCondition, value, OPERATION_AND);
	}

	/**
	 * Adds <code>OR</code> operation to filter with <code>Object</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor orToFilter(String sFieldName, int nCondition, Object value)
	{
		return addSectionToFilter(sFieldName, nCondition, value, OPERATION_OR);
	}

	/**
	 * Adds <code>AND</code> operation to filter with <code>float</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilter(String sFieldName, int nCondition, float value)
	{
		return addSectionToFilter(sFieldName, nCondition, new Double(value), OPERATION_AND);
	}

	/**
	 * Adds <code>OR</code> operation to filter with <code>float</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor orToFilter(String sFieldName, int nCondition, float value)
	{
		return addSectionToFilter(sFieldName, nCondition, new Double(value), OPERATION_OR);
	}

	/**
	 * Adds <code>AND</code> operation to filter with <code>int</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilter(String sFieldName, int nCondition, int value)
	{
		return addSectionToFilter(sFieldName, nCondition, Long.valueOf(value), OPERATION_AND);
	}

	/**
	 * Adds <code>OR</code> operation to filter with <code>int</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor orToFilter(String sFieldName, int nCondition, int value)
	{
		return addSectionToFilter(sFieldName, nCondition, Long.valueOf(value), OPERATION_OR);
	}

	/**
	 * Adds <code>AND</code> operation to filter with <code>long</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilter(String sFieldName, int nCondition, long value)
	{
		return addSectionToFilter(sFieldName, nCondition, Long.valueOf(value), OPERATION_AND);
	}

	/**
	 * Adds <code>OR</code> operation to filter with <code>long</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor orToFilter(String sFieldName, int nCondition, long value)
	{
		return addSectionToFilter(sFieldName, nCondition, Long.valueOf(value), OPERATION_OR);
	}

	public CSQLWhereConstructor andToFilterEqual(String sFieldName, long value)
	{
		return andEquals(sFieldName, value);
	}

	public CSQLWhereConstructor andEquals(String sFieldName, long value)
	{
		return andEquals(sFieldName, Long.valueOf(value));
	}

	public CSQLWhereConstructor andToFilterEqual(String sFieldName, double value)
	{
		return andEquals(sFieldName, value);
	}

	public CSQLWhereConstructor andEquals(String sFieldName, double value)
	{
		return andEquals(sFieldName, new Double(value));
	}

	public CSQLWhereConstructor andToFilterEqual(String sFieldName, int value)
	{
		return andEquals(sFieldName, value);
	}

	public CSQLWhereConstructor andEquals(String sFieldName, int value)
	{
		return andEquals(sFieldName, Integer.valueOf(value));
	}

	public CSQLWhereConstructor andEquals(String sFieldName, char value)
	{
		return andEquals(sFieldName, Character.valueOf(value));
	}

	/**
	 * Adds <code>AND</code> operation to filter with <code>Object</code> value
	 * and condtition <code>COND_EQUAL</code>.
	 *
	 * @param sFieldName	name of field.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilterEqual(String sFieldName, Object value)
	{
		return andEquals(sFieldName, value);
	}

	public CSQLWhereConstructor andEquals(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_EQUAL, value, OPERATION_AND);
	}

	public CSQLWhereConstructor andGreater(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_GREATER, value, OPERATION_AND);
	}

	public CSQLWhereConstructor andGreaterEqual(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_GREATER_EQUAL, value, OPERATION_AND);
	}

	public CSQLWhereConstructor andLess(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_LESS, value, OPERATION_AND);
	}

	public CSQLWhereConstructor andLessEqual(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_LESS_EQUAL, value, OPERATION_AND);
	}

	public CSQLWhereConstructor andNotEqual(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_NOT_EQUAL, value, OPERATION_AND);
	}

	public CSQLWhereConstructor andLike(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_LIKE, value, OPERATION_AND);
	}

	public CSQLWhereConstructor andNotLike(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_NOT_LIKE, value, OPERATION_AND);
	}

	/**
	 * Adds <code>OR</code> operation to filter with <code>Object</code> value
	 * and condtition <code>COND_EQUAL</code>.
	 *
	 * @param sFieldName	name of field.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor orToFilterEqual(String sFieldName, Object value)
	{
		return orEquals(sFieldName, value);
	}

	public CSQLWhereConstructor orEquals(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_EQUAL, value, OPERATION_OR);
	}

	public CSQLWhereConstructor orGreater(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_GREATER, value, OPERATION_OR);
	}

	public CSQLWhereConstructor orGreaterEqual(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_GREATER_EQUAL, value, OPERATION_OR);
	}

	public CSQLWhereConstructor orLess(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_LESS, value, OPERATION_OR);
	}

	public CSQLWhereConstructor orLessEqual(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_LESS_EQUAL, value, OPERATION_OR);
	}

	public CSQLWhereConstructor orNotEqual(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_NOT_EQUAL, value, OPERATION_OR);
	}

	public CSQLWhereConstructor orLike(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_LIKE, value, OPERATION_OR);
	}

	public CSQLWhereConstructor orNotLike(String sFieldName, Object value)
	{
		return addSectionToFilter(sFieldName, COND_NOT_LIKE, value, OPERATION_OR);
	}

	/**
	 * Adds <code>AND</code> operation to filter with String value
	 * and condtition <code>COND_EQUAL</code>.
	 *
	 * @param sFieldName	name of field.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilterEqual(String sFieldName, String value)
	{
		return andEquals(sFieldName, value);
	}
	
	public CSQLWhereConstructor andToFilterEqualIgnoreCase(String sFieldName, String value) 
	{
		return andEqualsIgnoreCase(sFieldName, value);
	}

	/**
	 * Adds condition AND [Field name] IS NOT NULL
	 * <p>
	 * @param sFieldName	name of field.
	 * @return <code>CSQLWhereConstructor</code> object.
	 */
	public CSQLWhereConstructor andToFilterNotNull(String sFieldName)
	{
		return andToFilter(sFieldName, COND_NOT_EQUAL, null);
	}

	public CSQLWhereConstructor andEquals(String sFieldName, String value)
	{
		return addSectionToFilter(sFieldName, COND_EQUAL, value, OPERATION_AND);
	}
	
	public CSQLWhereConstructor andEqualsIgnoreCase(String sFieldName,	String value) 
	{
		return addSectionToFilter("UPPER(" + sFieldName + ")", COND_EQUAL, value.toUpperCase(), OPERATION_AND);
	}

	/**
	 * Adds <code>OR</code> operation to filter with String value
	 * and condtition <code>COND_EQUAL</code>.
	 *
	 * @param sFieldName	name of field.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor orToFilterEqual(String sFieldName, String value)
	{
		return orEquals(sFieldName, value);
	}

	public CSQLWhereConstructor orEquals(String sFieldName, String value)
	{
		return addSectionToFilter(sFieldName, COND_EQUAL, value, OPERATION_OR);
	}

	/**
	 * Adds <code>AND</code> operation to filter with uppercase <code>String</code> value
	 * and condtition <code>COND_EQUAL</code>.
	 *
	 * Comparing is uppercase.
	 * <p>
	 * @param sFieldName	name of field.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilterUpperEqual(String sFieldName, String value)
	{
		return addSectionToFilter( sFieldName, COND_EQUAL_UPPER, value, OPERATION_AND);
	}

	/**
	 * <p>
	 * Adds <code>AND</code> operation to filter with uppercase <code>String</code> value
	 * and condtition <code>COND_LIKE</code>.
	 * </p>
	 * <p>
	 * Comparing is uppercase.<br>
	 * Result of this search will give all strings that contains part of specified value.
	 * </p>
	 *
	 * @param sFieldName	name of field.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilterUpperLike(String sFieldName, String value)
	{
		return addSectionToFilter(sFieldName, COND_UPPER_LIKE, value, OPERATION_AND);
	}

	/**
	 * <p>
	 * Adds <code>AND</code> operation to filter with uppercase <code>String</code> value
	 * and condtition <code>COND_LIKE</code>.
	 * </p>
	 * <p>
	 * Comparing is uppercase.<br>
	 * Result of this search will give all string that starts with specified value.
	 * </p>
	 * @param sFieldName	name of field.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilterUpperBegins(String sFieldName, String value)
	{
		return addSectionToFilter(sFieldName, COND_UPPER_BEGINS, value, OPERATION_AND);
	}

	public CSQLWhereConstructor andToFilterTrimUpperEqual(String sFieldName, String value)
	{
		return addSectionToFilter(sFieldName, COND_EQUAL_TRIM_UPPER, value, OPERATION_AND);
	}

	/**
	 * Adds <code>AND</code> operation to filter with <code>String</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andToFilter(String sFieldName, int nCondition, String value)
	{
		return addSectionToFilter(sFieldName, nCondition, value, OPERATION_AND);
	}

	/**
	 * Adds <code>AND</code> operation to filter with <code>String</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor andStringToFilterAsIs(String sFieldName, int nCondition, String value)
	{
		return addSectionToFilter(sFieldName, nCondition, value, OPERATION_AND, true);
	}

	/**
	 * Adds <code>OR</code> operation to filter with <code>String</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor orToFilter(String sFieldName, int nCondition, String value)
	{
		return addSectionToFilter(sFieldName, nCondition, value, OPERATION_OR);
	}

	/**
	 * Adds <code>OR</code> operation to filter with <code>String</code> value.
	 *
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			for condition.
	 * @return this
	 */
	public CSQLWhereConstructor orStringToFilterAsIs(String sFieldName, int nCondition, String value)
	{
		return addSectionToFilter(sFieldName, nCondition, value, OPERATION_OR, true);
	}

	/**
	 * Adds <code>AND</code> operation to filter with specified subselect, which
	 * is built from the given CSQLWhereConstructor, subselect field name and
	 * subselect table name. Subselect is inserted using IN condition.
	 *
	 * @param sFieldName name of field
	 * @param cSQLSubSelect WHERE clause of the subselect
	 * @param sSubSelectFieldName field name to select from subselect
	 * @param sSubSelectTableName table name from where subselect is selected
	 * @return this
	 */
	public CSQLWhereConstructor andInSubSelect(String sFieldName,
		CSQLWhereConstructor cSQLSubSelect, String sSubSelectFieldName, String sSubSelectTableName)
	{
		return addSectionToFilter(sFieldName, COND_IN,
			new CSubSelect(cSQLSubSelect, sSubSelectFieldName, sSubSelectTableName), OPERATION_AND);
	}

	/**
	 * Adds <code>OR</code> operation to filter with specified subselect, which
	 * is built from the given CSQLWhereConstructor, subselect field name and
	 * subselect table name. Subselect is inserted using IN condition.
	 *
	 * @param sFieldName name of field
	 * @param cSQLSubSelect WHERE clause of the subselect
	 * @param sSubSelectFieldName field name to select from subselect
	 * @param sSubSelectTableName table name from where subselect is selected
	 * @return this
	 */
	public CSQLWhereConstructor orInSubSelect(String sFieldName, CSQLWhereConstructor cSQLSubSelect, String sSubSelectFieldName, String sSubSelectTableName)
	{
		return addSectionToFilter(sFieldName, COND_IN,
			new CSubSelect(cSQLSubSelect, sSubSelectFieldName, sSubSelectTableName), OPERATION_OR);
	}

	/**
	 * Adds <code>AND</code> operation and nested SQL constructor.
	 *
	 * @param cSQL	nested contructor
	 * @return this
	 */
	public CSQLWhereConstructor andNestedSQLConstructor(CSQLWhereConstructor cSQL)
	{
		return addSectionToFilter(null, COND_NESTED_FILTER, cSQL, OPERATION_AND);
	}

	/**
	 * Adds <code>OR</code> operation and nested SQL constructor.
	 *
	 * @param cSQL	nested contructor
	 * @return this
	 */
	public CSQLWhereConstructor orNestedSQLConstructor(CSQLWhereConstructor cSQL)
	{
		return addSectionToFilter(null, COND_NESTED_FILTER, cSQL, OPERATION_OR);
	}

	protected CSQLWhereConstructor addSectionToFilter(String sFieldName, int nCondition, Object value, int nOperation)
	{
		return addSectionToFilter(sFieldName, nCondition, value, nOperation, false);
	}

	/**
	 * Adds <code>Object</code> section to filter.
	 * <p>
	 * @param sFieldName	name of field.
	 * @param nCondition	type.
	 * @param value			section.
	 * @param nOperation	type.
	 */
	protected CSQLWhereConstructor addSectionToFilter(String sFieldName, int nCondition, Object value, int nOperation, boolean asIs)
	{
		int op = nOperation;
		if (m_oneLevelWhereExpression.isEmpty())
		{
			// This is the first statement in SQL
			op = OPERATION_NULL;
		}

		m_oneLevelWhereExpression.add(
			new FilterElement(sFieldName, nCondition, value, op, asIs));

		return this;
	}


	/**
	 * Static factory method for creating filter "rowid <= N".
	 *
	 * @param rows
	 * @return this
	 */
	public static CSQLWhereConstructor firstNRows(int rows)
	{
		return new CSQLWhereConstructor(rows);
	}

	/**
	 * @return the maximum amount of rows could be fetched
	 * during the current condition execution
	 */
	public Integer getMaxFirstRowsToReturn()
	{
		return m_nMaxFirstRowsToReturn;
	}

	public String toString(boolean buildTrickySql)
	{
		if (buildTrickySql)
			return toString();

		String sTrickyFilter = toString();
		CSQLWhereFilter filter = parseTrickSql(sTrickyFilter);
		return filter.buildUnbindedSql();
	}

	/**
	 * Returns a special `tricky` SQL string which will be later parsed by class
	 * CSQLWhereParser. This trick is done because this method toStirng() was
	 * historically used in many-many classes, but we want now to bind variables.
	 *
	 * @see	CSQLWhereConstructorTest (Unit test)
	 *
	 * @return 	SQL string.
	 */
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder(HEADER_TRICKY_FILTER);
		buildSql(sb, 1, true, null);
		return sb.toString();
	}

	// public String toString(PRINT_MODE)

	int buildSql(StringBuilder sbSelect, int nStartIndex, boolean bTrickySql, CSQLWhereFilter sqlFilter)
	{
		int nIndex = nStartIndex;
		for (FilterElement elem : m_oneLevelWhereExpression)
		{
			nIndex = elem.toString(sbSelect, nIndex, bTrickySql, sqlFilter);
		}

		return nIndex;
	}

	public static boolean isTrickySql(String sTrickySql)
	{
		return sTrickySql != null &&
				(sTrickySql.indexOf(HEADER_TRICKY_FILTER) > -1);
	}

	public static String extractClearSql(String sTrickySql)
	{
		String sClearSql = sTrickySql;
		int j = sClearSql.indexOf(HEADER_TRICKY_FILTER);
		if (j > -1)
		{
			sClearSql = sClearSql.substring(0, j) +
				sClearSql.substring(j + HEADER_TRICKY_FILTER.length());
		}

		return sClearSql;
	}

	static boolean hasConditions(String sTrickySql)
	{
		if (sTrickySql == null || sTrickySql.trim().length() < 1)
			return false;

		String sClearSql = extractClearSql(sTrickySql);
		return (sClearSql != null && sClearSql.trim().length() > 0);
	}

	static CSQLWhereFilter parseTrickSql(String sTrickSqlClause) throws NumberFormatException
	{
		if (!isTrickySql(sTrickSqlClause))
			return new CSQLWhereFilter(sTrickSqlClause);

		String sClearSqlClause = extractClearSql(sTrickSqlClause);
		CSQLWhereFilter sqlFilter = new CSQLWhereFilter();

		StringBuilder sb = new StringBuilder();
		int index = 0;
		int colon = sClearSqlClause.indexOf(':');
		while (colon > -1)
		{
			//If colon is surrounded by commas it means that it is a part of string literal
			//and not a part of a binding variable.
			if (isInsideQuotes(sClearSqlClause, index, colon))
			{
				colon = sClearSqlClause.indexOf(":", colon + 1);
				continue;
			}

			int nLeftBrace = sClearSqlClause.indexOf("[", colon);
			int nRightBrace = sClearSqlClause.indexOf("]", nLeftBrace);
			int nLeftBrace2 = sClearSqlClause.indexOf("[", nRightBrace);
			int nRightBrace2 = sClearSqlClause.indexOf("]", nLeftBrace2);

			sb.append( sClearSqlClause.substring(index, nLeftBrace) );

			Integer nVariableNumber = Integer.valueOf(sClearSqlClause.substring(colon+1, nLeftBrace));
			Integer sVariableType = Integer.valueOf(sClearSqlClause.substring(nLeftBrace+1, nRightBrace));
			String sVariableValue = sClearSqlClause.substring(nLeftBrace2+1, nRightBrace2);

			sqlFilter.addVariable(nVariableNumber, sVariableValue, sVariableType.intValue());

			index = nRightBrace2 + 1;
			colon = sClearSqlClause.indexOf(":", nRightBrace2);
		}
		sb.append( sClearSqlClause.substring(index) );
		sqlFilter.setNormalSql(sb.toString());
		return sqlFilter;
	}

	public CSQLWhereFilter build()
	{
		//String sFilterString = toString();
		//if (!hasConditions(sFilterString))
		//	return new CSQLWhereFilter("");
		//return parseTrickSql(sFilterString);

		// Build non-tricky SQL instead
		CSQLWhereFilter sql = new CSQLWhereFilter();

		StringBuilder sb = new StringBuilder();
		buildSql(sb, 1, false, sql);
		sql.setNormalSql( sb.toString() );

		return sql;
	}

	/**
	 * Method takes array of elements from <code>nIndexFrom</code> to <code>nIndexTo</code>
	 * and makes a IN-Clause String of them.
	 *
	 * For example, if
	 * 	<ol type="square">
	 * 		<li>asApplicationIDs = {"1", "2", "3", "4", "5"},</li>
	 * 		<li>nIndexFrom = 2, and</li>
	 *    <li>nIndexTo = 4,</li>
	 *	</ol>
	 * then result will be following String:
	 *		<p><code>	('3', '4', '5') </code></p>
	 *
	 * @param listValues		list with values as Objects
	 * @param nIndexFrom		>= 0
	 * @param nIndexTo			nIndexTo - nIndexFrom must be < 1000
	 * @return <code>String</code>
	 */
	private static String buildSelectInValues(List<?> listValues, int nIndexFrom, int nIndexTo)
	{
		StringBuilder sb = new StringBuilder("(");

		for (int i = nIndexFrom; i < nIndexTo; i++)
		{
			if (i > nIndexFrom)
			{
				sb.append(",");
			}

			Object o = listValues.get(i);

			if (o instanceof Integer || o instanceof Long)
			{
				sb.append(o.toString());
			}
			else
			{
				sb.append("'" + o.toString().replaceAll("'", "''") + "'");
			}
		}

		sb.append(")");

		return sb.toString();
	}

	/**
	 * Method builds an SQL clause that lists all object values.
	 * For example, if
	 * <pre>
	 * 	asApplicationIDs = {"222", "333", "444"},
	 * </pre>
	 * then
	 * result will be
	 * <pre>
	 * 	"APPLICATION_ID IN ('222', '333', '444').
	 * </pre>
	 *
	 * <br>
	 * NOTE<br>
	 * Oracle has a constraint that IN-clause cannot have more than 1000
	 * entries. So, if
	 * 		<code>asApplicationIDs = {"1", "2", ..., "1000", "1001", "1002", ..., "4536"}</code>,
	 * then result will be
	 * <pre>
	 *		OBJECT_ID IN ('1', '2', ..., '999') <br>
	 *		OR OBJECT_ID IN ('1000', '1001', ..., '1999')<br>
	 *		OR OBJECT_ID IN ('2000', '2001', ..., '2999')<br>
	 *		OR OBJECT_ID IN ('3000', '3001', ..., '3999')<br>
	 *		OR OBJECT_ID IN ('4000', '4001', ..., '4536')
	 * </pre>
	 * @see	hireright.sdk.db.CSQLWhereConstructor
	 *
	 * @param listValues		list with values as Objects.
	 * @param sFieldName 		field name.
	 * @param nOperation		opetaion type (AND / OR).
	 * @return instance of <code>CSQLWhereConstructor</code>
	 */
	private CSQLWhereConstructor addSelectInValues(List<?> listValues, String sFieldName, int nOperation)
	{
		CSQLWhereConstructor sqlConstructor = new CSQLWhereConstructor();

		for (int nIndex = 0; nIndex < Math.min(nIndex + MAX_IN_CLAUSE_SIZE, listValues.size());
				nIndex += MAX_IN_CLAUSE_SIZE)
		{
			sqlConstructor.orStringToFilterAsIs(
					sFieldName, COND_IN, buildSelectInValues(
							listValues, nIndex, Math.min(nIndex + MAX_IN_CLAUSE_SIZE, listValues.size())));
		}

		return addSectionToFilter(null, COND_NESTED_FILTER, sqlConstructor, nOperation);
	}

	/**
	 * Method builds an AND SQL clause that lists all object values.
	 * <p>
	 * @param listValues	list with values as Objects.
	 * @param sFieldName	field name.
	 * @return instance of <code>CSQLWhereConstructor</code>
	 */
	public CSQLWhereConstructor addAndSelectInValues(List<?> listValues, String sFieldName)
	{
		return addSelectInValues(listValues, sFieldName, OPERATION_AND);
	}

	public CSQLWhereConstructor andIn(String sFieldName, List<?> listValues)
	{
		return addSelectInValues(listValues, sFieldName, OPERATION_AND);
	}

	/**
	 * Method builds an OR SQL clause that lists all object values.
	 * <p>
	 * @param listValues	list with values as Objects.
	 * @param sFieldName	field name.
	 * @return instance of <code>CSQLWhereConstructor</code>
	 */
	public CSQLWhereConstructor addOrSelectInValues(List<?> listValues, String sFieldName)
	{
		return addSelectInValues(listValues, sFieldName, OPERATION_OR);
	}

	public CSQLWhereConstructor orIn(String sFieldName, List<?> listValues)
	{
		return addSelectInValues(listValues, sFieldName, OPERATION_OR);
	}

	/**
	 * Checks whether specified by position character of specified string is inside quotes.
	 * @param source source string.
	 * @param nCharNumber position of character in source string to analyze.
	 * @return true if character surrounded by commas, false otherwise. E.g.<br/>
	 * isInsideQuotes("'asdf'asfd'c'asdf", 0, 0) = false<br/>
	 * isInsideQuotes("'asdf'asfd'c'asdf", 0, 1) = true<br/>
	 * isInsideQuotes("'asdf'asfd'c'asdf", 0, 7) = false<br/>
	 * isInsideQuotes("'asdf'asfd'c'asdf", 0, 11) = true<br/>
	 * isInsideQuotes("'asdf'asfd'c'asdf", 0, 13) = false.
	 * isInsideQuotes("'asdf'asfd'c'asdf", 1, 13) = true.
	 */
	private static boolean isInsideQuotes(String source, int start, int end)
	{
		int quotesNum = 0;
		for(int i = start; i < end; i++)
		{
			i = source.indexOf('\'', i);
			if(i == -1 || i >= end) break;
			quotesNum++;
		}
		// If there are odd count of quotes then it is not inside quotes, otherwise it is inside quotes
		return !(quotesNum % 2 == 0);
	}
}