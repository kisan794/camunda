/*
 * @(#)$RCSfile: CCallableStatement.java,v $ $Revision: 1.15 $ $Date: 2015/04/18 09:16:20 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CCallableStatement.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 2001-11-15 S.Ignatov 		added to java_sdk_db from revision 1.2
 * 2002-09-03	S.Ignatov		setDate(int parameterIndex, java.util.Date x) added
 * 2002-09-26	S.Ignatov		oracle.jdbc.driver.OracleCallableStatement replaced with oracle.jdbc.OracleCallableStatement
 * 2005-08-23	A.Solntsev		Now all setters return this.
 * 2005-10-12	A.Solntsev		Casting to OracleCallableStatement is deprecated
 * 2006-06-12	A.Solntsev		Extends CClosableObject, implements IHasProperties
 * 2008-04-22	A.Solntsev		closeSilently(): added check for null
 * 2009-08-24	M.Abdulganejev		setDouble() added
 * 2014-04-17	M.Suhhoruki	closeSilently made public
 * 2015-03-24	Y.Halinouski	add setNString()
 */
package hireright.sdk.db;
import hireright.sdk.db2.CConnectionWrapper;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.IHasProperties;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OraclePreparedStatement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Simple wrapper to class java.sql.CallableStatement with 2 features:
 * 1. Null-safety. Every set-method check parameter for null and calls
 * 		setNull() method on original CallableStatement.
 * 2. Possibility of functional-style declarations. Thanks to every set-method
 * 		returns this, it's possible to call set-methods in a single row:
 * 
 * CCallableStatement stmt =
 * 		new CCallableStatement("{begin; call xxx...; end;}")
 * 			.setString(1, "AAA")
 *  		.setInteger(2, "BBB")
 *  		.registerOutParameter(3, Types.VARCHAR)
 *  		.execute();
 * 
 * @date	2001/11/15
 * @author	Sergei Ignatov
 * @version $Revision: 1.15 $ $Date: 2015/04/18 09:16:20 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CCallableStatement.java,v $
 */
@SuppressWarnings("serial")
public class CCallableStatement extends CClosableObject implements IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.15 $ $Author: cvsroot $";
	
	private final CallableStatement m_cstmt;
	
	private static final Log LOG = LogFactory.getLog(CCallableStatement.class);
	
	/**
	 * This variable becomes false when statement is opened (executed) until it's closed.
	 * It should be used in method finalize() for checking if statement was properly closed.
	 * 
	 * @see CClosableObject#isClosed()
	 */
	private boolean m_isClosed = true;
	
	/**
	 * This members holds all variables binded in this callable statement.
	 * They are used only for logging errors and warnings.
	 */
	private Map<Integer, Object> m_bindedVariables = new HashMap<Integer, Object>();
		
	public CCallableStatement(CallableStatement cstmt)
	{
		super(CCallableStatement.class);
		m_cstmt = cstmt;
	}
	
	public CCallableStatement execute() throws SQLException
	{
		onOpened(String.valueOf(m_bindedVariables));
		
		m_cstmt.execute();	// Result is ignored.
		m_isClosed = false;
		return this;
	}
	
	public CCallableStatement close() throws SQLException
	{
		try
		{
			m_cstmt.close();
		}
		finally
		{
			m_isClosed = true;
		}
		
		return this;
	}
	
	@Override
	public void closeSilently()
	{
		try
		{
			if (m_cstmt != null)
				m_cstmt.close();
		}
		catch (SQLException sqle)
		{
			LOG.warn(sqle.getMessage(), sqle);
		}
		finally
		{
			m_isClosed = true;
		}
	}
	
	private void bind(int nIndex, Object value)
	{
		if (value == null)
			m_bindedVariables.put(new Integer(nIndex), "null");
		else
			m_bindedVariables.put(new Integer(nIndex), value);
	}
	
	public CCallableStatement setString(int parameterIndex, String x) 
		throws SQLException
	{
		bind(parameterIndex, x);
		if (x != null)
			m_cstmt.setString(parameterIndex, x);
		else
			m_cstmt.setNull(parameterIndex, Types.VARCHAR );
		
		return this;
	}
	
	public CCallableStatement setNString(int parameterIndex, String x) throws SQLException
	{
		OraclePreparedStatement ost = CConnectionWrapper.unwrapOracleStatement(m_cstmt);
		if (ost != null)
		{
			ost.setFormOfUse(parameterIndex, OraclePreparedStatement.FORM_NCHAR);
		}
		else
		{
			StringBuilder sb = new StringBuilder();
			CConnectionWrapper.unwrapOracleStatement(m_cstmt, sb);
			LOG.error("Unable to unwrap oracle statement from chain:\n" + sb.toString());
		}

		bind(parameterIndex, x);
		if (x != null)
			m_cstmt.setString(parameterIndex, x);
		else
			m_cstmt.setNull(parameterIndex, Types.VARCHAR);

		return this;
	}
	
	public CCallableStatement setDate(int parameterIndex, java.util.Date x) 
		throws SQLException
	{
		bind(parameterIndex, x);
		if (x != null)
			m_cstmt.setTimestamp(parameterIndex, new Timestamp(x.getTime()));
		else
			m_cstmt.setNull(parameterIndex, Types.TIMESTAMP);

		return this;
	}
	
	public CCallableStatement setDouble(int parameterIndex, double x) 
	throws SQLException
	{
		bind(parameterIndex, x);
		m_cstmt.setDouble(parameterIndex, x);
	
		return this;
	}
	
	public CCallableStatement setDouble(int parameterIndex, Double x) 
	throws SQLException
	{
		bind(parameterIndex, x);
		if (x != null)
			m_cstmt.setDouble(parameterIndex, x.doubleValue());
		else
			m_cstmt.setNull(parameterIndex, Types.DOUBLE );
		
		return this;
	}
	
	public CCallableStatement setInteger(int parameterIndex, Integer x) 
		throws SQLException
	{
		bind(parameterIndex, x);
		if (x != null)
			m_cstmt.setInt(parameterIndex, x.intValue());
		else
			m_cstmt.setNull(parameterIndex, Types.NUMERIC );
		
		return this;
	}
	
	public CCallableStatement setInteger(int parameterIndex, int x) 
		throws SQLException
	{
		bind(parameterIndex, new Integer(x));
		m_cstmt.setInt(parameterIndex, x);
		return this;
	}
	
	public CCallableStatement setLong(int parameterIndex, Long x) 
		throws SQLException
	{
		bind(parameterIndex, x);
		if (x != null)
			m_cstmt.setLong(parameterIndex, x.longValue());
		else
			m_cstmt.setNull(parameterIndex, Types.NUMERIC );
		
		return this;
	}
	
	public CCallableStatement setLong(int parameterIndex, long x)
		throws SQLException
	{
		bind(parameterIndex, new Long(x));
		m_cstmt.setLong(parameterIndex, x);
		return this;
	}
	
	/**
	 * @deprecated	Don't use this method because CallableStatement is often
	 * not OracleCallableStatement but wrapper like P6SpyCallableStatement
	 * which delegates to OracleCallableStatement. 
	 */
	public CCallableStatement setOracleStruct(int parameterIndex, oracle.sql.STRUCT x)
		throws SQLException
	{
		bind(parameterIndex, x);
		OracleCallableStatement oracleStmt = (OracleCallableStatement) m_cstmt;
		oracleStmt.setOracleObject(parameterIndex, x);
		return this;
	}
	
	public CCallableStatement registerOutParameter(int parameterIndex, int sqlType, int scale) 
		throws SQLException
	{
		m_cstmt.registerOutParameter(parameterIndex, sqlType, scale);
		return this;
	}
	
	public CCallableStatement registerOutParameter(int parameterIndex, int sqlType) 
		throws SQLException
	{
		m_cstmt.registerOutParameter(parameterIndex, sqlType);
		return this;
	}
	
	/**
	 * @deprecated	Don't use this method because CallableStatement is often
	 * not OracleCallableStatement but wrapper like P6SpyCallableStatement
	 * which delegates to OracleCallableStatement. 
	 */
	public CCallableStatement registerOracleOutParameter(int parameterIndex, int oracleSqlType) 
		throws SQLException
	{
		OracleCallableStatement oracleStmt = (OracleCallableStatement) m_cstmt;
		oracleStmt.registerOutParameter(parameterIndex, oracleSqlType);
		return this;
	}
	
	/**
	 * @deprecated	Don't use this method because CallableStatement is often
	 * not OracleCallableStatement but wrapper like P6SpyCallableStatement
	 * which delegates to OracleCallableStatement. 
	 */
	public CCallableStatement registerOracleOutParameter(int parameterIndex, int oracleSqlType, String x) 
		throws SQLException
	{
		OracleCallableStatement oracleStmt = (OracleCallableStatement) m_cstmt;
		oracleStmt.registerOutParameter(parameterIndex, oracleSqlType, x);
		return this;
	}
	
	protected Object retNull(Object obj)
		throws SQLException
	{
		return m_cstmt.wasNull() ? null : obj;
	}
	
	public String getString(int parameterIndex) throws SQLException
	{
		return (String) retNull(m_cstmt.getString(parameterIndex));
	}

	public Integer getInteger(int parameterIndex) throws SQLException
	{
		return (Integer) retNull(new Integer(m_cstmt.getInt(parameterIndex)));
	}
	
	public Long getLong(int parameterIndex) throws SQLException
	{
		return (Long) retNull(new Long(m_cstmt.getLong(parameterIndex)));
	}
	
	public Float getFloat(int parameterIndex) throws SQLException
	{
		return (Float) retNull(new Float(m_cstmt.getFloat(parameterIndex)));
	}
	
	public java.sql.Date getDate(int parameterIndex) throws SQLException
	{
		return (java.sql.Date) retNull(m_cstmt.getDate(parameterIndex));
	}
	
	/**
	 * @deprecated	Don't use this method because CallableStatement is often
	 * not OracleCallableStatement but wrapper like P6SpyCallableStatement
	 * which delegates to OracleCallableStatement. 
	 */
	public oracle.sql.STRUCT getOracleStruct(int parameterIndex) throws SQLException
	{
		OracleCallableStatement oracleStmt = (OracleCallableStatement) m_cstmt;
		return oracleStmt.getSTRUCT(parameterIndex);
	}
	
	/**
	 * @see CClosableObject#isClosed()
	 * @since java_sdk_v2-6-13
	 */
	@Override
	protected boolean isClosed()
	{
		return m_isClosed;
	}
	
	/**
	 * @since java_sdk_v2-6-13
	 */
	public CProperties toProperties()
	{
		Map<String, Object> keyValues = new HashMap<String, Object>(m_bindedVariables.size());
		for (Map.Entry<Integer, Object> entry : m_bindedVariables.entrySet())
		{
			keyValues.put(entry.getKey().toString(), entry.getValue());
		}
		return new CProperties(keyValues);
	}
	
	@Override
	public String toString()
	{
		return "Callable Statement " + m_bindedVariables;
	}
}	

