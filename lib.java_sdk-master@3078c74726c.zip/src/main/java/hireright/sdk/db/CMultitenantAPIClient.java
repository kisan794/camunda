/*
 * Copyright 2001-2024 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * V.Ozernov				2024-07-04	HRG-314543 Created
 */
package hireright.sdk.db;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.Callable;

/**
 * All interactions with shared library multi_tenant_api.jar are here.
 * This class interacts with multi_tenant_api.jar using Java Reflections
 * and supports a mode when multi_tenant_api.jar is not provided.
 * CMultitenantDB shouldn't use the library directly.
 */
public class CMultitenantAPIClient
{
	private static Object tenantContentRoot = null;
	private static CAPIMethodRefs apiMethodRefs = null;
	
	protected static boolean isAPISupported()
	{
		return getAPIMethodRefs().isFound();
	}
	
	protected static String getCurrentTenantCode()
	{
		if (!isAPISupported())
		{
			return null;
		}
		
		try
		{
			return (String)getAPIMethodRefs().methodGetCurrentTenantCode.invoke(null);
		} catch(IllegalAccessException | InvocationTargetException e)
		{
			throw new CRuntimeException(e);
		}
	}
	
	/**
	 * Execute a callable using connection to container of provided tenant.
	 * E.g. for tenant code "ubs" and root container "hr2" tenant container service name is "hr2ubs"
	 *
	 * @param tenantCode - tenant code for PDB container or null/"" for root container
	 */
	protected static <T> T doExecuteInTenantContainer(String tenantCode, Callable<T> callable) throws Exception
	{
		if (!isAPISupported())
		{
			throw new IllegalStateException("Multitenant API is not supported");
		}
		try
		{
			@SuppressWarnings("unchecked")
			T result = (T) getAPIMethodRefs().methodCallWithContext.invoke(null, createTenantContext(tenantCode), callable);
			return result;
		}
		catch (InvocationTargetException e)
		{
			Throwable targetException = e.getTargetException();
			if (targetException instanceof Exception)
			{
				throw (Exception)targetException;
			}
			else
			{
				throw CRuntimeException.wrap(targetException);
			}
		}
	}
	
	private static Object createTenantContext(String tenantCode)
			throws IllegalAccessException, InvocationTargetException, InstantiationException
	{
		if (CStringUtils.isEmpty(tenantCode))
		{
			if (tenantContentRoot == null)
			{
				tenantContentRoot = getAPIMethodRefs().constructorTenantContext.newInstance(new Object[]{null});
			}
			return tenantContentRoot;
		}
		else
		{
			return getAPIMethodRefs().constructorTenantContext.newInstance(tenantCode.toLowerCase());
		}
	}
	
	protected static void resetTenantContext()
	{
		if (isAPISupported())
		{
			try
			{
				getAPIMethodRefs().methodSetCurrentContext.invoke(null, new Object[]{null});
			} catch(IllegalAccessException | InvocationTargetException e)
			{
				throw new CRuntimeException(e);
			}
		}
	}
	
	private static CAPIMethodRefs getAPIMethodRefs()
	{
		if (apiMethodRefs == null)
		{
			apiMethodRefs = loadAPIMethodRefs();
			if (!apiMethodRefs.isFound())
			{
				CTraceLog.warning("Multitenancy mode is not supported since no multi_tenant_api.jar is provided", CMultitenantAPIClient.class.getName() + ".getAPIMethodRefs");
			}
		}
		
		return apiMethodRefs;
	}
	
	private static synchronized CAPIMethodRefs loadAPIMethodRefs()
	{
		try
		{
			Class<?> classTenantContextHolder = Class.forName("hireright.datasource.multi_tenant.TenantContextHolder");
			Class<?> classTenantContext = Class.forName("hireright.datasource.multi_tenant.TenantContext");
			Method methodGetCurrentTenantCode = classTenantContextHolder.getMethod("getCurrentTenantCode");
			Method methodSetCurrentContext = classTenantContextHolder.getMethod("setCurrentContext", classTenantContext);
			Method methodCallWithContext = classTenantContextHolder.getMethod("callWithContext", classTenantContext, Callable.class);
			Constructor<?> constructorTenantContext = classTenantContext.getConstructor(String.class);
			return new CAPIMethodRefs(methodGetCurrentTenantCode, methodSetCurrentContext,
					methodCallWithContext, constructorTenantContext);
		}
		catch(ClassNotFoundException e)
		{
			return CAPIMethodRefs.UNSUPPORTED;
		}
		catch(NoSuchMethodException e)
		{
			throw new CRuntimeException(e);
		}
	}
	
	private static class CAPIMethodRefs
	{
		static final CAPIMethodRefs UNSUPPORTED = new CAPIMethodRefs(null, null, null, null);
		final Method methodGetCurrentTenantCode;
		final Method methodSetCurrentContext;
		final Method methodCallWithContext;
		final Constructor<?> constructorTenantContext;
		
		CAPIMethodRefs(Method methodGetCurrentTenantCode, Method methodSetCurrentContext,
				Method methodCallWithContext, Constructor<?> constructorTenantContext)
		{
			this.methodGetCurrentTenantCode = methodGetCurrentTenantCode;
			this.methodSetCurrentContext = methodSetCurrentContext;
			this.methodCallWithContext = methodCallWithContext;
			this.constructorTenantContext = constructorTenantContext;
		}
		
		boolean isFound()
		{
			return methodGetCurrentTenantCode != null;
		}
	}
}
