/*
 * @(#)$RCSfile: CFTable.java,v $ $Revision: 1.18 $ $Date: 2010/02/04 21:16:20 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CFTable.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Nesterov			2002-02-04	created
 *	A.Solntsev			2004-09-24	added statistics about subclasses.
 *	A.Solntsev			2004-10-26	added "synchronized (htSubclasses)"
 *	A.Solntsev			2005-06-02	Added more methods for monitoring instances.
 *	A.Solntsev			2005-06-08	Added method getPrimaryKeyColumn()
 *	A.Solntsev			2005-07-25	Added support for schema name (beta version).
 *	A.Solntsev			2005-08-16	Added support for array of columns.
 *	A.Solntsev			2006-05-11	Constructor with Connection is deprecated now.
 *	A.Solntsev			2006-10-31	Removed java.sql.Connection member; fixed javadoc.
 *	A.Solntsev			2008-10-10	Fixed NPE in method finalize()
 *	A.Solntsev			2009-12-09	Removed method finalize()
 *	A.Solntsev			2010-01-20	Constructors with Connection are deprecated again
 */
package hireright.sdk.db;
import hireright.sdk.util.CMultiSet;
import java.io.Serializable;
import java.sql.Connection;
import java.util.Date;

/**
 * A Base class for CFSomeTable clases.
 *
 * @author Alexander Nesterov 
 */
public class CFTable extends CCompositeTable implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.18 $ $Author: cvsroot $";
	
	/**
	 * If all columns need to be read/written, this keyword is used.
	 * It corresponds to SQL command "SELECT * FROM TABLE".
	 */
	public static final String ALL_COLUMNS = "*";

	private static Date m_dtStarted = new Date();
	
	@Deprecated
	public static final CMultiSet<String> getStatisticsCreated()
	{
		return null;
	}
	
	@Deprecated
	public static final CMultiSet<String> getStatisticsFinalized()
	{
		return null;
	}

	public static Date getDateStarted()
	{
		return m_dtStarted;
	}
	
	public static final String FIELD_ROWNUM	= "ROWNUM";

	/**
	 * @deprecated	Use constructor CFTable(String[] fields, String strTableName)
	 * 
	 * @param conn NOT USED
	 * @param strTableName name of table (without schema)
	 * @param strFieldsNames list of table columns delimited by commas
	 */
	public CFTable(@SuppressWarnings("unused") Connection conn, String strTableName, String strFieldsNames)
	{
		this (strTableName, null, null, strFieldsNames);
	}
	
	/**
	 * Constructor for accessing table with full list of columns (SELECT * FROM).
	 * 
	 * @since java_sdk_v2-6-9
	 * @param strTableName	name of table (without schema)
	 */
	public CFTable(String strTableName)
	{
		this (strTableName, null, null);
	}
	
	/**
	 * Constructor for accessing table with full list of columns (SELECT * FROM).
	 * 
	 * @deprecated Use constructor without connection parameter
	 * 
	 * @param strTableName	name of table (without schema)
	 * @param conn NOT USED
	 */
	@Deprecated
	public CFTable(Connection conn, String strTableName)
	{
		this (conn, strTableName, null, null);
	}

	/**
	 * Constructor with list of columns
	 * 
	 * @deprecated Use constructor without connection
	 * 
	 * @param conn 			not used
	 * @param strTableName	name of table (without schema)
	 * @param columns		must not be null or zero length array
	 */
	@Deprecated
	public CFTable(Connection conn, String[] columns, String strTableName)
	{
		this (conn, strTableName, null, columns);
	}
	
	/**
	 * Constructor with list of columns
	 * 
	 * @since java_sdk_v2-6-9
	 * 
	 * @param columns		must not be null or zero length array
	 * @param strTableName	name of table (without schema)
	 */
	public CFTable(String[] columns, String strTableName)
	{
		this (strTableName, null, columns);
	}
	
	/**
	 * Do we really need this constructor?
	 * Generally, Java classes should not use database schema name.
	 * 
	 * @deprecated Use constructor without connection
	 * 
	 * @param sSchema		name of schema, or null if no schema needs to be defined
	 * @param sTableName	name of table (without schema name)
	 * @param asColumns		if null, all columns need to be read/written
	 * @param conn			open connection to database
	 */
	@Deprecated
	public CFTable(@SuppressWarnings("unused") Connection conn, String sTableName, String sSchema, String[] asColumns)
	{
		this(sTableName, sSchema, asColumns, makeListOfColumns(asColumns));
	}
	
	/**
	 * Do we really need this constructor?
	 * Generally, Java classes should not use database schema name.
	 * 
	 * @since java_sdk_v2-6-9
	 * 
	 * @param sTableName
	 * @param sSchema
	 * @param asColumns
	 */
	public CFTable(String sTableName, String sSchema, String[] asColumns)
	{
		this(sTableName, sSchema, asColumns, makeListOfColumns(asColumns));
	}
	
	private CFTable(String sTableName, String sSchema, String[] asColumns, String sColumnsList)
	{
		super( 
			new CDBSource(
				(sSchema == null) ? sTableName : sSchema + "." + sTableName,
				sTableName,
				sColumnsList,
				asColumns));
	}
	
	/**
	 * Method composes list of table columns delimited by comma
	 * @return  COMMENT ME
	 * @param asColumns	if null, all columns need to be read/written
	 */
	private static String makeListOfColumns(String[] asColumns)
	{
		if (asColumns == null)
			return ALL_COLUMNS;

		// assume that average length of field name is 8 :)
		StringBuffer sFiledsList = new StringBuffer(asColumns.length * 8);

		// for (int i = asColumns.length-2; i>=0; i--)	// Why are columns in opposite order?
		for (int i = 0; i < asColumns.length; i++)
		{
			if (i > 0)
				sFiledsList.append(", ");
			sFiledsList.append(asColumns[i]);
		}
		return sFiledsList.toString();
	}
	
	/**
	 * Subclasses need to redefine this method if primary key column
	 * is different from "ID".
	 * 
	 * @return 	Name of column - "ID", "IS_DOMAIN_ID", "CUSTOMER_ID", etc.
	 */
	public String getPrimaryKeyColumn()
	{
		return "ID";
	}
}

