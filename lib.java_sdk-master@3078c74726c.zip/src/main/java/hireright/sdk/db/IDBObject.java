/*
 * @(#)$RCSfile: IDBObject.java,v $ $Revision: 1.2 $ $Date: 2008/09/05 10:14:57 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/IDBObject.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev			2008-08-28	created
 */
package hireright.sdk.db;

/**
 * Intefrace for CDBObject
 * 
 * @author	Andrei Solntsev
 * @date		2005-06-08
 * @version $Revision: 1.2 $ $Date: 2008/09/05 10:14:57 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/IDBObject.java,v $
 */
public interface IDBObject
{
	CFTable createCFTable();
	void getDataFromDb( CFTable table );
}
