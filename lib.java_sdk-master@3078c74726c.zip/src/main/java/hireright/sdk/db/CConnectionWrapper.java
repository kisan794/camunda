/*
 * @(#)$RCSfile: CConnectionWrapper.java,v $ $Revision: 1.13 $ $Date: 2010/03/11 21:42:18 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CConnectionWrapper.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2005-07-20	A.Solntsev	created
 *  2005-08-15	A.Solntsev	Added "locked" and "last time used" features.
 *  2006-10-12	A.Solntsev	Added check for concurrent Threads
 *  2007-02-13	A.Solntsev	Added locking stack trace
 *  2007-09-21	A.Solntsev	Method isClosed(): removed locking
 *  2007-11-21	A.Solntsev	Added method getDelegateConnection()
 *  2010-03-05	A.Solntsev	Removed (used Proxy instead of CConnectionWrapper)
 */
package hireright.sdk.db;

class CConnectionWrapper
{
}