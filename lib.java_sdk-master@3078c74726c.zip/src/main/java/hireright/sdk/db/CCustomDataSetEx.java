/*
 * @(#)$RCSfile: CCustomDataSetEx.java,v $ $Revision: 1.15 $ $Date: 2010/02/04 21:17:21 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CCustomDataSetEx.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2001-xx-xx	S.Ignatov	Created.
 *  2002-09-13	S.Ignatov	modified set read only
 *  2003-03-31	S.Ignatov	fixed group by - order by
 *  2005-08-08	A.Solntsev	getFieldsString(): removed table name and spaces from Sql statements.
 *  2005-08-16	A.Solntsev	New class CSQLWhereParser is used to bind variables.
 *	2005-08-24	A.Solntsev	Added Iterator-methods listSourceFields(), listActiveFields(), listChangedFields().
 *	2006-05-11	A.Solntsev	Added constructor without parameters
 *	2005-08-29	A.Solntsev	Performance improvement in getFieldsString(): uses StringBuilder instead of String
 *	2006-11-01	A.Solntsev	Added constructor CCustomDataSetEx(String szSrcName)
 *	2008-05-29	M.Litvinov	The logic for extracting n first rows in proc generatQueryDML is enhanced
 *	2008-09-01	A.Solntsev	Fixed SQL filter containing apostrophes
 */
package hireright.sdk.db;
import hireright.sdk.db.fields.CMirrorField;
import hireright.sdk.util.CFilteredIterator;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IFilter;

import java.sql.Connection;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * Class for working with sql queries based database sources, like tables or views. 
 * Class support only quering (read only) functionality. For updates and inserts use 
 * CCompositeTable or CTable. 
 *
 *	@author Sergei Ignatov
 *	@date 2001/11/15
 */
abstract class CCustomDataSetEx extends CCustomDataSet 
{
	protected static final String CLASS_VERSION = "$Revision: 1.15 $ $Author: cvsroot $";
	
	protected final LinkedList<CMirrorField> m_objMirrorFields;
	
	/*
	 * FIXME	Bad design: this class introduces LIST of sources (this.m_objSources), but
	 * 				inherits THE SINGLE source from class CCustomDataSet (this.m_source).
	 */
	protected final LinkedList<CDBSource> m_objSources;
	protected final LinkedList<CRelation> m_objRelations;		

	/**
	 * Base constructor for this class. Creating new instance of CCustomDataSetEx.
	 * 
	 *  @since java_sdk_v2-6-9
	 */
	CCustomDataSetEx() 
	{
		super();
		m_szDMLQuery = null;
		m_objMirrorFields = new LinkedList<CMirrorField>();
		m_objSources = new LinkedList<CDBSource>();
		m_objRelations = new LinkedList<CRelation>();
	}
	
	/**
	 * @deprecated Use default constructor 
	 * @param connection connection to jdbc data source - NOT USED
	 */
	@Deprecated
	CCustomDataSetEx(@SuppressWarnings("unused") Connection connection) 
	{
		this();
	}
	
	/**
	 * Add relation object to relations list of the datasource. 
	 *
	 * @param relation object, contains string condiitions of the several datasource 
	 * fields relations. 
	 *
	 */
	private final void addRelation(CRelation relation)
	{
		if (relation != null)
			m_objRelations.add(relation);
	}
	
	/**
	 * Add one source object to sources list, without any relations, with full fileds list. 
	 * suitable for first datasource addition, or single datasource dataset object.
	 *
	 * @param szSource source, like table name. 
	 *
	 */
	public final void addSource(String szSource)
	{
		addSource(szSource, null, null);
	}

	/**
	 * Add one source object to sources list, with relation to other data sources, with full fileds list. 
	 * 
	 *
	 * @param szSource source, like table name. 
	 * @param relation relation to other data sources, or to something else.
	 *
	 */
	public final void addSource(String szSource, CRelation relation)
	{
		addSource(szSource, null, relation);
	}
	
	/**
	 * Add one source object to sources list, with alternative name, with relation to other data sources, 
	 * with full fileds list. 
	 *
	 * @param szSource source, like table name. 
	 * @param szSynonym alternative name for this source. 
	 * @param relation relation to other data sources, or to something else. 
	 *
	 */
	private final void addSource(String szSource, String szSynonym, CRelation relation)
	{
		if (szSource == null)
			return;

		CDBSource source = new CDBSource(szSource, (szSynonym != null ? szSynonym : szSource));
		addSource(source, relation);
	}
	
	/**
	 * Add one custom source object to sources list, with relation to other data sources.
	 *
	 * @param dbSource source object. 
	 * @param relation relation to other data sources, or to something else. 
	 *
	 */
	private final void addSource(CDBSource dbSource, CRelation relation)
	{
		// FIXME
		if (m_source == null)
			m_source = dbSource;

		m_objSources.add(dbSource);
		getFieldsStructure(checkConnection());
		addRelation(relation);
	}	
	
	public final void addSource(CDBSource dbSource)
	{
		addSource(dbSource, null);
	}		
	
	/**
	 * Reset all internal data structures information. 
	 *
	 */ 
	protected void clearStructure()
	{
		m_objSources.clear();
		m_objRelations.clear();
		m_objMirrorFields.clear();
		m_objFields.clear();
	}
	
	/**
	 * Return field by given name, from fields list. 
	 *
	 * @param szName field name or synomym field name. 
	 *
	 * @return CField object or null, if not found. 
	 */
	@Override
	public CField fieldByName(String szName)
	{
		if (szName == null)
			return null;
		
		final String szNameUpper = szName.toUpperCase();
		String szRealName = szNameUpper;

		for (CMirrorField mrField : m_objMirrorFields)
		{
			if (mrField.getFieldNameUpper().equals(szNameUpper))
				szRealName = mrField.getSourceFieldName();
		}
	
		for (CField field : m_objFields.values())
		{		
			if (field.getNameUpper().equals(szRealName) ||
					field.getExpressionUpper().equals(szRealName))
				return field;
		}
	
		return null;
	}

	/**
	 * Method for SELECT DML composing. 
	 *
	 * @return select expression or empty string. 
	 *
	 */
	@Override
	protected String generateQueryDML(String sSqlFilter, Integer maxRows, boolean hasConditions)
	{
		if (m_objFields.size() == 0)
			return "";
	
		if (m_szDMLQuery == null)  
		{
			boolean bUseOrdering = (m_szOrderBy != null && m_szOrderBy.trim().length() > 0);
			boolean bUseFirstNRows = (maxRows != null);
			
			StringBuilder sb = new StringBuilder("SELECT ");
			appendFieldsString(sb);
			
			if (bUseOrdering && bUseFirstNRows)
			{
				sb.append("\n FROM (SELECT ");
				appendFieldsString(sb);
				sb.append(",\n row_number() OVER (ORDER BY ").append(m_szOrderBy)
					.append(") as j_rownm");
			}
			
			sb.append("\n  FROM ").append(getSourceString()).append("\n");
			
			String szRelations = getFilterString();
			if (szRelations != null && szRelations.trim().length() > 0 &&
					CSQLWhereConstructor.hasConditions(szRelations))
			
				sb.append(" WHERE ").append(szRelations).append("\n");
			
			// this is a very strange situation that should not ever occur
			// because the future result of selection being executed is unpredictable
			// and randomized
			if (!bUseOrdering && bUseFirstNRows)
			{
				sb.append("AND rownum <= ").append(maxRows)
				.append("\n");
			}

			if (m_isGroupByed)
			{
				if (m_sGroupExpression.length()==0)
				{
					sb.append(" GROUP BY ");
					appendFieldsString(sb);
				}
				else
				{
					sb.append(" GROUP BY ").append(m_sGroupExpression);
				}
			}

			if (bUseOrdering)
			{
				if (bUseFirstNRows)
				{
					sb.append(")\n").append(" WHERE j_rownm <= ")
						.append(maxRows).append("\n");
				}
				else
				{
					sb.append(" ORDER BY ").append(m_szOrderBy).append("\n");
				}				
			}
				
			m_szDMLQuery = sb.toString();
		}
		
		return m_szDMLQuery;
	}
	
	/**
	 * Method for composing fields list part of SELECT DML. 
	 *
	 * Method append to given StringBuilder list of fields delimited by comma.
	 * 
	 * @param sb  not null
	 */
	private final void appendFieldsString(StringBuilder sb)
	{
		if (m_objSources == null || m_objFields.isEmpty())
			return;

		// If more than 1 table is joined, we need to add table name to fields in SELECT
		boolean bJoinTables = (m_objSources != null && m_objSources.size() > 1);

		boolean bIsFirst = true;
		
		for (CField field : m_objFields.values()) 
		{
			if (field.isActive())
			{
				if (bIsFirst)
					bIsFirst = false;
				else
					sb.append(", \n       ");

				if (bJoinTables)
					sb.append(field.getExpression());
				else
					sb.append(field.getName());
			}
		}
	}

	protected Iterable<CField> listSourceFields(final CDBSource source)
	{
		return new Iterable<CField>()
		{
			public Iterator<CField> iterator()
			{
				return new CFilteredIterator<CField>(m_objFields.values().iterator(), new IFilter<CField>()
				{
					public boolean accept(CField field)
					{
						return field.getTableNameUpper().equals(source.getSynonymUpper());
					}
				});
			}
		};
	}
	
	protected Iterator<CField> listActiveFields(final CDBSource source)
	{
		return new CFilteredIterator<CField>(m_objFields.values().iterator(), new IFilter<CField>()
		{
			public boolean accept(CField field)
			{
				return field.isActive() &&
					field.getTableNameUpper().equals(source.getSynonymUpper());
			}
		});
	}

	protected Iterator<CField> listChangedFields(final CDBSource source)
	{
		return new CFilteredIterator<CField>(m_objFields.values().iterator(), new IFilter<CField>()
		{
			public boolean accept(CField field)
			{
				return field.isActive() && field.isChanged() &&
					field.getTableNameUpper().equals(source.getSynonymUpper());
			}
		});
	}
	
	/**
	 * Method for composing fields list part of SELECT DML for one source.  
	 *
	 * @return fields list string or empty string for one given source.
	 *
	 */
	public final String getFieldsString(CDBSource source)
	{
		if (m_objFields.size() == 0)
			return "";

		StringBuilder sbResult = new StringBuilder();
		CField field;
		
		for (Iterator<CField> it = listActiveFields(source); it.hasNext(); )
		{
			field = it.next();
			if (sbResult.length() > 0)
				sbResult.append(", ");

			// 2005-08-09		A.Solntsev, V.Zyakin	Removed this code to make Pl/Sql statements shorter.				
			// sbResult.append(field.getExpression());
			sbResult.append(field.getName());
		}

		return sbResult.toString();
	}

	abstract boolean getFieldsStructure(Connection conn);

	public String getRelationsString()
	{
		if (m_objRelations.isEmpty())
			return "";

		boolean bFirstRelation = true;
		StringBuilder sb = new StringBuilder("( ");
		
		for (CRelation relation : m_objRelations)
		{
			if (bFirstRelation)
				bFirstRelation = false;
			else
				sb.append("\n AND ");
			
			sb.append( relation.getRelationString() );
		}

		return sb.append(" )").toString();
	}

	/**
	 * Return list of data sources (table/view names) delimited by comma and \n.
	 * This method is used when creating SELECT, UPDATE, INSERT and DELETE statements.
	 * 
	 * @return For example, "OA_APPLICATION, \n OA_APPLICATION_PAGE"
	 * Returns empty string if there is no data sources added (generally this should not happen).
	 */
	@Override
	public final String getSource()
	{
		return getSourceString();
	}	

	/**
	 * Return list of data sources (table/view names) delimited by comma and \n.
	 * This method is used when creating SELECT, UPDATE, INSERT and DELETE statements.
	 * 
	 * @return For example, "OA_APPLICATION, \n OA_APPLICATION_PAGE"
	 * Returns empty string if there is no data sources added (generally this should not happen).
	 */
	final String getSourceString()
	{
		if (m_objSources.isEmpty())
			return "";

		StringBuilder sbResult = new StringBuilder();
		for (CDBSource source : m_objSources)
		{
			if (sbResult.length() > 0)
				sbResult.append(", \n       ");

			sbResult.append(source.getName());
		}

		return sbResult.toString();
	}

	protected boolean isSourceChanged(CDBSource source)
	{
		if (m_objFields.isEmpty())
			return false;

		return (listChangedFields(source).hasNext());
	}

	/**
	 * @deprecated	Use constructor with table name
	 * Currently method is used only in integrations
	 */
	@Override
	public final boolean setSource(String szSrcName)
	{
		if (szSrcName == null)
			return false;
			
		m_objSources.clear();
		addSource(szSrcName);

		return true;
	}
	
	public boolean setSource(CDBSource source)
	{
		if (source == null)
			return false;
			
		m_objSources.clear();
		addSource(source);

		return true;
	}	

	protected void setSourceChanged(CDBSource source, boolean isChanged)
	{
		if (m_objFields.isEmpty())
			return;

		for (CField field: listSourceFields(source))
		{
			field.setChanged(isChanged);
		}
	}
	
	@Override
	public String getFilterString()
	{
		if (m_objSources.isEmpty())
			return "";

		StringBuilder sbWhereClause = new StringBuilder();

		{
			// Concat `relations filter` and `given filter`
			String szRelations = getRelationsString();
			if (szRelations != null)
				sbWhereClause.append(szRelations);
	
			String szFilter = (m_szFilter == null) ? "" : m_szFilter;
					
			if (szRelations != null && szRelations.length() > 0 && szFilter.length() > 0 &&
								CSQLWhereConstructor.hasConditions(szFilter))
				sbWhereClause.append(" AND ").append(szFilter);
			else
				sbWhereClause.append(szFilter);
		}
		
		String sWhereClause = sbWhereClause.toString();
		if (!m_objMirrorFields.isEmpty())
		{
			// COMMENT ME		something with replacing substring from mirror fields
			for (CMirrorField field : m_objMirrorFields)
			{
				sWhereClause = CStringUtils.replace(sWhereClause, '[' + field.getFieldName() + ']', field.getSourceFieldName());
			}
		}
	
		return sWhereClause;
	}
	
	@Override
	public void setGroup(String sGroupExpression, boolean groupByState)
	{
		super.setGroup(sGroupExpression, groupByState);
		switchRowids(!groupByState);
	}
	
	@Override
	public void switchRowids(boolean isActive)
	{
		if (m_objSources.isEmpty())
			return;

		for (CDBSource source : m_objSources)
		{
			CField field = this.fieldByName("ROWIDTOCHAR(" + source.getIdentificationColumn() + ")");
			if (field != null)
				field.setActive(isActive);
		}
	}
}