/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	msuhhoruki	Jun 12, 2017	Created
 */
package hireright.sdk.db.pojo;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import hireright.sdk.db.CFTable;
import hireright.sdk.db.CField;
import hireright.sdk.util.CFilteredIterator;
import hireright.sdk.util.IFilter;

/**
 * Represents a database table row with references to other table rows.
 */
public class CTablePojo implements Serializable
{
	private static final long serialVersionUID = 1L;

	protected static final String CLASS_VERSION = "$Revision: $ $Author: $";
	
	private String table;
	private String label;
	private List<Column> columns;
	private List<CTablePojo> refs;
	
	public static class Column implements Serializable
	{
		private static final long serialVersionUID = 1L;
		
		private String name;
		private Object value;
		
		public Column()
		{
		}
		public Column(String name, Object value)
		{
			this.name = name;
			this.value = value;
		}
		public String getName()
		{
			return this.name;
		}
		public void setName(String name)
		{
			this.name = name;
		}
		public Object getValue()
		{
			return this.value;
		}
		public void setValue(Object value)
		{
			this.value = value;
		}
	}
	
	public String getTable()
	{
		return this.table;
	}
	
	public void setTable(String type)
	{
		this.table = type;
	}
	
	public String getLabel()
	{
		return this.label;
	}
	
	public void setLabel(String label)
	{
		this.label = label;
	}
	
	public List<Column> getColumns()
	{
		return this.columns;
	}
	
	public void setColumns(List<Column> columns)
	{
		this.columns = columns;
	}
	
	public static Map<String, Object> getPropertyMap(CTablePojo obj)
	{
		List<Column> columns = obj.getColumns();
		if (columns == null)
		{
			return null;
		}
		
		Map<String, Object> map = new HashMap<String, Object>(columns.size() + 10);
		for (Column column : columns)
		{
			map.put(column.getName(), column.getValue());
		}
		
		return map;
	}
	
	public <T> T getProperty(String sName)
	{
		if (columns == null)
		{
			return null;
		}
		
		for (Column column : columns)
		{
			if (sName.equals(column.getName()))
			{
				return (T) column.getValue();
			}
		}
		
		return null;
	}
	
	public List<CTablePojo> getRefs()
	{
		return this.refs;
	}
	
	public List<CTablePojo> getRefs(IFilter<CTablePojo> filter)
	{
		return CFilteredIterator.filterCollection(getRefs(), filter);
	}
	
	public void setRefs(List<CTablePojo> refs)
	{
		this.refs = refs;
	}
	
	public Iterator<CTablePojo> getThisAndAllRefs()
	{
		return new CTablePojoRefIterator(this);
	}
	
	public CTablePojo findByLabel(String sLabel)
	{
		return findByLabel(this, sLabel);
	}
	
	public static CTablePojo findByLabel(CTablePojo root, String sLabel)
	{
		for (Iterator<CTablePojo> iter = root.getThisAndAllRefs(); iter.hasNext();)
		{
			CTablePojo pojo = iter.next();
			//CTablePojo pojo = findByLabel(ref, sLabel);
			if (pojo != null && sLabel.equals(pojo.getLabel()))
			{
				return pojo;
			}
		}
		
		return null;
	}
	
	public static CFTable toCFTable(CTablePojo pojo)
	{
		return new CFTableProxy(pojo);
	}
	
	private static class CTablePojoRefIterator implements Iterator<CTablePojo>
	{
		private final Queue<CTablePojo> nextPojos;
		
		public CTablePojoRefIterator(CTablePojo root)
		{
			nextPojos = new ArrayDeque<CTablePojo>();
			nextPojos.add(root);
		}
		
		@Override
		public boolean hasNext()
		{
			return !nextPojos.isEmpty();
		}
		
		@Override
		public CTablePojo next()
		{
			CTablePojo pojo = nextPojos.poll();
			if (pojo != null)
			{
				List<CTablePojo> refs = pojo.getRefs();
				if (refs != null && !refs.isEmpty())
				{
					nextPojos.addAll(refs);
				}
			}
			
			return pojo;
		}
		
		@Override
		public void remove()
		{
			throw new UnsupportedOperationException("remove");
		}
	};
	
	private static class CFTableProxy extends CFTable
	{
		private final CTablePojo m_pojo;
		private Map<String, Object> m_columnValues;
		
		public CFTableProxy(CTablePojo pojo)
		{
			super(pojo.getTable(), null, toColumnNames(pojo.getColumns()));
			
			m_pojo = pojo;
			m_columnValues = new HashMap<String, Object>(m_pojo.getColumns().size() + 6);
			for (Column column : pojo.getColumns())
			{
				m_columnValues.put(column.getName(), column.getValue());
			}
		}
		
		@Override
		public CField fieldByName(String szName)
		{
			return new CFieldProxy(szName, m_columnValues.get(szName));
		}
		
		@Override
		public boolean getOneRecord(String szFilter)
		{
			return true;
		}
		
		private static String[] toColumnNames(List<Column> columns)
		{
			String[] clmNames = new String[columns.size()];
			for (int i = 0; i < columns.size(); i++)
			{
				clmNames[i] = columns.get(0).getName();
			}
			
			return clmNames;
		}
	}
	
	private static class CFieldProxy extends CField
	{
		private final String m_sName;
		private final Object m_value;
		
		public CFieldProxy(String sName, Object value)
		{
			super(null, "");
			m_sName = sName;
			m_value = value;
		}
		
		@Override
		public Object getValue()
		{
			return m_value;
		}
		
		@Override
		protected Date getDateValue()
		{
			return (Date) m_value;
		}
		
		@Override
		public String getColumnName()
		{
			return m_sName;
		}
		
		@Override
		public String getName()
		{
			return m_sName;
		}
		
		@Override
		protected void setParamToPrepStatement(PreparedStatement pstmt, int nIndex)
			throws SQLException
		{
			throw new UnsupportedOperationException();
		}
		
		@Override
		protected void setNull()
		{
			throw new UnsupportedOperationException();
		}
		
		@Override
		public boolean setValueToCallableStatement(CallableStatement pstmt, int nIndex)
			throws SQLException
		{
			return false;
		}
		
		@Override
		public void setFromRecordSet(ResultSet rst, int nIndex)
		{
			throw new UnsupportedOperationException();
		}
	}
}
