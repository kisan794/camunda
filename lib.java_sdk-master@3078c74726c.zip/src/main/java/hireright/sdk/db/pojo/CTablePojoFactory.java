/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	msuhhoruki	Jun 12, 2017	Created
 */
package hireright.sdk.db.pojo;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.IOUtils;

import hireright.sdk.db3.DB;
import hireright.sdk.util.CArrays;
import hireright.sdk.util.CStringUtils;

/**
 * Reads database as CTablePojos defined in CTablePojoReference.
 * References can be given as java objects or XML. Reading starts with the root reference and proceeds to read child refs using parent row data.
 */
public class CTablePojoFactory
{
	protected static final String CLASS_VERSION = "$Revision: $ $Author: $";
	
	private static final String COLUMN_REF_START = "$$";
	
	public static CTablePojo getFirst(CTablePojoReference ref)
		throws SQLException, IOException
	{
		List<CTablePojo> objs = get(ref, null);
		return objs != null && !objs.isEmpty() ? objs.get(0) : null;
	}
	
	public static List<CTablePojo> get(CTablePojoReference ref)
		throws SQLException, IOException
	{
		return get(ref, null);
	}
	
	private static List<CTablePojo> get(CTablePojoReference ref, CTablePojo referer)
		throws SQLException, IOException
	{
		List<CTablePojo> objs = loadDataObjects(
				ref.getLabel(), ref.getTo(), prepareQueryConditions(ref, referer));
		for (CTablePojo obj : CArrays.nvl(objs))
		{
			List<CTablePojo> referencedObjs = null;
			for (CTablePojoReference objRef : CArrays.nvl(ref.getRefs()))
			{
				List<CTablePojo> subObjs = get(objRef, obj);
				referencedObjs = add(referencedObjs, subObjs);
			}
			obj.setRefs(referencedObjs);
		}
		
		return objs;
	}
	
	private static Object[] prepareRefByValues(Object[] values, CTablePojo referer)
	{
		if (values == null)
		{
			return null;
		}
		
		Object[] usingValues = new Object[values.length];
		for (int i = 0; i < values.length; i++)
		{
			Object value = values[i];
			if (value instanceof String)
			{
				String sValue = (String) value;
				Object usingValue = sValue;
				if (sValue.startsWith(COLUMN_REF_START))
				{
					if (referer == null)
					{
						throw new IllegalArgumentException("null referer.");
					}
					
					String sPropertyName = sValue.substring(COLUMN_REF_START.length());
					usingValue = referer.getProperty(sPropertyName);
				}
				
				usingValues[i] = usingValue;
			}
			else
			{
				usingValues[i] = value;
			}
		}
		
		return usingValues;
	}
	
	private static List<CTablePojo> loadDataObjects(String sLabel, String sTable, List<QueryCondition> conditions)
		throws SQLException, IOException
	{
		if (CStringUtils.isEmpty(sTable))
		{
			throw new IllegalArgumentException("Table not provided.");
		}
		else if (conditions == null || conditions.isEmpty())
		{
			throw new IllegalArgumentException("Query conditions not provided.");
		}
		
		String sSafeTableColumnName = "^[0-9a-zA-Z_]+$";
		if (!sTable.matches(sSafeTableColumnName))
		{
			throw new IllegalArgumentException("Table " + sTable + " does not match security constraints.");
		}
		
		for (QueryCondition condition : conditions)
		{
			if (!condition.column.matches(sSafeTableColumnName))
			{
				throw new IllegalArgumentException("Column " + condition.column + " does not match security constraints.");
			}
		}
		
		Connection conn = DB.connection();
		StringBuilder sbSql = new StringBuilder(256);
		sbSql.append("select * from ").append(sTable);
		for (int i = 0; i < conditions.size(); i++)
		{
			QueryCondition condition = conditions.get(i);
			if (i == 0)
			{
				sbSql.append(" where ");
			}
			else
			{
				sbSql.append(" and ");
			}
			sbSql.append(condition.column);
			
			if (condition.values.length == 0)
			{
				sbSql.append(" IS NULL");
			}
			else if (condition.values.length == 1)
			{
				Object value = condition.values[0];
				if (value == null)
				{
					sbSql.append(" IS NULL");
				}
				else
				{
					sbSql.append(" = ?");
				}
			}
			else
			{
				sbSql.append(" IN (");
				for (int j = 0; j < condition.values.length; j++)
				{
					Object value = condition.values[j];
					if (value == null)
					{
						sbSql.append("NULL");
					}
					else
					{
						sbSql.append("?");
					}
					
					if (j < condition.values.length - 1)
					{
						sbSql.append(", ");
					}
				}
				sbSql.append(")");
			}
		}
		
		int nParamIdx = 1;
		List<CTablePojo> objs = null;
		PreparedStatement stmt = conn.prepareStatement(sbSql.toString());
		try
		{
			for (QueryCondition condition : conditions)
			{
				for (Object value : condition.values)
				{
					if (value == null)
					{
						// skip (NULL is set in query)
					}
					else if (value instanceof String)
					{
						stmt.setString(nParamIdx++, value.toString());
					}
					else if (value instanceof Integer)
					{
						stmt.setInt(nParamIdx++, ((Integer) value).intValue());
					}
					else if (value instanceof Long)
					{
						stmt.setLong(nParamIdx++, ((Long) value).longValue());
					}
					else if (value instanceof BigDecimal)
					{
						stmt.setBigDecimal(nParamIdx++, (BigDecimal) value);
					}
					else
					{
						throw new IllegalArgumentException("Value " + value + " not supported.");
					}
				}
			}
			
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metadata = null;
			while (rs.next())
			{
				if (metadata == null)
				{
					metadata = rs.getMetaData();
				}
				
				CTablePojo obj = new CTablePojo();
				obj.setTable(sTable);
				
				int nColumns = metadata.getColumnCount();
				List<CTablePojo.Column> columnsObjs = new ArrayList<CTablePojo.Column>(nColumns);
				for (int i = 1; i <= nColumns; i++)
				{
					Object columnValue = resolveValue(i, rs, metadata);
					//obj.setProperty(metadata.getColumnName(i), columnValue);
					columnsObjs.add(new CTablePojo.Column(metadata.getColumnName(i), columnValue));
				}
				obj.setColumns(columnsObjs);
				obj.setLabel(resolveLabel(sLabel, columnsObjs));
				
				objs = add(objs, obj);
			}
		}
		finally
		{
			stmt.close();
		}
		
		return objs;
	}
	
	private static Object resolveValue(int nColumn, ResultSet rs, ResultSetMetaData metadata)
		throws SQLException, IOException
	{
		Object value = null;
		int nColumnType = metadata.getColumnType(nColumn);
		int nPrecision = metadata.getPrecision(nColumn);
		int nScale = metadata.getScale(nColumn);
		switch (nColumnType)
		{
			case Types.VARCHAR:
			case Types.CHAR:
			case Types.LONGVARCHAR:
			case Types.LONGNVARCHAR:
			{
				value = rs.getString(nColumn);
				break;
			}
			case Types.NVARCHAR:
			case Types.NCHAR:
			{
				value = rs.getNString(nColumn);
				break;
			}
			case Types.SMALLINT:
			{
				value = rs.getShort(nColumn);
				break;
			}
			case Types.TINYINT:
			{
				value = rs.getByte(nColumn);
				break;
			}
			case Types.INTEGER:
			{
				value = rs.getInt(nColumn);
				break;
			}
			case Types.DECIMAL:
			{
				value = rs.getBigDecimal(nColumn);
				break;
			}
			case Types.NUMERIC:
			{
				if (nScale > 0)
				{
					value = rs.getBigDecimal(nColumn);
				}
				else
				{
					double maxValue = Math.pow(10, nPrecision);
					double minValue = maxValue * -1d;
					if (maxValue < Integer.MAX_VALUE && minValue > Integer.MIN_VALUE)
					{
						value = rs.getInt(nColumn);
					}
					else if (maxValue < Long.MAX_VALUE && minValue > Long.MIN_VALUE)
					{
						value = rs.getLong(nColumn);
					}
					else
					{
						value = rs.getBigDecimal(nColumn);
					}
				}
				
				break;
			}
			case Types.DATE:
			{
				//value = rs.getDate(nColumn);
				java.sql.Date date = rs.getDate(nColumn);
				if (date != null)
				{
					value = new Date(date.getTime());
				}
				break;
			}
			case Types.TIME:
			// case Types.TIME_WITH_TIMEZONE: // java 8
			{
				//value = rs.getTime(nColumn);
				java.sql.Time time = rs.getTime(nColumn);
				if (time != null)
				{
					value = new Date(time.getTime());
				}
				break;
			}
			case Types.TIMESTAMP:
			//case Types.TIMESTAMP_WITH_TIMEZONE: // java 8
			{
				//value = rs.getTimestamp(nColumn);
				java.sql.Timestamp timestamp = rs.getTimestamp(nColumn);
				if (timestamp != null)
				{
					value = new Date(timestamp.getTime());
				}
				break;
			}
			case Types.CLOB:
			{
				Clob clob = rs.getClob(nColumn);
				if (clob != null)
				{
					value = readAndClose(clob.getCharacterStream());
				}
				break;
			}
			case Types.NCLOB:
			{
				NClob clob = rs.getNClob(nColumn);
				if (clob != null)
				{
					value = readAndClose(clob.getCharacterStream());
				}
				break;
			}
			case Types.BIGINT:
			{
				value = rs.getLong(nColumn);
				break;
			}
			case Types.LONGVARBINARY:
			case Types.BINARY:
			{
				value = readAndClose(rs.getBinaryStream(nColumn));
				break;
			}
			case Types.BOOLEAN:
			{
				value = rs.getBoolean(nColumn);
				break;
			}
			case Types.DOUBLE:
			{
				value = rs.getDouble(nColumn);
				break;
			}
			case Types.FLOAT:
			{
				value = rs.getFloat(nColumn);
				break;
			}
			case Types.REAL:
			{
				value = rs.getFloat(nColumn);
				break;
			}
			case Types.BIT:
			{
				value = rs.getBoolean(nColumn);
				break;
			}
			default:
			{
				throw new IllegalArgumentException("Unsupported sql type " + nColumnType);
			}
		}
		
		if (rs.wasNull())
		{
			value = null;
		}
		
		return value;
	}
	
	private static String readAndClose(Reader reader)
		throws IOException
	{
		try
		{
			return IOUtils.toString(reader);
		}
		finally
		{
			IOUtils.closeQuietly(reader);
		}
	}
	
	private static byte[] readAndClose(InputStream stream)
		throws IOException
	{
		try
		{
			return IOUtils.toByteArray(stream);
		}
		finally
		{
			IOUtils.closeQuietly(stream);
		}
	}
	
	/*
	 * TODO: move to CArrays
	 */
	/**
	 * Add objects to list. If list is null and objects size == 1 then SingletonList will be used to avoid creating ArrayList.
	 * @param list
	 * @param objects
	 * @return
	 */
	private static <T> List<T> add(List<T> list, Collection<T> objects)
	{
		if (objects != null)
		{
			if (list == null
				&& objects.size() == 1)
			{
				list = Collections.singletonList(objects.iterator().next());
			}
			else if (list == null)
			{
				list = new ArrayList<T>(objects); 
			}
			else if (list.size() == 1)
			{
				list = new ArrayList<T>(list);
				list.addAll(objects);
			}
			else
			{
				list.addAll(objects);
			}
		}
		
		return list;
	}
	
	/**
	 * Add object to list. If list is null then SingletonList will be used to avoid creating ArrayList.
	 * @param list
	 * @param object
	 * @return
	 */
	private static <T> List<T> add(List<T> list, T object)
	{
		if (list == null)
		{
			list = Collections.singletonList(object);
		}
		else if (list.size() == 1)
		{
			list = new ArrayList<T>(list);
			list.add(object);
		}
		else
		{
			list.add(object);
		}
		
		return list;
	}
	
	static class QueryCondition
	{
		String column;
		Object[] values;
	}
	
	private static List<QueryCondition> prepareQueryConditions(CTablePojoReference ref, CTablePojo referer)
	{
		List<QueryCondition> conditions = new ArrayList<QueryCondition>();
		
		if (ref.getBy() != null)
		{
			QueryCondition condition = new QueryCondition();
			condition.column = ref.getBy();
			condition.values = prepareRefByValues(new Object[] { ref.getUsing() }, referer);
			conditions.add(condition);
		}
		
		for (CTablePojoReference.RefBy refBy : CArrays.nvl(ref.getRefBy()))
		{
			QueryCondition condition = new QueryCondition();
			condition.column = refBy.getColumn();
			condition.values = prepareRefByValues(refBy.getValues(), referer);
			if (refBy.getColumnType() != null)
			{
				for (int i = 0; i < condition.values.length; i++)
				{
					Object value = condition.values[i];
					condition.values[i] = convertToColumnType(refBy.getColumnType(), value);
				}
			}
			
			conditions.add(condition);
		}
		
		return conditions;
	}
	
	private static Object convertToColumnType(String sColumnType, Object value)
	{
		if (sColumnType == null || value == null)
		{
			return value;
		}
		else if ("integer".equalsIgnoreCase(sColumnType))
		{
			if (value instanceof String)
			{
				return Integer.valueOf((String) value);
			}
		}
		else if ("string".equalsIgnoreCase(sColumnType))
		{
			return value.toString();
		}
		
		return value;
	}
	
	private static String resolveLabel(String sLabel, List<CTablePojo.Column> columns)
	{
		if (sLabel != null)
		{
			int n = sLabel.indexOf(COLUMN_REF_START);
			if (n > 0)
			{
				String sColumnName = sLabel.substring(n + COLUMN_REF_START.length());
				for (CTablePojo.Column column : CArrays.nvl(columns))
				{
					if (sColumnName.equals(column.getName()))
					{
						return sLabel.substring(0, n) + column.getValue();
					}
				}
			}
		}
		
		return sLabel;
	}
}
