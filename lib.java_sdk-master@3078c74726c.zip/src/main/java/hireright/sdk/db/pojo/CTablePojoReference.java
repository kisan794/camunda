/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	msuhhoruki	Jun 12, 2017	Created
 */
package hireright.sdk.db.pojo;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.util.ArrayList;
import java.util.List;

/**
 * Reference to a set of tables. Provides reading instructions to CTablePojoFactory.
<?xml version="1.0" encoding="UTF-8"?>
<Ref to="request" by="REQUEST_ID" using="" label="Order">
	<Ref to="order_property" by="ORDER_ID" using="$$REQUEST_ID"/>
	<Ref to="customer_user" by="CUSTOMER_USER_ID" using="$$CUSTOMER_USER_ID" label="Customer User">
		<Ref to="address" by="ADDRESS_ID" using="$$ADDRESS_ID" label="Customer User Address"/>
	</Ref>
	<Ref to="customer" by="CUSTOMER_ID" using="$$CUSTOMER_ID" label="Customer">
		<Ref to="customer_property" label="Customer Property:$NAME">
			<By column="CUSTOMER_ID" values="$$CUSTOMER_ID"/>
			<By column="NAME" values="COMPANY_LEGAL_NAME, URI_AUDIO_NAME"/>
		</Ref>
		<Ref to="customer_property">
			<By column="CUSTOMER_ID" values="$$CUSTOMER_ID"/>
			<By column="NAME" values="ACCOUNT_MANAGER"/>
			<Ref to="operator" label="Account Manager">
				<By column="OPERATOR_ID" values="$$VALUE" columnType="integer"/>
			</Ref>
		</Ref>
		<Ref to="cust_addr" by="CUSTOMER_ID" using="$$CUSTOMER_ID" label="Customer Address:$$ADDRESS_TYPE">
			<Ref to="address" by="ADDRESS_ID" using="$$ADDRESS_ID"/>
		</Ref>
		<Ref to="customer_parent_child" by="CUSTOMER_CHILD_ID" using="$$CUSTOMER_ID">
			<Ref to="customer" by="CUSTOMER_ID" using="$$CUSTOMER_PARENT_ID" label="Parent Customer"/>
			<Ref to="customer_property" label="Parent Customer Property:$$NAME">
				<By column="CUSTOMER_ID" values="$$CUSTOMER_PARENT_ID"/>
				<By column="NAME" values="COMPANY_LEGAL_NAME, URI_AUDIO_NAME"/>
			</Ref>
		</Ref>
	</Ref>
</Ref>
 */
public class CTablePojoReference
{
	protected static final String CLASS_VERSION = "$Revision: $ $Author: $";
	
	private String to; // table
	private String by; // column
	private Object using; // value
	private String label;
	private List<RefBy> refBy; // column-values when simple by is not enough
	private List<CTablePojoReference> refs; // child references
	
	public static class RefBy
	{
		private String column;
		private Object[] values;
		private String columnType;
		
		public String getColumn()
		{
			return this.column;
		}
		public RefBy setColumn(String column)
		{
			this.column = column;
			return this;
		}
		public Object[] getValues()
		{
			return this.values;
		}
		public RefBy setValues(Object[] values)
		{
			this.values = values;
			return this;
		}
		public String getColumnType()
		{
			return this.columnType;
		}
		public RefBy setColumnType(String type)
		{
			this.columnType = type;
			return this;
		}
	}
	
	public String getTo()
	{
		return this.to;
	}
	
	public void setTo(String to)
	{
		this.to = to;
	}
	
	public CTablePojoReference to(String to)
	{
		setTo(to);
		return this;
	}
	
	public String getBy()
	{
		return this.by;
	}
	
	public void setBy(String by)
	{
		this.by = by;
	}
	
	public CTablePojoReference by(String by)
	{
		this.by = by;
		return this;
	}
	
	public Object getUsing()
	{
		return this.using;
	}
	
	public void setUsing(Object using)
	{
		this.using = using;
	}
	
	public String getLabel()
	{
		return this.label;
	}
	
	public void setLabel(String label)
	{
		this.label = label;
	}
	
	public CTablePojoReference label(String label)
	{
		this.label = label;
		return this;
	}
	
	public CTablePojoReference using(Object using)
	{
		this.using = using;
		return this;
	}
	
	public List<CTablePojoReference> getRefs()
	{
		return this.refs;
	}
	
	public void setRefs(List<CTablePojoReference> refs)
	{
		this.refs = refs;
	}
	
	public List<RefBy> getRefBy()
	{
		return this.refBy;
	}
	
	public void setRefBy(List<RefBy> refBy)
	{
		this.refBy = refBy;
	}
	
	/**
<Ref to="request" by="REQUEST_ID" using="123456">
	<Ref to="order_service" by="ORDER_ID" using="referer:REQUEST_ID">
		<Ref to="education" by="ORDER_SERVICE_ID" using="referer:ID"/>
		<Ref to="employment" by="ORDER_SERVICE_ID" using="referer:ID"/>
	</Ref>
	<Ref to="order_property">
		<By column="ORDER_ID" value="referer:REQUEST_ID" />
		<By column="NAME" values="BILLING_UNIT_ID, DATASOURCE_NAME" />
	</Ref>
</Ref>
	 * 
	 * @param sRef
	 * @return
	 * @throws DocumentException 
	 */
	public static CTablePojoReference parse(String sRef)
		throws DocumentException
	{
		Document doc = DocumentHelper.parseText(sRef);
		Element elRoot = doc.getRootElement();
		
		return parseRefElement(elRoot);
	}
	
	private static CTablePojoReference parseRefElement(Element el)
	{
		CTablePojoReference ref = new CTablePojoReference();
		ref.setTo(el.attributeValue("to"));
		ref.setBy(el.attributeValue("by"));
		ref.setUsing(el.attributeValue("using"));
		ref.setLabel(el.attributeValue("label"));
		
		List<Element> elsRefBy = el.elements("By");
		if (elsRefBy != null && !elsRefBy.isEmpty())
		{
			List<RefBy> refBys = new ArrayList<RefBy>(elsRefBy.size());
			for (Element elRefBy : elsRefBy)
			{
				String sColumn = elRefBy.attributeValue("column");
				String sColumnType = elRefBy.attributeValue("columnType");
				String sValues = elRefBy.attributeValue("values");
				
				Object[] values = null;
				String[] strValues = sValues != null ? sValues.split(", ") : null;
				if (strValues != null && strValues.length > 0)
				{
					values = strValues;
				}
				
				RefBy refBy = new RefBy()
					.setColumn(sColumn)
					.setValues(values)
					.setColumnType(sColumnType);
				
				refBys.add(refBy);
			}
			
			ref.setRefBy(refBys);
		}
		
		List<Element> elsRef = el.elements("Ref");
		if (elsRef != null && elsRef.size() > 0)
		{
			List<CTablePojoReference> refs = new ArrayList<CTablePojoReference>(elsRef.size());
			for (Element elRef : elsRef)
			{
				refs.add(parseRefElement(elRef));
			}
			ref.setRefs(refs);
		}
		
		return ref;
	}
}
