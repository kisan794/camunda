/*
 * @(#)$RCSfile: CDBSource.java,v $ $Revision: 1.10 $ $Date: 2007/09/14 08:55:07 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	unknown		unknown			created
 *  2001-10-11	A.Rudenko		Moving into main branch
 *  2001-11-01	S.Ignatov		Blob's added. Improved View's support.
 *  2002-04-05	A.Keks			Added getRowIDFieldName() method.
 *  2005-08-16	A.Solntsev		Added support for schema name (beta version).
 *  2005-08-16	A.Solntsev		Added support for array of columns.
 *  							Added several (non-empty) constructors.
 *	2006-04-24	A.Solntsev		implements Serializable
 *	2006-06-08	A.Solntsev		implements IHasProperties
 */
package hireright.sdk.db;

import hireright.sdk.util.CProperties;
import hireright.sdk.util.IHasProperties;

import java.io.Serializable;

/**
 * I guess this class implements a single database table.
 * 
 * @author	Unknown
 * @date 20010-11-14
 */
class CDBSource implements Serializable, IHasProperties
{
	public static final String ROWID = "ROWID";
	
	protected String m_sTableName = null;
	protected String m_sTableSynonym = null;
	protected String m_sTableSynonymUpper = null;
	protected boolean m_isChanged = false;
	protected boolean m_canUseROWID = true;
	protected String m_szIdentColumn = ROWID;
	
	/**
	 * List of columns separated by coma.
	 * Default value "*" means that all columns are required.
	 */
	protected String m_sColumnsList = "*";
	
	/**
	 * Array of columns.
	 * Default value `null` means that all columns are required.
	 */
	protected String[] m_asColumnsList = null;
	
	protected boolean m_isLobsSupported = true;

	public void setLobsSupported(boolean boolValue)
	{
		m_isLobsSupported = boolValue;
	}

	public boolean getLobsSupported()
	{
		return m_isLobsSupported;
	}
	 
	/**
	 * Returns list of columns of this table.
	 * 
	 * @return 	List of columns separated by coma.
	 * 					Default value "*" means that all columns are required.
	 */
	public String getColumnsList()
	{
		return m_sColumnsList;
	}
	
	public String[] getColumns()
	{
		return m_asColumnsList;
	}

	public String getIdentificationColumn()
	{
		return m_szIdentColumn;
	}

	public void setIdentificationColumn(String szValue)
	{
		m_szIdentColumn = szValue;
	}

	public boolean canUseROWID()
	{
		return m_canUseROWID;
	}

	public String getExp()
	{
		if(m_szIdentColumn.compareTo("ROWID") == 0)
			return "CHARTOROWID(" + getSynonym() + ".ROWID)";

		return getSynonym() + "." + m_szIdentColumn;
	}

	public String getRowIDFieldName()
	{
		if(m_szIdentColumn.compareTo("ROWID") == 0)
			return "ROWIDTOCHAR(" + getSynonym() + ".ROWID)";
		else
			return null;
	}
	
	/**
	 * Constrcutor with table name
	 * @param sTableName
	 */
	public CDBSource(String sTableName)
	{
		this(sTableName, sTableName);
	}

	/**
	 * Constrcutor with table name and synonym.
	 * @param sTableSynonym	
	 * @param sTableName
	 */
	public CDBSource(String sTableName, String sTableSynonym)
	{
		this.m_sTableName = sTableName;
		this.m_sTableSynonym = sTableSynonym;
		this.m_sTableSynonymUpper = sTableSynonym.toUpperCase();
	}

	/**
	 * Set list of columns of this table.
	 * @param asColumns		List of columns separated by coma.
	 * 										Default value "*" means that all columns are required.
	 *
	 * @param sColumnsList	Array of columns.
	 * 											Default value `null` means that all columns are required.
	 */
	public CDBSource(String sTableName, String sTableSynonym, String sColumnsList, String[] asColumns)
	{
		this(sTableName, sTableSynonym);
		
		m_sColumnsList = sColumnsList;
		m_asColumnsList = asColumns;
	}

	/**
	 *	Currently returns the same as getName().
	 */
	public String getSynonym()
	{
		return m_sTableSynonym;
	}

	public String getSynonymUpper()
	{
		return m_sTableSynonymUpper;
	}
	
	/**
	 * @return name of table (without schema name)
	 */
	public String getName()
	{
		return m_sTableName;
	}

	public String toString()
	{
		return "DB Source: " + getName() + " AS " + getSynonym();
	}
	
	/**
	 * @since java_sdk_v2-6-13
	 */
	public CProperties toProperties()
	{
		return new CProperties()
			.setProperty("canUseROWID", m_canUseROWID)
			.setProperty("isChanged", m_isChanged)
			.setProperty("isLobsSupported", m_isLobsSupported)
			.setProperty("table", m_sTableName)
			.setProperty("tableSynonym", m_sTableSynonym)
			.setProperty("identColumn", m_szIdentColumn);
	}
}