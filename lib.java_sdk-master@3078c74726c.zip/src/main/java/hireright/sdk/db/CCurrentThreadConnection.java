/*
 * @(#)$RCSfile: CCurrentThreadConnection.java,v $ $Revision: 1.5 $ $Date: 2015/03/28 08:33:10 $ $Author: cvsroot $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2006-04-26	A.Solntsev  created
 *  2006-04-27	A.Solntsev  simple version (without 'expirator')
 *  2015-01-20	A.Tanasenko Reimplemented using connection providers
 */
package hireright.sdk.db;

import hireright.sdk.db3.DB;

import java.sql.Connection;

/**
 * ThreadLocal implementation for DB connection provider.
 *  
 * @author Andrei Solntsev
 * @since java_sdk_v2-6-9
 * @deprecated use {@link DB#execute(java.util.concurrent.Callable)} along with {@link DB#connection()}
 */
@Deprecated
public class CCurrentThreadConnection 
{
	private final static ThreadLocal<IConnectionProvider> m_currentThreadConnection = new ThreadLocal<>();
	
	public static void bindProvider(IConnectionProvider connProv)
	{
		m_currentThreadConnection.set(connProv);
	}

	public static void unbindProvider()
	{
		m_currentThreadConnection.set(null);
	}
	
	public static IConnectionProvider getProvider()
	{
		return m_currentThreadConnection.get();
	}
	
	public static void bind(Connection conn)
	{
		IConnectionProvider prov = getProvider();
		if(prov == null || !prov.adapt(conn))
		{
			bindProvider(new ConnectionWrapper(conn));
		}
	}

	public static void unbind()
	{
		IConnectionProvider prov = getProvider();
		if(prov != null && !prov.adapt(null))
		{
			unbindProvider();
		}
	}
	
	public static Connection getConnection()
	{
		IConnectionProvider cp = getProvider();
		return cp == null ? null : cp.getConnection();
	}
	
	public static interface IConnectionProvider
	{
		/**
		 * Returns currently active connection, creating it if it didn't exist
		 * 
		 * @return
		 */
		public Connection getConnection();
		
		/**
		 * Legacy support: Connections bound using {@link CCurrentThreadConnection#bind(Connection)} will first be fed
		 * to this method; if this connectionProvider acceps such a connection and can serve it using its {@link #getConnection()} method,
		 * then <code>true</code> must be returned.<br/>
		 * If <code>false</code> is returned, then the current connectionProvider will be replaced with a default one.
		 * 
		 * @param conn
		 * @return true if this connection provider is ready to handle binding of such connection, false otherwise
		 */
		public boolean adapt(Connection conn);
	}
	
	public static class ConnectionWrapper implements IConnectionProvider
	{
		private Connection conn;
		
		public ConnectionWrapper(Connection conn) {
			this.conn = conn;
		}
		
		@Override
		public boolean adapt(Connection conn) {
			this.conn = conn;
			return true;
		}
		
		@Override
		public Connection getConnection() {
			return conn;
		}
	}
}
