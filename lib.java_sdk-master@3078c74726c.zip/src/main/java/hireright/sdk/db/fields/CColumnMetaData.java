/*
 * @(#)$RCSfile: CColumnMetaData.java,v $ $Revision: 1.8 $ $Date: 2010/06/17 21:01:42 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CColumnMetaData.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev		2005-08-15	created (part of code is moved here from CCustomDataSet and optimized).
 *	A.Solntsev		2006-04-06	implements Serializable
 *	A.Solntsev		2006-05-12	implements IHasProperties
 *  A.Solntsev		2008-11-18	Performance improvements: all fields made final, setters removed.
 *  I.Lopatukhin	2010-06-03	NCHAR support added 
 */
package hireright.sdk.db.fields;

import hireright.sdk.util.CProperties;
import hireright.sdk.util.IHasProperties;

import java.io.Serializable;

/**
 * This class contains meta-data about table column:
 *  - column name
 *  - type
 *  - is column nullable?
 *  - size
 *  - precision
 *  - scale
 *  - is NCHAR column?
 * 
 * @author	Andrei Solntsev
 * @since 2005-08-18
 * @version $Revision: 1.8 $ $Date: 2010/06/17 21:01:42 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CColumnMetaData.java,v $
 */
public final class CColumnMetaData implements Serializable, IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	private final int m_nType;
	private final String m_sName;
	private final String m_sNameUpper;
	private final boolean m_bIsNullable;
	private final String m_sColumnTypeName;
	private final int m_nColumnDisplaySize;
	private final int m_nPrecision;
	private final int m_nScale;
	private final boolean m_bIsNChar;
	
	public CColumnMetaData(int type, String sName, boolean bIsNullable,
		String sColumnTypeName, int nColumnDisplaySize, int nPrecision, int nScale, boolean ... bIsNChar )
	{
		m_nType = type;
		m_sName = sName;
		m_sNameUpper = sName.toUpperCase();
		m_bIsNullable = bIsNullable;
		m_sColumnTypeName = sColumnTypeName;
		m_nColumnDisplaySize = nColumnDisplaySize;
		m_nPrecision = nPrecision;
		m_nScale = nScale;
		m_bIsNChar= bIsNChar.length >0 ? bIsNChar[0] : false ;
	}

	public int getColumnType()
	{
		return m_nType;
	}
	
	public String getColumnName()
	{
		return m_sName;
	}

	public String getColumnNameUpper()
	{
		return m_sNameUpper;
	}
	
	public boolean isNullable()
	{
		return m_bIsNullable;
	}
	
	public String getColumnTypeName()
	{
		return m_sColumnTypeName;
	}
	
	public int getColumnDisplaySize()
	{
		return m_nColumnDisplaySize;
	}
	
	public int getPrecision()
	{
		return m_nPrecision;
	}
	
	public int getScale()
	{
		return m_nScale;
	}
	
	public boolean isNChar() 
	{
		return m_bIsNChar;
	}
	
	/**
	 * @since java_sdk_v2-6-9
	 */
	public CProperties toProperties()
	{
		return new CProperties()
			.setProperty("name", m_sName)
			.setProperty("type", m_sColumnTypeName)
			.setProperty("isNullable", isNullable());
	}
	
	@Override
	public String toString()
	{
		return "Column " + m_sName + " " + m_sColumnTypeName;
	}
}