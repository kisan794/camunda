/*
 * @(#)$RCSfile: CFieldsFactory.java,v $ $Revision: 1.7 $ $Date: 2015/11/02 20:16:19 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CFieldsFactory.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  A.Solntsev		2005-08-17	created
 *  S.Ignatov 		2015-07-24	added case Types.NCLOB
 */
package hireright.sdk.db.fields;
import hireright.sdk.db.CField;

import java.io.Serializable;
import java.sql.Types;

/**
 * 
 * @author asolntsev
 * @version $Revision: 1.7 $ $Date: 2015/11/02 20:16:19 $ $Author: cvsroot $
 */
public class CFieldsFactory implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
	private static final CFieldsFactory m_instance = new CFieldsFactory();
	private CFieldsFactory()
	{
	}
	
	public static CFieldsFactory getFactory()
	{
		return m_instance;
	}
	
	public CField createRowIdField(String sRowIdColumn, String sTableName, boolean isActive)
	{
		return new CRowidField(sRowIdColumn, sTableName, isActive);
	}
	
	public CField createField(CColumnMetaData column, String sTableName, boolean lobsSupported)
	{
		CField field = null;
		
		switch (column.getColumnType())
		{
			case Types.VARCHAR:
			case Types.CHAR:
				field = new CStringField(column, sTableName);
				break;					
			case Types.NUMERIC:
			case Types.REAL:
			case Types.DECIMAL:
			case Types.DOUBLE:
			case Types.FLOAT:
				field = new CNumericField(column, sTableName);
				break;
			case Types.INTEGER:
				field = new CIntegerField(column, sTableName);
				break;
			case Types.DATE:
			case Types.TIMESTAMP:
				field = new CDateField(column, sTableName);
				break;
			case Types.CLOB:
			case Types.NCLOB:
				field = new CCLOBField(column, sTableName);
				if (!lobsSupported)
					field = null;
				break;
			case Types.BLOB:
				field = new CBLOBField(column, sTableName);
				if (!lobsSupported)
					field = null;
				break;
			default:
				field = new CStringField(column, sTableName);
				break;
		}
		
		return field;
	}
}
