/*
 * @(#)$RCSfile: CRowidField.java,v $ $Revision: 1.5 $ $Date: 2009/05/11 14:56:41 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CRowidField.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev		2005-08-29	created
 *	A.Solntsev		2008-11-18	Performance improvements: all fields made final, setters removed.
 *								Added members m_sExpression, m_sExpressionUpper for re-using those values.
 *	A.Solntsev		2009-05-05	Added method isRowId()
 */
package hireright.sdk.db.fields;
import java.sql.Types;

/**
 * Class implements a string column of database table.
 * Generally, it can contain any values.
 *
 * @author	Andrei Solntsev
 * @date		2005-08-29
 * @since		java_sdk_v2-5-31
 * @version $Revision: 1.5 $ $Date: 2009/05/11 14:56:41 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CRowidField.java,v $
 */
public class CRowidField extends CStringField
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: asolntsev $";

	// private final String m_sRowIdColumn;
	private final String m_sExpression;
	private final String m_sExpressionUpper;

	public CRowidField(String sRowIdColumn, String sTableName, boolean isActive)
	{
		super(
			new CColumnMetaData(
				Types.VARCHAR, "ROWIDTOCHAR(" + sRowIdColumn + ")",
				true, "VARCHAR2",	0x0FFFFF, 0, 0),

			sTableName,	// name of table
			true,				// is read-only
			isActive		// ia active
			);

		// m_sRowIdColumn = sRowIdColumn;

		// Initialize "expression" and "expressionUpper"
		m_sExpression = (sTableName == null) ? getName()
				: "ROWIDTOCHAR(" + sTableName + "." + sRowIdColumn + ")";
		m_sExpressionUpper = m_sExpression.toUpperCase();
	}

	@Override
	public final boolean isRowId()
	{
		return true;
	}

	@Override
	protected final String getExpression()
	{
		return m_sExpression;
	}

	@Override
	protected final String getExpressionUpper()
	{
		return m_sExpressionUpper;
	}
}