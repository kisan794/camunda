/*
 * @(#)$RCSfile: CCLOBField.java,v $ $Revision: 1.14 $ $Date: 2015/11/02 20:15:17 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CCLOBField.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2002-xx-xx	Sergei Ignatov	Created.
 *  2004-04-19	Daniel Travin	saveClob changed.
 *  2004-04-28	Anton Keks		workaround of oracle's bug
 *  2005-08-08	A.Solntsev		Now ROWID is binded. This enables Oracle to cache statements.
 *  2005-08-21	A.Solntsev		Method saveCLOB() moved to CLobUtils.
 *  2005-10-12	A.Solntsev		Removed direct usage of class OracleCallableStatement.
 *  2005-10-26	A.Solntsev		Removed direct usage of OracleResultSet.
 *  2005-10-26	A.Solntsev		Method saveCLOB() is now nonstatic.
 *  2006-05-15	A.Solntsev		Removed method createClobLocator() since it's not used.
 * 	2006-11-01	A.Solntsev		Methods setInteger(), setString() are public now
 * 	2007-01-09	A.Solntsev		Return true when setting null value to nullable column
 * 	2007-01-22	A.Solntsev		(non-serializable) member m_clobLocator is now transient
 * 	2007-11-05	A.Solntsev		setFromRecordSet(): removed dependency on Oracle JDBC
 *  I.Lopatukhin	2010-06-03	NCHAR support added 
 *  M.Saddarov		2010-08-26	nchar check added when writing clobs
 *  V.Ozernov			2020-02-13	HIVPE-113095 saveCLOB() re-throws SQLException
 */
package hireright.sdk.db.fields;
import hireright.sdk.db.CField;
import hireright.sdk.db.fields.CColumnMetaData;
import hireright.sdk.db.sql.CLobUtils;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CDataSanitizer;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;

import hireright.sdk.util.CProperties;

/**
 *	COMMENT ME
 *
 *  @author	Sergei Ignatov
 *  @since 2002
 *  @version $Revision: 1.14 $ $Date: 2015/11/02 20:15:17 $ $Author: cvsroot $
 *  @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CCLOBField.java,v $
 */
public class CCLOBField extends CField
{
	private static final long serialVersionUID = -6935814216085038931L;

	protected static final String CLASS_VERSION = "$Revision: 1.14 $ $Author: cvsroot $";
	
	/**
	 * non-serializable member
	 */
	private transient Clob m_clobLocator = null;

	/**
	 * @serial
	 */
	private String m_sValue;

	public CCLOBField(CColumnMetaData columnMetaData, String sTableName)
	{
		super(columnMetaData, sTableName);
		m_sValue = null;
	}

	@Override
	public Object getValue()
	{
		return (m_sValue == null)? null : m_sValue.trim();
	}

	@Override
	public final Clob getClobLocator()
	{
		return m_clobLocator;
	}

	@Override
	public boolean setString(String sValue)
	{
		return setClob(sValue);
	}

	@Override
	public boolean setClob(String szValue)
	{
		// check for null if not null field
		if (!isNullable() && szValue == null)
			return true;

		boolean boolChange = false;
		String sNewValue = szValue;
		if (szValue == null)
		{
			if (m_sValue != null)
			{
				boolChange = true;
			}
		}
		else
		{
			// cut string if longer
			if (szValue.length() > getLength())
			{
				sNewValue = szValue.substring(0, getLength());
			}

			// check change state
			boolChange = (m_sValue == null || sNewValue.compareTo(m_sValue) != 0);
		}

		if (boolChange)
		{
			m_sValue = sNewValue;
			setChanged(true);
		}

		return true;
	}

	@Override
	public boolean setDate(Date dateValue)
	{
		CTraceLog.warning("Trying to set Date to Clob column",
				getClass().getName() + ".setDate()", toProperties());

		String szValue = null;

		if (dateValue != null)
			szValue = DateFormat.getDateInstance().format(dateValue);

		return setClob(szValue);
	}

	@Override
	public boolean setBoolean(Boolean boolValue)
	{
		CTraceLog.warning("Trying to set Boolean to Clob column",
				getClass().getName() + ".setBoolean()", toProperties());
		return setClob( (boolValue.booleanValue()) ? "Y" : "N");
	}

	public boolean setDouble(Double doubleValue)
	{
		CTraceLog.warning("Trying to set Double to Clob column",
				getClass().getName() + ".setDouble()", toProperties());
		String szValue = (doubleValue == null) ? null : doubleValue.toString();
		return setClob(szValue);

	}

	@Override
	public boolean setInteger(Integer nValue)
	{
		CTraceLog.warning("Trying to set Integer to Clob column",
				getClass().getName() + ".setInteger()", toProperties());
		String szValue = (nValue == null) ? null : nValue.toString();
		return setClob(szValue);
	}

	@Override
	public void setNull()
	{
		m_sValue = null;
	}

	@Override
	public void setFromRecordSet(ResultSet rst, int nIndex)
	{
		try
		{
			m_clobLocator = rst.getClob(nIndex);
			// oracle.sql.CLOB clob = (oracle.sql.CLOB) rst.getClob(nIndex);
			Clob clob = rst.getClob(nIndex);

			String szValue = null;
			if (clob != null)
			{
				szValue = clob.getSubString(1, (int) m_clobLocator.length());
			}

			setClob( szValue );

			if (rst.wasNull())
			{
				setNull();
			}

			setChanged(false);
		}
		catch (Exception e)
		{
			CTraceLog.error(e, getClass().getName()+".setFromRecordSet()", toProperties().setProperty("index", nIndex));
		}
	}

	@Override
	public boolean setValueToCallableStatement( CallableStatement pstmt, int index )
	{
		/*if (m_sValue == null)
		{
			pstmt.setNull(nIndex, Types.CLOB);
			return true;
		}
		else if (m_sValue.length() > CLobUtils.MAX_CLOB_LENGTH)
		{
			pstmt.setString(nIndex, m_sValue);
			return true;
		}
		else*/
		return false;
	}

	@Override
	protected void setParamToPrepStatement(PreparedStatement pstmt, int nIndex) throws SQLException
	{
		// CLOBs are stored to dababase later with a separate call
	}

	@Override
	public int getLength()
	{
		return 0x0FFFFFF;	// ???
	}

	public Clob getLocator()
	{
		return m_clobLocator;
	}

	/**
	 * Saves CLOB by creating new temporary clob and then updating locator into table by rowcharid.
	 * @param conn
	 * @param sRowIdColumn FIXME	Why it's not used?
	 * @param rowid rowid
	 * @throws SQLException
	 */
	public void saveCLOB(Connection conn, String sRowIdColumn, String rowid) throws SQLException
	{
		try
		{
			boolean disabledTransliteration = hireright.objects.rollout_feature.CRolloutFeatureCache.getInstance().isFeatureGloballyGranted("UTFINST_TRANSL_DISABLED");
			boolean bIsNChar = isNChar();
			if(!disabledTransliteration && !bIsNChar)
			{
				m_sValue = CDataSanitizer.replace(m_sValue);
			}
			CLobUtils.saveClob(conn, getTableName(), this.getName(),
				rowid, m_sValue, bIsNChar);
		}
		catch (Exception e)
		{
			CProperties params = toProperties()
				.setProperty("sRowIdColumn", sRowIdColumn)
				.setProperty("source", getTableName())
				.setProperty("rowid", rowid);
			if (m_sValue != null && m_sValue.length()<103)
			{
				params.setProperty("clob", m_sValue);
			}
			else if (m_sValue != null)
			{
				params.setProperty("clob", m_sValue.substring(0, 100) + "...");
			}

			CTraceLog.error(e, getClass().getName() + ".saveCLOB()", params);
			throw e;
		}
	}
}