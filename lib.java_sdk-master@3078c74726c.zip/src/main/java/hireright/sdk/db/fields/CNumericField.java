/*
 * @(#)$RCSfile: CNumericField.java,v $ $Revision: 1.10 $ $Date: 2009/11/20 11:28:53 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CNumericField.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov		2001-01		created
 *  A.Solntsev		2005-08-17	Redesign
 *  A.Solntsev		2006-11-01	Methods setInteger(), setString(), setFloat() are public now
 *  A.Solntsev		2007-01-09	Return true when setting null value to nullable column
 *  A.Solntsev		2007-02-21	Added method setFloat(float value)
 *  A.Solntsev		2007-02-21	Added methods setNumber(Number), setLong(Long)
 *  A.Solntsev		2009-07-09	Added methods getLongValue(), getNumericValue(), getCharValue(), setNumber(), setLong()
 *  A.Solntsev		2009-11-04	Method isChanged() has been made public (for using in unit tests)
 */
package hireright.sdk.db.fields;
import hireright.sdk.db.CField;
import hireright.sdk.util.CRuntimeException;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Class implements a numeric column of database table.
 * It can contain float, double, integer values.
 *
 * @author	Sergei Ignatov
 * @since 2001-01
 * @version $Revision: 1.10 $ $Date: 2009/11/20 11:28:53 $ $Author: cvsroot $
 */
public class CNumericField extends CField
{
	protected static final String CLASS_VERSION = "$Revision: 1.10 $ $Author: cvsroot $";
	
	private Number m_dValue;

	/**
	 * Constructor with table name and columnd meta data.
	 * @param sTableName
	 * @param columnMetaData
	 */
	public CNumericField(CColumnMetaData columnMetaData, String sTableName)
	{
		super(columnMetaData, sTableName);
		m_dValue = null;
	}

	@Override
	protected boolean isEqual(Object oldValue, Object newValue)
	{
		return ((Number)newValue).doubleValue() == ((Number)oldValue).doubleValue();
	}
	
	@Override
	public boolean setString(String sValue)
	{
		throw new CUnsupportedColumnType("Cannot set String value to numeric column",
				getClass().getName() + ".setString()", toProperties().setProperty("value", sValue));
	}

	@Override
	protected void setParamToPrepStatement(PreparedStatement pstmt, int nIndex) throws SQLException
	{
		if (m_dValue == null)
			pstmt.setNull(nIndex, Types.NUMERIC);
		else if ( m_dValue.longValue() ==  m_dValue.doubleValue())
			pstmt.setLong(nIndex, m_dValue.longValue());
		else
			pstmt.setDouble(nIndex, m_dValue.doubleValue());
	}

	@Override
	public Float getFloatValue()
	{
		if (m_dValue == null || (m_dValue instanceof Float))
			return (Float) m_dValue;
		else if (m_dValue != null)
			return Float.valueOf(m_dValue.floatValue());

		return null;
	}

	/**
	 * Method tries to represent field content as Long.
	 * If fails (field has more precise value than Long), method represents it as Double.
	 * @return String.valueOf( THIS.VALUE)
	 */
	@Override
	public String getStringValue()
	{
		if (m_dValue == null)
			return null;

		if ( m_dValue.longValue() ==  m_dValue.doubleValue())
			return String.valueOf( m_dValue.longValue());
		else
			return String.valueOf( m_dValue.doubleValue());
	}

	@Override
	public Integer getIntegerValue()
	{
		if (m_dValue == null || (m_dValue instanceof Integer))
			return (Integer) m_dValue;
		else if (m_dValue != null)
			return Integer.valueOf(m_dValue.intValue());

		return null;
	}

	@Override
	protected Double getDoubleValue()
	{
		if (m_dValue == null || (m_dValue instanceof Double))
			return (Double) m_dValue;
		else if (m_dValue != null)
			return Double.valueOf(m_dValue.doubleValue());

		return null;
	}

	@Override
	public Object getValue()
	{
		return m_dValue;
	}

	@Override
	public boolean setNumber(Number numericValue)
	{
		if (!isNullable() && numericValue == null)
			return false;

		setChanged(m_dValue, numericValue);
		m_dValue = numericValue;

		return true;
	}
	
	@Override
	public boolean setNumber(Double doubleValue)
	{
		return setNumber( (Number) doubleValue );
	}
	
	public boolean setDouble(double doubleValue)
	{
		return setDouble( Double.valueOf(doubleValue) );
	}
	
	@Override
	public boolean setDouble(Double doubleValue)
	{
		return setNumber( (Number) doubleValue );
	}

	@Override
	protected boolean setFloat(float fValue)
	{
		return setNumber(Float.valueOf( fValue ));
	}

	@Override
	public final boolean setFloat(Float fValue)
	{
		return setNumber( fValue );
	}

	@Override
	public final boolean setInteger(Integer nValue)
	{
		/*if (nValue == null)
			return setNumber( null );
		else
			return setNumber( new Double( nValue.intValue() ) );
		*/
		return setNumber( nValue );
	}

	@Override
	public final boolean setInteger(int nValue)
	{
		return setInteger( Integer.valueOf(nValue) );
	}
	
	@Override
	protected boolean setLong(Long lValue)
	{
		return setNumber( lValue );
	}
	
	@Override
	protected boolean setLong(long lValue)
	{
		return setNumber( Long.valueOf(lValue) );
	}

	@Override
	public void setNull()
	{
		m_dValue = null;
	}

	/**
	 * @param rst
	 * @param nIndex
	 * @throws CRuntimeException if SQLException occurred
	 */
	@Override
	public void setFromRecordSet(ResultSet rst, int nIndex)
	{
		try
		{
			setNumber( Double.valueOf(rst.getDouble(nIndex)) );
			if (rst.wasNull())
				setNull();

			setChanged(false);
		}
		catch (SQLException e)
		{
			throw new CRuntimeException(e, getClass().getName()+".setFromRecordSet()",
				toProperties().setProperty("index", nIndex));
		}
	}

	@Override
	public boolean setValueToCallableStatement(CallableStatement pstmt, int nIndex) throws SQLException
	{
		if (m_dValue == null)
			pstmt.setNull(nIndex, Types.NUMERIC);
		else
			pstmt.setDouble(nIndex, m_dValue.doubleValue());

		return true;
	}
}
