/*
 * @(#)$RCSfile: CIntegerField.java,v $ $Revision: 1.8 $ $Date: 2009/11/20 11:29:01 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CIntegerField.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov		2001-01		created
 *  A.Solntsev		2005-08-17	Redesign
 *  A.Solntsev		2006-11-01	Methods setInteger(), setString() are public now
 *  A.Solntsev		2007-01-09	Return true when setting null value to nullable column
 *  A.Solntsev		2009-07-09	Added methods getLongValue(), getNumericValue(), getCharValue(), setNumber(), setLong()
 */
package hireright.sdk.db.fields;
import hireright.sdk.db.CField;
import hireright.sdk.debug.CTraceLog;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Class implements an integer column of database table.
 * It can contain only integer values.
 * 
 * @author Sergei Ignatov
 * @since 2001-01
 */
public class CIntegerField extends CField
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	private Integer m_nValue;

	public CIntegerField(CColumnMetaData columnMetaData, String sTableName)
	{
		super(columnMetaData, sTableName);
		m_nValue = null;
	}
	
	@Override
	protected boolean isEqual(Object oldValue, Object newValue)
	{
		return ((Integer)newValue).intValue() == ((Integer)oldValue).intValue();
	}

	@Override
	public boolean setString(String sValue)
	{
		throw new CUnsupportedColumnType("Cannot set String value to numeric column",
				getClass().getName() + ".setString()", toProperties().setProperty("value", sValue));
	}

	@Override
	protected void setParamToPrepStatement(PreparedStatement  pstmt, int nIndex) throws SQLException
	{
		if (m_nValue == null)
			pstmt.setNull(nIndex, Types.NUMERIC);
		else  
			pstmt.setInt(nIndex, m_nValue.intValue());
	}

	@Override
	public Float getFloatValue()
	{
		if (m_nValue != null)
			return Float.valueOf(m_nValue.floatValue());	
	
		return null;
	}

	@Override
	public Integer getIntegerValue()
	{
		return m_nValue;
	}
	
	@Override
	public Double getDoubleValue()
	{
		if (m_nValue == null)
			return null;

		return Double.valueOf(m_nValue.doubleValue());
	}

	@Override
	public boolean setNumber(Number numericValue)
	{
		if (numericValue == null || (numericValue instanceof Integer))
			return setInteger( (Integer) numericValue );
		
		return setInteger( numericValue.intValue() );
	}
	
	@Override
	public boolean setDouble(Double fdValue) 
	{
		CTraceLog.error("Trying to set Double value to integer column",
			getClass().getName() + ".setDouble()", toProperties());

		if (fdValue != null)
			return setInteger( fdValue.intValue() );
	
		return setInteger(null);
	}

	@Override
	public boolean setInteger(Integer nValue) 
	{
		if (!isNullable() && nValue == null)
			return true;

		setChanged(m_nValue, nValue);		
		m_nValue = nValue;

		return true;
	}

	@Override
	public boolean setInteger(int nValue)
	{
		return setInteger( Integer.valueOf(nValue) );
	}
	
	@Override
	protected boolean setLong(Long lValue)
	{
		if (lValue == null)
			return setInteger( null );
		
		return setInteger( lValue.intValue() );
	}
	
	@Override
	protected boolean setLong(long lValue)
	{
		return setInteger( (int) lValue );
	}

	@Override
	public Object getValue()
	{
		return m_nValue ;
	}
	
	@Override
	public void setNull()
	{
		m_nValue = null;
	}

	@Override
	public void setFromRecordSet(ResultSet rst, int nIndex)
	{
		try
		{
			setInteger(Integer.valueOf(rst.getInt(nIndex)));
			if (rst.wasNull())
				setNull();

			setChanged(false);
		}
		catch(SQLException e)
		{
			CTraceLog.error(e, getClass().getName()+".setFromRecordSet()", toProperties().setProperty("index", nIndex));
		}
	}

	@Override
	public boolean setValueToCallableStatement(CallableStatement pstmt, int nIndex) throws SQLException
	{
		if (m_nValue == null)
			pstmt.setNull(nIndex, Types.INTEGER);
		else  
			pstmt.setInt(nIndex, m_nValue.intValue());
		
		return true;
	}
}
