/*
 * @(#)$RCSfile: CTableMetaData.java,v $ $Revision: 1.10 $ $Date: 2015/11/02 20:15:41 $ $Author: cvsroot $ 
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CTableMetaData.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2005-08-15	A.Solntsev	created (part of code is moved here from CCustomDataSet and optimized).
 *	2006-05-15	A.Solntsev	Added method getTableColumns()
 *	2008-07-18	A.Solntsev	Experiment: using SoftReference to enable class unloading
 *  2010-06-03	I.Lopatukhin NCHAR support added 
 */
package hireright.sdk.db.fields;
import java.io.Serializable;
import java.lang.ref.SoftReference;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * This class caches info about tables' columns.
 * Every field can be retrieved by table name and field name.
 * 
 * @author Andrei Solntsev
 * @since java_sdk_v2-5-33, 2005-08-15
 * @version $Revision: 1.10 $ $Date: 2015/11/02 20:15:41 $ $Author: cvsroot $ 
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CTableMetaData.java,v $
 */
public class CTableMetaData implements Serializable
{
	private static final Map<String, SoftReference<CTableMetaData>> m_tables 
		= new HashMap<String, SoftReference<CTableMetaData>>();
	
	public static CTableMetaData getTableMetaData(Connection conn,
		String sTableName) throws SQLException
	{
		return getTableMetaData(conn, sTableName,
			"SELECT * FROM " + sTableName + " WHERE ROWNUM < 1");
	}
	
	public static CTableMetaData getTableMetaData(Connection conn, 
				String sTableName, String sSelectMetaData) throws SQLException
	{
		CTableMetaData metaData = null;
		
		SoftReference<CTableMetaData> reference = m_tables.get(sSelectMetaData);
		if (reference != null)
			metaData = (CTableMetaData) reference.get();
		
		if (metaData == null)
		{
			synchronized (m_tables)
			{
				metaData = new CTableMetaData(conn, sTableName, sSelectMetaData);
				reference = new SoftReference<CTableMetaData>( metaData );

				m_tables.put(sSelectMetaData, reference);
			}
		}
		
		return metaData;
	}

		
	private final String m_sTableName;
	private final Map<String, CColumnMetaData> m_columns;
	
	private CTableMetaData(Connection conn, String sTableName, String sSelectMetaData) throws SQLException
	{
		m_sTableName = sTableName;
		m_columns = loadMetaData(conn, sSelectMetaData);
	}
	
	public CColumnMetaData getColumnMetaData(String sColumnName)
	{
		return (CColumnMetaData) m_columns.get(sColumnName);
	}
	
	public int getColumnType(String sColumnName)
	{
		return getColumnMetaData(sColumnName).getColumnType();
	}
	
	public String getColumnName()
	{
		return m_sTableName;
	}

	/**
	 * @since java_sdk_v2-6-9
	 */
	public Iterator<String> getTableColumnsNames()
	{
		return m_columns.keySet().iterator();
	}
	
	/**
	 * @return Iterator over instances of CColumnMetaData
	 */
	public Iterator<CColumnMetaData> getTableColumns()
	{
		return m_columns.values().iterator();
	}
	
	private final Map<String, CColumnMetaData> loadMetaData(Connection conn, String sSelectMetaData)
		throws SQLException
	{
		Map<String, CColumnMetaData> columnsMetaData = new HashMap<String, CColumnMetaData>();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			preparedStatement = conn.prepareStatement(sSelectMetaData);
			resultSet = preparedStatement.executeQuery();
			ResultSetMetaData metaData = resultSet.getMetaData();

			for (int nCounter = 1; nCounter <= metaData.getColumnCount(); nCounter++)
			{
				int nColumnType = metaData.getColumnType(nCounter);
				int nLength = 1000, nPrecision = 1000, nScale = 0;
				boolean bIsNChar = false;
				try
				{
					switch (nColumnType)
					{
						case oracle.jdbc.OracleTypes.ROWID:
							nLength = 1000;
							nPrecision = 1000;
							nScale = 0;
							bIsNChar = false;
							break;
						default:
							nLength = metaData.getColumnDisplaySize(nCounter);
							nPrecision = metaData.getPrecision(nCounter);
							nScale = metaData.getScale(nCounter);
							bIsNChar = ((oracle.jdbc.OracleResultSetMetaData)metaData).isNCHAR(nCounter);
					}
				}
				catch (Exception stE)
				{
					// throw new CRuntimeException(stE); // it causes errors, I don't understand why :(
				}
				
				if(nColumnType == Types.NCLOB)
				{
					nColumnType = Types.CLOB;
				}
				
				CColumnMetaData column = new CColumnMetaData(
					nColumnType,
					metaData.getColumnName(nCounter),
					metaData.isNullable(nCounter) > 0,
					metaData.getColumnTypeName(nCounter),
					nLength,
					nPrecision,
					nScale,
					bIsNChar);

					columnsMetaData.put(column.getColumnName(), column);
				}
		}
		finally
		{
			if (resultSet != null)
			{
				resultSet.close();
				resultSet = null;
			}
			if (preparedStatement != null)
			{
				preparedStatement.close();
				preparedStatement = null;
			}
		}
		
		return columnsMetaData;
	}
}