/*
 * @(#)$RCSfile: CDateField.java,v $ $Revision: 1.5 $ $Date: 2007/09/14 08:54:02 $ $Author: asolntsev $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov		2001-01-xx	created
 *  A.Solntsev		2005-08-17	Redesign
 *  M.Abdulganejev 	2006-02-22	java_sdk_v2-6-6: class casting in getDateValue() changed to new object instatiation
 *  A.Solntsev		2007-01-09	Return true when setting null value to nullable column
 */
package hireright.sdk.db.fields;
import hireright.sdk.db.CField;
import hireright.sdk.debug.CTraceLog;
import java.sql.*;

/**
 * Class implements a Date column of database table.
 * It can contain java.util.Date, java.sql.Date, java.sql.Timestamp values.
 * 
 * @author	Sergei Ignatov
 * @date		2001-01
 */
public class CDateField extends CField
{
	private Timestamp m_dateValue;

	public CDateField(CColumnMetaData columnMetaData, String sTableName)
	{
		super(columnMetaData, sTableName);
		m_dateValue = null;
	}
	
	protected void setParamToPrepStatement(PreparedStatement pstmt, int nIndex) throws SQLException
	{
		if (m_dateValue == null)
			pstmt.setNull(nIndex, Types.TIMESTAMP);
		else
			pstmt.setTimestamp(nIndex, m_dateValue);
	}

	public void setNull()
	{
		m_dateValue = null;
	}

	public java.util.Date getDateValue()
	{
        return ( (m_dateValue == null ) ? null : new java.util.Date ( m_dateValue.getTime() ) );
	}

	public java.sql.Date getSQLDateValue()
	{
		if (m_dateValue == null)
			return null;
 
		return new java.sql.Date(m_dateValue.getTime());
	}

	public Timestamp getTimestampValue()
	{
		return m_dateValue;
	}

	public Object getValue()
	{
		return m_dateValue;
	}

	public boolean setValueToCallableStatement(CallableStatement pstmt, int nIndex) throws SQLException
	{
		if (m_dateValue == null)
			pstmt.setNull(nIndex, Types.DATE);
		else  
			pstmt.setTimestamp(nIndex, m_dateValue);
		
		return true;
	}

	public boolean setDate(java.sql.Date dateValue)
	{
		if (dateValue == null)
		{
			java.sql.Timestamp date = null;
			return setDate(date);
		}
		else  
			return setDate(new Timestamp(((java.util.Date) dateValue).getTime()));
	}

	public boolean setDate(Timestamp dateValue)
	{
		if (!isNullable() && dateValue == null)
			return true;

		setChanged(m_dateValue, dateValue);
		m_dateValue = dateValue;
 
		return true;
	}

	public boolean setDate(java.util.Date dateValue)
	{
		if (dateValue == null)
		{
			java.sql.Timestamp date = null;
			return setDate(date);
		}
		else  
			return setDate(new Timestamp(dateValue.getTime()));
	}

	public void setFromRecordSet(ResultSet rst, int nIndex)
	{
		try
		{
			setDate(rst.getTimestamp(nIndex));
			if (rst.wasNull())
				setNull();

			setChanged(false);
		}
		catch (SQLException e)
		{
			CTraceLog.error(e, getClass().getName()+".setFromRecordSet()", toProperties().setProperty("index", nIndex));
		}
	}
}