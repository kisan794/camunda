/*
 * @(#)$RCSfile: CMirrorField.java,v $ $Revision: 1.5 $ $Date: 2008/11/21 11:32:20 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CMirrorField.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Rudenko		2001-06-20	Initial revision
 *	S.Ignatov		2001-11-15	added to java_sdk_db from revision 1.2
 *  A.Solntsev		2005-08-17	Move to package hireright.sdk.db.fields
 *  A.Solntsev		2006-11-01	implements Serializable
 *  A.Solntsev		2008-11-18	Performance improvements: all fields made final, setters removed.
 */
package hireright.sdk.db.fields;

import java.io.Serializable;

/**
 *	@author	Sergei Ignatov
 *  @since	java_sdk_v2-4
 *  @date 	2001-06-20
 *  @version $Revision: 1.5 $ $Date: 2008/11/21 11:32:20 $ $Author: cvsroot $
 *	@source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CMirrorField.java,v $
 */
public final class CMirrorField implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	private final String m_szSourceFieldName;
	private final String m_szFieldName;	
	private final String m_szFieldNameUpper;

	public CMirrorField(String szFieldName, String szMirrorName)
	{
		super();
		m_szSourceFieldName = szFieldName;
		m_szFieldName = szMirrorName;
		m_szFieldNameUpper = m_szFieldName.toUpperCase();
	}

	public String getFieldName()
	{
		return m_szFieldName;
	}

	public String getFieldNameUpper() 
	{
		return m_szFieldNameUpper;
	}

	public String getSourceFieldName() 
	{
		return m_szSourceFieldName;
	}

	@Override
	public String toString() 
	{
		return "SOURCE=" + m_szSourceFieldName + "; NAME=" + m_szFieldName;
	}
}