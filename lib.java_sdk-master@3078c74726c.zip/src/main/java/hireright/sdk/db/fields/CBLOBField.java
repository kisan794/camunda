/*
 * @(#)$RCSfile: CBLOBField.java,v $ $Revision: 1.8 $ $Date: 2007/11/09 09:43:48 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CBLOBField.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2002-xx-xx	Sergei Ignatov		Created.
 *  ...
 *  2005-08-08	A.Solntsev			Now ROWID is binded. This enables Oracle to cache statements.
 *  2005-10-12	A.Solntsev			Removed direct usage of class OracleCallableStatement.
 *  2005-12-03	A.Solntsev			Added method getBlobContent().
 *  2007-01-09	A.Solntsev			Return true when setting null value to nullable column
 *  2007-02-09	A.Solntsev			Added method getStringValue() (it's overridden from superclass)
 *  2007-11-05	A.Solntsev			saveBLOB(): removed dependency on Oracle JDBC
 */
package hireright.sdk.db.fields;

import hireright.sdk.db.CField;
import hireright.sdk.db.sql.CLobUtils;
import hireright.sdk.debug.CTraceLog;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Class implements a Blob column of database table.
 *
 * @author Sergei Ignatov
 * @since 2002
 * @version $Revision: 1.8 $ $Date: 2007/11/09 09:43:48 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CBLOBField.java,v $
 */
public class CBLOBField extends CField
{
	protected Blob m_blobLocator = null;
	protected byte[] m_content = null;

	public CBLOBField(CColumnMetaData columnMetaData, String sTableName)
	{
		super(columnMetaData, sTableName);
	}

	public Object getValue()
	{
		return m_blobLocator;
	}

	protected Blob getBlobValue()
	{
		return m_blobLocator;
	}

	protected byte[] getBlobContent() throws SQLException
	{
		if (m_blobLocator == null)
			return null;
		if (m_content != null)
			return m_content;

		long lBlobSize = m_blobLocator.length();
		m_content = m_blobLocator.getBytes(1, (int) lBlobSize);
		return m_content;
	}

	public String getStringValue()
	{
		try
		{
			if (getBlobContent() == null)
				return null;

			return new String(getBlobContent());
		}
		catch (SQLException sqle)
		{
			throw new RuntimeException(sqle);
		}
	}

	// FIXME	I think this method is not needed.
	//				Currently it's used only in CCompositeTable (methods INSERT and UPDATE).
	public boolean setBlob(Blob blobLocator)
	{
		// check for null if not null field
		if (!isNullable() && m_blobLocator == null)
			return true;

		setChanged(m_blobLocator, blobLocator);
		m_blobLocator = blobLocator;

		return true;
	}

	protected boolean setBlob(byte[] content)
	{
		// check for null if not null field
		if (!isNullable() && content == null)
			return true;

		setChanged(m_content, content);
		m_content = content;
		return true;
	}

	public void setNull()
	{
		m_blobLocator = null;
		m_content = null;
	}

	public void setFromRecordSet(ResultSet rst, int nIndex)
	{
		try
		{
			m_blobLocator = rst.getBlob(nIndex);
			if (rst.wasNull())
			  setNull();

			setChanged(false);
		}
		catch (Exception e)
		{
			CTraceLog.error(e, getClass().getName()+".setFromRecordSet()", toProperties().setProperty("index", nIndex));
		}
	}

	public boolean setValueToCallableStatement(CallableStatement pstmt, int nIndex) throws SQLException
	{
		// do nothing.
		return false;
	}


	protected void setParamToPrepStatement(PreparedStatement pstmt, int nIndex) throws SQLException
	{
		// do nothing.
	}

	public int getLength()
	{
		return 0x0FFFFFF; //???
	}

	public Blob getBlobLocator()
	{
		return m_blobLocator;
	}

	public void saveBLOB(Connection conn, String sRowIdColumn, String rowid )
		throws SQLException, IOException
	{
		if (m_content == null)
			return;

		// BLOB saving procedure follows

		Blob blob;

		if (isNull())
		{
			// Create an empty BLOB before getting the locator
			blob = CLobUtils.createBlobLocator(conn,
			 getTableName(), getColumnName(), sRowIdColumn, rowid);
		}
		else
		{
			// Get the existing BLOB
			blob = getBlobLocator();
		}

		// Write the array to the BLOB
		OutputStream outputStream = blob.setBinaryStream(0L);
		try
		{
			outputStream.write(m_content);
			outputStream.flush();
		}
		finally
		{
			try
			{
				outputStream.close();
			}
			catch (IOException ioe)
			{
				// Let's ignore it ?
			}
		}
	}
}