/*
 * @(#)$RCSfile: CStringField.java,v $ $Revision: 1.9 $ $Date: 2009/07/10 12:27:37 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CStringField.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov		2001-01		created
 *	A.Solntsev		2005-08-17	Redesign
 *	A.Solntsev		2006-11-01	Methods setInteger(), setString(), setFloat() are public now
 *	A.Solntsev		2007-01-09	Return true when setting null value to nullable column
 *	A.Solntsev		2007-12-28	bugfix for LONG columns: if maximum length is unknown, it's equal to 0.
 *	A.Solntsev		2009-07-09	Added methods getLongValue(), getNumericValue(), getCharValue(), setNumber(), setLong()
 */
package hireright.sdk.db.fields;
import hireright.sdk.db.CField;
import hireright.sdk.debug.CTraceLog;
import java.sql.*;
import java.text.DateFormat;

/**
 * Class implements a string column of database table.
 * Generally, it can contain any values.
 *
 * @author Sergei Ignatov
 * @since 2001-01
 * @version $Revision: 1.9 $ $Date: 2009/07/10 12:27:37 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/fields/CStringField.java,v $
 */
public class CStringField extends CField
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: asolntsev $";

	protected String m_szValue;

	public CStringField(CColumnMetaData columnMetaData, String sTableName)
	{
		super(columnMetaData, sTableName);
		m_szValue = null;
	}

	public CStringField(CColumnMetaData columnMetaData, String sTableName, boolean bReadOnly, boolean isActive)
	{
		super(columnMetaData, sTableName, bReadOnly, isActive);
		m_szValue = null;
	}

	@Override
	public Object getValue()
	{
		if (m_szValue != null)
			return m_szValue; //.trim();

		return m_szValue;
	}

	@Override
	public boolean setString(final String szValue)
	{
		if (!isNullable() && szValue == null)
			return true;

		final String normalizedValue;
		if (szValue != null && getLength() > 0 && szValue.length() > getLength())	// cut string if longer
		{
			// if maximum length is unknown, it's equal to 0.
			normalizedValue = szValue.substring(0, getLength());
		}
		else
			normalizedValue = szValue;

		setChanged(m_szValue, normalizedValue);
		m_szValue = normalizedValue;

		return true;
	}
	
	@Override
	public boolean setCharValue(Character charValue)
	{
		if (charValue == null)
			return setString( null );
		else
			return setString( String.valueOf(charValue) );
	}
	
	@Override
	public boolean setCharValue(char charValue)
	{
		return setString( String.valueOf(charValue) );
	}

	@Override
	public boolean setDate(Date dateValue)
	{
		CTraceLog.error("Trying to set Date value to String field",
			getClass().getName() + ".setDate()", toProperties());
		String szValue = null;

		if (dateValue != null)
			szValue = DateFormat.getDateInstance().format(dateValue);

		return setString(szValue);
	}

	@Override
	protected void setParamToPrepStatement(PreparedStatement  pstmt, int nIndex) throws SQLException
	{
		if (m_szValue == null)
			pstmt.setNull(nIndex, Types.VARCHAR);
		else
			pstmt.setString(nIndex, m_szValue);
	}

	@Override
	public boolean setDouble(Double dValue)
	{
		CTraceLog.error("Trying to set Double value to String field",
			getClass().getName() + ".setDouble()", toProperties());
		return setString( (dValue==null)? null : dValue.toString());
	}

	@Override
	public boolean setInteger(Integer nValue)
	{
		CTraceLog.error("Trying to set Integer value to String field",
			getClass().getName() + ".setInteger()", toProperties());
		String sValue = (nValue == null) ? null : nValue.toString();
		return setString(sValue);
	}

	@Override
	public void setNull()
	{
		m_szValue = null;
	}

	@Override
	public boolean setValueToCallableStatement(CallableStatement pstmt, int nIndex) throws SQLException
	{
		if (m_szValue == null)
			pstmt.setNull(nIndex, Types.VARCHAR);
		else
			pstmt.setString(nIndex, m_szValue);

		return true;
	}

	@Override
	public void setFromRecordSet(ResultSet rst, int nIndex)
	{
		try
		{
			setString(rst.getString(nIndex));
			if (rst.wasNull())
				setNull();

			setChanged(false);
		}
		catch (SQLException e)
		{
			CTraceLog.error(e, getClass().getName()+".setFromRecordSet()", toProperties().setProperty("index", nIndex));
		}
	}
}
