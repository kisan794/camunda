/*
 * @(#)$RCSfile: CTable.java,v $ $Revision: 1.11 $ $Date: 2009/03/20 10:33:31 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CTable.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2001-11-16	S.Ignatov		created
 *  2002-02-08	S.Ignatov		added empty procedure setGroup and working procedure setReadOnly, dataset with it doesnt call save procedures.
 *  2002-08-22	S.Ignatov		delete methods returns result of delete, instead result of next record retrieving
 *  2002-10-09	S.Ignatov		development update. logs writing into CTraceLog
 *	2005-08-20	A.Solntsev		[java_sdk_v2-5-31] Removed method delete().
 *  2005-08-23	A.Solntsev		[java_sdk_v2-5-31] redesign
 *  2005-10-12	A.Solntsev		[java_sdk_v2-5-34] Removed direct usage of class OracleCallableStatement.
 *	2006-04-27	A.Solntsev		[java_sdk_v2-6-9] Used CCurrentThreadConnection instead of java.sql.Connection member
 *	2005-08-29	A.Solntsev		[java_sdk_v2-6-13] Improved logging of exceptions
 *	2006-11-01	A.Solntsev		[java_sdk_v2-6-20] removed annoying deprecation warnings
 *	2006-11-01	A.Solntsev		[java_sdk_v2-6-20] Added constructor CTable(String sTableName, String sPKFieldName, String sSequenceName)
 *	2009-03-17	A.Solntsev		Method executeDelete() throw exception if called on read-only object
 */
package hireright.sdk.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Interface to table database objects. 
 *
 * last modified 2001/11/15
 * 
 * de-pre-cated		It's better to use class CFTable instead
 */
public class CTable extends CCustomDataSet
{
	protected static final String CLASS_VERSION = "$Revision: 1.11 $ $Author: cvsroot $";
	
	protected String m_szPKFieldName;
	protected String m_szSequenceName;
	
	private String getFilterString(String szPrefixIfNotNull)
	{
		String szResult = getFilterString();
		return (szResult.length() > 0?(szPrefixIfNotNull + szResult):"");
	}
	
	private boolean executeDelete(boolean deleteAll)
	{
		if (isReadOnly())
		{
			throw new IllegalStateException("Method executeDelete() called on read-only object");
		}
		
		Connection conn = CCurrentThreadConnection.getConnection();
		
		if (conn == null)
			return false;

		boolean boolResult = false;

		PreparedStatement  pstmt = null;
		String sStatement = "";		
		try
		{
			if(deleteAll)
			{
				sStatement = "DELETE FROM " + 
					getSource() + 
					getFilterString(" WHERE ");
				pstmt =  conn.prepareStatement(sStatement);
			}
			else
			{
				String sRowid = getString("ROWIDTOCHAR(" + m_source.getIdentificationColumn() + ")");
				if(sRowid == null)
					return false;
				sStatement = "DELETE FROM " + getSource() +
					" WHERE " + m_source.getIdentificationColumn() + " = " + 
					"CHARTOROWID(?)";
				pstmt =  conn.prepareStatement(sStatement);
				
				pstmt.setString(1, sRowid);
			}
			pstmt.executeUpdate();
			if(pstmt.getUpdateCount() > 0)
				boolResult = true;
			else
				boolResult = false;
			
		}
		catch( SQLException sqle )
		{
			CDBException e = new CDBException(
					"Failed to delete records from table",
					sqle, getClass().getName() + ".executeDelete()",
					toProperties(),
					"Query:\n" + m_sQuery + "\n\nstatement:" + sStatement);
					
			CDBException.logMe(e);
			boolResult = false;
		}

		try
		{
			if (pstmt != null)
			{
				pstmt.close();
				pstmt = null;
			}
		}
		catch(Exception e)
		{
		}

		return boolResult;
	}

	/**
	 * Delete all rows from table, depend on filters values.
	 *
	 */
	public boolean deleteAll()
	{
		return executeDelete(true);
	}	

	/**
	 * Return Primary Key name for this table. Not supported Multiply column primary keys. 
	 * Warning! Automatic primary key values generation not reccomended. 
	 *
	 * @return primary key column name. 
	 */
	public String getPKFieldName() 
	{
		return (m_szPKFieldName == null ? "" : m_szPKFieldName);
	}

	/**
	 * Return name of the sequence, attached to this table.
	 * Warning! Automatic primary key values generation not reccomended. 
	 *
	 * @return name of the sequence, which will be used for primary key values generation. 
	 */
	public String getSequenceName() 
	{
		return m_szSequenceName;
	}

	/**
	 * Set name of Primary Key for this table. Not supported Multiply column primary keys. 
	 * Warning! Automatic primary key values generation not reccomended. 
	 *
	 * @param szPKFieldName primary key column name. 
	 */
	public final void setPKFieldName(String szPKFieldName) 
	{
		m_szPKFieldName = szPKFieldName;
	}

	/**
	 * Set name of the sequence, attached to this table.
	 * Warning! Automatic primary key values generation not reccomended. 
	 *
	 * @param szSequenceName name of the sequence, which will be used for primary key values generation. 
	 */
	public final void setSequenceName(String szSequenceName) 
	{
		m_szSequenceName = szSequenceName;
	}

	/**
	 * Constructor. 
	 * 
	 * @since java_sdk_v2-6-9
	 */
	public CTable()
	{
		super();
	}
	
	public CTable(String sTableName, String sPKFieldName, String sSequenceName)
	{
		super(sTableName);
		setPKFieldName(sPKFieldName);
		setSequenceName(sSequenceName);
		// if (nValue != null)
		//	getOneRecord("ADDRESS_ID = " + nValue.intValue());
	}

	/**
	 * This is a special hack method which actually doesn't use given connection.
	 * This is needed for eliminating Java compiler warnings about unused connection parameter 
	 * in many methods in our code.
	 * 
	 * @param conn NOT USED
	 * @since Nov 1, 2006
	 */
	protected static final void simulateUse(Connection conn)
	{
		if (conn != null) {}
	}
	
	/**
	 * de-precated Use constructor without parameters 
	 *
	 * @param connection jdbc connection - NOT USED
	 */
	public CTable(Connection connection)
	{
		super(connection);
	}

	protected boolean getFieldsStructure()
	{
		m_source.setLobsSupported(false);
		m_objFields = createFields(m_source);
		
		if(m_objFields.size() == 0)
			return false;

		return false;  	 
	}

	
	protected boolean canInsertRecord()
	{
		// prepare insert string
		StringBuffer sbInsertFields = new StringBuffer();
		boolean hasPKhasSeq = (getString(getPKFieldName()) == null) && (getSequenceName() != null);

		// prepare insert string - field & ? lists
		for (CField field : m_objFields.values())
		{
			if (!field.isNull())
			{
				if (sbInsertFields.length() != 0)
				{
					sbInsertFields.append(", ");
				}
				sbInsertFields.append(field.getName());
			}
			else
				if (!field.isNullable()) // if field null but not nullable
				{
					if(!hasPKhasSeq || !(field.getName().equals(getPKFieldName()))) // if table has attached sequence
					{	// if not then insert not allowed cause this one will be empty value field
						if( field.getDataDefault() == null)
						{
							return false;
						}
					}
				}
		}

		return (sbInsertFields.length() > 0);
	}

	
	protected boolean executeInsert(Connection conn)
	{
		// Connection conn = CCurrentThreadConnection.getConnection();
		if (conn == null)
		{
			// TODO  throw exception here
			return false;
		}

		if (!canInsertRecord())
			return false;

		if ((getPKFieldName() != null) &&
			(getSequenceName() != null))
	
		if (getString(getSequenceName()) == null)
			setInteger(getPKFieldName(), CSequence.nextValue(conn, getSequenceName()));

		// prepare insert string
		String  szInsertFields = "";
		String  szInsertValues = "";
		boolean boolInsertResult = false;

		// prepare insert string - field & ? lists

		int counter = 1;
		for (CField field : m_objFields.values())
		{
			if (!field.isNull())
			{
				if (szInsertFields.length() != 0)
				{
					szInsertFields += ", ";
					szInsertValues += ", ";
				}
				szInsertFields += field.getName();
				szInsertValues += " :" + counter + " ";
				counter++;
			}
		}

		// execute insert dml
		PreparedStatement pstmt = null;	 
		CallableStatement cstmt = null;
		String szDMLStatement = "";

		try
		{
			String szAddCommit = "\n";
			if (conn.getAutoCommit())
				szAddCommit = "   COMMIT;\n";	
			
			szDMLStatement = 	
				"declare\n" +
				"       id VARCHAR2(250) := NULL;\n" +
				"begin\n" +
				"    begin\n" +
				"        INSERT INTO " + getSource() + " ( " +
				"        " + szInsertFields + " )\n"+
				"             VALUES ( " + szInsertValues + " )\n" +
				"          RETURNING ROWIDTOCHAR(" + m_source.getIdentificationColumn() + ") INTO id;\n" +
				szAddCommit + 
				"    exception\n" +
				"        when others\n" +
				"            then id := 'ERROR ' || SQLERRM;\n" +
				"    end;\n" +
				"    :" + counter + " := id;\n" +
				"end;";

			cstmt = conn.prepareCall(szDMLStatement);
			cstmt.registerOutParameter(counter, Types.VARCHAR);
					    
			int nCounter = 1;

			// collect null values field names
			final StringBuilder sbQueryFields = new StringBuilder();
			for (CField field : m_objFields.values())
			{
				if (sbQueryFields.length() > 0)
					sbQueryFields.append(',');
				sbQueryFields.append(field.getName());
			
				if (!field.isNull())
				{
					try
					{
						if (field.setValueToCallableStatement(cstmt, nCounter))
							nCounter++;
					}
					catch (SQLException sqle)
					{
						CDBException e = new CDBException(
								"Failed to insert records into table: " + sqle.getMessage(),
								sqle, getClass().getName() + ".executeInsert()",
								field.toProperties(),
								"Query:\n" + m_sQuery);
								
						CDBException.logMe(e);
					}
				}
			}

			cstmt.execute();
			String rowid = cstmt.getString(counter);
			
			if (rowid != null && rowid.startsWith("ERROR"))
			{
				throw new CDBException(rowid, getClass().getName() + ".executeInsert()");
			}

			// prepare select for getting def. fields values & ROWID value if inserted

			boolInsertResult = true;
			pstmt = conn.prepareStatement(" SELECT " + sbQueryFields +
				"   FROM " + getSource() +
				"  WHERE " + m_source.getIdentificationColumn() + 
				" = CHARTOROWID('" + rowid +"') ");
			
			final ResultSet rst = pstmt.executeQuery();
			
			if (rst.next())
			{
				int counter2 = 1;
				for (CField field : m_objFields.values())
				{
					field.setFromRecordSet(rst, counter2);
					counter2++;
				}
			}
			rst.close();
		}
		catch (CDBException dbe)
		{
			CDBException e = new CDBException(
					"Failed to insert records into table: " + dbe.getMessage(),
					dbe, getClass().getName() + ".executeInsert()",
					toProperties(),
					"Query:\n" + m_sQuery + "  Statement:\n" + szDMLStatement);
					
			CDBException.logMe(e);
		}
		catch (SQLException sqle)
		{
			CDBException e = new CDBException(
					"Failed to insert records into table: " + sqle.getMessage(),
					sqle, getClass().getName() + ".executeInsert()",
					toProperties(),
					"Query:\n" + m_sQuery + "  Statement:\n" + szDMLStatement);
					
			CDBException.logMe(e);
		}
		catch (RuntimeException ex)
		{
			CDBException e = new CDBException(
					"Failed to insert records into table: " + ex.getMessage(),
					ex, getClass().getName() + ".executeInsert()",
					toProperties(),
					"Query:\n" + m_sQuery + "  Statement:\n" + szDMLStatement);
					
			CDBException.logMe(e);
		}
	 
		try
		{
			if (pstmt != null)
				pstmt.close();
			if (cstmt != null)
				cstmt.close();		   
		}
		catch(SQLException e)
		{
		}

		return boolInsertResult;
	}

	/**
	 * Update current record into database. 
	 *
	 */
	private boolean executeUpdate(Connection conn)
	{
		// check connecton.
		// Connection conn = CCurrentThreadConnection.getConnection();
		if (conn == null)
		{
			// TODO  Throw exception here
			return false;
		}

		//prepare values. 
		boolean boolResult = false;

		String szUpdate = "";
		int nCounter = 1;	 

		// enumerate for changed fields. 
		for (CField field : m_objFields.values())
		{
			if (field.isChanged())
			{
				szUpdate += (((szUpdate.length() == 0)?"":" , ") + field.getName() + " = :" + nCounter + " ");
				nCounter++;
			}
		}

		// if no fields were changed
		if (nCounter == 1)
			return true;

		CallableStatement cstmt = null;
	
		try
		{
			String szAddCommit = "";
			if (conn.getAutoCommit())
				szAddCommit = "   COMMIT; ";
	
			szUpdate = "begin " + 
				"     UPDATE " + getSource() + 
				"        SET " + szUpdate + 
				"      WHERE " + m_source.getIdentificationColumn() + 
				" = CHARTOROWID('" + getString("ROWIDTOCHAR(" + 
				m_source.getIdentificationColumn() + ")")  + "' ); " + 
				szAddCommit + 
				"end;";

			cstmt = conn.prepareCall(szUpdate);
			
			nCounter = 0;

			for (CField field : m_objFields.values())
			{
				if (field.isChanged())
				{
					try
					{
						field.setParamToPrepStatement(cstmt, (++nCounter));
					}
					catch (SQLException sqle)
					{
						CDBException e = new CDBException(
								"Failed to set parameter to prepared statement: " + sqle.getMessage(),
								sqle, getClass().getName() + ".executeUpdate()",
								toProperties(),
								"Query:\n" + m_sQuery + "  Statement:\n" + szUpdate);
								
						CDBException.logMe(e);
					}
				}
			}
	
			/*int nUpdated = */cstmt.executeUpdate();

			boolResult = true;
		}
		catch (SQLException sqle)
		{
			CDBException e = new CDBException(
					"Failed to set update table: " + sqle.getMessage(),
					sqle, getClass().getName() + ".executeUpdate()",
					toProperties(),
					"Query:\n" + m_sQuery + "  Statement:\n" + szUpdate);
					
			CDBException.logMe(e);
			boolResult = false;
		}

		try
		{
			if (cstmt != null)
				cstmt.close();
		}
		catch (SQLException e)
		{
		}

		return boolResult;
	}
	
	/**
	 * Method returns true if at least one field of this table has been changed
	 * (needs to ba saved to database).
	 * 
	 * @return false if table is read-only 
	 */
	@Override
	public boolean isChanged()
	{
		if (isReadOnly() || m_objFields.isEmpty() || m_source.getSynonym() == null ||
				m_source.getIdentificationColumn() == null)
			return false;
		
		for (CField field : m_objFields.values())
		{
			if (field.isChanged())
				return true;
		}
		
		return false;
	}

	/**
	 * Save changes to database. 
	 */
	@Override
	public boolean save(Connection conn, boolean doForceInsert)
	{
		if (!isChanged())
			return true;
				
		if (!doForceInsert && 
				getString("ROWIDTOCHAR(" + m_source.getIdentificationColumn() + ")") != null)
			return executeUpdate(conn);
		else
			return executeInsert(conn);
	}
}