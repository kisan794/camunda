/*
 * @(#)$RCSfile: CDBObjectFactory.java,v $ $Revision: 1.15 $ $Date: 2010/02/18 21:30:11 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CDBObjectFactory.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev	2005-06-08	created
 *	A.Solntsev	2005-06-23	Added methods loadObjectList(), loadObjectIDList().
 *	A.Solntsev	2005-08-25	Added method loadIntegerMap().
 *	A.Solntsev	2005-11-30	Added methods loadObjectList(..., Integer), loadObjectIDList(..., Class).
 *	A.Solntsev	2006-05-11	Now Threadlocal connection is used.
 *	A.Solntsev	2006-06-15	Some code moved to CDBObjectIDLoader; added caching objects."
 *	A.Solntsev	2008-08-28	using generics 
 *	A.Solntsev	2010-02-08	Load List<T> instad of List<Serializable>
 */
package hireright.sdk.db;
import hireright.sdk.util.CProperties;

import java.io.Serializable;
import java.sql.Connection;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * Class for loading persistent object.
 * Class can load object using only
 * 	1. class name, and
 *  2. primary key  or  custom sql filter.
 * 
 * Class has 2 types of methods: 
 *  1. getObject()  -  method get object from cache.  If needed, calls method loadObject()
 *  2. loadObject() - method loads object directly from database
 * 
 * @author	Andrei Solntsev
 * @date		2005-06-08
 * @version $Revision: 1.15 $ $Date: 2010/02/18 21:30:11 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CDBObjectFactory.java,v $
 */
public class CDBObjectFactory
{
	protected static final String CLASS_VERSION = "$Revision: 1.15 $ $Author: cvsroot $";
	
	private CDBObjectFactory()
	{
	}

	/*
	 * Implementation detail:
	 * I need to call all methods like this: "CDBObjectFactory.<T>loadObject(...)" because of bug in JDK:
	 * http://ieeexplore.ieee.org/Xplore/login.jsp?url=/iel2/960/7005/00283118.pdf?arnumber=283118
	 * 
	 * Generally, it should work lie this: "loadObject(...)"
	 */
	
	public static Object loadObject(Class<?> clazz, Object primaryKey)
	{
		return loadObject(CCurrentThreadConnection.getConnection(), clazz.getName(), primaryKey);
	}
	
	public static <T extends IDBObject> T loadDbObject(final Class<T> clazz, final Object primaryKey)
	{
		return CDBObjectFactory.<T>loadDbObject(clazz.getName(), primaryKey);
	}
	
	public static <T extends IDBObject> T loadDbObject(final Class<T> clazz, final Object primaryKey, final CFTable table)
	{
		// return CDBObjectFactory.<T>loadDbObject(clazz.getName(), primaryKey);
		return CDBObjectFactory.<T>loadObjectByPrimaryKey(clazz.getName(), primaryKey, table, null);
	}

	public static Object loadObject(Connection conn, Class<?> clazz, Object primaryKey)
	{
		return loadObject(conn, clazz.getName(), primaryKey);
	}
	
	public static Object loadObject(String sClassName, Object primaryKey)
	{
		if (primaryKey == null)
			throw new IllegalArgumentException("Primary key must be given");
			
		return loadObjectByPrimaryKey( sClassName, primaryKey );
	}	
	
	public static <T extends IDBObject> T loadDbObject(String sClassName, Object primaryKey)
	{
		if (primaryKey == null)
			throw new IllegalArgumentException("Primary key must be given");
			
		return CDBObjectFactory.<T>loadObjectByPrimaryKey(sClassName, primaryKey);
	}	
	
	@Deprecated
	public static Object loadObject(@SuppressWarnings("unused") Connection conn, String sClassName, Object primaryKey)
	{
		return loadObject(sClassName, primaryKey);
	}
	
	public static <T extends IDBObject> T loadObjectByFilter(Class<T> clazz, CSQLWhereConstructor sqlFilter)
	{
		return CDBObjectFactory.<T>loadDbObjectByFilter(clazz.getName(), sqlFilter);
	}
	
	@Deprecated
	public static Object loadDbObjectByFilter(Class<?> clazz, CSQLWhereConstructor sqlFilter)
	{
		return loadObjectByFilter(CCurrentThreadConnection.getConnection(), clazz.getName(), sqlFilter);
	}
	
	public static Object loadObjectByFilter(Connection conn, Class<?> clazz, CSQLWhereConstructor sqlFilter)
	{
		return loadObjectByFilter(conn, clazz.getName(), sqlFilter);
	}

	public static Object loadObjectByFilter(String sClassName, CSQLWhereConstructor sqlFilter)
	{
		if (sqlFilter == null)
			throw new IllegalArgumentException("SQL Filter must be given");
			
		return loadObjectBySqlFilter(sClassName, sqlFilter);
	}
	
	public static <T extends IDBObject> T loadDbObjectByFilter(String sClassName, CSQLWhereConstructor sqlFilter)
	{
		if (sqlFilter == null)
			throw new IllegalArgumentException("SQL Filter must be given");
			
		return CDBObjectFactory.<T>loadObjectBySqlFilter( sClassName, sqlFilter);
	}
	
	@Deprecated
	public static Object loadObjectByFilter(@SuppressWarnings("unused") Connection conn, 
			String sClassName, CSQLWhereConstructor sqlFilter)
	{
		return loadObjectByFilter(sClassName, sqlFilter);
	}
	
	@SuppressWarnings("unchecked")
	private static <T extends IDBObject> T createInstance(String sClassName)
	{
		try
		{
			// Load object
			return ((Class<T>) Class.forName(sClassName)).newInstance();
		}
		catch (ClassNotFoundException cnfe)
		{
			// @since jdk 1.4
			throw new RuntimeException(cnfe);
		}
		catch (IllegalAccessException iae)
		{
			// @since jdk 1.4
			throw new RuntimeException(iae);
		}
		catch (InstantiationException ine)
		{
			// @since jdk 1.4
			throw new RuntimeException(ine);
		}
	}

	private static <T extends IDBObject> T loadObjectByPrimaryKey(final String sClassName, final Object primaryKey)
	{
		final T obj = CDBObjectFactory.<T>createInstance(sClassName);
		final CFTable table = obj.createCFTable();
		return loadObjectByPrimaryKey(sClassName, primaryKey, table, obj);
	}
	
	private static <T extends IDBObject> T loadObjectByPrimaryKey(final String sClassName, 
			final Object primaryKey, final CFTable table, final T targetObject) 
	{
		if (primaryKey == null)
			throw new IllegalArgumentException("Primary key is null");

		final T obj = (targetObject == null)? CDBObjectFactory.<T>createInstance(sClassName) : targetObject;
		
		// construct filter using primary key
		CSQLWhereConstructor sqlFilter = CSQLWhereConstructor.equals( table.getPrimaryKeyColumn(), primaryKey );
		
		try
		{
			if (table.getOneRecord(sqlFilter))
			{
				obj.getDataFromDb(table);
				return obj;
			}
			else
			{
				// Record not found in database
				return null;
			}
		}
		finally
		{
			table.close();
		}
	}
	
	private static <T extends IDBObject> T loadObjectBySqlFilter(String sClassName, CSQLWhereConstructor sqlFilter) 
	{
		T obj = CDBObjectFactory.<T>createInstance(sClassName);
		CFTable table = obj.createCFTable();
		
		try
		{
			if (table.getOneRecord(sqlFilter))
			{
				obj.getDataFromDb(table);
				return obj;
			}
			else
			{
				// Record not found in database
				return null;
			}
		}
		finally
		{
			if (table != null)
			{
				table.close();
				table = null;
			}
		}
	}

	public static <T extends IDBObject> List<T> loadObjectList(Class<T> objectClass, 
			CFTable tableDescriptor, String sFieldName, Integer nFieldValue)
	{
		return loadObjectList(CCurrentThreadConnection.getConnection(),
			objectClass.getName(), tableDescriptor, sFieldName, nFieldValue);
	}
	
	public static <T extends IDBObject> List<T> loadObjectList(Connection conn,
			Class<T> objectClass, CFTable tableDescriptor, String sFieldName, Integer nFieldValue)
	{
		return loadObjectList(conn, objectClass.getName(), tableDescriptor, sFieldName, nFieldValue);
	}

	public static <T extends IDBObject> List<T> loadObjectList(String sClassName, CFTable tableDescriptor, String sFieldName, Integer nFieldValue)
	{
		CSQLWhereConstructor sqlFilter = new CSQLWhereConstructor()
				.andToFilterEqual(sFieldName, nFieldValue);

		return loadObjectList(CCurrentThreadConnection.getConnection(),
			sClassName, tableDescriptor, sqlFilter);
	}
	
	public static <T extends IDBObject> List<T> loadObjectList(Connection conn, String sClassName, 
			CFTable tableDescriptor, String sFieldName, Integer nFieldValue)
	{
		CSQLWhereConstructor sqlFilter = new CSQLWhereConstructor()
				.andToFilterEqual(sFieldName, nFieldValue);

		return loadObjectList(conn, sClassName, tableDescriptor, sqlFilter);
	}
	
	public static <T extends IDBObject> List<T> loadObjectList(Class<T> objectClass, 
			CFTable tableDescriptor, String sFieldName, String sFieldValue)
	{
		return loadObjectList(CCurrentThreadConnection.getConnection(), 
			objectClass.getName(), tableDescriptor, sFieldName, sFieldValue);
	}
	
	public static <T extends IDBObject> List<T> loadObjectList(Connection conn, Class<T> objectClass, 
			CFTable tableDescriptor, String sFieldName, String sFieldValue)
	{
		return loadObjectList(conn, objectClass.getName(), tableDescriptor, sFieldName, sFieldValue);
	}
	
	public static <T extends IDBObject> List<T> loadObjectList(String sClassName, 
			CFTable tableDescriptor, String sFieldName, String sFieldValue)
	{
		CSQLWhereConstructor sqlFilter = new CSQLWhereConstructor()
				.andToFilterEqual(sFieldName, sFieldValue);

		return loadObjectList(CCurrentThreadConnection.getConnection(), sClassName, tableDescriptor, sqlFilter);
	}
	
	public static <T extends IDBObject> List<T> loadObjectList(Connection conn, String sClassName, 
			CFTable tableDescriptor, String sFieldName, String sFieldValue)
	{
		CSQLWhereConstructor sqlFilter = new CSQLWhereConstructor()
				.andToFilterEqual(sFieldName, sFieldValue);

		return loadObjectList(conn, sClassName, tableDescriptor, sqlFilter);
	}
	
	public static <T extends IDBObject> List<T> loadObjectList(Class<T> objectClass, 
			CFTable tableDescriptor, CSQLWhereConstructor sqlFilter)
	{
		return  loadObjectList(CCurrentThreadConnection.getConnection(), 
			objectClass.getName(), tableDescriptor, sqlFilter);
	}
	
	public static <T extends IDBObject> List<T> loadObjectList(Connection conn, Class<T> objectClass, 
			CFTable tableDescriptor, CSQLWhereConstructor sqlFilter)
	{
		return  loadObjectList(conn, objectClass.getName(), tableDescriptor, sqlFilter);
	}
	
	/**
	 * @deprecated use method without conenction parameter
	 * @see loadObjectList(String sClassName, CFTable tableDescriptor, CSQLWhereConstructor sqlFilter)
	 * @param conn not used
	 */
	@Deprecated
	public static <T extends IDBObject> List<T> loadObjectList(@SuppressWarnings("unused") Connection conn, 
			String sClassName, CFTable tableDescriptor, CSQLWhereConstructor sqlFilter)
	{
		return loadObjectList(sClassName, tableDescriptor, sqlFilter);
	}
	
	/**
	 * Factory method for loading list of objects from database.
	 * 
	 * 
	 * @param sClassName class name of objects to be created, 
	 * 					eg. "hireright.objects.utilities.CDesign"
	 * <pre>
	 * 	This class must 
	 * 	-	extend IDBObject, 
	 * 	-	have empty constructor, and
	 * 	-	have method getDataFromDB(CFTable tableDescriptor)
	 * </pre>
	 * @param tableDescriptor	instance of CFTable describing table from which 
	 * 		data should be loaded, eg. hireright.objects.utilities.fields.CFDesign
	 * @param sqlFilter		WHERE-clause.
	 * 		Use <code>CSQLWhereConstructor.ALL</code> if no filter is needed.
	 * @return	List of loaded objects. List is empty if no objects
	 * 			has been found in database.
	 */
	public static <T extends IDBObject> List<T> loadObjectList(String sClassName,
			CFTable tableDescriptor, CSQLWhereConstructor sqlFilter)
	{
		List<T> list = new LinkedList<T>();
		
		try
		{
			if (tableDescriptor.open(sqlFilter))
			{
				do
				{
					T obj = CDBObjectFactory.<T>createInstance(sClassName);
					obj.getDataFromDb(tableDescriptor);
					list.add(obj);
				}
				while (tableDescriptor.next());
			}
		}
		catch (RuntimeException e)
		{
			list.clear();	// Help Garbage Collector
			list = null;
			
			throw e;
		}
		finally
		{
			if (tableDescriptor != null)
			{
				tableDescriptor.close();
			}
		}

		return list;
	}

	/**
	 * Method loads list of Integers
	 * 
	 * @param tableDescriptor
	 * @param sIDFieldName
	 * @param sqlFilter
	 * @return
	 */
	public static List<Integer> loadObjectIDList(CFTable tableDescriptor,
			String sIDFieldName, CSQLWhereConstructor sqlFilter)
	{
		List<Integer> result = loadObjectIDList(tableDescriptor, sIDFieldName, sqlFilter, Integer.class);
		return result;
	}
	
	/**
	 * Method loads list of Longs
	 * 
	 * @param tableDescriptor
	 * @param sIDFieldName
	 * @param sqlFilter
	 * @return
	 */
	public static List<Long> loadObjectLongIDList(CFTable tableDescriptor,
			String sIDFieldName, CSQLWhereConstructor sqlFilter)
	{
		List<Long> result = loadObjectIDList(tableDescriptor, sIDFieldName, sqlFilter, Long.class);
		return result;
	}
	
	/**
	 * Method loads list of Integers
	 * @param conn NOT USED
	 * @param tableDescriptor
	 * @param sIDFieldName
	 * @param sqlFilter
	 * @return
	 */
	@Deprecated
	public static List<? extends Serializable> loadObjectIDList(@SuppressWarnings("unused") Connection conn,
			CFTable tableDescriptor, String sIDFieldName, CSQLWhereConstructor sqlFilter)
	{
		return loadObjectIDList(tableDescriptor, sIDFieldName, sqlFilter, Integer.class);
	}
	
	/**
	 * Method loads list of ObjectIDs (Integers or Strings).
	 * @param conn
	 * @param tableDescriptor
	 * @param sIDFieldName
	 * @param sqlFilter
	 * @param fieldType	Either Integer.class or String.class
	 * @return
	 */
	public static <T> List<T> loadObjectIDList(CFTable tableDescriptor, String sIDFieldName, 
			CSQLWhereConstructor sqlFilter, Class<? extends T> objectIdType)
	{
		return (List<T>) loadObjectIDs(new LinkedList<T>(), 
				tableDescriptor, sIDFieldName, sqlFilter, objectIdType, false);
	}
	
	/**
	 * Method loads set of ObjectIDs (Integers or Strings).
	 * @param conn
	 * @param tableDescriptor
	 * @param sIDFieldName
	 * @param sqlFilter
	 * @param fieldType	Either Integer.class or String.class
	 * @return
	 */
	public static <T> Set<T> loadObjectIdSet(CFTable tableDescriptor, String sIDFieldName, 
			CSQLWhereConstructor sqlFilter, Class<? extends T> objectIdType)
	{
		return (Set<T>) loadObjectIDs(new TreeSet<T>(), 
				tableDescriptor, sIDFieldName, sqlFilter, objectIdType, false);
	}
	
	public static <T> Set<T> loadCachedObjectIdSet(CFTable tableDescriptor, String sIDFieldName, 
			CSQLWhereConstructor sqlFilter, Class<? extends T> objectIdType)
	{
		return (Set<T>) loadObjectIDs(new TreeSet<T>(), 
				tableDescriptor, sIDFieldName, sqlFilter, objectIdType, true);
	}
	
	/**
	 * Load list/set of object IDs into given storage.
	 * 
	 * @param storage
	 * @param tableDescriptor
	 * @param sIDFieldName
	 * @param sqlFilter
	 * @param objectIdType
	 * @return
	 * 
	 * @throws IllegalArgumentException 
	 */
	static <T> Collection<T> loadObjectIDs(Collection<T> storage, CFTable tableDescriptor, String sIDFieldName, 
			CSQLWhereConstructor sqlFilter, Class<? extends T> objectIdType, boolean bCache)
	{
		CDBObjectIDLoader idLoader = CDBObjectIDLoader.getInstance(tableDescriptor.getSource(), sIDFieldName);
		
		if (bCache)
		{
			// get cached object IDs 
			Collection<T> res = idLoader.loadCachedObjectIDs(storage, tableDescriptor, sqlFilter, objectIdType);
			if (storage.getClass().equals(res.getClass()))
				return res;
			
			storage.addAll(res);
			return storage;
		}
		
		// Load object IDs directly
		return idLoader.loadObjectIDs(storage, tableDescriptor, sqlFilter, objectIdType);
	}
	
	public static void clearCache(CFTable tableDescriptor)
	{
		CDBObjectIDLoader.clearCache(tableDescriptor.getSource());
	}
	
	public static void clearCache(String sTableName)
	{
		CDBObjectIDLoader.clearCache(sTableName);
	}
	
	/**
	 * @deprecated use method without connection parameter
	 * @param conn NOT USED
	 */
	@Deprecated
	public static <T> List<T> loadObjectIDList(@SuppressWarnings("unused") Connection conn,
			CFTable tableDescriptor, String sIDFieldName, 
			CSQLWhereConstructor sqlFilter, Class<? extends T> objectIdType)
	{
		return loadObjectIDList(tableDescriptor, sIDFieldName, sqlFilter, objectIdType);
	}

	@Deprecated
	public static CProperties loadProperties(@SuppressWarnings("unused") Connection conn, CFTable tableDescriptor,
			String sFieldPropertyName, String sFieldPropertyValue, CSQLWhereConstructor sqlFilter)
	{
		return loadProperties(tableDescriptor,
				sFieldPropertyName, sFieldPropertyValue, sqlFilter);
	}
	
	public static CProperties loadProperties(CFTable tableDescriptor,
			String sFieldPropertyName, String sFieldPropertyValue, CSQLWhereConstructor sqlFilter)
	{
		CProperties properties = new CProperties();
		
		try
		{
			if (tableDescriptor.open(sqlFilter))
			{
				do
				{
					String sPropertyName = tableDescriptor.getString(sFieldPropertyName);
					String sPropertyValue = tableDescriptor.getString(sFieldPropertyValue);
					properties.setProperty(sPropertyName, sPropertyValue);
				}
				while (tableDescriptor.next());
			}
		}
		finally
		{
			if (tableDescriptor != null)
			{
				tableDescriptor.close();
			}
		}

		return properties;
	}

	@Deprecated
	public static Map<Integer, Integer> loadIntegerMap(@SuppressWarnings("unused") Connection conn, 
			CFTable tableDescriptor, String sFieldKey, String sFieldValue, CSQLWhereConstructor sqlFilter)
	{
		return loadIntegerMap(tableDescriptor, sFieldKey, sFieldValue, sqlFilter);
	}
	
	public static Map<Integer, Integer> loadIntegerMap(CFTable tableDescriptor,
			String sFieldKey, String sFieldValue, CSQLWhereConstructor sqlFilter)
	{
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		
		try
		{
			if (tableDescriptor.open(sqlFilter))
			{
				do
				{
					Integer nKey = tableDescriptor.getInteger(sFieldKey);
					Integer nValue = tableDescriptor.getInteger(sFieldValue);
					map.put(nKey, nValue);
				}
				while (tableDescriptor.next());
			}
		}
		finally
		{
			if (tableDescriptor != null)
			{
				tableDescriptor.close();
			}
		}

		return map;
	}
}