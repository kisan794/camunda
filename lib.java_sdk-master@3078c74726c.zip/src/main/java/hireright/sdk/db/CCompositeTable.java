/*
 * @(#)$RCSfile: CCompositeTable.java,v $ $Revision: 1.28 $ $Date: 2015/11/02 20:15:35 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CCompositeTable.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2001-11-19	S.Ignatov	last modification
 *	2002-07-09	S.Ignatov	add Blob access methods
 *	2002-08-23	S.Ignatov	if record REALY not deleted it dosnt fetch next
 *	2002-10-09	S.Ignatov	logs writing into CTraceLog
 *	2002-11-29	D.Travin	executeUpdate changed
 *	2003-10-13	S.Ignatov	added CDBRuntimeException raising
 *	2005-08-08	A.Solntsev	Now ROWID is binded. This enables Oracle to cache statements.
 *	2005-08-09	A.Solntsev	Removed table name from Pl/Sql statements.
 *	2005-08-16	A.Solntsev	Method deleteAll() reworked: it deletes every record by ROWID.
 *	2005-08-24	A.Solntsev	Used new Iterator-methods listSourceFields(), listActiveFields(), listChangedFields().
 *	2005-10-12	A.Solntsev	Removed direct usage of class OracleCallableStatement.
 *	2005-12-04	A.Solntsev	Fixed saving CLOBs and BLOBs.
 *	2006-04-27	A.Solntsev	Used CCurrentThreadConnection instead of java.sql.Connection member
 *	2006-06-09	A.Solntsev	Enhanced logging with new API of CDBException
 *	2006-11-01	A.Solntsev	Added constructor CCompositeTable(String sTableName)
 *	2007-04-20	A.Solntsev	Added logging of fields values when updating source has failed
 *	2008-02-18	A.Solntsev	Throw SQL Exception, don't swallow it.
 *	2009-03-17	A.Solntsev	Methods delete() throw exception if called on read-only object
 *	2009-05-05	A.Solntsev	Fixed old bug: ignore column ROWID when inserting new record
 *  2009-07-17	A.Solntsev	Enhanced error logging
 *  2010-01-20	A.Solntsev	Constructors with Connection are deprecated again
 *  2010-06-03	I.Lopatukhin NCHAR support added
 *  2011-08-08	A.Tanasenko	Fixed and error in error handling
 *  2017-04-17	V.Ozernov	Calls for transliterations extracted to separate protected method sanitizeString()
 *  2017-05-03	V.Ozernov	HIVPE-15372 added compatibility with old version of data_sanitizer
 */
package hireright.sdk.db;
import hireright.sdk.db.fields.CCLOBField;
import hireright.sdk.db.fields.CBLOBField;
import hireright.sdk.db.sql.CSqlCommands;
import hireright.sdk.db2.CConnectionWrapper;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.CDataSanitizer;

import java.io.IOException;
import java.sql.*;
import java.util.*;

/**
 *	COMMENT ME
 *
 * @author Sergei Ignatov
 * @since java_sdk_v2-3-7, 2001-11-19
 * @version $Revision: 1.28 $ $Date: 2015/11/02 20:15:35 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CCompositeTable.java,v $
 */
public class CCompositeTable extends CCustomDataSetEx
{
	private static final long serialVersionUID = -7236434079026964419L;

	protected static final String CLASS_VERSION = "$Revision: 1.28 $ $Author: cvsroot $";
	
	/**
	 * 	Language of source strings. Used in language-specific transliteration of non-ASCII characters.
	 */
	private String m_sTransliterationLocaleLanguage;
	
	/**
	 * @since java_sdk_v2-6-9
	 * @param dbSource
	 */
	public CCompositeTable(CDBSource dbSource)
	{
		addSource(dbSource);
	}

	/**
	 * @deprecated Use constructor without connection parameter
	 * @param conn NOT USED
	 * @param dbSource
	 */
	@Deprecated
	public CCompositeTable(Connection conn, CDBSource dbSource)
	{
		addSource(dbSource);
	}

	public CCompositeTable(String sTableName)
	{
		this(new CDBSource(sTableName));
	}

	/**
	 * @deprecated Use constructor without connection parameter
	 * You need to call setSource() or addSource() after using this constructor.
	 * @param conn not used
	 */
	@Deprecated
	public CCompositeTable(Connection conn)
	{
		super(conn);
	}

	protected boolean executeUpdate(Connection conn, CDBSource source)
	{
		// conn = checkConnection();

		boolean boolResult = false;

		StringBuilder szbUpdate = new StringBuilder();
		StringBuilder szbDMLText = new StringBuilder();
		StringBuilder sbFieldsValues = new StringBuilder();

		int nCounter = 1;
		CField field;

		for (Iterator<CField> it = listChangedFields(source); it.hasNext(); )
		{
			field = it.next();

			switch (field.getDetType())
			{
				case Types.BLOB:	// field is instance of CBlobField
					if (field.getBlobLocator() == null && !field.isNull())
					{
						szbUpdate.append((szbUpdate.length()==0)?"":" , ");
						//szbUpdate.append(field.getTableName()).append(".");	// Removed this code to make Pl/Sql statements shorter.
						szbUpdate.append(field.getName());								// 2005-08-09		A.Solntsev, V.Zyakin
						szbUpdate.append(" = EMPTY_BLOB()");
					}
					break;
				case Types.CLOB:	// field is instance of CCLOBField
				case Types.NCLOB:
					if (field.getClobLocator() == null && !field.isNull())
					{
						szbUpdate.append((szbUpdate.length()==0)?"":" , ");
						//szbUpdate.append(field.getTableName()).append(".");	// Removed this code to make Pl/Sql statements shorter.
						szbUpdate.append(field.getName());								// 2005-08-09		A.Solntsev, V.Zyakin
						szbUpdate.append(" = EMPTY_CLOB()");
					}
					break;
				default:
					szbUpdate.append((szbUpdate.length()==0)?"":" , ");
					// szbUpdate.append(field.getTableName()).append(".");		// Removed this code to make Pl/Sql statements shorter.
					szbUpdate.append(field.getName());									// 2005-08-09		A.Solntsev, V.Zyakin
					szbUpdate.append(" = :");
					szbUpdate.append(nCounter++);
					szbUpdate.append(" ");
				break;
			}
		}

		CallableStatement cstmt = null;

		if (szbUpdate.length() > 0)
		{
			try
			{
				szbDMLText.append("declare \n");
				szbDMLText.append("	szUpdateResult VARCHAR2(1000) := ''; \n");
				szbDMLText.append("begin \n");
				szbDMLText.append("	begin \n");
				szbDMLText.append("		UPDATE ").append(source.getSynonym()).append("\n");
				szbDMLText.append("		   SET ").append(szbUpdate.toString()).append("\n");
				szbDMLText.append("		 WHERE ROWID = CHARTOROWID(:").append(nCounter++).append("); \n");

				if (conn.getAutoCommit())
					szbDMLText.append("           COMMIT; \n");

				szbDMLText.append("	exception \n");
				szbDMLText.append("		when others \n");
				szbDMLText.append("			then szUpdateResult := SUBSTR(TO_CHAR(SQLCODE) || ' ' || SQLERRM, 1, 1000); \n");
				szbDMLText.append("	end; \n");
				szbDMLText.append("	:");
				szbDMLText.append(nCounter);
				szbDMLText.append(" := szUpdateResult; \n");
				szbDMLText.append("end;\n");

				cstmt = conn.prepareCall(szbDMLText.toString());

				sbFieldsValues.append("\n\nFields values:\n");
				nCounter = 1;
				for (Iterator<CField> it = listChangedFields(source); it.hasNext(); )
				{
					field = it.next();
					try
					{
						// NVARCHAR, NCHAR and other NXXX types but not CLOB (and not NCLOB) ?
						if (field.getDetType() != Types.NCLOB && field.getDetType() != Types.CLOB && field.isNChar()) 
						{
							CConnectionWrapper.unwrapOracleStatement(cstmt)
								.setFormOfUse(nCounter, oracle.jdbc.OraclePreparedStatement.FORM_NCHAR);
						} 
						// CHAR or VARCHAR
						else if (field.getDetType() == Types.CHAR || field.getDetType() == Types.VARCHAR)
						{
							field.setString(sanitizeString((String)field.getValue()));
						}
						// other types
						if (field.setValueToCallableStatement(cstmt, nCounter))
						{
							sbFieldsValues.append(nCounter).append("='");
							sbFieldsValues.append(field.getValue()).append("';\n");
							nCounter++;
						}
					}
					catch (SQLException sqle)
					{
						CDBException e = new CDBException(
							"Failed to set value to CallableStatement ",
							sqle, getClass().getName() + ".executeUpdate()",
							new CProperties()
								.setProperties("source.", source)
								.setProperties("field.", field),
							szbDMLText.toString());

						// TODO: throw exception
						CDBException.logMe(e);
					}
				}

				cstmt.setString(nCounter++, getRowId(source));
				cstmt.registerOutParameter(nCounter, Types.VARCHAR);

				cstmt.execute();
				String szDMLResult = cstmt.getString(nCounter);

				if (szDMLResult != null)
					throw new SQLException(szDMLResult);

				// all done
				boolResult = true;
			}
			catch (SQLException sqle)
			{
				CDBRuntimeException e = new CDBRuntimeException(
						"update of source " + getSource() +
						" failed with statement " + szbDMLText.toString(),
						sqle, source.toProperties(), szbDMLText.toString() + sbFieldsValues.toString());

				throw e;
			}
			finally
			{
				if (cstmt != null)
				{
					try
					{
						cstmt.close();
						cstmt = null;
					}
					catch (SQLException sqle)
					{
						CDBException e = new CDBException(
								"Failed to close CallableStatement",
								sqle, getClass().getName() + ".executeUpdate()",
								source.toProperties(),
								szbDMLText.toString());

						CDBException.logMe(e);
					}
				}
			}
		}

		PreparedStatement pstmt = null;
		ResultSet rst = null;
		try
		{
			// insert finished  now collect values from db
			StringBuilder szbQueryText = new StringBuilder();
			szbQueryText.append(" SELECT ").append(getFieldsString(source));
			szbQueryText.append("\n   FROM ").append(source.getSynonym());
			szbQueryText.append("\n  WHERE ROWID = CHARTOROWID(:1) ");

			pstmt = conn.prepareStatement(szbQueryText.toString());

			String rowid = getRowId(source);
			pstmt.setString(1, rowid);

			rst = pstmt.executeQuery();
			if (rst.next())
			{
				int counter2 = 1;
				for (Iterator<CField> it = listActiveFields(source); it.hasNext(); )
				{
					field = it.next();

					switch (field.getDetType())
					{
						case Types.BLOB:	// field is instance of BLOB
						{
							try
							{
								((CBLOBField) field).saveBLOB(conn, source.getIdentificationColumn(), rowid);
							}
							catch (IOException ioe)
							{
								throw new CRuntimeException("Failed to save BLOB to " + getSource(), ioe,
										source.toProperties(), szbUpdate.toString());
							}
							break;
						}
						case Types.CLOB:	// field is instance of CLOB
							((CCLOBField) field).saveCLOB(conn,
									source.getIdentificationColumn(), rowid);
							break;
						default:
							break;
					}
					field.setFromRecordSet(rst, counter2);
					counter2++;
				}
			}

			if (szbUpdate.length() == 0)
				boolResult = true;
		}
		catch (SQLException sqle)
		{
			CDBRuntimeException e = new CDBRuntimeException(
					"reload data from source " + getSource() +
					" failed with statement " + szbUpdate.toString(),
					sqle, source.toProperties(), szbUpdate.toString());

			throw e;
		}
		finally
		{
			try
			{
				if (rst != null)
				{
					rst.close();
					rst = null;
				}
				if (pstmt != null)
				{
					pstmt.close();
					pstmt = null;
				}
			}
			catch (SQLException sqle)
			{
				CDBException e = new CDBException(
						"closing source " + getSource() + " failed",
						sqle, getClass().getName() + ".executeUpdate()",
						source.toProperties(),
						szbUpdate.toString());

				CDBException.logMe(e);
			}
		}

		return boolResult;
	}


	/**
	 *	COMMENT ME
	 */
	@Override
	protected boolean getFieldsStructure(Connection conn)
	{
		if (m_objSources == null || m_objSources.isEmpty())
			return false;

		CDBSource source = null;
		try
		{
			source = m_objSources.getLast();
			source.setLobsSupported(true);
			m_objFields.putAll(createFields(conn, source));

			if (m_isGroupByed && !m_objFields.isEmpty())
			{
				CField field = getRowIdField(source);
				if (field != null)
					field.setActive(false);
			}
		}
		catch (CRuntimeException runtimeException)
		{
			throw runtimeException;
		}
		catch (RuntimeException e)
		{
			CProperties params = (source==null ? null : source.toProperties());
			CTraceLog.error(e, getClass().getName() + ".getFieldsStructure()", params, toString());
			throw new CRuntimeException("Failed to get fields structure", e,
					getClass().getName() + ".getFieldsStructure()", params );
		}

		return true;
	}

	@Override
	public String toString()
	{
		if (m_objSources.size() == 0)
			return "no sources";

		if (m_objFields.size() == 0)
		return "no fields";

		StringBuilder szResultBuffer = new StringBuilder();
		try
		{
			for (CField field : m_objFields.values())
			{
				szResultBuffer.append(field.toString()).append("\n");
			}
		}
		catch (Exception e)
		{
		}

		return szResultBuffer.toString();
	}

	/**
	 * Method returns true if at least one field of this table has been changed
	 * (needs to ba saved to database).
	 *
	 * @return false if table is read-only
	 */
	@Override
	public boolean isChanged()
	{
		if (m_objFields == null || m_objFields.isEmpty() || isReadOnly())
			return false;

		for (CDBSource source : m_objSources)
		{
			if (isSourceChanged(source))
				return true;
		}

		return false;

	}

	@Override
	public boolean save(Connection conn, boolean doForceInsert)
	{
		if (!isChanged())
			return true;

		boolean boolResult = true;

		for (CDBSource source : m_objSources)
		{
			if (isSourceChanged(source))
				boolResult &= saveSource(conn, source, doForceInsert);
		}

		return boolResult;
	}

	/**
	 *  set source for this data set and create fields objects for data storage
	 */
	protected boolean saveSource(Connection conn, CDBSource source, boolean doForceInsert)
	{
		boolean boolResult = false;

		if (doForceInsert || getRowId(source) == null)
		{
			boolResult = executeInsert(conn, source);
		}
		else
		{
			boolResult = executeUpdate(conn, source);
		}

		if (boolResult)
		{
			setSourceChanged(source, false);
		}

		return boolResult;
	}

	public boolean delete()
	{
		return deleteFromTable(checkConnection(), null);
	}

	protected boolean executeInsert(Connection conn, CDBSource source)
	{
		boolean boolResult = false;

		// prepare insert string
		StringBuilder szbInsert = new StringBuilder();
		StringBuilder szbInsertFields = new StringBuilder();
		StringBuilder szbInsertValues = new StringBuilder();
		boolean isRecordInserted = false;

		// prepare insert string - field & ? lists
		int nCounter = 1;

		for (CField field: listSourceFields(source))
		{
			if (!field.isNull() && !field.isRowId())
			{
				if (szbInsertFields.length() > 0)
				{
					szbInsertFields.append(", ");
					szbInsertValues.append(", ");
				}
				switch (field.getDetType())
				{
					case Types.BLOB:
						szbInsertFields.append(field.getName());
						szbInsertValues.append(" EMPTY_BLOB() ");
						break;
					case Types.CLOB:
					case Types.NCLOB:
						szbInsertFields.append(field.getName());
						szbInsertValues.append(" EMPTY_CLOB() ");
						break;
					default:
						szbInsertFields.append(field.getName());
						szbInsertValues.append(" :");
						szbInsertValues.append(nCounter);
						szbInsertValues.append(" ");
						nCounter++;
				}
			}
		}

		// execute insert dml
		PreparedStatement pstmt = null;
		String rowid = null;

		try
		{
			szbInsert.append("declare \n");
			szbInsert.append("       szInsertResult VARCHAR2(1000) := ''; \n");
			szbInsert.append("begin \n");
			szbInsert.append("     begin \n");
			szbInsert.append("          INSERT INTO ").append(source.getSynonym());
			szbInsert.append(" (").append(szbInsertFields).append(" ) \n");
			szbInsert.append("          VALUES ( ").append(szbInsertValues).append(" ) \n");
			szbInsert.append("          RETURNING ROWIDTOCHAR( ");
			szbInsert.append(source.getIdentificationColumn());
			szbInsert.append(" ) INTO :").append(nCounter).append(" ; \n");

			if (conn.getAutoCommit())
				szbInsert.append("           COMMIT; \n");

			szbInsert.append("     exception \n");
			szbInsert.append("         when others \n");
			szbInsert.append("             then szInsertResult := SUBSTR( TO_CHAR (SQLCODE) || ' ' || SQLERRM, 1, 1000); \n");
			szbInsert.append("     end; \n");
			szbInsert.append("	:");
			szbInsert.append((nCounter + 1));
			szbInsert.append(" := szInsertResult; \n");
			szbInsert.append("end;\n");

			final CallableStatement cstmt = conn.prepareCall(szbInsert.toString());
			try
			{
				cstmt.registerOutParameter(nCounter, Types.VARCHAR);
				cstmt.registerOutParameter((nCounter + 1), Types.VARCHAR);
	
				nCounter = 1;
	
				// collect null values field names				// WHAT ?!?!?!
				for (CField field: listSourceFields(source))
				{
					if (!field.isNull() && !field.isRowId())
					{
						try
						{
							if (field.getDetType() != Types.CLOB && field.isNChar()) 
							{
								CConnectionWrapper.unwrapOracleStatement(cstmt)
									.setFormOfUse(nCounter, oracle.jdbc.OraclePreparedStatement.FORM_NCHAR);
							} else 
							if (field.getDetType() == Types.CHAR || field.getDetType() == Types.VARCHAR)
							{
								field.setString(sanitizeString((String)field.getValue()));
							}
							if (field.setValueToCallableStatement(cstmt, nCounter))
								nCounter++;
						}
						catch (SQLException sqle)
						{
							CDBRuntimeException e = new CDBRuntimeException(
								"Failed to set value to CallableStatement when inserting record",
								sqle, new CProperties()
									.setProperties("source.", source)
									.setProperties("field.", field),
								szbInsert.toString());
	
							throw e;
						}
					}
				}
	
				cstmt.execute();

				rowid = cstmt.getString(nCounter);
				String szDMLResult = cstmt.getString(nCounter + 1);

				if (szDMLResult != null)
					throw new CDBException("source " + getSource() + " error on execute " + szDMLResult,
						getClass().getName() + ".executeInsert()", source.toProperties());

				if (rowid == null)
					throw new CDBException("source " + getSource() + " null rowid returned",
						getClass().getName() + ".executeInsert()", source.toProperties());

				isRecordInserted = true;
			}
			finally
			{
				CSqlCommands.closeSilently( cstmt );
			}
		}
		catch (CDBException dbe)
		{
			throw new CRuntimeException(dbe, dbe.toProperties(), dbe.getData());
		}
		catch (SQLException sqle)
		{
			throw new CDBRuntimeException("source " + getSource() + " execute insert failed with statement "
					+ formatSQL(source, szbInsert), sqle, source.toProperties(), null);
		}

		// insert finished now collect values from db
		ResultSet rst = null;
		if (isRecordInserted)
		{
			StringBuilder sbSelect = new StringBuilder();
			try
			{
				sbSelect
					.append(" SELECT ").append(getFieldsString(source))
					.append("\n   FROM ").append(source.getSynonym())
					.append("\n  WHERE ").append(source.getIdentificationColumn())
					.append(" = CHARTOROWID(:1) ");

				pstmt = conn.prepareStatement(sbSelect.toString());

				pstmt.setString(1, rowid);

				rst = pstmt.executeQuery();
				if (rst.next())
				{
					int counter2 = 1;
					CField field;
					for (Iterator<CField> it = listActiveFields(source); it.hasNext(); )
					{
						field = it.next();

						switch (field.getDetType())
						{
							case Types.BLOB:
								try
								{
									((CBLOBField) field).saveBLOB(conn, source.getIdentificationColumn(), rowid);
								}
								catch (IOException ioe)
								{
									throw new CRuntimeException("Failed to save BLOB to " + getSource(), ioe,
											source.toProperties(), sbSelect.toString());
								}
								break;
							case Types.CLOB:
								((CCLOBField) field).saveCLOB(conn,
									source.getIdentificationColumn(), rowid);
								break;
							default:
								field.setFromRecordSet(rst, counter2);	// FIXME move to "default"
								break;
						}
						counter2++;
					}
				}

				// all done
				boolResult = true;
			}
			catch (SQLException sqle)
			{
				throw new CDBRuntimeException(
					"Failed to reload after insert",
					sqle, new CProperties()
						.setProperties("source.", source),
					sbSelect.toString());
			}
			finally
			{
				try
				{
					if (rst != null)
					{
						rst.close();
						rst = null;
					}

					if (pstmt != null)
					{
						pstmt.close();
						pstmt = null;
					}
				}
				catch (SQLException sqle)
				{
					CDBException e = new CDBException("Closing source " + getSource() + " failed (after insert)",
						"CCompositeTable.executeInsert", sqle, source.toProperties());

					CDBException.logMe(e);
				}
			}
		}

		return boolResult;
	}
	
	/**
	 * 	Sets language of source strings. Used in language-specific transliteration of non-ASCII characters.
	 *
	 * @param sTransliterationLocaleLanguage two-letter code of the language of value. Null or empty if it's unknown.
	 */
	public void setTransliterationLocaleLanguage(String sTransliterationLocaleLanguage)
	{
		m_sTransliterationLocaleLanguage = sTransliterationLocaleLanguage;
	}

	/**
	 * Transliterates source string to Latin
	 *
	 * @param sValue - input value
	 * @return transliterated value
	 */
	protected String sanitizeString(String sValue)
	{
		boolean disabledTransliteration = hireright.objects.rollout_feature.CRolloutFeatureCache.getInstance().isFeatureGloballyGranted("UTFINST_TRANSL_DISABLED");
		if(!disabledTransliteration)
		{
			if (CStringUtils.isEmpty(m_sTransliterationLocaleLanguage))
			{
				return CDataSanitizer.replace(sValue);
			}
			else
			{
				return CDataSanitizer.replace(sValue, m_sTransliterationLocaleLanguage);
			}
		}
		else
		{
			return sValue;
		}
	}
	
	private String formatSQL( CDBSource source, StringBuilder sb )
	{
		int nCounter = 1;
		for (CField field: listSourceFields(source))
		{
			if (!field.isNull() && !field.isRowId() && field.getDetType()!=Types.BLOB && field.getDetType()!=Types.CLOB && field.getDetType()!=Types.NCLOB)
			{
				CStringUtils.replace( sb, ":"+nCounter+" ", "'"+String.valueOf(field.getValue())+"'" );
				nCounter++;
			}
		}
		return sb.toString();		
	}

	/**
	 * We suppose that some filter is given.
	 * @params filter
	 *
	 * @return false if deleting at least ohne field has failed
	 */
	public boolean deleteRecords(CSQLWhereConstructor filter)
	{
		if (isReadOnly())
		{
			throw new IllegalStateException("Method deleteFromTable() called on read-only object");
		}

		boolean bRetValue = true;
		try
		{
			if (this.open(filter))
			{
				do
				{
					bRetValue &= this.delete();
				}
				while (this.next());
			}
		}
		finally
		{
			this.close();
		}
		return bRetValue;
	}

	/**
	 * Delete all records from table matching for given filter.
	 * @return  true iff deleted at least one record FIXME
	 *
	 * @deprecated Use method deleteRecords(CSQLWhereConstructor)
	 */
	public boolean deleteAll()
	{
		return deleteRecords( CSQLWhereConstructor.ALL );
	}

	/**
	 *	Method delets active row from database table
	 */
	private boolean deleteFromTable(Connection conn, String szTableName)
	{
		if (isReadOnly())
		{
			throw new IllegalStateException("Method deleteFromTable() called on read-only object");
		}

		boolean boolResult = true;

		for (CDBSource source : m_objSources)
		{
			if (szTableName == null || szTableName.equals(szTableName))
				boolResult = boolResult & executeDelete(conn, source, false);
		}

		return boolResult;
	}

	private boolean executeDelete(Connection conn, CDBSource source, boolean deleteAll)
	{
		if (source == null)
			throw new CDBRuntimeException("Source is null", CDBRuntimeException.ERR_NULL_SOURCE_NAME);

		boolean boolResult = false;

		StringBuilder szbDelete = new StringBuilder("");

		try
		{
			StringBuilder szbDeleteFilter = new StringBuilder();
			int nCounter = 1;
			if (deleteAll)
			{
				// Delete ALL rows from table. Ahtung! This is dangerous operation!
				szbDeleteFilter.append(";\n");
			}
			else
			{
				String sRowid = getRowId(source);
				if (sRowid == null)
					return false;

				szbDeleteFilter.append("           WHERE ");
				szbDeleteFilter.append(source.getIdentificationColumn());
				szbDeleteFilter.append(" = CHARTOROWID(:").append(nCounter++).append("); \n");
		}

			szbDelete.append("declare \n");
			szbDelete.append("	szDeleteResult VARCHAR2(200) := ''; \n");
			szbDelete.append("	nDeletedRows NUMBER := 0; \n");
			szbDelete.append("begin \n");
			szbDelete.append("	begin \n");
			szbDelete.append("		DELETE \n");
			szbDelete.append("		  FROM ");
			szbDelete.append(source.getSynonym());
			szbDelete.append(szbDeleteFilter.toString());
			szbDelete.append(" nDeletedRows := SQL%ROWCOUNT; ");

			if (conn.getAutoCommit())
				szbDelete.append("           COMMIT; \n");

			szbDelete.append("	exception \n");
			szbDelete.append("		when others \n");
			szbDelete.append("			then szDeleteResult := (TO_CHAR(SQLCODE) || ' ' || SQLERRM); \n");
			szbDelete.append("	end; \n");
			szbDelete.append("	:").append(nCounter).append(" := nDeletedRows; \n");
			szbDelete.append("	:").append(nCounter+1).append(" := szDeleteResult; \n");
			szbDelete.append("end;\n");

			final CallableStatement cstmt = conn.prepareCall(szbDelete.toString());
			
			try
			{
				if (!deleteAll)
					cstmt.setString(1, getRowId(source));
	
				cstmt.registerOutParameter(nCounter, Types.INTEGER);
				cstmt.registerOutParameter(nCounter+1, Types.VARCHAR);
	
				cstmt.execute();
				int nRowsDeleted = cstmt.getInt(nCounter);
				String szDMLResult = cstmt.getString(nCounter+1);
	
				if (szDMLResult != null)
					throw new SQLException(szDMLResult);
	
				boolResult = (nRowsDeleted > 0);
			}
			finally
			{
				CSqlCommands.closeSilently( cstmt );
			}
		}
		catch (SQLException sqle)
		{
			CDBRuntimeException e = new CDBRuntimeException(
					"Failed to delete record using statement " + szbDelete.toString(),
					sqle, new CProperties()
						.setProperties("source.", source)
						.setProperty("deleteAll", deleteAll),
						szbDelete.toString());

				throw e;
		}

		return boolResult;
	}
}
