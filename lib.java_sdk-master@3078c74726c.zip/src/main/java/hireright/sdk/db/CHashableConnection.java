/*
 * @(#)$RCSfile: CHashableConnection.java,v $ $Revision: 1.3 $ $Date: 2015/11/02 20:17:13 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CHashableConnection.java,v $
 *
 * Copyright 2012 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  M. Suhhoruki		2014-05-08 created
 *  
 */
package hireright.sdk.db;

import hireright.sdk.db3.DB;
import hireright.sdk.debug.CStackTrace;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.util.Date;

/**
 * Pooled connections do not return a consistent hashCode.
 * 
 * @author atanasenko
 * @since java_sdk_v3-66
 */
public class CHashableConnection extends CAbstractConnectionProxy
{
	private final Object token;
	private final String name;
	private final String creatorThread;
	private final String creationTrace;
	
	public CHashableConnection(Connection conn, String name)
	{
		super(conn);
		this.name = name;
		token = new Object();
		
		creatorThread = Thread.currentThread().getName();
		creationTrace = CStackTrace.getStackTrace(this + " creation trace (" + new Date() + ")");
		
		DB.logActivity("Opened connection " + toString());
	}
	
	public String getCreationTrace()
	{
		return creationTrace;
	}
	
	@Override
	public Object invoke(Object proxy, Method m, Object[] args)
		throws Throwable
	{
		Object result = null;
		try
		{
			// wrap statements
			if ("hashCode".equals(m.getName()))
			{
				return token.hashCode();
			}
			
			if("equals".equals(m.getName()))
			{
				Object that = args[0];
				
				if(that instanceof Connection)
				{
				
					CHashableConnection other = unwrap((Connection) that);
					if(other != null)
					{
						return token.equals(other.token);
					}
				}
				return false;
			}
			
			if("toString".equals(m.getName()) && name != null)
			{
				return toString();
			}
			
			if("close".equals(m.getName()))
			{
				DB.logActivity("Closing connection " + toString());
			}
			
			result = m.invoke(getDelegate(), args);
		}
		catch (InvocationTargetException e)
		{
			Throwable cause = e.getTargetException();
			throw (cause != null) ? cause : e;
		}
		
		return result;
	}

	public String toString()
	{
		return name + "/" + creatorThread + "@" + Integer.toHexString(System.identityHashCode(getDelegate()));
	}
	
	public static Connection create(Connection connection, String name)
	{
		CHashableConnection stmt = new CHashableConnection(connection, name);
		
		return (Connection) Proxy.newProxyInstance(
				stmt.getClass().getClassLoader(),
				new Class<?>[] { Connection.class },
				stmt);
	}
	
	public static CHashableConnection unwrap(Connection conn)
	{
		return unwrap(CHashableConnection.class, conn);
	}
	
}
