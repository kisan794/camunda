/*
 * Copyright 2001-2024 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * V.Ozernov				2024-08-16	HRG-318608 Created
 */

package hireright.sdk.db;

import hireright.sdk.debug.CTraceLog;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * It's used by CMultitenantDB if DB supports multitenancy but there is no multitenant driver.
 * Do not use it from other code.
 * More efficient way is to use the driver since this class generates additional "alter session" requests.
 */
public class CMultitenantConnection extends CAbstractConnectionProxy
{
	public interface ContainerSwitcher
	{
		boolean isSupported(Connection connection, String dsJndiName);
		void switchToTenantContainer(Connection connection) throws SQLException;
		void switchToRootContainer(Connection connection) throws SQLException;
	}
	
	private static final ThreadLocal<ContainerSwitcher> multitenantConnectionSwitcher = new ThreadLocal<>();
	private final ContainerSwitcher containerSwitcher;
	private boolean bIsSwitchedToTenantContainerOnOpen = false;
	private boolean bIsSwitchedToRootContainerOnClose = false;
	
	public static void setContainerSwitcher(ContainerSwitcher switcher)
	{
		if (switcher == null)
		{
			multitenantConnectionSwitcher.remove();
		}
		else
		{
			multitenantConnectionSwitcher.set(switcher);
		}
	}
	
	public static void resetContainerSwitcher()
	{
		multitenantConnectionSwitcher.remove();
	}
	
	public static ContainerSwitcher getContainerSwitcher()
	{
		return multitenantConnectionSwitcher.get();
	}
	
	public static Connection wrapIfNeeded(Connection originalConnection, String dsJndiName)
	{
		ContainerSwitcher containerSwitcher = multitenantConnectionSwitcher.get();
		return containerSwitcher == null || !containerSwitcher.isSupported(originalConnection, dsJndiName)
				? originalConnection
				: create(originalConnection, containerSwitcher);
	}
	
	public static Connection create(Connection originalConnection, ContainerSwitcher containerSwitcher)
	{
		CMultitenantConnection connection = new CMultitenantConnection(originalConnection, containerSwitcher);
		return (Connection) java.lang.reflect.Proxy.newProxyInstance(
				originalConnection.getClass().getClassLoader(),
				new Class<?>[] {Connection.class},
				connection);
	}
	
	public static CMultitenantConnection unwrap(Connection connection)
	{
		return unwrap(CMultitenantConnection.class, connection);
	}
	
	public CMultitenantConnection(Connection connection, ContainerSwitcher containerSwitcher)
	{
		super(connection);
		this.containerSwitcher = containerSwitcher;
	}
	
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
	{
		Object result;
		try
		{
			if ("close".equals(method.getName()))
			{
				if (bIsSwitchedToTenantContainerOnOpen && !bIsSwitchedToRootContainerOnClose)
				{
					doSwitchToRootContainer();
					bIsSwitchedToRootContainerOnClose = true;
				}
			}
			else if (!bIsSwitchedToTenantContainerOnOpen)
			{
				doSwitchToTenantContainer();
				bIsSwitchedToTenantContainerOnOpen = true;
			}
			
			result = method.invoke(getDelegate(), args);
		}
		catch(InvocationTargetException e)
		{
			throw e.getCause();
		}
		
		return result;
	}
	
	private void doSwitchToRootContainer()
	{
		try
		{
			Connection connection = getDelegate();
			if (!connection.isClosed())
			{
				containerSwitcher.switchToRootContainer(connection);
			}
			else
			{
				CTraceLog.error("Can't switch connection to root container since it's already closed",
						this.getClass().getName()+".doSwitchToRootContainer");
			}
		}
		catch(SQLException e)
		{
			CTraceLog.error(e);
		}
	}
	
	private void doSwitchToTenantContainer()
	{
		try
		{
			Connection connection = getDelegate();
			if(!connection.isClosed())
			{
				containerSwitcher.switchToTenantContainer(connection);
			}
			else
			{
				CTraceLog.error("Can't switch connection to tenant container since it's already closed",
						this.getClass().getName() + ".doSwitchToTenantContainer");
			}
		}
		catch(SQLException e)
		{
			CTraceLog.error(e);
		}
	}
}
