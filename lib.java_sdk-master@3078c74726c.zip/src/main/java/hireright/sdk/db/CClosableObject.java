/*
 * Copyright 2001-2023 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev		2006-06-12	Extracted a common root object.
 *								Method finalize() writes to file instead of TraceLog.
 *	A.Solntsev		2007-01-08	Default constructor is not available (it was incorrectly used during deserialization)
 *	A.Solntsev		2008-03-05	Method for writing warnings to file is now public (used in CTrackingConnection)
 *	A.Solntsev		2008-11-14	Use ThreadSafeDateFormat instead of SimpleDateFormat
 *	A.Solntsev		2009-03-17	Turned off logging stack traces by default (consumes GC resources)
 *	A.Vassiljev		2023-12-10	HRG-297079. Commented out calls to CStackTrace.getStackTrace
 */
package hireright.sdk.db;

//import hireright.sdk.debug.CStackTrace;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.IHasProperties;

import java.io.Serializable;

/**
 * Any object that should be closed after using (DB Object, Callable Statement, file reader etc.)
 * can inherit this class.
 * 
 * In method "finalize()" it checks if the object has been really closed.
 * If not, a warning message is added to file "FinalizationWarnings.log".
 * 
 * @author Andrei Solntsev
 * @since java_sdk_v2-6-13
 */
public abstract class CClosableObject implements Serializable, IHasProperties
{	
	private static final long serialVersionUID = 1L;

	protected static final String CLASS_VERSION = "$Revision: 1.10 $ $Author: cvsroot $";
	
	/**
	 * Stack Trace when this object was created
	 */
	private String m_sCreationStackTrace = null;
	
	/**
	 * Stack Trace when this object was 'opened' (usually this is SQL call like SELECT or UPDATE)
	 */
	private String m_sOpeningStackTrace = null;

	/**
	 * Default constructor.
	 * Used during deserialization.
	 * 
	 * NB! Don't use it in subclasses.
	 */
	protected CClosableObject()
	{
	}
	
	protected CClosableObject(Class<? extends CClosableObject> objectClass)
	{
		//m_sCreationStackTrace = CStackTrace.getStackTrace(objectClass.getName() +
		//	" closable object has been created");
	}
	
	/**
	 * 
	 * @return Stack Trace when this object was created (not null)
	 */
	protected String getCreationStackTrace()
	{
		return m_sCreationStackTrace;
	}
	
	/**
	 * @see #m_sOpeningStackTrace
	 * @see #onOpened(String)
	 * 
	 * @return null if no method open(String sDescription) was called.  
	 */
	protected String getOpeningStackTrace()
	{
		return m_sOpeningStackTrace;
	}
	
	/**
	 * Subclasses should call this method when object is 'opened'.
	 * This means, in method which required 'close()' to be called after using.
	 * 
	 * Usually this is method like <code>PreparedStatement.execute()</code> 
	 * or <code>CCustomDataSet.open()</code>.
	 * 
	 * @param sDescription String describing how object was opened. 
	 * 		Usually this is SQL call like SELECT or UPDATE
	 */
	protected final void onOpened(String sDescription)
	{
		if (!isClosed())
		{
			CTraceLog.warning(
				new IllegalStateException("Trying to open object which is already opened"),
				getClass().getName() + ".onOpened()", toProperties(), getCreationStackTrace());
		}
		
		//m_sOpeningStackTrace = CStackTrace.getStackTrace(sDescription);
	}
	
	/**
	 * So we hope to find out all classes that don't close DB Objects
	 * @see	#isClosed()
	 * @throws java.lang.Throwable
	 */
	@Override
	protected void finalize() throws Throwable
	{
		if (!isClosed())
		{
			/*
			 * It means that method close() was not called
			 * after working with this object.
			 */

			writeFinalizationWarning(getClass(), getCreationStackTrace(),
					getOpeningStackTrace(), toProperties());
			
			closeSilently();
		}
		
		super.finalize();
	}
	
	public static void writeFinalizationWarning(Class<?> sourceClass, 
			String sCreationStackTrace, String sOpeningStackTrace, CProperties params)
	{
		try
		{
			params.setProperty("className", sourceClass.getName());
			
			if (sourceClass.getProtectionDomain() != null &&
				sourceClass.getProtectionDomain().getCodeSource() != null)
			{
				params.setProperty("codeSource", 
						sourceClass.getProtectionDomain().getCodeSource().getLocation());
			}
		}
		catch (RuntimeException e) {}
		
		StringBuilder data = new StringBuilder();
		data.append("CreationStackTrace:\n").append(sCreationStackTrace).append("\n");
		data.append("OpeningStackTrace:\n").append(sOpeningStackTrace).append("\n");
		
		CTraceLog.warning("Closable object is not closed properly", CClosableObject.class.getName(), params, data.toString());
	}
	/**
	 * To be overridden in subclasses
	 * @return "Closable object: <class name>" 
	 */
	@Override
	public String toString()
	{
		return "Closable object: " + getClass().getName() + " isClosed=" + isClosed();
	}
	
	/**
	 * This is the main method of this class.
	 * It should be implemented in subclasses and return true or false indicating
	 * if this object was properly closed.
	 * 
	 * @return true if 1) object was not opened at all   2) was closed properly after using
	 */
	protected abstract boolean isClosed();
	
	/**
	 * Try to close this object silently without throwing any exceptions.
	 * This method will be closed from finalizer Thread in case if method close() was not called.
	 * 
	 * NB! Do not call this method directly! Do not make it public! 
	 */
	protected abstract void closeSilently();
}

