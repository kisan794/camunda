/*
 * @(#)$RCSfile: CAbstractConnectionProxy.java,v $ $Revision: 1.3 $ $Date: 2015/11/02 20:15:38 $ $Author: cvsroot $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	atanasenko	05.02.2015	Created
 */
package hireright.sdk.db;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.sql.Connection;

/**
 * 
 */
public abstract class CAbstractConnectionProxy implements InvocationHandler {
	
	private final Connection m_delegate;

	public CAbstractConnectionProxy(Connection delegate) {
		this.m_delegate = delegate;
	}
	
	protected Connection getDelegate() {
		return this.m_delegate;
	}
	
	public static <T extends CAbstractConnectionProxy> T unwrap(Class<T> wrapperClass, Connection conn)
	{
		
		while(true)
		{
			if(!Proxy.isProxyClass(conn.getClass()))
			{
				return null;
			}
			
			InvocationHandler h = Proxy.getInvocationHandler(conn);
			if(!(h instanceof CAbstractConnectionProxy))
			{
				return null;
			}
			CAbstractConnectionProxy w = (CAbstractConnectionProxy) h;
			
			if(wrapperClass.isInstance(w))
			{
				return wrapperClass.cast(w);
			}
			
			conn = w.getDelegate();
		}
	}
	
	public static Connection unwrapAll(Connection conn)
	{
		while(true)
		{
			if(!Proxy.isProxyClass(conn.getClass()))
			{
				return conn;
			}
			
			InvocationHandler h = Proxy.getInvocationHandler(conn);
			if(!(h instanceof CAbstractConnectionProxy))
			{
				return conn;
			}
			CAbstractConnectionProxy w = (CAbstractConnectionProxy) h;
			
			conn = w.getDelegate();
		}
	}
	
}
