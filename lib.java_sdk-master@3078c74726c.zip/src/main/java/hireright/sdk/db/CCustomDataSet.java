/*
 * @(#)$RCSfile: CCustomDataSet.java,v $ $Revision: 1.43 $ $Date: 2010/02/04 21:17:03 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CCustomDataSet.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov		2003-10-13	added CDBRuntimeException raising
 * 	A.Keks			2004-04-30	a speed optimization :-)
 * 	A.Solntsev		2004-05-14	implements java.io.Serializable
 * 	S.Ignatov		2004-08-03	getFieldsNew changes: query of datasource structure where clause condition from " = 1" to " < 1 "
 *	A.Solntsev		2005-01-05	Added javadoc @throws CDBRuntimeException.
 *								Added method finalize() for finding out unclosed DB Objects.
 *  A.Solntsev		2005-03-08	Method getOneRecord() is more safe:  close() is in finally-block
 *  A.Solntsev		2005-04-01	Added stack trace of class creation.
 *  A.Solntsev		2005-07-25	Added support for schema name (source name vs. synonim) (beta version).
 *  A.Solntsev		2005-08-09	Added method getRowId(CDBSource source).
 *  A.Solntsev		2005-08-16	1. New class CSQLWhereParser is used to bind variables.
 *  							2. New class CTableMetaData is used to cache table metadata.
 *  A.Solntsev		2005-08-24	Fixed old bug in method insert(): now it returns false in case of error.
 *  A.Solntsev		2005-12-05	Added methods CProperties getProperties(String szFieldName),
 *  							byte[] getBlobContent(String szFieldName)
 *  A.Solntsev		2006-02-07	open(): if no records found, it's better to close table descriptor.
 *  M.Abdulganejev  2006-02-20  java_sdk_v2-6-6: m_connection variable made transient to enable serialization,-to remove it from the persistent state of an object.
 *  A.Solntsev		2006-03-06	Added method open(CSQLWhereConstructor filter, String sSortByField)
 *	A.Solntsev		2006-04-27	Used CCurrentThreadConnection instead of java.sql.Connection member
 *	A.Solntsev		2006-06-08	Added private function getField(String sFieldName) which throw IllegalArgumentException.
 *	A.Solntsev		2006-06-10	Enhanced usage of CDBException
 *	A.Solntsev		2006-06-12	Method finalize() writes to file instead of TraceLog.
 *	A.Solntsev		2005-08-29	Performance improvement in getCommaDelimitedFields(): uses StringBuffer instead of String
 *	A.Solntsev		2006-11-01	Removed java.sql.Connection m_connection member
 *	A.Solntsev		2006-11-01	Added constructor CCustomDataSet(String sTableName), method open(String sSqlFilter)
 *	A.Solntsev		2007-01-22	Removed unused methods getClob(String szFieldName) and getBlob(String szFieldName)
 *	A.Solntsev		2007-02-13	Added methods setNumber(String szFieldName, Double fValue)
 *	A.Solntsev		2007-10-23	Fixed a lot of javadocs; Method toProperties() produces shorter logs.
 *	A.Solntsev		2007-10-30	Method close() doesn't write warnings if connection is closed.
 *	A.Solntsev		2008-02-18	Added more constuctors to CDBRuntimeException
 *	A.Solntsev		2008-05-14	Removed several extra catch-blocks
 *	M.Litvinov		2008-05-29	Enhanced logic for fetching limited amount of records
 *	A.Solntsev		2008-09-01	Fixed SQL filter containing apostrophes
 *	A.Solntsev		2008-10-10	Fixed closing ResultSet
 *	A.Solntsev		2009-03-17	Method insert() throws exception if called on read-only object
 *	A.Solntsev		2009-07-09	Added methods getLongValue(), getNumericValue(), getCharacter()
 *	A.Solntsev		2009-07-09	warnings replaced by errors
 *	A.Solntsev		2009-07-17	Don't try to save object in method close
 */
package hireright.sdk.db;
import java.io.ByteArrayInputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import hireright.sdk.db.fields.CColumnMetaData;
import hireright.sdk.db.fields.CFieldsFactory;
import hireright.sdk.db.fields.CTableMetaData;
import hireright.sdk.db.sql.CSqlCommands;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CArrayIterator;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.IHasProperties;

/**
 * Class for base operations with single database object, like table or view.
 * Contains methods for accessing fields data.
 *
 * @author  Sergei Ignatov
 * @version $Revision: 1.43 $, $Date: 2010/02/04 21:17:03 $, $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CCustomDataSet.java,v $
 */
public abstract class CCustomDataSet extends CClosableObject
	implements Serializable, IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.43 $ $Author: cvsroot $";
	
	/**
	 * @serial
	 */
	protected CDBSource	m_source = null;		// data source
	protected String	m_szFilter  = null;		// where condition for query
	protected String	m_szOrderBy  = null;	// order by
	protected boolean	m_isGroupByed  = false;	// this dataset has GROUB BY clause
	protected String	m_sGroupExpression = "";

	/**
	 * @serial contains (String, CField) pairs
	 */
	protected Map<String, CField>		m_objFields;			// list of columns

	/**
	 * FIXME	I am not sure that this member is Serializable
	 */
	private transient ResultSet m_rst	= null;

	/**
	 * FIXME	I am not sure that this member is Serializable
	 */
	protected transient PreparedStatement m_pstmt = null;
	protected String		m_sQuery = null;

	private boolean		m_readOnlyDataSet = false;	// ability to write data
	protected String	m_szDMLQuery;
	private String		m_sCurrentlyExecutingQuery;
	// private Integer		m_nMaxFirstRowsToReturn;

	/**
	 * @deprecated Use constructor without connection parameter
	 * @param conn Not used anymore
	 */
	@Deprecated
	CCustomDataSet(@SuppressWarnings("unused") Connection conn)
	{
		this();
	}

	CCustomDataSet()
	{
		super(CCustomDataSet.class);

		m_objFields = new HashMap<String, CField>();
		m_szOrderBy = null;
		m_szFilter = null;
		m_source = null;
	}

	/**
	 *
	 * @param sTableName name of table
	 * @since Nov 1, 2006
	 *
	 * @throws NullPointerException if sTableName is null
	 */
	public CCustomDataSet(String sTableName)
	{
		super(CCustomDataSet.class);

		if (sTableName == null)
		{
			throw new IllegalArgumentException("Table name is null");
		}

		m_source = new CDBSource(sTableName);
		m_objFields = createFields(m_source);
	}

	/**
	 * @deprecated	Use constructor with table name
	 * Currently method is used only in integrations
	 */
	protected boolean setSource(String sTableName)
	{
		if (sTableName == null)
			return false;

		m_source = new CDBSource(sTableName);
		m_objFields = createFields(m_source);
		return true;
	}


	/**
	 * sets new connection for object
	 * @deprecated This method does not take any effect
	 * @param connection NOT USED
	 */
	@Deprecated
	public void setConnection(@SuppressWarnings("unused") Connection connection)
	{
	}

	/**
	 *	@since	java_sdk_v2-6-5
	 *	@deprecated This method does not take any effect
	 *
	 * @param dataSet NOT USED
	 * @param connection NOT USED
	 */
	@Deprecated
	public static void setConnection(@SuppressWarnings("unused") CCustomDataSet dataSet, 
			@SuppressWarnings("unused") Connection connection)
	{
	}

	/**
	 * Return field object by name of the field
	 */
	protected CField fieldByName(String szName)
	{
		if (szName == null || m_objFields.isEmpty())
			return null;

		return m_objFields.get(szName.toUpperCase());
	}

	/**
	 * Method returns CField by given name.
	 *
	 * @param sFieldName  (case-insensitive) name of field
	 * @return field with given name (not-null)
	 *
	 * @throws NullPointerException if sFieldName is null
	 * @throws IllegalArgumentException if sFieldName is not currently loaded
	 * 				(see constructor of class CFTable with list of available fields)
	 */
	protected final CField getField(String sFieldName)
	{
		if (sFieldName == null)
			throw new IllegalArgumentException("Field name must not be null");

		CField field = fieldByName(sFieldName);
		if (field == null)
		{
			throw new IllegalArgumentException("Field " + sFieldName + " is not currently loaded.");
		}

		return field;
	}

	/**
	 * return source, like table name
	 */
	String getSource()
	{
		return (m_source == null ? null : m_source.getSynonym());
	}

	/**
	 * Method opens the table with filter "WHERE sFieldName = fieldValue".
	 *
	 * @param sFieldName	Name of databse column
	 * @param fieldValue	Value of database column of any type (String, Date, Boolean etc.)
	 * @return	true iff table has at least one record matching given filter
	 * @throws CDBRuntimeException when???
	 */
	public boolean open(String sFieldName, Serializable fieldValue) throws CDBRuntimeException
	{
		return open(CSQLWhereConstructor.equals(sFieldName, fieldValue));
	}

	/**
	 * @deprecated
	 * @return	true iff table has at least one record matching given filter
	 * @throws CDBRuntimeException	when ???
	 * @since Nov 2, 2006
	 */
	public final boolean open() throws CDBRuntimeException
	{
		return this.open( getFilterString() );
	}

	/**
	 * Open  the table using the given filter.
	 * After open() method is called, you can call method next() in cycle.
	 *
	 * @param filter	Any SQL Filter (WHERE-clause)
	 * @param sSortByField Field to sort by (ORDER BY - clause)
	 * @return	true iff table has at least one record matching given filter
	 * @throws CDBRuntimeException	when ???
	 *
	 * @since java_sdk_v2-6-7
	 */
	public boolean open(CSQLWhereConstructor filter, String sSortByField) throws CDBRuntimeException
	{
		this.setOrder(sSortByField);
		return this.open(filter);
	}

	public boolean open(CSQLWhereConstructor sqlFilterConstructor) throws CDBRuntimeException
	{
		CSQLWhereFilter sqlFilter = sqlFilterConstructor.build();
		return open(sqlFilter, sqlFilterConstructor.getMaxFirstRowsToReturn());
	}
	
	public boolean open(CSQLWhereFilter sqlFilter, Integer maxRows) throws CDBRuntimeException
	{
		this.setFilter(sqlFilter.getSqlClause());
		Connection conn = checkConnection();
		try
		{
			closeSilently();

			m_szDMLQuery = m_sQuery = generateQueryDML( sqlFilter.getSqlClause(), maxRows, !sqlFilter.isEmpty());
			m_sCurrentlyExecutingQuery = m_szDMLQuery;

			onOpened(m_sCurrentlyExecutingQuery);

			m_pstmt = sqlFilter.prepareStatement(conn, m_sQuery);
			m_rst = m_pstmt.executeQuery();

			if (getRowData())
				return true;

			// If no records found, it's better to close table descriptor.
			// Further multiple calling ".close())" will not throw exceptions.
			close();
			return false;
		}
		catch (CDBRuntimeException runtimeException)
		{
			m_sCurrentlyExecutingQuery = null;
			throw runtimeException;
		}
		catch (SQLException sqle)
		{
			CDBRuntimeException e = new CDBRuntimeException(
				"Failed to open table for reading",
				sqle, toProperties(), m_sQuery);

			m_sCurrentlyExecutingQuery = null;
			throw e;
		}
	}
	
	/**
	 *	Open table for manipulations
	 *	return true, if one row of data successefully retrieved
	 *
	 *  NB! We suppose that SQL Filter is previously given by command
	 *  this.setFilter(CSQLWhereConstructor).
	 *
	 *  DE-PRE-CATED	It's recommended to use method open(CSQLWhereConstructor) instead.
	 *
	 *	@param sSqlFilter any WHERE construction, for example: "REQUEST_ID=2089059 AND COURT_RECORD_ID=2"
	 *	@return false if no one record was found
	 *  @throws CDBRuntimeException
	 */
	public boolean open(String sSqlFilter) throws CDBRuntimeException
	{
		// TODO:
		// 1) CSQLWhereFilter sqlFilter = CSQLWhereConstructor.parseTrickSql(m_sQuery);
		// 2) return open(sqlFilter);
		
		this.setFilter(sSqlFilter);
		Connection conn = checkConnection();

		if (m_pstmt != null || m_rst != null)
		{
			CTraceLog.error(
				new IllegalStateException("Trying to open table which is already opened"),
				getClass().getName() + ".open()", null, getCreationStackTrace());
		}

		try
		{
			closeSilently();

			m_szDMLQuery = m_sQuery = generateQueryDML(m_szFilter, null, CSQLWhereConstructor.hasConditions(sSqlFilter));
			m_sCurrentlyExecutingQuery = m_szDMLQuery;

			onOpened(m_sCurrentlyExecutingQuery);

			m_pstmt = CSQLWhereConstructor.parseTrickSql(m_sQuery).prepareStatement(conn);
			m_rst = m_pstmt.executeQuery();

			if (getRowData())
				return true;

			// If no records found, it's better to close table descriptor.
			// Further multiple calling ".close())" will not throw exceptions.
			close();
			return false;
		}
		catch (CDBRuntimeException runtimeException)
		{
			m_sCurrentlyExecutingQuery = null;
			throw runtimeException;
		}
		catch (SQLException sqle)
		{
			CDBRuntimeException e = new CDBRuntimeException(
				"Failed to open table for reading",
				sqle, toProperties(), m_sQuery);

			m_sCurrentlyExecutingQuery = null;
			throw e;
		}
	}

	/**
	 *	get next row of data
	 *	return true, if one row of data successefully retrieved
	 *
	 * 	@return false if not more records were found
	 */
	public boolean next()
	{
		Connection conn = checkConnection();
		if (!m_readOnlyDataSet)
			save(conn);

		return getRowData();
	}

	/**
	 *	Method closes this data set.
	 *  Method must be ALWAYS called after working with object.
	 *  If no, it leaves in memory some objects, what leads to memory leaks.
	 */
	public void close()
	{
		try
		{
			Connection conn = CCurrentThreadConnection.getConnection();
			if (CConnection.isClosed(conn))
			{
				// Nothing to do. Most likely this object was not saved because of closed connection.
			}
			else if (!m_readOnlyDataSet && isChanged())
			{
				CTraceLog.error("Data Set is not saved", getClass().getName()+".close()", toProperties());

				// I guess this causes many errors on production. This code should be removed.
				// save(conn);	// Update by A.Solntsev 2009-08-17: This happens in finally-blick when "save" or "create" failed. No need to try to save once more.
			}

			if (m_rst != null)
				m_rst.close();
			
			if (m_pstmt != null)
				m_pstmt.close();

			m_sCurrentlyExecutingQuery = null;
		}
		catch (Exception sqle)
		{
			CDBException e = new CDBException(
				"Failed to close table",
				sqle, getClass().getName() + ".close()",
				toProperties(),
				m_sQuery);

			CDBException.logMe(e);
			m_sCurrentlyExecutingQuery = null;
		}

		m_pstmt = null;
		m_rst = null;
		m_sCurrentlyExecutingQuery = null;
	}

	/**
	 * Do not use this method directly.
	 * It should be called only from method finalize().
	 *
	 * @see CClosableObject#closeSilently()
	 */
	@Override
	protected void closeSilently()
	{
		try
		{
			if (m_rst != null)
				m_rst.close();
		}
		catch (SQLException sqle)
		{
			// Let's ignore it silently
		}
		
		try
		{
			if (m_pstmt != null)
				m_pstmt.close();
		}
		catch (SQLException sqle)
		{
			// Let's ignore it silently
		}

		m_pstmt = null;
		m_rst = null;
		m_sCurrentlyExecutingQuery = null;
	}

	/**
	 * @param szFieldName
	 * @return true if value of given field is null
	 */
	public boolean isNull(String szFieldName)
	{
		CField field = fieldByName(szFieldName);
		return (field == null) || (field.isNull());
	}

	/**
	 *	Returns string-value of given column
	 * @param szFieldName
	 *	@return null	if error occured
	 */
	public String getString(String szFieldName)
	{
		try
		{
			CField field = getField(szFieldName);
			if (field == null)
				throw new RuntimeException("Strange: field " + szFieldName + " is not found");
			return field.getStringValue();
		}
		catch (IllegalArgumentException e)
		{
			CTraceLog.error(e, getClass().getName() + ".getString()",
				toProperties().setProperty("szFieldName", szFieldName), m_sQuery);

			return null;
		}
	}

	/**
	 * Method returns value of field of type `CProperties`
	 * (custom HireRight type). In database, this field usually has type VARCHAR2.
	 *
	 * @param szFieldName	name of database column
	 * @throws IllegalArgumentException if no column is found with given name
	 * @return	instance of CProperties, always not null
	 *
	 * @since	java_sdk_v2-6-5
	 */
	public CProperties getProperties(String szFieldName)
	{
		return new CProperties(getField(szFieldName).getStringValue());
	}

	/**
	 *	Method returns `preserved` string.
	 *	It means, not-null: if field value is null, method returns empty string.
	 * @param szFieldName
	 * @return empty string if field value is null
	 */
	public String getPString(String szFieldName)
	{
		String sPreservedString = getString(szFieldName);
		if (sPreservedString == null)
			sPreservedString = "";

		return sPreservedString;
	}

	/**
	 * Returns rowid of current row in given table.
	 * @return result of Pl/Sql operation ROWIDTOCHAR
	 */
	public String getRowId()
	{
		return getRowId(m_source);
	}

	/**
	 * Returns rowid of current row in given table.
	 * @return result of Pl/Sql operation ROWIDTOCHAR
	 * @param source	COMMENT ME
	 */
	protected String getRowId(CDBSource source)
	{
		return getString( "ROWIDTOCHAR(" + source.getIdentificationColumn() + ")" );
	}

	/**
	 *
	 * @param source
	 * @return Name of (virtual) column containing rowid. Usually it looks like  "ROWIDTOCHAR(id)"
	 */
	protected CField getRowIdField(CDBSource source)
	{
		return fieldByName("ROWIDTOCHAR(" + source.getIdentificationColumn() + ")");
	}

	public Number getNumber(String szFieldName)
	{
		return getField(szFieldName).getNumericValue();
	}
	
	/**
	 *	Return integer value of given columns.
	 * 	@param szFieldName
	 *	@return null if error occured
	 */
	public Integer getInteger(String szFieldName)
	{
		try
		{
			return getField(szFieldName).getIntegerValue();
		}
		catch (IllegalArgumentException e)
		{
			CTraceLog.error(e, getClass().getName() + ".getInteger()",
				toProperties().setProperty("szFieldName", szFieldName), m_sQuery);

			return null;
		}
	}
	
	public Long getLong(String szFieldName)
	{
		return getField(szFieldName).getLongValue();
	}
	
	public Character getCharacter(String szFieldName)
	{
		return getField(szFieldName).getCharValue();
	}

	/**
	 * Appends to given StringBuilder list of column name delimited by ", "
	 */
	private final void appendCommaDelimitedFields(StringBuilder sb)
	{
		String sDelim = " ";
		for (CField field : m_objFields.values())
		{
			if (field.isActive())
			{
				sb.append(sDelim).append(field.getName());
				sDelim = ", ";
			}
		}
	}
	
	/**
	 * Return Query DML string for datasource
	 */
	protected String generateQueryDML(String sSqlFilter, Integer maxRows, boolean hasConditions) 
	{
		if (m_objFields.isEmpty())
			return "";

		StringBuilder sbQuery = new StringBuilder(16*m_objFields.size());

		try
		{
			sbQuery.append("SELECT ");
			appendCommaDelimitedFields(sbQuery);
			sbQuery.append(" FROM ").append(getSource());

			if (hasConditions)
			{
				sbQuery.append(" WHERE ").append(sSqlFilter);
			}
			if (maxRows != null)
			{
				if (hasConditions)
					sbQuery.append(" AND");
				
				sbQuery.append(" rownum <= ").append(maxRows);
			}

			if (m_szOrderBy != null && m_szOrderBy.trim().length() > 0)
				sbQuery.append(" ORDER BY ").append(m_szOrderBy);

			if (m_isGroupByed)
			{
				if (m_sGroupExpression == null || m_sGroupExpression.trim().length() == 0)
				{
					// Does it happen somewhere?
					CTraceLog.error("Group by without columns", getClass().getName() +
						".generateQueryDML()", toProperties(), getCreationStackTrace());
					sbQuery.append("GROUP BY ");
					appendCommaDelimitedFields(sbQuery);
				}
				else
					sbQuery.append("GROUP BY ").append(m_sGroupExpression);
			}

			return sbQuery.toString();
		}
		finally
		{
			// Help garbage collector
			sbQuery.setLength(0);
			sbQuery = null;
		}
	}
	
	/**
	 * Method moves to the next row in opened table
	 * (corresponds to java.sql.ResultSet.next()) and populates fields
	 * with database values of this row.
	 *
	 * @return	false	if table has no more rows.
	 * 					In this case, all fields are set to null.
	 *
	 * @throws CDBRuntimeException if connection is closed or SQLException occured.
	 */
	private boolean getRowData() throws CDBRuntimeException
	{
		if (m_objFields.isEmpty())
			throw new CDBRuntimeException("List of fields is empty", CDBRuntimeException.ERR_NO_FIELDS);

		// Connection conn = checkConnection();

		boolean boolResult = false;

		try
		{
			if (m_rst.next())
			{
				int counter = 1;
				for (CField field : m_objFields.values())
				{
					if (field.isActive())
					{
						field.setNull();
						field.setFromRecordSet(m_rst, counter);
						counter++;
					}
				}
				boolResult = true;
			}
			else
			{
				for (CField field : m_objFields.values())
				{
					field.setNull();
				}
			}
		}
		catch (SQLException sqlException)
		{
			// FIXME   This is not a runtime exception!
			throw new CDBRuntimeException(sqlException, toProperties().setProperty("query", m_sQuery));
		}

		return boolResult;
	}

	/**
	 * Used by class CClosableObject in method finalize()
	 */
	@Override
	protected boolean isClosed()
	{
		return (m_pstmt == null && m_rst == null);
	}


	/**
	 * Returns true if column has one of following values: "Y", "YES", "T", "TRUE".
	 * @return java.lang.Boolean
	 * @param szFieldName name of column
	 */
	public Boolean getBoolean(String szFieldName)
	{
		try
		{
			return getField(szFieldName).getBooleanValue();
		}
		catch (IllegalArgumentException e)
		{
			CTraceLog.error(e, getClass().getName() + ".getBoolean()",
				toProperties().setProperty("szFieldName", szFieldName), m_sQuery);

			return null;
		}
	}

	/**
	 * Returns Float value of given column.
	 * @return null if columns is not of numeric type. In this case see TraceLog.
	 * @param szFieldName name of column
	 */
	public Float getFloat(String szFieldName)
	{
		try
		{
			return getField(szFieldName).getFloatValue();
		}
		catch (IllegalArgumentException e)
		{
			CTraceLog.error(e, getClass().getName() + ".getFloat()",
				toProperties().setProperty("szFieldName", szFieldName), m_sQuery);

			return null;
		}
	}

	/**
	 *	@param conn NOT USED
	 * @param filter
	 * @return true if at least one record was found
	 * @since	java_sdk_v2-6-5
	 * @deprecated Use method without connection parameter {@link #getOneRecord(CSQLWhereConstructor)}
	 */
	@Deprecated
	public final boolean getOneRecord(@SuppressWarnings("unused") Connection conn, CSQLWhereConstructor filter)
	{
		return getOneRecord(filter);
	}

	/**
	 * Method reads the first record from the table which matches
	 * filter "WHERE sFieldName = fieldValue".
	 *
	 * @param conn NOT USED
	 * @param sFieldName	Name of databse column
	 * @param fieldValue	Value of database column of any type (String, Date, Boolean etc.)
	 * @return	true iff table has at least one record matching given filter
	 * @throws CDBRuntimeException when???
	 *
	 * @since java_sdk_v2-6-5
	 * @deprecated Use method without connection parameter {@link #getOneRecord(String, Serializable)}
	 */
	@Deprecated
	public final boolean getOneRecord(@SuppressWarnings("unused") Connection conn, String sFieldName, Serializable fieldValue)
	{
		return getOneRecord(CSQLWhereConstructor.equals(sFieldName, fieldValue));
	}

	/**
	 * Method reads the first record from the table which matches
	 * filter "WHERE sFieldName = fieldValue".
	 *
	 * @param sFieldName	Name of databse column
	 * @param fieldValue	Value of database column of any type (String, Date, Boolean etc.)
	 * @return	true iff table has at least one record matching given filter
	 * @throws CDBRuntimeException when???
	 *
	 * @since java_sdk_v2-6-20
	 */
	public final boolean getOneRecord(String sFieldName, Serializable fieldValue)
	{
		return getOneRecord(CSQLWhereConstructor.equals(sFieldName, fieldValue));
	}

	/**
	 * Method reads the first record from the table which matches
	 * filter "WHERE sFieldName = nFieldValue".
	 *
	 * @param sFieldName	Name of databse column
	 * @param nFieldValue	Value of database column of any type (String, Date, Boolean etc.)
	 * @return	true iff table has at least one record matching given filter
	 * @throws CDBRuntimeException when???
	 *
	 * @since java_sdk_v2-6-20
	 */
	public final boolean getOneRecord(String sFieldName, int nFieldValue)
	{
		return getOneRecord(CSQLWhereConstructor.equals(sFieldName, nFieldValue));
	}

	public final boolean getOneRecord(CSQLWhereConstructor filter)
	{
		// return getOneRecord(filter.toString());
		try
		{
			return open(filter);
		}
		finally
		{
			close();
		}
	}


	/**
	 * @deprecated Parameter conn is not used. Use method {@link #getOneRecord(String)}
	 * @param conn NOT USED
	 * @param szFilter
	 * @return true if at least one record is found with this condition.
	 */
	@Deprecated
	public final boolean getOneRecord(@SuppressWarnings("unused") Connection conn, String szFilter)
	{
		return getOneRecord( szFilter );
	}

	/**
	 * Method reads one row with given SQL Where-statement
	 * NB! Method call this.close() after reading.
	 *
	 * @param szFilter	for example, "id=2345"  or "customer_id=234 and state in ('ACTIVE')".
	 * 									Use class CSQLWhereConstructor to form this parameter.
	 *
	 * @return true if at least one record is found with this condition.
	 */
	public boolean getOneRecord(String szFilter)
	{
		boolean boolResult = true;

		// set filter
		String szOldFilter = m_szFilter;
		setFilter(szFilter);

		// get data
		try
		{
			boolResult = open();
		}
		finally
		{
			close();
		}

		setFilter(szOldFilter);

		return boolResult;
	}

	/**
	 * COMMENT ME
	 * @return COMMENT ME
	 */
	public boolean insert()
	{
		if (!m_readOnlyDataSet)
		{
			return save(true);
		}

		throw new IllegalStateException("Method insert() called on read-only object");
	}

	/**
	 * @deprecated Use methods {@link #open(CSQLWhereConstructor)}, {@link #getOneRecord(CSQLWhereConstructor)},
	 * 	{@link #count(CSQLWhereConstructor)}, {@link #max(String, CSQLWhereConstructor)},
	 *  {@link #min(String, CSQLWhereConstructor)} which use SQL Filter as a parameter.
	 *
	 * @param szFilter
	 */
	public void setFilter(String szFilter)
	{
		m_szFilter = szFilter;
		m_szDMLQuery = null;
	}

	public boolean setDate(String szFieldName, java.sql.Date dtValue)
	{
		return getField(szFieldName).setDate(dtValue);
	}

	public boolean setNumber(String szFieldName, Number numericValue)
	{
		return getField(szFieldName).setNumber( numericValue );
	}
	
	public boolean setLong(String szFieldName, Long lValue)
	{
		return getField(szFieldName).setLong(lValue);
	}
	
	public boolean setLong(String szFieldName, long lValue)
	{
		return getField(szFieldName).setLong(lValue);
	}
	
	public boolean setFloat(String szFieldName, float fValue)
	{
		return getField(szFieldName).setFloat(fValue);
	}

	public boolean setFloat(String szFieldName, Float fValue)
	{
		return getField(szFieldName).setFloat(fValue);
	}

	public boolean setInteger(String szFieldName, int nValue)
	{
		return getField(szFieldName).setInteger(nValue);
	}

	public boolean setInteger(String szFieldName, Integer nValue)
	{
		return getField(szFieldName).setInteger(nValue);
	}

	public boolean setNumber(String szFieldName, Double fValue)
	{
		return getField(szFieldName).setDouble(fValue);
	}

	public boolean setNumber(String szFieldName, long lValue)
	{
		return getField(szFieldName).setLong(lValue);
	}

	public void setOrder(String szOrderBy)
	{
		m_szOrderBy = szOrderBy;
		m_szDMLQuery = null;
	}

	public boolean setString(String szFieldName, String szValue)
	{
		return getField(szFieldName).setString(szValue);
	}

	public boolean setString(String szFieldName, char charValue)
	{
		return getField(szFieldName).setCharValue(charValue);
	}
	
	public boolean setCharacter(String szFieldName, char charValue)
	{
		return getField(szFieldName).setCharValue(charValue);
	}

	
	public boolean setCharacter(String szFieldName, Character charValue)
	{
		return getField(szFieldName).setCharValue(charValue);
	}

	public boolean setBlob(String szFieldName, byte[] value)
	{
		return getField(szFieldName).setBlob(value);
	}

	/**
	 * @param szFieldName
	 * @return Date object for specified Field in table
	 */
	public java.util.Date getDate(String szFieldName)
	{
		return getField(szFieldName).getDateValue();
	}

	/**
	 * Save this object
	 * 
	 * @param conn NOT USED
	 * @return false if saving failed (?)
	 * @deprecated Use method without connection parameter {@link #save()}
	 */
	@Deprecated
	public boolean save(Connection conn)
	{
		return save(conn, false);
	}

	public boolean save()
	{
		return save(checkConnection(), false);
	}

	public boolean save(boolean doForceInsert)
	{
		return save(checkConnection(), doForceInsert);
	}

	abstract boolean save(Connection conn, boolean doForceInsert);

	abstract boolean isChanged();

	public boolean setDate(String szFieldName, java.util.Date dtValue)
	{
		return getField(szFieldName).setDate(dtValue);
	}

	public ByteArrayInputStream getByteArrayInputStream(String szFieldName)
	{
		String szData = getString(szFieldName);
		if (szData == null)
			return null;

		byte aByteArr [] = szData.getBytes();
		return new ByteArrayInputStream(aByteArr, 0, aByteArr.length);
	}

	/**
	 *
	 * @param szFieldName	Name of BLOB column in table.
	 * @throws IllegalArgumentException	if column szFieldName does not exist
	 * @return	null if SQLException occurred
	 *
	 * @since	java_sdk_v2-6-5
	 */
	public byte[] getBlobContent(String szFieldName)
	{
		try
		{
			return getField(szFieldName).getBlobContent();
		}
		catch (SQLException sqle)
		{
			CDBRuntimeException e = new CDBRuntimeException(
				"Failed to get blob content from field " + szFieldName,
				sqle, 
				toProperties().setProperty("szFieldName", szFieldName),
				m_sQuery);

			throw e;
		}
	}

	/**
	 *	@param szFieldName
	 * @return maximum value of given column
	 * @deprecated	Use method max(String, CSQLWhereConstructor)
	 */
	public Double max(String szFieldName)
	{
		BigDecimal fResult = (BigDecimal) summary("MAX", /*tableName+*/ getField(szFieldName).getName());
		double dValue = (fResult == null ? 0 : fResult.doubleValue());
		return Double.valueOf(dValue);
	}

	public Double max(String szFieldName, CSQLWhereConstructor filter)
	{
		setFilter(filter.toString());
		return max(szFieldName);
	}

	public Double min(String szFieldName, CSQLWhereConstructor filter)
	{
		setFilter(filter.toString());
		BigDecimal fResult = (BigDecimal) summary("MIN", /*tableName+*/ getField(szFieldName).getName());
		double dValue = (fResult == null ? 0 : fResult.doubleValue());
		return Double.valueOf(dValue);
	}

	/**
	 *	@return number of records
	 * @deprecated	Use method count(String, CSQLWhereConstructor)
	 */
	public int count()
	{
		BigDecimal fResult = (BigDecimal) summary("COUNT", "*");
		return (fResult == null ? 0 : fResult.intValue());
	}

	public int count(CSQLWhereConstructor filter)
	{
		setFilter(filter.toString());
		return count();
	}

	/**
	 *	COMMENT ME
	 *
	 * @return Method returns Number - typically BigDecimal, Double or Integer
	 */
	protected Serializable summary(String sSummaryFunc, String sSummaryCol)
	{
		try
		{
			Connection conn = checkConnection();
			CSQLWhereFilter sqlFilter = CSQLWhereConstructor.parseTrickSql(getFilterString());
			return CSqlCommands.select(conn,
				sSummaryFunc + "(" + sSummaryCol + ")", getSource(), sqlFilter);
		}
		catch (CDBRuntimeException runtimeException)
		{
			throw runtimeException;
		}
	}

	public String getFilterString()
	{
		return (m_szFilter == null ? "" : m_szFilter);
	}

	/**
	 * Let's turn off this check. If needed, we could make it configurable via JMX.
	 */
	private boolean checkConnection = false;
	
	protected Connection checkConnection()
	{
		if (!checkConnection)
			return CCurrentThreadConnection.getConnection();
		
		final Connection conn = CCurrentThreadConnection.getConnection();

		try
		{
			if (conn == null)
				throw new CDBRuntimeException("Connection is null", CDBRuntimeException.ERR_NULL_CONNECTION);
			if (conn.isClosed())
				throw new CDBRuntimeException("Connection is closed", CDBRuntimeException.ERR_CLOSED_CONNECTION);
		}
		catch (SQLException sqlException)
		{
			throw new CDBRuntimeException(sqlException);
		}

		return conn;
	}

	protected final Map<String, CField> createFields(CDBSource dbSource)
	{
		Connection conn = checkConnection();
		return createFields(conn, dbSource);
	}

	/**
	 *	This method performs one additional SELECT to database in order to
	 *  take table meta-data (information about columns' names and types).
	 *
	 *  Select looks like this:
	 *  SELECT * FROM <TABLE> WHERE ROWNUM < 1
	 */
	protected final Map<String, CField> createFields(Connection conn, CDBSource dbSource)
	{
		HashMap<String, CField> objFields = new HashMap<String, CField>();

		{
			// Add "rowid" field
			CField rowidField = CFieldsFactory.getFactory().createRowIdField(
				dbSource.getIdentificationColumn(), dbSource.getSynonym(), !m_isGroupByed);

			objFields.put(rowidField.getNameUpper(), rowidField);
		}

		StringBuilder sbSource = new StringBuilder("SELECT ")
			.append(dbSource.getColumnsList()).append(" FROM ")
			.append(dbSource.getName()).append(" WHERE ROWNUM < 1 ");

		try
		{
			if (this.m_isGroupByed)
			{
				if (this.m_sGroupExpression.length() == 0)
					sbSource.append(" GROUP BY ").append(dbSource.getColumnsList());
				else
					sbSource.append(" GROUP BY ").append(this.m_sGroupExpression);
			}

			CTableMetaData metaData = CTableMetaData
				.getTableMetaData(conn, dbSource.getName(), sbSource.toString());

			Iterator<String> itColumns = dbSource.getColumns() != null ?
				new CArrayIterator<String>(dbSource.getColumns()) : metaData.getTableColumnsNames();

			for (; itColumns.hasNext();)
			{
				String sColumnName = itColumns.next();
				CColumnMetaData column = metaData.getColumnMetaData(sColumnName);

				CField field = CFieldsFactory.getFactory().createField(column,
					dbSource.getSynonym(), dbSource.getLobsSupported());

				if (field != null)
					objFields.put(field.getNameUpper(), field);
			}
		}
		catch (CDBRuntimeException runtimeException)
		{
			throw runtimeException;
		}
		catch (SQLException sqlException)
		{
			throw new CDBRuntimeException(sqlException);
		}

		return objFields;
	}

	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();

		for (CField field : m_objFields.values())
		{
			if (field != null)
				sb.append(field.toString() + "\n");
		}

		return sb.toString();
	}

	/**
	 * @return instance of CProperties
	 * @since java_sdk_v2-6-13
	 */
	public CProperties toProperties()
	{
		CProperties props = new CProperties()
			.setProperty("m_source", String.valueOf(m_source))
			.setProperty("m_szFilter", m_szFilter)
			.setProperty("m_szOrderBy", m_szOrderBy)
			.setProperty("m_isGroupBy", String.valueOf(m_isGroupByed))
			.setProperty("m_readOnlyDataSet", String.valueOf(m_readOnlyDataSet));

		/*	// It produces too long logs
		CField field;
		int i=1;
		for (Iterator it = m_objFields.values().iterator(); it.hasNext(); i++)
		{
			field = (CField) it.next();
			if (field != null)
				props.setProperties("field" + i + ".", field.toProperties());
		}

		if (m_source != null)
			props.setProperties("m_source.", m_source.toProperties());
		*/

		return props;
	}

	/**
	 *	COMMENT ME !!!
	 * @param sGroupExpression
	 * @param groupByState
	 */
	public void setGroup(String sGroupExpression, boolean groupByState)
	{

		m_isGroupByed = groupByState;
		m_sGroupExpression = (sGroupExpression == null ? "":sGroupExpression);

		if (m_isGroupByed)
			setReadOnly(true);
		else
			m_szDMLQuery = null;

		switchRowids(!groupByState);
	}

	/**
	 *	COMMENT ME !!!
	 * @param groupByState
	 */
	public void setGroup(boolean groupByState)
	{
		setGroup("", groupByState);
	}

	/**
	 *	COMMENT ME !!!
	 * @param sGroupExpression
	 */
	public void setGroup(String sGroupExpression)
	{
		setGroup(sGroupExpression, true);
	}

	/**
	 *	COMMENT ME !!!
	 */
	public void setGroup()
	{
		setGroup(true);
	}

	/**
	 *	COMMENT ME !!!
	 * @param isActive
	 */
	public void switchRowids(boolean isActive)
	{
		String sIdColumn = (m_source == null ? CDBSource.ROWID : m_source.getIdentificationColumn());
		CField field = this.fieldByName("ROWIDTOCHAR(" + sIdColumn + ")");
		if (field != null)
			field.setActive(isActive);
	}


	/**
	 *	COMMENT ME !!!
	 * @param readOnlyState
	 */
	public void setReadOnly(boolean readOnlyState)
	{
		m_readOnlyDataSet = readOnlyState;
		m_szDMLQuery = null;
		switchRowids(!readOnlyState);
	}

	/**
	 *	COMMENT ME !!!
	 */
	public final void setReadOnly()
	{
		setReadOnly(true);
	}

	/**
	 *	COMMENT ME !!!
	 * @return COMMENT ME
	 */
	public boolean isReadOnly()
	{
		return m_readOnlyDataSet;
	}

	/**
	 * COMMENT ME !!!
	 * this method does nothing
	 * @return COMMENT ME
	 */
	public boolean lock()
	{
		if(isReadOnly())
			return false;

		return true;
	}
}
