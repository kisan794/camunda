/*
 * @(#)$RCSfile: CJVMConnection.java,v $ $Revision: 1.15 $ $Date: 2008/10/14 09:11:53 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CJVMConnection.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2002-09-30	M.Lukyanenko			changed for 9i Rel2 Application Server
 *  2005-05-23	A.Solntsev				Delegate all methods to CConnection
 *  2005-08-11	A.Solntsev				Added forced setting of NLS Parameters.
 *  2006-07-13	A.Solntsev				Fixed terrible bug with HireRightDS/HireRightJDS
 *  2007-09-21	A.Solntsev				Added method getNonTrackingConnection() for using by CTraceLog.
 *  2007-11-05	A.Solntsev				JNDI name is not customizable (seems to be needed in JBoss)
 */
package hireright.sdk.db;

import java.sql.Connection;
import java.sql.SQLException;

import hireright.settings.GeneralSettings;

/**
 * A class for connecting to the local DB to the JVM
 *
 * @author Maxim Lukyanenko
 * @author Andrei Solntsev
 * @version $Revision: 1.15 $ $Date: 2008/10/14 09:11:53 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CJVMConnection.java,v $
 */
public class CJVMConnection
{
	/**
	 * JNDI name used to bind DataSource for application server and
	 * default DataSource for HireRight business components.
	 *
	 * TODO	We should change it to "java:comp/env/jdbc/HireRightJDS"
	 */
	public static final String JNDI_NAME_CONNECTION = "java:comp/env/jdbc/HireRightJDS";

	private static final String JVM_PROPERTY_JNDI_NAME = "logging.jndi.name";

	/**
	 * By default it's equal to {@link #JNDI_NAME_CONNECTION}.
	 * It can be customized in web.xml or by givin JVM property "db.jndi.name".
	 *
	 * It's probably need while running web application on JBoss server.
	 */
	private static String m_sJndiName = null;

	/**
	 * No need to create instance, use static methods.
	 */
	private CJVMConnection()
	{
	}

	private static final String getJndiName()
	{
		if (m_sJndiName == null)
		{
			m_sJndiName = System.getProperty(JVM_PROPERTY_JNDI_NAME, JNDI_NAME_CONNECTION);
		}

		return m_sJndiName;
	}

	public static Connection getConnection()
	{
		return CConnection.getConnection(getJndiName(), GeneralSettings.isTrackJdbcConnections());
	}

	public static Connection getNonTrackingConnection()
	{
		return CConnection.getConnection(getJndiName(), false);
	}

	/**
	 * @since java_sdk_v2-6-9
	 * @param conn
	 */
	public static void closeConnection(Connection conn)
	{
		try
		{
			if (conn != null)
				conn.close();
		}
		catch (SQLException sqle)	{ }

		conn = null;
	}
}