/*
 * @(#)$RCSfile: CSQLWhereFilter.java,v $ $Revision: 1.9 $ $Date: 2010/02/18 21:29:03 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CSQLWhereFilter.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2005-08-15	A.Solntsev	created 
 *  2005-09-02	A.Solntsev	Added method buildUnbindedSql().
 *  2006-03-13	A.Solntsev	Class CStringUtils is used instead of CFString.
 *  2006-06-16	A.Solntsev	implements Serializable, IHasProperties
 *  2006-10-03	A.Solntsev	Added logging of SQLException (it was ignored)
 *	2008-09-01	A.Solntsev	Fixed SQL filter containing apostrophes
 *	2010-02-08	A.Solntsev	Added support for DATEs in SQL filters
 *	2018-04-24	I.Suits		Added BIGINT to Long mapping
 */
package hireright.sdk.db;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IHasProperties;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

/**
 * This is a tricky class for bind variable in SQL Callable statements.
 * This class parses a special `tricky` SQL statements created by class
 * CSQLWhereConstructor. Then it can create CallableStatements based on
 * parsed `tricky` sql.
 * 
 * @see		hireright.sdk.db.CSQLWhereFilter (Unit test)
 * @see		hireright.sdk.db.CSQLWhereConstructor
 * @see		hireright.sdk.db.CSQLWhereConstructorTest (Unit test)
 * 
 * @author	Andrei Solntsev
 * @since		2005-08-16
 * @version $Revision: 1.9 $ $Date: 2010/02/18 21:29:03 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db/CSQLWhereFilter.java,v $
 */
public class CSQLWhereFilter implements Serializable, IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	private String m_sNormalSqlClause;
	private Map<Integer, String> m_bindedValues;
	private Map<Integer, Integer> m_bindedTypes;
	private int m_nMinIndex = -1;
	private int m_nMaxIndex = -1;
	
	CSQLWhereFilter(String sNormalSqlClause)
	{
		m_sNormalSqlClause = sNormalSqlClause;
		m_bindedValues = new HashMap<Integer, String>();
		m_bindedTypes = new HashMap<Integer, Integer>();
	}	
	
	CSQLWhereFilter()
	{
		this(null);
	}

	void addVariable(Integer nBindedVariableNumber, String variableValue, int sqlType)
	{
		m_bindedValues.put(nBindedVariableNumber, variableValue);
		m_bindedTypes.put(nBindedVariableNumber, new Integer(sqlType));

		if (m_nMinIndex == -1 || m_nMinIndex > nBindedVariableNumber.intValue())
			m_nMinIndex = nBindedVariableNumber.intValue();
		if (m_nMaxIndex == -1 || m_nMaxIndex < nBindedVariableNumber.intValue())
			m_nMaxIndex = nBindedVariableNumber.intValue();
	}
	
	void setNormalSql(String sNormalSqlClause)
	{
		m_sNormalSqlClause = sNormalSqlClause;
	}

	/**
	 * @since java_sdk_v2-6-14
	 * @return String-representation of this object of form "SQL Where Filter " + m_sNormalSqlClause;
	 */
	public String toString()
	{
		return "SQL Where Filter " + m_sNormalSqlClause;
	}
	
	/**
	 * @since java_sdk_v2-6-14
	 * @return CProperties containing all binded values and 
	 * 		SQL Where Clause (with \n replaced with \\)
	 */
	public CProperties toProperties()
	{
		return new CProperties()
			.setProperties( m_bindedValues )
			.setProperty("minIndex", m_nMinIndex)
			.setProperty("maxIndex", m_nMaxIndex)
			.setProperty("sqlClause", m_sNormalSqlClause.replace('\n', '\\'));
	}
	
	public String getSqlClause()
	{
		return m_sNormalSqlClause;
	}
	
	String getValue(int index)
	{
		return getValue(new Integer(index));
	}

	String getValue(Integer index)
	{
		return m_bindedValues.get(index);
	}

	int getSqlType(int index)
	{
		return getSqlType(new Integer(index));
	}
	
	int getSqlType(Integer index)
	{
		return ( m_bindedTypes.get(index)).intValue();
	}
	
	public int getMinIndex()
	{
		return m_nMinIndex;
	}
	
	public int getMaxIndex()
	{
		return m_nMaxIndex;
	}
	
	/**
	 * @return Iterator over Integers - indexes of binded variables
	 */
	public Iterable<Integer> getIndecies()
	{
		return m_bindedValues.keySet();
	}

	public boolean isEmpty()
	{
		return m_bindedTypes.isEmpty() && 
			(m_sNormalSqlClause == null || m_sNormalSqlClause.trim().length() < 1);
	}
	
	public PreparedStatement prepareStatement(Connection conn) throws SQLException
	{
		return prepareStatement(conn, getSqlClause());
	}
	
	public String buildUnbindedSql()
	{
		StringBuffer sbUnbindedSql = new StringBuffer(getSqlClause());

		for (Integer index : this.getIndecies())
		{
			String sValue = this.getValue(index);
			CStringUtils.replace(sbUnbindedSql, ":"+index, sValue);
		}
		
		return sbUnbindedSql.toString();
	}
	
	public PreparedStatement prepareStatement(Connection conn, String sStatement)
		throws SQLException
	{
		PreparedStatement stmt = conn.prepareStatement(sStatement);

		try
		{
			for (Integer index : this.getIndecies())
			{
				String sValue = this.getValue(index);
				switch (getSqlType(index))
				{
					case Types.INTEGER:
						stmt.setInt(index.intValue(), new Integer(sValue).intValue());
						break;
					case Types.BIGINT:
						stmt.setLong(index.intValue(), new Long(sValue).longValue());
						break;						
					case Types.NUMERIC:
						stmt.setDouble(index.intValue(), new Double(sValue).intValue());
						break;
					case Types.VARCHAR:
						stmt.setString(index.intValue(), sValue);
						break;
					case Types.DATE:
					case Types.TIME:
					case Types.TIMESTAMP:
						stmt.setTimestamp(index.intValue(), new Timestamp(Long.parseLong(sValue)) );
						break;
					default:
						stmt.setString(index.intValue(), sValue);
						break;
				}
			}
		}
		catch (SQLException sqlException)
		{
			try {stmt.close();} catch (SQLException e) {}
			throw new CDBRuntimeException(sqlException, toProperties(), m_sNormalSqlClause);
		}

		return stmt;
	}
}