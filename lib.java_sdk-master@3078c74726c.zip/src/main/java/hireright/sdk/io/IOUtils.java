/*
 * @(#)$RCSfile: IOUtils.java,v $ $Revision: 1.7 $ $Date: 2010/01/21 21:56:05 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/IOUtils.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-08-30	created
 * 	A.Solntsev			2008-02-20	Added methods readBytes(), writeBytes()
 * 	A.Solntsev			2008-05-08	Method writeBytes() now uses "byte[]" array instead of "char c".
 * 	A.Solntsev			2008-05-08	Added more methods for posting content to URL and retrieving response
 *	A.Solntsev			2008-06-16	Added function removeDuplicatedSlashes()
 */
package hireright.sdk.io;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * @author asolntsev
 * @since Aug 30, 2007
 * @version $Revision: 1.7 $ $Date: 2010/01/21 21:56:05 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/IOUtils.java,v $
 */
public class IOUtils
{
	// Constants
	public static final String HTTP_HEADER_CONTENT_TYPE = "Content-Type";
	public static final String CONTENT_TYPE_HTML = "text/html";
	public static final String HTTP_METHOD_POST = "POST";
	public static final String HTTP_METHOD_GET = "GET";
	
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
	public static final void closeSilently(Closeable closable)
	{
		if (closable != null)
		{
			try
			{
				closable.close();
			}
			catch (IOException ioe)
			{
				// keep silence
			}
		}
	}
	
	public static final void closeSilently(OutputStream out)
	{
		closeSilently( (Closeable) out );
	}

	public static final void closeSilently(InputStream in)
	{
		closeSilently( (Closeable) in );
	}
	
	public static final void closeSilently(InputStreamReader in)
	{
		closeSilently( (Closeable) in );
	}

	public static final void closeSilently(Writer out)
	{
		closeSilently( (Closeable) out );
	}
	
	public static String removeDuplicatedSlashes(String str)
	{
		if (str == null)
			return str;
		
		return str.replaceAll("(?<=[^:])/{2,}", "/");
	}
	
	public static String postHtml(String sUrl, String sContent) throws IOException
	{
		return post(sUrl, CONTENT_TYPE_HTML, sContent);
	}
	
	public static String post(String sUrl, String sContentType, String sContent) throws IOException
	{
		URL url = new URL(sUrl);
		return post(url, sContentType, sContent);
	}
	
	public static String postHtml(URL url, String sContent) throws IOException
	{
		return post(url, CONTENT_TYPE_HTML, sContent);
	}
	
	public static String post(URL url, String sContentType, String sContent) throws IOException
	{
		return post(url, sContentType, sContent, 60000);
	}
	
	public static String post(URL url, String sContentType, String sContent, int timeoutMs) throws IOException
	{
		HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
		try
		{
			httpConnection.setRequestMethod(HTTP_METHOD_POST);
			httpConnection.setRequestProperty(HTTP_HEADER_CONTENT_TYPE, sContentType);
			httpConnection.setConnectTimeout( timeoutMs );
			httpConnection.setReadTimeout( timeoutMs );
			httpConnection.setDoOutput(true);
	
			printText(httpConnection.getOutputStream(), sContent);
			return readText(httpConnection);
		}
		finally
		{
			httpConnection.disconnect();
		}
	}
	
	public static byte[] postHtmlReturningBytes(URL url, String sContent) throws IOException
	{
		return postReturningBytes(url, CONTENT_TYPE_HTML, sContent);
	}
	
	public static byte[] postReturningBytes(URL url, String sContentType, String sContent) throws IOException
	{
		HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
		try
		{
			httpConnection.setRequestMethod(HTTP_METHOD_POST);
			httpConnection.setRequestProperty(HTTP_HEADER_CONTENT_TYPE, sContentType);
			httpConnection.setDoOutput(true);
	
			printText(httpConnection.getOutputStream(), sContent);
			return readBytes(httpConnection);
		}
		finally
		{
			httpConnection.disconnect();
		}
	}
	
	public static void printText(OutputStream out, String sContent)
	{
		PrintWriter pwOut = new PrintWriter(out);
		try
		{
			pwOut.write(sContent);
			pwOut.flush();
		}
		finally
		{
			pwOut.close();
		}
	}
	
	public static String readText(HttpURLConnection httpConnection) throws IOException
	{
		return readText( httpConnection.getInputStream() );
	}
	
	public static String readText(InputStream in) throws IOException
	{
		// Read the result
		return readText( new InputStreamReader(in) );
	}

	public static String readText(InputStreamReader rIn) throws IOException
	{
		try
		{
			StringBuffer szbReturn = new StringBuffer();
			char[] caBuffer = new char[10*1024];	// 10 kb buffer
	
			while (true)
			{
				int nRead = rIn.read(caBuffer);
	
				if (nRead < 0)
					break;
	
				szbReturn.append(caBuffer, 0, nRead);
			}
	
			return szbReturn.toString();
		}
		finally
		{
			closeSilently( rIn );
		}
	}
	
	public static byte[] readBytes(HttpURLConnection httpConnection) throws IOException
	{
		// Get the length of resulting content
		int nContentLength = httpConnection.getContentLength();
		int bufferSize = (nContentLength > 0) ? nContentLength : 1024;

		InputStream inputStream = httpConnection.getInputStream();
		try
		{
			return readBytes( inputStream, bufferSize );
		}
		finally
		{
			// Close the HTTP connection
			closeSilently( inputStream );
		}
	}
	
	public static byte[] readBytes(InputStream in) throws IOException
	{
		return readBytes(in, 512);
	}
	
	public static byte[] readBytes(InputStream in, int initialSize) throws IOException
	{
		ByteArrayOutputStream out = new ByteArrayOutputStream(initialSize);
		writeBytes(in, out);
		return out.toByteArray();
	}
	
	public static boolean writeBytes(InputStream in, OutputStream out) throws IOException
	{
		boolean isEmptyFile = true;

		try
		{
			byte[] inputBuffer = new byte[1024];
			
			int bytesRead;
			while ((bytesRead = in.read(inputBuffer)) != -1)
			{
				out.write(inputBuffer, 0, bytesRead);
				isEmptyFile = false;
			}
		}
		finally
		{
			closeSilently( in );
			closeSilently( out );
		}

		return isEmptyFile;
	}
}
