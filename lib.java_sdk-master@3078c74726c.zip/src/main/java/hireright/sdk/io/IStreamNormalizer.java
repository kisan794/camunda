/*
 * @(#)$RCSfile: IStreamNormalizer.java,v $ $Revision: 1.5 $ $Date: 2008/07/28 09:47:34 $ $Author: cvsroot $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History
 * 	Anton Keks			2004-05-10	Created
 * 	A.Solntsev			2006-08-01	Extends Serializable
 */
package hireright.sdk.io;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.Serializable;

/**
 * An interface for stream normalizers, which remove unnecessary data from passed
 * streams
 *
 * @author Anton Keks 
 * @version $Revision: 1.5 $ $Date: 2008/07/28 09:47:34 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/IStreamNormalizer.java,v $
 */
public interface IStreamNormalizer extends Serializable
{
	
	/**
	 * This method reads data from input stream, normalizes (corrects) it 
	 * on-the-fly and writes to the output stream.
	 * 
	 * @param input Input Stream for reading data
	 * @param output Ouput Stream for writing data to 
	 */
	public void normalize(InputStream input, OutputStream output) throws IOException;

}
