/*
 * @(#)$RCSfile: RegexpFileFilter.java,v $Revision: 1.5 $ $Date: 2009/02/09 12:38:22 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/RegexpFileFilter.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 *	A.Solntsev			2007-09-09		created
 *	A.Solntsev			2007-09-21		Fixed bugs with Unix paths
 *	A.Solntsev			2009-02-03		Added optional parameter rootFolder (makes scanning faster)
 */
package hireright.sdk.io;

import java.io.File;
import java.io.FilenameFilter;
import java.io.Serializable;

/**
 * @author asolntsev
 * @since Sep 9, 2007
 * @version $Revision: 1.5 $ $Date: 2009/02/09 12:38:22 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/RegexpFileFilter.java,v $
 */
public class RegexpFileFilter implements FilenameFilter, Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	private final File rootFolder;
	private final String m_sFileNamePattern;
	private final boolean m_bRecurse;

	public RegexpFileFilter(String sFileNamePattern)
	{
		this(null, sFileNamePattern);
	}
	
	public RegexpFileFilter(File rootFolder, String sFileNamePattern)
	{
		this.rootFolder = rootFolder;
		m_sFileNamePattern = sFileNamePattern
			.replace('\\', '/')
			.replaceAll("\\.", "\\\\.")
			.replaceAll("\\*", ".*");

		m_bRecurse = (sFileNamePattern.indexOf("**") > -1);
	}

	public boolean accept(File dir, String name)
	{
		if (dir != null && rootFolder != null)
		{
			if (dir.toString().indexOf(rootFolder.toString()) != 0)
				return false;
		}
		
		String sFullName = name;
		if (dir != null)
		{
			sFullName = dir.toString() + File.separatorChar + name;
		}

		if (m_bRecurse)
		{
			File f = new File(sFullName);
			if (f.isDirectory())
				return true;
		}

		if (dir != null && rootFolder != null)
			sFullName = sFullName.substring(rootFolder.toString().length());
			
		sFullName = sFullName.replace('\\', '/');
		return (sFullName.matches(m_sFileNamePattern));
	}

	@Override
	public String toString()
	{
		if (rootFolder != null)
			return rootFolder + ":" + m_sFileNamePattern;
		
		return m_sFileNamePattern;
	}
}
