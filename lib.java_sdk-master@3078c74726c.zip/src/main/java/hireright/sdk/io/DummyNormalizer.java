/*
 * @(#)$RCSfile: DummyNormalizer.java,v $ $Revision: 1.5 $ $Date: 2008/07/28 09:47:13 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/DummyNormalizer.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History
 * 	Anton Keks				2004-05-10	Created
 */
package hireright.sdk.io;

import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;

/**
 * Normilizer that does nothing.
 * 
 * @author Daniel Travin
 * @version $Revision: 1.5 $ $Date: 2008/07/28 09:47:13 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/DummyNormalizer.java,v $
 */
public class DummyNormalizer implements IStreamNormalizer, Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	public DummyNormalizer()
	{

	}

	/**
	 * Input is forwarded to output
	 * 
	 * @param input Input Stream for reading data
	 * @param output Ouput Stream for writing data to 
	 */
	public void normalize(InputStream input, OutputStream output) throws IOException
	{
		int b = 0;

		while ( -1 != (b = input.read()) )
		{
			output.write(b);
		}
	}
}
