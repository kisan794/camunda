/*
 * @(#)$RCSfile: URLCommandRunner.java,v $ $Revision: 1.6 $ $Date: 2008/11/21 11:30:36 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/URLCommandRunner.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  V. Lazarev		2006-02-01	Created.
 *	A.Solntsev		2007-11-26	NetTracking.registerUrl();
 */
package hireright.sdk.io;

import java.io.*;
import java.net.*;
import java.util.*;

import hireright.sdk.net.NetTracking;

/**
 * This class is intended to execute requests by given URL.
 * Example of usage:
 * <code>
 * if (runner.executeRequest(sRequest, m_lRequestTimeout))
 * {
 *			if (runner.getLastError() != null)
 *				throw new CRuntimeException(runner.getLastError(),  this.getClass().getName());
 *
 *			result = runner.getContent();
 *			m_mapHeaders = runner.getHeaders();
 *		}
 *		else
 *		{
 *			throw new CRuntimeException("Timeout when executing URL command", this.getClass().getName());
 *		}
 * </code>
 * 
 * @author  Vladimir Lazarev
 * @version $Revision: 1.6 $ $Date: 2008/11/21 11:30:36 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/URLCommandRunner.java,v $
 */
public class URLCommandRunner implements Runnable
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	/** Request to be executed */
	private String m_sRequest = null;

	/** result of request execution */
	private byte[] m_byteContent;

	/** headers of response */
	private Map<String, String> m_mapHeaders;

	/** Flag to be used to see if process was finished */
	private boolean m_bCompleted = false;

	/** Last error of processing */
	private String m_sLastError = null;

	/**
	 * Run method for thread execution. Do not call it directly!
	 */
	public void run()
	{
		m_bCompleted 	= false;
		m_byteContent = null;
		m_sLastError 	= null;

		try
		{
			runCommand();
		}
		catch (IOException e)
		{
			m_sLastError = e.getMessage();
		}

		m_bCompleted = true;
	}

	/**
	 * Method starts separate thread which executes given request.
	 * @param sRequest
	 * @param lTimeout
	 * @return true - if successful , false - otherwise
	 * @throws InterruptedException
	 */
	public boolean executeRequest(String sRequest, long lTimeout) throws InterruptedException
	{
		m_sRequest = sRequest;

		final Thread executionThread = new Thread(this);
		executionThread.setPriority(Thread.MAX_PRIORITY);
		executionThread.start();

		executionThread.join(lTimeout);

		return m_bCompleted;
	}

	/**
	 * Method runs command and stores byte result and response headers.
	 * @throws IOException
	 */
	private void runCommand() throws IOException
	{
		m_bCompleted = false;

		NetTracking.registerUrl(m_sRequest);

		URL url = new URL(m_sRequest);
		URLConnection connection = url.openConnection();

		InputStream byteinStream =  connection.getInputStream();
		ByteArrayOutputStream byteoutStream = new ByteArrayOutputStream();

		byte[] buffer = new byte[2048];
		for (int c = byteinStream.read(buffer); c >= 0; c = byteinStream.read(buffer))
		{
			byteoutStream.write(buffer, 0, c);
		}

		m_byteContent = byteoutStream.toByteArray();

		// read headers
		m_mapHeaders = new HashMap<String, String>();

		if (connection.getHeaderFields() != null)
		{
			Set<String> keys = connection.getHeaderFields().keySet();

			for (String headerName : keys)
			{
				m_mapHeaders.put(headerName,connection.getHeaderField(headerName));
			}
		}
	}

	/**
	 * @return The byte result of request execution
	 */
	public byte[] getContent()
	{
		return m_byteContent;
	}

	/**
	 * @return The headers of result
	 */
	public Map<String, String> getHeaders()
	{
		return m_mapHeaders;
	}

	/**
	 * This method should be called to get last occured error
	 * @return Last error
	 */
	public String getLastError()
	{
		return m_sLastError;
	}
}
