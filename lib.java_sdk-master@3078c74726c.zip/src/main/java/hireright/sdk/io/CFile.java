/*
 * @(#)$RCSfile: CFile.java,v $ $Revision: 1.10 $ $Date: 2010/03/11 21:42:06 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/CFile.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	M.Lukyanenko			2002-07-03	Created
 *	Andrei Solntsev		2006-04-29	Initially this class was used in 'registry' tool.
 *																I guess it's not used any more.
 *	Andrei Solntsev		2009-02-11	System.out -> commons-logging
 *	A.Solntsev				2010-03-05	Use log4j instead of commons-logging.
 */
package hireright.sdk.io;

import hireright.sdk.util.WildCardFileFilter;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

/**
 *
 * @author M.Lukyanenko
 * @version $Revision: 1.10 $ $Date: 2010/03/11 21:42:06 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/CFile.java,v $
 */
public class CFile extends File implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.10 $ $Author: cvsroot $";
	
	private static final Logger log = Logger.getLogger(CFile.class);
	
	private static int BUFFER_SIZE = 2048;

	public CFile(String pathname)
	{
		super(pathname);
	}

	public void copy(String szDestFileName) throws IOException
	{
		copy(getPath(), szDestFileName);
	}

	public static void copy(String szSrcFileName, String szDestFileName) throws IOException
	{
		BufferedInputStream bis = new BufferedInputStream(new FileInputStream(szSrcFileName));
		try
		{
			BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(szDestFileName));

			try
			{
				int count;
				byte data[] = new byte[BUFFER_SIZE];
				while ((count = bis.read(data, 0, BUFFER_SIZE)) != -1) 
				{
					bos.write(data, 0, count);
				}
				bos.flush();
			}
			finally
			{
				IOUtils.closeSilently(bos);
			}
		}
		finally
		{
			IOUtils.closeSilently(bis);
		}
	}

	public void cpdir(String sDestDir) throws IOException
	{
		cpdir(getPath(), sDestDir);
	}

	public static void cpdir(String sSrcDir, String sDestDir) throws IOException
	{
		CFile srcDir = new CFile (sSrcDir);
		String sSrcPath = srcDir.getPath();

		CFile destDir = new CFile (sDestDir);
		if(!destDir.exists())
			destDir.mkdir();

		String listSrcDir[] = srcDir.list();
		String sptr = System.getProperty("file.separator");

		if(listSrcDir == null)
			throw new FileNotFoundException("Source directory not found: " + sSrcDir);

		for(int i = 0; i < listSrcDir.length; i++)
		{
			CFile srcFile = new CFile ( sSrcPath + sptr + listSrcDir[i] );
			CFile destFile = new CFile ( sDestDir + sptr + listSrcDir[i] );
			if (srcFile.isDirectory())
			{
				//if desdenation path is not exist
				if(!destFile.exists())
					destFile.mkdir();
				cpdir(srcFile.getPath(), destFile.getPath());
			}
			else
			{
				srcFile.copy(sDestDir + sptr + listSrcDir[i]);
			}
		}
	}

	public void rmdir() throws SecurityException
	{
		rmdir(getPath());
	}

	public static void rmdir(String sDirPath) throws SecurityException
	{
		File Dir = new File(sDirPath);
		String sptr = System.getProperty("file.separator");
		if(!Dir.exists())
			return;
		String sLstDir[] = Dir.list();
		for(int i = 0; i < sLstDir.length; i++)
		{
			File FileForDel = new File(sDirPath + sptr + sLstDir[i]);
			if( FileForDel.isDirectory() )
			{
				rmdir(sDirPath + sptr + sLstDir[i]);
			}
			else
			{
				if(!FileForDel.delete())
					log.error("I can't delete file: " + sDirPath + sptr + sLstDir[i] + "!");
			}
		}
		if(!Dir.delete())
			log.error("I can't delete directory:" + sDirPath +"!");
	}

	//return file extension or null
	public String getExt()
	{
		return getExt(getName());
	}

	public static String getExt(String sFileName)
	{
		String szExt = null;
		int nPointPos = sFileName.lastIndexOf('.');
		if(nPointPos != -1)
			szExt	= new String (sFileName.substring(nPointPos+1));
		return szExt;
	}

	public File findFile (String sFileName)
	{
		return findFile(getPath(), sFileName);
	}

	public static File findFile(String sDir, String sFileName)
	{
		File fRes = null;
		File fDir = new File(sDir);

		File [] fileList = fDir.listFiles();
		int n = -1;
		for(int i = 0 ; i < fileList.length; i++)
		{
			if(fileList[i].getName().equals(sFileName))
			{
				n = i;
				break;
			}
			else if(fileList[i].isDirectory())
			{
				fRes = findFile(fileList[i].getPath(),sFileName );
				if(fRes != null)
					return fRes;
			}
		}

		if( n != -1)
			fRes = new File(fileList[n].getPath());

		return fRes;
	}

	public static String createRandTmpDir()
	{
		int nExt = (int)(Math.random() * 10000);
		String szTest = System.getProperty("java.io.tmpdir");
		String szTmp = szTest.substring(szTest.length()-1);
		if(szTmp.equals(System.getProperty("file.separator")))
			szTest = szTest + "tmp_" + nExt;
		else
			szTest = szTest + System.getProperty("file.separator") +
												"tmp_" + nExt;
		CFile newDir = new CFile (szTest);
		newDir.mkdir();
		return szTest;
	}

	/**
	 * Creates temporary working directory.
	 *
	 * @return Directory object
	 */
	public static File createTmpDir()
	{
		File newDir = newTmpFile(System.getProperty("java.io.tmpdir"));
		if(newDir.mkdir())
			return newDir;

		return null;
	}

	/**
	 * Constructs File object with tmp.xxxx name and checks that such file does not exist.
	 * It will not create file, just an object.
	 *
	 * @param sPath directory path
	 */
	public static File newTmpFile(String sPath)
	{
		File tmpFile;

		for(int i = 0; i < 0xFFFF; i++)
		{
			try
			{
				tmpFile = new File(sPath + System.getProperty("file.separator")+ "tmp." + Integer.toHexString(i));
				if(!tmpFile.exists())
					return tmpFile;
			}
			catch(Exception e)
			{
				log.error(e.getMessage(), e);
			}
		}

		return null;
	}

	public static final Collection<String> getFileList(String sWildcard, boolean bRecurseSubdirectories)
	{
		File path = new File(sWildcard);
		File parentDir = path.getParentFile();
		if (parentDir == null)
			parentDir = new File(".");

		return getFileList(parentDir, new WildCardFileFilter(path.getName()), bRecurseSubdirectories);
	}

	public static final Collection<String> getFileList(File parentDir, FilenameFilter filenameFilter, boolean bRecurseSubdirectories)
	{
		List<String> outFileNameList = new LinkedList<String>();
		getDirList(outFileNameList, parentDir, filenameFilter, bRecurseSubdirectories);
		return outFileNameList;
	}

	public static final void getDirList(List<String> outFileNameList, File dirPath ,FilenameFilter filter, boolean bRecurseSubdirectories)
	{
		File[] list = dirPath.listFiles(filter);

		if(list != null)//if we can list this directory (somwtimes we might have no access)
		{
			int i = list.length;

			while(i-- != 0)
			{
				File entry = list[i];

				if(entry.isDirectory())
				{
					if(bRecurseSubdirectories)
						getDirList(outFileNameList, entry.getAbsoluteFile(), filter, bRecurseSubdirectories);
				}
				else
				{
					outFileNameList.add(entry.getAbsolutePath());
				}
			}
		}
	}

}