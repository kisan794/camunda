/*
 * @(#)$RCSfile: IORuntimeException.java,v $ $Revision: 1.2 $ $Date: 2010/01/08 08:52:20 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/io/IORuntimeException.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev				2010-01-06	created
 */
package hireright.sdk.io;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $ $Date: 2010/01/08 08:52:20 $ $Author: cvsroot $
 */
public class IORuntimeException extends RuntimeException
{
	public IORuntimeException( String message, Throwable cause )
	{
		super( message, cause );
	}

	public IORuntimeException( String message )
	{
		super( message );
	}

	public IORuntimeException( Throwable cause )
	{
		super( cause );
	}	
}
