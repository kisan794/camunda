/*
 * @(#)$RCSfile: Constants.java,v $ $Revision: 1.6 $ $Date: 2008/07/28 09:48:10 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/consts/Constants.java,v $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	2001-03-20	A.Rudenko		Added define for request types
 *  2001-03-21	A.Nesterov	dublicated request type constants now hav same values
 *  2001-09-25	unknown			Added XML_WEEK, XML_YEAR, XML_DAY, XML_MONTH, XML_HOUR values
 *  2005-03-09	A.Solntsev	added constant Integer COUNTRY_ID_USA
 */
package hireright.sdk.consts;

/**
 * @author A.Rudenko ?
 * @version $Revision: 1.6 $ $Date: 2008/07/28 09:48:10 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/consts/Constants.java,v $
 */
public class Constants
{
	public final static Integer COUNTRY_ID_USA = new Integer(1);
	public final static short COUNTRY_USA = 1;
	public final static short UNDEFINED = -1;
	
	public final static String COUNTRY_CODE3_USA = "USA";
	public final static String COUNTRY_CODE2_USA = "US";

		//define :))) for request types
	public final static short EMP = 1;
	public final static short EDU = 2;
	public final static short REF = 3;

	//now this looks better ...
	public final static short REQ_TYPE_EDUCATION = EDU;
	public final static short REQ_TYPE_EMPLOYMENT = EMP;
	public final static short REQ_TYPE_PERSONAL_REF = REF;

	public static final short MODULE_ID_USERS = 309;

//some handy values for XML documents
	public static final String XML_TRUE = "true";
	public static final String XML_FALSE = "false";

	public static final String XML_WEEK = "week";
	public static final String XML_YEAR = "year";
	public static final String XML_DAY = "day";
	public static final String XML_MONTH = "month";
	public static final String XML_HOUR = "hour";

//common constant values used as DB field values
	public static final String DB_TRUE = "T";
	public static final String DB_FALSE = "F";

	public static final String DB_YES = "Y";
	public static final String DB_NO = "N";
}

