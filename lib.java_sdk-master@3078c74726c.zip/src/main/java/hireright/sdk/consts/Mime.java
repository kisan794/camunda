/*
 * @(#)$RCSfile: Mime.java,v $ $Revision: 1.6 $ $Date: 2008/07/28 09:46:13 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/consts/Mime.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Nexterov			2002-08-30	created
 *  M.Karpov			2008-02-13	Added IMAGE_JPEG type
 *  J.Jegorov			2022-03-11	Added TEXT_JSON type
 */
package hireright.sdk.consts;

import java.io.Serializable;

/**
 * MIME types constants
 * 
 * @author Alex Nexterov
 * @version $Revision: 1.6 $ $Date: 2008/07/28 09:46:13 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/consts/Mime.java,v $
 */
public final class Mime implements Serializable
{
	public static final String TEXT_PLAIN = "text/plain";
	public static final String TEXT_HTML = "text/html";
	public static final String TEXT_XML = "text/xml";
	public static final String TEXT_JSON = "text/json";
	public static final String APPLICATION_PDF = "application/pdf";
	public static final String IMAGE_JPEG = "image/jpeg";
}
