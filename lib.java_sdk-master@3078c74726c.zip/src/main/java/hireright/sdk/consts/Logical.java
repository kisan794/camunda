/*
 * @(#)$RCSfile: Logical.java,v $ $Revision: 1.6 $ $Date: 2013/02/27 10:13:38 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/consts/Logical.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   M.Abdulganejev		2007-04-19  Created
 *   M.Suhhoruki		2011-10-10  added isTrue
 *   M.Suhhoruki		2013-02-18  added isFalse to discourage potentially dangerous !isTrue() use, added to toBoolean with true/false/null return
 *   											NB! Incompatibility: removed 'T' check from isTrue: too ambiguous
 *   
 */
package hireright.sdk.consts;

/**
 * TODO add description
 * @author M.Abdulganejev
 * @version $Revision: 1.6 $ $Date: 2013/02/27 10:13:38 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/consts/Logical.java,v $
 */
public class Logical 
{
	/**
	 * 
	 */
	public static final String YES_SHORT = "Y";
	
	/**
	 * 
	 */
	public static final String YES_FULL_UPPER_CASE = "YES";
	
	/**
	 * 
	 */
	public static final String YES_FULL_MIXED_CASE = "Yes";
	
	/**
	 * 
	 */
	public static final String YES_FULL_LOWER_CASE = "yes";
	
	/**
	 * 
	 */
	public static final String NO_SHORT = "N";
	
	/**
	 * 
	 */
	public static final String NO_FULL_UPPER_CASE = "NO";
	
	/**
	 * 
	 */
	public static final String NO_FULL_MIXED_CASE = "No";
	
	/**
	 * 
	 */
	public static final String NO_FULL_LOWER_CASE = "no";
	
	/**
	 * 
	 */
	public static final String TRUE_SHORT = "T";
	
	/**
	 * 
	 */
	public static final String TRUE_FULL_UPPER_CASE = "TRUE";
	
	/**
	 * 
	 */
	public static final String TRUE_FULL_MIXED_CASE  = "True";
	
	/**
	 * 
	 */
	public static final String TRUE_FULL_LOWER_CASE = Boolean.TRUE.toString();
	
	/**
	 * 
	 */
	public static final String FALSE_SHORT = "F";
	
	/**
	 * 
	 */
	public static final String FALSE_FULL_UPPER_CASE = "FALSE";
	
	/**
	 * 
	 */
	public static final String FALSE_FULL_MIXED_CASE  = "False";
	
	/**
	 * 
	 */
	public static final String FALSE_FULL_LOWER_CASE = Boolean.FALSE.toString();
	
	/**
	 * Checks whether string means true/yes.
	 * 
	 * NB! Cannot be used to infer 'false',
	 * i.e. do not use !Logical.isTrue when legal matters are involved.
	 * Use explicit Logical.isFalse instead.
	 * 
	 * @param sAny
	 * @return
	 */
	public static boolean isTrue(String sAny)
	{
		return sAny != null
				&& (sAny.equalsIgnoreCase(TRUE_FULL_UPPER_CASE)
				|| sAny.equalsIgnoreCase(YES_SHORT)
				|| sAny.equalsIgnoreCase(YES_FULL_UPPER_CASE));
	}
	
	/**
	 * Checks whether string means false/no.
	 * 
	 * NB! Cannot be used to infer 'true',
	 * i.e. do not use !Logical.isFalse when legal matters are involved.
	 * Use explicit Logical.isTrue instead.
	 * 
	 * @param sAny
	 * @return
	 */
	public static boolean isFalse(String sAny)
	{
		return sAny != null
				&& (sAny.equalsIgnoreCase(FALSE_FULL_UPPER_CASE)
				|| sAny.equalsIgnoreCase(NO_SHORT)
				|| sAny.equalsIgnoreCase(NO_FULL_UPPER_CASE));
	}
	
	/**
	 * Create true/false/null boolean from string.
	 * Null/empty string produces null boolean.
	 * Non-empty value interpretation is determined by isTrue and isFalse methods.
	 */
	public static Boolean toBoolean(String sAny)
	{
		if (isTrue(sAny))
		{
			return Boolean.TRUE;
		}
		else if (isFalse(sAny))
		{
			return Boolean.FALSE;
		}
		
		return null;
	}
}
