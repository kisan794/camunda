/*
 * @(#)$RCSfile: EnvelopeStatus.java,v $ $Revision: 1.4 $ $Date: 2008/07/28 09:48:52 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/consts/EnvelopeStatus.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Nexterov?			2002-08-30	created
 */
package hireright.sdk.consts;

/**
 * 
 * @author unknown
 * @version $Revision: 1.4 $ $Date: 2008/07/28 09:48:52 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/consts/EnvelopeStatus.java,v $
 */
public final class EnvelopeStatus extends Object
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	//Status codes
	public static final int SC_SUCCESS							= 200;
	public static final int SC_BAD_REQUEST						= 400;
	public static final int SC_ACCESS_DENIED					= 401;
	public static final int SC_FORBIDDEN						= 403;
	public static final int SC_CREDENTIAL_ERROR					= 460;
	public static final int SC_CERTIFICATE_ERROR				= 461;
	public static final int SC_ENVELOPE_PARSE_ERROR				= 462;
	public static final int SC_MANIFEST_NOT_ACCEPTABLE			= 468;
	public static final int SC_ACTION_DOES_NOT_MATCH_MANIFEST	= 469;
	public static final int SC_PROCESS_NOT_IMPLEMENTED			= 501;

	//Short text description
	public static final String ST_SUCCESS						= "Success (ok)";
	public static final String ST_BAD_REQUEST					= "Bad Request";
	public static final String ST_ACCESS_DENIED					= "Access Denied (Unauthorised)";
	public static final String ST_FORBIDDEN						= "Forbidden";
	public static final String ST_CREDENTIAL_ERROR				= "Credential Error";
	public static final String ST_CERTIFICATE_ERROR				= "Certificate Error";
	public static final String ST_ENVELOPE_PARSE_ERROR			= "Envelope Parse Error";
	public static final String ST_MANIFEST_NOT_ACCEPTABLE			= "Manifest not acceptable";
	public static final String ST_ACTION_DOES_NOT_MATCH_MANIFEST	= "Action does not match manifest";
	public static final String ST_PROCESS_NOT_IMPLEMENTED		= "Process not implemented";

	//Long text description
/*Not used. Yet... :)
	public static final String LT_SUCCESS						= "Success (ok)";
	public static final String LT_BAD_REQUEST					= "Bad Request";
	public static final String LT_ACCESS_DENIED					= "Access Denied (Unauthorised)";
	public static final String LT_FORBIDDEN						= "Forbidden";
	public static final String LT_CREDENTIAL_ERROR				= "Credential Error";
	public static final String LT_CERTIFICATE_ERROR				= "Certificate Error";
	public static final String LT_ENVELOPE_PARSE_ERROR			= "Envelope Parse Error";
	public static final String LT_MANIFENOT_ACCEPTABLE			= "Manifest not acceptable";
	public static final String LT_ACTION_DOES_NOT_MATCH_MANIFEST	= "Action does not match manifest";
	public static final String LT_PROCESS_NOT_IMPLEMENTED		= "Process not implemented";
*/

	public static final String getShortText(int nStatusCode)
	{
		switch(nStatusCode)
		{
		case SC_SUCCESS:
			return ST_SUCCESS;
		case SC_BAD_REQUEST:
			return ST_BAD_REQUEST;
		case SC_ACCESS_DENIED:
			return ST_ACCESS_DENIED;
		case SC_FORBIDDEN:
			return ST_FORBIDDEN;
		case SC_CREDENTIAL_ERROR:
			return ST_CREDENTIAL_ERROR;
		case SC_CERTIFICATE_ERROR:
			return ST_CERTIFICATE_ERROR;
		case SC_ENVELOPE_PARSE_ERROR:
			return ST_ENVELOPE_PARSE_ERROR;
		case SC_MANIFEST_NOT_ACCEPTABLE:
			return ST_MANIFEST_NOT_ACCEPTABLE;
		case SC_ACTION_DOES_NOT_MATCH_MANIFEST:
			return ST_ACTION_DOES_NOT_MATCH_MANIFEST;
		case SC_PROCESS_NOT_IMPLEMENTED:
			return ST_PROCESS_NOT_IMPLEMENTED;
		default:
			return "";
		}
	}
}
