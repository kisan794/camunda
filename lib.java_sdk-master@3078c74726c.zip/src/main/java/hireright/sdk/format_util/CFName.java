/*
 * @(#)$RCSfile: CFName.java,v $ $Revision: 1.5 $ $Date: 2009/02/20 10:25:52 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFName.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  A.Nesterov			2001-10-24	created
 */
package hireright.sdk.format_util;

/**
 * Class CFFax provides formatting of e-mail address string
 * 
 * @author Alexander Nesterov
 * @version $Revision: 1.5 $ $Date: 2009/02/20 10:25:52 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFName.java,v $
 */
public class CFName extends CFDta implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	String m_strFirstName;
	String m_strLastName;
	String m_strMiddleName;
	private static final CXMLTag m_XMLTag = new CXMLTag("name");

	public CFName(String strFullName)
	{
		parseFullName(strFullName);
	}
//------------------------------------------------------------------------------
	public CFName(String strFirstName, String strMiddleName, String strLastName)
	{
		m_strFirstName = strFirstName;
		m_strLastName = strLastName;
		m_strMiddleName = strMiddleName;
		if(m_strFirstName == null)
			setValid(false);
	}
//------------------------------------------------------------------------------
	public CFName(String strFirstName, String strLastName)
	{
		m_strFirstName = strFirstName;
		m_strLastName = strLastName;
		m_strMiddleName = null;
		if(m_strFirstName == null)
			setValid(false);
	}
//------------------------------------------------------------------------------
	public String toString()
	{
		if(m_strFirstName == null || m_strFirstName.length() == 0)
			return "";

		StringBuffer result = new StringBuffer(m_strFirstName);

		if(m_strMiddleName != null && m_strMiddleName.length() != 0)
		{
			result.append(" ");
			result.append(m_strMiddleName);
		}

		if(m_strLastName != null && m_strLastName.length() != 0)
		{
			result.append(" ");
			result.append(m_strLastName);
		}

		return result.toString();
	}
//------------------------------------------------------------------------------
	public String getFirstName()
	{
		return m_strFirstName;
	}
//------------------------------------------------------------------------------
	public String getLastName()
	{
		return m_strLastName;
	}
//------------------------------------------------------------------------------
	public String getMiddleName()
	{
		return m_strMiddleName;
	}
//------------------------------------------------------------------------------
	protected final void parseFullName(String strFullName)
	{
		m_strLastName = null;
		m_strMiddleName = null;

		if(strFullName == null)
		{
			m_strFirstName = null;
			return;
		}

		StringBuffer temp = new StringBuffer(strFullName.trim());

		int charCount = temp.length();
		if(charCount == 0)
		{
			m_strFirstName = null;
			setValid(false);
			return;
		}

		int i = 0;
		for(; i < charCount;i++)//get first name
		{
			if(temp.charAt(i) == ' ' || i == charCount - 1)
			{
				m_strFirstName = temp.substring(0, ++i);
				temp.delete(0, i);
				break;
			}
		}

		charCount = i = temp.length();

		while(i-- != 0)//get last name
		{
			if(i == -1)
			{
				m_strLastName = temp.substring(++i, charCount);
				temp.setLength(0);
				break;
			}
			else if(temp.charAt(i) == ' ')
			{
				m_strLastName = temp.substring(++i, charCount);
				temp.delete(--i, charCount);
				break;
			}
		}

		if(temp.length() > 0)
		{
			m_strMiddleName = temp.toString().trim();
			if(m_strMiddleName.length() == 0)
				m_strMiddleName = null;
		}
	}
//------------------------------------------------------------------------------
	protected CXMLTag getXMLTag()
	{
		return m_XMLTag;
	}
}

