/*
 * @(#)$RCSfile: CFSalary.java,v $ $Revision: 1.4 $ $Date: 2008/07/28 09:48:39 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFSalary.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  A.Nesterov			2001-10-24	created
 */
package hireright.sdk.format_util;

/**
 * A CFSalary class.
 * 
 * @author Alexander Nesterov
 * @version $Revision: 1.4 $ $Date: 2008/07/28 09:48:39 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFSalary.java,v $
 */
public class CFSalary extends CFDta implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	private String m_strCurrency;
	private String m_strSalaryRate;
	private static CXMLTag m_XMLTag = new CXMLTag("salary");
//------------------------------------------------------------------------------
	public CFSalary(String strSalaryRate, String strCurrency)
	{
		m_strSalaryRate = strSalaryRate;
		m_strCurrency = strCurrency;
	}
//------------------------------------------------------------------------------
	public CFSalary(String strSalaryRate)
	{
		m_strSalaryRate = strSalaryRate;
		m_strCurrency = null;
	}
//------------------------------------------------------------------------------
	public String toString()
	{
		if(m_strCurrency != null && m_strCurrency.length() != 0)
			return m_strCurrency + m_strCurrency;
		return m_strSalaryRate;
	}
//------------------------------------------------------------------------------
	public String getSalaryRate()
	{
		return m_strCurrency;
	}
//------------------------------------------------------------------------------
	protected CXMLTag getXMLTag()
	{
		return m_XMLTag;
	}
}

