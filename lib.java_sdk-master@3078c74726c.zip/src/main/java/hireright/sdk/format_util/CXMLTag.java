/*
 * @(#)$RCSfile: CXMLTag.java,v $ $Revision: 1.4 $ $Date: 2008/07/28 09:47:22 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CXMLTag.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  A.Nesterov			2001-10-24	created
 */
package hireright.sdk.format_util;

/**
 * XML Tag
 * 
 * @author Alexander Nesterov
 * @version $Revision: 1.4 $ $Date: 2008/07/28 09:47:22 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CXMLTag.java,v $
 */
public class CXMLTag extends CXMLObject implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	protected String m_strTag;

	public CXMLTag(String strTag)
	{
			m_strTag = strTag;
	}

	public String getXMLTag()
	{
			return m_strTag;
	}

	public void setXMLTag(String strTag)
	{
			m_strTag = strTag;
	}
}