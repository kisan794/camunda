/*
 * @(#)$RCSfile: CXMLFormat.java,v $ $Revision: 1.4 $ $Date: 2008/07/28 09:47:26 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CXMLFormat.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  A.Nesterov			2001-10-24	created
 */
package hireright.sdk.format_util;

/**
 * XML Format functions
 * 
 * @author Alexander Nesterov 
 * @version $Revision: 1.4 $ $Date: 2008/07/28 09:47:26 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CXMLFormat.java,v $
 */
public class CXMLFormat implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	public static String format(String tagName, String tagValue, String tagAttributes)
	{
		return (new CXMLTag(tagName)).toXMLString(tagValue, tagAttributes);
	}
	
	public static String format(String tagName, String tagValue)
	{
		return (new CXMLTag(tagName)).toXMLString(tagValue);
	}
}