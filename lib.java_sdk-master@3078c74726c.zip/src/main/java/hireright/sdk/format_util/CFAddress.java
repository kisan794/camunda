/*
 * @(#)$RCSfile: CFAddress.java,v $ $Revision: 1.4 $ $Date: 2008/07/28 09:47:53 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFAddress.java,v $
 *
 * Copyright 2001-2008 by	HireRight, Inc.	All	rights reserved.
 *
 * This	software is	the	confidential and proprietary information
 * of	HireRight, Inc.	Use	is subject to	license	terms.
 *
 * History:
 * 	2002-xx-yy	A.Nesterov				created
 */
package hireright.sdk.format_util;
import hireright.sdk.consts.Constants;

/**
 * CFAddress class porovides address string formatting functionality
 * 
 * @author Alexander Nesterov
 * @version $Revision: 1.4 $ $Date: 2008/07/28 09:47:53 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFAddress.java,v $
 */
public class CFAddress extends CFDta implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	private String m_strCountry;
	private String m_strRegion;
	private String m_strCity;
	private String m_strStreet;
	private static final CXMLTag m_XMLTag = new CXMLTag("address");
	private short m_CountryCode = Constants.UNDEFINED;
//----------------------------------------------------
	public CFAddress(String strCountry,
					 String strRegion,
					 String strCity,
					 String strStreet)
	{
		m_strCountry = strCountry;
		m_strRegion = strRegion;
		m_strCity = strCity;
		m_strStreet = strStreet;
	}
//----------------------------------------------------
	public CFAddress(String strCountry,
					 String strCity,
					 String strStreet)
	{
		m_strCountry = strCountry;
		m_strRegion = null;
		m_strCity = strCity;
		m_strStreet = strStreet;
	}
//----------------------------------------------------
	public String toString()
	{
		if((m_strCity == null || m_strCity.length() == 0) &&
			(m_strCountry == null || m_strCountry.length() == 0) &&
			(m_strRegion == null || m_strRegion.length() == 0) &&
			(m_strStreet == null || m_strStreet.length() == 0))
			return "";

		StringBuffer result = new StringBuffer();

		boolean bFirst = true;


		if(m_strStreet != null && m_strStreet.length() != 0)
		{
			bFirst = false;
			result.append(m_strStreet);
		}
		
		if(m_strCity != null && m_strCity.length() != 0)
		{
			if(bFirst)
				bFirst = false;
			else
				result.append(", ");
				
			result.append(m_strCity);
		}

		if(m_strRegion != null && m_strRegion.length() != 0)
		{
			if(bFirst)
				bFirst = false;
			else
				result.append(", ");

			result.append(m_strRegion);
		}

		if(m_strCountry != null && m_strCountry.length() != 0)
		{
			if(bFirst)
				bFirst = false;
			else
				result.append(", ");

			result.append(m_strCountry);
		}

		return result.toString();
	}
//----------------------------------------------------
	public String getCity()
	{
		return m_strCity;
	}
//----------------------------------------------------
	public String getCountry()
	{
		return m_strCountry;
	}
//----------------------------------------------------
	public String getRegion()
	{
		return m_strRegion;
	}
//----------------------------------------------------
	public String getStreet()
	{
		return m_strStreet;
	}
//----------------------------------------------------
	protected CXMLTag getXMLTag()
	{
		return m_XMLTag;
	}
}

