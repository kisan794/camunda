/*
 * @(#)$RCSfile: CXMLObject.java,v $ $Revision: 1.4 $ $Date: 2008/07/28 09:48:25 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CXMLObject.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  A.Nesterov			2001-10-24	created
 */
package hireright.sdk.format_util;

/**
 * XML output helper
 * 
 * @author Alexander Nesterov 
 * @version $Revision: 1.4 $ $Date: 2008/07/28 09:48:25 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CXMLObject.java,v $
 */
public abstract class CXMLObject implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	protected abstract String getXMLTag(); //Must be overwritten and return protected static String m_strXMLTag;

	protected String toXMLString(String strValue)
	{
			String strXMLTag = getXMLTag();
			if(strValue == null || strValue.length() == 0)
					return "<" + strXMLTag + "/>";

			StringBuffer result = new StringBuffer();
			result.append("<");
			result.append(strXMLTag);
			result.append(">");
			result.append(strValue);
			result.append("</");
			result.append(strXMLTag);
			result.append(">");

			return  result.toString();
	}

	protected String toXMLString(String strValue, String strAttributes)
	{
			String strXMLTag = getXMLTag();
			if((strValue == null || strValue.length() == 0) &&
					(strAttributes == null || strAttributes.length() == 0))
					return "<" + strXMLTag + "/>";


			StringBuffer result = new StringBuffer();
			result.append("<");
			result.append(strXMLTag);

			if(strAttributes != null && strAttributes.length() != 0)
			{
					result.append(' ');
					result.append(strAttributes);
			}

			if(strValue == null || strValue.length() == 0)
			{
					result.append("/>");
					return result.toString();
			}

			result.append(">");
			result.append(strValue);
			result.append("</");
			result.append(strXMLTag);
			result.append(">");

			return  result.toString();
	}
}