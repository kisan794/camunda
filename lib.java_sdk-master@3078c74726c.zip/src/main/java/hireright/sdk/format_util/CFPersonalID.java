/*
 * @(#)$RCSfile: CFPersonalID.java,v $ $Revision: 1.13 $ $Date: 2009/10/23 08:14:44 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFPersonalID.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * A.Nikulin   		2002-12-10 - new constructor added to support not olny CountryID, but CountryCode also;
 * S.Prokopov		2003-09-22 - changed SSN format from xxx-xx to ***-**
 * M.Litvinov		2004-07-12 - added proc. getMaskedPersonalID
 * A.Solntsev		2007-01-11 - fixed NullPointerException in method getMaskedPersonalID()
 * A.Velizhanin	2009-10-14 - fixed SSN format in getInSsnFormat()
 */
package hireright.sdk.format_util;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.IHasProperties;
import hireright.sdk.consts.Constants;


/**
 * Performes formatting for personal ID data
 * 
 * @author Alexander Nesterov
 * @version $Revision: 1.13 $ $Date: 2009/10/23 08:14:44 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFPersonalID.java,v $
 */
public class CFPersonalID extends CFDta implements java.io.Serializable, IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.13 $ $Author: asolntsev $";
	
	// constants for formatting ssn
	public static final int FORMAT_DEFAULT = 0;
	public static final int FORMAT_ALLOWED_BY_LAW = 1;
	
	public static final boolean PARAM_TYPE_PERSONAL_ID = true;
	public static final boolean PARAM_TYPE_EXTENSION = false;
	
	private String m_strPersonalID;
	private String m_strExtension;
	private static final CXMLTag m_XMLTag = new CXMLTag("ssn");
	private short m_nCountryID;
	private int		m_nOutputFormat = FORMAT_DEFAULT;

//------------------------------------------------------------------------------
	public CFPersonalID(String strPersonalID, String strExtension)
	{
		initPersonalIdWithExtenion(strPersonalID, strExtension);
	}
//------------------------------------------------------------------------------
	public CFPersonalID(String strPersonalID)
	{
		m_strPersonalID = strPersonalID;
		m_nCountryID = Constants.UNDEFINED;
		checkData();
	}
//------------------------------------------------------------------------------
	public CFPersonalID(String strPersonalID, String strExtension, short nCountryID)
	{
		m_strPersonalID = strPersonalID;
		m_strExtension = strExtension;
		m_nCountryID = nCountryID;
		checkData();
	}
//------------------------------------------------------------------------------
	public CFPersonalID(String strPersonalID, short nCountryID)
	{
		m_strPersonalID = strPersonalID;
		m_nCountryID = nCountryID;
		checkData();
	}
//------------------------------------------------------------------------------
	
	/**
	 * if bParamtype == PARAM_TYPE_PERSONAL_ID -> sParam is CountryCode;
	 * else -> sParam is Extension;
	 * 
	 * @param strPersonalID 
	 * @param sParam 
	 * @param bParamType PARAM_TYPE_PERSONAL_ID or PARAM_TYPE_EXTENSION
	 * 
	 */
	public CFPersonalID(String strPersonalID, String sParam, boolean bParamType)
	{
		if (bParamType == PARAM_TYPE_PERSONAL_ID)
		{
			String sCountryCode = sParam;
			m_strPersonalID = strPersonalID;
			if (sCountryCode.equals(Constants.COUNTRY_CODE3_USA)
				|| sCountryCode.equals(Constants.COUNTRY_CODE2_USA))
			{
				m_nCountryID = Constants.COUNTRY_USA;
			}
			else
			{
				m_nCountryID = Constants.UNDEFINED;
			}
			checkData();
		}
		else 
			initPersonalIdWithExtenion(strPersonalID, sParam);
	}
//------------------------------------------------------------------------------
	private void initPersonalIdWithExtenion(String strPersonalID, String strExtension)
	{
		m_strExtension = strExtension;
		m_nCountryID = Constants.UNDEFINED;
		checkData();
	}
//------------------------------------------------------------------------------
	public String getFull()
	{
		if(m_strPersonalID == null || m_strPersonalID.length() == 0)
			return "";

		if(m_strExtension != null && m_strExtension.length() != 0)
		{
			StringBuffer result = new StringBuffer(m_strPersonalID);
			result.append(", ");
			result.append(m_strExtension);
			return result.toString();
		}

		return m_strPersonalID;
	}
//------------------------------------------------------------------------------
	public String toString()
	{
		switch (m_nCountryID)
		{
			case Constants.COUNTRY_USA:
				return getInSsnFormat();
			default:
				return getFull();
		}
	}
//------------------------------------------------------------------------------
	public void setOutputFormat(int nOutputFormat)
	{
		m_nOutputFormat = nOutputFormat;
	}
//------------------------------------------------------------------------------
	public String getPersonalID()
	{
		return m_strPersonalID;
	}
		/**
	 * @return SSN in NNN-NN-NNNN format
	 * or if it shorter than 9 in the unchanged format
	 */
	public String getInSsnFormat() 
	{
		if(m_strPersonalID == null)
			return null;

		StringBuffer result = new StringBuffer(m_strPersonalID);
	
		if (result.length() >= 9)	// There may be illegal shorter SSN's
		{
			// filter out any "-" that SSN may have
			StringBuffer resultFiltered = new StringBuffer();
			for (int i=0; i < result.length(); i++)
			{
				if (result.charAt(i) == '-')
				{
					continue;
				}
				resultFiltered.append(result.charAt(i));
			}
			result = resultFiltered;
			// output format is for ssn's only : ****-**-1234
			if(m_nOutputFormat  == FORMAT_ALLOWED_BY_LAW)
			{
				result.replace(0, 5, "*****");
			}
			// insert "-" in correct places
			result.insert(3, "-");
			result.insert(6, "-");
		}

		return result.toString();
	}
//------------------------------------------------------------------------------
	public String getExtesion()
	{
		return m_strExtension;
	}
//------------------------------------------------------------------------------
	private final void parsePersonalID(String strPersonalID)
	{
		if (strPersonalID.trim().length() < 5) //FIXME correct minimal length of ID string must be set
		{
			m_strPersonalID = strPersonalID.trim(); //FIXME if parsing failed may be right to set ID value of null.
			m_strExtension = null;
			setValid(false);
		}
	}
//------------------------------------------------------------------------------
	protected CXMLTag getXMLTag()
	{
		return m_XMLTag;
	}
//------------------------------------------------------------------------------
	protected final void checkData()
	{
		if (m_strPersonalID == null)
		{
				setValid(false);
				return;
		}
		
		switch(m_nCountryID)
		{
			case Constants.COUNTRY_USA:
				removeNonDigit();
				if(m_strPersonalID.length() != 9)
					setValid(false);

			default:
				parsePersonalID(m_strPersonalID);
		}
	}
//------------------------------------------------------------------------------
	protected final void removeNonDigit()
	{
		StringBuffer temp = new StringBuffer();
		char character;
		int charCount = m_strPersonalID.length();

		for(int i = 0; i < charCount; i++)
		{
			character = m_strPersonalID.charAt(i);
			if(Character.isDigit(character))
				temp.append(character);
		}

		if(temp.length() != charCount)
			m_strPersonalID = temp.toString();
	}
	
	/**
	 * Function is intended to substitute characters with '*' symbols
	 * in personal id/ssn. Characters like '-' or spaces are not substituted.
	 * 
	 * @return personal id in '***-**-1234' or '*****1234' format
	 */
	public String getMaskedPersonalID()
	{
		if (m_strPersonalID == null)
			return m_strPersonalID;
		
		// amount of unmasked symbols at the end of personal id
		final int nNonMaskedChars = 4; 
		
		try
		{
			if (m_strPersonalID.length() > nNonMaskedChars)
			{
				String pattern = "[^\\-\\s]";	// any character except '-' or whitespace chars
				return  m_strPersonalID.substring(0, m_strPersonalID.length() - nNonMaskedChars).replaceAll(pattern, "*")
					+ m_strPersonalID.substring(m_strPersonalID.length() - nNonMaskedChars);
			}
			else
				return m_strPersonalID;
		}
		catch(Exception e)
		{
			CTraceLog.error(e, this.getClass().getName() + ".getMaskedPersonalID()");
			// return unmasked personal id as it is
			return m_strPersonalID;
		}
	}
	
	public CProperties toProperties()
	{
		return new CProperties()
			.setProperty("personalID", m_strPersonalID)
			.setProperty("extension", m_strExtension)
			.setProperty("countryID", m_nCountryID)
			.setProperty("outputFormat", m_nOutputFormat == FORMAT_DEFAULT? null : "alloowed_by_law");
	}
}

