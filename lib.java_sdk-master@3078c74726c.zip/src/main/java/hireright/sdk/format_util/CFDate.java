/*
 * @(#)$RCSfile: CFDate.java,v $ $Revision: 1.15 $ $Date: 2011/11/18 10:22:08 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFDate.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  A.Nesterov			2001-10-24	created
 *  A.Plohotnichenko	2003-10-13	getDay(): format changed "d" -> "dd"
 *	A.Solntsev			2006-05-10	Fixed formatting logic; added javadoc
 *	A.Solntsev			2006-05-19	QuickFix: "mm" --> "MM"
 *	M.Abdulganejev		2007-02-27	ISO_8601_FULL added
 *	E.Naidenyshev		2011-11-14	Added pattern USA_DATE_TIME_FORMAT
 */
package hireright.sdk.format_util;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * CFDate class provides date formatting functionality
 * 
 * @author Alexander Nesterov
 * @since 2001/10/24
 * @version $Revision: 1.15 $ $Date: 2011/11/18 10:22:08 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFDate.java,v $
 */
public class CFDate extends CFDta implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.15 $ $Author: cvsroot $";
	
	public static final ThreadSafeDateFormat DD = new ThreadSafeDateFormat("dd");
	public static final ThreadSafeDateFormat MM = new ThreadSafeDateFormat("MM");
	public static final ThreadSafeDateFormat YYYY = new ThreadSafeDateFormat("yyyy");
	public static final ThreadSafeDateFormat HOURS = new ThreadSafeDateFormat("H");
	public static final ThreadSafeDateFormat MINUTES = new ThreadSafeDateFormat("m");
	
	public static final String ISO_8601 = "yyyy-MM-dd";	// + hh:mm:ss ?
	public static final String USA_DATE_FORMAT = "MM/dd/yyyy";
	public static final String USA_DATE_TIME_FORMAT = "MM/dd/yyyy HH:mm";
	
	public static final String ISO_8601_FULL = "yyyy-MM-dd'T'HH:mm:ss";
	
	private static final String DEF_XML_DATE_FORMAT = "'y=\"'yyyy'\" m=\"'MM'\" d=\"'dd\"";
	
	private static final CXMLTag m_XMLTag = new CXMLTag("date");
	
	private Date m_date;
	
	private final SimpleDateFormat m_stringFormatter;
	private final SimpleDateFormat m_xmlFormatter;

	private String m_strBadDate = new String();

	private CFDate()
	{
		m_stringFormatter = new SimpleDateFormat(USA_DATE_FORMAT);
		m_xmlFormatter = new SimpleDateFormat(DEF_XML_DATE_FORMAT);		
	}
	
	public CFDate(Date date)
	{
		this();
		
		m_date = date;
		// if(m_date == null)
		// 		setValid(false);
	}

	public CFDate(String strDate)
	{
		this();
		
		if (strDate == null)
		{
			m_date = null;
			return;
		}

		strDate.trim();

		if (strDate.length() == 0)
		{
			m_date = null;
			return;
		}

		parseDate(strDate);
	}

	public CFDate(int year, int month, int day)
	{
		this();
		setDate(year, month, day);
	}

	public final void setDate(int year, int month, int day)
	{
		if (year > 2100 || year < 1000 ||
			month > 12 || month < 1 ||
			day > 31 || day < 1)
			setValid(false);

		m_date = (new GregorianCalendar(year, month - 1, day)).getTime();
	}

	public CFDate(String strYear, String strMonth, String strDay)
	{
		this();
		
		if (strYear == null || strYear.length() == 0 ||
			strMonth == null || strMonth.length() == 0 ||
			strDay == null || strDay.length() == 0)
		{
			m_date = null;
			return;
		}

		try
		{
			setDate(new Integer(strYear).intValue(),
					new Integer(strMonth).intValue(),
					new Integer(strDay).intValue());
		}
		catch (Exception e)
		{
			setValid(false);
		}
	}

	@Override
	public String toString()
	{
		if (m_date == null)
			return m_strBadDate;

		return m_stringFormatter.format(m_date);
	}

	public static String toString(Date date)
	{
		if (date == null)
			return "";

		try
		{
			SimpleDateFormat formatter = new SimpleDateFormat(USA_DATE_FORMAT);
			return formatter.format(date);
		}
		catch (Exception e)
		{
			return "";
		}
	}

	public String format(String sFormatPattern)
	{
		if (m_date == null)
			return m_strBadDate;

		return new SimpleDateFormat(sFormatPattern).format(m_date);
	}

	public String getYear()
	{
		return YYYY.format(m_date);
	}

	public String getMonth()
	{
		return MM.format(m_date);
	}

	public String getDay()
	{
		return DD.format(m_date);
	}

	public String getHours()
	{
		return HOURS.format(m_date);
	}

	public String getMinutes()
	{
		return MINUTES.format(m_date);
	}

	@Override
	public String toXML()
	{
		if(m_date == null)
			return m_XMLTag.toXMLString(m_strBadDate);

		String strAttrib = m_xmlFormatter.format(m_date);

		if (!isValid())
			strAttrib += " valid=\"No\"";
		return m_XMLTag.toXMLString(null, strAttrib);
	}

	public final void parseDate(String strDate)
	{
		//suppose it is in MM/dd/yyyy format
		StringBuffer temp;
		int i = 0, charCount = strDate.length();
		int mm;
		int dd;
		int yyyy;
		while(i < charCount && !Character.isDigit(strDate.charAt(i))) //skip nondigit characters
			i++;

		temp = new StringBuffer();
		while(i < charCount && Character.isDigit(strDate.charAt(i))) //collect month
			temp.append(strDate.charAt(i++));
		try
		{
			mm = Integer.parseInt(temp.toString());

			while(i < charCount && !Character.isDigit(strDate.charAt(i))) //skip nondigit characters
				i++;

			temp = new StringBuffer();
			while(i < charCount && Character.isDigit(strDate.charAt(i))) //collect day
				temp.append(strDate.charAt(i++));
			dd = Integer.parseInt(temp.toString());

			while(i < charCount && !Character.isDigit(strDate.charAt(i))) //skip nondigit characters
				i++;

			temp = new StringBuffer();
			while(i < charCount && Character.isDigit(strDate.charAt(i))) //collect year
				temp.append(strDate.charAt(i++));
			yyyy = Integer.parseInt(temp.toString());

			if(yyyy > 2100 || yyyy < 1000 ||
				mm > 12 || mm < 1 ||
				dd > 31 || dd < 1)
			{
				setValid(false);
				m_strBadDate = strDate;
			}
			
			m_date = (new GregorianCalendar(yyyy, mm - 1, dd)).getTime();
		}
		catch(Exception e)
		{
			m_date = null;
			m_strBadDate = strDate;
		}
	}

	public Date getDate()
	{
		return m_date;
	}

	@Override
	protected CXMLTag getXMLTag()
	{
		return m_XMLTag;
	}

	@Override
	public boolean isEmpty()
	{
		return m_date == null;
	}
}

