/*
 * @(#)$RCSfile: CDateFormatMatcher.java,v $ $Revision: 1.2 $ $Date: 2012/03/29 20:37:45 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CDateFormatMatcher.java,v $
 *
 * Copyright 2001-2012 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   K.Ovchinnikov		2011-10-13  Created.
 *   K.Ovchinnikov		2012-03-16  Renamed and moved from ehf_contribution_form 
 */
package hireright.sdk.format_util;

import hireright.sdk.util.CStringUtils;

/**
 * Date validation
 * 
 * @author Kirill_Ovchinnikov
 * @version $Revision: 1.2 $ $Date: 2012/03/29 20:37:45 $ $Author: cvsroot $
 */
public class CDateFormatMatcher
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	private static final String MONTH_REGEXP = "^(0[0-9])|(1[0-2])$";
	private static final String YEAR_REGEXP = "^(19\\d\\d)|(20\\d\\d)$";
	private static final String DAY_REGEXP = "^([0-2][0-9])|(3[0|1])$";
	
	/**
	 * Checks if day format is correct 
	 * 
	 * @param day
	 * @return
	 */
	public static boolean matchDay(String day)
	{
		return matches(day, DAY_REGEXP);
	}
	
	/**
	 * Checks if month format is correct
	 * 
	 * @param month
	 * @return
	 */
	public static boolean matchMonth(String month)
	{
		return matches(month, MONTH_REGEXP);
	}
	
	/**
	 * Checks if year format is correct
	 * 
	 * @param year
	 * @return
	 */
	public static boolean matchYear(String year)
	{
		return matches(year, YEAR_REGEXP);
	}
	
	private static boolean matches(String str, String regexp)
	{
		if(!CStringUtils.isEmpty(str))
		{
			return str.matches(regexp);
		}
		return false;
	}
	
}
