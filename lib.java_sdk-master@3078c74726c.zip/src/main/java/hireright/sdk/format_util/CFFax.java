/*
 * @(#)$RCSfile: CFFax.java,v $ $Revision: 1.4 $ $Date: 2008/07/28 09:48:00 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFFax.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  A.Nesterov			2001-10-24	created
 */
package hireright.sdk.format_util;
import	hireright.sdk.consts.Constants;

/**
 * Class CFFax provides formatting of fax phone number data
 * 
 * @author Alexander Nesterov
 * @version $Revision: 1.4 $ $Date: 2008/07/28 09:48:00 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFFax.java,v $
 */
public final class CFFax extends CFDta implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	private CFPhone m_phoneNumber;
	private static final CXMLTag m_XMLTag = new CXMLTag("fax");
//------------------------------------------------------------------------------
	public CFFax(String strCountryCode, String strAreaCode, String strPhoneNumber)
	{
		m_phoneNumber = new CFPhone(strCountryCode, strAreaCode, strPhoneNumber);
	}
//------------------------------------------------------------------------------
	public CFFax(String strCountryCode, String strPhoneNumber)
	{
		m_phoneNumber = new CFPhone(strCountryCode, strPhoneNumber);
	}
//------------------------------------------------------------------------------
	public CFFax(String strPhoneNumber)
	{
		m_phoneNumber = new CFPhone(strPhoneNumber);
	}
//------------------------------------------------------------------------------
	public CFFax(String strCountryCode, String strAreaCode, String strPhoneNumber, short nCountryCode)
	{
		m_phoneNumber = new CFPhone(strCountryCode, strAreaCode, strPhoneNumber, nCountryCode);
	}
//------------------------------------------------------------------------------
	public CFFax(String strCountryCode, String strPhoneNumber, short nCountryCode)
	{
		m_phoneNumber = new CFPhone(strCountryCode, strPhoneNumber, nCountryCode);
	}
//------------------------------------------------------------------------------
	public CFFax(String strPhoneNumber, short nCountryCode)
	{
		m_phoneNumber = new CFPhone(strPhoneNumber, nCountryCode);
	}
//------------------------------------------------------------------------------
	public final String toString()
	{
		return m_phoneNumber.toString();
	}
//------------------------------------------------------------------------------
	public final String toXML()
	{
		StringBuffer attrib = new StringBuffer();
		String value;
		String strCountryPhoneCode = m_phoneNumber.getCountryPhoneCode();

		if(strCountryPhoneCode.length() > 0)
		{
			switch(m_phoneNumber.getCountryCode())
			{
			case Constants.COUNTRY_USA:
				break;

			case Constants.UNDEFINED:
				attrib.append("ccode=\"FIX ME PLEASE!!!\""); //Just debug feature, please remove if not needed.
				break;

			default:
				attrib.append("ccode=\"");
				attrib.append(strCountryPhoneCode);
				attrib.append('\"');
			}
		}

		if(isValid())
			value = m_phoneNumber.toString();
		else
		{
			StringBuffer temp = new StringBuffer("<![CDATA[");
			temp.append(m_phoneNumber.toString());
			temp.append("]]>");
			value = temp.toString();
			attrib.append(" valid=\"No\"");
		}

		return m_XMLTag.toXMLString(value, attrib.toString());
	}
//------------------------------------------------------------------------------
	public final String getCountryCode()
	{
		return m_phoneNumber.getCountryPhoneCode();
	}
//------------------------------------------------------------------------------
	public final String getAreaCode()
	{
		return m_phoneNumber.getAreaCode();
	}
//------------------------------------------------------------------------------
	public final String getFaxNumber()
	{
		return m_phoneNumber.getPhoneNumber();
	}
//------------------------------------------------------------------------------
	public final void parseFaxNumber(String strFaxNumber)
	{
		m_phoneNumber.parsePhoneNumber(strFaxNumber);
	}
//------------------------------------------------------------------------------
	protected CXMLTag getXMLTag()
	{
		return m_XMLTag;
	}
}

