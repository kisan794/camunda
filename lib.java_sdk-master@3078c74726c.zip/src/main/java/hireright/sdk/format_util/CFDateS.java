/*
 * @(#)$RCSfile: CFDateS.java,v $ $Revision: 1.4 $ $Date: 2008/07/28 09:46:42 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFDateS.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  Sergei Ignatov			2001-08-03	created
 */
package hireright.sdk.format_util;

/**
 * Insert the type's description here.
 * 
 * @author Sergei Ignatov
 * @since 3/8/2001 4:37:28 PM
 * @version $Revision: 1.4 $ $Date: 2008/07/28 09:46:42 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFDateS.java,v $
 */
public class CFDateS extends CFDate implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	private final CXMLTag m_tag = new CXMLTag("");
	
	/**
	 * CFDateS constructor comment.
	 * @param year int
	 * @param month int
	 * @param date int
	 */
	public CFDateS(int year, int month, int date)
	{
		super(year, month, date);
		m_tag.setXMLTag("");
	}

	/**
	 * CFDateS constructor comment.
	 * @param strDate java.lang.String
	 */
	public CFDateS(String strDate)
	{
		super(strDate);
		m_tag.setXMLTag("");
	}
	
	/**
	 * CFDateS constructor comment.
	 * @param year java.lang.String
	 * @param month java.lang.String
	 * @param date java.lang.String
	 */
	public CFDateS(String year, String month, String date)
	{
		super(year, month, date);
		m_tag.setXMLTag("");
	}

	/**
	 * CFDateS constructor comment.
	 * @param year java.lang.String
	 * @param month java.lang.String
	 * @param date java.lang.String
	 */
	public CFDateS(String year, String month, String date, String szTag )
	{
		super(year, month, date);
		m_tag.setXMLTag( szTag == null ? "" : szTag );
	}

	/**
	 * CFDateS constructor comment.
	 * @param date java.util.Date
	 */
	public CFDateS(java.util.Date date)
	{
		super(date);
		m_tag.setXMLTag("");
	}

	/**
	 * Insert the method's description here.
	 * Creation date: (3/8/2001 4:38:21 PM)
	 * @return java.sql.Date
	 */
	public java.sql.Date getSQLDate()
	{
		java.sql.Date retSqlDate = null;
		
		if(  getDate() != null )
			retSqlDate = new java.sql.Date( getDate().getTime() );
		
		return retSqlDate;
	}

	public String toXML()
	{
		String szResult = super.toXML();
		if( m_tag.getXMLTag().length() > 0 )
			szResult = "<" + m_tag.getXMLTag() + ">" + szResult + "</" + m_tag.getXMLTag() + ">";
		
		return szResult;
	}

	/**
	 * CFDateS constructor comment.
	 * @param date java.util.Date
	 */
	public CFDateS(java.util.Date date, String szTag )
	{
		super(date);
		m_tag.setXMLTag(szTag);
	}
}
