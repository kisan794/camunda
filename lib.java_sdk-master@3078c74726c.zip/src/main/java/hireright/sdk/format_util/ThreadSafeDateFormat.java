/*
 * @(#)$RCSfile: ThreadSafeDateFormat.java,v $ $Revision: 1.6 $ $Date: 2011/04/04 13:33:06 $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/ThreadSafeDateFormat.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Solntsev		2008-11-13		Created
 *  A.Solntsev		2008-12-08		Stupid bugfix: if (softRef == softRef)
 *  M.Suhhoruki	2010-04-23		setTimeZone NPE fix (called on DateFormat)
 *  A.Tanasenko		2011-03-31		Added constructor with TimeZone
 */
package hireright.sdk.format_util;

import java.lang.ref.SoftReference;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Class is a thread-safe implementation of java.text.DateFormat.
 * It can be used in multi-thread environment.
 * 
 * TODO Add usage example
 * 
 * 
 * @author Andrei Solntsev
 * @version $Revision: 1.6 $, $Date: 2011/04/04 13:33:06 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/ThreadSafeDateFormat.java,v $
 */
public class ThreadSafeDateFormat extends DateFormat
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	private final String m_sDateFormat;
	private final TimeZone m_timeZone;

	public ThreadSafeDateFormat(String sDateFormat)
	{
		this(sDateFormat, null);
	}

	public ThreadSafeDateFormat(String sDateFormat, TimeZone timeZone)
	{
		m_sDateFormat = sDateFormat;
		m_timeZone = timeZone;
	}

	private final ThreadLocal<SoftReference<DateFormat>> m_formatCache = new ThreadLocal<SoftReference<DateFormat>>()
	{
		@Override
		public SoftReference<DateFormat> get()
		{
			SoftReference<DateFormat> softRef = super.get();
			if (softRef == null || softRef.get() == null)
			{
				DateFormat format = new SimpleDateFormat(m_sDateFormat);
				if(m_timeZone != null)
				{
					format.setTimeZone(m_timeZone);
				}
				softRef = new SoftReference<DateFormat>( format );
				super.set(softRef);
			}
			return softRef;
		}
	};

	private DateFormat getDateFormat()
	{
		return m_formatCache.get().get();
	}

	@Override
	public StringBuffer format(Date date, StringBuffer toAppendTo,
			FieldPosition fieldPosition)
	{
		return getDateFormat().format(date, toAppendTo, fieldPosition);
	}

	@Override
	public Date parse(String source, ParsePosition pos)
	{
		return getDateFormat().parse(source, pos);
	}
	
	@Override
	public void setTimeZone(TimeZone zone)
	{
		getDateFormat().setTimeZone(zone);
	}
	
	@Override
	public TimeZone getTimeZone()
	{
		return getDateFormat().getTimeZone();
	}
}
