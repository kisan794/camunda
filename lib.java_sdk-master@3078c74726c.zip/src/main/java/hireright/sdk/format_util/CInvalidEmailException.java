/*
 * @(#)$RCSfile: CInvalidEmailException.java,v $ $Revision: 1.3 $ $Date: 2008/07/28 09:46:46 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CInvalidEmailException.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  A.Solntsev			2007-xx-yy	created
 */
package hireright.sdk.format_util;

import java.text.ParseException;

/**
 * 
 * @author asolntsev
 * @version $Revision: 1.3 $ $Date: 2008/07/28 09:46:46 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CInvalidEmailException.java,v $
 */
public class CInvalidEmailException extends ParseException
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
	
	public CInvalidEmailException(final String sEmail, int errorOffset, String sCause)
	{
		super("Invalid email: " + sEmail, errorOffset);
	}
}
