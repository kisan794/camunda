/*
 * @(#)$RCSfile: CFString.java,v $ $Revision: 1.8 $ $Date: 2008/11/21 11:31:26 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFString.java,v $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	S.Ignatov		2001-03-02	created
 *	S.Ignatov		2001-03-09	compareTo( Integer ) added
 *	S.Ignatov		2001-03-23	compareAndSet added
 *	S.Ignatov		2001-04-03	more functions added
 *	S.Ignatov		2001-04-05	Method toXML optimized (a little :) )
 *	A.Solntsev	2005-12-01	Method replace now returns this.
 *	M.Suhhoruki	2017-08-28	Added max length, isValid
 */
package hireright.sdk.format_util;

import hireright.sdk.util.CStringUtils;

/**
 * 	COMMENT ME
 *  
 * @author Sergei Ignatov
 * @since	2001-02-03
 * @version $Revision: 1.8 $ $Date: 2008/11/21 11:31:26 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFString.java,v $
 */
public class CFString extends CFDta  implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	protected String m_szValue = "";
	protected final CXMLTag m_XMLTag = new CXMLTag("");	
	protected String m_szReqParam = "";
	private Integer m_nMaxLength;
	
	/**
	 * toString method comment.
	 */
	public CFString() 
	{
		super();
		setValid( true );
	}
	/**
	 * toString method comment.
	 */
	public CFString( String szData ) 
	{
		super();
		m_szValue = ( (szData == null ) ? "": szData ) ;
		setValid( true );	
	}
	/**
	 * toString method comment.
	 */
	public CFString( String szData, String szTag ) 
	{
		super();
		m_szValue = szData;
		m_XMLTag.setXMLTag( szTag == null ? "" : szTag );
		setValid( true );	
	}
	/**
	 * toString method comment.
	 */
	public CFString( String szData, String szTag, String szRequestParam ) 
	{
		super();
		m_szValue = szData;
		m_XMLTag.setXMLTag( szTag == null ? "" : szTag );
		m_szReqParam = ( szRequestParam == null ? "" : szRequestParam );
		setValid( true );	
	}
	
	public CFString(String szData, Integer nMaxLength) 
	{
		this(szData);
		setMaxLength(nMaxLength);
	}
	
	/**
	 * toString method comment.
	 */
	public int compareTo( String szParam ) 
	{
		if( szParam == null )
		  return -1;
		  
		return toString().compareTo(szParam);
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/6/2001 4:34:23 PM)
	 */
	public void empty() 
	{
		m_szValue = "";
	}
	
	/**
	 * getXMLTag method comment.
	 */
	protected CXMLTag getXMLTag() 
	{
		return m_XMLTag;
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/6/2001 4:07:23 PM)
	 */
	public boolean isEmpty() 
	{
		if( toString().length() == 0 )
		  return true;
		return false;  
	}
	
	/**
	 * toString method comment.
	 */
	public String toString() 
	{
		return ( m_szValue == null ? "" : m_szValue.trim() );
	}
	
	/**
	 * 
	 */
	public String toXML()
	{
		String szResult = '<' + m_XMLTag.getXMLTag();
		
		if(m_szReqParam.length() != 0)
			szResult += ' ' + m_szReqParam;
		
		if(!isValid())
			szResult += " valid=\"No\"";
		
		Integer nMaxLength = getMaxLength();
		if (nMaxLength != null)
		{
			szResult += " maxLength=\"" + nMaxLength + "\"";
		}
		
		szResult += ( m_id != null ? ( ' ' + m_XMLTag.getXMLTag() + "_id=\"" + m_id.toString() + "\">") : ">" );
		
		if(m_isCFDATA)
			szResult += "<![CDATA[" + toString() + "]]>";
		else
			szResult += toString();
		
		szResult += "</" + m_XMLTag.getXMLTag() + '>';
		return szResult;
	}
	
	/**
	 * toString method comment.
	 */
	public int compareTo( Integer nParam ) 
	{
		if( nParam == null )
		  return -1;
	
		return toString().compareTo( nParam.toString() );
	}
	
		    protected String m_id = "";
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/12/2001 5:16:44 PM)
	 * @param nValue java.lang.Integer
	 */
	public String getID() 
	{
		return ( m_id == null ? "" : m_id );
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/12/2001 5:16:44 PM)
	 * @param nValue java.lang.Integer
	 */
	public Integer getIntegerID() 
	{
		Integer nResult = null;
		
		try
		{
		    nResult = new Integer( m_id );
		}
		catch( Exception e )
		{
		}
		    
		return nResult;
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/12/2001 5:16:44 PM)
	 * @param nValue java.lang.Integer
	 */
	public void setID(int nValue) 
	{
		m_id = String.valueOf( nValue );
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/12/2001 5:16:44 PM)
	 * @param nValue java.lang.Integer
	 */
	public void setID(Integer nValue) 
	{
		if( nValue == null )
		  m_id = "";
		else  
		  m_id = nValue.toString();
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/12/2001 5:16:44 PM)
	 * @param nValue java.lang.Integer
	 */
	public void setID(String nValue) 
	{
		m_id = ( nValue == null ? "" : nValue );
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/12/2001 6:56:17 PM)
	 * @param szValue java.lang.String
	 */
	public void setValue(String szValue) 
	{
		m_szValue = ( szValue == null ? "" : szValue );
	}
	
	/**
	 * toString method comment.
	 */
	public String toLowerCase() 
	{
		return toString().toLowerCase();
	}
	
	/**
	 * toString method comment.
	 */
	public String toUpperCase() 
	{
		return toString().toUpperCase();
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/22/2001 11:46:12 AM)
	 * @param szParam java.lang.String
	 */
	public void append(String szParam) 
	{
		if( szParam == null )
		  szParam = "";
		if( m_szValue == null )
		  m_szValue = szParam;
		else
		  m_szValue = m_szValue + szParam; 
	}
	
	/**
	 * toString method comment.
	 */
	public Integer toInteger() 
	{
		Integer cntrID = null;
		
		try
		{
			cntrID = new Integer( toString() );
		}
		catch( Exception e )
		{
			cntrID = null;
		}
		
		return cntrID;
	}
	
	/**
	 * toString method comment.
	 */
	public int compareAndSet( String szParam1, String szParam2 ) 
	{
		if( szParam1 == null )
		  return -1;
		  
		int nResult = toString().compareTo( szParam1 );
		if( nResult == 0 )
		  m_szValue = ( szParam2 == null ? "" : szParam2 );
	
		return nResult;
	}
	
		protected boolean m_isCFDATA = true;
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/22/2001 11:46:12 AM)
	 * @param szParam java.lang.String
	 */
	public void appendIf( boolean canAppend, String szParam ) 
	{
		if (canAppend)
			append( szParam );
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/6/2001 4:07:23 PM)
	 */
	public boolean endsWith( String szParam ) 
	{
		if( szParam == null )
		  return true;
		  
		if( isEmpty() )
		  return false;
	
		return toString().endsWith( szParam );  
	}
	
	/**
	 * Creation date: (3/23/2001 12:04:04 PM)
	 *
	 */
	public void setCFDATAMode(boolean boolParam) 
	{
		m_isCFDATA	 = boolParam;
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/6/2001 4:07:23 PM)
	 */
	public boolean startsWith( String szParam ) 
	{
		if( szParam == null )
		  return true;
		  
		if( isEmpty() )
		  return false;
	
		return toString().startsWith( szParam );  
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (4/3/2001 12:12:41 PM)
	 */
	public void trim() 
	{
		if( m_szValue == null )
			m_szValue = "";
		else	
			m_szValue = m_szValue.trim();
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/12/2001 6:56:17 PM)
	 * @param szValue java.lang.String
	 */
	public void cutFromEnd( int nParam )
	{
		if( nParam < 1 )
			return;
				
		int cutPos = toString().length() - nParam - 1;
		if( cutPos < 1 )
			m_szValue = "";
		else
			m_szValue = toString().substring( 0, cutPos );
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/12/2001 6:56:17 PM)
	 * @param szValue java.lang.String
	 */
	public void cutFromStart( int nParam )
	{
		if( nParam < 1 )
			return;
			
		if( toString().length() <= nParam )
		{
			m_szValue = "";
			return;
		}
	
		m_szValue = toString().substring( nParam );
	}
	
	/**
	 * method comment.
	 */
	public boolean addParam( String szParam ) 
	{
		if( szParam == null )
		  return false;
		  
		m_szReqParam += ' ' + szParam;
		return true;
	}
	
	/**
	 * Insert the method's description here.
	 * Creation date: (3/12/2001 5:16:44 PM)
	 * @param nValue java.lang.Integer
	 */
	public CFString replace( String szParam, String szReplacement ) 
	{
		if( szParam == null )
		  return this;
	
		if( szReplacement == null )
			szReplacement = "";
	
		String szValue = toString();
		int index = szValue.indexOf( szParam );
		while( index != -1 )
		{
			szValue = szValue.substring( 0, index ) + szReplacement + szValue.substring( index + szParam.length() );
			index += szReplacement.length();
			index = szValue.indexOf( szParam, index );
		}
		m_szValue = szValue;
		return this;
	}
	
	public Integer getMaxLength()
	{
		return m_nMaxLength;
	}
	
	public CFString setMaxLength(Integer maxLength)
	{
		m_nMaxLength = maxLength;
		return this;
	}
	
	@Override
	public boolean isValid()
	{
		boolean bValid = super.isValid();
		if (bValid)
		{
			Integer nMaxLength = getMaxLength();
			if (nMaxLength != null)
			{
				bValid = CStringUtils.nvl(m_szValue).length() <= nMaxLength;
			}
		}
		
		return bValid;
	}
}
