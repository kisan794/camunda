/*
 * @(#)$RCSfile: CFPhone.java,v $ $Revision: 1.13 $ $Date: 2012/05/21 08:01:57 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFPhone.java,v $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Nesterov		2001-04-03  American phone numbers formatting changed
 *   A.Nesterov		2001-09-12  added function "boolean isEmpty()"
 *   A.Solntsev		2004-01-26	American phone numbers are formatted with '-' instead of ' '.
 *   J.Zaporozets 2004-04-19	International Cisco and Global
 *   P.Bushuk		2005-05-02  Added m_strAreaCode initialization in CFPhone(String, short)
 *   P.Bushuk		2005-05-02  Added m_strAreaCode initialization in CFPhone(String, short)
 *   M.Suhhoruki	2010-03-09  Added equals
 *   M.Suhhoruki	2010-12-23  Added getFormattedPhoneNumber with ext. sign to note extension
 *   A.Putintsev	2012-04-05	Added m_strPhoneNumberAsIs to store a phone number formatted identically to its format in database
 */
package hireright.sdk.format_util;

import hireright.sdk.consts.Constants;
import hireright.sdk.util.Lang;

/**
 *
 * Class CFPhone provides formatting of phone data.
 *
 * @author  Alexander Nesterov
 * @version $Revision: 1.13 $ $Date: 2012/05/21 08:01:57 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFPhone.java,v $
 */
public class CFPhone extends CFDta implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.13 $ $Author: cvsroot $";
	
	private String m_strCountryPhoneCode;
	private String m_strAreaCode;
	private String m_strPhoneNumber;
	private String m_strPhoneNumberAsIs;
	private static final CXMLTag m_XMLTag = new CXMLTag("phone");
	private short m_nCountryCode;


	public CFPhone(String strCountryCode, String strAreaCode, String strPhoneNumber)
	{
		m_strCountryPhoneCode = strCountryCode;
		m_strAreaCode = strAreaCode;
		m_strPhoneNumber = strPhoneNumber;		
		m_nCountryCode = Constants.UNDEFINED;		
		m_strPhoneNumberAsIs = strPhoneNumber != null ? strPhoneNumber : "";

		if(m_strCountryPhoneCode == null)
			m_strCountryPhoneCode = "";

		if(m_strPhoneNumber == null)
			m_strPhoneNumber = "";
		
		if(m_strAreaCode == null)
		{
			m_strAreaCode = "";
			parsePhoneNumber(strPhoneNumber);
		}
	}


	public CFPhone(String strCountryCode, String strPhoneNumber)
	{
		m_strCountryPhoneCode = strCountryCode;
		m_strAreaCode = "";
		m_nCountryCode = Constants.UNDEFINED;
		m_strPhoneNumberAsIs = strPhoneNumber != null ? strPhoneNumber : "";

		if(m_strCountryPhoneCode == null)
			m_strCountryPhoneCode = "";

		parsePhoneNumber(strPhoneNumber);
	}


	public CFPhone(String strPhoneNumber)
	{
		m_nCountryCode = Constants.UNDEFINED;
		m_strCountryPhoneCode = "";
		m_strAreaCode = "";
		m_strPhoneNumberAsIs = strPhoneNumber != null ? strPhoneNumber : "";
		parsePhoneNumber(strPhoneNumber);
	}


	public CFPhone(String strCountryCode, String strAreaCode, String strPhoneNumber, short nCountryCode)
	{
		m_strCountryPhoneCode = strCountryCode;
		m_strAreaCode = strAreaCode;
		m_strPhoneNumber = strPhoneNumber;
		m_nCountryCode = nCountryCode;
		m_strPhoneNumberAsIs = strPhoneNumber != null ? strPhoneNumber : "";

		if(m_strPhoneNumber == null)
			m_strPhoneNumber = "";

		if(m_strCountryPhoneCode == null)		
			m_strCountryPhoneCode = "";

		if(m_strAreaCode == null)
		{
			m_strAreaCode = "";
			parsePhoneNumber(strPhoneNumber);
		}
	}


	public CFPhone(String strCountryCode, String strPhoneNumber, short nCountryCode)
	{
		m_strCountryPhoneCode = strCountryCode;
		m_nCountryCode = nCountryCode;
		m_strAreaCode = "";
		m_strPhoneNumber = "";
		m_strPhoneNumberAsIs = strPhoneNumber != null ? strPhoneNumber : "";

		if(m_strCountryPhoneCode == null)
			m_strCountryPhoneCode = "";

		parsePhoneNumber(strPhoneNumber);
	}


	public CFPhone(String strPhoneNumber, short nCountryCode)
	{
		m_nCountryCode = nCountryCode;
		m_strCountryPhoneCode = "";
		m_strAreaCode = "";
		m_strPhoneNumberAsIs = strPhoneNumber != null ? strPhoneNumber : "";
		parsePhoneNumber(strPhoneNumber);
	}

	/**
	 * Method returns string representation of phone number.
	 * For USA:  		(countryCcode) xxx-yyyy-zzzz
	 * For others:	countryCode-xxxyyyyzzzz
	 */
	public String toString()
	{
		return getFormattedPhoneNumber("-");
	}


	public short getCountryCode()
	{
		return m_nCountryCode;
	}


	public String getCountryPhoneCode()
	{
		return m_strCountryPhoneCode;
	}


	public String getAreaCode()
	{
		return m_strAreaCode;
	}


	public String getPhoneNumber()
	{
		return m_strPhoneNumber;
	}

	public String getFormattedPhoneNumber()
	{
		return getFormattedPhoneNumber(" ext.");
	}

	public final void parsePhoneNumber(String strPhoneNumber)//FIXME
	{
		m_strPhoneNumber = "";

		if(strPhoneNumber == null)
			return;

		strPhoneNumber = strPhoneNumber.trim();

		if(strPhoneNumber.length() <= 0)
			return;

		if(strPhoneNumber.length() < 5)
		{
			setValid(false);
			m_strPhoneNumber = strPhoneNumber;
			return;
		}

		StringBuffer temp = new StringBuffer();
		int charCount = strPhoneNumber.length();
		char character;
		int i;

		for(i = 0; i < charCount; i++)
		{
			character = strPhoneNumber.charAt(i);
			if(Character.isDigit(character))
				temp.append(character);
		}

		if(temp.length() <= 0)
			return;

		if(temp.length() < 5)
		{
			setValid(false);
			m_strPhoneNumber = strPhoneNumber;
			return;
		}

		if(m_nCountryCode == Constants.COUNTRY_USA)
		{
			int areaCodeStartFrom = temp.substring(0,1).equals("1") ? 1 : 0;
			int phoneNumberStartFrom = areaCodeStartFrom + 3;
			
			m_strAreaCode = temp.substring(areaCodeStartFrom, phoneNumberStartFrom);
			m_strPhoneNumber = temp.substring(phoneNumberStartFrom);
		}
		else
		{
			m_strAreaCode = "";
			m_strPhoneNumber = temp.substring(0);
		}
	}
	
	public String getPhoneNumberAsIs()
	{
		return m_strPhoneNumberAsIs;
	}

	protected CXMLTag getXMLTag()
	{
		return m_XMLTag;
	}


	public String toXML()
	{
		StringBuffer attrib = new StringBuffer();
		String value;

		if(m_strCountryPhoneCode.length() > 0)
		{
			switch(m_nCountryCode)
			{
			case Constants.COUNTRY_USA:
				attrib.append("ccode=\"\"");
				break;

			case Constants.UNDEFINED:
				attrib.append("ccode=\"\""); //Just debug feature, please remove if not needed.
				break;

			default:
				attrib.append("ccode=\"");
				attrib.append(m_strCountryPhoneCode);
				attrib.append('\"');
			}
		}

		if(isValid())
			value = toString();
		else
		{
			StringBuffer temp = new StringBuffer("<![CDATA[");
			temp.append(toString());
			temp.append("]]>");
			value = temp.toString();
			attrib.append(" valid=\"No\"");
		}

		return m_XMLTag.toXMLString(value, attrib.toString());
	}

	public boolean isCustomTollRateNumber()
	{
		if(m_strPhoneNumber.length() != 0 &&
			m_strPhoneNumber.charAt(0) == '9')//9xx series phones
		return true;

		return false;
	}

	public boolean isEmpty()
	{
		return m_strPhoneNumber == null || m_strPhoneNumber.length() == 0;
	}
	
	public boolean equals(Object obj)
	{
		if (this == obj)
		{
			return true;
		}
		
		CFPhone phone = (CFPhone) obj;
		if (isEmpty() && phone == null)
		{
			return true;
		}
		
		if (phone == null)
		{
			return false;
		}
		
		return Lang.equal(m_strCountryPhoneCode, phone.m_strCountryPhoneCode)
			&& Lang.equal(m_strAreaCode, phone.m_strAreaCode)
			&& Lang.equal(m_strPhoneNumber, phone.m_strPhoneNumber)
			&& Lang.equal(m_nCountryCode, phone.m_nCountryCode);
	}
	
	public int hashCode()
	{
		return Lang.hashCode(m_strCountryPhoneCode,
				m_strAreaCode,
				m_strPhoneNumber,
				m_nCountryCode
			);
	}
	
	/**
	 * Method returns string representation of phone number.
	 * For USA:  		(countryCcode) xxx-yyyy-zzzz
	 * For others:	countryCode-xxxyyyyzzzz
	 */
	private String getFormattedPhoneNumber(String sExtensionSign)
	{
		StringBuffer result = new StringBuffer();

		if(m_strAreaCode.length() > 0)
		{
			switch (m_nCountryCode)
			{
			case Constants.COUNTRY_USA:
				result.append('+');
				result.append(m_nCountryCode);
				result.append(' ');
				result.append('(');
				result.append(m_strAreaCode);
				result.append(')');
				result.append(' ');

				int n = m_strPhoneNumber.length();
				if(n > 3)
				{
					result.append(m_strPhoneNumber.substring(0, 3));
					result.append('-');
					if(n > 7)
					{
						result.append(m_strPhoneNumber.substring(3, 7));
						result.append(sExtensionSign);
						result.append(m_strPhoneNumber.substring(7));
					}
					else
						result.append(m_strPhoneNumber.substring(3));

				}

				break;

			default:
				result.append(m_strAreaCode);
				result.append('-');
				result.append(m_strPhoneNumber);
				break;
			}
		}
		else
		{
		  if(m_strPhoneNumber != null )
			result.append(m_strPhoneNumber);
		}

		return result.toString();
	}
}

