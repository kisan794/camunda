/*
 *
 * Copyright 2001-2018 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Ivanov			2018-11-30	HIVPE-59930 Created to mask date of birth partly or fully
 */
package hireright.sdk.format_util;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CStringUtils;

/**
 * Class to mask passed date of birth
 */
public class CFDateOfBirth extends CFDta
{
		public static final String DIVIDER_REGEXP = "\\s*[-./\\\\]\\s*";
		public static final String MONTH_REGEXP = "(0[1-9]|1[0-2])";
		public static final String DAY_REGEXP = "(0[1-9]|[1-2][0-9]|3[0-1])";
		public static final String YEAR_REGEXP = "((19\\d{2})|(20\\d{2}))";
		public static final String DATE_OF_BIRTH_DEFAULT_REGEXP
				= "\\s*" + MONTH_REGEXP + DIVIDER_REGEXP + DAY_REGEXP
				+ DIVIDER_REGEXP + YEAR_REGEXP + "\\s*";
		private static final CXMLTag m_XMLTag = new CXMLTag("dob");
		private final String m_sDateOfBirth;
		private final String m_sValidationRegExp = DATE_OF_BIRTH_DEFAULT_REGEXP;

		public CFDateOfBirth(String sDateOfBirth)
		{
				m_sDateOfBirth = sDateOfBirth == null ? "" : sDateOfBirth;
				validateDob();
		}

		private void validateDob()
		{
				try
				{
						setValid(!CStringUtils.isEmpty(m_sDateOfBirth)
								&& m_sDateOfBirth.matches(m_sValidationRegExp));
				}
				catch(Exception e)
				{
						CTraceLog.error(e, this.getClass().getName() + ".validateDob()",
								"Can't validate dob: " + m_sDateOfBirth);
				}
		}

		public String getMaskedYearDob()
		{
				try
				{
						return m_sDateOfBirth.replaceAll(YEAR_REGEXP, "****");
				}
				catch(Exception e)
				{
						CTraceLog.error(e, this.getClass().getName() + ".getMaskedYearDob()",
								"Can't mask year for: " + m_sDateOfBirth);
						return m_sDateOfBirth;
				}
		}

		public String getFullyMaskedDob()
		{
				try
				{
						return m_sDateOfBirth.replaceAll("\\d", "*");
				}
				catch(Exception e)
				{
						CTraceLog.error(e, this.getClass().getName() + ".getFullyMaskedDob()",
								"Can't mask dob for: " + m_sDateOfBirth);
						return m_sDateOfBirth;
				}
		}

		@Override
		protected CXMLTag getXMLTag()
		{
				return m_XMLTag;
		}

		@Override
		public String toString()
		{
				return m_sDateOfBirth;
		}

		@Override
		public boolean isEmpty() throws Exception
		{
				return m_sDateOfBirth.isEmpty();
		}
}
