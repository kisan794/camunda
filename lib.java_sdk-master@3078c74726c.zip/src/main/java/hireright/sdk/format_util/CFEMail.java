/*
 * @(#)$RCSfile: CFEMail.java,v $ $Revision: 1.9 $ $Date: 2010/08/19 20:26:30 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFEMail.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * A.Rudenko		2001-06-20	created
 * A.Solntsev		2007-09-25	Added static method checkEmailSyntax() which uses regexp validation
 * A.Solovyev		2008-12-05	Changed regular expression for email: apostroph supporting added.
 * A.Solovyev		2008-12-09	Changed method parseEMail(). Now it is using checkEmailSyntax().
 * A.Nikonov		2017-09-06	Update EMAIL_REGEXP for email without symbol "_"
 * 
 */
package hireright.sdk.format_util;

/**
 * Class CEMail provides formatting of e-mail address string
 *
 * @author Alexander Nesterov
 * @author asolntsev
 * @version $Revision: 1.9 $ $Date: 2010/08/19 20:26:30 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFEMail.java,v $
 */
public class CFEMail extends CFDta implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	public static final String EMAIL_REGEXP = "^(?=.{5,254}$)[\\w!#$%&*+\'/=?^_`{|}~-]+(\\.[\\w!#$%&*+\'/=?^_`{|}~-]+)*@([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\\.)+[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$";

	private static final CXMLTag m_XMLTag = new CXMLTag("e-mail");

	private final String m_strEMail;

	public CFEMail(String strEMail)
	{
		if (strEMail == null)
			m_strEMail = "";
		else
			m_strEMail = strEMail.trim();

		parseEMail();
	}

	public String toString()
	{
		return m_strEMail;
	}

	private void parseEMail()
	{
		try
		{
			CFEMail.checkEmailSyntax(m_strEMail);
			setValid(true);
		} catch (CInvalidEmailException e)
		{
			setValid(false);
		}
	}

	protected CXMLTag getXMLTag()
	{
		return m_XMLTag;
	}

	public static void checkEmailSyntax(final String sEmail) throws CInvalidEmailException
	{
		if (sEmail == null || sEmail.trim().length() == 0)
		{
			throw new CInvalidEmailException(sEmail, 0, "Email is null or empty");
		}

		if (!sEmail.matches(EMAIL_REGEXP))
		{
			throw new CInvalidEmailException(sEmail, 0, "Email doesn't match regexp");
		}
	}
}

