/*
 * @(#)$RCSfile: CFDta.java,v $ $Revision: 1.7 $ $Date: 2009/02/20 10:26:01 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFDta.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * A.Nesterov		2001-09-12	added "public abstract String isEmpty();"
 * A.Solntsev		2007-09-25	Removed unused static member "m_bIsGlobalValid"
 */
package hireright.sdk.format_util;

/**
 * Common interface for formatted string data output
 *
 * @author Alexander Nesterov
 * @since Oct 23, 2007
 * @version $Revision: 1.7 $ $Date: 2009/02/20 10:26:01 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/format_util/CFDta.java,v $
 */
public abstract class CFDta implements java.io.Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
		private boolean m_bIsValid = true;
		protected abstract CXMLTag getXMLTag();

		public abstract String toString();        //returns data in default format

		public boolean isEmpty() throws Exception//This function must be abstract but to fix fast we'll make default impementation
		{
			throw new Exception("I'am empty!!! Please implement me in derived class");
		}

		public boolean isValid()
		{
				return m_bIsValid;
		}

		public final void setValid(boolean bIsValid)
		{
				m_bIsValid = bIsValid;
		}

		public String toXML()
		{
						StringBuffer value = new StringBuffer("<![CDATA[");
						value.append(toString());
						value.append("]]>");

				return isValid() ? getXMLTag().toXMLString(value.toString()) :
														getXMLTag().toXMLString(value.toString(), "valid=\"No\"");
		}

		public static final String xmlOut(CFDta object)
		{
				return object == null ? "" : object.toXML();
		}

		public final String toCDATAString()
		{
			return "<![CDATA[" + toString() + "]]>";
		}

	public static String toString(String strValue) //Just checks string for null
	{
		return (strValue == null ? "" : strValue);
	}

	public static String toCDATAString(String strValue) //Adds <![CDATA[]]> and checks for null
	{
		return (strValue == null ? "" : "<![CDATA[" + strValue + "]]>");
	}


}