/*
 * @(#)$RCSfile: AbstractContextListener.java,v $ $Revision: 1.4 $ $Date: 2010/03/11 21:42:38 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/jmx/AbstractContextListener.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev			2008-10-01	created
 *	A.Solntsev			2008-11-14	Use commons-logging instead of System.err.println
 *	A.Solntsev			2010-03-05	Use log4j instead of commons-logging.
 */
package hireright.sdk.jmx;

import java.util.ArrayList;
import java.util.List;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.4 $ $Date: 2010/03/11 21:42:38 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/jmx/AbstractContextListener.java,v $
 */
public abstract class AbstractContextListener implements ServletContextListener
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	private String contextName;
	private MBeanServer server;
	private final List<ObjectName> registeredBeans = new ArrayList<ObjectName>(2);
	
	private static final Logger log = Logger.getLogger(AbstractContextListener.class);
	
	protected final ObjectName addBean(String sType, String sName, Object mbean)
	{
		String sObjectName = "hireright:ContainerName="+contextName +",Type="+sType+",Name="+sName;
		try
		{
			ObjectName name = new ObjectName(sObjectName);
			
			server.registerMBean(mbean, name);
			registeredBeans.add(name);
			return name;
		}
		catch (Throwable e)
		{
			log.error("Failed to register bean " + sObjectName + ": ", e);
			return null;
		} 
	}
	
	public void setContextName(String contextName)
	{
		this.contextName = contextName;
	}
	
	public String getContextName()
	{
		return this.contextName;
	}
	
	@SuppressWarnings("unchecked")
	public void contextInitialized(ServletContextEvent event) 
	{
		contextName = event.getServletContext().getServletContextName();
		List<MBeanServer> servers = MBeanServerFactory.findMBeanServer(null);
		server = servers.get(0);
	}
	
	public final void contextDestroyed(ServletContextEvent event) 
	{
		if (server != null)
		{
			for (ObjectName name : registeredBeans)
			{
				try {
					server.unregisterMBean(name);
				} catch (InstanceNotFoundException e) {
				} catch (MBeanRegistrationException e) {
				}
			}
		}
	}
}
