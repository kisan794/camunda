/*
 * @(#)$RCSfile: GeneralSettingsContextListener.java,v $ $Revision: 1.3 $ $Date: 2008/10/14 09:11:29 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/jmx/GeneralSettingsContextListener.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev			2008-10-01	created
 */
package hireright.sdk.jmx;

import hireright.sdk.debug.CLogsSettingsMBean;
import hireright.settings.GeneralSettingsMBean;

import javax.servlet.ServletContextEvent;

// import net.sf.ehcache.CacheManager;
// import net.sf.ehcache.management.ManagementService;

// import org.hibernate.jmx.StatisticsService;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.3 $ $Date: 2008/10/14 09:11:29 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/jmx/GeneralSettingsContextListener.java,v $
 */
public class GeneralSettingsContextListener extends AbstractContextListener
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
		
	public GeneralSettingsContextListener()
	{
	}
	
	@Override
	public void contextInitialized(ServletContextEvent event) 
	{
		super.contextInitialized(event);
		
		addBean("settings", "GeneralSettings", new GeneralSettingsMBean());
		addBean("settings", "LogSettings", new CLogsSettingsMBean());
		/*
		try
		{
			if (CClass.getCodeSource("org.hibernate.jmx.StatisticsService") != null)
			{
				org.hibernate.jmx.StatisticsService hibStatBean = new org.hibernate.jmx.StatisticsService(); 
				hibStatBean.setStatisticsEnabled(true);
				
				Connection conn = CConnection.initThreadLocalConnection();
				try
				{
					hibStatBean.setSessionFactory(CSessionFactory.getSessionFactory());
					addBean("Hibernate", "StatisticsService", hibStatBean);
				}
				finally
				{
					CCurrentThreadConnection.unbind();
					CConnection.closeConnection(conn);
				}
			}
		}
		catch (Throwable e)
		{
			System.err.println("Failed to register Hibernate StatisticsService");
			// e.printStackTrace();
		}
		
		try
		{
			net.sf.ehcache.CacheManager cacheManager = net.sf.ehcache.CacheManager.create();
			boolean registerCacheManager = true;
			boolean registerCaches = true;
			boolean registerCacheConfigurations = true;
			boolean registerCacheStatistics = true;
			net.sf.ehcache.management.ManagementService.registerMBeans(cacheManager, server, 
					registerCacheManager, registerCaches,
					registerCacheConfigurations, registerCacheStatistics);
		}
		catch (Throwable e)
		{
			System.err.println("Failed to register EHCache MBean");
			// e.printStackTrace();
		}
		*/
	}
}
