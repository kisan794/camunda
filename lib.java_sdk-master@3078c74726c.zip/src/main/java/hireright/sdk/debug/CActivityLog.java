/*
 * @(#)$RCSfile: CActivityLog.java,v $ $Revision: 1.15 $ $Date: 2012/08/24 07:25:52 $  $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CActivityLog.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	A.Keks			2002-xx-xx	created
 *  A.Solntsev		2006-02-08	File logging enhancement. 
 *  A.Solntsev		2006-03-06	Now all methods addLog() return long - log ID.
 *  A.Solntsev		2006-05-07	Class CLogsSettings is now used.
 *  A.Solntsev		2008-04-15	Fixed CActivityLog: truncate too long strings.
 *  A.Solntsev		2008-05-09	Added current thread parameters
 *  A.Solntsev		2008-11-14	Use ThreadSafeDateFormat instead of SimpleDateFormat
 *  A.Solntsev		2010-01-18	Added posting logs to HTTP receiver in addition to logging to DB
 *	A.Solntsev		2010-01-26	Use tracelog for error logging (instead of writing to local file)
 *	A.Solntsev		2010-01-26	If posting failed, store unsent log to table LOG_QUEUE 
 *	A.Knyazev			2012-06-13	Changed: migrated to Logging API.
 *	A.Knyazev			2012-08-10	Changed: Added EPAM logging environment support.
 *	A.Knyazev			2012-08-13	Changed: logging properties file path: java_sdk/java_sdk.properties ->
 *														logging/logging.properties.
 *	A.Knyazev			2012-08-13	Changed: mechanism based on classpath:logging/logging.properties file
 *														was replaced with environment variable "LOGGING_ENVIRONMENT" with the
 *														only permissible value "DB_FALLBACK".
 *	P.Vammus		2016-06-16 HIVPE-648: addLog() overloaded for compliance logging.
 *	A.Gavrilkov	2023-04-28 HRG-259870: addLog() overloaded for ability to log without text size restrictions
 */
package hireright.sdk.debug;

import hireright.lib.logging.activity.model.impl.ActivityLog;
import hireright.lib.logging.activity.model.logger.ActivityLogger;
import hireright.lib.logging.activity.model.logger.util.ActivityLoggerUtils;
import hireright.lib.logging.util.settings.LoggingSettings;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

import org.apache.commons.lang.StringUtils;

/**
 * The CActivityLog allows to write activity logs into database.
 * 
 * @author Anton Keks
 * @version $Revision: 1.15 $ $Date: 2012/08/24 07:25:52 $  $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CActivityLog.java,v $
 */
public class CActivityLog
{

	protected static final String CLASS_VERSION = "$Revision: 1.15 $ $Author: cvsroot $";

	private static volatile ActivityLogger ACTIVITY_LOGGER;

	private static final int OBJECT_CLASS_MAX_LENGTH = 20;
	private static final int OBJECT_ID_MAX_LENGTH = 64;
	private static final int ACTIVITY_NAME_MAX_LENGTH = 100;
	private static final int PARAMETERS_MAX_LENGTH = 4000;
	private static final int TEXT_MAX_LENGTH = 128000; // Too much?!
	private static final int CLIENT_IP_MAX_LENGTH = 15; // NB! No support for IPv6 while old CTS table still in use.
	private static final int OLD_VALUES_MAX_LENGTH = 4000;
	private static final int NEW_VALUES_MAX_LENGTH = 4000;

	/**
	 * This ThreadLocal variable holds any parameters.
	 * They will be used for writing any TraceLog in current thread.
	 *
	 * @see #addCurrentThreadParameters(CProperties)
	 * @see #eraseCurrentThreadParameters()
	 */
	private static final ThreadLocal<CProperties> CURRENT_THREAD_PARAMETERS = new ThreadLocal<CProperties>();

	/**
	 * Since all methods are static constructor made protected
	 */
	protected CActivityLog()
	{
		super();
	}

	/**
	 * Every program can put here any parameters using method addParameters().
	 * They will be used in case of any errors occurred in current thread.
	 *
	 * If no exceptions occur in current thread, these properties will be loosed.
	 *
	 * @param parameters any CProperties
	 * @since java_sdk_v2-6-9
	 */
	public static void addCurrentThreadParameters(final CProperties parameters)
	{
		CProperties params = CURRENT_THREAD_PARAMETERS.get();
		if (params == null)
		{
			params = new CProperties();
			CURRENT_THREAD_PARAMETERS.set(params);
		}

		params.setProperties(parameters);
	}

	/**
	 * Remove all properties being stored in the current thread.
	 * Usually it's called before Thread should be stopped or reused.
	 * @since java_sdk_v2-6-11
	 */
	public static void eraseCurrentThreadParameters()
	{
		final CProperties params = CURRENT_THREAD_PARAMETERS.get();
		if (params != null)
		{
			params.clear();
			CURRENT_THREAD_PARAMETERS.set(null);
		}
	}

	public static final long addLog(final String objectClass, final String objectId,
			final String toObjectClass, final String toObjectId, final String activityName,
			final String text, final CProperties params)
	{
		return addLog(objectClass, objectId, toObjectClass, toObjectId, activityName, text, params,
				(String) null, (String) null, (String) null);
	}

	/**
	 * Adds activity into log
	 *
	 * @param objectClass Object's class name, which performs the activity
	 * @param objectId Object's ID, which performs the activity
	 * @param toObjectClass Object's class, which is the victim of the activity
	 * @param toObjectId Object's ID, which is the victim of the activity
	 * @param activityName Activity name
	 * @param params Parameters of an activity
	 */
	public static final long addLog(final String objectClass, final String objectId,
			final String toObjectClass, final String toObjectId, final String activityName,
			final CProperties params)
	{
		return addLog(objectClass, objectId, toObjectClass, toObjectId, activityName, (String) null,
				params);
	}

	/**
	 * Adds activity into log
	 *
	 * @param objectClass Object's class name, which performs the activity
	 * @param objectId Object's ID, which performs the activity
	 * @param activityName Activity name
	 * @param params Parameters of an activity
	 */
	public static final long addLog(final String objectClass, final String objectId,
			final String activityName, final CProperties params)
	{
		return addLog(objectClass, objectId, (String) null, (String) null, activityName, (String) null,
				params);
	}

	/**
	 * Adds activity into log
	 *
	 * @param objectClass Object's class name, which performs the activity
	 * @param objectId Object's ID, which performs the activity
	 * @param activityName Activity name
	 * @param text
	 * @param params Parameters of an activity
	 */
	public static final long addLog(final String objectClass, final String objectId,
			final String activityName, final String text, final CProperties params)
	{
		return addLog(objectClass, objectId, (String) null, (String) null, activityName, text, params);
	}

	/**
	 * Logs activity.
	 *
	 * @param objectClass Object's class name, which performs the activity
	 * @param objectId Object's ID, which performs the activity
	 * @param toObjectClass Object's class, which is the victim of the activity
	 * @param toObjectId Object's ID, which is the victim of the activity
	 * @param activityName Activity name
	 * @param text Text about the activity (saved into CLOB)
	 * @param params Parameters of an activity
	 * @param clientIp
	 * @param oldValues
	 * @param newValues
	 */
	public static final long addLog(final String objectClass, final String objectId,
			final String toObjectClass, final String toObjectId, final String activityName,
			final String text, final CProperties params, final String clientIp, final String oldValues,
			final String newValues)
	{
		return addLog(objectClass, objectId, toObjectClass, toObjectId, activityName, text, params,
				clientIp, oldValues, newValues, true);
	}
	
	/**
	 * Logs activity.
	 *
	 * @param objectClass Object's class name, which performs the activity
	 * @param objectId Object's ID, which performs the activity
	 * @param toObjectClass Object's class, which is the victim of the activity
	 * @param toObjectId Object's ID, which is the victim of the activity
	 * @param activityName Activity name
	 * @param text Text about the activity (saved into CLOB)
	 * @param params Parameters of an activity
	 * @param clientIp
	 * @param oldValues
	 * @param newValues
	 * @param abbreviateText True value limits max text size to 128KB; False = no limit 
	 */
	public static final long addLog(final String objectClass, final String objectId,
			final String toObjectClass, final String toObjectId, final String activityName,
			final String text, final CProperties params, final String clientIp, final String oldValues,
			final String newValues, boolean abbreviateText)
	{
		final ActivityLog log = new ActivityLog(abbreviate(StringUtils.isEmpty(activityName) ? "n/a"
				: activityName, ACTIVITY_NAME_MAX_LENGTH));
		//
		log.setObjectClass(abbreviate(objectClass, OBJECT_CLASS_MAX_LENGTH));
		log.setObjectId(abbreviate(objectId, OBJECT_ID_MAX_LENGTH));
		log.setToObjectClass(abbreviate(toObjectClass, OBJECT_CLASS_MAX_LENGTH));
		log.setToObjectId(abbreviate(toObjectId, OBJECT_ID_MAX_LENGTH));
		log.setMessage(abbreviateText ? abbreviate(text, TEXT_MAX_LENGTH) : text);
		log.setParameters(abbreviate(toLoggableParameters(params), PARAMETERS_MAX_LENGTH));
		log.setClientIp(abbreviate(getClientIp(clientIp, params), CLIENT_IP_MAX_LENGTH));
		log.setOldValues(abbreviate(oldValues, OLD_VALUES_MAX_LENGTH));
		log.setNewValues(abbreviate(newValues, NEW_VALUES_MAX_LENGTH));
		//
		getActivityLogger().log(log);
		//
		return log.getId();
	}
	
	/**
	 * Adds activity into log
	 *
	 * @param objectClass Object's class name, which performs the activity
	 * @param objectId Object's ID, which performs the activity
	 * @param toObjectClass Object's class, which is the victim of the activity
	 * @param toObjectId Object's ID, which is the victim of the activity
	 * @param activityName Activity name
	 * @param oldValues
	 * @param newValues
	 */
	public static final long addLog(final String objectClass, final String objectId, final String toObjectClass,
			final String toObjectId, final String activityName, final String oldValues, final String newValues)
	{
		return addLog(objectClass, objectId, toObjectClass, toObjectId, activityName, (String) null, (CProperties) null, (String) null, oldValues, newValues);
	}
	
	/**
	 * Adds activity into log
	 *
	 * @param objectClass Object's class name, which performs the activity
	 * @param objectId Object's ID, which performs the activity
	 * @param toObjectClass Object's class, which is the victim of the activity
	 * @param toObjectId Object's ID, which is the victim of the activity
	 * @param activityName Activity name
	 * @param params Parameters of an activity
	 * @param oldValues
	 * @param newValues
	 */
	public static final long addLog(final String objectClass, final String objectId, final String toObjectClass,
			final String toObjectId, final String activityName, final CProperties params, final String oldValues, final String newValues)
	{
		return addLog(objectClass, objectId, toObjectClass, toObjectId, activityName, (String) null, params, (String) null, oldValues, newValues);
	}

	private static String toLoggableParameters(final CProperties params)
	{
		CProperties currentThreadParameters = CURRENT_THREAD_PARAMETERS.get();
		if (currentThreadParameters == null)
		{
			return CStringUtils.toString(params);
		}

		final CProperties paramsToLog = new CProperties(params);
		paramsToLog.setProperties(currentThreadParameters);
		return paramsToLog.toString();
	}

	private static String getClientIp(final String clientIp, final CProperties params)
	{
		return (clientIp == null) ? CProperties.getProperty(params, "clientIP") : clientIp;
	}

	private static ActivityLogger getActivityLogger()
	{
		if (CActivityLog.ACTIVITY_LOGGER == null)
		{
			synchronized (CActivityLog.class) // While activity logger is a static. 
			{
				if (CActivityLog.ACTIVITY_LOGGER == null)
				{
					final String loggerName = CActivityLog.class.getName() + "_activityLogger";
					ActivityLogger activityLogger = null;
					//
					if ("DB_FALLBACK".equalsIgnoreCase(System.getenv("LOGGING_ENVIRONMENT")))
					{
						// NB! For EPAM limited environment we could use custom ActivityLogger (with SQL
						// appender instead of posting GLX-messages to Log Receiver Servlet).
						activityLogger = ActivityLoggerUtils.newLimitedEnvironmentActivityLogger(loggerName,
								"java:comp/env/jdbc/HireRightJDS");
					}
					else
					{
						// For complete HireRight environment with use our default logger (with GLX-messages posting appender).
						activityLogger = ActivityLoggerUtils.newActivityLogger(loggerName,
								new LoggingSettings().getInitialGlxHttpAppenderPostingUrl());
					}
					//
					CActivityLog.ACTIVITY_LOGGER = activityLogger;
				}
			}
		}
		//
		return CActivityLog.ACTIVITY_LOGGER;
	}

	private static String abbreviate(final String s, final int maxLength)
	{
		if (maxLength < 0)
		{
			throw new IllegalArgumentException("Invalid max length. Zero or positive value is expected.");
		}
		//
		return s == null ? null : s.substring(0, Math.min(s.length(), maxLength));
	}

	/*
	private static LoggingEnvironment getLoggingEnvironment()
	{
		LoggingEnvironment result = null;
		//
		final InputStream is = CActivityLog.class.getClassLoader().getResourceAsStream(
				"logging/logging.properties");
		if (is != null)
		{
			try
			{
				final Properties props = new Properties();
				props.load(is);
				if (!props.isEmpty())
				{
					final String loggingEnvironmentCode = props.getProperty("loggingEnvironment");
					result = LoggingEnvironment.fromCode(loggingEnvironmentCode);
				}
			}
			catch (final IOException ioe)
			{
				// Ignoring.
				// FIXME: Log error?
			}
			finally
			{
				IOUtils.closeSilently(is);
			}
		}
		//
		return result == null ? LoggingEnvironment.COMPLETE : result;
	}
	*/

	/* *
	 * @author Artur Knyazev
	 * @version $Revision: 1.15 $ $Date: 2012/08/24 07:25:52 $  $Author: cvsroot $
	 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CActivityLog.java,v $
	 */
	/*
	private static enum LoggingEnvironment
	{

		COMPLETE("COMPLETE"), // For HireRight.
		LIMITED("LIMITED"); // For EPAM.

		@SuppressWarnings("unused")
		protected static final String CLASS_VERSION = "$Revision: 1.15 $ $Author: cvsroot $";

		private static final Map<String, LoggingEnvironment> CODE_2_LOGGING_ENVIRONMENT_MAP;

		static
		{
			CODE_2_LOGGING_ENVIRONMENT_MAP = new HashMap<String, LoggingEnvironment>(3);
			//
			for (final LoggingEnvironment le : LoggingEnvironment.values())
			{
				final String code = le.getCode();
				//
				ValidationUtils.isTrue(!CODE_2_LOGGING_ENVIRONMENT_MAP.containsKey(code),
						"Duplicate logging environment codes are prohibited: '" + code + "'.");
				//
				CODE_2_LOGGING_ENVIRONMENT_MAP.put(code, le);
			}
		}

		private final String code;

		private LoggingEnvironment(final String code)
		{
			this.code = code;
		}

		public String getCode()
		{
			return this.code;
		}

		public static LoggingEnvironment fromCode(final String code)
		{
			return CODE_2_LOGGING_ENVIRONMENT_MAP.get(code);
		}

	}
	*/

}
