/*
 * @(#)$RCSfile: CLogsSettingsMBean.java,v $ $Revision: 1.4 $ $Date: 2009/09/11 13:47:38 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CLogsSettingsMBean.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev			2008-10-02	created
 */
package hireright.sdk.debug;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.4 $ $Date: 2009/09/11 13:47:38 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CLogsSettingsMBean.java,v $
 */
public class CLogsSettingsMBean implements CLogsSettingsMBeanMBean
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	public CLogsSettingsMBean()
	{
	}
	
	public void setLogSetting(String name, String value)
	{
		CLogsSettings.getInstance().setCustomSetting(name, value);
	}
	
	public String getLogTraceLevel()
	{
		return CLogsSettings.getInstance().getLogLevelAsString();
	}
	
	public void setLogTraceLevel(String sLevel)
	{
		CLogsSettings.getInstance().setLogTraceLevel(sLevel);
	}
	
	public String getLogFilePath()
	{
		return CLogsSettings.getInstance().getLogFilePath();
	}
	
	public void setLogFilePath(String sLogsPath)
	{
		CLogsSettings.getInstance().setLogFilePath(sLogsPath);
	}
}
