/*
 * @(#)$RCSfile: CLogsSettings.java,v $ $Revision: 1.11 $ $Date: 2010/02/04 21:16:35 $  $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CLogsSettings.java,v $
 *
 * Copyright 2005-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2005-04-01	A.Solntsev	Several methods moved here from GeneralSettings.
 *  2005-07-29	S.Vasilyev	m_nTraceLevel variable removed - it is defined in super class
 *  2005-08-03	A.Solntsev	m_nLogLevel variable restored (removed in parent class).
 *  2005-09-28	D.Belorunov	readTraceLogLevel() updated - LOGS scheme prefix was removed
 *	2006-05-07	A.Solntsev	Renamed to CLogsSettings
 *	2006-05-18	A.Solntsev	Support for custom logs settings
 *	2006-07-11	A.Solntsev	Added method reloadSettings()
 *	2006-08-03	A.Solntsev	Load the entire table LOG_SETTINGS without calling Pl/Sql
 *	2007-09-21	A.Solntsev	Now using method CJVMConnection.getNonTrackingConnection()
 *	2008-08-27	A.Solntsev	using generics
 *	2008-10-01	A.Solntsev	Enabling JMX: created class CLogsSettingsMBean\
 *	2009-08-28	A.Solntsev	m_customLogsSettings is now ThreadLocal (safe running of unit-tests inside container)
 *	2010-01-26	A.Solntsev	Custom settings are deprecated now
 */
package hireright.sdk.debug;
import hireright.sdk.db.CConnection;
import hireright.sdk.db.CJVMConnection;
import hireright.settings.GeneralSettings;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

/**
 * Settings for TraceLog, ActivityLog, FileLog
 *
 * @author Andrei Solntsev
 * @since java_sdk_v2-5-22, 2005-04-01
 * @version $Revision: 1.11 $ $Date: 2010/02/04 21:16:35 $  $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CLogsSettings.java,v $
 */
public class CLogsSettings implements Serializable, Observer
{
	protected static final String CLASS_VERSION = "$Revision: 1.11 $ $Author: cvsroot $";
	
	public static final String SETTING_NAME_LOGS_PATH = "LOGS_PATH";

	// Parameters' names in table LOGS.LOG_SETTINGS
	public static final String LOG_TRACE_NAME   = "LOG_TRACE";
	public static final String TRACE_LEVEL_PAR	= "TRACE_LEVEL";

	/**
	 * Available log levels
	 */
	public static final String[] TRACE_LEVEL	=
	{
		"DEBUG",		// level = 0
		"INFO",			// level = 1
		"WARNING",		// level = 2
		"ERROR",		// level = 3
		"FATAL"			// level = 4
	};

	// default log level
	public static final int DEFAULT_TRACE_LEVEL = 1;	// INFO

	/**
	 * Class members
	 */
	protected int m_nLogLevel;
	
	protected String m_sLogsPath;

	/**
	 * Singletone. Class is loaded only once.
	 */
	private static CLogsSettings INSTANCE = null;

	/**
	 * Content of table LOGS.LOG_SETTINGS
	 */
	private Map<String, String> m_logsSettings;

	/**
	 * @since java_sdk_v2-6-9
	 * @deprecated It was created only for local development. Now it's not recommended to use.
	 */
	@Deprecated
	private static final ThreadLocal<Map<String, String>> m_customLogsSettings = 
		new ThreadLocal<Map<String,String>>();


	static CLogsSettings getInstance()
	{
		if (INSTANCE == null)
		{
			synchronized (CLogsSettings.class)
			{
				if (INSTANCE == null)
				{
					INSTANCE = new CLogsSettings();
					GeneralSettings.registerObserver(INSTANCE);
				}
			}
		}
		return INSTANCE;
	}

	/**
	 * @deprecated It was created only for local development. Now it's not recommended to use.
	 * @param customLogsSettings
	 */
	@Deprecated
	public static void setCustomLogsSettings(Map<String, String> customLogsSettings)
	{
		getInstance().setCustomSettings(customLogsSettings);
	}
	
	/**
	 * @deprecated It was created only for local development. Now it's not recommended to use.
	 */
	@Deprecated
	public static <K, V> void setCustomLogsProperties(Map<K, V> customLogsProperties)
	{
		Map<String, String> customLogsSettings = new HashMap<String, String>( customLogsProperties.size() );
		for (Map.Entry<K, V> entry : customLogsProperties.entrySet())
		{
			customLogsSettings.put( String.valueOf(entry.getKey()), String.valueOf(entry.getValue()) );
		}
		
		getInstance().setCustomSettings(customLogsSettings);
	}
	
	@Deprecated
	public static void resetCustomLogsProperties()
	{
		getInstance().resetCustomSettings();
	}

	/**
	 * Override settings given in table LOGS_SETTINGS
	 *
	 * @since java_sdk_v2-6-9
	 * @param customLogsSettings any CProperties, usually read from web.xml during local development
	 * @deprecated It was created only for local development. Now it's not recommended to use.
	 */
	@Deprecated
	private void setCustomSettings(Map<String, String> customLogsSettings)
	{
		if (m_customLogsSettings.get() == null)
			m_customLogsSettings.set( new HashMap<String, String>() );

		m_customLogsSettings.get().putAll(customLogsSettings);
		// m_nLogLevel = getTraceLogLevel();
		// m_sLogsPath = readLogsPath();
	}
	
	@Deprecated
	void setCustomSetting(String name, String value)
	{
		if (m_customLogsSettings.get() == null)
			m_customLogsSettings.set( new HashMap<String, String>() );
		
		m_customLogsSettings.get().put(name, value);
		// m_nLogLevel = getTraceLogLevel();
		// m_sLogsPath = readLogsPath();
	}
	
	@Deprecated
	void resetCustomSettings()
	{
		if (m_customLogsSettings.get() != null)
			m_customLogsSettings.get().clear();
		
		m_customLogsSettings.set( null );
		// m_nLogLevel = getTraceLogLevel();
		// m_sLogsPath = readLogsPath();
	}
	
	String getLogLevelAsString()
	{
		if (getLogTraceLevel()<0 || getLogTraceLevel()>= TRACE_LEVEL.length)
			return "Unknown: " + getInstance().getLogTraceLevel();

		return TRACE_LEVEL[getLogTraceLevel()];
	}
	
	void setLogTraceLevel(String sLevel)
	{
		setCustomSetting(TRACE_LEVEL_PAR, sLevel);
		m_nLogLevel = parseLogLevel(sLevel);
	}

	/**
	 * Static method returns log level.
	 *
	 * @return Log level: 0=DEBUG, 1=INFO, 2=WARNING, 3=ERROR, 4=FATAL
	 * 			Default value = 1 (INFO).
	 */
	public static int getTraceLevel()
	{
		return getInstance().getLogTraceLevel();
	}

	public static String getLogLevel()
	{
		return getInstance().getLogLevelAsString();
	}
	
	int getLogTraceLevel()
	{
		if (m_customLogsSettings.get() != null && m_customLogsSettings.get().containsKey(TRACE_LEVEL_PAR) )
			return parseLogLevel( m_customLogsSettings.get().get(TRACE_LEVEL_PAR) );
		
		return m_nLogLevel;
	}
	

	String getLogFilePath()
	{
		if (m_customLogsSettings.get() != null)
			return m_customLogsSettings.get().get(SETTING_NAME_LOGS_PATH);
		
		return m_sLogsPath;
	}
	
	void setLogFilePath(String sLogsPath)
	{
		setCustomSetting(SETTING_NAME_LOGS_PATH, sLogsPath);
		m_sLogsPath = sLogsPath;
	}
	
	public static String getLogsPath()
	{
		return getInstance().getLogFilePath();
	}

	/**
	 * Constructor
	 */
	protected CLogsSettings()
	{
		m_logsSettings = readLogSettings();
		m_nLogLevel = readTraceLogLevel();
		m_sLogsPath = readLogsPath();
	}

	public void update(Observable o, Object arg)
	{
		reload();
	}

	private void reload()
	{
		m_logsSettings = readLogSettings();
		m_nLogLevel = readTraceLogLevel();
		m_sLogsPath = readLogsPath();
	}

	public static void reloadSettings()
	{
		getInstance().reload();
	}

	private final String readLogsPath()
	{
		String sLogsPath = null; // System.getProperty(SETTING_NAME_LOGS_PATH);
		// if (sLogsPath == null && m_customLogsSettings.get() != null)
		// 	sLogsPath = m_customLogsSettings.get().get(SETTING_NAME_LOGS_PATH);
		if (sLogsPath == null)
			sLogsPath = GeneralSettings.loadProperty(SETTING_NAME_LOGS_PATH);

		return sLogsPath;
	}

	/**
	 * Function tries to get trace level from 3 different sources:
	 * 1. System property
	 * 2. custom Logs setttings
	 * 3. Pl/SQL procedure SDK_LOG_TRACE.get_traceLevel()
	 *
	 * @return DEFAULT_TRACE_LEVEL	if some error occurred
	 */
	private final int readTraceLogLevel()
	{
		try
		{
			// I guess this was used in old IS Adapters framework (vefore 2.0)
			// I think it's not used any more.
			return Integer.parseInt(System.getProperty(TRACE_LEVEL_PAR));
		}
		catch (NumberFormatException e)
		{
			// System Property is not found. Let's load it from database.
		}

		String sTraceLevel = System.getProperty(TRACE_LEVEL_PAR);
		// if (sTraceLevel == null && m_customLogsSettings.get() != null)
		// 	sTraceLevel = m_customLogsSettings.get().get(TRACE_LEVEL_PAR);
		if (sTraceLevel == null && m_logsSettings != null)
			sTraceLevel = m_logsSettings.get(TRACE_LEVEL_PAR);

		return parseLogLevel(sTraceLevel);
	}
	
	private static int parseLogLevel(String sTraceLevel)
	{
		for (int level = 0; level<TRACE_LEVEL.length; level++)
		{
			if (TRACE_LEVEL[level].equalsIgnoreCase(sTraceLevel))
			{
				return level;
			}
		}
		
		// It would be better to throw exception
		throw new IllegalArgumentException("Unknown trace level: [" + sTraceLevel + "]");
	}

	public static Map<String, String> getProperties()
	{
		if (m_customLogsSettings.get() == null)
			return getInstance().m_logsSettings;

		Map<String, String> settings = new HashMap<String, String>();
		settings.putAll(getInstance().m_logsSettings);
		settings.putAll(m_customLogsSettings.get());
		return settings;
	}

	/**
	 * Execute SELECT from LOG_SETTINGS.
	 *
	 * @return Map of Strings: parameter name / parameter value
	 * @since java_sdk_v2-6-16
	 */
	private static final Map<String, String> readLogSettings()
	{
		Map<String, String> logSettings = new HashMap<String, String>();

		Connection conn = CJVMConnection.getNonTrackingConnection();
		if (conn == null || CConnection.isClosed(conn))
		{
			CConnection.closeConnection(conn);
			throw new RuntimeException("Cannot get DB connection");
		}

		String sSelect = "SELECT parameter_name, parameter_value\n" +
			"FROM log_settings\n" +
			"WHERE log_name = ?\n";

		PreparedStatement stmt = null;
		ResultSet rs = null;
		try
		{
			stmt = conn.prepareStatement(sSelect);
			stmt.setString(1, LOG_TRACE_NAME);

			rs = stmt.executeQuery();
			while (rs.next())
			{
				logSettings.put(rs.getString(1), rs.getString(2));
			}

			return logSettings;
		}
		catch (SQLException sqle)
		{
			throw new RuntimeException("Failed to read logs settings", sqle);
		}
		finally
		{
			if (rs != null)
			{
				try
				{
					rs.close();
					rs = null;
				}
				catch (SQLException sqle) {}
			}

			if (stmt != null)
			{
				try
				{
					stmt.close();
					stmt = null;
				}
				catch (SQLException sqle) {}
			}

			CConnection.closeConnection(conn);
		}
	}
}