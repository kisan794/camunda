/*
 * @(#)$RCSfile: CLogsSettingsMBeanMBean.java,v $ $Revision: 1.2 $ $Date: 2008/10/14 09:11:47 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CLogsSettingsMBeanMBean.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev			2008-10-01	created
 */
package hireright.sdk.debug;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $ $Date: 2008/10/14 09:11:47 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CLogsSettingsMBeanMBean.java,v $
 */
public interface CLogsSettingsMBeanMBean 
{
	String getLogTraceLevel();
	void setLogTraceLevel(String sLevel);
	
	String getLogFilePath();
	void setLogFilePath(String sLogsPath);
	
	void setLogSetting(String name, String value);
}
