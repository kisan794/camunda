/*
 * @(#)$RCSfile: CFTraceLog.java,v $ $Revision: 1.7 $ $Date: 2012/06/29 08:15:19 $ $Author: cvsroot $	
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/fields/CFTraceLog.java,v $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	A.Nesterov		2002-xx-xx	created
 * 	A.Rudenko			2002-09-23	added parameters support
 *	A.Solntsev		2005-04-01	removed SEQUENCE_NAME and method setNextIdValue().
 *  													Added constants FIELD_XXX_MAX_LENGTH.
 *	M.Litvinov		2005-04-15	FIELD_PAYLOAD_CLOB_MAX_LENGTH increased to 128 kb
 *  A.Solntsev		2005-08-16	Added constant FIELDS_ONLY_CLOB.
 *  A.Knyazev			2012-06-14	Deprecated: in favor of indirect access to log storage.
 */
package hireright.sdk.debug.fields;
import hireright.sdk.db.*;
import java.sql.Connection;

/**
 * Class containing meta-info about table LOGS.LOG_TRACE
 * 
 * @deprecated In favor of indirect access to log storage.
 * 
 * @author	Alexandr Nesterov
 */
@Deprecated
public class CFTraceLog extends CFTable
{
	public static final String TABLE_NAME		= "LOG_TRACE";
	//protected static final String SEQUENCE_NAME		= "LOG_TRACE_ID_SEQ";

	public static final String FIELD_ID				= "ID";
	public static final String FIELD_TYPE			= "TYPE";
	public static final String FIELD_SOURCE			= "SOURCE";
	public static final String FIELD_TEXT			= "TEXT";
	public static final String FIELD_PARAMETERS		= "PARAMETERS";
	public static final String FIELD_PAYLOAD_CLOB	= "PAYLOAD_CLOB";
	public static final String FIELD_PAYLOAD_BLOB	= "PAYLOAD_BLOB";
	public static final String FIELD_DTTM			= "DTTM";
	public static final String FIELD_TM				= "TM";
	
	public static final int FIELD_TYPE_MAX_LENGTH	= 8;
	public static final int FIELD_SOURCE_MAX_LENGTH	= 256;
	public static final int FIELD_TEXT_MAX_LENGTH	= 4000;
	public static final int FIELD_PARAMETERS_MAX_LENGTH	= 4000;
	public static final int FIELD_PAYLOAD_CLOB_MAX_LENGTH	= 131072; // 128 KB 


	public static final String[] FIELDS_WITHOUT_BLOB = 
	{
		FIELD_ID,
		FIELD_TYPE,
		FIELD_SOURCE,
		FIELD_TEXT,
		FIELD_PARAMETERS,
		FIELD_PAYLOAD_CLOB,
		FIELD_TM		
	};

	public static final String[] FIELDS_TEXT_SOURCE_CLOB = 
	{
		FIELD_TEXT,
		FIELD_SOURCE,
		FIELD_PAYLOAD_CLOB
	};
	
	public static final String[] FIELDS_ONLY_CLOB = 
	{
		FIELD_PAYLOAD_CLOB
	};
	
	public CFTraceLog(Connection connection)
	{
		super(connection, TABLE_NAME);
	}

	public CFTraceLog(Connection connection, String[] fields)
	{
		super(connection, fields, TABLE_NAME);
	}
}
