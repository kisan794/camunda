/*
 * @(#)$RCSfile: CDataExchangeLog.java,v $ $Revision: 1.5 $ $Date: 2015/11/02 20:16:39 $  $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CDataExchangeLog.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	V.Hahhulin			2013-11-26	EV#320590: created
 * 	M.Suhhoruki			2015-09-07	Changed addLog to public to avoid addInLog/addOutLog switch by direction when adding IN/OUT logs in same function
 */
package hireright.sdk.debug;

import hireright.lib.logging.data_exchange.logger.DataExchangeLogger;
import hireright.lib.logging.data_exchange.logger.DataExchangeLoggerConsts;
import hireright.lib.logging.data_exchange.logger.util.DataExchangeLoggerUtils;
import hireright.lib.logging.data_exchange.model.impl.DataExchangeLog;
import hireright.lib.logging.data_exchange.model.impl.DataExchangeLog.Direction;
import hireright.lib.logging.util.settings.LoggingSettings;
import hireright.sdk.util.CProperties;

/**
 * The CDataExchangeLog allows to write data exchange logs into database.
 * 
 * @author Vadim Hahhulin <vhahhulin@hireright.ee>
 * 
 */
public class CDataExchangeLog
{

	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";

	private static volatile DataExchangeLogger DATA_EXCHANGE_LOGGER;

	private static final int RECIPIENT_NAME_MAX_LENGTH = 100;
	private static final int RECIPIENT_OBJECT_CLASS_MAX_LENGTH = 20;
	private static final int RECIPIENT_OBJECT_ID_MAX_LENGTH = 64;
	private static final int PROTOCOL_MAX_LENGTH = 64;
	private static final int PARAMETERS_MAX_LENGTH = 4000;
	
	public static final String DIRECTION_OUT = "OUT";
	public static final String DIRECTION_IN = "IN";
	
	/**
	 * This ThreadLocal variable holds any parameters.
	 * They will be used for writing any TraceLog in current thread.
	 *
	 * @see #addCurrentThreadParameters(CProperties)
	 * @see #eraseCurrentThreadParameters()
	 */
	private static final ThreadLocal<CProperties> CURRENT_THREAD_PARAMETERS = new ThreadLocal<CProperties>();

	/**
	 * Since all methods are static constructor made protected
	 */
	protected CDataExchangeLog()
	{
		super();
	}

	/**
	 * Every program can put here any parameters using method addParameters().
	 * They will be used in case of any errors occurred in current thread.
	 * 
	 * If no exceptions occur in current thread, these properties will be lost.
	 * 
	 * @param parameters any CProperties
	 * @since java_sdk_v2-6-9
	 */
	public static void addCurrentThreadParameters(final CProperties parameters)
	{
		CProperties params = CURRENT_THREAD_PARAMETERS.get();
		if (params == null)
		{
			params = new CProperties();
			CURRENT_THREAD_PARAMETERS.set(params);
		}

		params.setProperties(parameters);
	}

	/**
	 * Remove all properties being stored in the current thread.
	 * Usually it's called before Thread should be stopped or reused.
	 * @since java_sdk_v2-6-11
	 */
	public static void eraseCurrentThreadParameters()
	{
		final CProperties params = CURRENT_THREAD_PARAMETERS.get();
		if (params != null)
		{
			params.clear();
			CURRENT_THREAD_PARAMETERS.set(null);
		}
	}

	public static final String addOutLog(final String recipientName, final String recipientClass, final String recipientId,
			final String protocol, final String parameters, final String payload)
	{
		return addLog((String) null, DIRECTION_OUT, recipientName, recipientClass, recipientId, protocol, parameters, payload);
	}

	public static final String addOutLog(final String transactionId,
			final String recipientName, final String recipientClass, final String recipientId,
			final String protocol, final String parameters, final String payload)
	{
		return addLog(transactionId, DIRECTION_OUT, recipientName, recipientClass, recipientId, protocol, parameters, payload);
	}

	public static final String addInLog(final String transactionId,
			final String recipientName, final String recipientClass, final String recipientId,
			final String protocol, final String parameters, final String payload)
	{
		return addLog(transactionId, DIRECTION_IN, recipientName, recipientClass, recipientId, protocol, parameters, payload);
	}

	public static final String addInLog(final String recipientName, final String recipientClass, final String recipientId,
			final String protocol, final String parameters, final String payload)
	{
		return addLog((String) null, DIRECTION_IN, recipientName, recipientClass, recipientId, protocol, parameters, payload);
	}
	
	/**
	 * Data Exchange log
	 * 
	 * @param transactionId
	 * @param direction IN or OUT
	 * @param recipientName
	 * @param recipientClass
	 * @param recipientId
	 * @param protocol
	 * @param parameters
	 * @param payload
	 * @return transaction ID
	 */
	public static final String addLog(String transactionId, String sDirection,
			final String recipientName, final String recipientClass, final String recipientId,
			final String protocol, final String parameters, final String payload)
	{
		if (transactionId == null)
		{
			transactionId = generateTransactionID();
		}
		
		final DataExchangeLog log = new DataExchangeLog(transactionId, Direction.fromCode(sDirection));
		
		log.setRecipientName(abbreviate(recipientName, RECIPIENT_NAME_MAX_LENGTH));
		log.setRecipientClass(abbreviate(recipientClass, RECIPIENT_OBJECT_CLASS_MAX_LENGTH));
		log.setRecipientId(abbreviate(recipientId, RECIPIENT_OBJECT_ID_MAX_LENGTH));
		log.setProtocol(abbreviate(protocol, PROTOCOL_MAX_LENGTH));
		log.setParameters(abbreviate(parameters, PARAMETERS_MAX_LENGTH));
		log.setPayload(payload);

		getDataExchangeLogger().log(log);

		return log.getTransactionId();
	}
	
	public static String generateTransactionID()
	{
		return DataExchangeLoggerConsts.TRANSACTION_ID_REFERENCE_GENERATOR.generateReference(null);
	}
	
	private static DataExchangeLogger getDataExchangeLogger()
	{
		if (CDataExchangeLog.DATA_EXCHANGE_LOGGER == null)
		{
			synchronized (CDataExchangeLog.class)
			{
				if (CDataExchangeLog.DATA_EXCHANGE_LOGGER == null)
				{
					final String loggerName = CDataExchangeLog.class.getName() + "_dataExchangeLogger";
					CDataExchangeLog.DATA_EXCHANGE_LOGGER = DataExchangeLoggerUtils.newDataExchangeLogger(
								loggerName, new LoggingSettings().getInitialGlxHttpAppenderPostingUrl());
				}
			}
		}

		return CDataExchangeLog.DATA_EXCHANGE_LOGGER;
	}

	private static String abbreviate(final String s, final int maxLength)
	{
		if (maxLength < 0)
		{
			throw new IllegalArgumentException("Invalid max length. Zero or positive value is expected.");
		}
		
		return s == null ? null : s.substring(0, Math.min(s.length(), maxLength));
	}

}
