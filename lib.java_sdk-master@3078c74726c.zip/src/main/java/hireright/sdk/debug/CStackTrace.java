/*
 * @(#)$RCSfile: CStackTrace.java,v $ $Revision: 1.13 $ $Date: 2015/03/28 08:32:14 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CStackTrace.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	A.Solntsev		2005-04-01	created
 * 	A.Solntsev		2005-04-01	Added method getExceptionSource(Throwable e)
 *  A.Solntsev		2005-07-26	Added method truncate().
 *  A.Solntsev		2006-02-08	Method substringBefore() moved to CStringUtils.
 *  A.Solntsev		2007-12-18	Added method getClassVersion()
 */
package hireright.sdk.debug;
import hireright.sdk.util.CClass;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Class with utilities for printing stack trace.
 *
 * @author	Andrei Solntsev
 * @date		2005-04-01
 * @since		java_sdk_v2-5-22
 * @version $Revision: 1.13 $ $Date: 2015/03/28 08:32:14 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CStackTrace.java,v $
 */
public class CStackTrace
{
	protected static final String CLASS_VERSION = "$Revision: 1.13 $ $Author: cvsroot $";

	private CStackTrace()
	{
		// all methods are static
	}

	public static String getStackTrace(Throwable e)
	{
		return getStackTrace(e, false);
	}

	/**
	 * Method returns stack trace of given error as String.
	 * @param e	any Throwable: Exception, RuntimeException, ...
	 * @return String
	 */
	public static String getStackTrace(Throwable e, boolean bPrintVersions)
	{
		final StringWriter writer = new StringWriter();
		final PrintWriter printWriter = new PrintWriter(writer);
		try
		{
			printStackTrace(e, printWriter, bPrintVersions);
			printWriter.flush();
		}
		finally
		{
			printWriter.close();
		}
		return writer.toString();
	}

	private static void printStackTrace(Throwable e, PrintWriter	printWriter, boolean bPrintVersions)
	{
		String sClassVersion;
		String prevClassVersion = null;
		printWriter.println(e.toString());
		StackTraceElement[] stack = e.getStackTrace();
		for (int i=0; i<stack.length; i++)
		{
			printWriter.print( "\tat " );
			printWriter.print(stack[i].toString());
			if (bPrintVersions)
			{
				sClassVersion = CClass.getClassVersion(stack[i].getClassName());
				if (sClassVersion != null)
				{
					printWriter.print(" [");
					if (prevClassVersion != null && prevClassVersion.equals(sClassVersion))
					{
						printWriter.print("...");
					}
					else
					{
						printWriter.print(sClassVersion);
					}
					printWriter.print("]");
				}
				prevClassVersion = sClassVersion;
			}
			printWriter.println();
		}

		if (e.getCause() != null)
		{
			printWriter.println("Caused by: ");
			printStackTrace(e.getCause(), printWriter, bPrintVersions);
		}
	}

	/**
	 * Constant is package-private, so that unit-test could use it.
	 */
	static final String MESSAGE_STACK_TRACE = "Stack trace:";

	/**
	 * Method returns program's stack trace like this:
	 * <pre>Stack trace:<br>
	 *  at hireright.objects.xzx.yyy.sgfs<br>
	 *  ...
	 * </pre>
	 * @return String
	 */
	public static String getStackTrace()
	{
		return getStackTrace(MESSAGE_STACK_TRACE, false);
	}
	
	public static String getStackTrace(boolean bPrintVersions)
	{
		return getStackTrace(MESSAGE_STACK_TRACE, bPrintVersions);
	}

	public static String getStackTrace(String sMessage)
	{
		return getStackTrace(sMessage, false);
	}

	/**
	 * Method returns program's stack trace like this:
	 * <pre>[Given message]<br>
	 *  at hireright.objects.xzx.yyy.sgfs<br>
	 *  ...<br>
	 * </pre>
	 * @return String
	 */
	public static String getStackTrace(String sMessage, boolean bPrintVersions)
	{
		// Make artificial exception & get its stack trace
		String sStackTrace = getStackTrace(new Exception(), bPrintVersions);

		// Remove 2 first lines and add given message
		return sMessage + "\n" + split(sStackTrace, '\n');
	}

	/**
	 * Method splits original string into 3 strings using given delimiter
	 * @param sOriginalString
	 * @param	sDelimiters
	 * @return The last of these 3 strings.
	 */
	public static String split(String sOriginalString, char cDelimiter)
	{
		/*
		 * FIXME	Use method String.split() when HireRight migrates to J2SDK >= 1.4
		 */
		int i = sOriginalString.indexOf(cDelimiter);
		if (i == -1)
		{
			// Just for safety. It never occurs.
			return sOriginalString;
		}

		int j = sOriginalString.indexOf(cDelimiter, i+1);
		if (j == -1)
		{
			// Just for safety. It never occurs.
			return sOriginalString.substring(i+1);
		}

		return sOriginalString.substring(j+1);
	}

	/**
	 * Method returns name of class in which this exception has occurred.
	 * For example, if e is
	 * <pre>hireright.gui.mvc.exceptions.DisplayableErrorException: Failed to load ...<br>
	 *  at hireright.gui.extensions.entry.controllers.CEntryPointController.entry(CEntryPointController.java:88)<br>
	 *  at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)<br>
	 *  ...
	 * </pre>
	 *
	 * then method returns
	 * <code>hireright.gui.extensions.entry.controllers.CEntryPointController.entry()</code>
	 *
	 * @see	getExceptionSource(String sStackTrace)
	 * @param e	Exception to find source.
	 * @return Name of class and row number.
	 */
	public static String getExceptionSource(Throwable e)
	{
		String sTrace = CStackTrace.getStackTrace(e);
		return getExceptionSource(sTrace);
	}

	/**
	 * Getting error stack, method finds out name of class where this
	 * exception occurred ("exception source").
	 *
	 * For example, if stack trace is
	 * <pre>java.io.FileNotFoundException: ...<br>
	 *  at sun.net.www.protocol.http.HttpURLConnection.getInputStream(HttpURLConnection.java:798)<br>
	 *  at java.net.URL.openStream(URL.java:913)<br>
	 *  ...</pre>
	 * then exception source is
	 * <code>sun.net.www.protocol.http.HttpURLConnection.getInputStream(HttpURLConnection.java:798)</code>.
	 *
	 *
	 * If exception source is not found (for example, if stack trace is
	 * <code>"java.lang.OutOfMemoryException"</code>), then method returns
	 * <code>"java.lang"</code>.
	 *
	 * @param sStackTrace	Stack trace of exception.
	 * @return 	Exception source or "java.lang"
	 */
	public static String getExceptionSource(String sStackTrace)
	{
		int iEOL = sStackTrace.indexOf('\n');
		if (iEOL < 1)
			return "java.lang";

		int iAt = sStackTrace.indexOf("	at ", iEOL + 1);
		if (iAt < 1)
			return "java.lang";

		int iRightBrace = sStackTrace.indexOf(')', iAt + 1);
		if (iRightBrace < 1)
			return "java.lang";

		return sStackTrace.substring(iAt + 4, iRightBrace+1);
	}

	/**
	 * Print n first lines of error stack trace
	 * @param nLines
	 * @param out
	 * @param e
	 *
	 * @since jdk 1.4
	 */
	public static void printStackTrace(Throwable e, PrintStream out, int nLines)
	{
		StackTraceElement[] stack = e.getStackTrace();
		for (int i=0; i<nLines && i<stack.length; i++)
		{
			out.println(stack[i].toString());
		}
	}

	public static void main(String[] args)
	{
		Exception e = new Exception("Test");
		printStackTrace(e, System.out, 1);
	}

}