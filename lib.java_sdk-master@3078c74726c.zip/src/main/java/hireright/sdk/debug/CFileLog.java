/*
 * @(#)$RCSfile: CFileLog.java,v $ $Revision: 1.10 $ $Date: 2012/06/29 08:15:02 $  $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CFileLog.java,v $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	11.05.2000 A.Nesterov	class moved to debug package, all empty comments deleted, also removed "import db.*;"
 * 	06.06.2000 A.Nesterov	added writeSeparateFile function
 * 	08.06.2000 A.Nesterov	all path strings replaced by LOG_PATH constant
 * 	11.10.2001 A.Rudenko	millisecond added into writeSeparateFile function
 *  2006-02-08 A.Solntsev	File logging enhancement. 
 *  2006-05-07 A.Solntsev	Class CLogsSettings is now used
 *  2012-06-14 A.Knyazev	Deprecated: In favor of capabilities provided by Logging API.
 */
package hireright.sdk.debug;
import java.util.Date;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;

/**
 * Set of functions for writing debug logs into any file
 * 
 * @deprecated In favor of capabilities provided by Logging API.
 * 
 * @author Sergei Ignatov & Alexander Rudenko
 * @version $Revision: 1.10 $ $Date: 2012/06/29 08:15:02 $  $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CFileLog.java,v $
 */
@Deprecated
public class CFileLog
{
	
	protected static final String CLASS_VERSION = "$Revision: 1.10 $ $Author: cvsroot $";
	
	private static final PrintStream failFailureLog = System.out;
	
	public static void insert( String szValue )
	{
		insert( szValue, "default.log");
	}

	//Writes logs in separate files with names like "SomePrefix_yymmdd_hhmmss.log"
	public static void writeSeparateFile( String szValue,  String strFileNamePrefix )
	{
		try
		{
			SimpleDateFormat formatter = new SimpleDateFormat();
			formatter.applyPattern("yyMMdd'_'hhmmss_SSS");
			String strFileName = formatter.format(new Date()) + '_' + strFileNamePrefix +".log";
			
			File file = new File(CLogsSettings.getLogsPath() + strFileName);
			file.createNewFile();
			FileWriter fileWriter = new FileWriter( file.getAbsolutePath() , true );
			fileWriter.write(szValue);
			fileWriter.write('\n');
			fileWriter.flush();
			fileWriter.close();
		}
		catch( Exception e )
		{
			failFailureLog.println(e);
		}
	}

	public static void insert( String szValue,  String szFileName )
	{
		try
		{
			File file = new File(CLogsSettings.getLogsPath() + szFileName );
			file.createNewFile();
			FileWriter fileWriter = new FileWriter( file.getAbsolutePath() , true );
			Date date = new Date();
			fileWriter.write( date.toString() + "  " + szValue );
			fileWriter.write( '\n' );
			fileWriter.flush();
			fileWriter.close();
		}
		catch( Exception e )
		{
			failFailureLog.println(e);
		}
	}

	public static void insert( Throwable ex,  String szFileName )
	{
		try
		{
			File file = new File(CLogsSettings.getLogsPath() + szFileName );
			file.createNewFile();
			FileWriter fileWriter = new FileWriter( file.getAbsolutePath() , true );
			Date date = new Date();
			fileWriter.write( date.toString() );
			fileWriter.write( '\n' );
			ex.printStackTrace( new java.io.PrintWriter( fileWriter) );
			fileWriter.flush();
			fileWriter.close();
		}
		catch( Exception e )
		{
			failFailureLog.println(e);
		}

	}

	// ------------ Object methods -----------
	private FileWriter m_fileWriter;

	public CFileLog(String sFileName) throws IOException
	{
		String sFullFileName = CLogsSettings.getLogsPath() + sFileName;
		File file = new File( sFullFileName );
		file.createNewFile();
		
		// failFailureLog.println("File log: " + file.getAbsolutePath());
		m_fileWriter = new FileWriter( file.getAbsolutePath() , true );
	}
	
	public CFileLog append(String sMessage) throws IOException
	{
		if (sMessage != null)
		{
			m_fileWriter.write( sMessage );
		}
		return this;
	}
	
	public CFileLog append( Throwable ex ) 
	{
		if (ex != null)
		{
			ex.printStackTrace( new java.io.PrintWriter( m_fileWriter) );
		}
		return this;
	}
	
	public CFileLog flush() throws IOException
	{
		m_fileWriter.flush();
		m_fileWriter.close();

		return this;
	}
}
