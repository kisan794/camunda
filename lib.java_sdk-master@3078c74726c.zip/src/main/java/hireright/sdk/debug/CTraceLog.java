/*
 * @(#)$RCSfile: CTraceLog.java,v $ $Revision: 1.36 $ $Date: 2012/03/02 07:09:43 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CTraceLog.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	A.Nesterov		2002-xx-xx	created
 * 	A.Rudenko		2002-09-03	sdk_trace	calls	changed	to sdk_log_trace to	LOGS schema
 * 	A.Rudenko		2002-09-23	added	parameters support
 * 	A.Nesterov		2002-10-09	added	failed trace logging into	file TraceFailures.log
 * 	A.Nesterov		2002-10-15	parameters now can be	saved	into TraceFailures.log
 * 	A.Nesterov		2002-10-30	added	more checks	for	log	writing	failures
 * 	D.Travin		2003-04-08	added	anpther	overloaded info()
 * 	A.Solntsev		2004-05-24	added	more methods error(),	fatal().
 * 	I.Suits			2004-12-03	added	info(Throwable,	String,	CProperties) method
 * 	A.Solntsev		2005-01-05	added warning(Throwable)
 * 	I.Suits			2005-01-24	changed addMessage that it uses SDK_LOG_TRACE.add_log in all cases
 * 	I.Suits			2005-02-02	log level constansts made public (for GeneralSettings class)
 *  A.Solntsev		2005-03-31	Fixed NullPointerException when cannot connect to DB.
 *  							One of methods addMessage() is removed.
 *                            	New class CLogTraceSettings is used.
 *	A.Solntsev		2005-04-01	Now all messages contain Stack Trace.
 *  							Fixed processing errors.
 *  A.Solntsev		2005-05-03	Now all methods return ID of created log.
 *  A.Solntsev		2005-05-24	More smart logging of exceptions in sdk_logs.add_log()
 *  							When writing to file, now log IP of this machine.
 *  A.Solntsev		2005-07-22	To decrease size of LOG_TRACE, truncate useless tail of stack trace
 *  A.Solntsev		2005-08-16	Now CLOB is saved without using hireright.sdk.db.* package.
 *  A.Solntsev		2006-02-08	File logging enhancement.
 *  A.Solntsev		2006-05-04	Added "Current Thread parameters" mega-feature
 *  A.Solntsev		2006-05-07	Class CLogsSettings is now used
 *  A.Solntsev		2006-05-28	Added method eraseCurrentThreadParameters()
 *  A.Solntsev		2006-08-20	Added method addCurrentThreadParameters(CProperties parameters, Object sessionHistory)
 *  A.Solntsev		2006-08-24	Added check for null source
 *  O.Golovachev	2006-10-09	Now write full stack trace (don't cut it)
 *  A.Solntsev		2006-08-24	When more information to file (max. length 1024 -> 32000)
 *  A.Solntsev		2007-09-06	Fixed bug: make copy of CProperties instance before modifying it.
 *  A.Solntsev		2007-09-21	Now using method CJVMConnection.getNonTrackingConnection()
 *  A.Solntsev		2007-09-21	System property 'process_name' is added to be used as preffix for source (the same as in TraceLogAppender)
 *  A.Solntsev		2007-11-26	Implemented (optional) recording of current thread logs
 *  A.Solntsev		2007-12-18	Added printing class versions to stack trace
 *  E.Shatohhin		2008-02-26	writeTraceLog(): Truncated TEXT is now written to CLOB
 *  A.Solntsev		2008-08-29	using generics
 *  A.Solntsev		2008-11-14	Use ThreadSafeDateFormat instead of SimpleDateFormat
 *  A.Solntsev		2010-01-12	Moved most of functionality from CTraceLog to hireright.sdkex.log4j.TraceLogAppender
 *  E.Shatohhin		2011-08-24	Added error(),fatal(),warning() with single throwable parameter
 *  A.Knyazev			2012-01-31	Added: compatibility with changes in tracelog4j. See EV 227799.
 */
package hireright.sdk.debug;

import hireright.sdk.util.CProperties;
import hireright.sdkex.log4j.NDC;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;

/**
 * The CTraceLog allows	to write application logs	into database.
 * <P>
 * There are five	types	of messages	can	be added to	log:<br><br>
 *
 * debug - debug information of	maximum	possible verbosity<br>
 * warning - warning message<br>
 * info	-	any	type of	short	messages for gathering statistics	or for debug purposes<br>
 * error - all errors	except fatal<br>
 * fatal - fatal errors, that	stop or	crash	running	application
 *
 * @author Alexander Nesterov
 * @version $Revision: 1.36 $ $Date: 2012/03/02 07:09:43 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/debug/CTraceLog.java,v $
 */
public class CTraceLog implements Serializable
{

	protected static final String CLASS_VERSION = "$Revision: 1.36 $ $Author: cvsroot $";

	private static final long serialVersionUID = 1L;

	//log level constansts
	public static final int DEBUG = 0;
	public static final int INFO = 1;
	public static final int WARNING = 2;
	public static final int ERROR = 3;
	public static final int FATAL = 4;

	/**
	 * This ThreadLocal variable holds any parameters.
	 * They will be used for writing any TraceLog in current thread.
	 *
	 * @see #addCurrentThreadParameters(CProperties)
	 * @see #eraseCurrentThreadParameters()
	 */
	private static final ThreadLocal<CProperties> m_currentThreadParameters = new ThreadLocal<CProperties>();

	/**
	 * This ThreadLocal variable holds any object useful for being logged to field PAYLOAD_CLOB
	 * of table LOG_TRACE.
	 *
	 * Typically it's an object containing history of user actions.
	 * For example, hireright.gui.mvc.CUserSessionHistory.
	 *
	 * When logging, a method toString() will be called on this object.
	 *
	 * @see #addCurrentThreadParameters(CProperties, Object)
	 * @see #eraseCurrentThreadParameters()
	 */
	private static final ThreadLocal<Object> m_currentThreadSessionHistory = new ThreadLocal<Object>();

	public static CProperties getCurrentThreadParameters()
	{
		return m_currentThreadParameters.get();
	}

	/**
	 * Every program can put here any parameters using method addParameters().
	 * They will be used in case of any errors occurred in current thread.
	 *
	 * If no exceptions occur in current thread, these properties will be loosed.
	 *
	 * @param parameters any CProperties
	 * @since java_sdk_v2-6-9
	 */
	public static void addCurrentThreadParameters(CProperties parameters)
	{
		CProperties params = m_currentThreadParameters.get();
		if (params == null)
		{
			params = new CProperties();
			m_currentThreadParameters.set(params);
		}

		params.setProperties(parameters);
		NDC.addParameters(params.getMap());
	}

	public static void addCurrentThreadParameters(CProperties parameters, Object sessionHistory)
	{
		addCurrentThreadParameters(parameters);
		m_currentThreadSessionHistory.set(sessionHistory);
	}

	/**
	 * Remove all properties being stored in the current thread.
	 * Usually it's called before Thread should be stopped or reused.
	 * @since java_sdk_v2-6-11
	 */
	public static void eraseCurrentThreadParameters()
	{
		CProperties params = m_currentThreadParameters.get();
		if (params != null)
		{
			params.clear();
			m_currentThreadParameters.set(null);
		}

		m_currentThreadSessionHistory.set(null);
	}

	/**
	 * Used only in HireBug
	 * 
	 * @deprecated No HireBug any more.
	 */
	@Deprecated
	public static void startRecording()
	{
		// TraceLogAppender.startRecording();
	}

	/**
	 * Used only in HireBug
	 * 
	 * @deprecated No HireBug any more
	 */
	@Deprecated
	public static List<CLogTrace> finishRecording()
	{
		//		List<hireright.sdkex.log4j.CLogTrace> rs = TraceLogAppender.finishRecording();
		//		List<CLogTrace> res = new ArrayList<CLogTrace>(rs.size());
		//		for (hireright.sdkex.log4j.CLogTrace log : rs)
		//		{
		//			res.add( new CLogTrace(log) );
		//		}
		//		return res;
		return new ArrayList<CLogTrace>(0);
	}

	/**
	 * Adds	"warning"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long warning(String sMessage, String sSource)
	{
		LogManager.getLogger(sSource).warn(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"warning"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	sData any data to log (XML, stack trace etc.)
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long warning(String sMessage, String sSource, String sData)
	{
		setUp(null, sData);
		LogManager.getLogger(sSource).warn(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"warning"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	params message parameters
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long warning(String sMessage, String sSource, CProperties params)
	{
		setUp(params, null);
		LogManager.getLogger(sSource).warn(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"warning"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	params message parameters
	 * @param	sData	extra	information	attached to	message
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long warning(String sMessage, String sSource, CProperties params, String sData)
	{
		setUp(params, sData);
		LogManager.getLogger(sSource).warn(sMessage);
		return tearDown();
	}

	/**
	 * Adds "warning" message into log
	 *
	 * @param e as it's just warning, it's not real exception - it's just used to log stack trace.
	 * @param sSource message source description
	 * @param params message parameters
	 * @param sData extra information attached to message
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long warning(Throwable e, String sSource, CProperties params, String sData)
	{
		setUp(params, sData);
		LogManager.getLogger(sSource).warn(e.getMessage(), e);
		return tearDown();
	}

	/**
	 * Adds "warning" message into log
	 *
	 * @param e as it's just warning, it's not real exception - it's just used to log stack trace.
	 * @param sSource message source description
	 * @param params message parameters
	 */
	public static void warning(Throwable e, String sSource, CProperties params)
	{
		setUp(params, null);
		LogManager.getLogger(sSource).warn(e.getMessage(), e);
	}

	/**
	 * Adds "warning" message into log
	 *
	 * @param e as it's just warning, it's not real exception - it's just used to log stack trace.
	 * @param sSource message source description
	 */
	public static void warning(Throwable e, String sSource)
	{
		LogManager.getLogger(sSource).warn(e.getMessage(), e);
	}

	/**
	 * Adds "warning" message into log with source of caller class
	 *
	 * @param e as it's just warning, it's not real exception - it's just used to log stack trace.
	 */
	public static void warning(Throwable e)
	{
		warning(e, Thread.currentThread().getStackTrace()[2].getClassName());
	}

	/**
	 * Adds	"debug"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long debug(String sMessage, String sSource)
	{
		LogManager.getLogger(sSource).debug(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"debug"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	params message parameters
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long debug(String sMessage, String sSource, CProperties params)
	{
		setUp(params, null);
		LogManager.getLogger(sSource).debug(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"debug"	message	into log
	 *
	 * @param sMessage message text
	 * @param sSource	message	source description
	 * @param params message parameters
	 * @param sData extra information attached to message (data writes to CLOB)
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long debug(String sMessage, String sSource, CProperties params, String sData)
	{
		setUp(params, sData);
		LogManager.getLogger(sSource).debug(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"debug"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	sData	extra	information	attached to	message
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long debug(String sMessage, String sSource, String sData)
	{
		setUp(null, sData);
		LogManager.getLogger(sSource).debug(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"info" message into	log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long info(String sMessage, String sSource)
	{
		LogManager.getLogger(sSource).info(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"info" message into	log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	params message parameters
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long info(String sMessage, String sSource, CProperties params)
	{
		setUp(params, null);
		LogManager.getLogger(sSource).info(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"info" message into	log
	 *
	 * @param sMessage message text
	 * @param sSource	message	source description
	 * @param sData extra information attached to message (data writes to CLOB)
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long info(String sMessage, String sSource, String sData)
	{
		setUp(null, sData);
		LogManager.getLogger(sSource).info(sMessage);
		return tearDown();
	}

	public static long info(String sMessage, String sSource, CProperties params, String sData)
	{
		setUp(params, sData);
		LogManager.getLogger(sSource).info(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"info" message into	log
	 * @param	e	exception	to report	in log
	 * @param	sSource	message	source description
	 * @param	params simple	parameters
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long info(Throwable e, String sSource, CProperties params)
	{
		setUp(params, null);
		LogManager.getLogger(sSource).info(e.getMessage(), e);
		return tearDown();
	}

	public static long info(Throwable e, String sSource, CProperties params, String sData)
	{
		setUp(params, sData);
		LogManager.getLogger(sSource).info(e.getMessage(), e);
		return tearDown();
	}

	/**
	 * Adds	"error"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description.
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long error(String sMessage, String sSource)
	{
		LogManager.getLogger(sSource).error(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"error"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	params message parameters
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long error(String sMessage, String sSource, CProperties params)
	{
		setUp(params, null);
		LogManager.getLogger(sSource).error(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"error"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	sData	extra	information	attached to	message
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long error(String sMessage, String sSource, String sData)
	{
		setUp(null, sData);
		LogManager.getLogger(sSource).error(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"error"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	params parameters name value pairs holder object
	 * @param	sData	extra	information	attached to	message
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long error(String sMessage, String sSource, CProperties params, String sData)
	{
		setUp(params, sData);
		LogManager.getLogger(sSource).error(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"error"	message	into log
	 *
	 * @param	e	exception	to report	in log
	 * @param	sSource	message	source description
	 * @param	sData	extra	information	attached to	message
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long error(Throwable e, String sSource, String sData)
	{
		setUp(null, sData);
		LogManager.getLogger(sSource).error(e.getMessage(), e);
		return tearDown();
	}

	/**
	 * Adds	"error"	message	into log
	 * @param	e	exception	to report	in log
	 * @param	sSource	message	source description
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long error(Throwable e, String sSource)
	{
		LogManager.getLogger(sSource).error(e.getMessage(), e);
		return tearDown();
	}

	/**
	 * Adds	"error"	message	into log with source of caller class
	 * @param	e	exception	to report	in log
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long error(Throwable e)
	{
		return error(e, Thread.currentThread().getStackTrace()[2].getClassName());
	}

	/**
	 * Adds	"error"	message	into log
	 * @param	e	exception	to report	in log
	 * @param	sSource	message	source description
	 * @param 	params parameters name value pairs holder object
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long error(Throwable e, String sSource, CProperties params)
	{
		setUp(params, null);
		LogManager.getLogger(sSource).error(e.getMessage(), e);
		return tearDown();
	}

	/**
	 * Adds	"error"	message	into log
	 * @param	e	exception	to report	in log
	 * @param	sSource	message	source description
	 * @param 	params parameters name value pairs holder object
	 * @param	sData	message	source description
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long error(Throwable e, String sSource, CProperties params, String sData)
	{
		setUp(params, sData);
		LogManager.getLogger(sSource).error(e.getMessage(), e);
		return tearDown();
	}

	/**
	 * Adds	"fatal"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long fatal(String sMessage, String sSource)
	{
		LogManager.getLogger(sSource).fatal(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"fatal"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	params message parameters
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long fatal(String sMessage, String sSource, CProperties params)
	{
		setUp(params, null);
		LogManager.getLogger(sSource).fatal(sMessage);
		return tearDown();
	}

	/**
	 * Adds	"fatal"	message	into log
	 *
	 * @param	e	exception	to report	in log
	 * @param	sSource	message	source description
	 * @param 	params parameters name value pairs holder object
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long fatal(Throwable e, String sSource, CProperties params)
	{
		setUp(params, null);
		LogManager.getLogger(sSource).fatal(e.getMessage(), e);
		return tearDown();
	}

	/**
	 * Adds	"fatal"	message	into log
	 *
	 * @param e	exception	to report	in log
	 * @param sSource	message	source description
	 * @param sData extra information attached to message (data writes to CLOB)
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long fatal(Throwable e, String sSource, String sData)
	{
		setUp(null, sData);
		LogManager.getLogger(sSource).fatal(e.getMessage(), e);
		return tearDown();
	}

	/**
	 * Adds	"fatal"	message	into log
	 *
	 * @param	e	exception	to report	in log
	 * @param	sSource	message	source description
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long fatal(Throwable e, String sSource)
	{
		LogManager.getLogger(sSource).fatal(e.getMessage(), e);
		return tearDown();
	}

	/**
	 * Adds	"fatal"	message	into log with source of caller class
	 *
	 * @param	e	exception	to report	in log
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long fatal(Throwable e)
	{
		return fatal(e, Thread.currentThread().getStackTrace()[2].getClassName());
	}

	/**
	 * Adds	"fatal error"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param	sData	extra	information	attached to	message
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long fatal(String sMessage, String sSource, String sData)
	{
		setUp(null, sData);
		LogManager.getLogger(sSource).fatal(sMessage);
		return tearDown();
	}

	public static long fatal(Throwable e, String sSource, CProperties params, String sData)
	{
		setUp(params, sData);
		LogManager.getLogger(sSource).fatal(e.getMessage(), e);
		return tearDown();
	}

	/**
	 * Adds	"fatal error"	message	into log
	 *
	 * @param	sMessage message text
	 * @param	sSource	message	source description
	 * @param 	params parameters name value pairs holder object
	 * @param	sData	extra	information	attached to	message
	 *
	 * @return 	ID of created record, >= 1.
	 * 			If exception happened, returns -1.
	 */
	public static long fatal(String sMessage, String sSource, CProperties params, String sData)
	{
		setUp(params, sData);
		LogManager.getLogger(sSource).fatal(sMessage);
		return tearDown();
	}

	/**
	 * @deprecated Use method with Level parameter instead of nLevel
	 * @param nLevel
	 */
	@Deprecated
	public static final long addException(int nLevel, Throwable ex, String sSource,
			CProperties params, String sData)
	{
		setUp(params, sData);
		switch (nLevel)
		{
			case DEBUG:
				LogManager.getLogger(sSource).debug(ex.getMessage(), ex);
				break;
			case INFO:
				LogManager.getLogger(sSource).info(ex.getMessage(), ex);
				break;
			case WARNING:
				LogManager.getLogger(sSource).warn(ex.getMessage(), ex);
				break;
			case ERROR:
				LogManager.getLogger(sSource).error(ex.getMessage(), ex);
				break;
			case FATAL:
				LogManager.getLogger(sSource).fatal(ex.getMessage(), ex);
				break;
			default:
				LogManager.getLogger(sSource).error(ex.getMessage(), ex);
				break;
		}
		return tearDown();
	}

	/**
	 * @deprecated Use method with Level parameter instead of nLevel
	 * @param nLevel
	 */
	@Deprecated
	public static final long addMessage(int nLevel, String sMessage, String sSource,
			CProperties params, String sData)
	{
		setUp(params, sData);
		switch (nLevel)
		{
			case DEBUG:
				LogManager.getLogger(sSource).debug(sMessage);
				break;
			case INFO:
				LogManager.getLogger(sSource).info(sMessage);
				break;
			case WARNING:
				LogManager.getLogger(sSource).warn(sMessage);
				break;
			case ERROR:
				LogManager.getLogger(sSource).error(sMessage);
				break;
			case FATAL:
				LogManager.getLogger(sSource).fatal(sMessage);
				break;
			default:
				LogManager.getLogger(sSource).error(sMessage);
				break;
		}
		return tearDown();
	}

	private static final void setUp(final CProperties params, final String sData)
	{
		String sDataToLog;
		if (m_currentThreadSessionHistory.get() == null) // TODO: session history, recheck!
		{
			sDataToLog = sData;
		}
		else
		{
			if (sData == null)
			{
				sDataToLog = m_currentThreadSessionHistory.get().toString();
			}
			else
			{
				sDataToLog = sData + "\n\n" + m_currentThreadSessionHistory.get().toString();
			}
		}
		
		NDC.setParameters(params == null ? null : params.getMap()); // FIXME: Rethink!
		NDC.setData(sDataToLog); // FIXME: Rethink!
	}

	private static final long tearDown()
	{
		final Long ndcLastLogId = NDC.getLastLogId();
		final long lastLogId = ndcLastLogId == null ? -1 : ndcLastLogId.longValue();
		NDC.reset();
		return lastLogId;
	}

	/*
	 * FIXME	I think methods below should be removed. Don't use them!
	 * 				2005-04-01	A.Solntsev
	 */

	/**
	 * @return true	if writing trace level messages	is enabled in	application	settings
	 */
	public static final boolean warningLogEnabled()
	{
		return (CLogsSettings.getTraceLevel() <= WARNING);
	}

	/**
	 * @return true	if writing debug level messages	is enabled in	application	settings
	 */
	public static final boolean debugLogEnabled()
	{
		return (CLogsSettings.getTraceLevel() <= DEBUG);
	}

	/**
	 * @return true	if writing info	level	messages is	enabled	in application settings
	 */
	public static final boolean infoLogEnabled()
	{
		return (CLogsSettings.getTraceLevel() <= INFO);
	}

	/**
	 * @return true	if writing error level messages	is enabled in	application	settings
	 */
	public static final boolean errorLogEnabled()
	{
		return (CLogsSettings.getTraceLevel() <= ERROR);
	}

	/**
	 * @return true	if writing fatal level messages	is enabled in	application	settings
	 */
	// FIXME: Strange method.
	public static final boolean fatalLogEnabled()
	{
		return (CLogsSettings.getTraceLevel() <= FATAL);
	}

	/**
	 * Since all methods	are	static constructor made	private.
	 * No instance can be created.
	 */
	private CTraceLog()
	{
	}

	@Deprecated
	public static class CLogTrace extends hireright.sdkex.log4j.CLogTrace
	{
		/*public CLogTrace( long nID, String sType, String sSource, String sText, 
				Date dDTTM, String sProperties, String sPayloadClob )
		{
			super( nID, sType, sSource, sText, dDTTM, sProperties, sPayloadClob );
		}*/

		public CLogTrace(hireright.sdkex.log4j.CLogTrace cloneMe)
		{
			super(cloneMe);
		}
	}

}
