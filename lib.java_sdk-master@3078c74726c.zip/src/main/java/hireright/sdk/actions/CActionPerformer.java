/*
 * @(#)$RCSfile: CActionPerformer.java,v $ $Revision: 1.2 $ $Date: 2015/11/02 20:15:29 $ $Author: cvsroot $
 *
 * Copyright 2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Podlipski		2015-08-29	created
 */
package hireright.sdk.actions;


/**
 * Generic class for performing controlled actions on objects.
 */
public final class CActionPerformer
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	/**
	 * 
	 * @param file
	 * @param controller
	 * @return
	 */
	public static <T> boolean doAction(T object, IActionController<T> controller, IAction<T, Boolean> impl) throws Exception 
	{
		boolean bSuccess = false;
		if (controller == null || controller.accepts(object))
		{
			try
			{
				if (controller != null)
				{
					controller.before(object);
				}
				bSuccess = impl.doAction(object);
				if (bSuccess && controller != null)
				{
					controller.onSuccess(object);
				}
			}
			finally
			{
				if (!bSuccess && controller != null)
				{
					controller.onFailure(object);
				}
			}
		}
		return bSuccess; 
	}
}
