/*
 * @(#)$RCSfile: IAction.java,v $ $Revision: 1.2 $ $Date: 2015/11/02 20:15:26 $ $Author: cvsroot $
 *
 * Copyright 2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Podlipski		2015-08-28	created
 */
package hireright.sdk.actions;

/**
 * Common contract for primitive actions: entities that perform a piece of work on specified object.
 * Action is not allowed to have any decision making logic, or react to successful completion or failure; 
 * this is done by {@link IActionController}.
 * 
 * @author apodlipski
 */
public interface IAction<T, R>
{
	public R doAction(T object) throws Exception;
}
