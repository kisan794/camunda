/*
 * @(#)$RCSfile: IActionController.java,v $ $Revision: 1.2 $ $Date: 2015/11/02 20:15:06 $ $Author: cvsroot $
 *
 * Copyright 2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Podlipski		2015-08-27	created
 */
package hireright.sdk.actions;


/**
 * Common contract for entities that control abstract action fulfillment.  
 * This allows to separate the decision making logic from the action implementation.
 * @see IAction
 */
public interface IActionController<T>
{
	/** 
	 * Allows controller to accept or reject certain objects. 
	 * Action must be performed on accepted objects and must not be performed on rejected objects. 
	 */
	public boolean accepts(T t);
	
	/** Allows making preparations before performing the action. */
	public void before(T t) throws Exception;
	
	/** Allows reacting to successful action completion. */
	public void onSuccess(T t) throws Exception;
	
	/** Allows reacting to action failure. */
	public void onFailure(T t) throws Exception;
}
