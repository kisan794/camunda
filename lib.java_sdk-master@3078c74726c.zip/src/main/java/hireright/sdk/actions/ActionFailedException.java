/*
 * @(#)$RCSfile: ActionFailedException.java,v $ $Revision: 1.6 $ $Date: 2008/03/03 11:50:01 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/actions/ActionFailedException.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	D.Travin				2003-07-07	Created experimental
 *	A.Solntsev			2006-11-04	extends CException
 *	A.Solntsev			2008-02-28	Added more useful constructors
 */
package hireright.sdk.actions;
import hireright.sdk.util.CException;
import hireright.sdk.util.CProperties;

/**
 * @author Daniel Travin
 * @since Jul 7, 2003
 * @version $Revision: 1.6 $ $Date: 2008/03/03 11:50:01 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/actions/ActionFailedException.java,v $
 */
public class ActionFailedException extends CException
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: asolntsev $";
	
	/**
	 * @deprecated parameter sSourceMethod is not needed anymore
	 * @param errorMessage
	 * @param sSourceMethod
	 * @param errorParameters
	 */
	public ActionFailedException(String errorMessage, String sSourceMethod, CProperties errorParameters)
	{
		super( errorMessage, errorParameters );
	}
	
	public ActionFailedException(String errorMessage, CProperties errorParameters)
	{
		super( errorMessage, errorParameters );
	}
	
	public ActionFailedException(String errorMessage, Throwable cause, CProperties errorParameters)
	{
		super( errorMessage, cause, errorParameters );
	}
	
	public ActionFailedException(Throwable cause, CProperties errorParameters)
	{
		super( cause, errorParameters );
	}
	
	public ActionFailedException(Throwable cause, CProperties errorParameters, String sData)
	{
		super( cause, errorParameters, sData );
	}

	public String getErrorMessage()
	{
		return super.getMessage();
	}

	public CProperties getErrorParameters()
	{
		return super.getProperties();
	}

	/**
	 * @deprecated This method does not take effect.
	 */
	public void setErrorSourceClass( String sourceClassName )
	{
		if (sourceClassName == null) {}
	}
}