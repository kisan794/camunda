/*
 * @(#)$RCSfile: CXMLToMapTransformer.java,v $ $Revision: 1.3 $ $Date: 2011/05/12 20:49:00 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/actions/CXMLToMapTransformer.java,v $
 *
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	L.Ruzanova			2009-01-29		created
 *	H.Lukashenka		2011-04-19		move from background_forms_servlet#hireright.project.applications.core.actions.CExtractFieldsFromApplicationXMLAction
 *										and rename to CXMLToMapTransformer
 *	H.Lukashenka		2011-05-11		getFieldMapping: add escapes Map value
 */
package hireright.sdk.actions;

import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLObjectException;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.transform.HTMLTransformer;
import hireright.sdk.util.CStringUtils;

import java.io.Serializable;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.transform.TransformerException;

/**
 * Class creates mapping between field names and values.
 *
 * @author Lyubov Ruzanova
 * @version $Revision: 1.3 $, $Date: 2011/05/12 20:49:00 $
 * @see     java.lang.Object
 */
public class CXMLToMapTransformer implements Serializable
{
	/**
	 *
	 */
	private static final long serialVersionUID = -2804158067180642172L;

	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";

	/**Name of root node in new xml format*/
	private static final String NODE_FIELDS = "Fields";

	/**Child of "Field" node which contains field's value*/
	private static final String NODE_VALUE = "Value";

	/**Child of "Field" node which contains field's name*/
	private static final String NODE_NAME = "Name";

	/**Node which contains field's name and value*/
	private static final String NODE_FIELD = "Field";

	/**URL of xslt file which transforms data xml*/
	private final String toFieldsSpecXslt;

	/**Source XML*/
	private final String sXML;

	/**
	 * Constructor sets url to xslt file and Source XML of data
	 * @param toFieldsSpecXslt - URL of xslt file which transforms data xml
	 * @param sXML - source XML
	 */
	public CXMLToMapTransformer(String toFieldsSpecXslt, String sXML)
	{
		this.toFieldsSpecXslt = toFieldsSpecXslt;
		this.sXML = sXML;
	}

	/**
	 * Method transforms data xml via xslt
	 * and gets mapping between field names and values from the new xml.
	 * @return mapping between field names and values
	 * @throws MalformedURLException
	 * @throws TransformerException
	 * @throws XMLObjectException
	 */
	public Map<String, Object> execute() throws MalformedURLException, TransformerException, XMLObjectException
	{
		XMLTreeNode rootNode = transformToFieldSpec(toFieldsSpecXslt, sXML);
		return getFieldMapping(rootNode.getChildNodeByTag( NODE_FIELDS ));
	}

	/**
	 * Method transforms data xml via xslt into the following format
	 * <Fields>
	 * 	<Field>
	 * 		<Name></Name>
	 * 		<Value></Value>
	 * 	</Field>
	 * <Fields>
	 *
	 * @param toFieldsSpecXslt - URL of transformation file
	 * @param sXML - root node of xml which should be transformed
	 * @return transformed xml
	 * @throws MalformedURLException
	 * @throws TransformerException
	 * @throws XMLObjectException
	 */
	private XMLTreeNode transformToFieldSpec(String toFieldsSpecXslt, String sXML)
		throws MalformedURLException, TransformerException, XMLObjectException
	{
		HTMLTransformer transformer = new HTMLTransformer(new java.net.URL(toFieldsSpecXslt));
		StringWriter sOut = new StringWriter();
		transformer.transform(sXML, sOut);
		XMLObject result = new XMLObject(sOut.toString());
		return result.getRootNode();
	}

	/**
	 * Parses xml and returns map where set of keys consists of field names which refer to field values.
	 *
	 * @param rootNode - root node of xml tree
	 * @return mapping between field names and values
	 */
	private Map<String, Object> getFieldMapping(XMLTreeNode rootNode)
	{
		Map<String, Object> fieldNames = new HashMap<String, Object>();
		for ( XMLTreeNode fieldNode : rootNode.getChildNodesByTag( NODE_FIELD ) )
		{
			XMLTreeNode fieldName = fieldNode.getChildNodeByTag( NODE_NAME );
			XMLTreeNode fieldValue = fieldNode.getChildNodeByTag( NODE_VALUE );
			fieldNames.put( fieldName.getText(), CStringUtils.escapeHTML(fieldValue.getText()));
		}
		return fieldNames;

	}
}
