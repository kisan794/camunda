/*
 * @(#)$RCSfile: IClassByNameResolver.java,v $ $Revision: 1.4 $ $Date: 2008/09/19 10:11:42 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/classes/resolver/IClassByNameResolver.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  D.Belorunov			2007-12-10		Created
 */
package hireright.sdk.classes.resolver;

import java.io.Serializable;

/**
 * Interface for class resolvers by it's name.
 *
 * @author Denis Belorunov
 * @version $Revision: 1.4 $ $Date: 2008/09/19 10:11:42 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/classes/resolver/IClassByNameResolver.java,v $
 */
public interface IClassByNameResolver extends Serializable
{
	/**
	 * Returns class by it's name. Exact meaning is implementation-dependent. It could be some logic
	 * name, or full class name.
	 *
	 * @param name logic name of the class.
	 * @return class instance.
	 */
	public <T> Class<T> resolve(String name);
}
