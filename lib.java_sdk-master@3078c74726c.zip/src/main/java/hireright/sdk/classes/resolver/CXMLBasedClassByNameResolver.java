/*
 * @(#)$RCSfile: CXMLBasedClassByNameResolver.java,v $ $Revision: 1.4 $ $Date: 2008/09/19 10:11:54 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/classes/resolver/CXMLBasedClassByNameResolver.java,v $
 * 
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 * 
 * This software is the confidential and proprietary information of HireRight,
 * Inc. Use is subject to license terms.
 * 
 * History: 
 * Denis Belorunov		2008-02-10		Initial revision
 */
package hireright.sdk.classes.resolver;

import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.utils.XMLUtils;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.CSystemConfigurationException;
import hireright.sdk.util.IHasProperties;

/**
 * Class for holding logic names and classes. Has methods for taking classes by their logic names.
 * Takes configuration(logicNames and classNames) from XMLTreeNode.
 *
 * @author Denis Belorunov
 * @version $Revision: 1.4 $ $Date: 2008/09/19 10:11:54 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/classes/resolver/CXMLBasedClassByNameResolver.java,v $
 */
public class CXMLBasedClassByNameResolver implements IClassByNameResolver,
		IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	/** XML node with class definitions. */
	private final XMLTreeNode m_classDefinitions;

	/** Name of node with class definitions. */
	private final String m_sClassDefinitionNodeName;
	/** Name of node containing logicName. */
	private final String m_sLogicNameNodeName;
	/** Name of node containing fullName. */
	private final String m_sFullNameNodeName;

	/** Container for generator logicName to className mapping. */
	private final CSimpleClassByNameResolver m_simpleResolver = new CSimpleClassByNameResolver();

	/**
	 * Finds out if classDefinition treeNode has necessary nodes. If checking passes, takes
	 * configuration from it.
	 *
	 * @param classDefinitions xml with class definitions.
	 * @param classDefinitionNodeName name of node with classDefinitions.
	 * @param logicNameNodeName name of node with logicName.
	 * @param fullNameNodeName name of node with full class name.
	 * @throws IllegalArgumentException in case any parameter is null.
	 * @throws CSystemConfigurationException in case of any error in XML structure.
	 */
	public CXMLBasedClassByNameResolver(XMLTreeNode classDefinitions,
			String classDefinitionNodeName, String logicNameNodeName,
			String fullNameNodeName) throws IllegalArgumentException, CSystemConfigurationException
	{
		this.m_classDefinitions = classDefinitions;
		if (classDefinitions == null)
		{
			throw new IllegalArgumentException("classDefinitions XML can't be empty");
		}

		this.m_sClassDefinitionNodeName = classDefinitionNodeName;
		if (CStringUtils.isEmpty(classDefinitionNodeName))
		{
			throw new IllegalArgumentException("classDefinitionNodeName can't be empty");
		}

		this.m_sLogicNameNodeName = logicNameNodeName;
		if (CStringUtils.isEmpty(logicNameNodeName))
		{
			throw new IllegalArgumentException("logicNameNodeName can't be empty");
		}

		this.m_sFullNameNodeName = fullNameNodeName;
		if (CStringUtils.isEmpty(fullNameNodeName))
		{
			throw new IllegalArgumentException("fullNameNodeName can't be empty");
		}

		configure();
	}

	/**
	 * Takes classes and their logic names from classDefinitions and puts them into simpleResolver.
	 *
	 * @throws CSystemConfigurationException in case of any error in XML structure.
	 */
	private final void configure() throws CSystemConfigurationException
	{
		int classDefinitionNumber = m_classDefinitions
				.getChildNodesCount(m_sClassDefinitionNodeName);

		for (int i = 1; i <= classDefinitionNumber; i++)
		{
			XMLTreeNode classDefinitionNode = m_classDefinitions
					.getChildNodeByTag(m_sClassDefinitionNodeName, i);

			String classLogicName = XMLUtils.nodeValue(classDefinitionNode
					.getChildNodeByTag(m_sLogicNameNodeName), null);
			if (CStringUtils.isEmpty(classLogicName))
			{
				throw new CSystemConfigurationException(
						"Node with logic name of the class can't be empty", this);
			}

			String className = XMLUtils.nodeValue(classDefinitionNode
					.getChildNodeByTag(m_sFullNameNodeName), null);

			if (CStringUtils.isEmpty(className))
			{
				throw new CSystemConfigurationException(
						"Node with full name of the class node can't be empty", this);
			}
			m_simpleResolver.addClass(classLogicName, className);
		}
	}

	/**
	 * Returns class by it's logic name.
	 *
	 * @param logicName logic name of the class.
	 * @return Class instance.
	 */
	public <T> Class<T> resolve(String logicName)
	{
		return m_simpleResolver.resolve(logicName);
	}

	/**
	 * Adds necessary fields and their values to properties.
	 *
	 * @return CProperties with all necessary fields and their values.
	 */
	public CProperties toProperties()
	{
		return new CProperties().setProperty("classDefinitionNodeName",
				m_sClassDefinitionNodeName).setProperty("logicNameNodeName",
				m_sLogicNameNodeName).setProperty("fullNameNodeName",
				m_sFullNameNodeName);
	}
}
