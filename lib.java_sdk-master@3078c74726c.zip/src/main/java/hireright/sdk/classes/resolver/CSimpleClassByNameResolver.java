/*
 * @(#)$RCSfile: CSimpleClassByNameResolver.java,v $ $Revision: 1.6 $ $Date: 2009/11/20 11:28:44 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/classes/resolver/CSimpleClassByNameResolver.java,v $
 * 
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 * 
 * This software is the confidential and proprietary information of HireRight,
 * Inc. Use is subject to license terms.
 * 
 * History: 
 * Denis Belorunov		2008-02-10		Initial revision
 */

package hireright.sdk.classes.resolver;

import hireright.sdk.util.CSystemConfigurationException;

import java.util.HashMap;
import java.util.Map;

/**
 * Class keeps logicNames and classes. Classes can be resolved by their logicNames.
 *
 * @author Denis Belorunov
 * @version $Revision: 1.6 $ $Date: 2009/11/20 11:28:44 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/classes/resolver/CSimpleClassByNameResolver.java,v $
 */
public class CSimpleClassByNameResolver implements IClassByNameResolver
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	/** Map containing logicName to class mapping. */
	private Map<String, Class<?>> m_logicNameToClass = new HashMap<String, Class<?>>();

	/**
	 * Adds all key-values from passed map to logicNameToClass map.
	 *
	 * @param logicNameToFullClassName map with logicName to class mappings. Is added to
	 * m_logicNameToClass map.
	 */
	public CSimpleClassByNameResolver(Map<String, String> logicNameToFullClassName)
	{
		for (Map.Entry<String, String> entry : logicNameToFullClassName.entrySet())
		{
			addClass( entry.getKey(), entry.getValue());
		}
	}

	/** Default constructor if no Map with logicNameToFullClassName mapping need to be passed. */
	public CSimpleClassByNameResolver()
	{
	}

	/**
	 * Calls addClass fot logicName and class specified by fullName.
	 *
	 * @param logicName logicName of class.
	 * @param fullName fullName of class.
	 */
	public final void addClass(String logicName, String fullName)
	{
		try
		{
			addClass(logicName, Class.forName(fullName));
		}
		catch (ClassNotFoundException e)
		{
			throw new CSystemConfigurationException(e);
		}
	}

	/**
	 * Adds logicName and clazz to logicNameToClass map.
	 *
	 * @param logicName logicName of class.
	 * @param clazz class for specified logicName.
	 */
	public final void addClass(String logicName, Class<?> clazz)
	{
		m_logicNameToClass.put(logicName, clazz);
	}

	/**
	 * Returns class by it's logic name. Or null, if such logic name is unknown.
	 *
	 * @param name logic name of the class.
	 * @return class instance, or null if such logic name is unknown.
	 */
	@SuppressWarnings("unchecked")
	public <T> Class<T> resolve(String name)
	{
		return (Class<T>) m_logicNameToClass.get(name);
	}
}
