/*
 * @(#)$RCSfile: CClosableRegistryFilter.java,v $ $Revision: 1.2 $ $Date: 2015/03/28 08:38:14 $ $Author: cvsroot $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	atanasenko	19.03.2015		Created
 *	M.Konstantinov	2017-04-21	added closing for CCurrentSessionIdentifier
 */
package hireright.sdk.servlet;

import hireright.sdk.debug.CActivityLog;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CClosableRegistry;
import hireright.sdk.util.CCurrentSessionIdentifier;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class CClosableRegistryFilter implements Filter {
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void destroy() {
	}
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
	{
		CClosableRegistry.initThreadInstance();
		try
		{
			chain.doFilter(request, response);
		}
		finally
		{
			CClosableRegistry.closeAllCurrentThread();
			CTraceLog.eraseCurrentThreadParameters();
			CActivityLog.eraseCurrentThreadParameters();
			CCurrentSessionIdentifier.clear();
		}
	}

	public static boolean isHandling()
	{
		StackTraceElement[] sts = Thread.currentThread().getStackTrace();
		String cn = CClosableRegistryFilter.class.getName();
		for(StackTraceElement st: sts)
		{
			if(st.getClassName().equals(cn)) return true;
		}
		return false;
	}

	
}
