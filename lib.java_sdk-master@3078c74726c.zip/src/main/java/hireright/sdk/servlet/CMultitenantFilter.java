/*
 * Copyright 2001-2024 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * V.Ozernov				2024-07-04	HRG-314131 Created
 */

package hireright.sdk.servlet;

import hireright.sdk.db.CMultitenantDB;
import hireright.sdk.util.CStringUtils;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class CMultitenantFilter implements Filter
{
	
	@Override public void init(FilterConfig filterConfig) throws ServletException
	{
	}
	
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
			FilterChain filterChain) throws IOException, ServletException
	{
		HttpServletRequest httpServletRequest = ((HttpServletRequest) servletRequest);
		String dbTenantCode = httpServletRequest.getHeader(CMultitenantDB.REQUEST_HEADER_DB_TENANT_CODE);
		if (CStringUtils.isEmpty(dbTenantCode))
		{
			HttpSession session = httpServletRequest.getSession(false);
			if (session != null)
			{
				dbTenantCode = (String) session.getAttribute(CMultitenantDB.USER_SESSION_ATTR_DB_TENANT_CODE);
			}
		}
		
		if (CStringUtils.isNotEmpty(dbTenantCode))
		{
			try
			{
				CMultitenantDB.execute(dbTenantCode, () -> {
					filterChain.doFilter(servletRequest, servletResponse);
					return null;
				}
				);
			}
			catch(IOException | ServletException | RuntimeException e)
			{
				throw e;
			}
			catch(Exception e)
			{
				throw new RuntimeException(e);
			}
		}
		else
		{
			//It's just for a case if the "finally" block of the previous "CMultitenantDB.execute()" was not executed due to OOM exception
			CMultitenantDB.resetTenantContext();
			
			filterChain.doFilter(servletRequest, servletResponse);
		}
	}
	
	@Override public void destroy()
	{
	}
}
