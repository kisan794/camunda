/*
 * @(#)$RCSfile: CClass.java,v $ $Revision: 1.17 $ $Date: 2015/11/02 20:15:55 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CClass.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2005-09-14	A.Solntsev		Created
 *	2006-04-26	A.Solntsev		Added utility method checkSerializable()
 *	2006-11-06	A.Solntsev		Added methods serialize() and deserialize()
 *	2006-11-06	A.Solntsev		Added method getCodeSource(String sClassName)
 *	2007-01-06	A.Solntsev		Added objects' comparision member-by-member
 *	2007-01-22	A.Solntsev		Added method searchNonSerializableMembers()
 *	2007-05-21	A.Solntsev		Fixed method equals(): returns true if both arguments are null
 *	2007-12-18	A.Solntsev		Added method getClassVersion()
 *	2008-01-11	V.Lazarev		Changes in getClassVersion(): catch all exceptions (Throwable).
 *	2008-08-28	A.Solntsev		using generics
 *	2008-12-29	A.Solntsev		Bugfix in CClass: (catch Throwable) instead of (catch Exception)
 */
package hireright.sdk.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import hireright.sdk.debug.CStackTrace;
import hireright.sdk.debug.CTraceLog;

/**
 * System utilities for getting
 * 	1. class code source,
 *  2. ...
 *
 * @author Andrei Solntsev
 * @since 2005-09-14
 * @version $Revision: 1.17 $ $Date: 2015/11/02 20:15:55 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CClass.java,v $
 */
public class CClass
{
	protected static final String CLASS_VERSION = "$Revision: 1.17 $ $Author: cvsroot $";

	private CClass()
	{
		// All methods are static
	}

	/**
	 * Method returns code source of given class.
	 * This is URL of classpath folder, zip or jar file.
	 * If code source is unknown, returns null (for example, for classes java.io.*).
	 *
	 * @param clazz	For example, <code>hireright.sdk.db.CConnection.class</code> or
	 * 							<code>fiorano.tifosi.tps.rtl.Argument.class</code>
	 * @return for example, <code>"file:/C:/jdev10/jdev/mywork/HireRight/ESB%20Services/classes/"</code>
	 * 							or <code>"file:/C:/works/projects/ESB/sdk/java/fiorano/SPRTL.zip"</code>
	 */
	public static String getCodeSource(Class<?> clazz)
	{
		URL loc = getCodeSourceLocation(clazz);
		return loc == null ? null :loc.toString();
	}
	
	public static URL getCodeSourceLocation(Class<?> clazz)
	{
		if (clazz == null ||
				clazz.getProtectionDomain() == null ||
				clazz.getProtectionDomain().getCodeSource() == null ||
				clazz.getProtectionDomain().getCodeSource().getLocation() == null)
			return null;

		return clazz.getProtectionDomain().getCodeSource().getLocation();
	}

	/**
	 * @see #getCodeSource(Class)
	 * @param sClassName Full name of class - for example, "oracle.jdbc.OracleDriver"
	 * @return error message if unable to initialize given class by name
	 * @since Nov 6, 2006
	 */
	public static String getCodeSource(String sClassName)
	{
		try
		{
			URL loc = getCodeSourceLocation(sClassName);
			return loc == null ? null :loc.toString();
		}
		catch (Throwable e)
		{
			return e.toString();
		}
	}
	public static URL getCodeSourceLocation(String sClassName) throws ClassNotFoundException
	{
		if (sClassName == null)
			return null;
		Class<?> clazz = Class.forName(sClassName);
		return getCodeSourceLocation(clazz);
	}

	public static String getClassPath()
	{
		return System.getProperty("java.class.path");
	}

	public static String getLibraryPath()
	{
		return System.getProperty("java.library.path");
	}

	public static String getJavaHome()
	{
		return System.getProperty("java.home");
	}

	/**
	 * @param obj
	 * @return serialized object (array of bytes -> String)
	 * @since java_sdk_v2-6-14
	 */
	public static String checkSerializable(Serializable obj)
	{
		return checkSerializable(obj, 256);
	}

	/**
	 * Method tries to serialize given object.
	 * If serialization failed, output warning to System.out
	 *
	 * PS. Probably it's not needed on production
	 * @param obj
	 * @param nApproxSize
	 *
	 * @since java_sdk_v2-6-8
	 * @return Serialized object
	 */
	public static String checkSerializable(Serializable obj, int nApproxSize)
	{
		java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(nApproxSize);
		try
		{
			ObjectOutputStream s = new ObjectOutputStream(out);
			s.writeObject(obj);
			s.flush();
			s.close();

			// It's ok
			String serializedObject = new String(out.toByteArray());
			return serializedObject;
		}
		catch (IOException e)
		{
			String sObj = String.valueOf(obj).substring(0, 40);
			// System.out.println("WARNING! Failed to serialize object " + sObj);
			// e.printStackTrace();
			return "WARNING! Failed to serialize object " + sObj + CStackTrace.getStackTrace(e);
		}
	}


	public static byte[] serialize(Serializable storedObject) throws IOException
	{
		java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
		try
		{
			ObjectOutputStream s = new ObjectOutputStream(out);
			s.writeObject(storedObject);
			s.flush();
			s.close();
		}
		finally
		{
			out.close();
		}

		return out.toByteArray();
	}

	public static Serializable deserialize(byte[] baSerizalizedObject) throws IOException, ClassNotFoundException
	{
		ByteArrayInputStream in = new ByteArrayInputStream(baSerizalizedObject);
		try
		{
			ObjectInputStream s = new ObjectInputStream(in);
			Serializable obj = (Serializable) s.readObject();
			s.close();
			return obj;
		}
		finally
		{
			in.close();
		}
	}

	/**
	 *
	 * @param a
	 * @param b
	 * @return true if both <code>a</code> and <code>b</code> are null
	 */
	public static boolean equals(Object a, Object b)
	{
		if (a == null && b == null)
			return true;
		else if (a == null || b == null)
			return false;
		else if (a.getClass().isArray() && b.getClass().isArray())
		{
			return compareArrays(a, b);
		}
		else
			return a.equals(b);
	}

	public static boolean equals(byte[] a, byte[] b)
	{
		if (a == null && b == null)
			return false;
		else if (a == null || b == null)
			return false;
		else if (a.length != b.length)
			return false;

		for (int i=0; i<a.length; i++)
		{
			if (a[i] != b[i])
				return false;
		}

		return true;
	}

	public static boolean equals(Collection<?> a, Collection<?> b)
	{
		if (a == null && b == null)
			return false;
		else if (a == null || b == null)
			return false;
		else if (a.size() != b.size())
			return false;

		Iterator<?> itA = a.iterator();
		Iterator<?> itB = b.iterator();
		for (; itA.hasNext() && itB.hasNext();)
		{
			if (!equals(itA.next(), itB.next()))
				return false;
		}

		return true;
	}

	public static boolean compareArrays(Object a, Object b)
	{
		if (a == null && b == null)
			return false;
		else if (a == null || b == null)
			return false;
		else if (Array.getLength(a) != Array.getLength(b))
			return false;

		for (int i=0; i<Array.getLength(a); i++)
		{
			if (!equals(Array.get(a, i), Array.get(b, i)))
				return false;
		}

		return true;
	}

	static final Object[] no_args = new Object[]{};

	private static String toStr(Object obj)
	{
		String str = String.valueOf(obj);
		if (str.length() < 60 && str.indexOf('\n') == -1)
			return str;
		int nCutLength = (str+'\n').indexOf('\n');
		if (nCutLength > 60)
			nCutLength = 60;

		return str.substring(0, nCutLength) + "...";
	}

	public static Map<?,?> compare(Object a, Object b, int nMaxDifferences)
	{
		return compare(null, "", a, b, nMaxDifferences, 0, " ", new HashSet<Object>());
	}

	/**
	 * Method checks if container contains given object.
	 * NB! Method uses only 'instance' comparision (aka ==), not using methods equals() and hashCode().
	 *
	 * @param container
	 * @param object
	 * @return true if the object has been already added into container
	 */
	private static boolean contains(Collection<?> container, Object object)
	{
		for (Iterator<?> it = container.iterator(); it.hasNext(); )
		{
			if (object == it.next())
				return true;
		}
		return false;
	}

	protected static Map<String, String> compare(Map<String, String> diff, String sPropertyName, Object a, Object b,
		int nMaxDifferences, int deep, String sIndentForDebug, Set<Object> alreadyCheckedObjects)
	{
		if (diff != null && diff.size() >= nMaxDifferences)
			return diff;
		else if (a == null && b == null)
			return diff;
		else if (a == null || b == null)
		{
			//if ((a instanceof String) && (b instanceof String) &&
			//		CStringUtils.equals((String) a, (String) b) )
			//	return diff;

			// One of objects (a, b) is null, but other is not.
			Map<String, String> newDiff = (diff != null ? diff : new HashMap<String, String>());
			newDiff.put(sPropertyName, "'" + toStr(a) + "' <> '" + toStr(b) + "'");
			return newDiff;
		}

		Class<?> comparedClass;
		if (a.getClass() == b.getClass())
			comparedClass = a.getClass();
		else if (a.getClass().isAssignableFrom(b.getClass()))
			comparedClass = a.getClass();
		else if (b.getClass().isAssignableFrom(a.getClass()))
			comparedClass = b.getClass();
		else
			throw new IllegalArgumentException("Cannot compare objects " + a + " and " + b);

		Map<String, String> newDiff = diff;

		// compare atom types
		if (comparedClass.isPrimitive() ||
			Number.class.isAssignableFrom(comparedClass) ||
			comparedClass == Boolean.class ||
			comparedClass == String.class ||
			comparedClass == Character.class ||
			comparedClass == Object.class
			/* ||
			comparedClass.isArray()*/)
		{
			if (!equals(a, b))
			{
				if (newDiff == null)
					newDiff = new HashMap<String, String>();
				newDiff.put(sPropertyName, "'" + toStr(a) + "' <> '" + toStr(b) + "'");
			}

			//System.out.println(sIndentForDebug + "/" + sPropertyName);
			return newDiff;
		}

		if (deep > 10)
		{
			return newDiff;
		}

		if (Map.class.isAssignableFrom(a.getClass()))
		{
			Map<?,?> mapA = (Map<?,?>) a;
			Map<?,?> mapB = (Map<?,?>) b;

			if (mapA.size() != mapB.size())
			{
				if (newDiff == null)
					newDiff = new HashMap<String, String>();
				newDiff.put(sPropertyName, "size.1=" + mapA.size() + " <> size.2=" + mapB.size() + "");
			}
			else if (mapA.isEmpty() && mapB.isEmpty())
			{
				return newDiff;
			}
			else
			{
				SortedSet<?> sortedKeysA = new TreeSet<Object>( mapA.keySet() );
				SortedSet<?> sortedKeysB = new TreeSet<Object>( mapB.keySet() );

				Iterator<?> itA = sortedKeysA.iterator();
				Iterator<?> itB = sortedKeysB.iterator();
				Object keyA, keyB;
				for (int i=0; itA.hasNext() && itB.hasNext(); i++)
				{
					keyA = itA.next();
					keyB = itB.next();
					String sComparedPropertyName = sPropertyName + ".elem#" + i;
					newDiff = compare(newDiff, sComparedPropertyName, mapA.get(keyA), mapB.get(keyB),
						nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects);
				}
			}

			// System.out.println(sIndentForDebug + "/" + sPropertyName);
			return newDiff;
		}

		//System.out.println(sIndentForDebug + comparedClass.getName());
		//System.out.println(sIndentForDebug + sPropertyName);

		if (Collection.class.isAssignableFrom(a.getClass()))
		{
			Collection<?> colA = (Collection<?>) a;
			Collection<?> colB = (Collection<?>) b;

			if (colA.size() != colB.size())
			{
				if (newDiff == null)
					newDiff = new HashMap<String, String>();
				newDiff.put(sPropertyName, "size.1=" + colA.size() + " <> size.2=" + colB.size() + "");
			}
			else if (colA.isEmpty() && colB.isEmpty())
			{
				return newDiff;
			}
			else
			{
				if (Set.class.isAssignableFrom(comparedClass))
				{
					// Order is not important for sets
					colA = new HashSet<Object>( colA );
					colB = new HashSet<Object>( colB );
				}

				Iterator<?> itA = colA.iterator();
				Iterator<?> itB = colB.iterator();
				for (int i=0; itA.hasNext() && itB.hasNext(); i++)
				{
					String sComparedPropertyName = sPropertyName + ".elem#" + i;
					newDiff = compare(newDiff, sComparedPropertyName, itA.next(), itB.next(),
						nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects);
				}
			}

			//System.out.println(sIndentForDebug + "/" + sPropertyName);
			return newDiff;
		}

		try
		{
			if (contains(alreadyCheckedObjects, a))
			{
				// Object a is already checked. We got here due to cyclic reference.
				return newDiff;
			}
		}
		catch (RuntimeException e)
		{
			// it may happen if some object's method hashCode() fails.
		}

		alreadyCheckedObjects.add(a);

		if (a.getClass().isArray() && b.getClass().isArray())
		{
			if (Array.getLength(a) != Array.getLength(b))
			{
				if (newDiff == null)
					newDiff = new HashMap<String, String>();
				newDiff.put(sPropertyName, "size.1=" + Array.getLength(a) + " <> size.2=" + Array.getLength(b) + "");
			}
			else
			{
				for (int i=0; i<Array.getLength(a); i++)
				{
					String sComparedPropertyName = sPropertyName + ".elem#" + i;
					newDiff = compare(newDiff, sComparedPropertyName, Array.get(a, i), Array.get(b, i),
						nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects);
				}
			}

			//System.out.println(sIndentForDebug + "/" + sPropertyName);
			return newDiff;
		}

		// compare complex objects member-by-member
		Set<Field> allFields = getFields(comparedClass, false, false);
		for (Field f : allFields)
		{
			f.setAccessible(true);

			Object valueA = null, valueB = null;
			String sComparedPropertyName = sPropertyName;
			try
			{
				valueA = f.get(a);
				valueB = f.get(b);
				sComparedPropertyName = sPropertyName + "." + f.getName();

				newDiff = compare(newDiff, sComparedPropertyName, valueA, valueB,
					nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects);
			}
			catch (Exception ex) // InvocationTargetException
			{
				// what to do?
				if (newDiff == null)
					newDiff = new HashMap<String, String>();

				// I guess all this stuff is not needed...
				CProperties params = new CProperties();
				params.setProperty("propName", sComparedPropertyName);
				params.setProperty("valueA", toStr(valueA));
				params.setProperty("valueB", toStr(valueB));
				CTraceLog.debug(CStackTrace.getStackTrace(ex), CClass.class.getName()+".compare()", params);
			}
		}

		//System.out.println(sIndentForDebug + "/" + sPropertyName);
		return newDiff;
	}


	public static String findIntersection(Object a, Object b, int nMaxDifferences)
	{
		return findIntersection("", a, b, nMaxDifferences, 0, " ", new HashSet<Object>());
	}

	protected static String findIntersection(String sPropertyName, Object a, Object b,
		int nMaxDifferences, int deep, String sIndentForDebug, Set<Object> alreadyCheckedObjects)
	{
		if (a == null && b == null)
			return sPropertyName + ": both are null";
		else if (a == null || b == null)
		{
			// One of objects (a, b) is null, but other is not.
			return null;
		}
		else if (a == b)
		{
			return sPropertyName + ": a==b";
		}

		Class<?> comparedClass;
		if (a.getClass() == b.getClass())
			comparedClass = a.getClass();
		else if (a.getClass().isAssignableFrom(b.getClass()))
			comparedClass = a.getClass();
		else if (b.getClass().isAssignableFrom(a.getClass()))
			comparedClass = b.getClass();
		else
			throw new IllegalArgumentException("Cannot compare objects " + a + " and " + b);

		// compare atom types
		if (comparedClass.isPrimitive() ||
			Number.class.isAssignableFrom(comparedClass) ||
			comparedClass == Boolean.class ||
			comparedClass == String.class ||
			comparedClass == Character.class ||
			comparedClass == Object.class
			/* ||
			comparedClass.isArray()*/)
		{
			//System.out.println(sIndentForDebug + "/" + sPropertyName);
			return null;
		}

		if (deep > 300)
		{
			return null;
		}

		if (Map.class.isAssignableFrom(a.getClass()))
		{
			Map<?,?> mapA = (Map<?,?>) a;
			Map<?,?> mapB = (Map<?,?>) b;

			if (mapA.size() != mapB.size())
			{
				//return (sPropertyName, "size.1=" + mapA.size() + " <> size.2=" + mapB.size() + "");
				return null; // ?
			}
			else if (mapA.isEmpty() && mapB.isEmpty())
			{
				return null;
			}
			else
			{
				SortedSet<?> sortedKeysA = new TreeSet<Object>( mapA.keySet() );
				SortedSet<?> sortedKeysB = new TreeSet<Object>( mapB.keySet() );

				Iterator<?> itA = sortedKeysA.iterator();
				Iterator<?> itB = sortedKeysB.iterator();
				Object keyA, keyB;
				for (int i=0; itA.hasNext() && itB.hasNext(); i++)
				{
					keyA = itA.next();
					keyB = itB.next();
					String sComparedPropertyName = sPropertyName + ".elem#" + i;
					String sIntersection = findIntersection(sComparedPropertyName, mapA.get(keyA), mapB.get(keyB),
						nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects);
					if (sIntersection != null)
						return sIntersection;
				}
			}

			// System.out.println(sIndentForDebug + "/" + sPropertyName);
			return null;
		}

		//System.out.println(sIndentForDebug + comparedClass.getName());
		//System.out.println(sIndentForDebug + sPropertyName);

		if (Collection.class.isAssignableFrom(a.getClass()))
		{
			Collection<?> colA = (Collection<?>) a;
			Collection<?> colB = (Collection<?>) b;

			if (colA.size() != colB.size())
			{
				// newDiff.put(sPropertyName, "size.1=" + colA.size() + " <> size.2=" + colB.size() + "");
				return null; //?
			}
			else if (colA.isEmpty() && colB.isEmpty())
			{
				return null;
			}
			else
			{
				if (Set.class.isAssignableFrom(comparedClass))
				{
					// Order is not important for sets
					colA = new HashSet<Object>( colA );
					colB = new HashSet<Object>( colB );
				}

				Iterator<?> itA = colA.iterator();
				Iterator<?> itB = colB.iterator();
				for (int i=0; itA.hasNext() && itB.hasNext(); i++)
				{
					String sComparedPropertyName = sPropertyName + ".elem#" + i;
					String sIntersection = findIntersection(sComparedPropertyName, itA.next(), itB.next(),
						nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects);
					if (sIntersection != null)
						return sIntersection;
				}
			}

			//System.out.println(sIndentForDebug + "/" + sPropertyName);
			return null;
		}

		try
		{
			if (contains(alreadyCheckedObjects, a))
			{
				// Object a is already checked. We got here due to cyclic reference.
				return null;
			}
		}
		catch (RuntimeException e)
		{
			// it may happen if some object's method hashCode() fails.
		}

		alreadyCheckedObjects.add(a);

		if (a.getClass().isArray() && b.getClass().isArray())
		{
			if (Array.getLength(a) != Array.getLength(b))
			{
				// newDiff.put(sPropertyName, "size.1=" + Array.getLength(a) + " <> size.2=" + Array.getLength(b) + "");
				return null; //?
			}
			else
			{
				for (int i=0; i<Array.getLength(a); i++)
				{
					String sComparedPropertyName = sPropertyName + ".elem#" + i;
					String sIntersection = findIntersection(sComparedPropertyName, Array.get(a, i), Array.get(b, i),
						nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects);
					if (sIntersection != null)
						return sIntersection;
				}
			}

			//System.out.println(sIndentForDebug + "/" + sPropertyName);
			return null;
		}

		// compare complex objects member-by-member
		Set<Field> allFields = getFields(comparedClass, false, false);
		for (Field f : allFields)
		{
			f.setAccessible(true);

			Object valueA = null, valueB = null;
			String sComparedPropertyName = sPropertyName;
			try
			{
				valueA = f.get(a);
				valueB = f.get(b);
				sComparedPropertyName = sPropertyName + "." + f.getName();

				String sIntersection = findIntersection(sComparedPropertyName, valueA, valueB,
					nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects);
				if (sIntersection != null)
					return sIntersection;
			}
			catch (Exception ex) // InvocationTargetException
			{
				// what to do?
				// I guess all this stuff is not needed...
				CProperties params = new CProperties();
				params.setProperty("propName", sComparedPropertyName);
				params.setProperty("valueA", toStr(valueA));
				params.setProperty("valueB", toStr(valueB));
				CTraceLog.debug(CStackTrace.getStackTrace(ex), CClass.class.getName()+".compare()", params);
			}
		}

		//System.out.println(sIndentForDebug + "/" + sPropertyName);
		return null;
	}

	/**
	 * Method returns set of ALL fields of given object (including private, protected
	 * and derived fields).
	 *
	 * Result does NOT include java.lang.Object fields (if any)
	 *
	 * @param clazz
	 * @param bNeedStaticFields
	 * @param bNeedTransientFields
	 * @return empty set if class doesn't have fields
	 */
	public static Set<Field> getFields(Class<?> clazz, boolean bNeedStaticFields, boolean bNeedTransientFields)
	{
		Set<Field> container = new HashSet<Field>();
		getFields(clazz, bNeedStaticFields, bNeedTransientFields, container);
		return container;
	}

	private static void getFields(Class<?> clazz, boolean bNeedStaticFields, boolean bNeedTransientFields, Set<Field> container)
	{
		if (clazz == java.lang.Object.class)
			return;

		Field[] fields = clazz.getDeclaredFields();
		for (int i=0; i<fields.length; i++)
		{
			if (!bNeedStaticFields && Modifier.isStatic( fields[i].getModifiers() ))
				continue;
			if (!bNeedTransientFields && Modifier.isTransient( fields[i].getModifiers() ))
				continue;

			container.add(fields[i]);
		}

		getFields(clazz.getSuperclass(), bNeedStaticFields, bNeedTransientFields, container);
	}

	public static String getClassVersion(String sClassName)
	{
		if (sClassName == null)
			return null;

		try
		{
			Class<?> clazz = Class.forName(sClassName);
			return getClassVersion(clazz);
		}
		catch (Throwable e)
		{
			return null;
		}
	}
	
	private static final Map<Class<?>, String> CLASS_VERSIONS = new ConcurrentHashMap<Class<?>, String>();

	public static String getClassVersion(Class<?> clazz)
	{
		String classVersion = CLASS_VERSIONS.get(clazz);
		if(classVersion == null)
		{
			synchronized(CLASS_VERSIONS)
			{
				classVersion = CLASS_VERSIONS.get(clazz);
				if(classVersion == null)
				{
					classVersion = doGetClassVersion(clazz);
					if(classVersion == null)
					{
						classVersion = "";
					}
					CLASS_VERSIONS.put(clazz, classVersion);
				}
			}
		}
		
		if("".equals(classVersion))
		{
			return null;
		}
		return classVersion;
	}

	private static String doGetClassVersion(Class<?> clazz)
	{
		String jarName = null;
		String timestamp = null;
		String commitId = null;
		
		URL classUrl = getCodeSourceLocation(clazz);
		if(classUrl != null)
		{
			InputStream in = null;
			try {
				String url = classUrl.toString();
				if(url.endsWith(".jar"))
				{
					String file = classUrl.getFile();
					int idx = file.lastIndexOf('/');
					if(idx >= 0)
					{
						jarName = file.substring(idx+1);
					}
					else
					{
						jarName = file;
					}
					
					// skip jboss internal jars
					if(jarName.startsWith("tmp") && jarName.contains("jbossweb"))
					{
						jarName = null;
					}
					
					url = "jar:" + url + "!/";
				}
				else if(!url.endsWith("/"))
				{
					url = url + "/";
				}
				url = url + "META-INF/MANIFEST.MF";
				classUrl = new URL(url);
			
				in = classUrl.openStream();
				Manifest mf = new Manifest(in);
				
				Attributes attrs = mf.getMainAttributes();
				timestamp = attrs.getValue("build-timestamp");
				commitId = attrs.getValue("scm-commit");
			}
			catch (IOException e)
			{
				// ignore
			}
			finally
			{
				if(in != null)
				{
					try{ in.close(); } catch(IOException e){}
				}
			}
		}
		
		
		String qualifier = commitId;
		if(qualifier == null || qualifier.isEmpty()) qualifier = getVersionFieldValue(clazz);
		if(qualifier == null || qualifier.isEmpty()) qualifier = timestamp;
		
		if(jarName != null)
		{
			return jarName + (qualifier != null && !qualifier.isEmpty() ? " @ " + qualifier : "");
		}
		
		return qualifier;
	}

	private static String getVersionFieldValue(Class<?> clazz)
	{
		
		String classVersion = null;
		Class<?> ec = clazz;
		while(ec != null)
		{
			try
			{
				Field f = ec.getDeclaredField( "CLASS_VERSION" );
				if (f != null)
				{
					f.setAccessible( true );
					Object value = f.get(null);
					if(value != null)
					{
						classVersion = value.toString();
						break;
					}
				}
			}
			catch (NoSuchFieldException e)
			{
			}
			catch (IllegalAccessException e)
			{
			}
			ec = ec.getEnclosingClass();
		}
		
		return classVersion;
	}

	/**
	 * Method returns set of ALL methods of given object (including private, protected
	 * and derived methods).
	 *
	 * Result does NOT include java.lang.Object methods (hashMap, equals etc.)
	 *
	 * @param clazz
	 * @param bNeedStaticMethods if true, static methods are returned too.
	 * @return empty set if class doesn't have methods.
	 */
	public static Set<Method> getMethods(Class<?> clazz, boolean bNeedStaticMethods)
	{
		Set<Method> container = new HashSet<Method>();
		getMethods(clazz, bNeedStaticMethods, container);
		return container;
	}

	private static void getMethods(Class<?> clazz, boolean bNeedStaticMethods, Set<Method> container)
	{
		if (clazz == java.lang.Object.class)
			return;

		Method[] methods = clazz.getDeclaredMethods();
		for (int i=0; i<methods.length; i++)
		{
			if (!bNeedStaticMethods && Modifier.isStatic( methods[i].getModifiers() ))
				continue;

			container.add(methods[i]);
		}

		getMethods(clazz.getSuperclass(), bNeedStaticMethods, container);
	}

	/**
	 * Method looks for all members of given class and checks each of them for being
	 * really serializable.
	 *
	 * If some non-serializable objects found, method returns Map of (String, String) pairs,
	 * when key is full name of non-serializable member.
	 *
	 * @param obj
	 * @param nMaxDifferences
	 * @return null or empty map if all members are serializable
	 */
	public static Map<String, String> searchNonSerializableMembers(Serializable obj, int nMaxDifferences)
	{
		return searchNonSerializableMembers(null, "", obj, nMaxDifferences, 0, " ", new HashSet<Object>(), "hireright.");
	}

	protected static Map<String, String> searchNonSerializableMembers(Map<String, String> diff, String sPropertyName, Object obj,
		int nMaxDifferences, int deep, String sIndentForDebug, Set<Object> alreadyCheckedObjects, String sClassNamePrefix)
	{
		if (diff != null && diff.size() >= nMaxDifferences)
			return diff;
		else if (obj == null)
			return diff;
		else if (contains(alreadyCheckedObjects, obj))
		{
			// Object a is already checked. We got here due to cyclic reference.
			return diff;
		}
		else if (deep > 10)
		{
			return diff;
		}

		// -- Store obj to 'already checked' objects
		alreadyCheckedObjects.add(obj);

		Map<String, String> newDiff = diff;

		if (!(obj instanceof Serializable))
		{
			if (newDiff == null)
				newDiff = new HashMap<String, String>();
			newDiff.put(sPropertyName, "Object " + obj + " is not serializable");
			return newDiff;
		}

		else if (Map.class.isAssignableFrom(obj.getClass()))
		{
			Map<?, ?> map = (Map<?, ?>) obj;
			int i=0;
			for (Map.Entry<?, ?> entry : map.entrySet())
			{
				String sComparedPropertyName = sPropertyName + ".elem#" + i;
				newDiff = searchNonSerializableMembers(newDiff, sComparedPropertyName, entry.getValue(),
					nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects, sClassNamePrefix);
			}

			// System.out.println(sIndentForDebug + "/" + sPropertyName);
			return newDiff;
		}

		//System.out.println(sIndentForDebug + comparedClass.getName());
		//System.out.println(sIndentForDebug + sPropertyName);

		else if (Collection.class.isAssignableFrom(obj.getClass()))
		{
			Collection<?> coll = (Collection<?>) obj;
			if (Set.class.isAssignableFrom(obj.getClass()))
			{
				// Order is not important for sets
				coll = new TreeSet<Object>( coll );
			}

			Iterator<?> it = coll.iterator();
			for (int i=0; it.hasNext(); i++)
			{
				String sComparedPropertyName = sPropertyName + ".elem#" + i;
				newDiff = searchNonSerializableMembers(newDiff, sComparedPropertyName, it.next(),
					nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects, sClassNamePrefix);
			}

			//System.out.println(sIndentForDebug + "/" + sPropertyName);
			return newDiff;
		}

		else if (obj.getClass().isArray())
		{
			for (int i=0; i<Array.getLength(obj); i++)
			{
				String sComparedPropertyName = sPropertyName + ".elem#" + i;
				newDiff = searchNonSerializableMembers(newDiff, sComparedPropertyName, Array.get(obj, i),
					nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects, sClassNamePrefix);
			}

			//System.out.println(sIndentForDebug + "/" + sPropertyName);
			return newDiff;
		}

		else if (sClassNamePrefix != null && !obj.getClass().getName().startsWith(sClassNamePrefix))
		{
			try
			{
				/*byte[] baSerializedObject = */CClass.serialize( (Serializable) obj );
			}
			catch (IOException ioe)
			{
				// Object is not serializable
				if (newDiff == null)
					newDiff = new HashMap<String, String>();
				newDiff.put(sPropertyName, ioe.toString()); // we dont' need stack trace
			}
			return newDiff;
		}

		// compare complex objects member-by-member
		Set<Field> allFields = getFields(obj.getClass(), false, false);
		for (Field f : allFields)
		{
			f.setAccessible(true);

			Object value = null;
			String sComparedPropertyName = sPropertyName;
			try
			{
				value = f.get(obj);
				sComparedPropertyName = sPropertyName + "." + f.getName();

				newDiff = searchNonSerializableMembers(newDiff, sComparedPropertyName, value,
					nMaxDifferences, deep+1, sIndentForDebug + "  ", alreadyCheckedObjects, sClassNamePrefix);
			}
			catch (Exception ex) // InvocationTargetException
			{
				// what to do?
				if (newDiff == null)
					newDiff = new HashMap<String, String>();

				// I guess all this stuff is not needed...
				CProperties params = new CProperties();
				params.setProperty("propName", sComparedPropertyName);
				params.setProperty("value", toStr(value));
				CTraceLog.debug(CStackTrace.getStackTrace(ex), CClass.class.getName()+".compare()", params);
			}
		}

		//System.out.println(sIndentForDebug + "/" + sPropertyName);
		return newDiff;
	}
	
	/**
	 * Returns class path entries as array or URLs. Useful for knowing the classpath jars at runtime.
	 * @see {@link URL#getFile()} 
	 */
	public static URL[] getClassPathEntries()
	{
		ClassLoader cl = ClassLoader.getSystemClassLoader();
		return ((URLClassLoader) cl).getURLs();
	}

}