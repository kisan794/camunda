/*
 * @(#)$RCSfile: IVisitor.java,v $ $Revision: 1.2 $ $Date: 2013/09/20 07:01:01 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/IVisitor.java,v $
 * Copyright 2013 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2013-01-01	created
 */
package hireright.sdk.util;

/**
 * Generic interface to support "Visitor" behavioral pattern.
 * @author apodlipski
 */
public interface IVisitor<T>
{
	/** Visitor must be able to "visit" (apply itself to) the target object. */
	public void applyTo(T object);
}
