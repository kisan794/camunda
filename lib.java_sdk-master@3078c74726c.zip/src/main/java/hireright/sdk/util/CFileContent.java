/*
 * @(#)$RCSfile: CFileContent.java,v $ $Revision: 1.9 $ $Date: 2010/01/08 08:52:48 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CFileContent.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	A.Solntsev		2005-04-14	created.
 *	A.Solntsev		2005-05-26	Method getContent(URL) moved here from FileReturner.
 *	A.Solntsev		2005-08-08	Added method getContentSilently(String sUrl)
 *	A.Solntsev		2010-01-06	Added URL and file name to IOException
 */
package hireright.sdk.util;
import hireright.sdk.debug.CStackTrace;
import hireright.sdk.io.IORuntimeException;
import hireright.sdk.io.IOUtils;
import hireright.sdk.net.NetTracking;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Serializable;
import java.net.URL;
import java.net.URLConnection;

/**
 * Class for reading content of file/url and returning it as a single String.
 *
 * @author Andrei Solntsev
 * @since 2005-04-14
 * @version $Revision: 1.9 $ $Date: 2010/01/08 08:52:48 $ $Author: cvsroot $
 */
public class CFileContent implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	/*
	 * TODO		Consider moving this class to package hireright.sdk.io
	 */

	/**
	 * Constructor is not needed. Use static methods.
	 */
	protected CFileContent()
	{
	}


	/**
	 * Method reads input stream line-by-line and returns output as String.
	 * NB! File should be text, not binary! It's being read line-by-line.
	 *
	 * @param inputStream
	 * @param nFileLength
	 * @return content of given input stream collected to a single string
	 * @throws java.io.IOException
	 */
	public static String getText(InputStream inputStream, int nFileLength) throws IOException
	{
		return getText(new InputStreamReader(inputStream), nFileLength);
	}

	public static String getText(File file)
	{
		return getText(file, 1024);
	}

	/**
	 * Method returns content of text file as String.
	 * @param file
	 * @param nFileLength
	 * @return content of given file collected to a single string
	 * @throws IORuntimeException
	 */
	public static String getText(File file, int nFileLength)
	{
		try
		{
			return getText(new FileReader(file), nFileLength);
		}
		catch (IOException e)
		{
			throw new IORuntimeException(e.getMessage() + ": " + file, e);
		}
	}

	/**
	 *
	 * @param reader	reader is closed after reading.
	 * @param nFileLength
	 * @return content of given reader collected to a single string
	 * @throws java.io.IOException
	 */
	protected static String getText(final Reader reader, final int nFileLength) throws IOException
	{
		try
		{
			final StringBuilder sbReturn = new StringBuilder(nFileLength);
			final BufferedReader brIn = new BufferedReader(reader);
			try
			{
				
	
				// Read & output file data
				String buf = null;
				while ( (buf = brIn.readLine()) != null)
				{
					// Read line by line and output them
					sbReturn.append(buf);
					sbReturn.append('\n');	// readline() strips these
				}
	
				// Return the content
				return sbReturn.toString();
			}
			finally
			{
				brIn.close();
				sbReturn.setLength(0);
			}
		}
		finally
		{
			if (reader != null)
			{
				reader.close();
			}			
		}
	}

	/**
	 * Returns the content of a URL as String
	 * NB! File should be text, not binary! It's being read line-by-line.
	 *
	 * @param	url		java.net.URL
	 */
	public static String getContent(URL url)
	{
		NetTracking.registerUrl(url);

		try
		{
			// Open the URL connection to read the file
			final URLConnection urlConnection = url.openConnection();
			final InputStream inputStream = urlConnection.getInputStream();
			try
			{
				return CFileContent.getText(inputStream, urlConnection.getContentLength() + 10);
			}
			finally
			{
				IOUtils.closeSilently( inputStream );
			}
		}
		catch (IOException e)
		{
			throw new IORuntimeException(e.getMessage() + ": " + url, e);
		}
	}

	/**
	 * Returns the content of a URL as String
	 * NB! File should be text, not binary! It's being read line-by-line.
	 *
	 * @param	szURL		for example, "http://www.microsoft.com/description.txt"
	 */
	public static String getContent(String szURL)
	{
		try
		{
			return getContent(new URL(szURL));
		}
		catch (IOException e)
		{
			throw new IORuntimeException(e.getMessage() + ": " + szURL, e);
		}
	}

	/**
	 * Returns the content of a URL as String, not throwing any exceptions.
	 * Used for logging errors.
	 *
	 * @param sUrl URL to grab
	 * @return stack trace of exception, if failed to read URL content
	 * @since Aug 8, 2006
	 */
	public static String getContentSilently(String sUrl)
	{
		try
		{
			return CFileContent.getContent(sUrl);
		}
		catch (IORuntimeException ioe)
		{
			return CStackTrace.getStackTrace(ioe);
		}
	}
}