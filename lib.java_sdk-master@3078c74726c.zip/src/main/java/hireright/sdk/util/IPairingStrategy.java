/*
 * @(#)$RCSfile: IPairingStrategy.java,v $ $Revision: 1.2 $ $Date: 2015/05/30 09:11:56 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/IPairingStrategy.java,v $
 * Copyright 2014-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2014-06-12	created
 * A.Podlipski		2015-05-06	switching to generics
 */
package hireright.sdk.util;

import java.util.Collection;

/**
 * Common contract for object pairing strategies.
 * @author apodlipski
 */
public interface IPairingStrategy<T, S, P>
{
	/** 
	 * Method that actually pairs specified object collections.
	 * It is OK for strategy to have auxiliary internal object collections and use them for pairing under certain conditions.  
	 */
	public Collection<P> doPairing(Collection<T> men, Collection<S> women);
}
