/*
* @(#)$RCSfile: CCompositeFilter.java,v $ $Revision: 1.5 $ $Date: 2015/03/28 08:31:37 $ $Author: cvsroot $
* $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CCompositeFilter.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev			2006-04-26	created
 *	A.Solntsev			2009-03-09	using generics
 */
package hireright.sdk.util;

/**
 * Composite filters: AND, OR, XOR
 * 
 * @author	Andrei Solntsev
 * @since java_sdk_v2-6-8
 */
public abstract class CCompositeFilter<T> implements IFilter<T>
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	public CCompositeFilter()
	{
		// constructor
	}
	
	public abstract boolean accept(T obj);
	
	/**
	 * Static factory method for creating AND composite filter based on 1..n other filters.
	 * 
	 * @param filters array of filters
	 * @return instance of CCompositeFilter
	 */
	public static <T> CCompositeFilter<T> AND(final IFilter<T>... filters)
	{
		return new CCompositeFilter<T>()
		{
			@Override
			public boolean accept(T obj)
			{
				for (IFilter<T> filter : filters)
				{
					if (!filter.accept(obj))
					{
						return false;
					}
				}
				return true;
			}
		};		
	}
	
	/**
	 * Static factory method for creating AND composite filter
	 * based on 2 given filters.
	 * 
	 * @param firstOperand IFilter, not null
	 * @param secondOperand IFilter, not null
	 * @return instance of CCompositeFilter
	 */
	public static <T> CCompositeFilter<T> AND(final IFilter<T> firstOperand,
			final IFilter<T> secondOperand)
	{
		return new CCompositeFilter<T>()
		{
			@Override
			public boolean accept(T obj)
			{
				return firstOperand.accept(obj) && 
					secondOperand.accept(obj);
			}
		};
	}
	
	/**
	 * Static factory method for creating OR composite filter
	 * based on 2 given filters.
	 * 
	 * @param firstOperand IFilter, not null
	 * @param secondOperand IFilter, not null
	 * @return instance of CCompositeFilter
	 */
	public static <T> CCompositeFilter<T> OR(final IFilter<T> firstOperand, 
			final IFilter<T> secondOperand)
	{
		return new CCompositeFilter<T>()
		{
			@Override
			public boolean accept(T obj)
			{
				return firstOperand.accept(obj) || 
					secondOperand.accept(obj);
			}
		};
	}
	
	/**
	 * Static factory method for creating XOR composite filter
	 * based on 2 given filters.
	 * 
	 * @param firstOperand IFilter, not null
	 * @param secondOperand IFilter, not null
	 * @return instance of CCompositeFilter
	 */
	public static <T> CCompositeFilter<T> XOR(final IFilter<T> firstOperand, 
			final IFilter<T> secondOperand)
	{
		return new CCompositeFilter<T>()
		{
			@Override
			public boolean accept(T obj)
			{
				return firstOperand.accept(obj) != secondOperand.accept(obj);
			}
		};
	}
}
