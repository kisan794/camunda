/*
 * @(#)$RCSfile: IGenerator.java,v $ $Revision: 1.2 $ $Date: 2015/01/10 08:55:14 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/IGenerator.java,v $
 * Copyright 2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2014-12-10	created
 */
package hireright.sdk.util;

/**
 * Common contract for all classes that have something to generate or produce.
 * @author apodlipski
 */
public interface IGenerator<T>
{
	/** Yes, it generates. */
	public T generate() throws Exception;
}
