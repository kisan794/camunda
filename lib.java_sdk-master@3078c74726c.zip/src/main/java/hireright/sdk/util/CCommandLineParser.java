/*
 * @(#)$RCSfile: CCommandLineParser.java,v $ $Revision: 1.5 $ $Date: 2008/11/21 11:31:52 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CCommandLineParser.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	D.Travin			20-Jan-2003		Created
 * 	A.Solntsev			2006-01-06		Removed deprecated APIs and classes	
 */
package hireright.sdk.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * @author      Daniel Travin
 *
 * A class that parses a command line argument string with specified options.
 * Rules:
 *      1) option must be defined only once in command line
 *      2) option must be declared like this "-option_short_name value" and
 *	      optionaly full name can be specified like this "--option_full_name=value"
 *      3) if option value is declared as not required its value cannot be specified in command line
 *      4) if option is declared as required it must exist in command line
 *      5) all options must be declared before parsing using addOption(...) method
 *      6) only one option group can be specified in command line
 *      6) optiongroups must not be empty
 *      7) optiongroup is created after calling method addOptionGroup()
 *      8) option with non-required values can be merged like this "-abcdf -rty"
 *      9) option with required values can be merged only if it is placed last like this
 *                      " --abcf filename " where "f" requires a value
 *      If something comes outside of these rules parser throws an exception.
 *
 *      Example:
 *                  CCommandLineParser parser = new CCommandLineParser( args );
 *                  parser.declareOption( "c" );
 *                  parser.declareOption( "f", "filename", false, true );
 *                  parser.addOptionGroup();
 *                  parser.declareOption( "h", "help", false, false );
 *                  parser.addOptionGroup();
 *                  try
 *                  {
 *                      parser.parse();
 *                  }
 *                  catch( Exception e )
 *                  {
 *                      System.out.println( e.getMessage() );
 *                  }
 *                  if ( parser.getOptionValue( "h" ) != null)
 *                  {
 *                      System.out.println( "User asked for help.");
 *                  }
 *                  else
 *                  {
 *                      System.out.println( "Parameter c  = ", parser.getOptionValue( "c" );
 *                      if ( parser.getOptionValue( "f" ) != null )
 *                      {
 *                          System.out.println( "Parameter filename was specified.");
 *                          System.out.println( "Filename = ", parser.getOptionValue( "f" );
 *                      }
 *                  }
 */
public class CCommandLineParser
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	private final String[] m_args;

	// number of option groups declared
	private int m_nGroupCount;

	// storage for grouped options
	// Index   : group id
	// Element : Treemap of groupOptions
	private List<SortedMap<String, Integer>> m_groups;

	// storage that contains all options in group
	// KEY    : option short name
	// VALUE  : option type ( option value is required OR option value is not required )
	private SortedMap<String, Integer> m_groupOptions;

	// storage of all required option in group
	// Index   : group id
	// Element : vector with required options for group
	private List<List<String>> m_groupRequiredOptions;

	// global storage for correspodance between
	// KEY    : option full name
	// OBJECT : option short name
	private Map<String, String> m_optionsFullNames;

	// After parsing this map is filled with option values
	// KEY    : option short name
	// OBJECT : option value
	private SortedMap<String, String> m_optionsValues;

	// option types
	private final static Integer VALUE_REQUIRED = new Integer( 0 );
	private final static Integer VALUE_NOT_REQUIRED = new Integer ( 1 );
	private final static int MAX_GROUP_COUNT = 10;

	public CCommandLineParser( String[] args )
	{
		m_args = args;
		m_nGroupCount = 0;
		m_groups = new ArrayList<SortedMap<String,Integer>>();
		m_groupRequiredOptions = new ArrayList<List<String>>(MAX_GROUP_COUNT);
		m_groupRequiredOptions.add(new ArrayList<String>());
		m_groupOptions = new TreeMap<String, Integer>();
		m_optionsFullNames = new TreeMap<String, String>();
	}

	/**
	 * Adds an option to parse..
	 * @param sShortName		    short name of an option
	 * @param sFullName		       full name of option
	 * @param bIsRequired		    boolean identifier of option needed to be set or not
	 * @param bIsValueRequired	    boolean identifier of options value needed to be set or not
	 * @return True if sShortName is not null
	 */
	public boolean declareOption( String sShortName, String sFullName,
			boolean bIsRequired, boolean bIsValueRequired )
	{
		if ( sShortName == null )
		{
			return false;
		}
		else if ( bIsValueRequired )
		{
			m_groupOptions.put( sShortName, VALUE_REQUIRED );
		}
		else
		{
			m_groupOptions.put( sShortName, VALUE_NOT_REQUIRED );
		}

		if ( sFullName != null )
		{
			m_optionsFullNames.put( sFullName, sShortName);
		}

		if ( bIsRequired )
		{
			addRequiredOption( m_nGroupCount, sShortName );
		}

		return true;
	}
	
	private void addRequiredOption(int index, String sShortName)
	{
		List<String> list = m_groupRequiredOptions.get(index);
		if (list == null)
		{
			list = new ArrayList<String>();
			m_groupRequiredOptions.add(index, list);
		}
		list.add( sShortName );
	}

	/**
	 * Defines a required option with required value to parse.
	 * @param sShortName
	 * @return True if option name is not null
	 */
	public boolean declareOption( String sShortName )
	{
		return declareOption(sShortName, null, true, true);
	}

	/**
	 * @return ID of the group if it is created else -1
	 */
	public int addOptionGroup()
	{
		if ( m_groupOptions.size() == 0)
		{
			return -1;
		}
		m_groups.add( m_groupOptions );
		m_groupOptions = new TreeMap<String, Integer>();
		m_nGroupCount++;
		m_groupRequiredOptions.add(m_nGroupCount, new ArrayList<String>());

		return m_nGroupCount - 1;
	}

	/**
	 * Parses the command line string
	 * @return Group ID of the first option.in command line.
	 * @throws java.lang.IllegalArgumentException if given cml argument is invalid
	 */
	public int parse() throws IllegalArgumentException
	{
		boolean bWaitingForOption = true;
		boolean bGroupFound = false;
		int nGroupID = -1;
		String sShortName = "";
		String sFullName = "";
		String sValue = "";

		// user error prevent
		if ( m_groupOptions.size() != 0)
		{
			addOptionGroup();
		}

		m_optionsValues = new TreeMap<String, String>();

		if ( m_args.length == 0)
			throw new IllegalArgumentException( "No command line arguments.");

		// cycle for all arguments
		for (int i=0; i < m_args.length; i++ )
		{
			if (bWaitingForOption)
			{
				if (m_args[i].startsWith("--"))
				{
					// fully named option was specified
					int nIndexOfSeparator = m_args[i].indexOf("=");
					if (nIndexOfSeparator == -1)
					{
						sFullName = m_args[i].substring( 2 );
					}
					else
					{
						sFullName = m_args[i].substring( 2, nIndexOfSeparator );
					}

					sShortName = m_optionsFullNames.get( sFullName );

					// check that there is a shortly named option corresponding to it
					if (sShortName == null)
					{
						throw new IllegalArgumentException("Unknown option '" +sFullName +"'.");
					}
					else
					{
						if ( !bGroupFound)
						{
							// find the optionsGroup which first option belongs to
							nGroupID = findGroupIDByOptionName( sShortName );
							m_groupOptions = m_groups.get( nGroupID );
							bGroupFound = true;
						}

						Integer nOptionType = m_groupOptions.get( sShortName );

						// Check that all options are from one group
						if ( nOptionType == null)
						{
							throw new IllegalArgumentException("Option '" +sShortName +"' cannot be specified in this context.");
						}
						else if ( nOptionType.equals( VALUE_REQUIRED ) )
						{
							if (nIndexOfSeparator == -1)
							{
								throw new IllegalArgumentException("Option '--" + sFullName + "' should contain "+
									"the key-value separator '='.");
							}
							// check the required value
							if (sValue == null || sValue.equals("") )
							{
								throw new IllegalArgumentException("No value specified for option '" +sFullName +"'.");
							}

							sValue = m_args[i].substring( nIndexOfSeparator + 1 );

						}
						else
						{
							// option value is not required
							sValue = new String( "" );
						}

						setOptionValue( sShortName, sValue );
					}
				}
				else if (m_args[i].startsWith("-"))
				{
					// shortly named option was specified
					sShortName = m_args[i].substring( 1 );

					if ( !bGroupFound)
					{
						// find the optionsGroup which first option belongs to
						nGroupID = findGroupIDByOptionName( sShortName );
						if ( nGroupID != -1)
						{
							m_groupOptions = m_groups.get( nGroupID );
							bGroupFound = true;
						}
						else
						{
							// Maybe this option is a merged list of options with not required value
							for (int j = 2; j < m_args[i].length(); j++)
							{
								String sHypoticShortOption = m_args[i].substring( 1, j );
								nGroupID = findGroupIDByOptionName( sHypoticShortOption );
								if ( nGroupID != -1 )
								{
									m_groupOptions = m_groups.get( nGroupID );
									bGroupFound = true;
									break;
								}
							}
							if ( !bGroupFound )
							{
								throw new IllegalArgumentException("Cannot find group for option '" + sShortName +"'.");
							}
						}
					}

					Integer nOptionType = m_groupOptions.get( sShortName );

					// Check that option is from current group
					if ( nOptionType == null)
					{
						// Maybe this option is a merged list of options with not required value
						String sHypoticShortOption;
						int nStartIndex = 1;
						List<String> mergedOptions = new ArrayList<String>();
						for (int j = 2; j <= m_args[i].length(); j++)
						{
							sHypoticShortOption = m_args[i].substring( nStartIndex, j );
							boolean bHypOptionExist = false;
							Integer nType = m_groupOptions.get( sHypoticShortOption );
							if ( nType != null)
							{
								if ( nType.equals( VALUE_NOT_REQUIRED) )
								{
									// option with nonrequired value has been found
									mergedOptions.add( sHypoticShortOption );
									nStartIndex = j;
									bHypOptionExist = true;
								}
								else if ( (j == m_args[i].length() ) && nType.equals( VALUE_REQUIRED ) )
								{
									// this is the last option and its value is required
									// So, the value will be obtained in next loop of FOR statement
                                    sShortName = sHypoticShortOption;
                                    bWaitingForOption = false;
								}
								else
								{
									throw new IllegalArgumentException( "Option '" + sHypoticShortOption +
									            "' cannot be merged with other options, because its value is required.");
								}
							}

							if ( (j == m_args[i].length() ) && bWaitingForOption  && !bHypOptionExist)
							{
								// we have reached the last symbol of string
								throw new IllegalArgumentException("Option '" +sShortName +"' cannot be specified here.");
							}
						}

						// if we have get any options with nonrequired values
						// from sShortName option, add them
						if (mergedOptions.size() != 0)
						{
							for ( String option : mergedOptions)
							{
								setOptionValue( option, CStringUtils.EMPTY_STRING );
							}
						}
						else
						{
							throw new IllegalArgumentException("Option '" +sShortName +"' cannot be specified here.");
						}
					}
					else if ( nOptionType.equals( VALUE_REQUIRED ) )
					{
						bWaitingForOption = false;
					}
					else
					{
						setOptionValue( sShortName, new String( "" ) );
					}
				}
				else
				{
					// unexpected command line argument
					throw new IllegalArgumentException( "Expected option, got '" + m_args[i] + "' .");
				}
			}
			else
			{
				// shortly named option was specified with value
				sValue = m_args[i];

				// check for syntax
				if ( sValue.startsWith( "-"))
				{
					throw new IllegalArgumentException( "Required value of option '" + sShortName + "' cannot start with symbol '-'.");
				}

				setOptionValue( sShortName, sValue );
				bWaitingForOption = true;
			}
		}

		if ( !bWaitingForOption )
		{
			// shortly  named option was specified without value
			// and end of string reached
			throw new IllegalArgumentException("Expected value for option '" +
				sShortName +"' , but end of string reached.");
		}

		// Check that all required options of this group have values
		for (String shortName : m_groupRequiredOptions.get(nGroupID))
		{
			if ( !m_optionsValues.containsKey( shortName ) )
			{
				throw new IllegalArgumentException("Required option '" + shortName +"' is not specified.");
			}
		}

		return nGroupID;
	}

	/**
	 * For private use. Set a value to option.
	 * @param sShortName
	 * @throws Exception
	 */
	private void setOptionValue( String sShortName, String sValue)
		throws IllegalArgumentException
	{
		if ( m_optionsValues.put( sShortName, sValue ) != null )
		{
			throw new IllegalArgumentException( "Dublicated definition of option '" +sShortName +"' .");
		}
	}

	/**
	 * @param sShortName
	 * @return  group ID that contains specified option or -1
	 */
	public int findGroupIDByOptionName( String sShortName )
	{
		for ( int i = 0; i < m_nGroupCount; i++ )
		{
			Map<String, Integer> options = m_groups.get( i );
			if ( options.containsKey( sShortName ) )
			{
				return i;
			}
		}

		return -1;
	}

	/**
	 * @param sShortName
	 * @return the value of command line option if the value was specified
	 * or empty string for option with no value or NULL if option has not been declared.
	 */
	public String getOptionValue( String sShortName )
	{
		return m_optionsValues.get( sShortName );
	}
}
