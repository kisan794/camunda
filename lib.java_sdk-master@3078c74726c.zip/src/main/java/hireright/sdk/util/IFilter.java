/*
 * @(#)$RCSfile: IFilter.java,v $ $Revision: 1.7 $ $Date: 2008/10/14 09:11:17 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/IFilter.java,v $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Solntsev			2005-05-20	created
 *   A.Solntsev			2005-09-01	Added constants NOT_NULL, IS_NULL.
 *   A.Solntsev			2008-08-26	using generics
 */
package hireright.sdk.util;

/**
 * Abstract interface that can either accept or not given objects.
 * Can be used for filtering Collections (selecting sublist using given criteria).
 * 
 * Additionally, class provides 2 predefined filters: one that accepts
 * all objects and another that negates all objects.
 * 
 * @author	Andrei Solntsev
 * @since		2005-05-20
 * @version $Revision: 1.7 $ $Date: 2008/10/14 09:11:17 $ $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/IFilter.java,v $
 */
public interface IFilter<T>
{
	/**
	 * Method defines whether given object is accepted.
	 * @param obj any Object
	 * @return true iff object is accepted
	 */
	boolean accept(T obj);
	
	/**
	 * Predefined filter that accepts all objects
	 */
	@SuppressWarnings("unchecked")
	public static final IFilter ACCEPT = new IFilter<Object>()
	{
		public boolean accept(Object obj){return true;}
	};

	/**
	 * Predefined filter that negates all objects
	 */
	@SuppressWarnings("unchecked")
	public static final IFilter NEGATE = new IFilter<Object>()
	{
		public boolean accept(Object obj){return false;}
	};

	/**
	 * Predefined filter that accepts all non-null objects
	 */
	@SuppressWarnings("unchecked")
	public static final IFilter NOT_NULL = new IFilter<Object>()
	{
		public boolean accept(Object obj){return obj != null;}
	};

	/**
	 * Predefined filter that accepts only null objects
	 */
	@SuppressWarnings("unchecked")
	public static final IFilter IS_NULL = new IFilter<Object>()
	{
		public boolean accept(Object obj){return obj == null;}
	};
	
	/**
	 * Predefined filter that randomly accepts objects
	 */
	@SuppressWarnings("unchecked")
	public static final IFilter WOMAN_LOGIC = new IFilter<Object>()
	{
		public boolean accept(Object obj){return Math.random() > Math.random();}
	};

	/**
	 * NO COMMENTS
	 */
	@SuppressWarnings("unchecked")
	public static final IFilter MAN_LOGIC = new IFilter<Object>()
	{
		public boolean accept(Object obj){return !WOMAN_LOGIC.accept(obj);}
	};

}