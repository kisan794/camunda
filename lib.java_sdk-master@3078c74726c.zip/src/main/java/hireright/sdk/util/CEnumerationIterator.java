/*
 * @(#)$RCSfile: CEnumerationIterator.java,v $ $Revision: 1.5 $ $Date: 2008/09/05 10:57:39 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CEnumerationIterator.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the conficdential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Solntsev				2005-09-07	created
 */
package hireright.sdk.util;
import java.util.Enumeration;
import java.util.Iterator;

/**
 * Wrapper class for transforming Enumeration to Iterator.
 * It's needed for those (old) classes that can return only Enumeration and
 * cannot return Iterator (for example, java.util.Properties).
 * 
 * @author	Andrei Solntsev
 * @since		2005-09-07
 * @version $Revision: 1.5 $, $Date: 2008/09/05 10:57:39 $, $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CEnumerationIterator.java,v $
 */
public class CEnumerationIterator<T> implements Iterator<T>
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: asolntsev $";
	
	private final Enumeration<T> m_enumeration;
	
	public CEnumerationIterator(Enumeration<T> enumeration)
	{
		m_enumeration = enumeration;
	}

	public boolean hasNext()
	{
		return m_enumeration.hasMoreElements();
	}

	public T next()
	{
		return m_enumeration.nextElement();
	}

	public void remove() throws UnsupportedOperationException
	{
		throw new UnsupportedOperationException("Enumeration doesn't support removing elements");
	}	
}