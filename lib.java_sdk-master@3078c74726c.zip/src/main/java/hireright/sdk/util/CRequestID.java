
// Copyright (c) 2001 Hireright Estonia
package hireright.sdk.util;

/**
 * A Class class.
 * <P>
 * @author Alexander Plohotnichenko
 */
public class CRequestID extends Object
{
	private int m_nReqID;
	private int m_nSubReqID;

	public CRequestID(int nReqID, int nSubReqID)
	{
		m_nReqID = nReqID;
		m_nSubReqID = nSubReqID;
	}
	public final int getReqID()
	{
		return m_nReqID;
	}

	public final int getSubReqID()
	{
		return m_nSubReqID;
	}

	public final void setReqID(int nReqID)
	{
		m_nReqID = nReqID;
	}

	public final void setSubReqID(int nSubReqID)
	{
		m_nSubReqID = nSubReqID;
	}
}

