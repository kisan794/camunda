/*
 * @(#)$RCSfile: CClosableRegistry.java,v $ $Revision: 1.4 $ $Date: 2015/03/28 08:29:20 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CClosableRegistry.java,v $
 *
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   E.Shatohhin	2011-09-15	Created
 *   M.Suhhoruki	2014-07-15	null thread local on closeAllCurrentThread + soft references to avoid classloader leaks when closeables are not closed
 *   V.Ozernov		2020-08-13	HRG-130762 Replaced soft reference with strong reference, added size limitation
 *   V.Ozernov		2021-12-12	HRG-184202 Single warning on number of closables exceeded limit
 */

package hireright.sdk.util;

import hireright.sdk.debug.CTraceLog;

import java.lang.ref.SoftReference;
import java.util.LinkedList;
import java.util.List;

/**
 * Registry to manage {@link IClosable}
 *
 * @author Evgeni Shatohhin
 */
public class CClosableRegistry
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	private static final int REGISTRY_SIZE_WARNING = 1000;
	private static final int REGISTRY_SIZE_FATAL = 10000;

	private static final ThreadLocal<CClosableRegistry> m_registry = new ThreadLocal<>();

	private List<IClosable> m_closables = new LinkedList<>();
	
	/**
	 * Returns registry for current thread
	 *
	 * @return
	 */
	public static CClosableRegistry currentThreadInstance()
	{
		return m_registry.get();
	}

	/**
	 * Initializes registry in the current thread.
	 * This method is just for compatibility with existing jars
	 * @return null
	 * @deprecated Use {@link #getOrCreateThreadInstance()}
	 */
	@Deprecated
	public static SoftReference<CClosableRegistry> initThreadInstance()
	{
			getOrCreateThreadInstance();
			return null;
	}

	/**
	 * Initializes registry in the current thread
	 */
	public static CClosableRegistry getOrCreateThreadInstance()
	{
		CClosableRegistry registry = m_registry.get();
		if (registry == null)
		{
				registry = new CClosableRegistry();
				m_registry.set(registry);
		}

		return registry;
	}
	
	/**
	 * Register given {@link IClosable}
	 *
	 * @param closable
	 */
	public void register( IClosable closable )
	{
		if (m_closables.size() == REGISTRY_SIZE_WARNING)
		{
				CTraceLog.warning("Too many items in CClosableRegistry",
						CClosableRegistry.class.getName() + ".register",
						new CProperties(CTraceLog.getCurrentThreadParameters())
							.setProperty("registry_size", m_closables.size())
							.setProperty("closable", CStringUtils.toString(closable)));
		}
		else if (m_closables.size() == REGISTRY_SIZE_FATAL)
		{
				throw new CRuntimeException("Limit of items in CClosableRegistry exceeded",
						new CProperties(CTraceLog.getCurrentThreadParameters())
							.setProperty("registry_size", m_closables.size())
							.setProperty("closable", CStringUtils.toString(closable)));
		}

		m_closables.add(closable);
	}
	
	/**
	 * Invokes close() on all registered {@link IClosable}.
	 * Handles exceptions and writes error to tracelog.
	 * When finished the registry is cleared.
	 */
	public void closeAll()
	{
		for ( IClosable closable : m_closables )
		{
			try
			{
				closable.close();
			}
			catch (Throwable e) 
			{
				CTraceLog.error( e );
			}
		}
		m_closables.clear();
	}
	
	/**
	 * Closes all registered {@link IClosable} for current thread
	 */
	public static void closeAllCurrentThread()
	{
		CClosableRegistry registry = m_registry.get();
		if (registry != null)
		{
				try
				{
						registry.closeAll();
				}
				finally
				{
						m_registry.remove();
				}
		}
	}
	
	/**
	 * Register given {@link IClosable} in current thread registry
	 *
	 * @param closable
	 */
	public static void registerCurrentThread( IClosable closable )
	{
		registerCurrentThread(closable, false);
	}
	public static void registerCurrentThread( IClosable closable, boolean strict )
	{
		CClosableRegistry registry = m_registry.get();
		if (registry == null)
		{
			if (strict)
			{
					CTraceLog.warning("Uninitialized CClosableRegistry, potential resource leaks",
					CClosableRegistry.class.getName() + ".registerCurrentThread", CTraceLog.getCurrentThreadParameters());
			}

			registry = getOrCreateThreadInstance();
		}

		registry.register(closable);
	}
}
