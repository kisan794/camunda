/*
 * @(#)$RCSfile: CRecord.java,v $ $Revision: 1.3 $ $Date: 2007/09/14 09:02:22 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	Alexander Nesterov			2004-10-20	Created
 * 	A.Solntsev					2006-11-23	implements Serializable
 */
package hireright.sdk.util;

import java.io.Serializable;

/**
 * Implementation of record with field-level access
 */
public class CRecord implements Serializable
{
	/**
	 * @serial
	 */
	protected Serializable[] m_fields;

	/**
	 * Constructs empty record
	 * @param nFieldsNumber number of fields
	 */
	public CRecord(int nFieldsNumber)
	{
		m_fields = new Serializable[nFieldsNumber];
	}

	/**
	 * Constructs record from objects array
	 * @param valuesArray record data
	 */
	public CRecord(Serializable[] valuesArray)
	{
		m_fields = valuesArray;
	}

	/**
	 * Constructs record and fills if with data from array
	 * @param valuesArray record data
	 * @param nValuesNumber number of values to copy
	 */
	public CRecord(Serializable[] valuesArray, int nValuesNumber)
	{
		m_fields = new Serializable[nValuesNumber];

		for(int i=0; i < nValuesNumber; i++)
			m_fields[i] = valuesArray[i];
	}

	/**
	 * Sets field value
	 * @param nFieldID field id
	 * @param oValue field value
	 */
	public void setValue(int nFieldID, Serializable oValue)
	{
		m_fields[nFieldID] = oValue;
	}

	/**
	 * Returns field value
	 * @param nFieldID
	 * @return field value
	 */
	public Serializable getValue(int nFieldID)
	{
		return m_fields[nFieldID];
	}

	/**
	 * Returns number of fields
	 * @return number of fields
	 */
	public int getFieldsNumber()
	{
		return m_fields.length;
	}
}