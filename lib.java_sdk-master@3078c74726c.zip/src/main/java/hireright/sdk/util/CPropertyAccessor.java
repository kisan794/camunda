/*
 * @(#)$RCSfile: CPropertyAccessor.java,v $ $Revision: 1.3 $ $Date: 2014/06/28 07:29:12 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CPropertyAccessor.java,v $
 *
 * Copyright 2001-2012 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	A.Tanasenko		23.01.2013		Created
 */
package hireright.sdk.util;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.io.Serializable;

/**
 * Provides access to javabean properties (getter/setter pair).
 * 
 * @author atanasenko
 */
public class CPropertyAccessor implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
	
	private volatile Map<String, PropertyDescriptor> properties = new HashMap<String, PropertyDescriptor>();
	
	/**
	 * Retrieves provided bean's property value
	 * @param obj
	 * @param property
	 * @return
	 */
	public String getValue(Object obj, String property)
	{
		return (String) invoke(obj, getter(obj.getClass(), property), new Object[0]);
	}
	
	/**
	 * Sets provided bean's property value
	 * @param obj
	 * @param property
	 * @param value
	 */
	public void setValue(Object obj, String property, String value)
	{
		invoke(obj, setter(obj.getClass(), property), new Object[]{ value });
	}
	
	private Object invoke(Object obj, Method m, Object[] args)
	{
		try
		{
			return m.invoke(obj, args);
		}
		catch (IllegalAccessException e)
		{
			throw new IllegalStateException(e);
		}
		catch (InvocationTargetException e)
		{
			throw new IllegalStateException(e);
		}
	}
	
	private Method getter(Class<?> clazz, String property)
	{
		return getDescriptor(clazz, property).getReadMethod();
	}

	private Method setter(Class<?> clazz, String property)
	{
		return getDescriptor(clazz, property).getWriteMethod();
	}
	
	private PropertyDescriptor getDescriptor(Class<?> clazz, String property)
	{
		
		String key = clazz.getName() + "#" + property;
		
		PropertyDescriptor pd = properties.get(key);
		
		if(pd == null)
		{
			
			synchronized(properties) {
				
				pd = properties.get(key);
				
				if(pd == null)
				{
					try
					{
						pd = new PropertyDescriptor(property, clazz);
					}
					catch (IntrospectionException e)
					{
						throw new IllegalArgumentException("No such property: " + key, e);
					}
					
				}
				
			}
			
		}
		
		return pd;
	}
	
}
