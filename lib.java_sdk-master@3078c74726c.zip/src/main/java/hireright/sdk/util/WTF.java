/*
 * @(#)$RCSfile: WTF.java,v $Revision: 1.3 $ $Date: 2010/06/03 20:49:33 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/WTF.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *   
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2010-02-16	created
 */
package hireright.sdk.util;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Indicates that class or method below has a frustrating design or name.
 * 
 * @author asolntsev
 * @version $Revision: 1.3 $ $Date: 2010/06/03 20:49:33 $ $Author: cvsroot $
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
// @Target(ElementType.METHOD)
public @interface WTF
{
	String by() default ""; 
	String comment() default "";
	String date() default "";
}
