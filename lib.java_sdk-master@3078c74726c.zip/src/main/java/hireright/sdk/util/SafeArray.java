/*
 * @(#)$RCSfile: SafeArray.java,v $ $Revision: 1.6 $ $Date: 2008/11/21 11:33:00 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/SafeArray.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Nesterov			created
 *  P.Bushuk			2005-07-06	added method delete
 *	S.Ignatov			2006-10-26	implements Serializable
 */
package hireright.sdk.util;

import java.io.Serializable;

/**
 * A SafeArray class is just exeption safe interface for java array
 *
 * @author Alexander Nesterov
 * @version $Revision: 1.6 $ $Date: 2008/11/21 11:33:00 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/SafeArray.java,v $
 */
public class SafeArray implements Serializable
{
	/**
	 * @serial
	 */
	private Serializable[] m_array;

	/**
	 * Constructor
	 */
	public SafeArray(Serializable[] array)
	{
		m_array = array;
	}

	public SafeArray(String[] asArray)
	{
		m_array = asArray;
	}

	public SafeArray(Integer[] anArray)
	{
		m_array = anArray;
	}

	public SafeArray(int nLength)
	{
		m_array = new Serializable[nLength];
	}

	/**
	 * if nIndex is wrong you'll get false value
	 */
	public boolean set(int nIndex, Serializable value)
	{
		try
		{
			m_array[nIndex] = value;
			return true;
		}
		catch (RuntimeException e)
		{
			return false;
		}
	}

	/**
	 * if nIndex is wrong you'll get null value
	 */
	public Serializable get(int nIndex)
	{
		try
		{
			return m_array[nIndex];
		}
		catch(Exception e)
		{
			return null;
		}
	}

	/**
	 * if nIndex is wrong you'll get "" value
	 */
	public String getString(int nIndex)
	{
		try
		{
			return (String) m_array[nIndex];
		}
		catch (RuntimeException e)
		{
			return "";
		}
	}

	/**
	 * if nIndex is wrong you'll get -1 value
	 */
	public Integer getInteger(int nIndex)
	{
		try
		{
			return (Integer) m_array[nIndex];
		}
		catch (RuntimeException e)
		{
			return new Integer(-1);
		}
	}

	/**
	 * if nIndex is wrong you'll get -1 value
	 */
	public int getInt(int nIndex)
	{
		try
		{
			return ((Integer) m_array[nIndex]).intValue();
		}
		catch (RuntimeException e)
		{
			return -1;
		}
	}

	public Serializable[] toArray()
	{
		return m_array;
	}

	public void delete(int nIndex)
	{
		Serializable[] tmpArray;
		if (nIndex <= length())
		{
			tmpArray = new Serializable[length()-1];
			for (int i=1; i<=tmpArray.length; i++)
			{
				if (i >= nIndex)
					tmpArray[i-1] = m_array[i];
				else
					tmpArray[i-1] = m_array[i-1];
			}
			m_array = tmpArray;
		}
	}

	public int length()
	{
		try
		{
			return m_array.length;
		}
		catch (RuntimeException e)
		{
			return 0;
		}
	}

	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder("{");
		for (int i=0; i<m_array.length; i++)
		{
			if (i > 0)
				sb.append(", ");
			sb.append(m_array[i]);
		}
		return sb.append("}").toString();
	}
}

