/*
 * @(#)$RCSfile: CHexBinaryAdapter.java,v $ $Revision: 1.3 $ $Date: 2009/09/11 13:47:55 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CHexBinaryAdapter.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	I.Suits					2008-12-08	Created.
 *	A.Solntsev			2009-09-01	Enhanced error handling (throws exception instead of returning null)
 *	M.Suhhoruki			2016-05-10	Added static methods
 */
package hireright.sdk.util;

/**
 * This class content is copied from Java 6. Copied to use the code in Java 5 applications
 *  com.sun.xml.internal.bind.DatatypeConverterImpl.java
 *  In Java6 it is used in 
 *  javax.xml.bind.annotation.adapters.HexBinaryAdapter.marshal()
 *  javax.xml.bind.annotation.adapters.HexBinaryAdapter.unmarshal()
 *  
 *  
 *  
 * @author I.Suits
 * @version $Revision: 1.3 $ $Date: 2009/09/11 13:47:55 $ $Author: cvsroot $
 */
public class CHexBinaryAdapter
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";

	private static final char[] hexCode = "0123456789ABCDEF".toCharArray();

	private static String printHexBinary( byte[] data )
	{
		StringBuilder r = new StringBuilder( data.length * 2 );
		for ( byte b : data )
		{
			r.append( hexCode[(b >> 4) & 0xF] );
			r.append( hexCode[(b & 0xF)] );
		}
		return r.toString();
	}

	private static byte[] parseHexBinary( String s )
	{
		final int len = s.length();

		// "111" is not a valid hex encoding.
		if ( len % 2 != 0 )
		{
			throw new IllegalArgumentException( "Hex string length should be even number, but received: " + s );
		}

		byte[] out = new byte[len / 2];

		for ( int i = 0; i < len; i += 2 )
		{
			int h = hexToBin( s.charAt( i ) );
			int l = hexToBin( s.charAt( i + 1 ) );
			if ( h == -1 || l == -1 )
				return null; // illegal character

			out[i / 2] = (byte)(h * 16 + l);
		}

		return out;
	}

	private static int hexToBin( char ch )
	{
		if ( '0' <= ch && ch <= '9' )
			return ch - '0';
		if ( 'A' <= ch && ch <= 'F' )
			return ch - 'A' + 10;
		if ( 'a' <= ch && ch <= 'f' )
			return ch - 'a' + 10;
		return -1;
	}

	public static byte[] fromHex(String s)
	{
		return parseHexBinary( s );
	}

	public static String toHex(byte[] bytes)
	{
		return printHexBinary( bytes );
	}
	
	@Deprecated
	public byte[] unmarshal( String s )
	{
		return parseHexBinary( s );
	}

	@Deprecated
	public String marshal( byte[] bytes )
	{
		return printHexBinary( bytes );
	}
}
