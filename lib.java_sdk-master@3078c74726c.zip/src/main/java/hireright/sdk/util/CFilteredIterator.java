/*
* @(#)$RCSfile: CFilteredIterator.java,v $ $Revision: 1.10 $ $Date: 2014/11/22 08:15:39 $ $Author: cvsroot $
* $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CFilteredIterator.java,v $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev		2005-05-20	created
 *	A.Solntsev		2005-08-24	Added static utility methods findFirst(), filterCollection().
 *	A.Solntsev		2006-01-18	Added utility method notNull().
 *	A.Solntsev		2008-08-26	Using generics
 *	M.Suhhoruki	2014-02-18	filterCollection: handle null collection without NPE
 *	M.Suhhoruki	2016-05-26	filterCollection: added nMaxAccepts
 */
package hireright.sdk.util;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Iterator that selects only those objects in given Iterator,
 * which match to given filter.
 * 
 * @author	Andrei Solntsev
 * @since		2005-05-20
 * @version $Revision: 1.10 $ $Date: 2014/11/22 08:15:39 $ $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CFilteredIterator.java,v $
 */
public class CFilteredIterator<T> implements Iterator<T>
{
	protected static final String CLASS_VERSION = "$Revision: 1.10 $ $Author: cvsroot $";
	
	private static final int UNLIM_ACCEPTS = -1;
	
	/*
	 * TODO		Possibly such functionality is implemented in Java SDK.
	 */
	private Iterator<T> m_baseIterator;
	private IFilter<T> m_filter;
	private T m_currentObject;

	/**
	 * Constructor
	 * 
	 * @param iterator	Base Iterator
	 * @param filter		filter for selecting objects from base iterator
	 */
	public CFilteredIterator(Iterator<T> iterator, IFilter<T> filter)
	{
		m_baseIterator = iterator;
		m_filter = filter;
		m_currentObject = findNearestObject();
	}
	
	public CFilteredIterator(Iterable<T> collection, IFilter<T> filter)
	{
		m_baseIterator = collection.iterator();
		m_filter = filter;
		m_currentObject = findNearestObject();
	}

	/**
	 * Method looks for a next suitable object in base iterator
	 * @return null if no more suitable objects found
	 */
	private T findNearestObject()
	{
		T nextObj;
		while (m_baseIterator.hasNext())
		{
			nextObj = m_baseIterator.next();
			if (m_filter.accept(nextObj))
				return nextObj;
		}
		
		return null;
	}
	
	/**
	 * @see java.util.Iterator.next()
	 */
	public T next()
	{
		if (m_currentObject == null)
			throw new NoSuchElementException();
		
		T retValue = m_currentObject;
		m_currentObject = findNearestObject();
		return retValue;
	}

	/**
	 * See java.util.Iterator.hasNext()
	 */
	public boolean hasNext()
	{
		return m_currentObject != null;
	}

	/**
	 * See java.util.Iterator.remove()
	 */
	public void remove()
	{
		m_baseIterator.remove();
	}
	
	
	public static <T> T findFirst(Iterator<T> it, IFilter<? super T> criteria)
	{
		T obj;
		for (; it.hasNext(); )
		{
			obj = it.next();
			if (criteria.accept(obj))
				return obj;
		}
		
		return null;
	}
	
	/**
	 * Method receives an Iterator and creates a new Iterator that iterates only
	 * not-null objects from the original iterator
	 * 
	 * @param originalIterator	any Iterator
	 * @return	Iterator over not-null objects
	 */
	@SuppressWarnings({ "cast", "unchecked" })
	public static <T> Iterator<T> notNull(Iterator<T> originalIterator)
	{
		return new CFilteredIterator<T>(originalIterator, (IFilter<T>) IFilter.NOT_NULL);
	}
	
	public static <T> List<T> filterCollection(Collection<T> originalCollection, IFilter<? super T> criteria)
	{
		return filterCollection(originalCollection, criteria, UNLIM_ACCEPTS);
	}
	
	/**
	 * Method receives an Iterator over any collection and creates another
	 * Collection (List) containing those elements from the original collection
	 * that match given criteria.
	 * 
	 * @param originalCollection	any Collection
	 * @param criteria Any predicate, @see IFilter
	 * @return List of filtered elements
	 */
	public static <T> List<T> filterCollection(Collection<T> originalCollection, IFilter<? super T> criteria, int nMaxAccepts)
	{
		if (originalCollection == null)
		{
			return null;
		}
		
		return filterCollection(originalCollection.iterator(), criteria, nMaxAccepts);
	}
	
	public static <T> List<T> filterCollection(Iterator<T> originalCollectionIterator, IFilter<? super T> criteria)
	{
		return filterCollection(originalCollectionIterator, criteria, UNLIM_ACCEPTS);
	}
	
	public static <T> List<T> filter(Iterable<T> items, IFilter<? super T> criteria)
	{
		if (items == null)
		{
			return null;
		}
		
		return filterCollection(items.iterator(), criteria, UNLIM_ACCEPTS);
	}
	
	/**
	 * Method receives an Iterator over any collection and creates another
	 * Collection (List) containing those elements from the original collection
	 * that match given criteria.
	 * 
	 * @param originalCollectionIterator	any Iterator
	 * @param criteria	Any predicate, @see IFilter
	 * @return	List of filtered elements
	 */
	public static <T> List<T> filterCollection(Iterator<T> originalCollectionIterator, IFilter<? super T> criteria, int nMaxAccepts)
	{
		if (originalCollectionIterator == null)
		{
			return null;
		}
		
		List<T> filteredList = new LinkedList<T>();
		
		T obj;
		for (; originalCollectionIterator.hasNext()
			&& (nMaxAccepts == UNLIM_ACCEPTS || filteredList.size() < nMaxAccepts);)
		{
			obj = originalCollectionIterator.next();
			if (criteria != null && criteria.accept(obj))
				filteredList.add(obj);
		}
		
		return filteredList;
	}
}