/*
 * @(#)$RCSfile: CStringUtils.java,v $ $Revision: 1.30 $ $Date: 2015/04/18 09:12:32 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CStringUtils.java,v $
 *
 * Copyright 2005-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Solntsev			2005-12-04	created
 *   A.Solntsev			2006-02-08	Added methods substringBefore(), trim(), truncate().
 *   A.Solntsev			2006-03-12	Added methods replace().
 *   A.Solntsev			2006-03-20	Added static method equals().
 *   A.Solntsev			2006-05-12	Added methods decode() (the same as in Pl/Sql)
 *   A.Solntsev			2006-05-17	Added method toString(Object[] asArray)
 *   A.Solntsev			2006-05-26	Method toString(Object[] anyArray) renamed to arrayToString().
 *   A.Solntsev			2006-08-08	Added methods decode( String, int ) (case-insensitive)
 *   A.Solntsev			2006-08-11	Added method md5_digest
 *   M.Abdulganejev		2006-09-13	java_sdk_v2-6-18: String masking methods added
 *   A.Solntsev			2006-11-03	Added method replaceWholeWord()
 *   A.Podlipski		2007-07-30	string padding implemented: padLeft() and padRight()
 *   M.Abdulganejev		2007-10-29	Added functions to check if string is number or not
 *   A.Podlipski		2008-01-18	arrayToString, stringToArray moved here from CGUIReportFilter
 *   D.Belorunov		2008-03-12	Added convertObjectListToStringList().
 *   A.Solntsev			2008-03-28	Added method listToString()
 *   E.Shatohhin		2008-05-12	Added method toStringByPattern()
 *   A.Solntsev			2008-11-14	Methods padLeft(), padRight() are not synchronized.
 *   A.Solntsev			2009-03-17	StringBuffer -> StringBuilder
 *   D.Pivovarov		2009-05-19	Added invert method
 *   E.Shatohhin		2009-08-11	Added nevlp and concat
 *   D.Murashev			2009-12-25	escapeHTML() method was added
 *   A.Solntsev			2010-02-15	Added method unescapeHTML()
 *   A.Velizhanin		2011-03-15	stringToDeQueue() added
 *   V.Polyakov			2011-05-10	MAP_HTML_ESCAPE_REPLACEMENTS.put('\'', "&apos;")
 *   								was changed to MAP_HTML_ESCAPE_REPLACEMENTS.put('\'', "&#39;") 
 *   V.Polyakov			2012-08-14	Added method nonBreakingSpaceCharacterToCode();
 *   D.Onischenko		2014-05-16	isNotEmpty added
 *   A.Podlipski		2014-05-16	EV 437122: firstNonEmpty() added
 *   I.Monahhov			2016-08-31	HIVPE-1849 added : areAnyNonEmpty(varargs String) 
 *   P.Fedyukovich	    2017-11-21	Added trimNonBreakingSpaces and replace
 *   A.Naboyshchikov	2019-11-29  HIVPE-106191: add method to check string contains arabic, thai or CJK chars
 *   V.Ozernov			2020-09-30	HRG-129108: Added isPureASCII()
 *   A.Nikolajenko		2020-12-09	HRG-134503 Romanian/Hindi Translations Round 2 - Parent Consent and Instructions with PDF support
 *   A.Nikolajenko		2021-03-11	HRG-151713 UKi: Applicant invite - Consent signed in Korean converted to PDF with blank characters
 *   A.Naboyshchikov	2022-06-03  HRG-201053: added hasHtmlTags(..)
 *   A.Naboyshchikov	2025-03-06  HRG-333242: added isEmail(..)
 */
package hireright.sdk.util;

import org.apache.xml.serializer.utils.XMLChar;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

/**
 * Utilities for working with Strings: nvl, replace etc.
 *
 * @author Andrei Solntsev
 * @version $Revision: 1.30 $ $Date: 2015/04/18 09:12:32 $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CStringUtils.java,v $
 */
@SuppressWarnings("serial")
public class CStringUtils implements Serializable
{
	public static final String EMPTY_STRING = "";
	public static final String SPACE_STRING = " ";

	protected static final String CLASS_VERSION = "$Revision: 1.30 $ $Author: cvsroot $";

	private static final String DEFAULT_MASK_SYMBOL = "*";

	public static final int LEAVE_NON_MASKED_LEFT = -1;
	public static final int LEAVE_NON_MASKED_RIGHT = 1;

	/** Padding directions. */
	private static final int LEFT = 1;
	private static final int RIGHT = 2;
	
	/** non-breaking space js character*/
	public static final String NON_BREAKING_SPACE_JS = "\u00A0"; 

	/** non-breaking space character*/
	public static final String NON_BREAKING_SPACE_CHARACTER = "&nbsp;"; 
	
	/** non-breaking space code*/
	public static final String NON_BREAKING_SPACE_CODE = "&#160;";

	private static final String THAI_REGEX = "[\\p{IsThai}].*";
	private static final String ARABIC_REGEX = "[\\p{IsArabic}].*";
	private static final String CJK_REGEX = "[\\p{IsHan}].*";
	private static final String HINDI_REGEX = "[\\p{IsDevanagari}].*";
	private static final String KOREAN_REGEX = "[\\p{IsHangul}].*";
	
	private static final Pattern THAI_CASE_INSENSITIVE_PATTERN = Pattern.compile(THAI_REGEX, Pattern.CASE_INSENSITIVE);
	private static final Pattern ARABIC_CASE_INSENSITIVE_PATTERN = Pattern.compile(ARABIC_REGEX, Pattern.CASE_INSENSITIVE);
	private static final Pattern CJK_CASE_INSENSITIVE_PATTERN = Pattern.compile(CJK_REGEX, Pattern.CASE_INSENSITIVE);
	private static final Pattern HINDI_CASE_INSENSITIVE_PATTERN = Pattern.compile(HINDI_REGEX, Pattern.UNICODE_CASE | Pattern.CANON_EQ | Pattern.CASE_INSENSITIVE);
	private static final Pattern KOREAN_CASE_INSENSITIVE_PATTERN = Pattern.compile(KOREAN_REGEX, Pattern.UNICODE_CASE | Pattern.CANON_EQ | Pattern.CASE_INSENSITIVE);
	
	private static final Pattern PURE_ASCII_PATTERN = Pattern.compile("^\\p{ASCII}*$");
	private static final String TAGS_REGEX = ".*\\<[^>]+>.*";
	private static final Pattern HTML_TAGS_PATTERN = Pattern.compile(TAGS_REGEX);
	
	private static final Pattern PATTERN_EMAIL = Pattern.compile(".*[@].*");
		/**
	 * (NVL = Non-null value)
	 * Method returns str if it's not null, and defaultValue if str is null.
	 *
	 * @param str	any String (may be null)
	 * @param defaultValue	any String (may be null)
	 * @return defaultValue if str is null
	 */
	public static String nvl(String str, String defaultValue)
	{
		return (str == null) ? defaultValue : str;
	}

	/**
	 * Method checks if str is null.
	 * If so, method returns empty string "".
	 *
	 * If str is not null, the str is returned.
	 *
	 * @param str any String (may be null)
	 * @return empty string if str is null
	 */
	public static String nvl(String str)
	{
		return nvl(str, EMPTY_STRING);
	}
	
	/**
	 * NullEmptyVaLuePrefix
	 * 
	 * An extension to NVL which also check for empty value and adds prefix if provided
	 * Usefull when constructing a coma delimited string which should only include non empty items
	 * 
	 * e.g. nvl(address1) + nevlp(", ",address2) 
	 * 
	 * @param prefix
	 * @param str
	 * @see CStringUtils.nevls()
	 * @return
	 */
	private static String nevlp(String prefix, String str)
	{
		return isEmpty( str ) ? EMPTY_STRING : nvl(prefix) + str;
	}

	/**
	 * Returns the 1st string if it isn't empty, 2nd string otherwise
	 *
	 * @param str    any String (nullable)
	 * @param defaultValue    any String (nullable)
	 * @return defaultValue if str is empty
	 * @see #nvl(String, String)
	 */
	public static String evl(String str, String defaultValue)
	{
		return isEmpty(str) ? defaultValue : str;
	}

	/**
	 * Concat two or more values with provided delimiter.
	 * Implementation is intended for small values and thus does not use
	 * StringBuffer. Do not abuse!
	 * 
	 * @param delimiter
	 * @param values
	 * @return
	 */
	public static String concat(String delimiter, String ... values)
	{
		int i;
		StringBuilder result = new StringBuilder();
		//first value
		for ( i = 0; i < values.length && result.length()==0; i++ )
		{
			result.append( nvl( values[i] ) );
		}
		//rest values with prefixed delimiter
		for ( ; i < values.length; i++ )
		{
			result.append( nevlp( delimiter, values[i] ) );
		}
		return result.toString();
	}
	
	/**
	 * Methods checks if obj is null.
	 * If so, method returns "", otherwise obj.toString().
	 *
	 * @param obj	any Object, possibly null.
	 * @return <code>obj == null ? EMPTY_STRING : obj.toString()</code>
	 */
	public static String toString(Object obj)
	{
		return (obj == null ? EMPTY_STRING : obj.toString() );
	}

	/**
	 * Methods checks if obj is null.
	 * If so, method returns "", otherwise obj.toString().
	 *
	 * @param obj	any Object, possibly null.
	 * @param defaultValue any String, not null
	 * @return <code>obj == null ? nvl(defaultValue) : obj.toString()</code>
	 */
	public static String toString(Object obj, String defaultValue)
	{
		return (obj == null ? nvl(defaultValue) : obj.toString() );
	}



	/**
	 * Method returns true iff str is null, or
	 * doesn't contain any symbols except spaces.
	 *
	 * @param str any String (may be null)
	 * @return false if str contains at least one non-space character
	 */
	public static boolean isEmpty(String str)
	{
		return (str == null || str.trim().length() < 1);
	}

	public static boolean isNotEmpty(String str)
	{
		return !isEmpty(str);
	}
	/**
	 * Returns true if array or arguments
	 * contain any non-empty strings.
	 * 
	 * Designed to check if there was any input in forms
	 * 
	 * Empty or null array will return false
	 *
	 * @param args array or varargs String (may be null)
	 * @return if at least one string is non-empty.
	 */
	public static boolean areAnyNonEmpty(String... args)
	{
		if(args == null)
		{
			return false;
		}
		return firstNonEmpty(args) != null;
	}

	public static String firstNonEmpty(String... values)
	{
		for (String s : values)
		{
			if (CStringUtils.isNotEmpty(s))
			{
				return s;
			}
		}
		return null;
	}

	/**
	 * Method gets stack trace of some exception and truncates useless tail.
	 * Formally, it finds the first occurrence of given patterns and removes
	 * this and all characters after it.
	 *
	 * @return Truncated stack trace.
	 * 					Returns the same object if it doesn't contain given pattern.
	 *
	 * @param sPattern	eg. "	at javax.servlet.http.HttpServlet.service"
	 * @param sStackTrace		Any String
	 */
	public static String substringBefore(String sStackTrace, String sPattern)
	{
		int i = sStackTrace.indexOf(sPattern);
		if (i > -1)
		{
			return sStackTrace.substring(0, i);
		}

		return sStackTrace;
	}

	public static String substringAfter(String sObject, String sSeparator)
	{
		if(isEmpty(sObject))
		{
			return sObject;
		}
		else if(sSeparator == null)
		{
			return EMPTY_STRING;
		}
		else
		{
			int nIndex = sObject.indexOf(sSeparator);
			return nIndex == -1 ? EMPTY_STRING : sObject.substring(nIndex + sSeparator.length());
		}
	}


	/**
	 * If message has length greater than nMaxLength, truncate it.
	 * For example, truncate ("abcde", 3) gives "abc".
	 *
	 * @param sMessage	any String, probably null.
	 * @param nMaxLength	any positive integer
	 * @return sMessage if it's null or shorter than nMaxLength.
	 */
	public static String truncate(String sMessage, int nMaxLength)
	{
		if (sMessage != null && sMessage.length() > nMaxLength)
			return sMessage.substring(0, nMaxLength);

		return sMessage;
	}

	/**
	 * If str is null, returns null.
	 * Otherwise, return str.trim()
	 *
	 * @param str	any String, probably null.
	 * @return <code>str == null ? null : str.trim()</code>
	 */
	public static String trim(String str)
	{
		return (str == null ? null : str.trim());
	}

	/**
	 * If str is null, returns null.
	 * Otherwise, replaces non breaking spaces and trims
	 *
	 * @param str	any String, probably null.
	 */
	public static String trimNonBreakingSpaces(String str)
	{
		String[] arr = {NON_BREAKING_SPACE_CHARACTER, NON_BREAKING_SPACE_CODE, NON_BREAKING_SPACE_JS};
		return trim(replace(str, arr, SPACE_STRING, -1));
	}
	
  /**
   * <p>Replaces a String with another String elements inside a larger String,
   * for the first <code>max</code> values of the search String.</p>
   *
   * <p>A <code>null</code> reference passed to this method is a no-op.</p>
   *
   * @param sText  text to search and replace in, may be null
   * @param searchStrings the String array to search for, may be null
   * @param sReplacement  the String to replace it with, may be null
   * @param nMax  maximum number of values to replace, or <code>-1</code> if no maximum
   * @return the text with any replacements processed,
   *  <code>null</code> if null String input
   */
	public static String replace(String sText, String[] searchStrings, String sReplacement, int nMax)
	{
		if(isEmpty(sText) || searchStrings == null || sReplacement == null || nMax == 0)
		{
			return sText;
		}
		int nStart = 0;
		int nEnd = -1;
		int nArrayIndex = 0;
		
		for(int i = 0; i < searchStrings.length; i++)
		{
			int nIndex = sText.indexOf(searchStrings[i], nStart);
			if(nEnd == -1 || nIndex < nEnd)
			{
				nArrayIndex = i;
				nEnd = nIndex;
			}
		}
		
		if(nEnd == -1)
		{
			return sText;
		}
		
		int nReplLength = searchStrings[nArrayIndex].length();
		
		StringBuffer buf = new StringBuffer();
		while(nEnd != -1)
		{
			buf.append(sText.substring(nStart, nEnd)).append(sReplacement);
			nStart = nEnd + nReplLength;
			if(--nMax == 0)
			{
				break;
			}
			nEnd = -1;
			for(int i = 0; i < searchStrings.length; i++)
			{
				int nIndex = sText.indexOf(searchStrings[i], nStart);
				if(nEnd == -1 || nIndex < nEnd)
				{
					nEnd = nIndex;
					nArrayIndex = i;
				}
			}
			nReplLength = searchStrings[nArrayIndex].length();
			nEnd = sText.indexOf(searchStrings[nArrayIndex], nStart);
		}
		buf.append(sText.substring(nStart));
		return buf.toString();
	}

	/**
	 * Since JDK 1.4, method String.replaceAll() can be used for this purpose.
	 *
	 * @param str
	 * @param match
	 * @param replacement
	 * @return String str in which all substrings <match> are replaced to <replacement>
	 */
	public static String replace(String str, String match, String replacement)
	{
		return replace(new StringBuilder(str), match, replacement).toString();
	}

	/**
	 * @deprecated Use method {@link #replace(StringBuilder, String, String)} since StringBuilder
	 * 	is more preferred that StringBuffer in most cases.
	 *
	 * @param sb
	 * @param match
	 * @param replacement
	 * @return StringBuffer sb in which all substrings <match> are replaced to <replacement>
	 */
	public static StringBuffer replace(StringBuffer sb, String match, String replacement)
	{
		int i = sb.indexOf(match);
		while (i > -1)
		{
			sb.replace(i, i+match.length(), replacement);
			i = sb.indexOf(match, i + replacement.length());
		}

		return sb;
	}

	/**
	 * @param sb
	 * @param match
	 * @param replacement
	 * @return StringBuffer sb in which all substrings <match> are replaced to <replacement>
	 */
	public static StringBuilder replace(StringBuilder sb, String match, String replacement)
	{
		int i = sb.indexOf(match);
		while (i > -1)
		{
			sb.replace(i, i+match.length(), replacement);
			i = sb.indexOf(match, i + replacement.length());
		}

		return sb;
	}


	public static String replaceWholeWord(String str, String match, String replacement)
	{
		return replaceWholeWord(new StringBuilder(str), match, replacement).toString();
	}

	/**
	 * @deprecated Use method {@link #replaceWholeWord(StringBuilder, String, String)} since StringBuilder
	 * 	is more preferred that StringBuffer in most cases.
	 *
	 * @param sb
	 * @param match
	 * @param replacement
	 * @return
	 */
	public static StringBuffer replaceWholeWord(StringBuffer sb, String match, String replacement)
	{
		int i = sb.indexOf(match);
		char nextChar, prevChar;
		boolean bCharBefore = true, bCharAfter = true;
		while (i > -1)
		{
			if (i+match.length() > sb.length())
				throw new RuntimeException("match is longer than match");// it cannot happen

			bCharAfter = (i+match.length() == sb.length());
			if (!bCharAfter)
			{
				nextChar = sb.charAt(i+match.length());
				bCharAfter = isDivider(nextChar);
			}

			bCharBefore = (i == 0);
			if (!bCharBefore)
			{
				prevChar = sb.charAt(i-1);
				bCharBefore = isDivider(prevChar);
			}

			if ( bCharBefore && bCharAfter )
			{
				sb.replace(i, i+match.length(), replacement);
				i = sb.indexOf(match, i + replacement.length());
			}
			else
			{
				i = sb.indexOf(match, i + match.length());
			}
		}

		return sb;
	}

	public static StringBuilder replaceWholeWord(StringBuilder sb, String match, String replacement)
	{
		int i = sb.indexOf(match);
		char nextChar, prevChar;
		boolean bCharBefore = true, bCharAfter = true;
		while (i > -1)
		{
			if (i+match.length() > sb.length())
				throw new RuntimeException("match is longer than match");// it cannot happen

			bCharAfter = (i+match.length() == sb.length());
			if (!bCharAfter)
			{
				nextChar = sb.charAt(i+match.length());
				bCharAfter = isDivider(nextChar);
			}

			bCharBefore = (i == 0);
			if (!bCharBefore)
			{
				prevChar = sb.charAt(i-1);
				bCharBefore = isDivider(prevChar);
			}

			if ( bCharBefore && bCharAfter )
			{
				sb.replace(i, i+match.length(), replacement);
				i = sb.indexOf(match, i + replacement.length());
			}
			else
			{
				i = sb.indexOf(match, i + match.length());
			}
		}

		return sb;
	}

	public static boolean isDivider(char c)
	{
		return " ,.:;()'\"".indexOf(c) > -1;
	}

	/**
	 * Null-safe check for equal strings.
	 *
	 * @param a	any string, probably null.
	 * @param b any string, probably null.
	 * @return true iff both strings are null or a.equals(b)
	 */
	public static boolean equals(String a, String b)
	{
		return a == b || (a != null && a.equals(b));
	}

	/**
	 * Null-safe check for equal strings (ignoring case).
	 *
	 * @param a	any string, probably null.
	 * @param b any string, probably null.
	 * @return true iff both strings are null or a.equals(b)
	 */
	public static boolean equalsIgnoreCase(String a, String b)
	{
		return (a == null && b == null) ||
				(a != null && a.equalsIgnoreCase(b));
	}
	
	/**
	 * Compares two strings case-insensitive. {@code null} and empty values considered equals.
	 *
	 * @param a first string
	 * @param b second string
	 * @return {@code true} if both strings a and b are {@link #isEmpty(String) empty}
	 *         or the string a equals to the string b ignoring case
	 */
	public static boolean equalsOrEmptyIgnoreCase(String a, String b)
	{
		return isEmpty(a) ? isEmpty(b) : a.equalsIgnoreCase(b);
	}	

	/**
	 * Analog of Pl/Sql function 'DECODE'.
	 * NB! Method is case-insensitive!
	 *
	 * @param sSource
	 * @param sMatch1
	 * @param sReplace1
	 * @param sDefaultValue
	 * @return sDefaultValue if sSource != sMatch1
	 */
	public static String decode(String sSource,
			String sMatch1, String sReplace1, String sDefaultValue)
	{
		if (CStringUtils.equalsIgnoreCase(sSource, sMatch1))
			return sReplace1;
		return sDefaultValue;
	}

	/**
	 * Analog of Pl/Sql function 'DECODE'.
	 * NB! Method is case-insensitive!
	 *
	 * @param sSource
	 * @param sMatch1
	 * @param nReplace1
	 * @param nDefaultValue
	 * @return either <code>nReplace1</code> or <code>nDefaultValue</code>
	 */
	public static int decode(String sSource,
			String sMatch1, int nReplace1, int nDefaultValue)
	{
		if (CStringUtils.equalsIgnoreCase(sSource, sMatch1))
			return nReplace1;

		return nDefaultValue;
	}

	/**
	 * Analog of Pl/Sql function 'DECODE'.
	 * NB! Method is case-insensitive!
	 *
	 * @param sSource
	 * @param sMatch1
	 * @param sReplace1
	 * @param sMatch2
	 * @param sReplace2
	 * @param sDefaultValue
	 * @return sDefaultValue if sSource not in (sMatch1, sMatch2)
	 */
	public static String decode(String sSource,
			String sMatch1, String sReplace1,
			String sMatch2, String sReplace2, String sDefaultValue)
	{
		if (CStringUtils.equalsIgnoreCase(sSource, sMatch1))
			return sReplace1;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch2))
			return sReplace2;

		return sDefaultValue;
	}

	/**
	 * Analog of Pl/Sql function 'DECODE'.
	 * NB! Method is case-insensitive!
	 *
	 * @param sSource
	 * @param sMatch1
	 * @param nReplace1
	 * @param sMatch2
	 * @param nReplace2
	 * @param nDefaultValue
	 * @return Either nReplace1, nReplace2 or nDefaultValue
	 */
	public static int decode(String sSource,
			String sMatch1, int nReplace1,
			String sMatch2, int nReplace2, int nDefaultValue)
	{
		if (CStringUtils.equalsIgnoreCase(sSource, sMatch1))
			return nReplace1;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch2))
			return nReplace2;
		return nDefaultValue;
	}

	/**
	 * Analog of Pl/Sql function 'DECODE'.
	 * NB! Method is case-insensitive!
	 *
	 * @param sSource
	 * @param sMatch1
	 * @param sReplace1
	 * @param sMatch2
	 * @param sReplace2
	 * @param sMatch3
	 * @param sReplace3
	 * @param sDefaultValue
	 * @return sDefaultValue if sSource not in (sMatch1, sMatch2, sMatch3)
	 */
	public static String decode(String sSource,
			String sMatch1, String sReplace1,
			String sMatch2, String sReplace2,
			String sMatch3, String sReplace3, String sDefaultValue)
	{
		if (CStringUtils.equalsIgnoreCase(sSource, sMatch1))
			return sReplace1;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch2))
			return sReplace2;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch3))
			return sReplace3;
		return sDefaultValue;
	}

	/**
	 * Analog of Pl/Sql function 'DECODE'.
	 * NB! Method is case-insensitive!
	 *
	 * @param sSource
	 * @param sMatch1
	 * @param nReplace1
	 * @param sMatch2
	 * @param nReplace2
	 * @param sMatch3
	 * @param nReplace3
	 * @param nDefaultValue
	 * @return Either nReplace1, nReplace2, nReplace3 or nDefaultValue
	 */
	public static int decode(String sSource,
			String sMatch1, int nReplace1,
			String sMatch2, int nReplace2,
			String sMatch3, int nReplace3, int nDefaultValue)
	{
		if (CStringUtils.equalsIgnoreCase(sSource, sMatch1))
			return nReplace1;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch2))
			return nReplace2;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch3))
			return nReplace3;

		return nDefaultValue;
	}

	/**
	 * Analog of Pl/Sql function 'DECODE'.
	 * NB! Method is case-insensitive!
	 *
	 * @param sSource
	 * @param sMatch1
	 * @param sReplace1
	 * @param sMatch2
	 * @param sReplace2
	 * @param sMatch3
	 * @param sReplace3
	 * @param sMatch4
	 * @param sReplace4
	 * @param sDefaultValue
	 * @return sDefaultValue if sSource not in (sMatch1, sMatch2, sMatch3, sMatch4)
	 */
	public static String decode(String sSource,
			String sMatch1, String sReplace1,
			String sMatch2, String sReplace2,
			String sMatch3, String sReplace3,
			String sMatch4, String sReplace4, String sDefaultValue)
	{
		if (CStringUtils.equalsIgnoreCase(sSource, sMatch1))
			return sReplace1;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch2))
			return sReplace2;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch3))
			return sReplace3;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch4))
			return sReplace4;

		return sDefaultValue;
	}

	/**
	 * Analog of Pl/Sql function 'DECODE'.
	 * NB! Method is case-insensitive!
	 *
	 * @param sSource
	 * @param sMatch1
	 * @param nReplace1
	 * @param sMatch2
	 * @param nReplace2
	 * @param sMatch3
	 * @param nReplace3
	 * @param sMatch4
	 * @param nReplace4
	 * @param nDefaultValue
	 * @return nDefaultValue if sSource not in (sMatch1, sMatch2, sMatch3, sMatch4)
	 */
	public static int decode(String sSource,
			String sMatch1, int nReplace1,
			String sMatch2, int nReplace2,
			String sMatch3, int nReplace3,
			String sMatch4, int nReplace4, int nDefaultValue)
	{
		if (CStringUtils.equalsIgnoreCase(sSource, sMatch1))
			return nReplace1;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch2))
			return nReplace2;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch3))
			return nReplace3;
		else if (CStringUtils.equalsIgnoreCase(sSource, sMatch4))
			return nReplace4;

		return nDefaultValue;
	}

	/**
	 * @deprecated	Use method arrayToString(Object[] anyArray)  -  it has better name
	 */
	public static String toString(Object[] anyArray)
	{
		return arrayToString(anyArray);
	}

	/**
	 * Given an array of objects, method returns a single String containing all these objects: "{a, b, c}"
	 *
	 * @param anyArray array of any objects. Method toString() will be applied on its elements
	 * @return For instance, "{a1, a2, a3, a4}"
	 *
	 * @since java_sdk_v2-6-9
	 */
	public static String arrayToString(Object[] anyArray)
	{
		StringBuilder sb = new StringBuilder(5*anyArray.length).append("{");
		for (int i=0; i<anyArray.length; i++)
		{
			if (i > 0)
				sb.append(", ");
			sb.append(anyArray[i]);
		}

		sb.append("}");
		return sb.toString();
	}

	public static String arrayToString(String[] array, String delimiter)
	{
		return arrayToString( (Object[]) array, delimiter);
	}

	/**
	 * Packs an array into string, separating elements with specified delimiter.
	 * @param array Array of Strings.
	 * @param delimiter String to be used as separator.
	 * @return string
	 */
	public static String arrayToString(Object[] array, String delimiter)
	{
		StringBuilder sbResult = new StringBuilder();
		if (array != null)
		{
			int cnt = 0;
			for (int i=0; i<array.length; sbResult.append(array[i++]).append(delimiter))
			{
				assert ++cnt < 10000 : "Infinite loop";
			}
		}

		return sbResult.toString();
	}

	public static <T> String listToString(Collection<T> array)
	{
		return listToString(array, ", ");
	}

	public static <T> String listToString(Collection<T> array, String delimiter)
	{
		StringBuilder sbResult = new StringBuilder();
		if (array != null && !array.isEmpty())
		{
			boolean isFirstElement = true;
			for (T element : array)
			{
				if (!isFirstElement)
				{
					sbResult.append(delimiter);
				}
				sbResult.append(element);
				isFirstElement = false;
			}
		}

		return sbResult.toString();
	}

	/**
	 * Reconstructs the array from string
	 * @param str
	 * @return string array
	 */
	public static String[] stringToArray(String str, String delimiter)
	{
		List<String> v = new ArrayList<String>();
		if (str != null)
		{
			StringTokenizer tokenizer = new StringTokenizer(str, delimiter);
			while (tokenizer.hasMoreTokens())
			{
				v.add(tokenizer.nextToken());
			}
		}
		return v.toArray(new String[v.size()]);
	}
	
	/**
	 * Reconstructs the <code>Stack</code> from string
	 * this way "1;2;3" string become to 
	 * "3"
	 * "2"
	 * "1"
	 * deque (stack)
	 * @param str
	 * @return <code>Stack</code> of <code>String</code> objects
	 */
	public static Stack<String> stringToStack(String str, String delimiter)
	{
		Stack<String> deque = new Stack<String>();
		if (str != null)
		{
			StringTokenizer tokenizer = new StringTokenizer(str, delimiter);
			while (tokenizer.hasMoreTokens())
			{
				deque.push(tokenizer.nextToken());
			}
		}
		return deque;
	}

	/**
	 * Serialize <code>Stack</code> to string
	 * this way:   
	 * "3"
	 * "2"
	 * "1"
	 * stack become to "1;2;3" string 
	 * @param deque
	 * @param delimiter
	 * @return <code>String</code> contains serialized deque
	 */
	public static String stackToString(Stack<String> deque, String delimiter)
	{
		String str = new String();
		if (deque != null && !deque.isEmpty())
		{
			String [] arrString = new String[deque.size()];
			deque.copyInto(arrString);
			for (int i = 0; i < arrString.length; i++)
			{
				if (i > 0)
				{
					str += delimiter;
				}
				str += arrString[i];
			}
		}
		return str;
	}


	private static final String MD5 = "MD5";
	private static final String ZERO_DIGIT = "0";

	/**
	 * Calculates MD5 hash for given data chunk.
	 *
	 * @param sData any string data
	 * @return 32-character hexadecimal uppercase string key.
	 *
	 * @throws RuntimeException if crypting algorithm "MD5" is not available (is not registered)
	 * @since Aug 11, 2006
	 */
	public static String md5_digest(String sData)
	{
		MessageDigest md;
		try
		{
			md = MessageDigest.getInstance(MD5);
		}
		catch (NoSuchAlgorithmException alg_ex)
		{
			// TODO Add more properties for logging (code source, list of available algorithms etc.)
			throw new CRuntimeException("Failed to apply crypting algorithm " + MD5,
					alg_ex, null);
		}

		md.update(sData.getBytes());
		byte[] bHash = md.digest();

		String sHex;
		StringBuilder sbKey = new StringBuilder(2*bHash.length);
		for (int i=0; i<bHash.length; i++)
		{
			int n = bHash[i];
			sHex = Integer.toHexString((n + 0x100)%0x100);
			sbKey.append(sHex.length() < 2 ? ZERO_DIGIT : EMPTY_STRING);
			sbKey.append(sHex);
		}

		return sbKey.toString().toUpperCase();
	}

	/**
	 * masks string with default symbol '*' <i>(white spaces and '-' are not masked)</i><br/><br/>
	 * For example:<br>
	 * mask("S123-sd2# 324") will return "****-**** ***"
	 *
	 * @param sStringToMask string to be masked
	 * @return masked input string
	 */
	public static String mask(String sStringToMask)
	{
		return mask(sStringToMask, DEFAULT_MASK_SYMBOL);
	}

	/**
	 * masks string with provided symbol
	 * @see #mask(String sStringToMask) for further exmplanation
	 * @param sStringToMask string to be masked
	 * @param sMaskChar symbols to mask string chars with
	 * @return masked input string
	 */
	public static String mask(String sStringToMask, String sMaskChar)
	{
		return maskLeavingNonMaskedLeft(0, sStringToMask, sMaskChar);
	}

	/**
	 * mask string with default symbol leaving first nNonMaskedChNum characters as non masked
	 * @param nNonMaskedChNum number of string character to be left unmasked
	 * @param sStringToMask string to be masked
	 * @return masked input string
	 */
	public static String maskLeavingNonMaskedLeft(int nNonMaskedChNum, String sStringToMask)
	{
		return maskLeavingNonMaskedLeft(nNonMaskedChNum, sStringToMask, DEFAULT_MASK_SYMBOL);
	}

	/**
	 *  mask string with default symbol leaving last nNonMaskedChNum characters as non masked
	 * @param nNonMaskedChNum number of string character to be left unmasked
	 * @param sStringToMask string to be masked
	 * @return masked input string
	 */
	public static String maskLeavingNonMaskedRight(int nNonMaskedChNum, String sStringToMask)
	{
		return maskLeavingNonMaskedRight(nNonMaskedChNum, sStringToMask, DEFAULT_MASK_SYMBOL);
	}

	/**
	 * mask string with provided sybol(sMaskChar) symbol leaving first nNonMaskedChNum characters as non masked
	 * @param nNonMaskedChNum number of string character to be left unmasked
	 * @param sStringToMask string to be masked
	 * @param sMaskChar symbols to mask string chars with
	 * @return masked input string
	 */
	public static String maskLeavingNonMaskedLeft(int nNonMaskedChNum, String sStringToMask, String sMaskChar)
	{
		return mask(nNonMaskedChNum, sStringToMask, LEAVE_NON_MASKED_LEFT, sMaskChar);
	}

	/**
	 * mask string with provided symbol(sMaskChar) symbol leaving last nNonMaskedChNum characters as non masked
	 * @param nNonMaskedChNum number of string character to be left unmasked
	 * @param sStringToMask string to be masked
	 * @param sMaskChar symbols to mask string chars with
	 * @return masked input string
	 */
	public static String maskLeavingNonMaskedRight(int nNonMaskedChNum, String sStringToMask, String sMaskChar)
	{
		return mask(nNonMaskedChNum, sStringToMask, LEAVE_NON_MASKED_RIGHT, sMaskChar);
	}

	/**
	 * masks string according to provided parameters
	 * @param nNonMaskedChNum number of string character to be left unmasked
	 * @param sStringToMask string to be masked
	 * @param nCharNonMaskingDirection determines where to leave chars as unmasked
	 *  starting from left -  CStringUtils.LEAVE_NON_MASKED_LEFT, right - CStringUtils.LEAVE_NON_MASKED_RIGHT
	 * @param sMaskChar symbols to mask string chars with
	 * @return masked input string
	 */
	private static String mask(int nNonMaskedChNum, String sStringToMask, int nCharNonMaskingDirection, String sMaskChar)
	{
		String szResultString = EMPTY_STRING;
		try
		{
			if (sStringToMask.length() > nNonMaskedChNum)
			{
				//any character except '-' or whitespace chars
				String pattern = "[^\\-\\s]";

				if(nCharNonMaskingDirection == LEAVE_NON_MASKED_LEFT )
				{
					szResultString = sStringToMask.substring(0, nNonMaskedChNum)
						+ sStringToMask.substring(nNonMaskedChNum).replaceAll(pattern, sMaskChar);
				}
				else if(nCharNonMaskingDirection == LEAVE_NON_MASKED_RIGHT)
				{
					szResultString = sStringToMask.substring(0, sStringToMask.length() - nNonMaskedChNum).replaceAll(pattern, sMaskChar)
						+ sStringToMask.substring(sStringToMask.length() - nNonMaskedChNum);
				}
			}
			else
			{
				szResultString = sStringToMask;
			}
			return szResultString;
		}
		catch(Exception e)
		{
			return EMPTY_STRING;
		}
	}

	/**
	 * Pads specified string with specified character from the left.
	 * Example: padLeft("124FB", '0', 9) will return "0000124FB".
	 * @param source String to be padded.
	 * @param paddingCharacter character to pad a string with.
	 * @param length Length of the desired padded string.
	 * @return source string left-padded with specified characters.
	 */
	public static String padLeft(String source, char paddingCharacter, int length)
	{
		return pad(source, LEFT, paddingCharacter, length);
	}

	/**
	 * Pads specified string with specified character from the right.
	 * Example: padRight("124FB", '0', 9) will return "124FB0000".
	 * @param source String to be padded.
	 * @param paddingCharacter character to pad a string with.
	 * @param length Length of the desired padded string.
	 * @return source string right-padded with specified characters.
	 */
	public static String padRight(String source, char paddingCharacter, int length)
	{
		return pad(source, RIGHT, paddingCharacter, length);
	}

	private static String pad(
		String source, int paddingDirection, char paddingCharacter, int length)
	{
		if (source != null)
		{
			StringBuilder padding = new StringBuilder();
			if (paddingDirection == RIGHT)
				padding.append(source);

			for(int i=0; i<length-source.length(); i++)
			{
				padding.append(paddingCharacter);
			}
			if (paddingDirection == LEFT)
				padding.append(source);

			return padding.toString();
		}
		else
		{
			return null;
		}
	}

	/**
	 *
	 * @param sStringToCheck string to be checked if it represents number
	 * (may contain negative number sign  i.e. '-') or not
	 * @return true if String is a number, false - otherwise
	 */
	public static boolean isNumber(String sStringToCheck)
	{
		return isNumber(sStringToCheck, false);
	}


	/**
	 * @param sStringToCheck string to be checked if it represents number or not
	 * @param nSupportPositiveSign true if string may contain positive number sign('+')
	 * @return true if String is a number, false - otherwise
	 */
	public static boolean isNumber(String sStringToCheck, boolean nSupportPositiveSign)
	{
		//return false if string is empty or null
		if (isEmpty(sStringToCheck))
		{
			return false;
		}

		boolean bContainsSignSymbol =
			(sStringToCheck.charAt(0) == '-') ||
				(nSupportPositiveSign && sStringToCheck.charAt(0) == '+');

		/* check if all chars starting from second(in case of negative number) or first
		 * (in case of positive) are digits
		 */
		for (int i = (bContainsSignSymbol ? 1 : 0), j = sStringToCheck.length(); i < j; i++)
		{
			if (!Character.isDigit(sStringToCheck.charAt(i)))
			{
				return false;
			}
		}

		//looks like evaluated string is a number
		return true;
	}


	/**
	 * @param sStringToCheck String to be checked if it can be converted into boolean value
	 * @return true if string can be converted into boolean value (false or true), false - otherwise
	 */
	public static boolean isBoolean(String sStringToCheck)
	{
		return (CStringUtils.equals(sStringToCheck, Boolean.FALSE.toString()) ||
				equals(sStringToCheck, Boolean.TRUE.toString()));

	}

	/**
	 * Converts list with arbitrary objects into list with strings representations.
	 *
	 * @param objectList list with objects.
	 * @return List with String instances.
	 */
	public static <T> List<String> convertObjectListToStringList(List<T> objectList)
	{
		List<String> result = new ArrayList<String>(objectList.size());
		for (T item : objectList)
		{
			result.add(String.valueOf(item));
		}
		return result;
	}

	/**
	 * Converts object to String representation by using given pattern.
	 *
	 * Pattern contain getters names prefixed with dollar sign($),
	 * which will be replaced with result of method invocation.
	 *
	 * If getter returns null, it is considered as an empty string.
	 * If pattern is null, toString() value is returned
	 *
	 * Example of operation:
	 * 	Pattern "Name $name" will result in "Name "+obj.getName().toString()
	 *
	 * @param obj - object to be converted
	 * @param pattern - pattern
	 * @return string representation derived using given pattern
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 */
	public static String toStringByPattern( Object obj, String pattern )
	{
		if (obj == null)
			throw new IllegalArgumentException("Object is null for pattern " + pattern);

		if( pattern == null )
		{
			return obj.toString();
		}
		StringTokenizer st = new StringTokenizer( pattern );
		StringBuilder sbResult = new StringBuilder();

		while ( st.hasMoreTokens() )
		{
			String token = st.nextToken();

			if ( token.charAt( 0 ) == '$' )
			{
				String getterName = "get" + Character.toUpperCase( token.charAt( 1 ) ) + token.substring( 2, token.length() );

				Method m;
				try
				{
					m = obj.getClass().getMethod( getterName, (Class[]) null );
					Object result = m.invoke( obj, (Object[]) null );
					token = result == null ? "" : result.toString();
				}
				catch ( Exception e )
				{
					throw CRuntimeException.wrap(e, null);
				}
			}

			if( sbResult.length() > 0 )
			{
				sbResult.append( ' ' );
			}
			sbResult.append( token );
		}
		return sbResult.toString();
	}
	
	
	/**
	 * Method simply inverts the string
	 * @param s
	 * @return inverted string
	 */
	public static String invert(String s) 
	{
		if(null == s)
		{
			return null;
		}
		else
		{
			return new StringBuilder(s).reverse().toString();
		}
	}

	/**
	 * Method escapes HTML strings.
	 *
	 * @param text text to be escaped
	 * @return escaped text
	 */
	
	public static String escapeHTML(String text)
	{
		if (text != null)
		{
			String result ="";
			for(char c:text.toCharArray())
			{
				// Switch is optimized by compiler
				switch(c)
				{
					case '\'' : result += "&#39;"; break;
					case '\"' : result += "&quot;"; break;
					case '&' : result += "&amp;"; break;
					case '<' : result += "&lt;"; break;
					case '>' : result += "&gt;"; break;
					default : result += c;
				}
			}
			return result;
		}
		else
		{
			return null;
		}
	}
	
	/**
	 * @param escapedText e.g. "&lt;Person&gt;"
	 * @return e.g. "<Person>"
	 */
	public static String unescapeHTML(String escapedText)
	{
		if (escapedText != null)
		{
			return escapedText.replaceAll("&#39;", "\'")
					.replaceAll("&apos;", "\'")
					.replaceAll("&quot;", "\"")
					.replaceAll("&amp;", "&")
					.replaceAll("&lt;", "<")
					.replaceAll("&gt;", ">");
		}
		else
		{
			return null;
		}
	}
	
	/**
	 * Replaces non-breaking character &nbsp; with &#160;.
	 * 
	 * @param textWithNonBreakingSpaceCharacter text containing &nbsp;
	 * @return text with replaced &nbsp; 
	 */
	public static String nonBreakingSpaceCharacterToCode(String textWithNonBreakingSpaceCharacter)
	{
		if (textWithNonBreakingSpaceCharacter == null)
			return null;
		
		StringBuilder text = new StringBuilder(textWithNonBreakingSpaceCharacter);
		replace( text, NON_BREAKING_SPACE_CHARACTER, NON_BREAKING_SPACE_CODE);
		
		return text.toString();
	}

	public static String stripXMLUnsupportedChars(String str) {
		if (isEmpty(str))
			return str;
		
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (XMLChar.isValid(c)) {
				sb.append(c);
			}
		}
		
		return sb.toString();
	}

	public static boolean isValidXmlNCName(String sName)
	{
		return XMLChar.isValidNCName(sName);
	}

	public static String replaceNonAsciiCharsWithEntities(String str) {
		if (isEmpty(str))
			return str;
		
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (c <= 127) {
				sb.append(c);
			} else {
				int codePoint = str.codePointAt(i);
				sb.append(String.format("&#%s;", codePoint));
			}
		}
		
		return sb.toString();
	}

	public static boolean hasThaiChars(String sString)
	{
			return !isEmpty(sString) && THAI_CASE_INSENSITIVE_PATTERN.matcher(sString).find();
	}

	public static boolean hasArabicChars(String sString)
	{
			return !isEmpty(sString) && ARABIC_CASE_INSENSITIVE_PATTERN.matcher(sString).find();
	}

	public static boolean hasCJKChars(String sString)
	{
			return !isEmpty(sString) && CJK_CASE_INSENSITIVE_PATTERN.matcher(sString).find();
	}

	public static boolean isPureASCII(String sString)
	{
			return sString != null && PURE_ASCII_PATTERN.matcher(sString).matches();
	}
	
	public static boolean hasHindiChars(String sString)
	{
		return sString != null && HINDI_CASE_INSENSITIVE_PATTERN.matcher(sString).find();
	}
	
	public static boolean hasKoreanChars(String sString)
	{
		return sString != null && KOREAN_CASE_INSENSITIVE_PATTERN.matcher(sString).find();
	}
	
	public static boolean hasHtmlTags(String sString) {
		return sString != null && HTML_TAGS_PATTERN.matcher(sString).find();
	}
	
	public static boolean isEmail(String sString) {
		return sString != null && PATTERN_EMAIL.matcher(sString).matches();
	}
}
