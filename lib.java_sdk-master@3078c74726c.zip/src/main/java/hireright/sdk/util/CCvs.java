/*
 * @(#)$RCSfile: CCvs.java,v $ $Revision: 1.10 $ $Date: 2010/03/11 21:42:30 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CCvs.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	M.Lukyanenko		2002-07-03	created
 *	M.Lukyanenko		2002-11-09	added disable verbose cotroll if Windows
 *	A.Solntsev			2005-11-14	Added logging CVS errors.
 *	A.Solntsev			2007-05-23	Added commands checkout,update, edit, commit, getRevision; created unit tests.
 *	A.Solntsev			2010-03-05	Use log4j instead of commons-logging.
 */
package hireright.sdk.util;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;

/**
 * This class was created by Maxim Lukyanenko for Registry utility a long time ago.
 * Now it's not used.
 *  
 * @author Andrei Solntsev
 * @version $Revision: 1.10 $ $Date: 2010/03/11 21:42:30 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CCvs.java,v $
 */
public class CCvs
{
	protected static final String CLASS_VERSION = "$Revision: 1.10 $ $Author: cvsroot $";
	
	private static final Logger log = Logger.getLogger(CCvs.class);
	private static boolean m_bVerbose = true;

	public CCvs()
	{
		// default constructor
	}

	public static void exportFlatten(String szCvsTag, String szCvsModule, String szOutputDir)
		throws IOException, InterruptedException
	{
		// int nExt = (int)(Math.random() * 10000);
		// String szWorkDir = "cvs_export_" + nExt;

		export(szCvsTag, szCvsModule, szOutputDir, true);

		// CFile moveDir = new CFile(System.getProperty("user.dir")+"/"+szWorkDir);
		// moveDir.cpdir(szOutputDir);
		// moveDir.rmdir();
	}

	public static void export(String szCvsTag, String szCvsModule, String szOutputDir, boolean bFlatten)
		throws IOException, InterruptedException
	{
		String sFlattenFlag = " -N";
		if (bFlatten)
			sFlattenFlag = "";

		String sQuery = "-r -Q -z9 export" + sFlattenFlag + " -r " + szCvsTag +
			" \"" + szCvsModule + "\"";

		//" -d \"" + fixDir(szOutputDir) + "\"

		executeCvs(sQuery, szOutputDir);
	}

	public static void checkout(String szCvsTag, String szCvsModule, String szOutputDir)
		throws IOException, InterruptedException
	{
		final String sStickyParam;
		if (szCvsTag == null || "HEAD".equals(szCvsTag))
			sStickyParam = " -A";
		else
			sStickyParam = " -r " + szCvsTag;

		String sQuery = "-r -Q -z9 checkout -P" + sStickyParam +
			" -N \"" + szCvsModule + "\""; // -d \"" + fixDir(szOutputDir) + "\"
		executeCvs(sQuery, szOutputDir);
	}

	public static void update(String sModule, String szWorkingDir)
		throws IOException, InterruptedException
	{
		String sQuery = "-r -Q update -P -d \"" + sModule + "\""; //  + fixDir(szWorkingDir)
		executeCvs(sQuery, szWorkingDir);
	}

	public static void edit(String sModule, String szWorkingDir)
		throws IOException, InterruptedException
	{
		String sQuery = "-r -Q edit \"" + sModule + "\"";
		executeCvs(sQuery, szWorkingDir);
	}

	public static void commit(String sModule, String sComment, boolean bForcedCommit, String szWorkingDir)
		throws IOException, InterruptedException
	{
		String sForceFlag = (bForcedCommit? " -f" : "");
		String sQuery = "-r -Q commit" + sForceFlag + " -m \"" + sComment + "\" \"" + sModule + "\"";
		executeCvs(sQuery, szWorkingDir);
	}

	public static String getStatus(String sModule, String szWorkingDir)
		throws IOException, InterruptedException
	{
		String sQuery = "-r -q status \"" + sModule + "\"";
		return executeCvs(sQuery, szWorkingDir);
	}

	public static String getRevision(String sModule, String szWorkingDir)
		throws IOException, InterruptedException
	{
		String sStatus = getStatus(sModule, szWorkingDir);
		String sRevision = sStatus.replaceFirst(".*Working revision:\\s*([\\d\\.]+).*", "$1");
		return sRevision;
	}

	private static boolean isWindowsSupported = false;
	
	private static String executeCvs(String sQuery, String sWorkingDir) throws IOException, InterruptedException
	{
		String szOsName = System.getProperty("os.name");
		boolean bVerbose = false;
		final String sCvsCommand;
		if (isWindowsSupported && szOsName.indexOf("Windows") != -1)
		{
			// Windows (?)
			sCvsCommand = "cmd /c start cvs.exe " + sQuery;
			bVerbose = true;
		}
		else
		{
			// Unix-type system
			bVerbose = m_bVerbose;
			sCvsCommand = "cvs " + sQuery;
		}

		File workingDir = (sWorkingDir == null ? null :  new File(sWorkingDir));
		Process cvs = Runtime.getRuntime().exec(sCvsCommand, null, workingDir);

		int nExitCode = cvs.waitFor();

		String sCvsOutput = CFileContent.getText(cvs.getInputStream(), 8);

		if (nExitCode != 0)
		{
			if (bVerbose)
			{
				log.info("CVS Command:");
				log.info(sCvsCommand);

				String sCvsErrors = CFileContent.getText(cvs.getErrorStream(), 64);

				if (sCvsOutput != null && sCvsOutput.trim().length() > 0)
				{
					log.info("CVS Output:");
					log.info(sCvsOutput);
				}

				if (sCvsErrors != null && sCvsErrors.trim().length() > 0)
				{
					log.info("CVS Errors:");
					log.info(sCvsErrors);
				}
			}

			throw new RuntimeException("Failed to execute cvs command: '" + sCvsCommand + "'. Exit code: "
				+ nExitCode);
		}

		return sCvsOutput;
	}
}

