/*
 * @(#)$RCSfile: CNumberUtils.java,v $ $Revision: 1.2 $ $Date: 2013/11/01 08:22:44 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CNumberUtils.java,v $
 *
 * Copyright 2008-2013 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  M. Suhhoruki	2013-10-15	Created.
 *  
 */
package hireright.sdk.util;

import java.math.BigInteger;

/**
 * Number manipulation functions for Java.
 * PL/SQL equivalent is sdk_numbers package.
 * 
 * @author msuhhoruki
 *
 */
public final class CNumberUtils
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	private static final char[] BASE62_ALPHABET = "qwertyuiopasdfghjklzxcvbnm1234567890QWERTYUIOPASDFGHJKLZXCVBNM".toCharArray();
	
	/**
	 * Convert number to specified base using provided alphabet
	 * @param n
	 * @return
	 */
	public static String toBase(BigInteger n, int nBase, char[] alphabet)
	{
		sanityCheck(nBase, alphabet);
		
		StringBuilder sb = new StringBuilder(20);
		BigInteger base = BigInteger.valueOf(nBase);
		BigInteger res = n;
		do
		{
			char c = alphabet[res.mod(base).intValue()];
			sb.append(c);
			res = res.divide(base);
		}
		while (!BigInteger.ZERO.equals(res));
		
		return sb.reverse().toString();
	}
	
	/**
	 * Convert number of specified base to decimal
	 * @param n
	 * @return
	 */
	public static BigInteger toDec(String sEncNumber, int nBase, char[] alphabet)
	{
		sanityCheck(nBase, alphabet);
		
		BigInteger base = BigInteger.valueOf(nBase);
		BigInteger res = BigInteger.ZERO;
		for (int i = 0; i < sEncNumber.length(); i++)
		{
			char c = sEncNumber.charAt(i);
			BigInteger idx = BigInteger.valueOf(indexOf(alphabet, c));
			res = res.multiply(base).add(idx);
		}
		
		return res;
	}
	
	/**
	 * Convert number to base 62
	 * @param n
	 * @return
	 */
	public static String toBase62(BigInteger n)
	{
		return toBase(n, 62, BASE62_ALPHABET);
	}
	
	/**
	 * Convert base 62 to decimal
	 * @param n
	 * @return
	 */
	public static BigInteger base62toDec(String sEncNumber)
	{
		return toDec(sEncNumber, 62, BASE62_ALPHABET);
	}
	
	private static void sanityCheck(int nBase, char[] alphabet)
	{
		if (alphabet == null || alphabet.length == 0)
		{
			throw new IllegalArgumentException("Alphabet is empty");
		}
		else if (nBase <= 1)
		{
			throw new IllegalArgumentException("Invalid base " + nBase);
		}
		else if (nBase > alphabet.length)
		{
			throw new IllegalArgumentException("Alphabet smaller than base " + nBase);
		}
	}
	
	private static int indexOf(char[] cc, char c)
	{
		for (int i = 0; i < cc.length; i++)
		{
			if (cc[i] == c)
			{
				return i;
			}
		}
		
		return -1;
	}
}
