/*
 * @(#)$RCSfile: CSystemConfigurationException.java,v $ $Revision: 1.3 $ $Date: 2008/06/06 07:32:10 $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History: 
 * Denis Belorunov		2008-02-10		Initial revision
 * Denis Belorunov		2008-05-20		New constructor added.
 */

package hireright.sdk.util;

import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.IHasProperties;

/**
 * Exception for marking errors during low-level system configuration. Usually such kind of errors
 * are unrecoverable, so it is RuntimeException descendant.
 * 
 * @author Denis Belorunov
 * @version $Revision: 1.3 $, $Date: 2008/06/06 07:32:10 $
 */
public class CSystemConfigurationException extends CRuntimeException
{
	/**
	 * Constructs an <code>CRuntimeException</code> with the specified detail message.
	 *
	 * @param sMessage the detail message.
	 * @param properties the parameters of exception
	 */
	public CSystemConfigurationException(String sMessage, CProperties properties)
	{
		super(sMessage, properties);
	}

	/**
	 * Constructs a <code>CRuntimeException</code> object.
	 * <p/>
	 *
	 * @param cause cause of the exception
	 */
	public CSystemConfigurationException(Throwable cause)
	{
		super(cause);
	}

	/**
	 * Constructs a <code>CRuntimeException</code> object.
	 *
	 * @param sMessage exception message.
	 * @param cause cause of the exception
	 */
	public CSystemConfigurationException(String sMessage, Throwable cause)
	{
		super(sMessage, cause);
	}


	/**
	 * Constructs an <code>CRuntimeException</code> with the specified detail message.
	 *
	 * @param sMessage the detail message.
	 */
	public CSystemConfigurationException(String sMessage)
	{
		super(sMessage);
	}

	/**
	 * Constructs a <code>CRuntimeException</code> object.
	 *
	 * @param sMessage exception message.
	 * @param propOwner object that implements <code>IHasProperties</code> interface.
	 */
	public CSystemConfigurationException(String sMessage, IHasProperties propOwner)
	{
		super(sMessage, propOwner);
	}

	/**
	 * Constructs a <code>CSystemConfigurationException</code> object.
	 * <p/>
	 *
	 * @param cause cause of the exception
	 * @param properties additional properties
	 */
	public CSystemConfigurationException(Throwable cause, CProperties properties)
	{
		super(cause, properties);
	}
}
