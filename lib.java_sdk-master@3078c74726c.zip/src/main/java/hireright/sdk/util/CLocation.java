
// Copyright (c) 2001 HireRight Estonia
package hireright.sdk.util;

public class CLocation extends Object
{
	int m_nCountryID;
	String m_strRegionName;
	String m_strCountyName;

	public CLocation(int nCountryID, String strRegionName, String strCountyName)
	{
		m_nCountryID = nCountryID;
		m_strRegionName = strRegionName;
		m_strCountyName = strCountyName;
	}

	public final int getCountryID()
	{
		return m_nCountryID;
	}

	public final String getRegionName()
	{
		return m_strRegionName;
	}

	public final String getCountyName()
	{
		return m_strCountyName;
	}
}

 