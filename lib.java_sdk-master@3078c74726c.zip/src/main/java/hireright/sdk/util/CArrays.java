/*
 * @(#)$RCSfile: CArrays.java,v $ $Revision: 1.4 $ $Date: 2015/05/30 09:11:21 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CArrays.java,v $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	M.Suhhoruki	2014-11-28	created
 */
package hireright.sdk.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class CArrays
{
	public static <T> Iterable<T> nvl(Iterable<T> arr, Iterable<T> def)
	{
		return arr != null ? arr : def; 
	}
	
	/**
	 * NPE guard for loops:
			List<String> list = getStrings();
			for (String s : CArrays.nvl(list))
			{
				System.out.println(s);
			}
	 */
	public static <T> Iterable<T> nvl(Iterable<T> arr /* matey */)
	{
		if (arr == null)
		{
			return Collections.emptyList();
		}
		
		return arr; 
	}
	
	public static <T> void add(Collection<T> arr, Collection<T> objs)
	{
		if (objs != null && !objs.isEmpty())
		{
			arr.addAll(objs);
		}
	}
	
	public static <T> List<T> toArray(T ... objs)
	{
		return Arrays.asList(objs);
	}
	
	public static List<Integer> toInts(Iterable<String> s)
	{
		List<Integer> n = new ArrayList<Integer>();
		for (String si : nvl(s))
		{
			n.add(Integer.valueOf(si));
		}
			
		return n;
	}
	
	public static Iterable<Integer> asInts(final Iterable<String> a)
	{
		return new Iterable<Integer>()
		{
			public Iterator<Integer> iterator()
			{
				return new StringAsIntegerIterator(nvl(a).iterator());
			}
		};
	}
	
	private static class StringAsIntegerIterator implements Iterator<Integer>
	{
		private final Iterator<String> m_iter;
		
		public StringAsIntegerIterator(Iterator<String> iter)
		{
			m_iter = iter;
		}
		
		@Override
		public boolean hasNext()
		{
			return m_iter != null && m_iter.hasNext();
		}
		
		@Override
		public Integer next()
		{
			return Integer.valueOf(m_iter.next());
		}
		
		@Override
	    public void remove()
	    {
	        throw new UnsupportedOperationException();
	    }
	}
}
