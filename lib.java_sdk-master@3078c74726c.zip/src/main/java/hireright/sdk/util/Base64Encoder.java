package hireright.sdk.util;

/**
 * History:
 *
 * A.Nikulin  14.01.2003		added method "String encode(byte[])"
 */

public class Base64Encoder
{
	public static String encode(char[] rawChars)
	{
		byte[] rawBytes = new byte[rawChars.length];
		for (int i=0; i < rawChars.length; i++) 
			rawBytes[i] = (byte) rawChars[i];

		return encode(rawBytes);
	}
	
	public static String encode(byte[] rawBytes)
	{
		StringBuffer sbEncoded = new StringBuffer();
		for (int i = 0; i < rawBytes.length; i += 3)
		{
			sbEncoded.append(encodeBlock(rawBytes, i));
		}
		return sbEncoded.toString();
	}

	protected static char[] encodeBlock(byte[] rawBytes, int nOffset)
	{
		int nBlock = 0;
		int nSlack = rawBytes.length - nOffset - 1;
		int nEnd = (nSlack >= 2) ? 2 : nSlack;

		for (int i = 0; i <= nEnd; i++)
		{
			byte b = rawBytes[nOffset + i];
			int nNeuter = (b < 0) ? b + 256 : b;
			nBlock += nNeuter << (8 * (2 - i));
		}

		char[] chaBase64 = new char[4];
		for (int i = 0; i < 4; i++)
		{
			int nSixbit = (nBlock >>> (6 * (3 - i))) & 0x3f;
			chaBase64[i] = getChar(nSixbit);
		}

		if (nSlack < 1) chaBase64[2] = '=';
		if (nSlack < 2) chaBase64[3] = '=';

		return chaBase64;
	}

	protected static char getChar(int nSixbit)
	{
		if (nSixbit >= 0 && nSixbit <= 25)
			return (char)('A' + nSixbit);

		if (nSixbit >= 26 && nSixbit <= 51)
			return (char)('a' + (nSixbit - 26));

		if (nSixbit >= 52 && nSixbit <= 61)
			return (char)('0' + (nSixbit - 52));

		if (nSixbit == 62)
			return '+';

		if (nSixbit == 63)
			return '/';

		return '?';
	}
}