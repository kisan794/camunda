/*
 * @(#)$RCSfile: CDateTime.java,v $ $Revision: 1.6 $ $Date: 2014/11/01 08:24:20 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CDateTime.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  D.Belorunov(VDI)	2005-08-10	created
 *  M.Elshin					2007-03-22	added constructors: CDateTime(String year, String month, String day),
 *  									CDateTime(), CDateTime(XMLTreeNode xml) - and functions
 *  									stringToInt	and setDate.
 *  A.Larin						2007-06-28	added temporary solution for parsing text representation of date (getMonth() etc)
 *  A.Larin						2007-06-29	added support for the mmyyyy format
 *  A.Solntsev				2008-08-26	using generics
 *	A.Muravyev					201410-08	The method getMonth and getDay have been changed to handle the following separators: "/", ".", "-"
 */
package hireright.sdk.util;

import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLObjectException;
import hireright.sdk.html.parser.XMLTreeNode;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Data holder for Date object. Responsible for generating XML node for date and time information.
 *      <DateTime>
 *              <Day>9</Day>
 *              <Month>8</Month>
 *              <Year>2005</Year>
 *              <Hour>17</Hour>
 *              <Minute>30</Minute>
 *      </DateTime>
 * @author Denis Belorunov
 * @version $Revision: 1.6 $ $Date: 2014/11/01 08:24:20 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CDateTime.java,v $
 */
public class CDateTime implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";

	/** Root node. */
	public static final String DATETIME_NODE = "<DateTime/>";

	/** Tag name of node that stores year. */
	private final static String YEAR_TAG_NAME = "Year";

	/** Tag name of node that stores month. */
	private final static String MONTH_TAG_NAME = "Month";

	/** Tag name of node that stores day. */
	private final static String DAY_TAG_NAME = "Day";

	/** Tag name of node that stores hours. */
	private final static String HOUR_TAG_NAME = "Hour";

	/** Tag name of node that stores minutes. */
	private final static String MINUTE_TAG_NAME = "Minute";

	/**
	 * Defines a date format.
	 * @deprecated It is a temporary solution for COM, will be replaced with ISO dates soon
	 */
	public final static String TYPE_MM_DD_YYYY = "mmddyyyy";

	/**
	 * Defines a date format.
	 * @deprecated It is a temporary solution for COM, will be replaced with ISO dates soon
	 */
	public final static String TYPE_DD_MM_YYYY = "ddmmyyyy";

	/**
	 * Defines a date format.
	 * @deprecated It is a temporary solution for COM, will be replaced with ISO dates soon
	 */
	public final static String TYPE_MM_YYYY = "mmyyyy";

	/**
	 * Map with relation between formater and node name.
	 */
	private static Map<DateFormat, String> FORMAT_TO_XML_TAG = new HashMap<DateFormat, String>();
	static
	{
		FORMAT_TO_XML_TAG.put(new SimpleDateFormat("yyyy"), YEAR_TAG_NAME);
		FORMAT_TO_XML_TAG.put(new SimpleDateFormat("MM"), MONTH_TAG_NAME);
		FORMAT_TO_XML_TAG.put(new SimpleDateFormat("dd"), DAY_TAG_NAME);
		FORMAT_TO_XML_TAG.put(new SimpleDateFormat("HH"), HOUR_TAG_NAME);
		FORMAT_TO_XML_TAG.put(new SimpleDateFormat("mm"), MINUTE_TAG_NAME);
	}

	/**
	 * Construct object by input parameters.
	 * @param year - year.
	 * @param month - month.
	 * @param day - day of month.
	 */
	public static Date toDate(String year, String month, String day)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, stringToInt(year));
		calendar.set(Calendar.MONTH, stringToInt(month) - 1);
		calendar.set(Calendar.DAY_OF_MONTH, stringToInt(day));
		return calendar.getTime();
	}
	/**
	 * Constructor create object using input xml.
	 *
	 * @param xml - Input xml.
	 */
	public static Date toDate(XMLTreeNode xml)
	{
		XMLTreeNode node = xml.getChildNodeByTag(YEAR_TAG_NAME);
		Calendar calendar = Calendar.getInstance();
		if (node != null)
		{
			if (CStringUtils.isEmpty(node.getValue()))
			{
				return new Date();
			}
			calendar.set(Calendar.YEAR, stringToInt(node.getValue()));
		}
		else
		{
			return new Date();
		}

		node = xml.getChildNodeByTag(MONTH_TAG_NAME);
		if (node != null)
		{
			calendar.set(Calendar.MONTH, stringToInt(node.getValue()) - 1);
		}

		node = xml.getChildNodeByTag(DAY_TAG_NAME);
		if (node != null)
		{
			calendar.set(Calendar.DAY_OF_MONTH, stringToInt(node.getValue()));
		}

		node = xml.getChildNodeByTag(HOUR_TAG_NAME);
		if (node != null)
		{
			calendar.set(Calendar.HOUR_OF_DAY, stringToInt(node.getValue()));
		}

		node = xml.getChildNodeByTag(MINUTE_TAG_NAME);
		if (node != null)
		{
			calendar.set(Calendar.MINUTE, stringToInt(node.getValue()));
		}
		return calendar.getTime();
	}

	/**
	 * Generate XML node representation.
	 * @return XMLTreeNode instance.
	 */
	public static XMLTreeNode toXMLTreeNode(Date date)
	{
		XMLObject dateXML = getRootXMLObject();
		XMLTreeNode result = (XMLTreeNode) dateXML.getRootNode().firstChildNode();

		if (date == null)
		{
			return result;
		}

		for (Map.Entry<DateFormat, String> entry : FORMAT_TO_XML_TAG.entrySet())
		{
			DateFormat fieldFormat = entry.getKey();
			String tagName = (String) entry.getValue();
			String fieldValue = fieldFormat.format(date);
			result.addChildNode(tagName, fieldValue);
		}
		return result;
	}

	/**
	 * Generate root XMLObject.
	 * @return XMLObject instance.
	 */
	private static XMLObject getRootXMLObject()
	{
		XMLObject dateXML = null;
		try
		{
			dateXML = new XMLObject(DATETIME_NODE);
		}
		catch (XMLObjectException e)
		{
			//It couldn't be...
		}
		return dateXML;
	}

	/**
	 * Convert string to int return 0 if string is not in int format.
	 * @param str - string to convert.
	 * @return resulting int value.
	 */
	private static int stringToInt(String str)
	{
		int result = 0;
		try
		{
			result = Integer.parseInt(str);
		}
		catch (NumberFormatException nfe)
		{
			result = 0;
		}
		return result;
	}

	/**
	 * Parses specidied date (text representation sNodeText) and returns the month.
	 * @param strType type of format, see TYPE_MM_DD_YYYY etc
	 * @param sNodeText text representation of date
	 * @return the month
	 */
	public static Integer getMonth(String strType, String sNodeText)
	{
		if (CStringUtils.equals(strType, TYPE_MM_DD_YYYY) || CStringUtils.equals(strType, TYPE_MM_YYYY))
		{
			Pattern regexp = Pattern.compile("(\\d*?)(?:[/\\.-])");
			Matcher m = regexp.matcher(sNodeText);
			m.find();
			return new Integer(m.group(1));
		}
		else
		{
			return null;
		}
	}

	/**
	 * Parses specidied date (text representation sNodeText) and returns the day.
	 * @param strType type of format, see TYPE_MM_DD_YYYY etc
	 * @param sNodeText text representation of date
	 * @return the day
	 */
	public static Integer getDay(String strType, String sNodeText)
	{
		if (CStringUtils.equals(strType, TYPE_MM_DD_YYYY))
		{
			Pattern regexp = Pattern.compile("(?:[/\\.-])(\\d*?)(?:[/\\.-])");
			Matcher m = regexp.matcher(sNodeText);
			m.find();
			return new Integer(m.group(1));
		}
		else if (CStringUtils.equals(strType, TYPE_MM_YYYY))
		{
			return null;
		}
		else
		{
			return null;
		}
	}

	/**
	 * Parses specidied date (text representation sNodeText) and returns the year.
	 * @param strType type of format, see TYPE_MM_DD_YYYY etc
	 * @param sNodeText text representation of date
	 * @return the year
	 */
	public static Integer getYear(String strType, String sNodeText)
	{
		Pattern regexp = Pattern.compile("(\\d*)$");
		Matcher m = regexp.matcher(sNodeText);
		m.find();
		return new Integer(m.group(1));
	}
}
