/*
 * @(#)$RCSfile: IClosable.java,v $ $Revision: 1.2 $ $Date: 2011/09/23 06:15:25 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/IClosable.java,v $
 *
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   E.Shatohhin	2011-09-15	Created
 */

package hireright.sdk.util;

/**
 * Perform actions needed to properly close given object
 *
 * @author Evgeni Shatohhin
 */
public interface IClosable
{
	public void close();
}
