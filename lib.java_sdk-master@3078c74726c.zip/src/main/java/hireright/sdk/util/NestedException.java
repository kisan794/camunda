/*
 * @(#)$RCSfile: NestedException.java,v $ $Revision: 1.3 $ $Date: 2009/05/22 06:40:06 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/NestedException.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev	2007-12-12	Created.
 */
package hireright.sdk.util;

/**
 * Class is useful for wrapping check exception to unchecked.
 * It saves the original stack trace and guarantees that exception which is already runtime
 * will not be wrapped once more.
 *
 * @author Andrei Solntsev
 * @version $Revision: 1.3 $, $Date: 2009/05/22 06:40:06 $, $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/NestedException.java,v $
 */
public class NestedException extends RuntimeException
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: asolntsev $";

	private final Throwable throwable;

	private NestedException( Throwable t )
	{
		this.throwable = t;
	}

	/**
	 * Wraps another exception in a RuntimeException.
	 * If t is already a RuntimeException, returns t.
	 * @param t
	 * @return
	 */
	public static RuntimeException wrap( Throwable t )
	{
		if ( t instanceof RuntimeException )
		{
			return (RuntimeException) t;
		}

		return new NestedException( t );
	}

	@Override
	public Throwable getCause()
	{
		return this.throwable;
	}

	@Override
	public void printStackTrace()
	{
		this.throwable.printStackTrace();
	}
}