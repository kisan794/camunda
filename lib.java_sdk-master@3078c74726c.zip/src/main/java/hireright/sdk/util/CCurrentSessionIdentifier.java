/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	mkonstantinov	Apr 20, 2017	Created
 */
package hireright.sdk.util;

/**
 * Class to store session identifier. 
 * Main purpose is to be used for load balancers.
 * This one is supposed to be set at the moment when any mvc event is processed, and cleared after it.
 * Clearing is need becaus app servers use a thread pool, so every thread with thread locals is returned to the pool and reused.
 */
public class CCurrentSessionIdentifier 
{
	private static ThreadLocal<String> identifier = new ThreadLocal<String>();
	
	public static void set(String sessionId) 
	{
		identifier.set(sessionId);
	}
	
	public static String get() 
	{
		return identifier.get();
	}
	
	public static void clear() 
	{
		identifier.remove();
	}
}
