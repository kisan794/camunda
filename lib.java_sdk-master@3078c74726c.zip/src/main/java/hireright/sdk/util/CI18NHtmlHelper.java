package hireright.sdk.util;

/*
 * Copyright 2001-2021 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Nikolajenko		2021-03-11	HRG-151713 UKi: Applicant invite - Consent signed in Korean converted to PDF with blank characters*
 */

public class CI18NHtmlHelper
{
	private CI18NHtmlHelper(){}
	
	/**
	 * Inserts corresponding attributes in HTML string allowing to identify characters present in
	 * HTML
	 * @param sHTMLData string representing HTML
	 * @return HTML string with corresponding language attributes set
	 */
	public static String setLanguageAttributes(String sHTMLData)
	{
		String sDataAttrs = " data-has-thai=\"" + CStringUtils.hasThaiChars(sHTMLData) + "\"" +
												" data-has-cjk=\"" + CStringUtils.hasCJKChars(sHTMLData) + "\"" +
												" data-has-arabic=\"" + CStringUtils.hasArabicChars(sHTMLData) + "\"" +
												" data-has-hindi=\"" + CStringUtils.hasHindiChars(sHTMLData) + "\"" +
												" data-has-korean=\"" + CStringUtils.hasKoreanChars(sHTMLData) + "\"";
		
		sHTMLData = sHTMLData.replace("<html", "<html" + sDataAttrs);
		return sHTMLData;
	}
}
