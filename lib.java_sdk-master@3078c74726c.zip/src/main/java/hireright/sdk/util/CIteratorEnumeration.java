/*
 * @(#)$RCSfile: CIteratorEnumeration.java,v $ $Revision: 1.3 $ $Date: 2009/03/10 14:21:07 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CIteratorEnumeration.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev			2008-03-14	Created
 *	A.Solntsev			2009-03-06	Using generics
 */
package hireright.sdk.util;

import java.util.Enumeration;
import java.util.Iterator;

/**
 *
 * @author Andrei Solntsev
 * @version $Revision: 1.3 $, $Date: 2009/03/10 14:21:07 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CIteratorEnumeration.java,v $
 */
public class CIteratorEnumeration<T> implements Enumeration<T>
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
	
	private final Iterator<T> m_iterator;
	
	public CIteratorEnumeration(Iterator<T> iter)
	{
		m_iterator = iter;
	}
	
	public boolean hasMoreElements()
	{
		return m_iterator.hasNext();
	}
	
	public T nextElement()
	{
		return m_iterator.next();
	}
}
