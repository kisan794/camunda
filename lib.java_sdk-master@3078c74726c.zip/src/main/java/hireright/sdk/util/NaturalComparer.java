/*
 * @(#)$RCSfile: NaturalComparer.java,v $ $Revision: 1.2 $ $Date: 2008/11/21 11:31:16 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/NaturalComparer.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:	
 *	A.Solntsev		2006-11-14	Created
 */
package hireright.sdk.util;

import java.util.Comparator;

/**
 * The comparator which simply call method "compareTo" for given objects.
 * 
 * @param <T>
 * 
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $, $Date: 2008/11/21 11:31:16 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/NaturalComparer.java,v $
 */
public class NaturalComparer<T extends Comparable<T>> implements Comparator<T>
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	public int compare(T o1, T o2)
	{
		return o1.compareTo(o2);
	}
}
