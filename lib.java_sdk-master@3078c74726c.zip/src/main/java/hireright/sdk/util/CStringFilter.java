/*
 * @(#)$RCSfile: CStringFilter.java,v $ $Revision: 1.5 $ $Date: 2008/09/05 10:16:16 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CStringFilter.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Solntsev			2005-10-20	created
 *   A.Solntsev			2008-08-26	using generics: implements IFilter<String>
 */
package hireright.sdk.util;

/**
 * Class contains factory methods for creating several string predicats (filters).
 * 
 * @author	Andrei Solntsev
 * @date		2005-10-20
 * @version $Revision: 1.5 $ $Date: 2008/09/05 10:16:16 $ $Author: asolntsev $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CStringFilter.java,v $
 */
public abstract class CStringFilter implements IFilter<String>
{
	public abstract boolean accept(String str);

	public static CStringFilter startsWith(final String sPrefix)
	{
		return new CStringFilter()
		{
			public boolean accept(String str)
			{
				return str.startsWith(sPrefix);
			}
		};
	}

	public static CStringFilter endsWith(final String sSuffix)
	{
		return new CStringFilter()
		{
			public boolean accept(String str)
			{
				return str.endsWith(sSuffix);
			}
		};
	}

	public static CStringFilter contains(final String sSubString)
	{
		return new CStringFilter()
		{
			public boolean accept(String str)
			{
				return str.indexOf(sSubString) > -1;
			}
		};
	}
}