/*
 * @(#)$RCSfile: CThreadSafeSet.java,v $Revision: 1.5 $ $Date: 2009/12/18 07:12:43 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CThreadSafeSet.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 *	A.Solntsev			2007-08-30	created
 *	A.Solntsev			2009-12-09	Removed method finalize()
 */
package hireright.sdk.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import hireright.sdk.debug.CStackTrace;
import hireright.sdk.debug.CTraceLog;

/**
 * @author asolntsev
 * @since Aug 30, 2007
 * @version $Revision: 1.5 $ $Date: 2009/12/18 07:12:43 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CThreadSafeSet.java,v $
 */
public class CThreadSafeSet<T> implements Set<T>
{
	private final Set<T> m_originalSet;

	public CThreadSafeSet(Set<T> originalSet)
	{
		m_originalSet = originalSet;
	}

	@Override
	public String toString()
	{
		return m_originalSet.toString();
	}

	// --- Query Operations ---
	public int size()
	{
		return m_originalSet.size();
	}

	public boolean isEmpty()
	{
		return m_originalSet.isEmpty();
	}

	public boolean contains(Object o)
	{
		return m_originalSet.contains(o);
	}

	public Iterator<T> iterator()
	{
		return new ThreadSafeSetItr<T>(m_originalSet.iterator());
		// return m_originalSet.iterator();
	}

	public Object[] toArray()
	{
		return m_originalSet.toArray();
	}

	public <X> X[] toArray(X[] a)
	{
		return m_originalSet.toArray(a);
	}

	@Override
	public boolean equals(Object o)
	{
		return m_originalSet.equals(o);
	}

	@Override
	public int hashCode()
	{
		return m_originalSet.hashCode();
	}

	// --- Bulk Operations ---
	public boolean containsAll(Collection<?> c)
	{
		return m_originalSet.containsAll(c);
	}

	// --- Modification Operations ---
	public boolean add(T o)
	{
		lockForWriting("add");

		try
		{
			return m_originalSet.add(o);
		}
		finally
		{
			unlockForWriting();
		}
	}

	public boolean remove(Object o)
	{
		lockForWriting("remove");

		try
		{
			return m_originalSet.remove(o);
		}
		finally
		{
			unlockForWriting();
		}
	}

	public boolean addAll(Collection<? extends T> c)
	{
		lockForWriting("addAll");
		try
		{
			return m_originalSet.addAll(c);
		}
		finally
		{
			unlockForWriting();
		}
	}

	public boolean retainAll(Collection<?> c)
	{
		lockForWriting("retainAll");
		try
		{
			return m_originalSet.retainAll(c);
		}
		finally
		{
			unlockForWriting();
		}
	}

	public boolean removeAll(Collection<?> c)
	{
		lockForWriting("removeAll");
		try
		{
			return m_originalSet.removeAll(c);
		}
		finally
		{
			unlockForWriting();
		}
	}

	public void clear()
	{
		lockForWriting("clear");
		try
		{
			m_originalSet.clear();
		}
		finally
		{
			unlockForWriting();
		}
	}


	private class ThreadSafeSetItr<K> implements Iterator<K>
	{
		private final Iterator<K> m_originalIterator;

		ThreadSafeSetItr (Iterator<K> originalIterator)
		{
			m_originalIterator = originalIterator;
			lockReadonly("itr.init");
		}

		public boolean hasNext()
		{
			if (!m_originalIterator.hasNext())
				unlockReadonly();

			return m_originalIterator.hasNext();
		}

		public K next()
		{
			return m_originalIterator.next();
		}

		public void remove()
		{
			lockForWriting("itr.remove");
			try
			{
				m_originalIterator.remove();
			}
			finally
			{
				unlockForWriting();
			}
		}
	}

	// --- Smart solution for finding out parallel threads
	// --- that are using this Set simultaneously
	/**
	 * @serial map of (Thread.name, StackTrace)
	 */
	private Map<String, String> m_currentReaders = new HashMap<String, String>();

	private boolean m_bLockedForWriting = false;

	/**
	 * Stack trace of thread which lock m_children for writing.
	 */
	private String m_sLockingStackTrace;

	private final void lockReadonly(String sMethod)
	{
		checkLockingForWriting(sMethod);
		m_currentReaders.put(Thread.currentThread().getName(), CStackTrace.getStackTrace("Readonly Lock"));
	}

	private final void lockForWriting(String sMethod)
	{
		checkLockingForWriting(sMethod);
		checkLockingForReading(sMethod);

		m_sLockingStackTrace = CStackTrace.getStackTrace("Lock for writing");
		m_bLockedForWriting = true;
	}

	private final void checkLockingForWriting(String sMethod)
	{
		String sLockingChildrenStackTrace = m_sLockingStackTrace;
		if (m_bLockedForWriting)
		{
			CTraceLog.warning("Concurrent access to m_listChildren " +
				Thread.currentThread().getName(), getClass().getName() + "."+sMethod+"()",
				sLockingChildrenStackTrace);

			long timeout = System.currentTimeMillis() + 10*1000; // wait for 10 seconds
			try
			{
				while (System.currentTimeMillis() < timeout)
				{
					Thread.sleep(100);
					if (!m_bLockedForWriting)
						break;
				}
			}
			catch (InterruptedException e)
			{
			}
		}
	}

	private final void checkLockingForReading(String sMethod)
	{
		if (!m_currentReaders.isEmpty())
		{
			int size = 0;
			final String sCurThreadName = Thread.currentThread().getName();
			final String sReaderThreads;
			synchronized (m_currentReaders)
			{
				StringBuilder sb = new StringBuilder("Current reader threads:\n");
				
				for (Map.Entry<String, String> entry : m_currentReaders.entrySet())
				{
					if (!sCurThreadName.equals(entry.getKey()))
					{
						sb.append("==============\n");
						sb.append(entry.getKey());
						sb.append("=");
						sb.append(entry.getValue());
						size++;
					}
				}
				sReaderThreads = sb.toString();
			}

			if (size > 0)
			{
				CTraceLog.warning("Concurrent access to m_listChildren " +
					sCurThreadName, getClass().getName() + "."+sMethod+"()",
					sReaderThreads);
			}
		}
	}

	private final void unlockReadonly()
	{
		unlockReadonly(Thread.currentThread().getName());
	}

	private final void unlockReadonly(String sCurrentThreadName)
	{
		m_currentReaders.remove(sCurrentThreadName);
	}

	private final void unlockForWriting()
	{
		m_bLockedForWriting = false;
		m_sLockingStackTrace = null;
	}
}
