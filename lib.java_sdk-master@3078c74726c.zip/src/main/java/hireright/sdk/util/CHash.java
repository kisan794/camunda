/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	M.Suhhoruki		2016-05-10 Extracted from hireright.project.collections.processors.events.handlers.builder.CSearchTextBuilder
 */
package hireright.sdk.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Used by event engine and duplicate order check:
 * hireright.project.collections.processors.events.handlers.builder.CSearchTextBuilder
 * hireright.sdk_impl.duplicate_check.core.CCrypter
 */
public final class CHash
{
	protected static final String CLASS_VERSION = "$Revision: $ $Author: $";
	
	public static final String ALG_SHA256 = "SHA-256";
	public static final String ALG_SHA512 = "SHA-512";
	
	public static String sha256(String data, String salt) 
		throws NoSuchAlgorithmException
	{
		return hash(ALG_SHA256, data, salt);
	}
	
	public static String sha512(String data, String salt) 
		throws NoSuchAlgorithmException
	{
		return hash(ALG_SHA512, data, salt);
	}
	
	public static String hash(String sAlg, String data, String salt) 
		throws NoSuchAlgorithmException
	{
		if(CStringUtils.isEmpty(data))
		{
			return CStringUtils.EMPTY_STRING;
		}
		
		byte[] hash = hash(sAlg, data.getBytes(), salt.getBytes());
		return hash != null ? CHexBinaryAdapter.toHex(hash) : null;
	}
	
	public static byte[] hash(String sAlg, byte[] data, byte[] salt) 
		throws NoSuchAlgorithmException
	{
		MessageDigest digest = MessageDigest.getInstance(sAlg);
		digest.reset(); //?
		
		if (salt != null)
		{
			digest.update(salt);
		}
		
		return digest.digest(data);
	}
}
