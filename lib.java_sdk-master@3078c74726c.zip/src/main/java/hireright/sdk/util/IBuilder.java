/*
 * @(#)$RCSfile: IBuilder.java,v $ $Revision: 1.2 $ $Date: 2011/10/20 18:46:36 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/IBuilder.java,v $
 *
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   E.Shatohhin	2011-10-10	Created
 */

package hireright.sdk.util;

/**
 * Generic Object Builder
 *
 * @author Evgeni Shatohhin
 */
public interface IBuilder<T>
{
	public T build();
}
