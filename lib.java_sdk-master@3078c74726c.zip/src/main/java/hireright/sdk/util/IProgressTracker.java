/*
 * @(#)$RCSfile: IProgressTracker.java,v $ $Revision: 1.2 $ $Date: 2015/11/02 20:15:14 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/IProgressTracker.java,v $
 * Copyright 2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2015-03-31	created
 */
package hireright.sdk.util;

/**
 * Common contract for "progress trackers": objects used to track progress of long lasting operations.
 * This allows to de-couple the operation logic from progress tracking details, substitute trackers 
 * easily, use composite trackers etc.
 * @author apodlipski
 */
public interface IProgressTracker<S>
{
	/** Instructs progress tracker to initialize itself. */
	public void initialize();
	
	/** Updates progress status with new value. For better usability value is generic. */
	public void update(S status);
	
	/** Tells progress tracker the operation is completed. */
	public void complete();
}
