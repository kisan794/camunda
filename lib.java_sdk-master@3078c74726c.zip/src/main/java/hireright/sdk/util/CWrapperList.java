/*
 * @(#)$RCSfile: CWrapperList.java,v $ $Revision: 1.3 $ $Date: 2010/12/02 21:22:03 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CWrapperList.java,v $
 * 
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	E.Shatohhin		2010-10-27	Created
 *	E.Shatohhin		2010-11-22	Loosened type requirements for Original
 */

package hireright.sdk.util;

import java.util.AbstractList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * Unmodifiable list that wraps item into a proxy class
 * Class can wrap iterable, 
 * however the get() method will throw classcastexception if underlying collection is not a list
 * and size() if not a collection
 *
 * @author Evgeni Shatohhin
 */
public abstract class CWrapperList<Original,Wrapped> extends AbstractList<Wrapped>
{
	private Iterable<Original> m_list;

	public CWrapperList( Iterable<Original> list )
	{
		m_list = list;
	}

	@Override
	public Wrapped get( int index )
	{
		return wrap( ((List<Original>)m_list).get( index ) );
	}

	@Override
	public int size()
	{
		return ((Collection<Original>)m_list).size();
	}
	
	@Override
	public Iterator<Wrapped> iterator()
	{
		return new CWrapperIterator<Original,Wrapped>(m_list.iterator())
		{
			@Override
			public Wrapped wrap( Original o )
			{
				return CWrapperList.this.wrap(o);
			}
		};
	}
	
	/**
	 * Implement this method to create wrapper objects
	 *
	 * @param o - original object
	 * @return wrapped object
	 */
	public abstract Wrapped wrap(Original o);
}