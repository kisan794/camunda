/*
 * @(#)$RCSfile: Filters.java,v $ $Revision: 1.5 $ $Date: 2014/06/28 07:28:46 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/Filters.java,v $
 *
 * Copyright 2008-2013 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Solntsev			2008-10-10	created
 *   A.Podlipski		2013-10-18	apply() method added
 */
package hireright.sdk.util;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Helper class for using IFilter constants in Java5 (generics)
 * 
 * @author	Andrei Solntsev
 * @since		2005-05-20
 * @version $Revision: 1.5 $ $Date: 2014/06/28 07:28:46 $ $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/Filters.java,v $
 */
public class Filters 
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	@SuppressWarnings({ "cast", "unchecked" })
	public static <T> IFilter<T> notNull()
	{
		return (IFilter<T>) IFilter.NOT_NULL;
	}
	
	@SuppressWarnings({ "cast", "unchecked" })
	public static <T> IFilter<T> isNull()
	{
		return (IFilter<T>) IFilter.IS_NULL;
	}
	
	@SuppressWarnings({ "cast", "unchecked" })
	public static <T> IFilter<T> accept()
	{
		return (IFilter<T>) IFilter.ACCEPT;
	}
	
	@SuppressWarnings({ "cast", "unchecked" })
	public static <T> IFilter<T> negate()
	{
		return (IFilter<T>) IFilter.NEGATE;
	}
	
	@SuppressWarnings({ "cast", "unchecked" })
	public static <T> IFilter<T> womanLogic()
	{
		return (IFilter<T>) IFilter.WOMAN_LOGIC;
	}
	
	@SuppressWarnings({ "cast", "unchecked" })
	public static <T> IFilter<T> manLogic()
	{
		return (IFilter<T>) IFilter.MAN_LOGIC;
	}

	/**
	 * Applies specified filter to the collection of elements by removing rejected elements from collection.
	 * @param <T>
	 * @param collection
	 * @param filter
	 * @return
	 */
	public static <T> void applyFilter(Collection<T> collection, IFilter<T> filter)
	{
		Collection<T> rejectedElements = new ArrayList<T>();
		for (T element : collection)
		{
			if (filter != null && !filter.accept(element))
			{
				rejectedElements.add(element);
			}
		}
		collection.removeAll(rejectedElements);
	}

	/**
	 * Applies specified chain of filters to specified collection of elements. 
	 * Filters are applied in the same order they are provided. 
	 * @param <T>
	 * @param collection
	 * @param filters
	 * @return
	 */
	public static <T> void apply(Collection<T> collection, IFilter<T>... filters)
	{
		if (filters != null)
		{
			for (IFilter<T> filter : filters)
			{
				applyFilter(collection, filter);
			}
		}
	}
	
	/**
	 * Applies specified collection of filters to specified collection of elements. 
	 * If collection of filters is ordered, filters are applied in that order. 
	 * @param <T>
	 * @param collection
	 * @param filters
	 * @return
	 */
	public static <T> void apply(Collection<T> collection, Collection<IFilter<T>> filters)
	{
		if (filters != null)
		{
			for (IFilter<T> filter : filters)
			{
				applyFilter(collection, filter);
			}
		}
	}
	
}
