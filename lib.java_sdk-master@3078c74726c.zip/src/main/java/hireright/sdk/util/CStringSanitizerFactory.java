/*
 *
 * Copyright 2001-2019 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Vassiljev		2019-03-19	Created
 */
package hireright.sdk.util;

import hireright.objects.rollout_feature.CRolloutFeatureCache;

/**
 * Factory creates concrete class of interface IStringSanitizer based on UTFINST_TRANSL_DISABLED rollout feature
 * If feature is disabled - then CStringSanitizer is created which is wrapper over CDataSanitizer
 * If feature is enabled - then CDummyStringSanitizer is created which does nothing
 */
public class CStringSanitizerFactory
{
	private static CStringSanitizer m_actualSanitizer = new CStringSanitizer();
	private static CDummyStringSanitizer m_dummySanitizer = new CDummyStringSanitizer();
	
	
	public static IStringSanitizer get()
	{
		if(CRolloutFeatureCache.getInstance().isFeatureGloballyGranted("UTFINST_TRANSL_DISABLED"))
		{
			return m_dummySanitizer;
		}
		return m_actualSanitizer;
	}
}
