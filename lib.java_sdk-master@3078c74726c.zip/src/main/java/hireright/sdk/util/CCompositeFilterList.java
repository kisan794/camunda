/*
 * @(#)$RCSfile: CCompositeFilterList.java,v $	$Revision: 1.3 $ $Date: 2015/05/30 09:11:49 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CCompositeFilterList.java,v $
 * Copyright 2001-2006 by	HireRight, Inc.	All	rights reserved.
 *
 * This	software is	the	confidential and proprietary information
 * of	HireRight, Inc.	Use	is subject to	license	terms.
 *
 * History
 * 	M. Suhhoruki			2012-03-20 Created
 */
package hireright.sdk.util;

import java.util.ArrayList;
import java.util.List;

public class CCompositeFilterList<T>  implements IFilter<T>
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
	
	private List<IFilter<T>> m_filters = new ArrayList<IFilter<T>>(10);
	
	public CCompositeFilterList<T> addFilter(IFilter<T> filter)
	{
		if (filter != null)
		{
			if (filter instanceof CCompositeFilterList)
			{
				// flatten provided CCompositeFilterList
				CCompositeFilterList<T> cf = (CCompositeFilterList<T>) filter;
				for (IFilter<T> f : CArrays.nvl(cf.getFilters()))
				{
					m_filters.add(f);
				}
			}
			else
			{
				m_filters.add(filter);
			}
		}
		
		return this;
	}
	
	/**
	 * Make new set of filters from existing composite filter.
	 * Filter applicability is determined by provided criteria implemented as IFilter.
	 * 
	 * @param criteria - filter that filters out filters
	 * @return
	 */
	public CCompositeFilterList<T> subFilter(IFilter<IFilter<T>> criteria)
	{
		CCompositeFilterList<T> subFilter = new CCompositeFilterList<T>();
		for (IFilter<T> filter : CArrays.nvl(m_filters))
		{
			if (criteria.accept(filter))
			{
				subFilter.addFilter(filter);
			}
		}
		
		return subFilter;
	}
	
	public List<IFilter<T>> getFilters()
	{
		return m_filters;
	}
	
	@Override
	public boolean accept(T obj)
	{
		for (IFilter<T> filter : CArrays.nvl(m_filters))
		{
			if (!filter.accept(obj))
			{
				return false;
			}
		}
		
		return true;
	}
}
