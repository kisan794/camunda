/*
 * @(#)$RCSfile: ByteArray.java,v $ $Revision: 1.3 $ $Date: 2008/11/21 11:30:22 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/ByteArray.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Nesterov    2001-xx-yy  Created
 */
package hireright.sdk.util;

import java.io.Serializable;

/**
 * A ByteArray class.
 * 
 * @author Alexander Nesterov
 * @version $Revision: 1.3 $, $Date: 2008/11/21 11:30:22 $ $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/ByteArray.java,v $
 */
public class ByteArray implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";
	
	private final byte[] m_bytes;

	/**
	 * Constructor
	 */
	public ByteArray(byte[] bytes)
	{
		m_bytes = bytes;
	}
	
	public int size()
	{
		return m_bytes.length;
	}

	public byte[] getBytes()
	{
		return m_bytes;
	}

	@Override
	public String toString()
	{
		return new String(m_bytes);
	}
}

 