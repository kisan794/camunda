/*
 * @(#)$RCSfile: Lang.java,v $ $Revision: 1.8 $ $Date: 2015/11/02 20:17:08 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/Lang.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev				2009-05-14	Created
 *	A.Solntsev				2009-10-21	Added methods hashCode(), assertNotNull(), decode()
 *	A.Solntsev				2010-01-07	Added method cast
 *	A.Solntsev				2010-03-08	Added method hashCode(Object... members)
 *	M.Suhhoruki			2010-03-09	 equal: invoke equals even when one object is null
 *	E.Shatohhin			2011-01-12	 hashCode: fixed according to junit test
 *
 */
package hireright.sdk.util;

/**
 * Java language extensions :)
 *
 * Useful null-safe utility methods for comparing objects and computing hash code
 *
 * @author	Andrei Solntsev
 * @version $Revision: 1.8 $ $Date: 2015/11/02 20:17:08 $ $Author: cvsroot $
 */
public class Lang
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";

	/**
	 * This object is not equal to any other object.
	 * In other words, its method "equals" always returns "false".
	 */
	public static final Object UNIQUE = new Object()
	{
		@Override
		public int hashCode()
		{
			return super.hashCode();
		}

		@Override
		public boolean equals( Object obj )
		{
			return false;
		}
	};
	
	public static final int hashCode(Object o)
	{
		return ( o == null ) ? 0 : o.hashCode();
	}

	public static final int hashCode(Object o1, Object o2)
	{
		return 17*hashCode( o1 ) + hashCode( o2 );
	}

	public static final int hashCode(Object o1, Object o2, Object o3)
	{
		return 23*hashCode( o1 ) + 17*hashCode( o2 ) + hashCode( o3 );
	}

	public static final int hashCode(Object o1, Object o2, Object o3, Object o4)
	{
		return 29*hashCode( o1 ) + 23*hashCode( o2 ) + 17*hashCode( o3 ) + hashCode( o4 );
	}
	
	public static final int hashCode(Object o1, Object o2, Object o3, Object o4, Object o5)
	{
		return 37*hashCode( o1 ) + 29*hashCode( o2 ) + 23*hashCode( o3 ) + 17*hashCode( o4 ) + hashCode( o5 );
	}

	public static final int hashCode(Object o1, Object o2, Object o3, Object o4, Object o5, Object o6)
	{
		return 41*hashCode( o1 ) + 37*hashCode( o2 ) + 29*hashCode( o3 ) + 23*hashCode( o4 ) + 17*hashCode( o5 ) + hashCode( o6 );
	}

	public static final int hashCode(Object... members)
	{
		int hashCode = 0;
		if( members != null )
		{
			for (Object member : members)
			{
				hashCode = (7*hashCode + hashCode(member)) % Integer.MAX_VALUE;
			}
		}
		return hashCode;
	}
	
	public static final boolean equal(Object o1, Object o2)
	{
		return (o1 == null && o2 == null)
			|| (
					// Sometimes null is equal to empty object, so lets invoke equals
					(o1!=null && o1.equals(o2))
					|| o2!=null && o2.equals(o1)
				);
	}

	/**
	 * @see http://charsequence.blogspot.com/2009/10/detecting-nullpointerexception-with.html
	 */
	public static <T> T assertNotNull( final T object )
	{
		return assertNotNull(object, "null value not allowed");
	}
	
	/**
	 * @see http://charsequence.blogspot.com/2009/10/detecting-nullpointerexception-with.html
	 */
	public static <T> T assertNotNull( final T object, final String errorMsg )
	{
		if ( object == null )
		{
			throw new IllegalArgumentException( errorMsg );
		}
		return object;
	}
	
	/**
	 * Allows shorter code 
	 * <code>
	 *   Map<String, Map<String, Collection<Entity>>> beautiful = cast(webappSession.getAttribute("beautiful"));
	 * </code>
	 * 
	 * instead of the ugly alternative:
	 * <code>
	 *   Map<String, Map<String, Collection<Entity>>> myUglyMap = 
	 *     (Map<String, Map<String, Collection<Entity>>>)(webappSession.getAttribute("myUglyMap"));
	 * </code>
	 * 
	 * @see http://codemunchies.com/2009/10/cast-away-with-java-generics/
	 * @see http://satukubik.com/2010/01/06/java-tips-using-generic-correctly/
	 */
	@SuppressWarnings("unchecked")
	public static <T, X extends T> X cast(T o)
	{
		return (X) o;
	}
	
	public static <T> T nvl(T obj, T defaultValue)
	{
		return obj == null ? defaultValue : obj;
	}

	public static <T, R> R decode(final T source,
			final T match1, final R replace1,
			final R defaultReplace)
	{
		return decode(source, match1, replace1, UNIQUE, null, UNIQUE, null, UNIQUE, null, defaultReplace);
	}
	
	public static <T, R> R decode(final T source,
			final T match1, final R replace1,
			final T match2, final R replace2,
			final R defaultReplace)
	{
		return decode(source, match1, replace1, match2, replace2, UNIQUE, null, UNIQUE, null, defaultReplace);
	}
	
	public static <T, R> R decode(final T source,
			final T match1, final R replace1,
			final T match2, final R replace2,
			final T match3, final R replace3,
			final R defaultReplace)
	{
		return decode(source, match1, replace1, match2, replace2, match3, replace3, UNIQUE, null, defaultReplace);
	}
	
	public static <T, R> R decode(final T source,
			final T match1, final R replace1,
			final T match2, final R replace2,
			final T match3, final R replace3,
			final T match4, final R replace4, 
			final R defaultReplace)
	{
		if (equal(source, match1))
			return replace1;
		else if (equal(source, match2))
			return replace2;
		else if (equal(source, match3))
			return replace3;
		else if (equal(source, match4))
			return replace4;

		return defaultReplace;
	}
	
	public static Long toLong(Integer n)
	{
		return n == null ? null : Long.valueOf( n.longValue() );
	}
	
	public static Integer toInt(Long n)
	{
		return n == null ? null : Integer.valueOf( n.intValue() );
	}
}
