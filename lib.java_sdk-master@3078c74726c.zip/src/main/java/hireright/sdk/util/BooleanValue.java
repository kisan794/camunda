/*
 * @(#)$RCSfile: BooleanValue.java,v $Revision: 1.3 $ $Date: 2007/09/14 09:01:15 $ $Author: asolntsev $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-01-18	created
 */
package hireright.sdk.util;

import java.io.Serializable;

/**
 * This is a special class for boolean values which may be undefined.
 *
 * @author Andrei Solntsev
 * @since Apr 11, 2007
 * @version $Revision: 1.3 $ $Date: 2007/09/14 09:01:15 $ $Author: asolntsev $
 */
public class BooleanValue implements Serializable
{
	public static final BooleanValue UNDEFINED = new BooleanValue(false, false);
	public static final BooleanValue TRUE = new BooleanValue(true, true);
	public static final BooleanValue FALSE = new BooleanValue(true, false);

	private final boolean m_bIsValueDefined;
	private final boolean m_bValue;

	private BooleanValue(boolean bIsValueDefined, boolean bValue)
	{
		m_bIsValueDefined = bIsValueDefined;
		m_bValue = bValue;
	}

	public boolean isValueDefined()
	{
		return m_bIsValueDefined;
	}

	public boolean booleanValue()
	{
		return m_bValue;
	}

	public String toString()
	{
		if (!m_bIsValueDefined)
			return "undefined boolean value";

		return String.valueOf(m_bValue);
	}

	public static BooleanValue valueOf(boolean bValue)
	{
		return (bValue ? TRUE : FALSE);
	}
}