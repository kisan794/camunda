/*
 * @(#)$RCSfile: CParameters.java,v $ $Revision: 1.7 $ $Date: 2009/12/18 07:13:04 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CParameters.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	D.Belorunov			2008-03-12	Created
 *	A.Solntsev			2008-08-29	using generics; created unit-tests
 *	A.Solntsev			2008-10-24	Fixed method size()
 *	A.Solntsev			2009-01-11	Added metod setParameter()
 *	A.Solntsev			2009-12-09	Removed method finalize()
 */
package hireright.sdk.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Parameters container class that follows logic from PL/SQL code. It support several parameters
 * with the same name. Keeps order of parameters.
 *
 * @author Denis Belorunov.
 * @version $Revision: 1.7 $ $Date: 2009/12/18 07:13:04 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CParameters.java,v $
 */
public class CParameters implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
	/** default delimiter between KEY and VALUE */
	protected static final String EQUAL_SIGN = "=";

	/** default delimiter is the newline character */
	protected static final String DEFAULT_DELIMETER = "\n";

	// Class members
	private final Map<String, List<String>> m_parameters;
	private final String m_szDelimiters;
	private final String m_szKeyValueSeparator;

	/**
	 * Copy constructor
	 *
	 * @param parameters instance of CProperties to take copy of.
	 * @throws NullPointerException if parameters is null
	 */
	public CParameters(CParameters parameters)
	{
		this(null, parameters.m_szDelimiters, parameters.m_szKeyValueSeparator);
		m_parameters.putAll(parameters.m_parameters);
	}

	/** Empty constructor. */
	public CParameters()
	{
		this(null, DEFAULT_DELIMETER, EQUAL_SIGN);
	}

	/**
	 * Constructor parses given String-representation of properties using default delimiters.
	 *
	 * @param szParameters eg. "name1=param1\nname2=param2\nname3=param3"
	 */
	public CParameters(String szParameters)
	{
		this(szParameters, DEFAULT_DELIMETER, EQUAL_SIGN);
	}


	/**
	 * Constructor with custom row delimiter and key/value delimiter.
	 *
	 * @param szProperties eg. "name1=param1\nname2=param2\nname3=param3"
	 * @param szDelimiters Default deleimiter is "\n".
	 * @see	#DEFAULT_DELIMETER
	 * @see	#EQUAL_SIGN
	 * @param	szKeyValueSeparator	Default is "=".
	 */
	public CParameters(String szProperties, String szDelimiters, String szKeyValueSeparator)
	{
		m_parameters = new LinkedHashMap<String, List<String>>();
		m_szDelimiters = szDelimiters;
		m_szKeyValueSeparator = szKeyValueSeparator;

		parse(szProperties);
	}

	/**
	 * Parses string with parameters.
	 *
	 * @param szParameters parameters.
	 */
	protected final void parse(String szParameters)
	{
		if (szParameters == null || szParameters.trim().length() == 0)
		{
			return;
		}

		StringTokenizer stProperties = new StringTokenizer(szParameters, m_szDelimiters);
		while (stProperties.hasMoreElements())
		{
			String sProperty = stProperties.nextToken();
			int nSeparatorIndex = sProperty.indexOf(m_szKeyValueSeparator);
			if (nSeparatorIndex != -1)
			{
				String szKey = sProperty.substring(0, nSeparatorIndex);
				String szValue = sProperty.substring(nSeparatorIndex + 1);

				if (szKey != null && szKey.length() != 0 && szValue != null)
				{
					addParameter(szKey, szValue);
				}
			}
		}
	}

	/**
	 * Adds new parameter. Old value of parameter won't be overwritten.
	 *
	 * @param szKey key of parameter.
	 * @param szValue value of parameter.
	 */
	public void addParameter(String szKey, String szValue)
	{
		Collection<String> values = m_parameters.get(szKey);
		if (values == null)
		{
			m_parameters.put(szKey, createSingleValueList(szValue));
		}
		else
		{
			values.add(szValue);
		}
	}

	@Override
	public int hashCode()
	{
		return 19 * m_szDelimiters.hashCode() +
				13 * m_szKeyValueSeparator.hashCode() +
				m_parameters.hashCode();
	}

	/**
	 * Checks whether parameter with provided key exists.
	 *
	 * @param szKey key of parameter.
	 * @return true if parameter exists.
	 */
	public boolean hasParameter(String szKey)
	{
		return m_parameters.containsKey(szKey);
	}

	/** @return true iff this object has not properties set up */
	public boolean isEmpty()
	{
		return m_parameters == null || m_parameters.isEmpty();
	}

	/**
	 * Returns all parameter's values in unmodifiable list.
	 *
	 * @param szKey key of parameter.
	 * @return all parameter's values. Always not-null.
	 * @deprecated Use method {@link #getParameterValues(String)}
	 */
	public List<String> getParametersByName(String szKey)
	{
		return getParametersByName(szKey, null);
	}

	public List<String> getParameterValues(String sParameterName)
	{
		return getParameterValues(sParameterName, null);
	}
	
	/**
	 * Returns all parameter's values in unmodifiable list.
	 *
	 * @param szKey key of parameter.
	 * @param szDefValue value that will be returned, in case key is not found. If null, empty list
	 * will be returned.
	 * @return all parameter's values. Always not-null.
	 * @deprecated Use method {@link #getParameterValues(String, String)}
	 */
	public List<String> getParametersByName(String szKey, String szDefValue)
	{
		final List<String> value = (szKey == null ? null : m_parameters.get(szKey));

		return new ArrayList<String>((value != null)	? value : createSingleValueList(szDefValue));
	}

	public List<String> getParameterValues(String sParameterName, String szDefValue)
	{
		final List<String> value = (sParameterName == null ? null : m_parameters.get(sParameterName));

		return Collections.unmodifiableList( (value != null)	? value : createSingleValueList(szDefValue) );
	}
	
	/**
	 * Overwrites values of parameter. All old values will be removed.
	 *
	 * @param szKey key of parameter.
	 * @param values values of parameter.
	 */
	public void setParameter(String szKey, List<?> values)
	{
		List<String> stringValues = CStringUtils.convertObjectListToStringList(values);
		m_parameters.put(szKey, stringValues);
	}

	/**
	 * Overwrites value of parameter. All old values will be removed.
	 *
	 * @param szKey key of parameter.
	 * @param szValue value of parameter.
	 */
	public void setParameter(String szKey, String szValue)
	{
		m_parameters.put(szKey, createSingleValueList(szValue));
	}
	
	public void setParameter(String sKeyValue)
	{
		String[] keyValue = sKeyValue.split(m_szKeyValueSeparator, 2);
		addParameter(keyValue[0], keyValue[1]);
	}
	
	public void setParameters(String sKeyValue)
	{
		String[] keyValue = sKeyValue.split(m_szKeyValueSeparator, 2);
		addParameter(keyValue[0], keyValue[1]);
	}

	/**
	 * Changes value of parameter to the new one.
	 *
	 * @param szKey key of parameter.
	 * @param szOldValue old value of parameter to change.
	 * @param szValue new value of parameter.
	 */
	public void changeParameterValue(String szKey, String szOldValue, String szValue)
	{
		List<String> values = m_parameters.get(szKey);
		if (values == null)
		{
			setParameter(szKey, szValue);
		}
		else
		{
			int index = values.indexOf(szOldValue);
			while (index != -1)
			{
				values.remove(index);
				values.add(index, szValue);
				index = values.indexOf(szOldValue);
			}
		}
	}

	/**
	 * Converts arbitrary object into list with string representations.
	 *
	 * @param singleItem object
	 * @return list with string representations.
	 */
	private static <T> List<T> createSingleValueList(T singleItem)
	{
		List<T> result = new ArrayList<T>(1);
		if (singleItem != null)
		{
			result.add(singleItem);
		}
		return result;
	}

	/**
	 * Removes values for parameter with given key.
	 *
	 * @param szKey key of parameter.
	 */
	public void removeAllParametersByName(String szKey)
	{
		m_parameters.remove(szKey);
	}

	/** Removes all parameters. */
	public void clear()
	{
		m_parameters.clear();
	}

	@Override
	public String toString()
	{
		return toString(m_szDelimiters, m_szKeyValueSeparator);
	}

	/**
	 * Returns textual representation of CProperties object - alphabetically sorted set of (key,value)
	 * pairs separated by delimeter.
	 *
	 * @return String-representation of properties
	 * @param	szDelimiters delimiters
	 * @param	sKeyValueSeparator separator
	 */
	public String toString(String szDelimiters, String sKeyValueSeparator)
	{
		StringBuffer sb = new StringBuffer();

		for (Map.Entry<String, List<String>> entry : m_parameters.entrySet())
		{
			for (String value : entry.getValue())
			{
				sb.append(entry.getKey()).append(sKeyValueSeparator).append(value).append(szDelimiters);
			}
		}
		return sb.toString();
	}

	/**
	 * Method returns number of parameters stored in this object.
	 * If there are several parameters with the same name, method counts +1 for each of them.
	 *
	 * @return 0 if no parameters are given
	 */
	public int size()
	{
		if (m_parameters == null || m_parameters.isEmpty())
			return 0;
		
		int count = 0;
		for (List<String> list : m_parameters.values())
		{
			if (list != null && !list.isEmpty())
				count += list.size();
		}
		
		return count;
	}

	@Override
	public boolean equals(Object obj)
	{
		return obj != null && (obj instanceof CParameters) &&
				equals((CParameters) obj);
	}

	/**
	 * Compare 2 CParameters
	 *
	 * @param p2 another parameters set
	 * @return false <code>this</code> and <code>p2</code> have different size or have at least one
	 *         parameter which value differs in <code>this</code> and <code>p2</code>.
	 */
	public boolean equals(CParameters p2)
	{
		if (m_parameters == null && p2.m_parameters == null)
		{
			return true;
		}
		if (m_parameters == null || p2.m_parameters == null)
		{
			return false;
		}
		if (m_parameters.size() != p2.m_parameters.size())
		{
			return false;
		}

		// iterate all properties
		for (Map.Entry<String, List<String>> entry : m_parameters.entrySet())
		{
			Object key = entry.getKey();
			List<String> values1 = entry.getValue();
			List<String> values2 = p2.m_parameters.get(key);

			// go on if both are nulls
			if (values1 == null && values2 == null)
			{
				continue;
			}
			if (values1 == null || values2 == null)
			{
				return false;
			}

			if (!values1.equals(values2))
			{
				return false;
			}
		}

		// return true if all checks passed
		return true;
	}
}
