/*
 * @(#)$RCSfile: CObjectCache.java,v $ $Revision: 1.7 $ $Date: 2010/03/11 21:41:58 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CObjectCache.java,v $ 
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev			2005-06-08	created
 *	A.Solntsev			2005-06-23	More smart counting of expiration time.
 *	A.Solntsev			2010-03-05	Use log4j instead of commons-logging.
 */
package hireright.sdk.util;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * Class that allows to put object into cache with defined living time.
 * A very simple implementation that uses Hashmap.
 * 
 * @author	Andrei Solntsev
 */
public class CObjectCache 
{
	/*
	 * IMPLMENT ME	Possibly we should use Oracle object cache or another library,
	 * 							or at least use java week references.
	 */

	private static final Logger log = Logger.getLogger(CObjectCache.class);
			
	/**
	 * Private Map for storing objects
	 */
	private static final Map<Object,CObjectContainer> m_storage = new HashMap<Object,CObjectContainer>();
	
	/**
	 * The nearest time when some service expires
	 */
	private static long m_expirationTime = System.currentTimeMillis();
	
	/**
	 * No need to create instance
	 */
	protected CObjectCache()
	{
	}
	
	/**
	 * Method puts given object into cache with given key and living time.
	 * If cache already contains another object with same key, it's removed.
	 * 
	 * @param key	- must implement equals() and hashCode().
	 * @param object
	 * @param timeToLive	- time to live (millisecunds).
	 */
	public static void put(Object key, Object object, long timeToLive)
	{
		synchronized (m_storage)
		{
			CObjectContainer container = new CObjectContainer(object, timeToLive);
			m_storage.put(key, container );
			if (container.m_expirationTime < m_expirationTime)
				m_expirationTime = container.m_expirationTime;
		}
		
		// FIXME	This should be run as a low-priority background process
		clearExpiredObjects();
	}
	
	/**
	 * Method removes from cache object with given key.
	 * If cache doesn't contain any object with given key, method does nothing.
	 * 
	 * @param key		- must implement equals() and hashCode().
	 */
	public static void remove(Object key)
	{
		synchronized (m_storage)
		{
			m_storage.remove(key);
		}
	}
	
	/**
	 * Method goes throw all objects and removes expired objects.
	 * Ideally, it should be run as background low-priority process.
	 */
	private static void clearExpiredObjects()
	{
		if (m_expirationTime < System.currentTimeMillis())
		{
			// There are some expired objects in the cache.
			// Reset expiration time. We are going to recount it.
			m_expirationTime = -1;
			
			// Check all objects in cache.
			for (Iterator<CObjectContainer> it = m_storage.values().iterator(); it.hasNext(); )
			{
				CObjectContainer container = it.next();
				if (container.isExpired())
					it.remove();
				else if (m_expirationTime == -1 || container.m_expirationTime < m_expirationTime)
					m_expirationTime = container.m_expirationTime;
			}
		}
	}


	/**
	 * Method gets an object from cache using given key.
	 * 
	 * @param key	- must implement equals() and hashCode().
	 * @return null if object is not stored in cache or is expired
	 */
	public static Object get(Object key)
	{
		final CObjectContainer container = m_storage.get(key);
		if (container == null)
			return null;

		if (container.isExpired())
		{
			remove(key);
			return null;
		}
		
		return container.m_object;
	}
	
	/**
	 * Method clears entire object cache.
	 */
	public static void clearCache()
	{
		synchronized (m_storage)
		{
			m_storage.clear();
		}
	}
	
	/**
	 * Method puts given object into cache.
	 * 
	 * @param clazz			Object class
	 * @param classKey	unique key within given class (say, customerId, designNr etc.)
	 * @param object		Object to be cached
	 * @param timeToLive
	 */
	public static void put(Class<?> clazz, Object classKey, Object object, long timeToLive)
	{
		put(clazz.getName() + classKey, object, timeToLive);
	}
	
	/**
	 * Method gets object from cache
	 * @param clazz			Object class
	 * @param classKey	unique key within given class (say, customerId, designNr etc.)
	 * @return null if object is not found or is expired
	 */
	public static Object get(Class<?> clazz, Object classKey)
	{
		return get(clazz.getName() + classKey);
	}
	
	/**
	 * Inner class
	 */
	private static class CObjectContainer
	{
		private Object m_object;
		private long m_expirationTime;
		
		/**
		 * @param livingTime	- time to live (millisecunds).
		 */
		CObjectContainer (Object object, long livingTime)
		{
			m_object = object;
			m_expirationTime = System.currentTimeMillis() + livingTime;
		}
		
		boolean isExpired()
		{
			if (System.currentTimeMillis() > m_expirationTime)
			{
				if (log.isDebugEnabled())
					log.debug("Removing object from cache...");
			}
			return System.currentTimeMillis() > m_expirationTime;
		}
	}
}