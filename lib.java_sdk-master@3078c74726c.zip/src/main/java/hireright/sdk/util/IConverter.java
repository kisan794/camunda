/*
 * @(#)$RCSfile: IConverter.java,v $ $Revision: 1.2 $ $Date: 2015/01/10 08:55:00 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/IConverter.java,v $
 * Copyright 2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2014-12-09	created
 */
package hireright.sdk.util;

/**
 * Generic "convertor" interface that allows for a more reusable code by encapsulating object conversion logic.
 * @author apodlipski
 */
public interface IConverter<T, S>
{
	/** Converts T to S. */
	public S convert(T t);
	
	/** Reverse conversion. */
	public T reverse(S s);
}
