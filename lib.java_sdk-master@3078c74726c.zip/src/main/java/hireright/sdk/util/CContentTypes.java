/*
 * @(#)$RCSfile: CContentTypes.java,v $ $Revision: 1.2 $ $Date: 2015/05/09 08:54:12 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CContentTypes.java,v $
 * Copyright 2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M. Suhhoruki 2009-04-16 Created
 * M. Suhhoruki 2015-04-09 Moved to java_sdk from dms document
 */
package hireright.sdk.util;

import hireright.sdk.io.IORuntimeException;
import hireright.sdk.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Helper class to determine file extension by content type and back.
 * @author MSuhhoruki
 *
 */
public class CContentTypes
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	private static final String FILE_EXTENSION_MAPPING = "hireright/sdk/util/content_extension_type.properties";
	private static final String FILE_CONTENT_TYPE_MAPPING = "hireright/sdk/util/content_type_extension.properties";
	private static Properties m_extensionMapping;
	private static Properties m_contentTypeMapping;

	private static final Object LOCK = new Object();

	/**
	 * @return file extension by content type
	 */
	public static String getExtensionByContentType(String sContentType)
	{
		Properties mappings = getContentTypeMapping();
		return mappings != null ? mappings.getProperty(sContentType) : null;
	}
	
	public static String getContentTypeByExtension(String sExtension)
	{
		Properties mappings = getExtensionMapping();
		return mappings != null ? mappings.getProperty(sExtension) : null;
	}

	private static Properties getExtensionMapping()
	{
		if (m_extensionMapping == null)
		{
			synchronized(LOCK)
			{
				if (m_extensionMapping == null)
				{
					m_extensionMapping = getProperties(FILE_EXTENSION_MAPPING);
				}
			}
		}

		return m_extensionMapping;
	}
	
	private static Properties getContentTypeMapping()
	{
		if (m_contentTypeMapping == null)
		{
			synchronized(LOCK)
			{
				if (m_contentTypeMapping == null)
				{
					m_contentTypeMapping = getProperties(FILE_CONTENT_TYPE_MAPPING);
				}
			}
		}

		return m_contentTypeMapping;
	}
	
	private static Properties getProperties(String sFile)
	{
		Properties p = new Properties();
		InputStream isProps = CContentTypes.class.getClassLoader()
			.getResourceAsStream(sFile);
		try
		{
			p.load(isProps);
		}
		catch (IOException e)
		{
			throw new IORuntimeException(e);
		}
		finally
		{
			IOUtils.closeSilently(isProps);
		}
		
		return p;
	}
}
