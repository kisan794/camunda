/*
 * @(#)$RCSfile: CIteratorUtils.java,v $ $Revision: 1.7 $ $Date: 2015/04/18 09:14:15 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CIteratorUtils.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   A.Solntsev			2006-01-18	created
 *   A.Solntsev			2006-05-04	Added methods collectList(Enumeration enumElements), collectArray(Enumeration enumElements)
 *   A.Solntsev			2008-08-27	Added test-cases for ALL methods; using generics.
 *   A.Podlipski		2015-03-31	EV 437122: collect(Iterable<T>) added
 */
package hireright.sdk.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

/**
 * Utilities for java.util.Iterator:
 * method for collecting elements of given Iterator to a List or Array 
 * 
 * @author Andrei Solntsev
 * @since java_sdk_v2-6-5
 * @version $Revision: 1.7 $ $Date: 2015/04/18 09:14:15 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CIteratorUtils.java,v $
 */
public class CIteratorUtils
{
	/**
	 * Given an Enumeration, method composes a List of its elements
	 * @param enumElements java.util.Enumeration not null, but may contain no elements
	 * @return LinkedList containing all elements from given Enumeration
	 * 
	 * @since java_sdk_v2-6-9
	 */
	public static <T> List<T> collectList(Enumeration<? extends T> enumElements)
	{
		List<T> collector = new LinkedList<T>();
		for (; enumElements.hasMoreElements(); )
		{
			collector.add(enumElements.nextElement());
		}
		return collector;
	}
	
	/**
	 * Given an Iterator, method composes a List of its elements
	 * 
	 * @param iterator any iterator
	 * @return List of its elements
	 */
	public static <T> List<T> collectList(Iterator<T> iterator)
	{
		return (List<T>) collect(iterator, new LinkedList<T>());
	}
	
	/**
	 * Given an Iterator, method composes a sorted set of its elements.
	 * @param iterator
	 * @return
	 * 
	 * @since java_sdk_v2-6-9
	 */
	public static <T> TreeSet<T> collectSorted(Iterator<? extends T> iterator)
	{
		return (TreeSet<T>) collect(iterator, new TreeSet<T>());
	}
	
	/**
	 * Given an enumeration, method composes a sorted set of its elements.
	 * @param enumElements
	 * @return
	 * 
	 * @since java_sdk_v2-6-9
	 */
	public static <T> TreeSet<T> collectSorted(Enumeration<? extends T> enumElements)
	{
		TreeSet<T> collector = new TreeSet<T>();
		for (; enumElements.hasMoreElements(); )
		{
			collector.add(enumElements.nextElement());
		}
		
		return collector;
	}
	
	
	/**
	 * Given an Iterator, method composes an array of its elements.
	 * Array has a type Object[].
	 * 
	 * @param iterator any iterator
	 * @return array of its elements
	 */
	public static <T> Object[] collectArray(Iterator<T> iterator)
	{
		Collection<T> array = collect(iterator, new ArrayList<T>());
		return array.toArray();
	}
	
	/**
	 * Given an enumeration, method composes an array of its elements.
	 * 
	 * @param enumElements
	 * @param toArray see Collections.toArray
	 * @return
	 * 
	 * @since java_sdk_v2-6-9
	 */
	public static <T> T[] collectArray(Enumeration<? extends T> enumElements, T[] toArray)
	{
		ArrayList<T> collector = new ArrayList<T>();
		for (; enumElements.hasMoreElements(); )
		{
			collector.add(enumElements.nextElement());
		}
		
		return collector.toArray(toArray);
	}
	
	/**
	 * Given an Iterator, method composes an array of its elements.
	 * Array has the same type as given toArray.
	 * 
	 * @param iterator any iterator
	 * @param toArray @see java.util.ArrayList#toArray(Object[] toArray)
	 * @return array of its elements
	 */
	public static <T> T[] collectArray(Iterator<? extends T> iterator, T[] toArray)
	{
		return collect(iterator, new ArrayList<T>()).toArray(toArray);
	}
	
	/**
	 * Given an iterator and collections, method run through the iterator and
	 * adds all its elements to the given collection.
	 * 
	 * @param iterator	any iterator
	 * @param collector	any collection
	 * @return	the same collection object
	 */
	private static <T> Collection<T> collect(Iterator<? extends T> iterator, Collection<T> collector)
	{
		for (; iterator.hasNext(); )
		{
			collector.add(iterator.next());
		}
		
		return collector;
	}
	
	public static <T> Collection<T> collect(Iterable<T> iterable) 
	{
	    Collection<T> list = new ArrayList<T>();
	    for (T item : iterable) 
	    {
	        list.add(item);
	    }
	    return list;
	}
}
