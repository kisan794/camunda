/*
 * @(#)$RCSfile: CEntityGenerator.java,v $ $Revision: 1.2 $ $Date: 2015/01/10 08:56:25 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CEntityGenerator.java,v $
 * Copyright 2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2014-12-09	created
 */
package hireright.sdk.util;

import java.util.Collection;

/**
 * Generates XML as text of following kind:
 * 
 * <Entities>
 * 	 <Entity key="123">45678</Entity>
 *   <Entity key="ABCD">EFGH</Entity>
 *   ...
 * </Entities>
 * 
 * where "key" is textual representation of specified entities, and values are their values produced by specified 
 * converter (hashed, encrypted etc.)
 * This class is for consumers who just need the XML and don't care about element names. 
 *  
 * @author apodlipski
 */
public class CEntityGenerator<T> implements IGenerator<String>
{
	private Collection<T> m_entities;
	private IConverter<T, String> m_converter;
	
	/** Instantiation guard to prevent uncontrollable instantiation. */
	protected CEntityGenerator()
	{
	}

	/**
	 * Instantiation controller. 
	 * @param <T>
	 * @param entities entities to encrypt.
	 * @param cryptoKey key to encrypt entities with.
	 * @return
	 */
	public static <T> CEntityGenerator<T> getInstance(Collection<T> entities, IConverter<T, String> c)
	{
		CEntityGenerator<T> g = new CEntityGenerator<T>();
		g.setEntities(entities);
		g.setConvertor(c);
		return g;
	}

	public void setConvertor(IConverter<T, String> c)
	{
		m_converter = c;
	}
	
	public void setEntities(Collection<T> entities)
	{
		m_entities = entities; 
	}
		
	/**
	 * IGenerator contract implementation: generates primitive XML-like strings with known entities.  
	 * @see hireright.sdk.util.IXmlGenerator#generate()
	 */
	@Override
	public String generate() throws Exception
	{
		StringBuffer sb = new StringBuffer("<Entities>\n");
		for (T entity : m_entities)
		{
			if (entity != null)
			{
				sb.append("<Entity key=\"" + entity.toString() + "\">" + m_converter.convert(entity) + "</Entity>\n");
			}
		}
		sb.append("</Entities>\n");
		return sb.toString(); 
	}
}
