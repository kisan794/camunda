/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	Tanel.Prikk	2017-08-11	Created
 */
package hireright.sdk.util;

public interface IContainsProperties
{
	public CProperties getProperties();
	public void setProperties(CProperties properties);
}
