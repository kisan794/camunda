/*
 * @(#)$RCSfile: IObjectProxy.java,v $ $Revision: 1.2 $ $Date: 2015/05/09 08:53:47 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/IObjectProxy.java,v $
 * Copyright 2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2015-04-27	created
 */
package hireright.sdk.util;

import java.io.Serializable;

/**
 * Object proxy interface, used in scenarios where passing something that gives access to the object 
 * is more preferable than passing the object itself. 
 * @author apodlipski
 */
public interface IObjectProxy<T>
{
	/** 
	 * Asks proxy to acquire the object, whatever this means in given context. This could involve returning singleton, 
	 * reading the object from cache, loading from DB etc. 
	 */
	public T getObject(Serializable objectID);
}
