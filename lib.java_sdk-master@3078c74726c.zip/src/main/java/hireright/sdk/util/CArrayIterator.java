/*
 * @(#)$RCSfile: CArrayIterator.java,v $ $Revision: 1.6 $ $Date: 2008/09/05 10:15:00 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CArrayIterator.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2005-08-18 	A.Solntsev			Created
 * 	2006-11-23	A.Solntsev			implements Serializable
 */
package hireright.sdk.util;
import java.io.Serializable;
import java.util.Iterator;

/**
 * Iterator over elements of given array
 *
 * @author Andrei Solntsev
 * @since 2005-08-18
 * @version $Revision: 1.6 $, $Date: 2008/09/05 10:15:00 $, $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CArrayIterator.java,v $
 */
public class CArrayIterator<T extends Serializable> implements Iterator<T>, Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: asolntsev $";
	
	/**
	 * @serial
	 */
	private final T[] m_array;

	/**
	 * Index of current (active) element in this iterator
	 */
	private int m_index;
	
	public CArrayIterator(T[] array)
	{
		m_array = array;
		m_index = 0;
	}
	
	public boolean hasNext()
	{
		return (m_index < m_array.length);
	}

	public T next()
	{
		return m_array[m_index++];
	}

	public void remove()
	{
		throw new UnsupportedOperationException();
	}
}