/*
 * @(#)$RCSfile: ISortableDataSource.java,v $ $Revision: 1.3 $ $Date: 2007/09/14 09:03:01 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	Alexander Nesterov			2004-10-20	Created
 * 	A.Solntsev					2006-11-23	included into java_sdk_v2-6-20
 */
package hireright.sdk.util;

/**
 * Data source that support sorting of records
 * @author Alexander Nesterov
 * @version $Revision: 1.3 $ $Date: 2007/09/14 09:03:01 $ $Author: asolntsev $
 * @since 2004
 */
public interface ISortableDataSource
{
	/**
	 * Opens data source
	 * @return true if successfull
	 */
	public boolean open();

	/**
	 * Closes data source
	 */
	public void close();

	/**
	 * Sets sorting type
	 * @param nSortingType
	 */
	public void setSortingType(int nSortingType);

	/**
	 * Applys data filter
	 * @param filter
	 */
	public void setFilter(IDataFilter filter);

	/**
	 * Returns next avaliable record
	 * @return record object or null
	 */
	public CRecord next();
}