/*
 *
 * Copyright 2001-2019 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Vassiljev		2019-03-19	Created
 */
package hireright.sdk.util;

/**
 * 
 */
public interface IStringSanitizer
{
	public String replace(final String src);
	
	public String replace(final String src, final String sSourceLanguage);
}
