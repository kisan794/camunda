/*
 * @(#)$RCSfile: CConversions.java,v $ $Revision: 1.2 $ $Date: 2015/11/02 20:16:42 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CConversions.java,v $
 * Copyright 2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2015-03-31	created
 */
package hireright.sdk.util;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Generic object conversion logic.
 * @author apodlipski
 */
public final class CConversions
{
	/**
	 * Generic conversion method for transforming object collections. Uses ArrayList for target collection.
	 * @param <T>
	 * @param <S>
	 * @param sourceCollection
	 * @param converter
	 * @return
	 */
	public static <T, S> Collection<S> convert(Collection<T> sourceCollection, IConverter<T, S> converter)
	{
		Collection<S> targetCollection = new ArrayList<S>();
		if (sourceCollection != null && !sourceCollection.isEmpty())
		{
			for (T t : sourceCollection)
			{
				targetCollection.add(converter.convert(t));	
			}
		}
		return targetCollection;
	}
}
