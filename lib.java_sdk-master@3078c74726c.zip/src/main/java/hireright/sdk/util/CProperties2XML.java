/*
 * @(#)$RCSfile: CProperties2XML.java,v $ $Revision: 1.7 $ $Date: 2013/12/13 08:14:56 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CProperties2XML.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   A.Larin			2006-05-06	Created
 *   V.Lazarev		2006-05-25	Moved to hireright.sdk.util package.
 *   M.Suhhoruki	2007-11-15	toXML(CProperties) returns invalid XML when
 *   					property value has & character outside &amp; sequence.
 *   					2007-11-16	Tests moved to hireright.sdk.uti.CProperties2XMLTest
 *   M.Suhhoruki	2008-05-14	private made public: toXML(CProperties, String, String, String)
 *   M.Suhhoruki	2009-08-12	toXML(CProperties): convert < and > to &lt; and &gt;
 *   					StringBuffer -> StringBuilder
 *   A.Podlipski	2013-11-08	toXML(): declared property sorting is now working
 */
package hireright.sdk.util;

import java.util.Iterator;

/**
 * This class provides the toXML() static method for generating properties
 * XML string representation.
 * An XML format must be specified by version.
 * <p/>
 * For example, the following code generates properties XML string
 * with new naming conventions (Properties/Property):<br/>
 * <code>
 * String propertiesXML = CProperties2XML.
 * toXML(templatePage.m_Properties, CProperties2XML.VERSION_1_1);
 * </code>
 * @author Artem Larin
 */
public class CProperties2XML
{
// ------------------------------ FIELDS ------------------------------

	/**
	 * Defines version 1.0 for properties (old XML naming convention,
	 * properties/property).
	 * Example:
	 * <pre>
	 * &lt;properties version="1.0">
	 * 	&lt;property name="id">1&lt;/property>
	 * 	&lt;property name="prop">value&lt;/property>
	 * &lt;/properties>
	 * </pre>
	 */
	public final static int VERSION_1_0 = 1;

	/**
	 * Defines version 1.1 for properties (new XML naming convention
	 * Properties/Property).
	 * Example:
	 * <pre>
	 * &lt;Properties version="1.1">
	 * 	&lt;Property name="id">1&lt;/Property>
	 * 	&lt;Property name="prop">value&lt;/Property>
	 * &lt;/Properties>
	 * </pre>
	 */
	public final static int VERSION_1_1 = 11;

// -------------------------- STATIC METHODS --------------------------

	/**
	 * Returns XML representation (String) of specified properties object.
	 * @param properties CProperties instance to be converted into XML
	 * @param nVersion	 version which defines XML format
	 * @return XML string representation or null
	 *         if no properties object was specified
	 * @see #VERSION_1_0
	 * @see #VERSION_1_1
	 */
	public static String toXML(CProperties properties, int nVersion)
	{
		if (properties == null)
			return null;

		/**
		 * Generate XML depending on version number.
		 */
		String szResult;
		switch (nVersion)
		{
			case VERSION_1_0:
				szResult = toXML(properties, "properties", "property", "name");
				break;
			case VERSION_1_1:
				szResult = toXML(properties, "Properties", "Property", "name");
				break;
			default:
				throw new IllegalArgumentException("Unknown version");
		}

		return szResult;
	}

	/**
	 * Returns XML representation of CProperties object, alphabetically sorted.
	 * @param properties				 CProperties instance to make XML representation
	 * @param sPropertiesTagName a tag name for root tag "properties"
	 * @param sPropertyTagName	 a tag name for each property
	 * @param sNameAttributeName an attribute name for property
	 * @return String XML or null if no properties defined
	 *         <properties>
	 *         <property name="id">1</property>
	 *         ......
	 *         </properties>
	 */
	public static String toXML(CProperties properties, String sPropertiesTagName,
					String sPropertyTagName, String sNameAttributeName)
	{
		/**
		 * Check arguments for validity.
		 */
		if (properties == null)
		{
			throw new IllegalArgumentException("Null properties object");
		}
		if (sPropertiesTagName == null)
		{
			throw new IllegalArgumentException("Null properties tag name");
		}
		if (sPropertyTagName == null)
		{
			throw new IllegalArgumentException("Null property tag name");
		}
		if (sNameAttributeName == null)
		{
			throw new IllegalArgumentException("Null name attribute name");
		}

		/**
		 * Assemble XML string with properties.
		 */
		StringBuilder sb = new StringBuilder(properties.size() * 60);
		Iterator itKeys = properties.getSortedKeys();
		if (itKeys.hasNext())
		{
			sb.append("<").append(sPropertiesTagName).append(">");
			while (itKeys.hasNext())
			{
				String szKey = (String) itKeys.next();
				String szValue = properties.getProperty(szKey);

				sb.append("<").append(sPropertyTagName).append(" ")
								.append(sNameAttributeName).append("=\"").append(szKey)
								.append("\">");
				sb.append(almostXMLSafe(szValue));
				sb.append("</").append(sPropertyTagName).append(">");
			}
			sb.append("</").append(sPropertiesTagName).append(">");
		}

		return sb.toString();
	}
	
	private static final String almostXMLSafe(String sValue)
	{
		if (sValue != null)
		{
			if (sValue.indexOf('&') != -1)
			{
				// substitute & character with &amp;
				sValue = sValue.replaceAll("&(?!amp;)", "&amp;");
			}
			if (sValue.indexOf('<') != -1)
			{
				sValue = sValue.replaceAll("<", "&lt;");
			}
			if (sValue.indexOf('>') != -1)
			{
				sValue = sValue.replaceAll(">", "&gt;");
			}
		}
		
		return sValue;
	}
}
