/*
 * @(#)$RCSfile: IDataFilter.java,v $ $Revision: 1.3 $ $Date: 2007/09/14 09:02:46 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	Alexander Nesterov			2004-10-20	Created
 * 	A.Solntsev					2006-11-23	Added to java_sdk_v2-6-20
 */
package hireright.sdk.util;

/**
 * Interface for filtering data of some abstract data source
 */
public interface IDataFilter
{
}