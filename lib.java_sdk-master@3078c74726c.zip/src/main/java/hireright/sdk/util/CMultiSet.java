/*
 * @(#)$RCSfile: CMultiSet.java,v $ $Revision: 1.6 $ $Date: 2008/09/05 10:19:14 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CMultiSet.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   A.Solntsev		2005-08-11	created
 *   A.Solntsev		2006-05-11	implements Serializable
 *   A.Solntsev		2008-08-28	using generics
 */
package hireright.sdk.util;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;

/**
 * Class implements a set in which every element can present
 * in several exemplars.
 * 
 * Example of usage: See JUnit-test
 * utests/java/hireright/sdk/util/CMultiSetTest.java
 * 
 * @author	Andrei Solntsev
 * @date		2005-08-11
 * @since		java_sdk_v2-5-32
 * @version $Revision: 1.6 $ $Date: 2008/09/05 10:19:14 $ $Author: asolntsev $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CMultiSet.java,v $
 */
public class CMultiSet<T> implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: asolntsev $";
	
	public static final Integer ZERO = new Integer(0);
	public static final Integer ONE = new Integer(1);
	
	/**
	 * The main internal structure.
	 * Maps objects to Integers (number of exemplars)
	 */
	private	Map<T, Integer> m_map;
	
	/**
	 * Default contructor
	 */
	public CMultiSet()
	{
		m_map = new HashMap<T, Integer>();
	}

	public CMultiSet(int initialCapacity)
	{
		m_map = new HashMap<T, Integer>(initialCapacity);
	}
	
	public CMultiSet(int initialCapacity, float loadFactor)
	{
		m_map = new HashMap<T, Integer>(initialCapacity, loadFactor);
	}
	
	/**
	 * @return 	true iff map contains at least one exemplar of this object.
	 * @param object	any object with method equals() and hashCode()
	 */
	public boolean containsObject(T object)
	{
		return m_map.containsKey(object);
	}
	
	/**
	 * Method puts object into set. If this set already contained, say, 2
	 * exemplars of this objects, then after this operation set will contain
	 * 3 exemplars.
	 * 
	 * If set didn't contain this object, then after this operation set will
	 * contain 1 exemplar.
	 * 
	 * @return Integer - number of exemplars of this object.
	 * @param object	any object with method equals() and hashCode()
	 */
	public Integer put(T object)
	{
		Integer nTimes = m_map.get(object);
		if (nTimes == null)
			nTimes = ONE;
		else
			nTimes = new Integer(1 + nTimes.intValue());

		m_map.put(object, nTimes);
		return nTimes;
	}

	/**
	 * Method removes one exemplar of this object from set. 
	 * 
	 * If this set contained, say, 3 exemplars of this objects, then after this
	 * operation set will contain 2 exemplars.
	 * 
	 * If set didn't contain this object, method does nothing.
	 * 
	 * @return Integer - number of exemplars of this object.
	 * @param object	any object with method equals() and hashCode()
	 */
	public Integer remove(T object)
	{
		Integer nTimes = m_map.get(object);
		if (nTimes == null || nTimes.intValue() < 2)
		{
			nTimes = ZERO;
			m_map.remove(object);
		}
		else
		{
			nTimes = new Integer(nTimes.intValue() - 1);
			m_map.put(object, nTimes);
		}

		return nTimes;
	}

	/**
	 * Removes all objects from this set.
	 */
	public void clear()
	{
		m_map.clear();
	}
	
	/**
	 * @return true iff set is empty (contains no objects)
	 */
	public boolean isEmpty()
	{
		return m_map.isEmpty();
	}
	
	/**
	 * Method returns sorted Iterator over all object contained in set (every
	 * object only once!). For sorting objects natural order is used.
	 * @return Iterator
	 */
	public Iterator<T> listObjects()
	{
		return new TreeSet<T>(m_map.keySet()).iterator();
	}
	
	/**
	 * Hw many exemplars of this object this set contains
	 * @return 0 iff set doesn't contain given object
	 * @param object
	 */
	public int getArity(T object)
	{
		Integer nTimes = m_map.get(object);
		return (nTimes == null ? 0 : nTimes.intValue());
	}
}