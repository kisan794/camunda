/*
 * @(#)$RCSfile: CCounter.java,v $ $Revision: 1.5 $ $Date: 2009/10/23 08:14:46 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CCounter.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Nesterov		2001-11-30	created
 *	A.Solntsev		2007-06-05	added counter name; implements Serializable
 *	A.Solntsev		2009-10-21	added optional parameter "maxCount"
 */
package hireright.sdk.util;

import java.io.Serializable;

/**
 * It's a class just because this stupid language has no struct keyword.
 *
 * @author Alexander Nesterov
 * @since Jun 5, 2007
 * @version $Revision: 1.5 $ $Date: 2009/10/23 08:14:46 $ $Author: asolntsev $
 */
public class CCounter implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: asolntsev $";
	
	private final String m_sName;
	private int m_nCount;
	private final int m_nMaxCount;

	public CCounter(String sName)
	{
		this(sName, 0);
	}

	/**
	 * @deprecated Use constructor with counter name
	 */
	public CCounter()
	{
		this("Counter", 0);
	}

	public CCounter(String sName, int nCount)
	{
		this(sName, nCount, -1);
	}

	/**
	 * 
	 * @param sName
	 * @param nCount
	 * @param maxCount If given, counter value cannot exceed it. If exceeds, it is reset to 0.
	 */
	public CCounter(String sName, int nCount, int maxCount)
	{
		m_sName = sName;
		m_nCount = nCount;
		m_nMaxCount = maxCount;
	}
	
	public void setCount(int nCount)
	{
		m_nCount = nCount;
	}

	public final int getCount()
	{
		return m_nCount;
	}

	/**
	 * @deprecated Use method with a shorter name: inc()
	 */
	public final void incCount()
	{
		inc();
	}

	public void inc()
	{
		m_nCount++;
		if (m_nMaxCount > -1 && m_nCount > m_nMaxCount)
			m_nCount = m_nCount - m_nMaxCount - 1;
	}

	/**
	 * @deprecated Use method with a shorter name: dec()
	 */
	public final void decCount()
	{
		dec();
	}

	public void dec()
	{
		m_nCount--;
	}

	@Override
	public String toString()
	{
		return m_sName + ": " + String.valueOf(m_nCount);
	}
}


