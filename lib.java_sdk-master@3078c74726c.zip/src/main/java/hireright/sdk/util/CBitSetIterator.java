/*
 * @(#)$RCSfile: CBitSetIterator.java,v $ $Revision: 1.7 $ $Date: 2009/03/20 10:33:29 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CBitSetIterator.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	2005-06-27	A.Solntsev			Created
 *	2006-11-23	A.Solntsev			implements Serializable
 *	2008-02-05	A.Solntsev			Bugfix: check parameter for null
 *	2009-03-12	A.Solntsev			Using generics: implements Iterator<Integer>
 */
package hireright.sdk.util;
import java.io.Serializable;
import java.util.BitSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A simple utility class for iterating over all set bits in given BitSet.
 * Iterator returns Integers - positions of set bits.
 *
 * @author Andrei Solntsev
 * @since 2005-06-27 [java_sdk_v2-5-27]
 * @version $Revision: 1.7 $ $Date: 2009/03/20 10:33:29 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CBitSetIterator.java,v $
 */
public class CBitSetIterator implements Iterator<Integer>, Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
	/**
	 * @serial
	 */
	private final BitSet m_bitset;
	private int m_nModuleID;

	public CBitSetIterator(BitSet bitset)
	{
		m_bitset = bitset;
		m_nModuleID = (m_bitset == null ? -1 : m_bitset.nextSetBit(0));
	}

	public boolean hasNext()
	{
		return (m_nModuleID >= 0);
	}

	public Integer next()
	{
		if (!hasNext())
			throw new NoSuchElementException("Don't call method next() if iterator has no more elements");
		
		Integer moduleID = new Integer(m_nModuleID);
		m_nModuleID = m_bitset.nextSetBit(m_nModuleID+1);
		return moduleID;
	}

	public void remove()
	{
		throw new UnsupportedOperationException();
	}

	/**
	 * Static utility for creating BitSet from any collection of Integers.
	 * @param list	Any Collection containing Integers.
	 * @return instance of BitSet with set bits corresponding to Integers from Collection
	 */
	public static BitSet createBitSet(Collection<Integer> bitIndexes)
	{
		BitSet bs = new BitSet(bitIndexes.size());
		for (Integer bit : bitIndexes)
		{
			bs.set( bit.intValue() );
		}
		return bs;
	}
}