/*
 * @(#)$RCSfile: CPeriodType.java,v $ $Revision: 1.4 $ $Date: 2007/09/14 09:02:13 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	A.Solntsev			2007-01-18	created
 *  V. Lazarev			2007-02-19	moved to hireright.sdk.util and updated
 *	A.Solntsev			2007-02-22	Added constant CPeriodType.FIVE_MINUTES
 */
package hireright.sdk.util;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * The descriptor of time period.
 *
 * @author Andrei Solntsev
 * @author Vladimir Lazarev
 */
public class CPeriodType implements Serializable
{
	public static final CPeriodType MINUTE = new CPeriodType(Calendar.MINUTE, "MINUTE",
		"yyyy-MM-dd'T'HH:mm", new DateShift(1, 1, 1, 1, 1), new DateShift(1, 0, 0, 0, 0));

	public static final CPeriodType HOUR = new CPeriodType(Calendar.HOUR_OF_DAY, "HOUR",
		"yyyy-MM-dd'T'HH", new DateShift(0, 1, 1, 1, 1), new DateShift(0, 1, 0, 0, 0));

	public static final CPeriodType DAY = new CPeriodType(Calendar.DAY_OF_MONTH, "DAY",
		"yyyy-MM-dd", new DateShift(0, 0, 1, 1, 1), new DateShift(0, 0, 1, 0, 0));

	public static final CPeriodType MONTH = new CPeriodType(Calendar.MONTH, "MONTH",
		"yyyy-MM", new DateShift(0, 0, 0, 1, 1), new DateShift(0, 0, 0, 1, 0));

	public static final CPeriodType YEAR = new CPeriodType(Calendar.YEAR, "YEAR",
		"yyyy", new DateShift(0, 0, 0, 0, 1), new DateShift(0, 0, 0, 0, 1));

	public static final CPeriodType FIVE_MINUTES = new CPeriodType(Calendar.MINUTE, "FIVE_MINUTES",
		"yyyy-MM-dd'T'HH:mm", new DateShift(-666, 1, 1, 1, 1), new DateShift(-666, 0, 0, 0, 0))
	{
		protected int resetMinutes(int keepMinutes, int nMinute)
		{
			return nMinute - (nMinute % 5);
		}

		protected int incMinutes(int keepMinutes, int incMinutes, int nMinute)
		{
			return nMinute - (nMinute % 5) + 5;
		}

		private Object readResolve()
		{
			return CPeriodType.FIVE_MINUTES;
		}
	};

	private final int	m_nCalendarType;
	private final String m_sPeriodType;
	private final DateFormat m_dateFormat;
	private final DateShift m_fieldsToReset;
	private final DateShift m_fieldsToIncrement;

	private CPeriodType(
			final int nCalendarType,
			final String sPeriod,
			String sDateFormat,
			final DateShift fieldsToReset,
			final DateShift fieldsToIncrement)
	{
		super();

		m_nCalendarType = nCalendarType;
		m_sPeriodType = sPeriod;
		m_dateFormat = new SimpleDateFormat(sDateFormat);
		m_fieldsToReset = fieldsToReset;
		m_fieldsToIncrement = fieldsToIncrement;
	}

	public final String toString()
	{
		return m_sPeriodType;
	}

	public final int hashCode()
	{
		return m_sPeriodType.hashCode();
	}

	private int resetDay(int keepDay, int day)
	{
		if (keepDay == 1)
			return day;

		return 1; // since day range is [1..31]
	}

	protected int resetMinutes(int keepMinutes, int nMinute)
	{
		return keepMinutes*nMinute;
	}

	protected int incMinutes(int keepMinutes, int incMinutes, int nMinute)
	{
		return keepMinutes*nMinute + incMinutes;
	}

	public Date getBeginningOfPeriod(Date middleOfPeriod)
	{
		return new Date(
			middleOfPeriod.getYear(),
			m_fieldsToReset.m_nMonth * middleOfPeriod.getMonth(),
			resetDay(m_fieldsToReset.m_nDays, middleOfPeriod.getDate()),
			m_fieldsToReset.m_nHours * middleOfPeriod.getHours(),
			resetMinutes(m_fieldsToReset.m_nMinutes, middleOfPeriod.getMinutes()));
	}

	public Date getEndOfPeriod(Date middleOfPeriod)
	{
		return new Date(
			middleOfPeriod.getYear() + m_fieldsToIncrement.m_nYear,
			m_fieldsToReset.m_nMonth * middleOfPeriod.getMonth() + m_fieldsToIncrement.m_nMonth,
			resetDay(m_fieldsToReset.m_nDays, middleOfPeriod.getDate()) + m_fieldsToIncrement.m_nDays,
			m_fieldsToReset.m_nHours * middleOfPeriod.getHours() + m_fieldsToIncrement.m_nHours,
			incMinutes(m_fieldsToReset.m_nMinutes, m_fieldsToIncrement.m_nMinutes, middleOfPeriod.getMinutes()));
	}

	public String formatDate(Date date)
	{
		return m_dateFormat.format(date);
	}

	/**
	 * @see System#currentTimeMillis()
	 *
	 * @param timeMls
	 * @return
	 */
	public String formatDate(long timeMls)
	{
		return m_dateFormat.format( new Date(timeMls) );
	}


	public Date parseDate(String sDate)
	{
		Date date;

		try
		{
			date = m_dateFormat.parse(sDate);
		}
		catch (ParseException ex)
		{
			date = null;
		}

		return date;
	}

	public int getCalendarType()
	{
		return m_nCalendarType;
	}

	/**
	 * NB! This method is strongly required for serialization. It allows typesafe enumeration to save the same
	 * instances when deserializing enumeration items.
	 *
	 * @return One of incstances HOUR, DAY, MONTH, YEAR
	 * @throws IllegalArgumentException if object is not in (HOUR, DAY, MONTH, YEAR)
	 */
	private Object readResolve()
	{
		return valueOf(m_sPeriodType);
	}

	public static final CPeriodType valueOf(String sPeriodType)
	{
		if (MINUTE.m_sPeriodType.equals(sPeriodType))
			return MINUTE;
		if (FIVE_MINUTES.m_sPeriodType.equals(sPeriodType))
			return FIVE_MINUTES;
		else if (HOUR.m_sPeriodType.equals(sPeriodType))
			return HOUR;
		else if (DAY.m_sPeriodType.equals(sPeriodType))
			return DAY;
		else if (MONTH.m_sPeriodType.equals(sPeriodType))
			return MONTH;
		else if (YEAR.m_sPeriodType.equals(sPeriodType))
			return YEAR;
		else
			throw new IllegalArgumentException("Unknown summary period: " + sPeriodType);
	}

	private static final class DateShift implements Serializable
	{
		/**
		 * @see Calendar#MINUTE
		 */
		private final int m_nMinutes;

		/**
		 * @see Calendar#HOUR_OF_DAY
		 */
		private final int m_nHours;

		/**
		 * @see Calendar#DAY_OF_MONTH
		 */
		private final int m_nDays;

		/**
		 * @see Calendar#MONTH
		 */
		private final int m_nMonth;

		/**
		 * @see Calendar#YEAR
		 */
		private final int m_nYear;

		public DateShift(final int nMinutes, final int nHours,
			final int nDays, final int nMonth, final int nYear)
		{
			m_nMinutes = nMinutes;
			m_nHours = nHours;
			m_nDays = nDays;
			m_nMonth = nMonth;
			m_nYear = nYear;
		}

		public String toString()
		{
			return "min: " + m_nMinutes + "  hr: " + m_nHours + "  day: " + m_nDays
				+ "  month: " + m_nMonth + "  year: " + m_nYear;
		}
	}
}
