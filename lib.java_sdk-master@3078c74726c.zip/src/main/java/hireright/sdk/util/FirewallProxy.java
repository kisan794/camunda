/*
 * @(#)$RCSfile: FirewallProxy.java,v $Revision: 1.2 $ $Date: 2010/03/11 21:42:50 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/FirewallProxy.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 *	A.Solntsev			2010-03-05	Created
 */
package hireright.sdk.util;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $ $Date: 2010/03/11 21:42:50 $ $Author: cvsroot $
 */
public class FirewallProxy
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	/**
	 * Create a proxy object that doesn't allow calling some methods.
	 * E.g. instance of java.sql.Connection which doesn't allow calling "close" method.
	 * 
	 * @param <T>
	 * @param object
	 * @param forbiddenMethods
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T createProxy( final T object, Class<T> clazz, Collection<String> forbiddenMethods )
	{
		return (T) java.lang.reflect.Proxy.newProxyInstance(
				object.getClass().getClassLoader(),
				new Class<?>[] {clazz},
				new FirewallInvocationHandler(object, forbiddenMethods));
	}
}

class FirewallInvocationHandler implements InvocationHandler
{
	private final Object delegate;
	private final Collection<String> forbiddenMethods;
	
	public FirewallInvocationHandler( final Object delegate, final Collection<String> forbiddenMethods )
	{
		this.delegate = delegate;
		this.forbiddenMethods = forbiddenMethods;
	}
	
	public Object invoke( Object proxy, Method m, Object[] args ) throws Throwable
	{
		Object result;
		try
		{
			if (forbiddenMethods.contains( m.getName() ))
			{
				throw new UnsupportedOperationException("Method" + m.getName() + " is prohibited");
			}

			result = m.invoke( delegate, args );
		}
		catch ( InvocationTargetException e )
		{
			throw e.getTargetException();
		}
		
		return result;
	}	
}
