/*
 *
 * Copyright 2001-2019 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Vassiljev		2019-03-19	Created
 */
package hireright.sdk.util;

import hireright.sdk.util.CDataSanitizer;


/**
 * Wrapper over CDataSanitizer
 */
public class CStringSanitizer implements IStringSanitizer
{
	/**
	 * Wrapper over CDataSanitizer.replace
	 */
	public String replace(final String src)
	{
		return CDataSanitizer.replace(src);
	}
	
	/**
	 * Wrapper over CDataSanitizer.replace
	 */
	public String replace(final String src, final String sSourceLanguage)
	{
		return CDataSanitizer.replace(src, sSourceLanguage);
	}
}
