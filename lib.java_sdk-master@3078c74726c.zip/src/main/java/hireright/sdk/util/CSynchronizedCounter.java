/*
 * @(#)$RCSfile: CSynchronizedCounter.java,v $Revision: 1.4 $ $Date: 2009/11/20 11:28:59 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CSynchronizedCounter.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 *	A.Solntsev				2007-06-05	created
 *	A.Solntsev				2009-11-17	Bugfix: m_lock is now Serializable
 */
package hireright.sdk.util;

import java.io.Serializable;

/**
 * @author Andrei Solntsev
 * @since Jun 5, 2007
 * @version $Revision: 1.4 $ $Date: 2009/11/20 11:28:59 $ $Author: cvsroot $
 */
public class CSynchronizedCounter extends CCounter
{
	private final Serializable m_lock = new Serializable(){};

	public CSynchronizedCounter(String sName)
	{
		super(sName);
	}
	
	public CSynchronizedCounter(String sName, int nCount, int maxCount)
	{
		super(sName, nCount, maxCount);
	}

	@Override
	public void setCount(int nCount)
	{
		synchronized (m_lock)
		{
			super.setCount(nCount);
		}
	}

	@Override
	public void inc()
	{
		synchronized (m_lock)
		{
			super.inc();
		}
	}

	@Override
	public void dec()
	{
		synchronized (m_lock)
		{
			super.dec();
		}
	}
}
