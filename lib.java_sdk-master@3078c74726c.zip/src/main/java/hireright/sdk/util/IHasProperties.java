/*
 * @(#)$RCSfile: IHasProperties.java,v $ $Revision: 1.6 $ $Date: 2007/09/14 09:02:52 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  A.Solntsev	2006-01-10	created
 */
package hireright.sdk.util;

/**
 * Any object that has properties or can be represented as a set of properties.
 *  
 * @author Andrei Solntsev
 * @since java_sdk_v2-6-5
 */
public interface IHasProperties
{
	CProperties toProperties();
}
