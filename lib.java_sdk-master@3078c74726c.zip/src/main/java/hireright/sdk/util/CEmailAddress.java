/*
 * @(#)$RCSfile: CEmailAddress.java,v $ $Revision: 1.2 $ $Date: 2013/12/13 08:15:37 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CEmailAddress.java,v $
 *
 * Copyright 2008-2013 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  M. Suhhoruki	2013-12-02	Created.
 *  
 */
package hireright.sdk.util;

import java.io.Serializable;

@SuppressWarnings("serial")
public final class CEmailAddress implements Serializable
{
	private final String m_sLocalPart;
	private final String m_sDomain;
	
	public CEmailAddress(String sLocalPart, String sDomain)
	{
		m_sLocalPart = sLocalPart;
		m_sDomain = sDomain;
	}
	
	public String getLocalPart()
	{
		return m_sLocalPart;
	}
	
	public String getDomain()
	{
		return m_sDomain;
	}
	
	@Override
	public int hashCode()
	{
		String sLocalPart = (m_sLocalPart != null) ? m_sLocalPart : "";
		String sDomain = (m_sDomain != null) ? m_sDomain.toUpperCase() : "";
		
		return (sLocalPart + sDomain).hashCode();
	}
	
	/**
	 * Checks case-sensitive local part and case-insensitive domain.
	 * @param obj
	 * @return false when argument is null or is not CEmailAddress instance
	 * 			otherwise equality checks are performed.
	 */
	@Override
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof CEmailAddress))
		{
			return false;
		}
		
		CEmailAddress addr = (CEmailAddress) obj;
		if (getLocalPart() == null && addr.getLocalPart() != null)
		{
			return false;
		}
		else if (getDomain() == null && addr.getDomain() != null)
		{
			return false;
		}
		
		return getLocalPart().equals(addr.getLocalPart())
				&& getDomain().equalsIgnoreCase(addr.getDomain());
	}
	
	public static CEmailAddress valueOf(String sEmail)
	{
		if (sEmail == null)
		{
			return null;
		}
		
		int nSobaka = sEmail.indexOf('@');
		if (nSobaka < 1)
		{
			throw new IllegalArgumentException("Unrecognized email address: " + sEmail);
		}
		
		String sLocalPart = sEmail.substring(0, nSobaka);
		String sDomain = sEmail.substring(nSobaka + 1);
		
		return new CEmailAddress(sLocalPart, sDomain);
	}
	
	/**
	 * isEqual("Abc@domain.com", "abc@domain.com"); // false
	 * isEqual("Abc@domain.com", "Abc@Domain.Com"); // true
	 * isEqual("Abc@domain.com", "Abc@domain.com"); // true
	 * 
	 * @see {@link #equals(Object)}
	 * 
	 * @param sEmail1
	 * @param sEmail2
	 * @return
	 */
	public static boolean isEqual(String sEmail1, String sEmail2)
	{
		CEmailAddress email1 = valueOf(sEmail1);
		CEmailAddress email2 = valueOf(sEmail2);
		
		return email1 != null && email2 != null
				&& email1.equals(email2);
	}
}
