/*
 * @(#)$RCSfile: CAmbiguousEntityException.java,v $ $Revision: 1.2 $ $Date: 2015/03/07 07:57:16 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CAmbiguousEntityException.java,v $
 * Copyright 2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2015-02-05	created
 */

package hireright.sdk.util;

/**
 * Exception that indicates existence of multiple entities in a situation when single entity is expected.
 * @author apodlipski
 */
public class CAmbiguousEntityException extends CException
{
	/**
	 * @param sMessage
	 */
	public CAmbiguousEntityException(String sMessage)
	{
		super(sMessage);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public CAmbiguousEntityException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sMessage
	 * @param properties
	 */
	public CAmbiguousEntityException(String sMessage, CProperties properties)
	{
		super(sMessage, properties);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sMessage
	 * @param propOwner
	 */
	public CAmbiguousEntityException(String sMessage, IHasProperties propOwner)
	{
		super(sMessage, propOwner);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sMessage
	 * @param cause
	 */
	public CAmbiguousEntityException(String sMessage, Throwable cause)
	{
		super(sMessage, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 * @param properties
	 */
	public CAmbiguousEntityException(Throwable cause, CProperties properties)
	{
		super(cause, properties);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 * @param properties
	 */
	public CAmbiguousEntityException(Throwable cause, IHasProperties properties)
	{
		super(cause, properties);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sMessage
	 * @param properties
	 * @param sData
	 */
	public CAmbiguousEntityException(String sMessage, CProperties properties,
			String sData)
	{
		super(sMessage, properties, sData);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sMessage
	 * @param propOwner
	 * @param sData
	 */
	public CAmbiguousEntityException(String sMessage, IHasProperties propOwner,
			String sData)
	{
		super(sMessage, propOwner, sData);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 * @param properties
	 * @param sData
	 */
	public CAmbiguousEntityException(Throwable cause, CProperties properties,
			String sData)
	{
		super(cause, properties, sData);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 * @param properties
	 * @param sData
	 */
	public CAmbiguousEntityException(Throwable cause,
			IHasProperties properties, String sData)
	{
		super(cause, properties, sData);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sErrorMessage
	 * @param cause
	 * @param properties
	 */
	public CAmbiguousEntityException(String sErrorMessage, Throwable cause,
			CProperties properties)
	{
		super(sErrorMessage, cause, properties);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sMessage
	 * @param cause
	 * @param propOwner
	 * @param sData
	 */
	public CAmbiguousEntityException(String sMessage, Throwable cause,
			IHasProperties propOwner, String sData)
	{
		super(sMessage, cause, propOwner, sData);
		// TODO Auto-generated constructor stub
	}

}
