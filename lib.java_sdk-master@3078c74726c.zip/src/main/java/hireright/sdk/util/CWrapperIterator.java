/*
 * @(#)$RCSfile: CWrapperIterator.java,v $ $Revision: 1.2 $ $Date: 2010/11/11 21:28:13 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CWrapperIterator.java,v $
 * 
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	E.Shatohhin		2010-10-27	Created
 */

package hireright.sdk.util;

import java.util.Iterator;

/**
 * Iterator that wraps items into a proxy class
 *
 * @author Evgeni Shatohhin
 */
public abstract class CWrapperIterator<Original,Wrapped> implements Iterator<Wrapped>
{
	private Iterator<Original> m_iterator;

	public CWrapperIterator(Iterator<Original> i)
	{
		m_iterator = i;
	}
	
	public boolean hasNext()
	{
		return m_iterator.hasNext();
	}

	public Wrapped next()
	{
		return wrap(m_iterator.next());
	}

	public void remove()
	{
		m_iterator.remove();
	}
	
	/**
	 * Implement this method to create wrapper objects
	 *
	 * @param o - original object
	 * @return wrapped object
	 */
	public abstract Wrapped wrap(Original o);
}