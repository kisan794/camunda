/*
 * @(#)$RCSfile: ArraySort.java,v $ $Revision: 1.5 $ $Date: 2008/11/21 11:32:08 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/ArraySort.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Keks			2001-xx-yy	Created
 *	A.Solntsev		2006-10-12	Removed "throws Exception"
 */
package hireright.sdk.util;
import java.util.Comparator;

/**
 * A Class for sorting arrays of objects
 * 
 * TODO Add usage example
 * 
 * @param <T>
 * 
 * @author Anton Keks
 * @since 2001
 * @version $Revision: 1.5 $, $Date: 2008/11/21 11:32:08 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/ArraySort.java,v $
 */
public class ArraySort<T extends Object>
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	private final Comparator<T> m_comparator;
	private T[] m_array;

	/*public ArraySort()
	{
		this( new NaturalComparer<T>() );
	}*/
	
	public ArraySort(Comparator<T> comparator)
	{
		m_comparator = comparator;
	}

	protected void QuickSortRecursive(int l, int r) 
	{
		int M = 4;
		int i, j;
		T obj;

		if ((r - l) > M)
		{
			i = (r + l) / 2;
			if (m_comparator.compare(m_array[l], m_array[i]) > 0) swapElements(l,i);
			if (m_comparator.compare(m_array[l], m_array[r]) > 0) swapElements(l,r);
			if (m_comparator.compare(m_array[i], m_array[r]) > 0) swapElements(i,r);

			j = r - 1;
			swapElements(i, j);
			i = l;
			obj = m_array[j];
			for(;;)
			{
				do {++i;} while(m_comparator.compare(m_array[i], obj) < 0);
				do {--j;} while(m_comparator.compare(m_array[j], obj) > 0);
				if (j < i) break;
				swapElements(i, j);
			}
			swapElements(i, r - 1);
			QuickSortRecursive(l, j);
			QuickSortRecursive(i + 1, r);
		}
	}

	protected void swapElements(int i, int j)
	{
		T tmp;
		tmp = m_array[i];
		m_array[i] = m_array[j];
		m_array[j] = tmp;
	}

	/**
	 * This method sorts m_array if there is less than 4 elements
	 * 
	 * @param lo0
	 * @param hi0
	 */
	protected void InsertionSort(int lo0, int hi0) 
	{
		int i, j;
		T obj;

		for (i = lo0 + 1; i <= hi0; i++)
		{
			obj = m_array[i];
			j = i;
			while (j > lo0 && m_comparator.compare(m_array[j-1], obj) > 0)
			{
				m_array[j] = m_array[j-1];
				j--;
			}
			m_array[j] = obj;
		}
	}

	public void sort(T[] array) 
	{
		sort(array, 0, array.length - 1);
	}

	public void sort(T[] array, int nFromIndex, int nToIndex) 
	{
		m_array = array;
		QuickSortRecursive(nFromIndex, nToIndex);
		InsertionSort(nFromIndex, nToIndex);
	}
}

