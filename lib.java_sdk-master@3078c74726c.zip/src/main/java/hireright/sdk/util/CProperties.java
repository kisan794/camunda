/*
 * @(#)$RCSfile: CProperties.java,v $ $Revision: 1.37 $ $Date: 2010/02/04 21:16:30 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CProperties.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Plohotnichenko	2002-09-19	Created.
 *	D.Travin			2002-12-04	added method getKeys.
 *	D.Travin			2003-01-06	added constructor for XML.
 *	D.Travin			2003-01-22	properties values can be in CDATA.
 *	D.Travin			2003-05-21	implements Cloneable, bug fixed.
 *	D.Travin			2003-06-07	setProperty overridden.
 *	A.Solntsev			2003-12-12	Method setProperty() is more safe.
 *	S.Ignatov			2003-12-17	java_sdk_v2-4-16:	Method parse changed - removed StringTokenizer parsing of key-value pair.
 *	A.Plohotnichenko	2002-09-19	method remove() addded.
 *	A.Podlipski			2004-05-05	getKeys() now returns keys alphabetically sorted
 *	A.Plohotnichenko	2004-07-12	method toXML added.
 *  A.Solntsev			2005-03-04	Added method getValues()
 *  								Methods setProperty(), setProperties() now return object itself.
 *  A.Solntsev			2005-04-08	Added method getKeysIterator().
 *  A.Solntsev			2005-05-26	Added methods setProperty(boolean), setProperty(int), setProperty(double).
 *  A.Solntsev			2005-07-07	Now properties are sorted alphabetically by key.
 *  A.Solntsev			2005-07-25	Refined: now delimioters are class members and used in method toString().
 *  								Added copy constructor.
 *	A.Solntsev			2005-10-07	Added constant CProperties.NO_PROPERTIES
 *  A.Solntsev			2005-10-20	Added methods size(), getKeysIterator(sPrefix).
 *  A.Solntsev			2005-10-21	Now class doesn't depends on hireright.sdk.html
 *  								2 methods moved to class hireright.sdk.html.utils.XML2Properties
 *  A.Solntsev			2006-04-24	Added method getKeyValues().
 *  A.Solntsev			2006-05-07	Added method hasProperty(); improved method equals().
 *  A.Solntsev			2006-05-16	Added methods CProperties(Map keyValues), getSortedKeys().
 *  A.Solntsev			2006-05-28	Added methods clear(), isEmpty(), setProperties(IHasProperties).
 *  A.Solntsev			2006-06-15	Added method setProperties(Map mapKeyValues); implements IHasProperties
 *  A.Solntsev			2006-08-01	Added methods setProperties(String sPrefix, Map properties) and finalize()
 *  S.Prokopov			2006-10-06	Removed last new line when converting properties to string.
 *  A.Solntsev			2006-11-29	Method toString(): added check if (value instanceof String[])
 *  A.Solntsev			2006-12-12	Added method getMap()
 *  D.Belorunov			2007-07-20	Added functionality to pass Comparator into toString(), method getSortedKeys(Comparator c) added
 *  A.Solntsev			2007-09-06	Copy-constructor: added check for null parameter
 *  A.Solntsev			2008-08-26	using generics: implements IFilter<String>
 *  Y.Shneykin			2009-07-14	Added constructor for XMLTreeNode.
 *	A.Solntsev			2009-12-09	Removed method finalize()
 *	A.Solntsev			2009-12-09	Constructor CProperties(XMLTreeNode) moved to XML2Properties
 *	M.Suhhoruki			2016-10-10	Added valueOf methods
 *	D.Onischenko		2017-01-09	getInteger added
 *	D.Onischenko		2020-08-11	HRG-127676: getLong, getBoolean added to simplify code constructions like Long.parseLong(properties.getProperty("Timeout")) or Logical.isTrue(properties.getProperty("FEATURE_ENABLED"))
 * 	V.Tsetsnev			2021-09-23	HRG-171238: added JAXB annotations needed for marshalling
 */
package hireright.sdk.util;

import hireright.sdk.consts.Logical;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.utils.XML2Properties;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.StringTokenizer;
import java.util.TreeSet;

/**
 * A simple properties container class
 *
 * @author Alexander Plohotnichenko
 * @version $Revision: 1.37 $ $Date: 2010/02/04 21:16:30 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CProperties.java,v $
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class CProperties implements Cloneable, Serializable, IHasProperties
{
	private static final long serialVersionUID = -1243008078850516733l;

	protected static final String CLASS_VERSION = "$Revision: 1.37 $ $Author: cvsroot $";

	/**
	 * Node name for properties.
	 */
	@Deprecated
	public static final String PROPERTIES_NODE_NAME = "properties";

	/**
	 * default delimiter between KEY and VALUE
	 */
	protected static final String EQUAL_SIGN = "=";

	/**
	 * default delimiter is the newline character
	 */
	protected static final String DEFAULT_DELIMETER = "\n";

	// Class members
	@XmlElementWrapper(name = "map")
	protected final Map<String, Object> m_properties;
	protected String m_szDelimiters = DEFAULT_DELIMETER;
	protected String m_szKeyValueSeparator = EQUAL_SIGN;

	/**
	 * Copy constructor
	 *
	 * @param properties instance of CProperties to take copy of. Not null!
	 * @throws NullPointerException if properties is null
	 */
	public CProperties(CProperties properties)
	{
		this();

		if (properties != null)
		{
			m_properties.putAll(properties.m_properties);
			m_szDelimiters = properties.m_szDelimiters;
			m_szKeyValueSeparator = properties.m_szKeyValueSeparator;
		}
	}

	/**
	 * "Copy" constructor
	 * Creates a CProperties instance containing all the key-values from given Map.
	 *
	 * @param keyValues Can contain any objects (not only Strings).
	 *                  When serializing, method String.valueOf() is applied on every key-value.
	 * @since java_sdk_v2-6-9
	 */
	public CProperties(Map<String, ?> keyValues)
	{
		if (keyValues != null)
		{
			m_properties = new HashMap<>(keyValues);
		}
		else
		{
			m_properties = new HashMap<>();
		}
		m_szDelimiters = DEFAULT_DELIMETER;
		m_szKeyValueSeparator = EQUAL_SIGN;
	}

	/**
	 * Empty constructor. Use setProperty() for adding new properties.
	 */
	public CProperties()
	{
		this(null, DEFAULT_DELIMETER, EQUAL_SIGN);
	}

	/**
	 * Constructor parses given String-representation of properties
	 * using default delimiters.
	 *
	 * @param szProperties eg. "name1=param1\nname2=param2\nname3=param3"
	 */
	public CProperties(String szProperties)
	{
		this(szProperties, DEFAULT_DELIMETER, EQUAL_SIGN);
	}


	/**
	 * Constructor with custom delimiter.
	 *
	 * @param szProperties eg. "name1=param1\nname2=param2\nname3=param3"
	 * @param szDelimiters Default deleimiter is "\n".
	 * @see #DEFAULT_DELIMETER
	 */
	public CProperties(String szProperties, String szDelimiters)
	{
		this(szProperties, szDelimiters, EQUAL_SIGN);
	}

	/**
	 * Constructor with custom row delimiter and key/value delimiter.
	 *
	 * @param szProperties        eg. "name1=param1\nname2=param2\nname3=param3"
	 * @param szDelimiters        Default deleimiter is "\n".
	 * @param szKeyValueSeparator Default is "=".
	 * @see #DEFAULT_DELIMETER
	 * @see #EQUAL_SIGN
	 */
	public CProperties(String szProperties, String szDelimiters, String szKeyValueSeparator)
	{
		m_szDelimiters = szDelimiters;
		m_szKeyValueSeparator = szKeyValueSeparator;
		m_properties = parse(szProperties, m_szDelimiters, m_szKeyValueSeparator, false);
	}


	/**
	 * Constructor parses given xmlTreeNode.
	 *
	 * @param propertiesNode XMLTreeNode of following structure:
	 *                       <Properties>
	 *                       <Property name="property_name_1">property_value_1</Property>
	 *                       <Property name="property_name_2">property_value_2</Property>
	 *                       </Properties>
	 * @deprecated Use static factory method {@link XML2Properties#parseProperties(XMLTreeNode)}
	 * (It's not good that class CProperties depends on class XMLTreeNode)
	 */
	@Deprecated
	public CProperties(XMLTreeNode propertiesNode)
	{
		this(XML2Properties.parseProperties(propertiesNode));
	}

	private static Map<String, Object> parse(String szProperties,
		String szDelimiters, String szKeyValueSeparator,
		boolean bTrimValues)
	{
		if (szProperties == null || szProperties.trim().isEmpty())
		{
			return new HashMap<>();
		}

		int nSize =
			Math.max(szProperties.length() - szProperties.replace(szDelimiters, "").length(), 16);
		Map<String, Object> p = new HashMap<>(nSize);
		StringTokenizer stProperties = new StringTokenizer(szProperties, szDelimiters);
		while (stProperties.hasMoreElements())
		{
			String sProperty = stProperties.nextToken();
			int nSeparatorIndex = sProperty.indexOf(szKeyValueSeparator);
			if (nSeparatorIndex != -1)
			{
				String szKey = sProperty.substring(0, nSeparatorIndex);
				String szValue = sProperty.substring(nSeparatorIndex + 1);

				if (szKey != null && !szKey.isEmpty() && szValue != null)
				{
					if (bTrimValues)
					{
						szValue = szValue.trim();
					}
					p.put(szKey, szValue);
				}
			}
		}

		return p;
	}

	public static CProperties valueOf(String szProperties,
		String szDelimiters, String szKeyValueSeparator,
		boolean bTrimValues)
	{
		Map<String, Object> p = parse(szProperties, szDelimiters, szKeyValueSeparator, bTrimValues);
		return new CProperties(p);
	}

	public static CProperties valueOf(String szProperties, boolean bTrimValues)
	{
		return valueOf(szProperties, DEFAULT_DELIMETER, EQUAL_SIGN, bTrimValues);
	}

	public static CProperties valueOf(String szProperties)
	{
		return valueOf(szProperties, DEFAULT_DELIMETER, EQUAL_SIGN, false);
	}

	@Override
	public int hashCode()
	{
		return 19 * m_szDelimiters.hashCode() +
			13 * m_szKeyValueSeparator.hashCode() +
			m_properties.hashCode();
	}

	public boolean hasProperty(String szKey)
	{
		return m_properties.containsKey(szKey);
	}

	/**
	 * @return true iff this object has not properties set up
	 * @since java_sdk_v2-6-11
	 */
	public boolean isEmpty()
	{
		return m_properties == null || m_properties.isEmpty();
	}

	public String getProperty(String szKey)
	{
		return getProperty(szKey, null);
	}

	public String getProperty(String szKey, String szDefValue)
	{
		Object value = null;

		if (szKey != null)
		{
			value = m_properties.get(szKey);
		}

		return (value != null) ? String.valueOf(value) : szDefValue;
	}

	public Integer getInteger(String sKey)
	{
		return getInteger(sKey, null);
	}

	public Integer getInteger(String sKey, Integer nDefault)
	{
		Integer nValue = nDefault;

		String sValue = getProperty(sKey);

		if (CStringUtils.isNumber(sValue))
		{
			nValue = Integer.valueOf(sValue);
		}

		return nValue;
	}

	public Long getLong(String sKey)
	{
		return getLong(sKey, null);
	}

	public Long getLong(String sKey, Long nDefault)
	{
		Long nValue = nDefault;

		String sValue = getProperty(sKey);

		if (CStringUtils.isNumber(sValue))
		{
			nValue = Long.valueOf(sValue);
		}

		return nValue;
	}

	public Boolean getBoolean(String sKey)
	{
		return getBoolean(sKey, null);
	}

	public Boolean getBoolean(String sKey, Boolean bDefault)
	{
		Boolean bValue = bDefault;

		String sValue = getProperty(sKey);

		if (Logical.isTrue(sValue))
		{
			bValue = Boolean.TRUE;
		}

		else if (Logical.isFalse(sValue))
		{
			bValue = Boolean.FALSE;
		}

		return bValue;
	}

	public CProperties setProperty(String szKey, String szValue)
	{
		if (szKey != null && szValue != null && !szKey.isEmpty() && !szValue.isEmpty())
		{
			m_properties.put(szKey, szValue);
		}

		return this;
	}

	public CProperties setProperty(String key, Object object)
	{
		return setProperty(key, (object != null ? object.toString() : null));
	}

	public CProperties setProperty(String key, int number)
	{
		return setProperty(key, String.valueOf(number));
	}

	public CProperties setProperty(String key, long value)
	{
		return setProperty(key, String.valueOf(value));
	}

	public CProperties setProperty(String key, boolean value)
	{
		return setProperty(key, String.valueOf(value));
	}

	public CProperties setProperty(String key, double value)
	{
		return setProperty(key, String.valueOf(value));
	}

	public CProperties setProperty(String key, float value)
	{
		return setProperty(key, String.valueOf(value));
	}

	public CProperties setProperties(CProperties properties)
	{
		if (properties != null)
		{
			m_properties.putAll(properties.m_properties);
		}

		return this;
	}

	/*public CProperties setProperties(Map<String, ?> mapKeyValues)
	{
		if (mapKeyValues != null)
			m_properties.putAll(mapKeyValues);

		return this;
	}*/

	/**
	 * @param mapKeyValues Map which may contain any objects (thought Strings are preferrable)
	 * @return this object
	 * @since java_sdk_v2-6-14
	 */
	public CProperties setProperties(Map<?, ?> mapKeyValues)
	{
		if (mapKeyValues != null)
		{
			for (Map.Entry<?, ?> entry : mapKeyValues.entrySet())
			{
				m_properties.put(String.valueOf(entry.getKey()), String.valueOf(entry.getValue()));
			}
		}

		return this;
	}

	/**
	 * Null-safe method copies all properties from given instance of IHasProperties.
	 *
	 * @param object
	 * @return this object
	 * @since java_sdk_v2-6-11
	 */
	public CProperties setProperties(IHasProperties object)
	{
		if (object != null)
		{
			return setProperties(object.toProperties());
		}

		return this;
	}

	/**
	 * Add all given properties, adding to all names given prefix.
	 * Typical usage:
	 * <p>
	 * <pre>
	 * 	CProperties params = new CProperties();
	 *  params.setProperties("old.", oldProperties);
	 *  params.setProperties("new.", newProperties);
	 * </pre>
	 *
	 * @param sPrefix    Any string, usually it should end with dot "." or semicolomn ":"
	 * @param properties
	 * @return this object
	 * @since java_sdk_v2-6-9
	 */
	public CProperties setProperties(String sPrefix, CProperties properties)
	{
		if (properties != null && !properties.isEmpty())
		{
			return setProperties(sPrefix, properties.m_properties);
		}

		return this;
	}

	/**
	 * Add all given properties, adding to all names given prefix.
	 *
	 * @param sPrefix
	 * @param properties
	 * @return this object
	 * @see #setProperties(String, CProperties)
	 * @since java_sdk_v2-6-13
	 */
	public CProperties setProperties(String sPrefix, Map<String, Object> properties)
	{
		if (properties != null && !properties.isEmpty())
		{
			for (Map.Entry<String, Object> entry : properties.entrySet())
			{
				m_properties.put(sPrefix + entry.getKey(), entry.getValue());
			}
		}

		return this;
	}

	/**
	 * Null-safe method copies all properties from given instance of IHasProperties.
	 *
	 * @param sPrefix Any string, usually it should end with dot "." or semicolomn ":"
	 * @param object
	 * @return this object
	 * @since java_sdk_v2-6-11
	 */
	public CProperties setProperties(String sPrefix, IHasProperties object)
	{
		if (object != null)
		{
			return setProperties(sPrefix, object.toProperties());
		}

		return this;
	}

	public Object remove(String sKey)
	{
		return m_properties.remove(sKey);
	}

	/**
	 * Remove all properties.
	 *
	 * @return this object
	 * @since java_sdk_v2-6-11
	 */
	public CProperties clear()
	{
		m_properties.clear();
		return this;
	}

	/**
	 * Method always returns this object itself
	 *
	 * @return this object
	 * @since java_sdk_v2-6-14
	 */
	public CProperties toProperties()
	{
		return this;
	}

	@Override
	public String toString()
	{
		return toString(m_szDelimiters, m_szKeyValueSeparator);
	}

	public String toString(String szDelimiters)
	{
		return toString(szDelimiters, m_szKeyValueSeparator);
	}

	/**
	 * Returns textual representation of CProperties object - alphabetically sorted set of
	 * (key,value) pairs separated by delimeter.
	 *
	 * @param szDelimiters
	 * @param sKeyValueSeparator
	 * @return String-representation of properties
	 */
	public String toString(String szDelimiters, String sKeyValueSeparator)
	{
		return toString(szDelimiters, sKeyValueSeparator, null);
	}

	/**
	 * Returns textual representation of CProperties object - sorted set of
	 * (key,value) pairs separated by delimeter.
	 *
	 * @param c                  comparator for sorting. If null alphabetical sorting is used.
	 * @param szDelimiters
	 * @param sKeyValueSeparator
	 * @return String-representation of properties
	 */
	public String toString(String szDelimiters, String sKeyValueSeparator, Comparator<String> c)
	{
		StringBuilder sb = new StringBuilder();

		Object value;
		String sValue;
		String[] asValue;

		for (String key : sortedKeys(c))
		{
			value = m_properties.get(key);
			if (value instanceof String[])
			{
				asValue = (String[]) value;
				if (asValue.length == 1)
				{
					sValue = asValue[0];
				}
				else
				{
					sValue = CStringUtils.arrayToString(asValue);
				}
			}
			else
			{
				sValue = String.valueOf(value);
			}

			sb.append(key).append(sKeyValueSeparator).append(sValue).append(szDelimiters);
		}

		return sb.toString();
	}

	/**
	 * Returns XML representation of CProperties object, alphabetically sorted
	 *
	 * @return String XML or null if no properties defined
	 * <properties>
	 * <property name="id">1</property>
	 * ......
	 * </properties>
	 * @deprecated Use static factory method {@link CProperties2XML#toXML(CProperties, int)}.
	 * (It's not good that class CProperties depends on class XMLTreeNode)
	 */
	@Deprecated
	public String toXML()
	{
		return CProperties2XML.toXML(this, CProperties2XML.VERSION_1_0);
		
		/*
		StringBuilder sb = new StringBuilder();

		Set<String> keys = sortedKeys();
		if (keys != null && !keys.isEmpty())
		{
			sb.append("<" + PROPERTIES_NODE_NAME + ">");

			String sValue;
			for (String key : keys)
			{
				sValue = String.valueOf(m_properties.get(key));

				sb.append("<" + PROPERTY_NODE_NAME + " ").append(
						PROPERTY_NODE_NAME_ATTRIBUTE + "=\"").
						append(key).append("\">");
				sb.append(sValue);
				sb.append("</" + PROPERTY_NODE_NAME + ">");
			}
			sb.append("</" + PROPERTIES_NODE_NAME + ">");
		}

		return sb.toString();
		*/
	}

	/**
	 * Returns all keys as a array of Strings
	 *
	 * @return String[] array of string keys
	 * @deprecated Use getValues() or getKeysIterator() instead
	 */
	public String[] getKeys()
	{
		String[] asKeys = new String[m_properties.keySet().size()];
		asKeys = m_properties.keySet().toArray(asKeys);

		Arrays.sort(asKeys);

		return asKeys;
	}

	/**
	 * Returns iterator over all keys.
	 * <p>
	 * NOT RECOMMENDED
	 * It's recommended to use method getKeyValues() since it works faster.
	 *
	 * @return java.util.Iterator
	 */
	public Iterator<String> getKeysIterator()
	{
		return m_properties.keySet().iterator();
	}

	public Set<String> keys()
	{
		return m_properties.keySet();
	}

	/**
	 * Returns iterator over all keys.
	 * Keys are sorted alphabetically.
	 *
	 * @return java.util.Iterator
	 * @since java_sdk_v2-6-9
	 */
	public Iterator<String> getSortedKeys()
	{
		return sortedKeys().iterator();
	}

	/**
	 * Returns iterator over all keys.
	 * Keys are sorted by suplied comparator.
	 *
	 * @param c Comaparator to use. If null, default is used (alphabetically)
	 * @return java.util.Iterator
	 */
	public Iterator<String> getSortedKeys(Comparator<String> c)
	{
		return sortedKeys(c).iterator();
	}

	public Set<String> sortedKeys()
	{
		return new TreeSet<>(m_properties.keySet());
	}

	public Set<String> sortedKeys(Comparator<String> c)
	{
		if (c == null)
		{
			return keys();
		}

		SortedSet<String> sortedKeys = new TreeSet<>(c);
		sortedKeys.addAll(m_properties.keySet());
		return sortedKeys;
	}


	/**
	 * @return Iterator over Map.Entry instances
	 * @see java.util.Map#entrySet()
	 * @since java_sdk_v2-6-8
	 */
	public Iterator<Map.Entry<String, Object>> getKeyValues()
	{
		return m_properties.entrySet().iterator();
	}

	public Set<Map.Entry<String, Object>> keyValues()
	{
		return m_properties.entrySet();
	}

	/**
	 * @return read-only Map of key-value properties
	 * @since java_sdk_v2-6-22
	 */
	public Map<String, Object> getMap()
	{
		return Collections.unmodifiableMap(m_properties);
	}

	/**
	 * Returns iterator over all keys beginning with given prefix.
	 *
	 * @param sPrefix Any non-null string
	 * @return java.util.Iterator
	 */
	public Iterator<String> getKeysIterator(String sPrefix)
	{
		return new CFilteredIterator<>(getKeysIterator(), CStringFilter.startsWith(sPrefix));
	}

	public Iterator<Object> getValues()
	{
		return m_properties.values().iterator();
	}

	/**
	 * @return New instance of CProperties containing the same properties.
	 * @deprecated Use copy constructor
	 */
	@Override
	public Object clone()
	{
		return new CProperties(this);
	}

	/**
	 * Method returns number of properties stored in this object.
	 *
	 * @return 0 if no properties are given
	 */
	public int size()
	{
		return m_properties == null ? 0 : m_properties.size();
	}

	/**
	 * Null-safe wrapper for nonstatic method getProperty(String).
	 *
	 * @param properties
	 * @param szKey
	 * @return null if properties or szKey is null
	 */
	public static String getProperty(CProperties properties, String szKey)
	{
		return (properties == null) ? null :
			properties.getProperty(szKey);
	}

	/**
	 * Null-safe wrapper for nonstatic method getProperty(String, String).
	 *
	 * @param properties
	 * @param szKey
	 * @param szDefValue
	 * @return <code>szDefValue</code> if <code>properties</code> or <code>szKey</code> is null
	 */
	public static String getProperty(CProperties properties, String szKey, String szDefValue)
	{
		return (properties == null) ? szDefValue :
			properties.getProperty(szKey, szDefValue);
	}

	public void setMap(Map<String, Object> properties)
	{
		setProperties(properties);
	}

	@Override
	public boolean equals(Object obj)
	{
		return obj != null && (obj instanceof CProperties) &&
			equals((CProperties) obj);
	}

	/**
	 * Compare 2 CProperties
	 *
	 * @param p2 another properties set
	 * @return false <code>this</code> and <code>p2</code> have different size or have at
	 * least one property which value differs in <code>this</code> and <code>p2</code>.
	 */
	public boolean equals(CProperties p2)
	{
		if (m_properties == null && p2.m_properties == null)
		{
			return true;
		}
		if (m_properties == null || p2.m_properties == null)
		{
			return false;
		}
		if (m_properties.size() != p2.m_properties.size())
		{
			return false;
		}

		// iterate all properties
		String key, sValue1, sValue2;
		for (Map.Entry<String, Object> entry : keyValues())
		{
			key = String.valueOf(entry.getKey());
			sValue1 = String.valueOf(entry.getValue());
			sValue2 = p2.getProperty(key);

			// go on if both are nulls
			if (sValue1 == null && sValue2 == null)
			{
				continue;
			}
			if (sValue1 == null || sValue2 == null)
			{
				return false;
			}

			// at least one property in two sets
			// is not equal another with the same name
			if (!sValue1.equals(sValue2))
			{
				return false;
			}
		}

		// return true if all checks passed
		return true;
	}

	@SuppressWarnings("null")
	public static boolean equal(CProperties a, CProperties b)
	{
		return (a == null && b == null ||
			a == null && b.isEmpty() ||
			b == null && a.isEmpty() ||
			a.isEmpty() && b.isEmpty() ||
			a != null && a.equals(b));
	}

	/**
	 * Predefined values - instance that contains no properties
	 */
	public static final CProperties NO_PROPERTIES = new CProperties()
	{
		@Override
		public CProperties setProperties(CProperties properties)
		{
			throw new UnsupportedOperationException("This class is immutable, cannot add properties [" + properties.size() + "]");
		}

		@Override
		public CProperties setProperty(String szKey, String szValue)
		{
			throw new UnsupportedOperationException("This class is immutable, cannot add property " + szKey + "=" + szValue);
		}
	};
}
