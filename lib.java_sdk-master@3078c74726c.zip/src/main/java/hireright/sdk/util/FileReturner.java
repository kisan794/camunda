/*
 * @(#)$RCSfile: FileReturner.java,v $ $Revision: 1.9 $ $Date: 2007/11/30 09:24:13 $ $Author: asolntsev $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	A.Keks				2002-06-25	Created.
 *	A.Solntsev			2004-05-25	Bug fixed: "!= null" is used instead of ".ready()"
 * 	A.Solntsev			2005-04-14	New class CFileContent is used.
 *	A.Solntsev			2005-04-19	Added method output(URL url, ...)
 *	A.Solntsev			2005-05-26	Method getContent(URL) moved to CFileContent.
 *	A.Solntsev			2006-07-11	Removed usage of javax.servlet.*
 *									Methods outputHTML() moved to MVC Framework
 */
package hireright.sdk.util;

import java.net.MalformedURLException;
import java.net.URL;
import java.io.*;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.net.NetTracking;

/**
 * A class for outputting files to the client
 * Should be used instead of redirecting to, eg html files
 * Also has a method for reading the content of a URL to String
 *
 * It is in this package to be together with all HTMLTransformers, etc
 *
 * @author Anton Keks
 * @version	java_sdk_v2-5-5
 */
public class FileReturner
{
	/**
	 * @deprecated Use method void output(String szURL, OutputStream out)
	 *
	 * @param szContentType  NOT USED
	 */
	public static void output(String szURL, String szContentType, OutputStream out)
		throws IOException, MalformedURLException
	{
		output(szURL, out);
	}

	public static void output(String szURL, OutputStream out)
		throws IOException, MalformedURLException
	{
		output(new URL(szURL), out);
	}

	public static void output(URL url, OutputStream out) throws IOException
	{
		NetTracking.registerUrl(url);

		// Open the URL connection to read the file
		output(url.openConnection().getInputStream(), out);
	}

	/**
	 * Output the entire content from inputStream to the outputStream line-by-line
	 * and close the outputStream.
	 *
	 * PS. Content is treated as ASCII content (not binary).
	 */
	public static void output(InputStream inputStream, OutputStream outputStream) throws IOException
	{
		PrintWriter pwOut = null;

		try
		{
			// Get the response PrintWriter
			pwOut = new PrintWriter(outputStream);

			BufferedReader brIn = new BufferedReader(new InputStreamReader(inputStream));

			// Read & output file data
			String buf = null;
			while ( (buf=brIn.readLine()) != null )
			{
				// Read line by line and output them
				pwOut.print(buf);
				pwOut.print('\n');	// readline() strips these
			}

			pwOut.flush();
		}
		finally
		{
			// Close the stream
			try
			{
				if (inputStream != null)
					inputStream.close();

				if (pwOut != null)
					pwOut.close();
			}
			catch (IOException e)	// Ignore exceptions here
			{
			}
		}
	}


	/**
	 * Returns the content of a URL as String
	 * NB! File should be text, not binary! It's being read line-by-line.
	 *
	 * @param	szURL		for example, "http://www.microsoft.com/description.txt"
	 *
	 * NB!	Method catches ALL exceptions, writes them to tracelog and returns null.
	 * @deprecated	Please use method CFileContent.getContent() which doesn't
	 * 							catch all exceptions but forwards them.
	 */
	public static String getContent(String szURL)
	{
		try
		{
			return CFileContent.getContent(szURL);
		}
		catch (Exception e)	// IOException, MalformedURLException
		{
			// Fatal error!!!
			CProperties params = new CProperties();
			params.setProperty("url", szURL);
			CTraceLog.fatal(e, FileReturner.class.getName()+".getContent()", params);

			return null;
		}
	}
}
