/*
 * @(#)$RCSfile: CExceptionLogProperties.java,v $ $Revision: 1.2 $ $Date: 2012/09/21 08:46:58 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CExceptionLogProperties.java,v $
 *
 * Copyright 2001-2012 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   K.Ovchinnikov			2012-09-10	Created
 */
package hireright.sdk.util;

/**
*
* @author K.Ovchinnikov
* @version $Revision: 1.2 $, $Date: 2012/09/21 08:46:58 $, $Author: cvsroot $
* @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CExceptionLogProperties.java,v $
*/
public class CExceptionLogProperties
{
	private static String LEVEL_PROP_NAME = "log.level";

	/**
	 * Create properties with given log level
	 */
	public static CProperties createWithLevel(CExceptionLogLevel level)
	{
		return createWithLevel(null, level);
	}
	
	/**
	 * Create properties with given log level by properties owner
	 */
	public static CProperties createWithLevel(IHasProperties propsOwner, CExceptionLogLevel level)
	{
		CProperties props = propsOwner == null ? 
				new CProperties() : new CProperties(propsOwner.toProperties());
		return props.setProperty(LEVEL_PROP_NAME, level.toString());
	}
	
	/**
	 * Get log level of given properties owner
	 */
	public static CExceptionLogLevel getLevel(IHasProperties hasProps,
			CExceptionLogLevel defaultLevel)
	{
		if(hasLevel(hasProps))
		{
			String level = hasProps.toProperties().getProperty(LEVEL_PROP_NAME);
			if(CExceptionLogLevel.canConvertFromString(level))
			{
				return CExceptionLogLevel.valueOf(level);
			}
		}
		return defaultLevel;
	}
	
	/**
	 * Check if properties contain log level
	 */
	public static boolean hasLevel(IHasProperties hasProps)
	{
		if(hasProps != null)
		{
			CProperties props = hasProps.toProperties();
			return props != null && props.hasProperty(LEVEL_PROP_NAME);
		}
		return false;
	}
	
}
