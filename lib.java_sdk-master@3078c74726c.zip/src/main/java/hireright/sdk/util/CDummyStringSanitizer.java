/*
 *
 * Copyright 2001-2019 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Vassiljev		2019-03-19	Created
 */
package hireright.sdk.util;

/**
 * 
 */
public class CDummyStringSanitizer implements IStringSanitizer
{

	@Override
	public String replace(final String src)
	{
		return src;
	}
	
	@Override
	public String replace(String src, String sSourceLanguage)
	{
		return src;
	}

}
