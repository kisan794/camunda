package hireright.sdk.util;

/**
 * Contract for entities that have an individual URL and can be accessed by this URL.
 * @version "$Revision: 1.3 $, $Date: 2007/09/14 09:02:55 $"
 * @author Aleksei Podlipski
 */
public interface IHaveURL 
{
	public String getURL();
}