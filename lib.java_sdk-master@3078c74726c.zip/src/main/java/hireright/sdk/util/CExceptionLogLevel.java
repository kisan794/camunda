/*
 * @(#)$RCSfile: CExceptionLogLevel.java,v $ $Revision: 1.2 $ $Date: 2012/09/21 08:46:49 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CExceptionLogLevel.java,v $
 *
 * Copyright 2001-2012 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   K.Ovchinnikov			2012-09-10	Created
 */
package hireright.sdk.util;

/**
*
* @author K.Ovchinnikov
* @version $Revision: 1.2 $, $Date: 2012/09/21 08:46:49 $, $Author: cvsroot $
* @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CExceptionLogLevel.java,v $
*/
public enum CExceptionLogLevel
{
	
	WARNING, ERROR, FATAL;
	
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	public static boolean canConvertFromString(String name)
	{
		for(CExceptionLogLevel level : values())
		{
			if(level.toString().equals(name))
			{
				return true;
			}
		}
		return false;
	}
}
