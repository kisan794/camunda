/*
 * @(#)$RCSfile: CBeanUtils.java,v $ $Revision: 1.3 $ $Date: 2007/09/14 09:01:25 $ $Author: asolntsev $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2007-01-07	A.Solntsev		Created
 */
package hireright.sdk.util;

import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.Set;

/**
 * System utilities for getting
 * 	1. class code source,
 *  2. ...
 *
 * @author Andrei Solntsev
 * @since 2005-09-14
 * @version $Revision: 1.3 $ $Date: 2007/09/14 09:01:25 $ $Author: asolntsev $
 */
public class CBeanUtils
{
	public CBeanUtils()
	{
	}

	public static CProperties toProperties(Object propertiesOwner)
	{
		if (propertiesOwner == null)
			return null;
		
		if (propertiesOwner.getClass().isPrimitive() ||
				Number.class.isAssignableFrom(propertiesOwner.getClass()) ||
				propertiesOwner.getClass() == Boolean.class ||
				propertiesOwner.getClass() == String.class ||
				propertiesOwner.getClass() == Character.class ||
				propertiesOwner.getClass() == Object.class)
		{
			return new CProperties()
				.setProperty("this", propertiesOwner.toString().substring(0, 50));
		}

		// compare complex objects member-by-member
		Set allFields = CClass.getFields(propertiesOwner.getClass(), false, false);
		if (allFields == null || allFields.isEmpty())
			return null;
		
		CProperties properties = new CProperties();
		Object value;
		Field f;
		for (Iterator it = allFields.iterator(); it.hasNext(); )
		{
			f = (Field) it.next();
			f.setAccessible(true);
			
			try
			{
				value = f.get(propertiesOwner);
				properties.setProperty(f.getName(), String.valueOf(value).substring(0, 50));
			}
			catch (Exception ex) // InvocationTargetException
			{
				// what to do?
			}
		}
		return properties;
	}
}