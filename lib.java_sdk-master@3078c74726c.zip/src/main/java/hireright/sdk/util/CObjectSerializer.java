/*
 * @(#)$RCSfile: CObjectSerializer.java,v $ $Revision: 1.2 $ $Date: 2015/11/02 20:17:02 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/util/CObjectSerializer.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   M.Abdulganejev			2008-12-10	created 
 *   M.Abdulganejev			2009-08-14	Relocated from COM and refactored.  
 *   E.Kapustin				2015-07-15	Relocated from form_engine.
 */

package hireright.sdk.util;


/**
 * stupid auxilary class capable of serializing objects and ensuring that
 * all format of serialized string will be the same all over the code
 *
 * @author M.Abdulganejev
 */
public class CObjectSerializer 
{
	String[] m_params;
	
	private static final String ARG_SEPARATOR = "=";
	private static final String ARG_PAIR_SEPARATOR = ", ";
	
	/**
	 * 
	 * @param clazz
	 * @param args
	 * @return
	 */
	public static String doSerialize(Class<?> clazz, Object...args)
	{
		StringBuffer serializationResults = new StringBuffer(clazz.getName() + " [");
		
		for (int i = 0, j = args.length; i < j; i++)
		{
			if (i > 0)
			{
				serializationResults.append(ARG_PAIR_SEPARATOR);
			}
			serializationResults.append(args[i]).append(ARG_SEPARATOR)
				.append(args[i + 1]);
			i++;
		}
		
		serializationResults.append("]");
		
		return serializationResults.toString();
	}
}


