/*
 * Copyright 2001-2021 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *
 *  D.Shchur        2021-06-08  Created.
 */
package hireright.sdk.mapper;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * Mapper for getting values by conditions.
 *
 * <p>Used to prevent writing multiple "else if" constructions.</p>
 *
 * @param <E> entry object type
 * @param <R> result object type
 */
public class CConditionMapper<E, R>
{
	/**
	 * Map of condition function - value pairs
	 */
	private LinkedHashMap<Function<E, Boolean>, R> mapperMap;
	
	/**
	 * Value to return with mismatch conditions.
	 */
	private R defaultValue;

	protected CConditionMapper(LinkedHashMap<Function<E, Boolean>, R> mapperMap)
	{
		this.mapperMap = mapperMap;
	}
	
	public void addFirst(Function<E, Boolean> entry, R result)
	{
		LinkedHashMap<Function<E, Boolean>, R> newMapperMap = new LinkedHashMap<>();
		newMapperMap.put(entry, result);
		newMapperMap.putAll(mapperMap);
		mapperMap = newMapperMap;
	}
	
	public void addFirst(LinkedHashMap<Function<E, Boolean>, R> map) {
		LinkedHashMap<Function<E, Boolean>, R> newMapperMap = new LinkedHashMap<>(map);
		newMapperMap.putAll(mapperMap);
		mapperMap = newMapperMap;
	}
	
	public void addLast(Function<E, Boolean> entry, R result)
	{
		mapperMap.put(entry, result);
	}
	
	public void addLast(LinkedHashMap<Function<E, Boolean>, R> map)
	{
		mapperMap.putAll(map);
	}
	
	public R getMatchFor(E entry)
	{
		return mapperMap.entrySet().stream()
			.filter(e -> e.getKey().apply(entry))
			.findFirst()
			.map(Map.Entry::getValue)
			.orElse(defaultValue);
	}
	
	public R getDefaultValue()
	{
		return defaultValue;
	}
	
	public void setDefaultValue(R defaultValue)
	{
		this.defaultValue = defaultValue;
	}
}
