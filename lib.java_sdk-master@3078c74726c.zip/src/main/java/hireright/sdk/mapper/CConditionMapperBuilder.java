/*
 * Copyright 2001-2021 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *
 *  D.Shchur        2021-06-08  Created.
 */
package hireright.sdk.mapper;

import java.util.LinkedHashMap;
import java.util.function.Function;

/**
 * Builder for {@link CConditionMapper}.
 *
 * <p>Used to create map of condition - value or just value - value pairs.</p>
 *
 * <p>Usage example:
 * 	<pre>
 * 	    CConditionMapper&lt;String, String&gt; conditionMapper = CConditionMapperBuilder.&lt;String, String&gt;builder()
 * 	    				.put(s -&gt; s.length() == 1, ONE_SYMBOL_STRING)
 * 	    				.put(SPECIAL_VALUE, SPECIAL_VALUE_STRING)
 * 	    				.withDefaultValue(UNPROCESSED_TYPE_STRING)
 * 	    				.build();
 *
 * 	    conditionMapper.getMatchFor(object.getString());
 * 	</pre>
 * <p>
 *
 * <p>Matches are searched from the first added element.</p>
 *
 * @param <E> entry object type
 * @param <R> result object type
 */
public class CConditionMapperBuilder<E, R>
{
	private final LinkedHashMap<Function<E, Boolean>, R> mapperMap = new LinkedHashMap<>();
	
	private R defaultValue = null;
	
	public static <E, R> CConditionMapperBuilder<E, R> builder()
	{
		return new CConditionMapperBuilder<>();
	}
	
	public CConditionMapperBuilder<E, R> put(Function<E, Boolean> entry, R result)
	{
		mapperMap.put(entry, result);
		return this;
	}
	
	public CConditionMapperBuilder<E, R> put(E entry, R result)
	{
		mapperMap.put(entry::equals, result);
		return this;
	}
	
	public CConditionMapperBuilder<E, R> withDefaultValue(R defaultValue)
	{
		this.defaultValue = defaultValue;
		return this;
	}
	
	public CConditionMapper<E,R> build()
	{
		CConditionMapper<E, R> mapMatcher = new CConditionMapper<>(mapperMap);
		mapMatcher.setDefaultValue(defaultValue);
		return mapMatcher;
	}
}
