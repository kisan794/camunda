package hireright.sdk.db3;

/*
 * Copyright 2001-2022 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Dashkovskii 2022-02-16 HRG-190623 opportunity to use other Hibernate version
 *  A.Dashkovskii 2024-02-06 HRG-302070 fix execution logic
 */

import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.Callable;

import hireright.sdk.db.CCurrentThreadConnection;
import org.hibernate.Session;

public interface IConnectionProvider
{
	/**
	 * Returns currently active jdbc connection
	 * @return
	 */
	Connection connection() throws SQLException;
	
	/**
	 * Returns a hibernate session that corresponds to the specified configuration and the current db environment
	 * @return
	 */
	Session session();
	
	/**
	 * Default wrapper executable
	 * @param callable
	 * @param <T>
	 * @return
	 */
    default <T> T execute(Callable<T> callable) {

        // Already in IConnectionProvider request
        if (CCurrentThreadConnection.getConnection() != null) {
            try {
                return callable.call();
            } catch (RuntimeException e) {
                throw e;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        // Create new IConnectionProvider request
        try {
            CCurrentThreadConnection.bind(connection());
            CHibernateWrapper.setConnectionProvider(this);
            return DB.execute(callable);
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            CHibernateWrapper.releaseConnectionProvider();
            CCurrentThreadConnection.unbind();
        }
    }
}
