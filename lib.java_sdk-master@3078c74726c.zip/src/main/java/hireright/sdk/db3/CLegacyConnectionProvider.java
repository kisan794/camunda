/*
 * Copyright 2001-2024 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 2024-04-22		V.Ozernov	HRG-308586 Created
 */
package hireright.sdk.db3;

import org.hibernate.Session;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.Callable;

/**
 * Implementation of IConnectionProvider which uses DB.
 * Use it in HRG1 code when you need to pass an instance of IConnectionProvider to somewhere else.
 */
public class CLegacyConnectionProvider implements IConnectionProvider
{
	private static final CLegacyConnectionProvider INSTANCE = new CLegacyConnectionProvider();
	
	protected CLegacyConnectionProvider()
	{
	}
	
	public static IConnectionProvider getInstance()
	{
		return INSTANCE;
	}
	
	@Override
	public Connection connection() throws SQLException
	{
		return DB.connection();
	}
	
	@Override
	public Session session()
	{
		return DB.session();
	}
	
	@Override
	public <T> T execute(Callable<T> callable)
	{
		try
		{
			return DB.execute(callable);
		}
		catch(RuntimeException e)
		{
			throw e;
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}
	}
}
