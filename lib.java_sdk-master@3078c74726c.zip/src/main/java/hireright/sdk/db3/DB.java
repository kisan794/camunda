/*
 * @(#)$RCSfile: DB.java,v $ $Revision: 1.3.2.6.2.3 $ $Date: 2015/10/27 10:47:45 $ $Author: atanasenko $
 *
 * Copyright 2015-2016 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Tanasenko	2015-01-20	Created
 *	A.Tanasenko	2015-06-02	Corrected flush/commit/rollback/close ordering and error handling/logging
 *	A.Podlipski	2016-04-20	fixing memory leak caused by infinite static activity log 
 *	E.Magi			2017-05-29	HIVPE-10934: add static currentEnvJNDIName function
 *	A.Dashkovskii	2022-02-16 HRG-190623 Hibernate wrapper added - opportunity to use other Hibernate version
 */
package hireright.sdk.db3;

import hireright.sdk.db.CAbstractConnectionProxy;
import hireright.sdk.db.CConnection;
import hireright.sdk.db2.CSessionFactory;
import hireright.sdk.db2.CThreadLocalMultiSessionContext;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CClass;
import hireright.sdk.util.CClosableRegistry;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.IClosable;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

/**
 * Main entry point for database environment access.
 */
public class DB
{
	private static final Logger LOG = Logger.getLogger(DB.class);
	
	private static final int MAX_ACTIVITIES = 10000;

	private static final ThreadLocal<Deque<String>> activities = new ThreadLocal<Deque<String>>()
	{
		@Override
		protected Deque<String> initialValue()
		{
			return new LinkedList<String>();
		}
	};
	
	private static final ThreadLocal<Deque<DB>> support = new ThreadLocal<Deque<DB>>()
	{
		@Override
		protected Deque<DB> initialValue()
		{
			return new LinkedList<DB>();
		}
	};
	
	/*
	 * INSTANCE MEMBERS
	 */
	
	private final DB parent;
	private final Map<String, DBEnvRef> envs;
	private final Deque<DBEnvRef> stack;
	private final StackTraceElement[] trace;
	private String defaultHibernateConfig;

	private boolean rollbackAll;
	
	private String defaultJNDIName = CConnection.JNDI_NAME_CONNECTION;
	
	@SuppressWarnings("deprecation")
	private hireright.sdk.db.CCurrentThreadConnection.IConnectionProvider oldProvider;

	@SuppressWarnings("deprecation")
	private hireright.sdk.db.CCurrentThreadConnection.IConnectionProvider conProvider;

    private DB(DB parent, boolean forceNewEnv) {
        this.parent = parent;
        this.trace = Thread.currentThread().getStackTrace();

        envs = new HashMap<String, DBEnvRef>();
        stack = new LinkedList<DBEnvRef>();

        // Skip CClosableRegistry logic if we are using a connection provider
        // https://jira.hireright.com/browse/HRG-302070
        if (!CHibernateWrapper.isConnectionProviderSet()) {
            if (support.get().isEmpty()) {
                bindProvider(forceNewEnv);

                CClosableRegistry.registerCurrentThread(new IClosable() {
                    @Override
                    public void close() {
                        DB.cleanup();
                    }
                }, true);
            }
            support.get().push(this);
        }

        DB.logActivity("Created DB " + this + (parent != null ? (", parent: " + parent) : ""));
    }
	
	private void setDefaultHibernateConfig(String hibernateConfig) {
		this.defaultHibernateConfig = hibernateConfig;
	}
	
	private void setDefaultJNDIName0(String defaultJNDIName)
	{
		this.defaultJNDIName = defaultJNDIName;
	}
	
	public void close()
	{
		DB.logActivity("Closing DB " + this);
		Deque<DB> dbstack = support.get();
		if(dbstack == null || dbstack.isEmpty()) return;
		
		try
		{
			if(!envs.isEmpty())
			{
				List<DBEnvRef> tmp = new ArrayList<DBEnvRef>(envs.values());
				
				try
				{
					// Phase 1: flush all envs
					for(DBEnvRef ref: tmp)
					{
						if(ref.env.isRollbackOnClose())
						{
							ref.beforeRollback();
						}
						else if(ref.env.isCommitOnClose())
						{
							ref.beforeCommit();
						}
					}
				}
				catch(Throwable t)
				{
					// rollback everything in case of an error during beforeCommit()
					rollbackAll();
					for(DBEnvRef ref: tmp)
					{
						ref.beforeRollback();
					}
					CRuntimeException.rethrow(t);
				}
				finally
				{
					// Phase 2: commit/rollback and close
					for(DBEnvRef ref: tmp)
					{
						try
						{
							// envs were flushed in phase 1
							ref.dispose(false, true);
						}
						catch(Throwable e)
						{
							LOG.error("Error closing db env", e);
						}
					}
				}
			}
		}
		finally
		{
			dbstack.remove(this);
			if(conProvider != null)
			{
				unbindProvider();
			}
		}
	}
	
	public DB rollbackAll() {
		rollbackAll = true;
		return this;
	}
	
	private void requestReadOnly0(String jndiName)
	{
		DBEnvRef ref = initEnv(jndiName);
		// don't force rollback just yet if it's not our env
		if(ref.isOwner()) ref.env.rollbackOnClose();
	}
	
	private void requestTransaction0(String jndiName)
	{
		DBEnvRef ref = initEnv(jndiName);
		if(ref.isOwner()) ref.env.commitOnClose();
	}
	
	private void registerSynchronization0(IDBSync sync)
	{
		currentEnvRef(true).addSync(sync);
	}
	
	private DBEnvRef currentEnvRef(boolean require)
	{
		if(stack.isEmpty()) {
			//throw new IllegalStateException("No DB environment requested");
			// init default one
			if(require) {
				return initEnv(defaultJNDIName);
			}
			return null;
		}
		return stack.peek();
	}
	
	private String currentEnvJNDIName(boolean require)
	{
		DBEnvRef ref = currentEnvRef(require);
		if (ref != null)
		{
			return ref.env.jndiName;
		}
		return null;
	}
	
	private DBEnvRef initEnv(String jndiName)
	{
		if(jndiName == null) jndiName = defaultJNDIName;
		
		DBEnvRef ref = envs.get(jndiName);
		if(ref == null)
		{
			// look up the context stack
			DB p = parent;
			while(p != null && ref == null)
			{
				ref = p.envs.get(jndiName);
				p = p.parent;
			}
			
			if(ref != null)
			{
				// get shared env
				ref = new DBEnvRef(ref.env);
			}
			else
			{
				// create own ref
				ref = new DBEnvRef(new DBEnv(this, jndiName));
			}
			envs.put(jndiName, ref);
		}
		
		ref.acquire();
		
		return ref;
	}
	
	private DBEnvRef getEnvRef(String jndiName)
	{
		if(jndiName == null) jndiName = defaultJNDIName;
		return envs.get(jndiName);
	}
	
	private class DBEnvRef
	{
		final DBEnv env;
		int uses = 0; // amount of uses in the current db context
		Connection decorated;
		
		List<IDBSync> syncs;
		
		DBEnvRef(DBEnv env) {
			this.env = env;
		}
		
		boolean isOwner()
		{
			return env.owner == DB.this;
		}
		
		void acquire()
		{
			uses++;
			stack.push(this);
			//logActivity("<" + DB.this + "> Acquiring env (" + uses + ") " + env.jndiName);
		}
		
		void release()
		{
			//logActivity("<" + DB.this + "> Releasing env (" + uses + ") " + env.jndiName);
			uses--;
			if(uses == 0)
			{
				// flush, commit/rollback and close
				dispose(true, true);
			}
			stack.removeFirstOccurrence(this);
		}
		
		void addSync(IDBSync sync)
		{
			if(syncs == null) syncs = new ArrayList<IDBSync>();
			syncs.add(sync);
		}
		
		private void beforeCommit()
		{
			if(syncs != null)
			{
				for(IDBSync sync: syncs)
				{
					try
					{
						sync.beforeCommit();
					}
					catch(DBSyncException e)
					{
						CRuntimeException.rethrow(e.getCause());
					}
					catch (Throwable e)
					{
						LOG.error("Error executing sync.beforeCommit() " + sync, e);
					}
				}
			}
		}
		
		private void beforeRollback()
		{
			// perform beforeRollback hooks
			if(syncs != null)
			{
				for(IDBSync sync: syncs)
				{
					try
					{
						sync.beforeRollback();
					}
					catch (Throwable e)
					{
						LOG.error("Error executing sync.beforeRollback() " + sync, e);
					}
				}
			}
		}
		
		private void afterClose()
		{
			if(syncs != null)
			{
				// perform afterClose hooks
				for(IDBSync sync: syncs)
				{
					try
					{
						sync.afterClose();
					}
					catch (Throwable e)
					{
						LOG.error("Error executing sync.afterClose() " + sync, e);
					}
				}
				syncs = null;
			}
		}
		
		void rollback() {
			beforeRollback();
			env.doRollback();
		}
		
		void commit() {
			beforeCommit();
			env.doCommit();
		}
		
		void dispose(boolean flush, boolean commitOrRollback)
		{
			try
			{
				if(flush)
				{
					if(env.isRollbackOnClose())
					{
						beforeRollback();
					}
					else if(env.isCommitOnClose())
					{
						beforeCommit();
					}
				}
				
				if(isOwner())
				{
					//logActivity("<" + DB.this + "> Closing owned env " + env.jndiName);
					try
					{
						if(env.isRollbackOnClose())
						{
							env.doRollback();
						}
						else if(env.isCommitOnClose())
						{
							env.doCommit();
						}
					}
					finally
					{
						env.close();
					}
				} else {
					//logActivity("<" + DB.this + "> Closing borrowed env " + env.jndiName);
				}
			}
			finally
			{
				envs.remove(env.jndiName);
				decorated = null;
				afterClose();
			}
		}
		
		public Connection getConnection()
		{
			if(decorated == null)
			{
				decorated = decorate(this, env.getConnection());
			}
			return decorated;
		}
	}
	
	private static class DBEnv
	{
		
		final DB owner;
		final String jndiName;
		
		Connection connection;
		
		boolean commitOnClose;
		boolean rollbackOnClose;
		boolean closed;
		
		DBEnv(DB owner, String jndiName)
		{
			this.owner = owner;
			this.jndiName = jndiName;
		}
		
		boolean isRollbackOnClose()
		{
			return rollbackOnClose || owner.rollbackAll;
		}
		
		boolean isCommitOnClose()
		{
			return !rollbackOnClose && !owner.rollbackAll && commitOnClose;
		}
		
		DBEnv commitOnClose() {
			commitOnClose = true;
			return this;
		}

		DBEnv rollbackOnClose()
		{
			rollbackOnClose = true;
			return this;
		}
		
		void doCommit()
		{
			if(connection == null) return;
			
			try
			{
				connection.commit();
			}
			catch (SQLException e)
			{
				LOG.error("Error commiting transaction", e);
			}
		}
		
		void doRollback()
		{
			if(connection == null) return;
			CConnection.rollback(connection);
		}
		
		DBEnv close()
		{
			if(connection == null) return this;
			
			logActivity("<" + owner + "> Closing connection " + connection);
			CConnection.closeConnection(connection);
			
			connection = null;
			closed = true;
			return this;
		}
		
		/*
		 * Lazily load a connection
		 */
		Connection getConnection()
		{
			if(closed) throw new IllegalStateException("DBEnv closed");
			if(connection == null)
			{
				connection = CConnection.getConnection(jndiName, true);
				
				if(connection == null)
				{
					Exception cause = null;
					if(CConnection.getException() != null)
					{
						cause = CConnection.getException();
					}
					throw new IllegalStateException("Cannot obtain connection " + jndiName, cause);
				}
				
				logActivity("<" + owner + "> Creating connection " + connection);
			}
			return connection;
		}
	}
	
	
	private static Connection decorate(DBEnvRef ref, Connection conn)
	{
		return (Connection) Proxy.newProxyInstance(
				DB.class.getClassLoader(),
				new Class[]{ Connection.class },
				new DBEnvDecorator(ref, conn));
	}
	
	private static DBEnvDecorator getDecorator(Connection conn)
	{
		if(conn == null) return null;
		
		return DBEnvDecorator.unwrap(conn);
	}
	
	@SuppressWarnings("deprecation")
	private void bindProvider(boolean forceNewEnv)
	{
		oldProvider = hireright.sdk.db.CCurrentThreadConnection.getProvider();
		conProvider = new DBConnectionProvider();
		
		hireright.sdk.db.CCurrentThreadConnection.bindProvider(conProvider);
		
		if(!forceNewEnv && oldProvider != null)
		{
			Connection existingConnection = oldProvider.getConnection();
			if(existingConnection != null)
			{
				conProvider.adapt(existingConnection);
			}
		}
	}
	
	@SuppressWarnings("deprecation")
	private void unbindProvider()
	{
		hireright.sdk.db.CCurrentThreadConnection.bindProvider(oldProvider);
	}
	
	@SuppressWarnings("deprecation")
	private class DBConnectionProvider implements hireright.sdk.db.CCurrentThreadConnection.IConnectionProvider
	{
		private Connection external;
		
		@Override
		public Connection getConnection()
		{
			if(external != null) return external;
			
			if(!isInitialized()) return null;
			return instance().currentEnvRef(true).getConnection();
		}
		
		@Override
		public boolean adapt(Connection conn)
		{
			if(conn == null)
			{
				logActivity("Unsetting external connection " + external);
				external = null;
			}
			else
			{
				DBEnvDecorator d = getDecorator(conn);
				if(d != null)
				{
					logActivity("Setting managed connection as external " + conn);
					DBEnvRef curRef = instance().stack.peek();
					if(curRef != d.ref)
					{
						instance().requestTransaction0(d.ref.env.jndiName);
					}
					external = null;
				}
				else
				{
					logActivity("Setting external connection " + conn);
					external = conn;
				}
			}
			return true;
		}
		
		public String toString() {
			return "Connection provider for " + DB.this;
		}
	};
	
	private static class DBEnvDecorator extends CAbstractConnectionProxy
	{
		final DBEnvRef ref;
		
		public DBEnvDecorator(DBEnvRef ref, Connection conn)
		{
			super(conn);
			this.ref = ref;
		}
		
		@Override
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
		{
			
			String name = method.getName();
			if(name.equals("commit"))
			{
				if(ref.env.isRollbackOnClose()) 
				{
					LOG.error("FIXME: Trying to commit a readonly transaction: " + getStackSource(Thread.currentThread().getStackTrace(), true));
				}
				ref.commit();
				return null;
			}
			
			if(name.equals("rollback"))
			{
				ref.rollback();
				return null;
			}
			
			if(name.equals("close"))
			{
				ref.dispose(false, false);
				return null;
			}
			
			if(name.equals("setAutoCommit"))
			{
				//throw new UnsupportedOperationException(name);
				return null;
			}
			
			try
			{
				return method.invoke( getDelegate(), args );
			}
			catch(InvocationTargetException e)
			{
				CTraceLog.addCurrentThreadParameters(new CProperties()
					.setProperty("dbActivities", getActivities())
				);
				throw e.getCause();
			}
		}
		
		public static DBEnvDecorator unwrap(Connection conn)
		{
			return unwrap(DBEnvDecorator.class, conn);
		}
	}
	
	/*
	 * STATIC MEMBERS
	 */
	
	/**
	 * Shortcut class for calling {@link DB#execute(Callable)} which requests specified jndi commit or readonly transaction automatically.
	 * 
	 * @param <T>
	 */
	public static abstract class Call<T>
	{
		private final String jndiName;
		
		/**
		 * Create a new call to be executed in a default db environment.
		 * Other db environments are also available on demand using {@link DB} <code>request*</code> methods,
		 * but automatic commit/rollback is only performed on default db environment.
		 */
		protected Call()
		{
			this(CConnection.JNDI_NAME_CONNECTION);
		}
		
		/**
		 * Create a new call to be executed in a db environment as identified by specified jndiName.
		 * Other db environments are also available on demand using {@link DB} <code>request*</code> methods,
		 * but automatic commit/rollback is only performed on specified db environment.
		 */
		protected Call(String jndiName)
		{
			this.jndiName = jndiName;
		}
		
		protected abstract T call() throws Exception;
		
		/**
		 * Executes this call and commits transaction if successful, rollbacks otherwise
		 * @return
		 */
		public final T execute() throws Exception
		{
			return execute(false, false);
		}
		
		/**
		 * Executes this call in an isolated db environment and commits transaction if successful, rollbacks otherwise
		 * @return
		 */
		public final T executeIsolated() throws Exception
		{
			return execute(false, true);
		}
		
		/**
		 * Executes this call and rollbacks transaction when done
		 * @return
		 */
		public final T executeReadOnly() throws Exception
		{
			return execute(true, false);
		}
		
		/**
		 * Executes this call in an isolated db environment and rollbacks transaction when done
		 * @return
		 */
		public final T executeReadOnlyIsolated() throws Exception
		{
			return execute(true, true);
		}
		
		/**
		 * Executes this call and commits transaction if successful, rollbacks otherwise
		 * @return
		 */
		public final T executeSafe()
		{
			return executeSafe(false, false);
		}
		
		/**
		 * Executes this call in an isolated db environment and commits transaction if successful, rollbacks otherwise
		 * @return
		 */
		public final T executeIsolatedSafe()
		{
			return executeSafe(false, true);
		}
		
		/**
		 * Executes this call and rollbacks transaction when done
		 * @return
		 */
		public final T executeReadOnlySafe()
		{
			return executeSafe(true, false);
		}
		
		/**
		 * Executes this call in an isolated db environment and rollbacks transaction when done
		 * @return
		 */
		public final T executeReadOnlyIsolatedSafe()
		{
			return executeSafe(true, true);
		}
		
		private final T executeSafe(boolean readonly, boolean forceNewContext)
		{
			try
			{
				return execute(readonly, forceNewContext);
			}
			catch(Exception e)
			{
				throw CRuntimeException.wrap(e);
			}
		}
		
		private final T execute(final boolean readonly, final boolean forceNewContext) throws Exception
		{
			return DB.execute(new Callable<T>()
			{
				@Override
				public T call() throws Exception
				{
					if(readonly)
					{
						requestReadOnly(jndiName);
					}
					else
					{
						requestTransaction(jndiName);
					}
					return Call.this.call();
				}
			}, forceNewContext);
		}
	}

	/**
	 * Invokes specified callable providing database support.
	 * @param callable
	 * @return
	 */
	public static <T> T execute(Callable<T> callable) throws Exception
	{
		return execute(callable, false);
	}
	
	/**
	 * Invokes specified callable providing database support.
	 * If <code>forceNewEnv</code> is set to true, then a new independent nested db context will be created even if one already exists.
	 * @param callable
	 * @param forceNewEnv
	 * @return
	 */
	public static <T> T execute(Callable<T> callable, boolean forceNewEnv) throws Exception
	{
		DB dbs = new DB(forceNewEnv ? null : support.get().peek(), forceNewEnv);
		try
		{
			T result = callable.call();
			return result;
		}
		catch (Throwable e)
		{
			dbs.rollbackAll();
			return CRuntimeException.rethrow(e);
		}
		finally
		{
			dbs.close();
		}
	}
	
	/**
	 * Wraps provided callable so that its invocation will be passed through {@link #execute(Callable, boolean)}
	 * 
	 * @param callable
	 * @param forceNewEnv
	 * @return
	 */
	public static <T> Callable<T> wrap(final Callable<T> callable, final boolean forceNewEnv)
	{
		return new Callable<T>() {
			@Override
			public T call() throws Exception {
				return execute(callable, forceNewEnv);
			}
		};
	}
	
	/**
	 * Creates and binds a new database context to current thread of execution; users of this method must ensure that {@link #close()} method
	 * is called once all the work has been done.
	 * 
	 * @return
	 */
	public static DB init()
	{
		return init(false);
	}
	
	/**
	 * Creates and binds a new database context to current thread of execution; users of this method must ensure that {@link #close()} method
	 * is called once all the work has been done.
	 * If <code>forceNewEnv</code> is set to true, then a new independent nested db context will be created even if one already exists.
	 * 
	 * @param forceNewEnv
	 * @return
	 */
	public static DB init(boolean forceNewEnv)
	{
		DB dbs = new DB(forceNewEnv ? null : support.get().peek(), forceNewEnv);
		return dbs;
	}
	
	/**
	 * Tests whether current thread of execution has a database context associated with it.
	 * 
	 * @return
	 */
	public static boolean isInitialized()
	{
		Deque<DB> dbs = support.get();
		return dbs != null && !dbs.isEmpty();
	}
	
	private static DB instance()
	{
		DB dbs = support.get().peek();
		if(dbs == null) throw new IllegalStateException("DB must be used within DB.execute()");
		return dbs;
	}
	
	/**
	 * Sets a default jndi name of db environment for methods which do not specify one explicitly.
	 * @param jndiName
	 */
	public static void setDefaultJNDIName(String jndiName) {
		instance().setDefaultJNDIName0(jndiName);
	}
	
	/**
	 * Requests a new default connection with readonly transaction to be available through {@link DB#connection()} 
	 */
	public static void requestReadOnly()
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		requestReadOnly(null);
	}
	
	/**
	 * Requests a new default connection with active transaction to be available through {@link DB#connection()} 
	 */
	public static void requestTransaction()
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		requestTransaction(null);
	}
	
	/**
	 * Requests a new connection with readonly transaction to be available through {@link DB#connection()} 
	 */
	public static void requestReadOnly(String jndiName)
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		instance().requestReadOnly0(jndiName);
	}
	
	/**
	 * Requests a new connection with active transaction to be available through {@link DB#connection()} 
	 */
	public static void requestTransaction(String jndiName)
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		instance().requestTransaction0(jndiName);
	}
	
	public static void registerSynchronization(IDBSync sync)
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		instance().registerSynchronization0(sync);
	}
	
	/**
	 * Performs a commit on the currently active transaction
	 */
	public static void commit()
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		DBEnvRef ref = instance().currentEnvRef(false);
		if(ref != null) ref.commit();
	}
	
	/**
	 * Performs a commit on an active transaction as identified by specified jndi name; 
	 * does nothing if no transaction with such name have been requested in the current db context.
	 * @param jndiName
	 */
	public static void commit(String jndiName)
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		DBEnvRef ref = instance().getEnvRef(jndiName);
		if(ref != null) ref.commit();
	}
	
	/**
	 * Performs a rollback on the currently active transaction
	 */
	public static void rollback()
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		DBEnvRef ref = instance().currentEnvRef(false);
		if(ref != null) ref.rollback();
	}
	
	/**
	 * Performs a rollback on an active transaction as identified by specified jndi name; 
	 * does nothing if no transaction with such name have been requested in the current db context.
	 * @param jndiName
	 */
	public static void rollback(String jndiName)
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		DBEnvRef ref = instance().getEnvRef(jndiName);
		if(ref != null) ref.rollback();
	}
	
	/**
	 * Marks all active and any future transactions to be rolled back on close of current db context.
	 */
	public static void rollbackAllOnClose()
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		instance().rollbackAll();
	}
	
	/**
	 * Marks currently active transaction to be rolled back on close of current db context.
	 */
	public static void rollbackCurrentOnClose()
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		instance().currentEnvRef(true).env.rollbackOnClose();
	}
	
	/**
	 * Marks an active transaction as identified by specified jndi name to be rolled back on close of current db context.
	 */
	public static void rollbackOnClose(String jndiName)
	{
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		DBEnvRef ref = instance().getEnvRef(jndiName);
		if(ref != null) ref.env.rollbackOnClose();
	}
	
	/**
	 * Configures current db context to use specified hibernate config by default
	 * @param hibernateConfig
	 */
	public static void initSession(String hibernateConfig) {
        if (CHibernateWrapper.isConnectionProviderSet()) {
            return;
        }
		instance().setDefaultHibernateConfig(hibernateConfig);
	}
	
	private static CHibernateWrapper hibernateWrapper = new CHibernateWrapper(
			hibernateConfig -> sessionBackward(hibernateConfig),
			() -> sessionBackward(),
			() -> connectionBackward()
	);

	/**
	 * Returns currently active jdbc connection
	 * @return
	 */
	public static Connection connection()
	{
		return hibernateWrapper.connection();
	}
	
	private static Connection connectionBackward()
	{
		return instance().currentEnvRef(true).getConnection();
	}
	
	/**
	 * Returns a hibernate session that corresponds to the current db environment
	 * @return
	 */
    private static Session sessionBackward()
	{
		String hibernateConfig = instance().defaultHibernateConfig;
		if(hibernateConfig == null) hibernateConfig = CSessionFactory.HIBERNATE_DEFAULT;
		return session(hibernateConfig);
	}

    public static Session session()
    {
        return hibernateWrapper.session();
    }
	
	/**
	 * Returns a hibernate session that corresponds to the specified configuration and the current db environment
	 * @return
	 */
	public static Session session(String hibernateConfig)
	{
		return hibernateWrapper.session(hibernateConfig);
	}
	
	private static Session sessionBackward(String hibernateConfig)
	{
		Session session = CSessionFactory.getSessionFactory(hibernateConfig).getCurrentSession();
		session.beginTransaction();
		return session;
	}
	
	/**
	 * Releases currently active db environment as previously acquired by {@link #requestTransaction()} or {@link #requestReadOnly()}
	 */
	public static void release()
	{
		DBEnvRef ref = instance().currentEnvRef(false);
		if(ref != null) ref.release();
	}
	
	public static void cleanup()
	{
		
		Deque<DB> dbstack = support.get();
		if(dbstack != null && !dbstack.isEmpty())
		{
			while(!dbstack.isEmpty())
			{
				DB db = dbstack.pop();
				Exception cause = new RuntimeException("Env history: " + getActivities() + "\nCreation stackTrace:");
				cause.setStackTrace(db.trace);
				Exception e = new RuntimeException("Unclosed db env: " + getStackSource(db.trace, true), cause);
				LOG.error(e.getMessage(), e);
				try
				{
					db.rollbackAll();
					db.close();
				}
				catch(Throwable ex)
				{
					LOG.error("Error cleaning up db env", e);
				}
			}
		}
		
		CThreadLocalMultiSessionContext.cleanup();
		activities.set(null);
	}
	
	public static String currentEnvJNDIName()
	{
		return instance().currentEnvJNDIName(false);
	}
	
	
	public static void logActivity(String activity)
	{
		if(!isInitialized()) return;
		
		Deque<String> activities = DB.activities.get();
		
		if (activities == null)
		{
			activities = new LinkedList<String>();
			DB.activities.set(activities);
		}
		while (activities.size() >= MAX_ACTIVITIES)
		{
			activities.remove();
		}
		
		Calendar c = Calendar.getInstance();
		String hour = String.format("%02d", c.get(Calendar.HOUR_OF_DAY));
		String min = String.format("%02d", c.get(Calendar.MINUTE));
		String sec = String.format("%02d", c.get(Calendar.SECOND));
		String ms = String.format("%03d", c.get(Calendar.MILLISECOND));
		
		String source = getStackSource(Thread.currentThread().getStackTrace(), false);

		StringBuilder newActivity = new StringBuilder();
		newActivity.append("\n[").append(hour).append(":").append(min).append(":").append(sec).append(".").append(ms).append("] ");
		if (source != null) 
		{
			newActivity.append(source).append(" ");
		}
		newActivity.append(activity);
		activities.add(newActivity.toString());
	}

	public static String getActivities()
	{
		Deque<String> activities = DB.activities.get();
		StringBuilder allActivities = new StringBuilder();
		if (activities != null && !activities.isEmpty())
		{
			for (String a : activities)
			{
				allActivities.append(a);
			}
		}
		return allActivities.toString();
	}
	
	private static String getStackSource(StackTraceElement[] sts, boolean fullName)
	{
		String source = null;
		for(StackTraceElement st: sts)
		{
			String cn = st.getClassName();
			if(cn.startsWith("$Proxy")) continue;
			if(cn.startsWith("java.") || cn.startsWith("sun.") || cn.startsWith("com.sun.")) continue;
			if(cn.startsWith("hireright.sdk.db")) continue;
			
			if(fullName)
			{
				source = st.toString() + " " + CClass.getClassVersion(cn);
			}
			else
			{
				int lastdot = cn.lastIndexOf('.');
				if(lastdot >= 0)
				{
					cn = cn.substring(lastdot+1, cn.length());
				}
				source = cn + "." + st.getMethodName() + ":" + st.getLineNumber();
			}
			break;
		}
		return source;
	}
	
}
