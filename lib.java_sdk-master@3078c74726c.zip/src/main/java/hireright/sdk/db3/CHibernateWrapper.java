package hireright.sdk.db3;

/*
 * Copyright 2001-2022 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Dashkovskii 2022-02-16 HRG-190623 opportunity to use other Hibernate version
 *  A.Dashkovskii 2024-02-06 HRG-302070 add execution provider set checker
 */

import java.sql.Connection;
import java.sql.SQLException;
import java.util.function.Function;
import java.util.function.Supplier;
import org.hibernate.Session;

public class CHibernateWrapper
{
	private static ThreadLocal<IConnectionProvider> connectionProviderLocal = new ThreadLocal<>();
	private Supplier<Connection> connectionGetter;
	private Function<String, Session> sessionGetter;
    private Supplier<Session> sessionGetterWithoutConfig;
	
	public CHibernateWrapper(
			Function<String, Session> sessionGetter,
			Supplier<Session> sessionGetterWithoutConfig,
			Supplier<Connection> connectionGetter
	)
	{
		this.sessionGetter = sessionGetter;
        this.sessionGetterWithoutConfig = sessionGetterWithoutConfig;
		this.connectionGetter = connectionGetter;
	}

    /**
     * It requires to check if connection provider is set
     * if it is set, then CClosableRegistry will not be used
     * @return
     */
    public static boolean isConnectionProviderSet() {
        return connectionProviderLocal.get() != null;
    }
	
	public Connection connection()
	{
		if(connectionProviderLocal.get() != null)
		{
			try
			{
				return connectionProviderLocal.get().connection();
			} catch(SQLException e)
			{
				throw new RuntimeException(e);
			}
		}
		return connectionGetter.get();
	}

    public Session session() {
        if (connectionProviderLocal.get() != null) {
            return connectionProviderLocal.get().session();
        }
        return sessionGetterWithoutConfig.get();
    }
	
	public Session session(String hibernateConfig)
	{
		if(connectionProviderLocal.get() != null)
		{
			return connectionProviderLocal.get().session();
		}
		return sessionGetter.apply(hibernateConfig);
	}
	
	public static void setConnectionProvider(IConnectionProvider connectionProvider)
	{
		connectionProviderLocal.set(connectionProvider);
	}
	
	public static void releaseConnectionProvider()
	{
		connectionProviderLocal.remove();
	}
}
