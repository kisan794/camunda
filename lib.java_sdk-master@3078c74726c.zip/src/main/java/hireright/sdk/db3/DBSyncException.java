/*
 * @(#)$RCSfile: DBSyncException.java,v $ $Revision: 1.2 $ $Date: 2015/11/02 20:14:44 $ $Author: cvsroot $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	atanasenko	2. juuli 2015	Created
 */
package hireright.sdk.db3;

/**
 * Cause of DBSyncException will be rethrown further up the caller stack as a RuntimeException on DB.close() and DB.commit() instead of being logged in-place 
 */
public class DBSyncException extends RuntimeException
{
	
	private static final long serialVersionUID = 1L;
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	public DBSyncException(Throwable cause)
	{
		super(cause);
	}
}
