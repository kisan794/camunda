/*
 * @(#)$RCSfile: IDBSync.java,v $ $Revision: 1.3 $ $Date: 2015/11/02 20:15:23 $ $Author: cvsroot $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	atanasenko	12.01.2015	Created
 */
package hireright.sdk.db3;

public interface IDBSync
{
	void beforeCommit() throws DBSyncException;
	
	void beforeRollback();
	
	void afterClose();
}
