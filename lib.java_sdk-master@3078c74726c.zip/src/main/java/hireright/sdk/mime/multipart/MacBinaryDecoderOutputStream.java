/*
 * @(#)$RCSfile: MacBinaryDecoderOutputStream.java,v $ $Revision: 1.5 $ $Date: 2008/07/28 09:48:30 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/mime/multipart/MacBinaryDecoderOutputStream.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	A.Podlipski				2003-01-09	created
 *	A.Solntsev				2007-xx-yy	Class is made package-private	
 */
package hireright.sdk.mime.multipart;

import java.io.*;

/**
* A <code>MacBinaryDecoderOutput</code> filters MacBinary files to normal 
* files on the fly; optimized for speed more than readability.
* 
* @author Aleksei Podlipski
* @version $Revision: 1.5 $ $Date: 2008/07/28 09:48:30 $ $Author: cvsroot $
* @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/mime/multipart/MacBinaryDecoderOutputStream.java,v $
*/
class MacBinaryDecoderOutputStream extends FilterOutputStream 
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	private int bytesFiltered = 0;
	private int dataForkLength = 0;

	public MacBinaryDecoderOutputStream(OutputStream out) 
	{
		super(out);
	}

	public void write(int b) throws IOException 
	{
		// Bytes 83 through 86 are a long representing the data fork length
		// Check <= 86 first to short circuit early in the common case
		if (bytesFiltered <= 86 && bytesFiltered >= 83) 
		{
			int leftShift = (86 - bytesFiltered) * 8;
			dataForkLength = dataForkLength | (b & 0xff) << leftShift;
		}
		// Bytes 128 up to (128 + dataForkLength - 1) are the data fork
		else if (bytesFiltered < (128 + dataForkLength) && bytesFiltered >= 128) 
		{
			out.write(b);
		}
		bytesFiltered++;
	}

	public void write(byte b[]) throws IOException 
	{
		write(b, 0, b.length);
	}

	public void write(byte b[], int off, int len) throws IOException 
	{
		// If the write is for content past the end of the data fork, ignore
		if (bytesFiltered >= (128 + dataForkLength)) 
		{
			bytesFiltered += len;
		}
		// If the write is entirely within the data fork, write it directly
		else if (bytesFiltered >= 128 && (bytesFiltered + len) <= (128 + dataForkLength)) 
		{
			out.write(b, off, len);
			bytesFiltered += len;
		}
		// Otherwise, do the write a byte at a time to get the logic above
		else 
		for (int i = 0 ; i < len ; i++) 
		{
			write(b[off + i]);
		}
	}
}
