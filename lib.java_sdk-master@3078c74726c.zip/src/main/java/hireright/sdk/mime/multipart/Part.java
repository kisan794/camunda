/*
 * @(#)$RCSfile: Part.java,v $ $Revision: 1.5 $ $Date: 2008/07/28 09:47:18 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/mime/multipart/Part.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	A.Podlipski				2003-01-09	created
 */
package hireright.sdk.mime.multipart;

/**
 * A <code>Part</code> is an abstract upload part which represents an <code>INPUT</code> 
 * form element in a <code>multipart/form-data</code> form submission.
 * 
 * @see FilePart
 * @see ParamPart
 * 
 * @author Aleksei Podlipski
 * @version $Revision: 1.5 $ $Date: 2008/07/28 09:47:18 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/mime/multipart/Part.java,v $
 */
public abstract class Part 
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	private String name;
  
	//Constructs an upload part with the given name.
	public Part(String name) 
	{
		this.name = name;
	}
  
	//Returns the name of the form element that this Part corresponds to.
	public String getName() 
	{
		return name;
	}
  
	//Returns true if this Part is a FilePart.
	public boolean isFile() 
	{
		return false;
	}
  
	//Returns true if this Part is a ParamPart.
	public boolean isParam() 
	{
		return false;
	}	
}