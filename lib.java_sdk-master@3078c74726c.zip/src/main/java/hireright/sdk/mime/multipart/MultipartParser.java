/*
 * @(#)$RCSfile: MultipartParser.java,v $ $Revision: 1.6 $ $Date: 2008/07/28 09:46:31 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/mime/multipart/MultipartParser.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 * 
 * History:
 *	A.Podlipski			2003-XX-XX	Created
 *	M.Abdulganejev	2006-02-15	java_sdk_v2-6-6: class is now java 1.5 compliant,- 'enum' vars renamed
 */
package hireright.sdk.mime.multipart;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

import javax.servlet.ServletInputStream;

/**
 * @author Aleksei Podlipski
 * @version $Revision: 1.6 $ $Date: 2008/07/28 09:46:31 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/mime/multipart/MultipartParser.java,v $
 */
public class MultipartParser 
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	/** input stream to read parts from */
	private ServletInputStream in;
  
	/** MIME boundary that delimits parts */
	private String boundary;
  
	/** reference to the last file part we returned */
	private FilePart lastFilePart;

	/** buffer for readLine method */
	private byte[] buf = new byte[8 * 1024];
  

	public MultipartParser(ServletInputStream is, String contentType, int nContentLength, int maxSize) throws IOException 
	{
		this(is, contentType, nContentLength, maxSize, true, true);
	}
  
	/**
	* Creates a <code>MultipartParser</code> from the specified request,
	* which limits the upload size to the specified length, and optionally buffers for 
	* performance and prevents attempts to read past the amount specified by the Content-Length. 
	* 
	* @param req   the servlet request.
	* @param maxSize the maximum size of the POST content.
	* @param limitLength boolean flag to indicate if we need to filter the request's input 
	* 		stream to prevent trying to read past the end of the stream.
	*/
	public MultipartParser(ServletInputStream is, String nContentType, int nContentLength, int maxSize, boolean buffer, boolean limitLength) throws IOException 
	{
		// Check the content type to make sure it's "multipart/form-data"
		// Access header two ways to work around WebSphere oddities
		String type  = null;
		String type1 = null; //req.getHeader("Content-Type");
		String type2 = nContentType; //req.getContentType();

		// If one value is null, choose the other value
		if (type1 == null && type2 != null) 
		{
			type = type2;
		}
		else if (type2 == null && type1 != null) 
		{
			type = type1;
		}
		// If neither value is null, choose the longer value
		else if (type1 != null && type2 != null) 
		{
			type = (type1.length() > type2.length() ? type1 : type2);
		}

		if (type == null || !type.toLowerCase().startsWith("multipart/form-data")) 
		{
			throw new IOException("Posted content type isn't multipart/form-data");
		}

		// Check the content length to prevent denial of service attacks
		int length = nContentLength; //req.getContentLength();
		if (length > maxSize) 
		{
			throw new IOException("Posted content length of " + length + " exceeds limit of " + maxSize);
		}

		// Get the boundary string; it's included in the content type.
		// Should look something like "------------------------12012133613061"
		String boundary = extractBoundary(type);
		if (boundary == null) 
		{
			throw new IOException("Separation boundary was not specified");
		}

		ServletInputStream in = is; //req.getInputStream();
    
		// if required, wrap the real input stream with classes that "enhance" its behaviour 
		// for performance and stability
		if (buffer) 
		{
			in = new BufferedServletInputStream(in);
		}
		if (limitLength) 
		{
			in = new LimitedServletInputStream(in, length);
		}

		// Save our values for later
		this.in = in;
		this.boundary = boundary;
    
		// Read the first line, should be the first boundary
		String line = readLine();
		if (line == null) 
		{
			throw new IOException("Corrupt form data: premature ending");
		}

		// Verify that the line is the boundary
		if (!line.startsWith(boundary)) 
		{
			throw new IOException("Corrupt form data: no leading boundary: " + line + " != " + boundary);
		}
	}


	/**
	* Read the next part arriving in the stream. Will be either a 
	* <code>FilePart</code> or a <code>ParamPart</code>, or <code>null</code>
	* to indicate there are no more parts to read. The order of arrival 
	* corresponds to the order of the form elements in the submitted form.
	* 
	* @return either a <code>FilePart</code>, a <code>ParamPart</code> or
	*        <code>null</code> if there are no more parts to read.
	* @exception IOException	if an input or output exception has occurred.
	* 
	* @see FilePart
	* @see ParamPart
	*/
	public Part readNextPart() throws IOException 
	{
		// Make sure the last file was entirely read from the input
		if (lastFilePart != null) 
		{
			lastFilePart.getInputStream().close();
			lastFilePart = null;
		}
    
		// Read the headers; they look like this (not all may be present):
		// Content-Disposition: form-data; name="field1"; filename="file1.txt"
		// Content-Type: type/subtype
		// Content-Transfer-Encoding: binary
		Vector headers = new Vector();

		String line = readLine();
		if (line == null) 
		{
			// No parts left, we're done
			return null;
		}
		else if (line.length() == 0) 
		{
			// IE4 on Mac sends an empty line at the end; treat that as the end.
			// Thanks to Daniel Lemire and Henri Tourigny for this fix.
			return null;
		}
		headers.addElement(line);

		// Read the following header lines we hit an empty line
		while ((line = readLine()) != null && (line.length() > 0)) 
		{
			headers.addElement(line);
		}

		// If we got a null above, it's the end
		if (line == null) 
		{
			return null;
		}

		String name = null;
		String filename = null;
		String origname = null;
		String contentType = "text/plain";  // rfc1867 says this is the default

		Enumeration eHeadersKeys = headers.elements();
		while (eHeadersKeys.hasMoreElements()) 
		{
			String headerline = (String) eHeadersKeys.nextElement();
			if (headerline.toLowerCase().startsWith("content-disposition:")) 
			{
				// Parse the content-disposition line
				String[] dispInfo = extractDispositionInfo(headerline);
				// String disposition = dispInfo[0];  // not currently used
				name = dispInfo[1];
				filename = dispInfo[2];
				origname = dispInfo[3];
			}
			else if (headerline.toLowerCase().startsWith("content-type:")) 
			{
				// Get the content type, or null if none specified
				String type = extractContentType(headerline);
				if (type != null) 
				{
					contentType = type;
				}
			}
		}

		// Now, finally, we read the content (end after reading the boundary)
		if (filename == null) 
		{
			// This is a parameter, add it to the vector of values
			return new ParamPart(name, in, boundary);
		}
		else 
		{
			// This is a file
			if (filename.equals("")) 
			{
				filename = null; // empty filename, probably an "empty" file param
			}
			lastFilePart = new FilePart(name, in, boundary, contentType, filename, origname);
			return lastFilePart;
		}
	}
  
	/**
	* Extracts and returns the boundary token from a line.
	* 
	* @return the boundary token.
	*/
	private String extractBoundary(String line) 
	{
		// Use lastIndexOf() because IE 4.01 on Win98 has been known to send the
		// "boundary=" string multiple times.  Thanks to David Wall for this fix.
		int index = line.lastIndexOf("boundary=");
		if (index == -1) 
		{
			return null;
		}
		String boundary = line.substring(index + 9);  // 9 for "boundary="
		if (boundary.charAt(0) == '"') 
		{
			// The boundary is enclosed in quotes, strip them
			index = boundary.lastIndexOf('"');
			boundary = boundary.substring(1, index);
		}

		// The real boundary is always preceeded by an extra "--"
		boundary = "--" + boundary;
		return boundary;
	}

	/**
	* Extracts and returns disposition info from a line, as a <code>String<code>
	* array with elements: disposition, name, filename.
	* 
	* @return String[] of elements: disposition, name, filename.
	* @exception  IOException if the line is malformatted.
	*/
	private String[] extractDispositionInfo(String line) throws IOException 
	{
		// Return the line's data as an array: disposition, name, filename
		String[] retval = new String[4];

		// Convert the line to a lowercase string without the ending \r\n
		// Keep the original line for error messages and for variable names.
		String origline = line;
		line = origline.toLowerCase();

		// Get the content disposition, should be "form-data"
		int start = line.indexOf("content-disposition: ");
		int end = line.indexOf(";");
		if (start == -1 || end == -1) 
		{
			throw new IOException("Content disposition corrupt: " + origline);
		}
		String disposition = line.substring(start + 21, end);
		if (!disposition.equals("form-data")) 
		{
			throw new IOException("Invalid content disposition: " + disposition);
		}

		// Get the field name
		start = line.indexOf("name=\"", end);  // start at last semicolon
		end = line.indexOf("\"", start + 7);   // skip name=\"
		if (start == -1 || end == -1) 
		{
			throw new IOException("Content disposition corrupt: " + origline);
		}
		String name = origline.substring(start + 6, end);

		// Get the filename, if given
		String filename = null;
		String origname = null;
		start = line.indexOf("filename=\"", end + 2);  // start after name
		end = line.indexOf("\"", start + 10);          // skip filename=\"
		if (start != -1 && end != -1) 
		{
			// note the !=
			filename = origline.substring(start + 10, end);
			origname = filename;
			// The filename may contain a full path.  Cut to just the filename.
			int slash = Math.max(filename.lastIndexOf('/'), filename.lastIndexOf('\\'));
			if (slash > -1) 
			{
				filename = filename.substring(slash + 1);  // past last slash
			}
		}

		// Return a String array: disposition, name, filename empty filename denotes no file posted!
		retval[0] = disposition;
		retval[1] = name;
		retval[2] = filename;
		retval[3] = origname;
		return retval;
	}

	/**
	* Extracts and returns the content type from a line, or null if the line was empty.
	* 
	* @return content type, or null if line was empty.
	* @exception  IOException if the line is malformatted.
	*/
	private String extractContentType(String line) throws IOException 
	{
		String contentType = null;

		// Convert the line to a lowercase string
		String origline = line;
		line = origline.toLowerCase();

		// Get the content type, if any
		if (line.startsWith("content-type")) 
		{
			int start = line.indexOf(" ");
			if (start == -1) 
			{
				throw new IOException("Content type corrupt: " + origline);
			}
			contentType = line.substring(start + 1);
		}
		else if (line.length() != 0) 
		{	
			// no content type, so should be empty
			throw new IOException("Malformed line after disposition: " + origline);
		}
		return contentType;
	}
  
	/**
	* Read the next line of input.
	* 
	* @return a String containing the next line of input from the stream, or null to indicate the end of the stream.
	* @exception IOException	if an input or output exception has occurred.
	*/
	private String readLine() throws IOException 
	{
		StringBuffer sbuf = new StringBuffer();
		int result;

		do 
		{
			result = in.readLine(buf, 0, buf.length);  // does +=
			if (result != -1) 
			{
				sbuf.append(new String(buf, 0, result, "ISO-8859-1"));
			}
		} 
		while (result == buf.length);  // loop only if the buffer was filled

		if (sbuf.length() == 0) return null;  // nothing read, must be at the end of stream

	    // Cut off the trailing \n or \r\n
		// It should always be \r\n but IE5 sometimes does just \n
		int len = sbuf.length();
		if (sbuf.charAt(len - 2) == '\r') 
			 sbuf.setLength(len - 2);  // cut \r\n
		else sbuf.setLength(len - 1);  // cut \n
		return sbuf.toString();
	}
}