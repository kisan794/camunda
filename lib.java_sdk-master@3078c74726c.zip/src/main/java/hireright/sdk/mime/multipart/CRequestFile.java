/*
 * @(#)$RCSfile: CRequestFile.java,v $ $Revision: 1.2 $ $Date: 2012/11/30 08:18:12 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/mime/multipart/CRequestFile.java,v $
 *
 * Copyright 2005-2012 by HireRight, Inc. All rights reserved.
 * 
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject
 * to license terms.
 * 
 * 
 * History: 
 *	H.Lukashenka			2012-16-11	Relocated from MVC
 */
package hireright.sdk.mime.multipart;

import java.io.Serializable;

/**
 * Class represent files retrieved from HTTP request.
 * @author Henadzi_Lukashenka
 */
public class CRequestFile implements Serializable
{

	private static final long serialVersionUID = 3368484724617435021L;

	/** Constant with current version of this class and its author. */
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";

	/**
	 * File name.
	 */
	private String name;

	/**
	 * File type.
	 */
	private String type;

	/**
	 * File mime type.
	 */
	private String mimeType;

	/**
	 * File content.
	 */
	private byte[] content;

	/**
	 * Get File name.
	 *
	 * @return String File name.
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * Get File name.
	 *
	 * @return String File type.
	 */
	public String getType()
	{
		return type;
	}

	/**
	 * Get File mime type.
	 *
	 * @return String File mime type.
	 */
	public String getMimeType()
	{
		return mimeType;
	}

	/**
	 * Get File content.
	 *
	 * @return byte[] File content.
	 */
	public byte[] getContent()
	{
		return content;
	}

	/**
	 * Set File name.
	 *
	 * @param name String File name.
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * Set File type.
	 *
	 * @param type String File type.
	 */
	public void setType(String type)
	{
		this.type = type;
	}

	/**
	 * Set File content.
	 *
	 * @param content byte[] File content.
	 */
	public void setContent(byte[] content)
	{
		this.content = content;
	}

	/**
	 * Set File mime type.
	 *
	 * @param mimeType String File mime type.
	 */
	public void setMimeType(String mimeType)
	{
		this.mimeType = mimeType;
	}
}
