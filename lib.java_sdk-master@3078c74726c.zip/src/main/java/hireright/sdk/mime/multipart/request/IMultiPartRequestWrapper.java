/*
 * @(#)$RCSfile: IMultiPartRequestWrapper.java,v $ $Revision: 1.2 $ $Date: 2012/11/30 08:18:16 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/mime/multipart/request/IMultiPartRequestWrapper.java,v $
 *
 * Copyright 2005-2012 by HireRight, Inc. All rights reserved.
 * 
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject
 * to license terms.
 * 
 * 
 * History: 
 *	H.Lukashenka			2012-16-11	Created.
 */
package hireright.sdk.mime.multipart.request;

import hireright.sdk.mime.multipart.CRequestFile;


/**
 * Interface of wrapped multipart user request object.
 * @author Henadzi_Lukashenka
 *
 */
public interface IMultiPartRequestWrapper
{

	/**
	 * File that were contained in request by its parameter name.
	 * @param sKey name of parameter under which file has been stored in request.
	 * @return file stored in http request.
	 */
	public CRequestFile getRequestFile(String sKey);

}
