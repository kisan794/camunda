/*
 * @(#)$RCSfile: CDateRange.java,v $ $Revision: 1.3 $ $Date: 2014/05/17 07:17:07 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/time/CDateRange.java,v $
 * Copyright 2001-2019 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   A.Tanasenko	2014-02-20	Created
 *   A.Tanasenko	2014-05-07	Added split(CTimeInterval)
 *   M.Konstantinov	2019-03-18	added equals()
 */

package hireright.sdk.time;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class CDateRange
{
	private final Date beginDate;
	private final Date endDate;
	
	protected CDateRange(Date beginDate, Date endDate)
	{
		this.beginDate = beginDate;
		this.endDate = endDate;
	}
	
	public Date getBeginDate()
	{
		return beginDate;
	}
	
	public Date getEndDate()
	{
		return endDate;
	}
	
	public static CDateRange range(Date beginDate, Date endDate)
	{
		return new CDateRange(beginDate, endDate);
	}
	
	public static CDateRange from(Date beginDate)
	{
		return new CDateRange(beginDate, null);
	}
	
	public static CDateRange to(Date endDate)
	{
		return new CDateRange(null, endDate);
	}
	
	public static CDateRange undefined()
	{
		return new CDateRange(null, null);
	}
	
	public boolean isDefined()
	{
		return beginDate != null || endDate != null;
	}
	
	public boolean isOpen()
	{
		return beginDate == null || endDate == null;
	}
	
	public CTimeInterval interval()
	{
		if(beginDate == null || endDate == null) return null;
		return CTimeInterval.diff(beginDate, endDate);
	}

	/**
	 * Splits this range into a list of continuous ranges each no longer than specified interval
	 */
	public List<CDateRange> split(final CTimeInterval maxInterval)
	{
		
		if(isOpen()) throw new IllegalStateException("Cannot split open interval");
		if(maxInterval.isZeroInterval()) throw new IllegalArgumentException("Cannot split by zero interval");
		
		CTimeInterval whole = CTimeInterval.diff(beginDate, endDate);
		
		// if it's less than required, return as is
		if(whole.compareTo(maxInterval, beginDate, true) < 0)
		{
			return Collections.singletonList(this);
		}
		
		long endTime = endDate.getTime();
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(beginDate);
		
		List<CDateRange> ranges = new ArrayList<CDateRange>();
		
		while(true)
		{
			long prevTime = cal.getTimeInMillis();
			maxInterval.addTo(cal);
			
			long curTime = cal.getTimeInMillis();
			
			if(curTime < endTime)
			{
				ranges.add(new CDateRange(new Date(prevTime), new Date(curTime)));
			}
			else
			{
				ranges.add(new CDateRange(new Date(prevTime), new Date(endTime)));
				break;
			}
		}
		
		return ranges;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		CDateRange other = (CDateRange) obj;
		return 
				 Objects.equals(beginDate, other.beginDate) 
			&& Objects.equals(endDate, other.endDate);
	}
	
	@Override
	public String toString()
	{
		return beginDate+" - "+endDate;
	}
	
	
}
