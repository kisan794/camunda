package hireright.sdk.time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/*
 * @(#)$RCSfile: CTDate.java,v $ $Revision: 1.5 $ $Date: 2015/11/02 20:14:48 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/time/CTDate.java,v $
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   A.Logachyov	2015-02-27	Created
 *   A.Podlipski	2015-04-13	NPE in setTDate fixed
 *   A.Podlipski	2015-07-02	now implements Comparable
 *   M.Suhhoruki	2017-10-02	added valueOf(Date date)
 */
import hireright.sdk.util.CStringUtils;

public class CTDate implements Comparable<CTDate>
{
    public static final String NOT_KNOWN = "not known";
    public static final String NOT_APPLICABLE = "not applicable";

    public static final String FORMAT_YYYY = "yyyy";
    public static final String FORMAT_YYYY_MM = "yyyy-MM";
    public static final String FORMAT_YYYY_MM_DD = "yyyy-MM-dd";

    public static final String FORMAT_MM_DD_YYYY = "MM/dd/yyyy";

    private final static Map<String, ThreadLocalDateFormat> m_formatMap =
            new HashMap<String, ThreadLocalDateFormat>();

    static
    {
        String[] patterns = {FORMAT_YYYY, FORMAT_YYYY_MM, FORMAT_YYYY_MM_DD, FORMAT_MM_DD_YYYY};

        for(String pattern: patterns)
        {
            m_formatMap.put(pattern, new ThreadLocalDateFormat(pattern));
        }
    }

    protected String m_sTDate = NOT_KNOWN;
    protected Integer m_nYear = null;
    protected Integer m_nMonth = null;
    protected Integer m_nDay = null;

    public String getTDate()
    {
        return m_sTDate;
    }

    public void setTDate(String sTDate)
    {
        m_sTDate = sTDate;
        m_nYear = null;
        m_nMonth = null;
        m_nDay = null;

        if (CStringUtils.isEmpty(sTDate) || NOT_KNOWN.equals(sTDate) || NOT_APPLICABLE.equals(sTDate))
        {
            return;
        }

        SimpleDateFormat simpleDateFormat = getDateFormat(FORMAT_YYYY_MM_DD);

        try
        {
            simpleDateFormat.parse(sTDate);
        }
        catch (ParseException e)
        {
            try
            {
                simpleDateFormat.parse(sTDate+"-01");
            }
            catch (ParseException ex)
            {
                try
                {
                    simpleDateFormat.parse(sTDate + "-01-01");
                }
                catch (ParseException exp)
                {
                    m_sTDate = NOT_KNOWN;
                    return;
                }
            }
        }

        m_nYear = Integer.parseInt(sTDate.substring(0,4));
        m_nMonth = (sTDate.length() > 6) ? Integer.parseInt(sTDate.substring(5,7)) : null;
        m_nDay = (sTDate.length() == 10) ? Integer.parseInt(sTDate.substring(8)) : null;
    }

    public Integer getYear()
    {
        return m_nYear;
    }

    public Integer getMonth()
    {
        return m_nMonth;
    }

    public Integer getDay()
    {
        return m_nDay;
    }

    public Date getDate()
    {
        if (m_nYear == null)
        {
            return null;
        }

        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(m_nYear,
                (m_nMonth != null) ? (m_nMonth-1) : 0,
                (m_nDay != null) ? m_nDay : 1,
                0,
                0,
                0);

        return calendar.getTime();
    }

	public Date getDate(String sFormat)
	{
		try
		{
			return getDateFormat(sFormat).parse(m_sTDate);
		}
		catch (Throwable t)
		{
			return null;
		}
	}

    public String format(String sFormat)
    {
        Date date = getDate();

        if (date != null)
        {
            SimpleDateFormat dateFormat = getDateFormat(sFormat);
            return dateFormat.format(date);
        }

        return null;
    }

    public static String formatWithEmpty(CTDate tDate, String sFormat)
    {
        return (sFormat == null || tDate == null)
                ?(null)
                :sFormat.replace("yyyy", (tDate.getYear()!=null)?(String.format("%04d",tDate.getYear())):"__")
                .replace("MM", (tDate.getMonth() != null) ? (String.format("%02d", tDate.getMonth())) : "__")
                .replace("dd", (tDate.getDay() != null) ? (String.format("%02d", tDate.getDay())) : "__");
    }

	public static String formatWithEmpty(CTDate tDate, String sSourceFormat, String sTargetFormat)
	{
		if (tDate == null
			|| CStringUtils.isEmpty(tDate.m_sTDate)
			|| CStringUtils.isEmpty(sSourceFormat)
			|| CStringUtils.isEmpty(sTargetFormat))
		{
			return null;
		}

		String sValue = tDate.m_sTDate;
		try
		{
			Date dValue = getDateFormat(sSourceFormat).parse(sValue);
			return getDateFormat(sTargetFormat).format(dValue);
		}
		catch (Throwable t)
		{
			return null;
		}
	}
	
	public static CTDate valueOf(Date date)
	{
		if (date == null)
		{
			return null;
		}
		
		CTDate tdate = new CTDate();
		tdate.setTDate(getDateFormat(FORMAT_YYYY_MM_DD).format(date));
		
		return tdate;
	}

    private static SimpleDateFormat getDateFormat(String sFormat)
    {
        ThreadLocalDateFormat threadLocalDateFormat = m_formatMap.get(sFormat);

        if (threadLocalDateFormat == null)
        {
            threadLocalDateFormat = new ThreadLocalDateFormat(sFormat);
            m_formatMap.put(sFormat, threadLocalDateFormat);
        }

        return threadLocalDateFormat.get();
    }

    private static class ThreadLocalDateFormat extends ThreadLocal<SimpleDateFormat>
    {
        private final String m_pattern;

        public ThreadLocalDateFormat(String pattern)
        {
            this.m_pattern = pattern;
        }

        @Override
        protected SimpleDateFormat initialValue()
        {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(m_pattern);
            simpleDateFormat.setLenient(false);
            return simpleDateFormat;
        }
    }

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(CTDate anotherDate)
	{
		return this.getTDate().compareTo(anotherDate.getTDate());
	}
}
