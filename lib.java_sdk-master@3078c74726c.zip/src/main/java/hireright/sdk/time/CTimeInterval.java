/*
 * @(#)$RCSfile: CTimeInterval.java,v $ $Revision: 1.3 $ $Date: 2014/03/15 07:34:21 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/time/CTimeInterval.java,v $
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   A.Tanasenko				2012-02-14	Created
 *   A.Tanasenko				2012-04-23	Moved from DD
 *   A.Tanasenko				2014-02-22	Extended with generic time interval methods
 *   V.Ozernov					2017-11-23	HIVPE-27292: fixed long to int casting error in compareTo()
 */
package hireright.sdk.time;

import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.EnumMap;
import java.util.Map;

/**
 * Maps time interval string '&lt;time&gt; &lt;unit&gt; ...' (e.g.: '3 days', '1 month 2 days', '10 Years 2 Months 1 Minute')
 * to time which can be added to {@link Calendar} instance.<br/><br/>
 * 
 * Time unit names are case insensitive and can be without trailing 's'.<br/><br/>
 * 
 * Many of the methods take a context date (or calendar instance) as an argument. This is due to the fact that time intervals are date dependent.
 * For example, '2 months' can be equal to 62, 61, 59 or 58 days, depending on the start date.
 * 
 * @author atanasenko
 * @version $Revision: 1.3 $, $Date: 2014/03/15 07:34:21 $ 
 */
public class CTimeInterval implements Comparable<CTimeInterval>
{
	/**
	 * Time unit to be used in intervals
	 */
	public enum Unit
	{
		YEAR(Calendar.YEAR, 0),
		MONTH(Calendar.MONTH, Calendar.JANUARY),
		WEEK(Calendar.WEEK_OF_YEAR, -1){
			@Override
			public void reset(Calendar cal)
			{
				cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
				DAY.reset(cal);
			}
		},
		DAY(Calendar.DAY_OF_YEAR, 1),
		HOUR(Calendar.HOUR_OF_DAY, 0),
		MINUTE(Calendar.MINUTE, 0),
		SECOND(Calendar.SECOND, 0),
		MILLISECOND(Calendar.MILLISECOND, 0);
		
		final int field;
		final int first;

		Unit(int field, int first)
		{
			this.field = field;
			this.first = first;
		}

		public static Unit forName(String name)
		{
			
			name = name.toLowerCase();
			for(Unit unit: values())
			{
				String unitName = unit.name().toLowerCase();
				
				if(unitName.startsWith(name))
				{
					return unit;
				}
				
				if(name.length() > 1 && name.charAt(name.length() - 1) == 's')
				{
					if(unitName.startsWith(name.substring(0, name.length() - 1)))
					{
						return unit;
					}
				}
			}
			
			throw new IllegalArgumentException("Invalid Unit: " + name);
		}
		
		/**
		 * Resets calendar to the beginning of &lt;Unit&gt;.<br/>
		 * Example: DAY.reset(cal) will set following fields to 0: milliseconds, seconds, minutes, hours of day
		 */
		public void reset(Calendar cal)
		{
			for(Unit unit: values())
			{
				// field constants go in opposite order
				if(unit.field > this.field && unit.first != -1)
				{
					cal.set(unit.field, unit.first);
				}
			}
		}
		
		/**
		 * Resets calendar to the beginning of &lt;Unit&gt;.<br/>
		 * Example: DAY.reset(cal) will set following fields to 0: milliseconds, seconds, minutes, hours of day
		 */
		public Date reset(Date date)
		{
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			reset(cal);
			return cal.getTime();
		}
	}
	
	private Map<Unit, Integer> times;
	
	/**
	 * Creates a new empty interval
	 */
	public CTimeInterval()
	{
	}
	
	/**
	 * Creates a single time interval
	 */
	public CTimeInterval(int time, Unit unit)
	{
		add(time, unit);
	}
	
	/**
	 * Copy constructor
	 */
	public CTimeInterval(CTimeInterval interval)
	{
		add(interval);
	}
	
	/**
	 * Adds an amount of time to this interval
	 * @param time
	 * @param unit
	 */
	public void add(int time, Unit unit)
	{
		if(time < 0) throw new IllegalArgumentException("Intervals must be positive");
		
		if(time == 0) return;
		
		if(times == null) times = new EnumMap<Unit, Integer>(Unit.class);
		Integer existingTime = times.get(unit);
		if(existingTime != null)
		{
			time += existingTime.intValue();
		}
		times.put(unit, time);
	}
	
	public String toString()
	{
		
		StringBuilder sb = new StringBuilder();
		
		if(times != null)
		{
			for(Map.Entry<Unit, Integer> e: times.entrySet())
			{
				int time = e.getValue().intValue();
				if(time == 0) continue;
				
				if(sb.length() != 0) sb.append(' ');
				sb.append(e.getValue()).append(' ').append(e.getKey().name().toLowerCase());
				if(time != 1) sb.append('s');
			}
		}
		
		return sb.toString();
	}
	
	/**
	 * Parses time interval string
	 * @param interval
	 * @return
	 */
	public static CTimeInterval parseInterval(String interval)
	{
		String[] parts = interval.split(" ");
		CTimeInterval intr = new CTimeInterval();
		
		for(int i = 1; i < parts.length; i += 2) {
			if(parts[1].endsWith("s"))
			{
				parts[i] = parts[i].substring(0, parts[i].length()-1);
			}
			intr.add(Integer.parseInt(parts[i-1]),
					Unit.forName(parts[i]));
		}
		
		return intr;
	}
	
	/**
	 * Calculates a difference interval between two dates
	 */
	public static CTimeInterval diff(Date date1, Date date2)
	{
		int c = date1.compareTo(date2);
		if(c == 0) return new CTimeInterval();
		if(c > 0)
		{
			// swap
			Date d = date1;
			date1 = date2;
			date2 = d;
		}
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(date1);
		
		CTimeInterval interval = new CTimeInterval();
		interval.fill(cal, date2.getTime(), true);
		return interval;
	}
	
	/**
	 * Add specified interval to the current interval
	 */
	public void add(CTimeInterval interval)
	{
		if(interval.times != null)
		{
			for(Map.Entry<Unit, Integer> e: interval.times.entrySet())
			{
				add(e.getValue(), e.getKey());
			}
		}
	}
	
	/**
	 * Creates a normalized interval which, when added to the specified context date, will yield the same result as the current interval.
	 */
	public CTimeInterval normalizeAdd(Date contextDate)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(contextDate);
		return normalize(cal, true);
	}
	
	/**
	 * Creates a normalized interval which, when subtracted from the specified context date, will yield the same result as the current interval.
	 */
	public CTimeInterval normalizeSubtract(Date contextDate)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(contextDate);
		return normalize(cal, false);
	}
	
	/**
	 * Creates a normalized interval which, when added to or subtracted from the specified context calendar, will yield the same result as the current interval.
	 */
	public CTimeInterval normalize(Calendar cal, boolean add)
	{
		CTimeInterval interval = new CTimeInterval();
		if(times == null || isZeroInterval()) return interval;
		
		long baseTime = cal.getTimeInMillis();
		if(add) addTo(cal);
		else subtractFrom(cal);
		long targetTime = cal.getTimeInMillis();
		
		cal.setTimeInMillis(baseTime);
		interval.fill(cal, targetTime, add);
		
		cal.setTimeInMillis(baseTime);
		return interval;
	}
	
	/**
	 * Calculates the number of whole units that this interval would cause to be added to the context date
	 */
	public int wholeUnitsAdd(Unit unit, Date contextDate)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(contextDate);
		return wholeUnits(unit, cal, true);
	}
	
	/**
	 * Calculates the number of whole units that this interval would cause to be subtracted from the context date
	 */
	public int wholeUnitsSubtract(Unit unit, Date contextDate)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(contextDate);
		return wholeUnits(unit, cal, false);
	}
	
	/**
	 * Calculates the number of whole units that this interval would cause to be added to or subtracted from the context calendar
	 */
	public int wholeUnits(Unit unit, Calendar cal, boolean add)
	{
		// prepare calendar
		long baseTime = cal.getTimeInMillis();
		if(add) addTo(cal);
		else subtractFrom(cal);
		long targetTime = cal.getTimeInMillis();
		
		if(unit.ordinal() > Unit.MONTH.ordinal())
		{
			cal.setTimeInMillis(baseTime);
			long var = targetTime - baseTime;
			return wholeUnits(unit, add ? var : -var);
		}
		
		cal.setTimeInMillis(baseTime);
		int amount = addSubtractWholeUnits(cal, targetTime, unit, add);
		
		cal.setTimeInMillis(baseTime);
		return amount;
	}
	
	// number of days, hours, minutes, seconds or milliseconds can be calculated from ms value directly
	private static int wholeUnits(Unit unit, long ms)
	{
		if(ms < 0) return 0;
		
		switch(unit)
		{
		case WEEK:
			ms = ms / 7;
			//$FALL-THROUGH$
		case DAY:
			ms = ms / 24;
			//$FALL-THROUGH$
		case HOUR:
			ms = ms / 60;
			//$FALL-THROUGH$
		case MINUTE:
			ms = ms / 60;
			//$FALL-THROUGH$
		case SECOND:
			ms = ms / 1000;
			//$FALL-THROUGH$
		case MILLISECOND:
			return (int) ms;
		default:
			throw new IllegalArgumentException("MONTH and YEAR are date-specific");
		}
	}
	
	/*
	 * fills this interval towards the target time
	 */
	private void fill(Calendar cal, long targetTime, boolean add)
	{
		for(Unit unit: Unit.values())
		{
			int num = addSubtractWholeUnits(cal, targetTime, unit, add);
			if(num > 0)
			{
				add(num, unit);
			}
		}
	}
	
	/*
	 * Adds or subtracts a number of whole units to the calendar until targetTime is reached. The number of units is returned.
	 */
	private static int addSubtractWholeUnits(Calendar cal, long targetTime, Unit unit, boolean add)
	{
		int amount = 0;
		
		long origTime = cal.getTimeInMillis();
		while(true)
		{
			cal.add(unit.field, add ? amount+1 : -(amount+1));
			
			if(add && cal.getTimeInMillis() <= targetTime || !add && cal.getTimeInMillis() >= targetTime)
			{
				amount++;
				cal.setTimeInMillis(origTime);
			}
			else
			{
				break;
			}
		}
		
		cal.setTimeInMillis(origTime);
		cal.add(unit.field, add ? amount : -amount);
		
		return amount;
	}
	
	/**
	 * Adds this time interval to specified date and returns a new date.
	 * This method is a shorthand for creating a new calendar out of existing date and calling {@link CTimeInterval#addTo(Calendar)}.
	 * 
	 * @param date
	 * @return
	 */
	public Date addTo(Date date)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		addTo(cal);
		return cal.getTime();
	}
	
	/**
	 * Adds this time interval to specified calendar
	 * 
	 * @param cal
	 */
	public void addTo(Calendar cal)
	{
		if(times != null)
		{
			for(Map.Entry<Unit, Integer> e: times.entrySet())
			{
				cal.add(e.getKey().field, e.getValue());
			}
		}
	}
	
	/**
	 * Subtracts this time interval from specified date and returns a new date.
	 * This method is a shorthand for creating a new calendar out of existing date and calling {@link CTimeInterval#subtractFrom(Calendar)}.
	 * 
	 * @param date
	 * @return
	 */
	public Date subtractFrom(Date date)
	{
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		subtractFrom(cal);
		return cal.getTime();
	}
	
	/**
	 * Subtracts this time interval from specified calendar
	 * 
	 * @param cal
	 */
	public void subtractFrom(Calendar cal)
	{
		if(times != null)
		{
			for(Map.Entry<Unit, Integer> e: times.entrySet())
			{
				cal.add(e.getKey().field, -e.getValue());
			}
		}
	}
	
	/**
	 * Returns true if this interval will not add anything
	 */
	public boolean isZeroInterval()
	{
		if(times == null) return true;
		for(Integer v: times.values())
		{
			if(v.intValue() > 0) return false;
		}
		
		return true;
	}
	
	/**
	 * Usage of this method is discouraged for non-normalized intervals
	 */
	public int compareTo(CTimeInterval o)
	{
		return compareTo(o, new Date(), true);
	}
	
	/**
	 * Context-date specific compare
	 */
	public int compareTo(CTimeInterval o, Date contextDate, boolean add)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(contextDate);
		long baseTime = calendar.getTimeInMillis();
		
		if(add) addTo(calendar);
		else subtractFrom(calendar);
		long thisTime = calendar.getTimeInMillis();
		
		calendar.setTimeInMillis(baseTime);
		
		if(add) o.addTo(calendar);
		else o.subtractFrom(calendar);
		long thatTime = calendar.getTimeInMillis();
		
		long var = thisTime - thatTime;
		var = add ? var : -var;
		
		return (var < 0 ? -1 : (var == 0 ? 0 : 1));
	}
	
	/**
	 * Comparator for non-normalized intervals, like '2 months'.compareTo('1 month 30 days'), which are date-dependent
	 */
	public static class IntervalComparator implements Comparator<CTimeInterval>
	{
		private Date contextDate;
		private boolean add;
		
		public IntervalComparator(Date contextDate, boolean add)
		{
			this.contextDate = contextDate;
			this.add = add;
		}
		
		@Override
		public int compare(CTimeInterval o1, CTimeInterval o2)
		{
			return o1.compareTo(o2, contextDate, add);
		}
	}
}