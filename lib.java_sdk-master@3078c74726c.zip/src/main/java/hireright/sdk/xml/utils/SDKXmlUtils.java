/*
 * @(#)$RCSfile: SDKXmlUtils.java,v $ $Revision: 1.5 $ $Date: 2008/02/21 21:54:45 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/SDKXmlUtils.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev		2005-04-07	created
 *	I.Suits				2005-07-12	setAttributeByPath now creates attrubute if it is missing
 *	A.Solntsev		2006-03-28	Now method buildDocument() doesn't spam System.out
 *	A.Solntsev		2006-04-18	Added method setNodeValueByPath(Document, String, Object)
 *	P.Bushuk			2007-02-02	check encoding
 *	A.Solntsev		2007-04-17	throw RuntimeException instead of Exception (on invlaid XML)
 *	A.Solntsev		2008-02-15	Removed useless INFO logs
 */
package hireright.sdk.xml.utils;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerException;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.apache.xpath.XPathAPI;
import hireright.sdk.util.CRuntimeException;

/**
 * XML Utilities used in J2SDK >= 1.4
 * Class needs library Xerces. See in CVS /sdk/java/fiorano/xerces.jar.
 *
 * @author Andrei Solntsev
 * @date 2005-04-07
 * @since java_sdk_v2-5-22_jdk14
 * @version $Revision: 1.5 $ $Date: 2008/02/21 21:54:45 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/SDKXmlUtils.java,v $
 */
public class SDKXmlUtils
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: asolntsev $";
	
	/**
	 * This class is not deployed on Application Server (which uses JDK 1.3),
	 * but deployed in library java_sdk_v2-5-22.jar, which is used in Fiorano ESB.
	 */
	private SDKXmlUtils()
	{
	}

	/**
	 * Method parses given string and build Document on it.
	 * If XML is invalid it throws an exception.
	 * @param sXML	for example, "<my_xml><first_node>value</first_node></my_xml>"
	 *
	 * @return null if sXML is not a valid XML
	 * @throws CRuntimeException
	 */
	public static Document buildDocument(String sXML)
	{
		if (sXML == null)
			return null;

		try
		{
			int simlpeLength = sXML.getBytes().length;
			int utf8Length = sXML.getBytes("UTF-8").length;
			
			if (simlpeLength != utf8Length)
			{
				throw new UnsupportedEncodingException("simlpeLength=" + simlpeLength + ", utf8Length=" + utf8Length);
			}

			Document doc = null;
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			//factory.setValidating(true);
			//factory.setNamespaceAware(true);

			InputStream is = new ByteArrayInputStream(sXML.getBytes());
			DocumentBuilder builder = factory.newDocumentBuilder();
			doc = builder.parse(is);

			return doc;
		}
		catch (Exception xmlEx)
		{
			throw new CRuntimeException(xmlEx, SDKXmlUtils.class.getName() + ".buildDocument()", null, sXML);
		}
	}

	/**
	 * method serializes XML DOM using Apache xerces.jar
	 * @param node	Document or Node object
	 * @return	xml string
	 */
	public static String serializeDocument(Node node)
	{
		if (node == null)
			return null;

		StringWriter writer = null;
		try
		{
			writer = new StringWriter();
			OutputFormat outformat = new OutputFormat();
			outformat.setIndent("	".length());
			outformat.setIndenting(true);
			outformat.setLineSeparator(System.getProperty("line.separator"));
			outformat.setOmitXMLDeclaration(true);
			if (node instanceof Document)
				(new XMLSerializer(writer, outformat)).serialize((Document)node);
			else
				(new XMLSerializer(writer, outformat)).serialize((Element)node);

			return writer.toString();
		}
		catch (Throwable xmlEx)
		{
			String sXmlToLog = null;
			if (writer != null)
				sXmlToLog = writer.toString();
			throw new CRuntimeException(xmlEx, SDKXmlUtils.class.getName() + ".serializeDocument()", null, sXmlToLog);
		}
		finally
		{
			try
			{
				if (writer != null)
					writer.close();
			}
			catch (IOException e)
			{
				// let's ignore it
			}
		}
	}

	/**
	 * Method finds a Node from given XML by given tag name.
	 * @param doc	Document not null
	 * @param sNodeName	Name of XML Tag.
	 * @return null if no elements found with given tag name.
	 */
	public static Node getDOMNode(Document doc, String sNodeName)
	{
		if (doc == null)
			return null;

		NodeList nodes = doc.getElementsByTagName(sNodeName);
		return (nodes==null || nodes.getLength()==0)? null : nodes.item(0);
	}

	/**
	 * Method gets node value or null
	 * @param doc DOM document
	 * @param sNodeName node name
	 * @return node value
	 */
	public static String getDOMNodeValue(Document doc, String sNodeName)
	{
		Node domNode = getDOMNode(doc, sNodeName);
		if (domNode != null && domNode.hasChildNodes())
		{
			return domNode.getFirstChild().getNodeValue();
		}
		return null;
	}

	/**
	 * Method returns node value using given XPath.
	 * @param doc	instance of org.w3c.dom.Document
	 * @param sXPath for example, "Person/ContactInfo/PersonName[FormattedName!='']/GivenName"
	 * @return null if no node found
	 *
	 * @throws NullPointerException	if sXPath is null
	 */
	public static String getNodeValueByPath(Document doc, String sXPath)
	{
		Node node = getNodeByPath(doc, sXPath);
		return (node==null || node.getFirstChild()==null)?
							null : node.getFirstChild().getNodeValue();
	}

	/**
	 * Method sets node value using given XPath.
	 * @param doc	instance of org.w3c.dom.Document
	 * @param sXPath for example, "Person/ContactInfo/PersonName[FormattedName!='']/GivenName".
	 * @param value any Object - Integer, Boolean etc. Method String.valueOf(value) is used.
	 * @return false if no node found
	 *
	 * @throws NullPointerException	if sXPath is null
	 */
	public static boolean setNodeValueByPath(Document doc, String sXPath, Object value)
	{
		return setNodeValueByPath(doc, sXPath, String.valueOf(value));
	}

	/**
	 * Method sets node value using given XPath.
	 * @param doc	instance of org.w3c.dom.Document
	 * @param sXPath for example, "Person/ContactInfo/PersonName[FormattedName!='']/GivenName".
	 * @param sValue any String value - for example, "John"
	 * @return false if no node found
	 *
	 * @throws NullPointerException	if sXPath is null
	 */
	public static boolean setNodeValueByPath(Document doc, String sXPath, String sValue)
	{
		Node node = getNodeByPath(doc, sXPath);

		if (node==null)
			return false;

		if (node.getFirstChild()==null)
		{
			// create child node
			Node nodeValue = doc.createTextNode(sValue);
			node.appendChild(nodeValue);
			return true;
		}

		// Change value of existing child node
		node.getFirstChild().setNodeValue(sValue);
		return true;
	}

	/**
	 * Method finds a node using given XPath and returns its attribute with given name.
	 * @param doc
	 * @param sXPath for example, "Person/ContactInfo/PersonName[FormattedName!='']/GivenName"
	 * @param sAttributeName for example, "valid".
	 * @return null if no node or attribute found.
	 *
	 * @throws NullPointerException	if sXPath is null
	 */
	public static String getAttributeByPath(Document doc, String sXPath, String sAttributeName)
	{
		Node node = getNodeByPath(doc, sXPath);

		if (node==null || node.getAttributes() == null
					|| node.getAttributes().getNamedItem(sAttributeName) == null)
			return null;

		return node.getAttributes().getNamedItem(sAttributeName).getNodeValue();
	}

	public static boolean setAttributeByPath(Document doc, String sXPath, String sAttributeName, String sAttributeValue)
	{
		Node node = getNodeByPath(doc, sXPath);

		if (node==null)
		{
			// TODO	create node
		}
		if (node.getAttributes() == null)
		{
			// TODO create attributes
		}
		if (node.getAttributes().getNamedItem(sAttributeName) == null)
		{
			node.getAttributes().setNamedItem(doc.createAttribute(sAttributeName));
		}

		node.getAttributes().getNamedItem(sAttributeName).setNodeValue(sAttributeValue);
		return true;
	}

	/**
	 * Method finds a Node using given XPath.
	 * @param doc	instance of org.w3c.dom.Document
	 * @param sXPath for example, "Person/ContactInfo/PersonName[FormattedName!='']/GivenName"
	 * @return null if no Node found
	 */
	public static Node getNodeByPath(Document doc, String sXPath)
	{
		if (doc == null || sXPath == null)
			return null;

		try
		{
			NodeList nodelist = XPathAPI.selectNodeList(doc, sXPath);
			Node node = (nodelist.getLength()==0)? null : nodelist.item(0);

			return node;
		}
		catch (TransformerException e)
		{
			return null;
		}
	}

	/**
	 *
	 * @param doc
	 * @param sNodeName
	 * @param sNodeValue
	 *
	 * @throws NullPointerException	if doc is null
	 * @return null if sNodeName is null or empty
	 */
	public static Node createNode(Document doc, String sNodeName, String sNodeValue)
	{
		if (sNodeName == null || sNodeName.trim().length()==0)
			return null;

		Node nodeName		= doc.createElement(sNodeName);
		Node nodeValue	= doc.createTextNode(sNodeValue == null ? "" : sNodeValue);

		nodeName.appendChild(nodeValue);

		return nodeName;
	}

	/**
	 *
	 * @param doc
	 * @param parentNode
	 * @param sChildNodeName
	 * @param sChildNodeValue
	 *
	 * @throws NullPointerException	if doc is null
	 */
	public static void createChildNode(Document doc, Node parentNode, String sChildNodeName, String sChildNodeValue)
	{
		Node childNode = createNode(doc, sChildNodeName, sChildNodeValue);
		parentNode.appendChild(childNode);
	}
}