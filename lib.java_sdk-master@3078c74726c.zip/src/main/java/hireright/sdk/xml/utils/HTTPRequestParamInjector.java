/*
 * @(#)$RCSfile: HTTPRequestParamInjector.java,v $ $Revision: 1.4 $ $Date: 2007/09/14 09:05:07 $ $Author: asolntsev $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 		Alexander Nesterov		2001		Created
 *		Andrei Solntsev			2006-04-24	Removed (this code is not used anymore)
 */
package hireright.sdk.xml.utils;

/**
 * @author Alexander Nesterov
 */
public class HTTPRequestParamInjector 
{
}
