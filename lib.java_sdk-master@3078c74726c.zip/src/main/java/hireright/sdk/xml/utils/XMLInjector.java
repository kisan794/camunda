/*
 * @(#)$RCSfile: XMLInjector.java,v $ $Revision: 1.4 $ $Date: 2008/11/21 11:31:54 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/XMLInjector.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov		2001-11-14	created
 *	A.Solntsev		2006-11-02	implements Serializable
 *	A.Solntsev		2008-11-14	Fixed empty statement body and IndexOutfBoundsException
 */	
package hireright.sdk.xml.utils;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import hireright.sdk.xml.parser.TreeNode;
import hireright.sdk.xml.parser.TreeNodeAttrib;
import hireright.sdk.xml.parser.XMLObject;
import hireright.sdk.xml.parser.XMLObjectException;
import hireright.sdk.xml.parser.XMLTreeNode;

/**
 * @author asolntsev
 * @version $Revision: 1.4 $ $Date: 2008/11/21 11:31:54 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/XMLInjector.java,v $
 */
public class XMLInjector extends XMLObject implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";

	private static final String NUMBERS = "0123456789";
	
	private TreeNode m_indexedParamsNodes;
	private XMLTreeNode m_outputNode;
	private String m_outputTableParameters;
	
	private final void initMe()
	{
		m_outputNode = new XMLTreeNode();
		m_indexedParamsNodes = new TreeNode();
		m_outputTableParameters = "";
	}
	
	public XMLInjector()
	{
		super();
		initMe();
	}
	
	public XMLInjector(String string) throws XMLObjectException
	{
		super(string);
	}
	
	public XMLInjector(URL url) throws XMLObjectException
	{
		super(url);
	}	 

	@Override
	public void parse(String string) throws XMLObjectException
	{
		initMe();
		super.parse(string);
	}
	
	@Override
	public void parse(URL url) throws XMLObjectException
	{
		initMe();
		super.parse(url);
	}	 	

	public String getTemplate()
	{
		if(m_rootNode != null)
			return m_rootNode.toString();
			
		return null;
	}

	public XMLTreeNode getOutputRootNode()
	{
		return m_outputNode;
	}
	
	public String getOutput()
	{
		if(m_outputNode != null)
			return m_outputNode.toString();
			
		return null;
	}
	
	public String getUpdateFields()
	{
		return m_outputTableParameters;
	}
	
	public void Inject(String szParamName,
					   String szParamValue)
	{
		// find node with 'param="szParaName"'
		TreeNode tempNode = (TreeNode) m_indexedParamsNodes.getData();
		
		int counter = 0;
		while (tempNode != null && tempNode.getPrevious() != null)
		{
			assert ++counter < 1000 : "Infinite loop";
			tempNode = tempNode.getPrevious();
		}

		int k = szParamName.length()-1;
		while ( k >= 0 && NUMBERS.indexOf( szParamName.charAt(k) ) != -1)
		{
			k--;
		}
		
		String szParam = szParamName.substring(0, k + 1);
		int nParamIndex = 1;
		if(k + 1 != szParamName.length())
			nParamIndex = (new Integer(szParamName.substring(k + 1))).intValue();
		
		int counter2 = 0;
		while (tempNode != null)
		{
			assert ++counter2 < 1000 : "Infinite loop";
			if (((TreeNodeAttrib) tempNode).getName().compareTo(szParam) == 0)
				injectNode(tempNode, nParamIndex, szParamValue);
			tempNode = tempNode.getNext();
		}
	}
	
	private void injectNode(TreeNode injectedNode, int nNodeIndex, String szParamValue)
	{
		try
		{
			List<XMLTreeNode> objList = new ArrayList<XMLTreeNode>();
		
			// walk to root node
			XMLTreeNode node = (XMLTreeNode) injectedNode.getData();
			String szStartTreeBrunch = node.getXMLTag();
			TreeNodeAttrib attrNode = node.getAttribNode("column");
			if(attrNode != null)
			{
				m_outputTableParameters += ("&UPD_" + ((String) attrNode.getData()) + "=" + szParamValue);
			}
			attrNode = node.getAttribNode("root");
			if(attrNode != null)
				szStartTreeBrunch = (String) attrNode.getData();
			
			int counter = 0;
			while (node.getParent() != null)
			{
				assert ++counter < 1000 : "Infinite loop";
				
				objList.add( node );
				node = (XMLTreeNode) node.getParent();
			}
		
			//check existance of the nodes in the result tree
			XMLTreeNode outNode = m_outputNode;			
			XMLTreeNode sddNode = null;
			int nodeIndex = 1;
			for(int i = objList.size() - 1; i >= 0; i--)
			{
				XMLTreeNode cloned = objList.get(i);
				if(szStartTreeBrunch.compareTo(cloned.getXMLTag()) == 0)
					nodeIndex = nNodeIndex;
				else
					nodeIndex = 1;
				XMLTreeNode existNode = outNode.getChildNodeByTag(cloned.getXMLTag(), nodeIndex);
				if(existNode == null)
				{
					sddNode = (XMLTreeNode) cloned.clone();
					if(i != 0)
						sddNode.setData( null );
					else
					{
						XMLTreeNode textNode = null;
						if(sddNode.getData() == null)
						{
							textNode = new XMLTreeNode();
							textNode.setData(szParamValue);
							sddNode.addChildNode(textNode);
						}
						else
						{
							textNode = (XMLTreeNode) sddNode.firstChildNode();
							if(textNode != null)
								textNode.setData(szParamValue);
						}
						sddNode.removeAttribNode("root");
						sddNode.removeAttribNode("param");
					}
					outNode.addChildNode(sddNode);
					outNode = sddNode;
				}
				else
				{
					outNode = existNode;
				}
			}
		}
		catch(Exception e)
		{
		}
	}
	
	@Override
	public void onNodeAdded(XMLTreeNode node)
	{
		TreeNodeAttrib anode = node.getAttribNode("param");
		if(anode != null)
		{
			TreeNodeAttrib storage = new TreeNodeAttrib();
			storage.setName(anode.getData().toString());
			storage.setData(node);
			m_indexedParamsNodes.addChildNode(storage);
		}
	}

	public void copyHeader()
	{
		// copy top level elements like '<?xml version ?>' into output
		TreeNode tempNode = m_rootNode.firstChildNode();				
		
		int counter = 0;
		while (tempNode != null)
		{
			assert ++counter < 1000 : "Infinite loop";
			
			if(tempNode.getData() == null)
				m_outputNode.addChildNode((TreeNode) tempNode.clone());

			tempNode = tempNode.getNext();
		}
	}
}