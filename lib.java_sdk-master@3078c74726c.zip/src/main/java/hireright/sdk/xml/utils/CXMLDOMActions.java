/*
 * @(#)$RCSfile: CXMLDOMActions.java,v $ $Revision: 1.2 $ $Date: 2008/01/11 15:49:37 $ $Author: asolntsev $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   Sergei Prokopov  2007-10-15  Created
 *   M.Karpov			2007-11-13  Moved to another more suitable package
 */
package hireright.sdk.xml.utils;

import hireright.sdk.util.CRuntimeException;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * Utilities class to work with XML DOM object
 *
 * @author  Sergei Prokopov
 * @version $Revision: 1.2 $ $Date: 2008/01/11 15:49:37 $ $Author: asolntsev $
 */
public class CXMLDOMActions
{
	/**
	 * Returns first child node by specified name
	 * <p> 
	 * @param parentNode			parent node
	 * @param sChildNodeName	child node name
	 * @return <code>Node</code> or <code>null</code> if child node is not found
	 */
	public static Node getFirstChildNodeByName(Node parentNode, String sChildNodeName)
	{
		NodeList childNodes = parentNode.getChildNodes();

		for (int count = 0; count < childNodes.getLength(); count++)
		{
			Node node = childNodes.item(count);

			if (sChildNodeName.equals(node.getNodeName()))
			{
				return node;
			}
		}

		return null;
	}

	/**
	 * Converts string to XML
	 * <p>
	 * @param sXML	string in XML format
	 * @return <code>Node</code>
	 */
	public static Node stringToXML(String sXML)
	{
		try
		{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			StringReader reader = new StringReader(sXML);
			InputSource inputSource = new InputSource(reader);
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(inputSource);
			return document.getFirstChild();
		}
		catch (Exception e)
		{
			throw new CRuntimeException(e);
		}
	}

	/**
	 * Returns quantity of child nodes with specified name
	 * <p>
	 * @param parentNode		parent node
	 * @param sChildName		child node name
	 * @return <code>int</code>
	 */
	public static int getChildNodesCountByName(Node parentNode, String sChildName)
	{
		int nNodes = 0;
		NodeList childNodes = parentNode.getChildNodes();

		for (int count = 0; count < childNodes.getLength(); count++)
		{
			Node node = childNodes.item(count);

			if (node.getNodeName().equals(sChildName))
			{
				nNodes++;
			}
		}

		return nNodes;
	}

	/**
	 * Converts XML into string
	 * <p>
	 * @param nodeRoot	xml node to convert
	 * @return <code>String</code>
	 */
	public static String xmlToString(Node nodeRoot)
	{
		try
		{
			Source source = new DOMSource(nodeRoot);
			StringWriter stringWriter = new StringWriter();
			Result result = new StreamResult(stringWriter);
			TransformerFactory factory = TransformerFactory.newInstance();
			Transformer transformer = factory.newTransformer();
			Properties props = transformer.getOutputProperties();
			props.setProperty("omit-xml-declaration", "yes");
			transformer.setOutputProperties(props);
			transformer.transform(source, result);
			return stringWriter.getBuffer().toString();
		}
		catch (Exception e)
		{
			throw new CRuntimeException(e);
		}
	}
}