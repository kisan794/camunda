/*
 * @(#)$RCSfile: UniversalInjector.java,v $ $Revision: 1.8 $ $Date: 2008/11/21 11:33:16 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/UniversalInjector.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2001-11-14	S.Ignatov		created
 *  2006-11-02  A.Solntsev  implements Serializable
 *  2006-11-07  A.Solntsev  Removed "System.out.println()"
 *  2008-02-18	A.Solntsev	Added method parseValidOutput() which throws RuntimeException
 */
package hireright.sdk.xml.utils;

import java.io.Serializable;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.xml.parser.*;

/**
 * Class for construction XML-Tree structures, from given XML document. 
 * All parsing operations - operations of XMLObject class.
 * All nodes operations - operations of XMLTreeNode class.
 *
 * example/test see below.
 * 
 * last changed 2001/11/20
 * @author Sergei Ignatov
 * @version $Revision: 1.8 $ $Date: 2008/11/21 11:33:16 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/UniversalInjector.java,v $
 */
public class UniversalInjector extends XMLObject implements Serializable 
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	protected class ValueIndexStruct implements Serializable 
	{
		public int m_nIndex;
		public String m_sValue;
	}

	/**
	 * Dublication mode. 
	 * No dublication at all, like it was before. Only Injection
	 *
	 */
	public static final int NO_DUBLICATION = 0;
	
	/**
	 * Dublication mode. 
	 * Dublicate info under branch out point, at injection, can be combined with 
	 * DUBL_ON_PARSING.
	 *
	 */
	public static final int DUBL_ON_INJECTION = 1;
	
	/**
	 * Dublication mode. 
	 * Dublicate all tree after source parsing( not at injection ), can be combined with 
	 * DUBL_ON_INJECTION.
	 *
	 */
	public static final int DUBL_ON_PARSING = 2;
	
	/**
	 * Dublication mode. 
	 * Dublicate only if DUBL attribute exists, can be combined with DUBL_ON_INJECTION or
	 * DUBL_ON_PARSING or both. Meaning attribute values "any_value"(any value thats default) - all 
	 * data and "stop_i", "stop_e" - only before this element(include, exclude it).
	 * ! do not combine with injector.copyHeader() it made same work !
	 *
	 */	
	public static final int DUBL_USE_PARAM = 4;
	
	protected int m_injectModes = NO_DUBLICATION;
	
	protected XMLTreeNode m_indexedAllParamsNodes;
	/**
	 * Output data node.
	 *
	 */
	protected XMLTreeNode m_outputNode;
	
	protected static String NUMBERS = "0123456789";
	protected String ROOT = "rootMap";
	protected static String DUBL = "retain";
	
	protected static String START_ONLY_THIS = "this";
	protected static String START_ALL_NODES = "all";
	protected static String STOP_INCLUDE = "stop_i";
	protected static String STOP_EXCLUDE = "stop_e";
	protected static String STOP_PREFIX = "stop_";
	
	protected static final int NO_DUBLICATION_I = NO_DUBLICATION;
	protected static final int DUBL_ON_INJECTION_I = DUBL_ON_INJECTION;
	protected static final int DUBL_ON_PARSING_I = DUBL_ON_PARSING;	
	protected static final int DUBL_USE_PARAM_I = DUBL_USE_PARAM;
	
	public UniversalInjector() 
	{
		super();
		
		if(m_outputNode == null)
			m_outputNode = new XMLTreeNode(); 
	}
	
	@Override
	protected void initParsing()
	{
		super.initParsing();
		
		if(m_indexedAllParamsNodes == null)
			return;
			
		XMLTreeNode childNode = (XMLTreeNode) m_indexedAllParamsNodes.firstChildNode();
		while(childNode != null)
		{
			childNode.setData(new java.util.Hashtable());
			childNode = (XMLTreeNode) childNode.getNext();
		}
	}
	
	/**
	 * Parse given XML and set it as output node.
	 *
	 */
	 
	public void parseOutput(java.net.URL url)
		throws XMLObjectException
	{
		XMLObject xmlObjL = new XMLObject(url);
		xmlObjL.mergeHashCodes(getRootNode());
		m_outputNode = xmlObjL.getRootNode();
		xmlObjL = null;
	}

	/**
	 * Create new xml structure from string as output. 
	 * @throws XMLObjectException if <code>sXMLData<code> contains invalid XML
	 */	
	public void parseOutput(String sXMLData) throws XMLObjectException
	{
		XMLObject xmlObjL = new XMLObject(sXMLData);
		xmlObjL.mergeHashCodes(getRootNode());
		m_outputNode = xmlObjL.getRootNode();
		xmlObjL = null;
	}
	
	/**
	 * The same as parseOutput() except that it throws RuntimeException in case of invalid input 
	 *
	 * @param sXMLData
	 */
	public void parseValidOutput(String sXMLData)
	{
		try
		{
			parseOutput( sXMLData );
		}
		catch (XMLObjectException xmle)
		{
			throw new RuntimeException(xmle);
		}
	}
	
	/**
	 * This calls when parse process done by XMLObject. 
	 *
	 */
	public void onDoneParsing()
	{
		if(m_outputNode != null)
		{
			m_outputNode.mergeXMLNodeHash(getRootNode());
		}
		
		if((m_injectModes & DUBL_ON_PARSING_I) == DUBL_ON_PARSING_I)
		{
			// this first child under root, data node only ONE always
			TreeNode childOfRootNode = m_rootNode.firstChildNode();
				
			while(childOfRootNode != null)
			{
				String szAtrNodeText = START_ONLY_THIS;
				if((m_injectModes & DUBL_USE_PARAM_I) == DUBL_USE_PARAM_I)
					szAtrNodeText = ((XMLTreeNode) childOfRootNode).getAttribText(UniversalInjector.DUBL);
					if(szAtrNodeText == null)
						szAtrNodeText = START_ONLY_THIS;
					
				if(szAtrNodeText != null)
				{
					XMLTreeNode clonedNode = (XMLTreeNode) m_outputNode.getChildNodeByHashCode(childOfRootNode.getHashCode(), 1);
					
					if(clonedNode == null)
					{
						clonedNode = cloneNodeWithSomeData((XMLTreeNode) childOfRootNode);
						clonedNode = dublicateStructure(clonedNode, childOfRootNode, szAtrNodeText);
						m_outputNode.addChildNode(clonedNode);
					}
					else
						clonedNode = dublicateStructure(clonedNode, childOfRootNode, szAtrNodeText);
				}
				childOfRootNode = childOfRootNode.getNext();
			}
		}

	}
	
	/**
	 * Overload from xml.parser.XMLObject. This method calls durig XML document pocessing 
	 * and add pointers to XML nodes to internal searching list.
	 * 
	 * @param node XML node, on which method fired.
	 *
	 */
	public void onNodeAdded(XMLTreeNode node)
	{
		if(m_indexedAllParamsNodes == null)
			return;
			
		XMLTreeNode childNode = (XMLTreeNode) m_indexedAllParamsNodes.firstChildNode();
		while(childNode != null)
		{
			// get node for all param nodes, like rootMap.
			TreeNodeAttrib anode = node.getAttribNode(childNode.getXMLTag());
			if(anode != null)
			{
				// if node not exists, node like rpptMap="sub10p"
				java.util.Hashtable hashtable = (java.util.Hashtable) childNode.getData();
					
				XMLTreeNode nodeFromHashTable = (XMLTreeNode) hashtable.get(anode.getData().toString()); 
				if(nodeFromHashTable == null)
				{
					hashtable.put(anode.getData().toString(), node);
				}
			}
			childNode = (XMLTreeNode) childNode.getNext();
		}
		
	}
	
	/**
	 * Initialisation method, call it before parsing. Call required before operations 
	 * with "inject", "injectAttribute", "injectValue" methods.
	 * 
	 * @param szAttributeName Attribute name for indexing. All XML nodes, contains this 
	 * attribute, will be added to internal searching list.
	 * @param removeAttrOnInjection Remove attribute with szAttributeName from output XML node.
	 *
	 */
	public void makeListsForNodes(String szAttributeName, boolean removeAttrOnInjection)
	{
		if(m_indexedAllParamsNodes == null)
			m_indexedAllParamsNodes = new XMLTreeNode();

		XMLTreeNode node = m_indexedAllParamsNodes.getChildNodeByTag(szAttributeName, 1);

		if(node == null)
			node = new XMLTreeNode();
		node.setData(null);

		node.setXMLTag(szAttributeName);

		java.util.Hashtable hashtable = new java.util.Hashtable();
		node.setData(hashtable);
		
		if(removeAttrOnInjection)
			node.setTag(1);
		else
			node.setTag(0);
		m_indexedAllParamsNodes.addChildNode(node);
	}
	
	/**
	 * Initialisation method. Set how injection process will work - inject only one node or
	 * all structure under node at which structure branch out.
	 * example: injector.setBranchInjectionMode(UniversalInjector.DUBL_ON_INJECTION | UniversalInjector.DUBL_ON_PARSING | UniversalInjector.DUBL_USE_PARAM);
	 *
	 * @param injectModes false(class default value), if injection must affect only one node. 
	 * else true.
	 *
	 */
	public void setBranchInjectionMode(int injectModes)
	{
		m_injectModes = injectModes;
	}

	/**
	 * Get node from source document which contain node with attribute 
	 * "szAttribName"="szAttribValue".
	 * 
	 * @param szAttribName
	 * @param szAttribValue
	 *
	 * @deprecated
	 *
	 */
	public XMLTreeNode getNodeFromSRC(String szAttribName, String szAttribValue)
	{
//ptc1
		/*
		XMLTreeNode childNode = (XMLTreeNode) m_indexedAllParamsNodes.getChildNodeByTag(szAttribName, 1);
		if(childNode != null)
		{
			XMLTreeNode nodeWithAttributeStorage = childNode.getChildNodeByTag(szAttribValue, 1);
			if(nodeWithAttributeStorage != null)
			{
				return (XMLTreeNode) nodeWithAttributeStorage.getData();
			}
		}
		*/
		return null;
	}
	/**
	 * Get node, contains all subnodes with concrete attribute name = parameter & real nodes as data
	 *
	 */
	public XMLTreeNode getParentNodeFromSRC(String szAttribName)
	{
		return m_indexedAllParamsNodes.getChildNodeByTag(szAttribName, 1);
	}

	/**
	 * Returns root node of injection operations.
	 *
	 */
	public XMLTreeNode getOutputRootNode()
	{
		return m_outputNode;
	}
	
	public void setOutputRootNode(XMLTreeNode node)
	{
		m_outputNode = node;
	}		
	
	protected ValueIndexStruct extractNameIndex(String sValue)
	{
		ValueIndexStruct result = new ValueIndexStruct();
		
		result.m_nIndex = 1;
		
		int k = sValue.length() -1;
		while (k>=0 && NUMBERS.indexOf(sValue.charAt(k)) != -1)
		{
			k--;
		}
		
		result.m_sValue = new String(sValue.substring(0, k + 1));

		if(k + 1 != sValue.length())
			result.m_nIndex = Integer.parseInt(sValue.substring(k + 1));
			
		return result;
	}

	/**
	 * Part of common procedure for injection attributes and nodes values. This one for injection with 
	 * attribute value contains name and index like "attribute10". It separate attribute name value 
	 * and node index, and call another inject() method. 
	 *
	 * @param szAttributeName name of attribute, owned by node where injection will be done. 
	 * @param szParamName value of attribute, owned by node where injection will be done. 
	 *  This name consist from attribute name and index of node, like 'attribute10'. 
	 * @param szParam1 name of attribute, which will be created in node attributes, or 
	 *  value if node value injected. 
	 * @param szParam2 value of attribute, which will be created in node attributes, or
	 *  null if node value injected. 
	 *
	 * @return true if inject done successefully, otherwise false. 
	 *
	 */
	protected boolean inject(String szAttributeName, String szParamName, String szParam1, String szParam2)
	{
		ValueIndexStruct valInd = extractNameIndex(szParamName);
		
		return inject(szAttributeName, valInd.m_sValue, valInd.m_nIndex, szParam1, szParam2);
	}
	
	/**
	 * Part of common procedure for injection attributes and nodes values. This one prepare parameters 
	 *  for node injection with injectNode(), and when injection will be done it setup data or create 
	 *  attribute for injected node. 
	 *
	 * @param szAttributeName name of attribute, owned by node where injection will be done. 
	 * @param szParam value of attribute, owned by node where injection will be done. 
	 * @param nParamIndex index of branch, owned by node where injection will be done. 
	 * @param szParam1 name of attribute, which will be created in node attributes, or 
	 *  value if node value injected. 
	 * @param szParam2 value of attribute, which will be created in node attributes, or
	 *  null if node value injected. 
	 *
	 * @return true if inject done successefully, otherwise false. 
	 *
	 */
	protected boolean inject(String szAttributeName, String szParam, int nParamIndex, String szParam1, String szParam2)
	{
		
		if(nParamIndex < 1)
			return false;
			
		// look for list of nodes with this attributes
		XMLTreeNode topAttributeNode = m_indexedAllParamsNodes.getChildNodeByTag(szAttributeName, 1);
		if(topAttributeNode == null)
			return false;

		// get node, contains link to requested node
		java.util.Hashtable hashtable = (java.util.Hashtable) topAttributeNode.getData();
		XMLTreeNode tempNode = (XMLTreeNode) hashtable.get(szParam);
		
		if(tempNode == null)
			return false;
		
		// parameters prepared, now inject. into . node with data, index, value
		XMLTreeNode node = null;
		// real injection methdod call.
		node = injectNode(m_outputNode, tempNode, nParamIndex, szParam1);
		
		if(node != null)  // if successefully injected
		{
			if(topAttributeNode.getTag() == 1) // remove attribute after injection
				node.removeAttribNode(topAttributeNode.getXMLTag());
				
			if(szParam2 != null) // attribute injection
			{
				TreeNodeAttrib atrNode = new TreeNodeAttrib();
				atrNode.setName(szParam1);
				atrNode.setData(szParam2);
				node.addAttribNode(atrNode);
			}
			else // value injection
			{
				XMLTreeNode textNode = (XMLTreeNode) node.getTextNode();
				if(textNode == null) // is node empty
				{
					textNode = new XMLTreeNode();
					textNode.setData(szParam1);
					textNode.setTextMode(XMLOpt.TEXT_NORMAL);
					node.addChildNode(textNode);
				}
				else // is node contains data
				{
					int textMode = textNode.getNodeType();
					textNode.setData(szParam1);
					//textNode.setTextMode(XMLOpt.TEXT_NORMAL);
					textNode.setTextMode(textMode);
				}
			}
			return true;
		}
		
		return false;
	}	

	/**
	 * Values injection into output XML tree. 
	 * Inject new attribute szInjAttribName="szParamValue" to node, with attribute szAttributeName="szParamNameXXXX". 
	 * 
	 * @param szAttributeName name of attribute, owned by node where injection will be done. 
	 * @param szParamName value of attribute, owned by node where injection will be done. 
	 *  This name consist from attribute name and index of node, like 'attribute10'. 
	 * @param szInjAttribName name of attribute, which will be created in node attributes. 
	 * @param szInjAttribValue value of attribute, which will be created in node attributes. 
	 *
	 * @return true if inject done successefully, otherwise false. 
	 * 
	 */
	public boolean injectAttribute(String szAttributeName, String szParamName, String szInjAttribName, String szInjAttribValue)
	{
		if(szInjAttribValue == null)
			szInjAttribValue = "";		
		// call for common procedure for injection attributes and nodes. 			
		return inject(szAttributeName, szParamName, szInjAttribName, szInjAttribValue);
	}
	
	/**
	 * Values injection into output XML tree. 
	 * Inject new attribute szInjAttribName="szParamValue" to node, with attribute szAttributeName="szParamNameXXXX". 
	 * 
	 * @param szAttributeName name of attribute, owned by node where injection will be done. 
	 * @param szParamName value of attribute, owned by node where injection will be done. 
	 * @param nParamIndex index of branch, owned by node where injection will be done. 
	 * @param szInjAttribName name of attribute, which will be created in node attributes. 
	 * @param szInjAttribValue value of attribute, which will be created in node attributes. 
	 *
	 * @return true if inject done successefully, otherwise false. 
	 * 
	 */	
	public boolean injectAttribute(String szAttributeName, String szParamName, int nParamIndex, String szInjAttribName, String szInjAttribValue)
	{
		if(szInjAttribValue == null)
			szInjAttribValue = "";		
		// call for common procedure for injection attributes and nodes. 
		return inject(szAttributeName, szParamName, nParamIndex, szInjAttribName, szInjAttribValue);
	}	
	
	/**
	 * This code make dublication of XML structure for appliedNode from srcStructureNode.
	 *
	 */
	protected XMLTreeNode dublicateStructure(TreeNode appliedNode, TreeNode srcStructureNode, String szDublicateMode)
	{
		try
		{
			XMLTreeNode childNode = (XMLTreeNode) srcStructureNode.firstChildNode();
			
			while(childNode != null)
			{
				String szAtrNodeText = null;
				if((m_injectModes & DUBL_USE_PARAM_I) == DUBL_USE_PARAM_I)
					szAtrNodeText = childNode.getAttribText(UniversalInjector.DUBL);
				else
					szAtrNodeText = START_ALL_NODES;

				if(szAtrNodeText == null)
				{
					if(szDublicateMode.compareTo(START_ONLY_THIS) == 0)
						szAtrNodeText = STOP_EXCLUDE;
					else
						szAtrNodeText = szDublicateMode;
				}
				
				XMLTreeNode clonedChild = ((XMLTreeNode) appliedNode).getChildNodeLike(childNode);
				boolean nodeExists = true;
				if(clonedChild == null)
				{
					clonedChild = (XMLTreeNode) childNode.clone();
					nodeExists = false;
				}
				if(clonedChild.getData() != null && clonedChild.getData().getClass().getName().compareTo(clonedChild.getClass().getName()) == 0)
					clonedChild.setData(null);
					
				if(!szAtrNodeText.startsWith(STOP_PREFIX))
					clonedChild = dublicateStructure(clonedChild, childNode, szAtrNodeText);
				if(!nodeExists && !szAtrNodeText.startsWith(STOP_EXCLUDE))
					appliedNode.addChildNode(clonedChild);

				childNode = (XMLTreeNode) childNode.getNext();
			}
		}
		catch (RuntimeException e)
		{
			CProperties params = new CProperties();
			if (appliedNode != null)
				params.setProperty("appliedNode", appliedNode.getTag());
			if (srcStructureNode != null)
				params.setProperty("srcStructureNode", srcStructureNode.getTag());
			params.setProperty("szDublicateMode", String.valueOf(szDublicateMode));
			
			// FIXME Throw RuntimeException instead
			CTraceLog.error(e, getClass().getName() + ".dublicateStructure()", params);
		}
		
		return (XMLTreeNode) appliedNode;
	}
	
	protected XMLTreeNode cloneNodeWithSomeData(XMLTreeNode nodeToClone)
	{
		XMLTreeNode sddNode = null;
		try
		{
			sddNode = (XMLTreeNode) nodeToClone.clone(); // clone node from hierarhy.
			if(nodeToClone.getNodeType() == XMLOpt.TEXT_NONE)
				sddNode.setData( null );                // set null data for node.
			XMLTreeNode textNode = (XMLTreeNode) nodeToClone.getTextNode();
			if(textNode != null && textNode.getNodeType() != XMLOpt.TEXT_NONE)
			{   // copy node data, if node contain it.
				int textMode = textNode.getNodeType();
				textNode = new XMLTreeNode();
				textNode.setData("");
				textNode.setTextMode(textMode);
				sddNode.addChildNode(textNode);
			}		
		}
		catch (RuntimeException e)
		{
			//FIXIT possible endless loop in calling proc.
			CProperties params = new CProperties();
			if (nodeToClone != null)
				params.setProperty("nodeToClone", nodeToClone.getTag());
			
			// FIXME Throw RuntimeException instead
			CTraceLog.error(e, getClass().getName() + ".cloneNodeWithSomeData()", params);
		}
		return sddNode;
	}
	
	/**
	 * Create new node in output nodes list. 
	 * ! do not support structures with same tags like <tag1><tag2><tag1></tag1></tag2></tag1>
	 *
	 * @param outNodes nodes tree, in where injection will be done. 
	 * @param iinjectedNode node from parsed structure, which correspond to new node in output structure. 
	 * @param nNodeIndex index of node`s branch. 
	 * @param szParamValue name of attribute, which will be created in node attributes, or 
	 *  value if node value injected. 
	 *
	 */
	protected XMLTreeNode injectNode(TreeNode outNodes, TreeNode iinjectedNode, int nNodeIndex, String szParamValue)
	{
		XMLTreeNode resultNode = null;
		try
		{
			//prepare list for collect nodes path from root to injection node
			// <ROOT>--<NODE>--<...>--<NODE>--<DIV NODE>--<NODE>--<...>--<NODE>--<INJECTION NODE = injectedNode data>
			java.util.LinkedList allParentOfInjectionNodeList = new java.util.LinkedList();

			// node, which will be injected
			XMLTreeNode node = (XMLTreeNode) iinjectedNode;
			
			// default tag name of node where structure will branch out( eq. this node tag )
			//! String szStartTreeBrunch = node.getXMLTag();
			int nHashCode = node.getHashCode();
			TreeNodeAttrib attrNode = node.getAttribNode(ROOT); // get attribute with branch out node tag value
			
			ValueIndexStruct valInd = null;
			if(attrNode != null) // then szStartTreeBrunch set this value to variable declared above
			{
				//! szStartTreeBrunch = (String) attrNode.getData();
				valInd = extractNameIndex((String) attrNode.getData());
			}

			int nSameTagsCounter = 1;
			while(node.getParent() != null) // get all parents and parents of parents of injection node
			{
				if(valInd != null && valInd.m_sValue.compareTo(node.getXMLTag()) == 0)
				{
					if(nSameTagsCounter == valInd.m_nIndex)
						nHashCode = node.getHashCode();
					nSameTagsCounter++;
				}
				
				allParentOfInjectionNodeList.add(node);
				node = (XMLTreeNode) node.getParent();
			}
						
			XMLTreeNode outNode = m_outputNode; // currently root node, later childs nodes
			//
			//////////// PREPARE done
			
			//////////// INJECTION start
			//
			for(int i = allParentOfInjectionNodeList.size() - 1; i >= 0; i--)
			{ 
				XMLTreeNode nodeFromParentsList = (XMLTreeNode) allParentOfInjectionNodeList.get(i);
				
				XMLTreeNode existNode = null;
				//! if(szStartTreeBrunch.compareTo(nodeFromParentsList.getXMLTag()) == 0)
				if(nHashCode == nodeFromParentsList.getHashCode())
				{ // check for branch out node: setup index value
					//! existNode = outNode.getChildNodeByTag(nodeFromParentsList.getXMLTag(), nNodeIndex);
					existNode = (XMLTreeNode) outNode.getChildNodeByHashCode(nodeFromParentsList.getHashCode(), nNodeIndex);
					while(existNode == null)
					{
						XMLTreeNode tmpNode = cloneNodeWithSomeData(nodeFromParentsList);
						// will dublicate structure.
						if((m_injectModes & DUBL_ON_INJECTION) == DUBL_ON_INJECTION)
							tmpNode = dublicateStructure(tmpNode, nodeFromParentsList, START_ALL_NODES);
						outNode.addChildNode(tmpNode);
						//! existNode = outNode.getChildNodeByTag(nodeFromParentsList.getXMLTag(), nNodeIndex);
						existNode = (XMLTreeNode) outNode.getChildNodeByHashCode(nodeFromParentsList.getHashCode(), nNodeIndex);
					}
				}
				else
				{
					//! existNode = outNode.getChildNodeByTag(nodeFromParentsList.getXMLTag(), 1);
					existNode = (XMLTreeNode) outNode.getChildNodeByHashCode(nodeFromParentsList.getHashCode(), 1);
					if(existNode == null)
					{
						outNode.addChildNode(cloneNodeWithSomeData(nodeFromParentsList));
						//! existNode = outNode.getChildNodeByTag(nodeFromParentsList.getXMLTag(), 1);
						existNode = (XMLTreeNode) outNode.getChildNodeByHashCode(nodeFromParentsList.getHashCode(), 1);
					}
				}
				
				resultNode = outNode = existNode;
			}
			//
			//////////// INJECTION done
		}
		catch (RuntimeException e)
		{
			CProperties params = new CProperties();
			if (outNodes != null)
				params.setProperty("outNodes", outNodes.getTag());
			if (iinjectedNode != null)
				params.setProperty("iinjectedNode", iinjectedNode.getTag());
			params.setProperty("nNodeIndex", String.valueOf(nNodeIndex));
			params.setProperty("szParamValue", String.valueOf(szParamValue));
			// FIXME Throw RuntimeException instead
			CTraceLog.error(e, getClass().getName() + ".injectNode()", params);
		}
		
		return resultNode;
		
	}

	/**
	 * Injection into output XML tree. 
	 * Inject string value=szParamValue as node data, for node with attribute szAttributeName = szParamNameXXXX.
	 *
	 */
	public boolean injectValue(String szAttributeName, String szParamName, String szParamValue)
	{
		if(szParamValue == null)
			szParamValue = "";
		return inject(szAttributeName, szParamName, szParamValue, null);
	}
	
	public boolean injectValue(String szAttributeName, String szParamName, int nParamIndex, String szParamValue)
	{
		if(szParamValue == null)
			szParamValue = "";
		return inject(szAttributeName, szParamName, nParamIndex, szParamValue, null);
	}	

	/**
	 * Recreate output node, kills all output data.
	 *
	 */
	public void resetOutput()
	{
		m_outputNode = new XMLTreeNode(); 
	}
	
	/**
	 * Copy second level nodes(under root), which not have childs nodes, to output. 
	 * Nodes like '<?xml version ?>'
	 *
	 */
	public void copyHeader()
	{
		TreeNode tempNode = m_rootNode.firstChildNode();
				
		while(tempNode != null)
		{
			if(tempNode.getData() == null && m_outputNode.getChildNodeByTag(((XMLTreeNode) tempNode).getXMLTag()) == null)
			{
				m_outputNode.addChildNode((TreeNode) tempNode.clone());
			}

			tempNode = tempNode.getNext();
		}
	}
	
	/**
	 * Define parameter name for tree branch out. 
	 *
	 */
	public void setRootString(String szRootName)
	{
		ROOT = szRootName;
	}
	
	
}

/*

// test class start

package hireright.tests;

import hireright.sdk.xml.parser.*;
import hireright.sdk.xml.utils.*;
import java.net.URL;

public class XMLObjectWrapperTest
{
	public static void main(String[] argv)
	{
		try
		{
			UniversalInjector injector = new UniversalInjector();
			injector.makeListsForNodes("paramMap", false);
			injector.makeListsForNodes("rootMap", false);
			injector.setBranchInjectionMode(UniversalInjector.DUBL_ON_PARSING | UniversalInjector.DUBL_USE_PARAM);
			injector.parseOutput(new URL("file:///F:/output.xml"));
			injector.injectValue("paramMap", "sub1p", "ELEMENT VAALUE");
			injector.setBranchInjectionMode(UniversalInjector.DUBL_ON_PARSING);
			injector.parse(new URL("file:///F:/input2.xml"));
			injector.parse(new URL("file:///F:/input2.xml"));			
			injector.parse(new URL("file:///F:/input.xml"));
			injector.parse(new URL("file:///F:/input2.xml"));			
			injector.parse(new URL("file:///F:/input.xml"));
			injector.injectAttribute("paramMap", "sub1p", 2, "new_attribute", "ATTRIBUTE VAALUE");			
			System.out.println("final result");
			System.out.println(injector.getOutputRootNode().toString());
		}
		catch(Exception e)
		{
			e.printStackTrace(System.out);
		}
	}
}

// xml`s

input.xml:
<?xml version='1.0'?>
<data>
	<sub1 paramMap='sub1p'>
	</sub1>
	<sub2 paramMap='sub2p'>
	</sub2>
</data>

input2.xml:
<?xml version='1.0'?>
<data>
	<sub10 paramMap='sub10p'>data 10</sub10>
	<sub20 paramMap='sub20p'>
		<structure20>
			<more20>data 20</more20>
		</structure20>
	</sub20>
</data>

output.xml:
<?xml version='1.0'?>
<data>
	<sub1 paramMap='sub1p'>sub 1 data 1</sub1>
	<sub1 paramMap='sub1p'>sub 1 data 2</sub1>
	<sub1 paramMap='sub1p'>sub 1 data 3</sub1>
	<sub2 paramMap='sub2p'>sub 2 data 1</sub2>
	<sub2 paramMap='sub2p'>sub 2 data 2</sub2>
</data>

*/