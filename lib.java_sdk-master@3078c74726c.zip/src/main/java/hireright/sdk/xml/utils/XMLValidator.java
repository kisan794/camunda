/*
 * @(#)$RCSfile: XMLValidator.java,v $ $Revision: 1.10 $ $Date: 2009/01/09 10:50:54 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/XMLValidator.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	A.Solntsev			2004-05-25	Created.
 *  A.Solntsev			2004-09-13	Added Schema cache.
 *  A.Solntsev			2005-08-29	Now EHCache is used.
 *  A.Solntsev			2007-06-22	Removed dependency on hireright.sdkex.as_cache
 *  A.Solntsev			2007-11-26	NetTracking.registerUrl(sUrlXSD);
 *  A.Solntsev			2008-01-15	Compatible with both Oracle XMl parsers 9i and 10g 
 */
package hireright.sdk.xml.utils;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.net.NetTracking;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.IHasProperties;

import java.io.ByteArrayInputStream;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import oracle.xml.parser.schema.XMLSchema;
import oracle.xml.parser.schema.XSDBuilder;
import oracle.xml.parser.schema.XSDException;
import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLConstants;
import oracle.xml.parser.v2.XMLParseException;

/**
 *	Class with utilities for validating XML.
 *	Currently contains only XSD-validation.
 *
 *	@author		Andrei Solntsev
 *	@source		$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/XMLValidator.java,v $
 *	@version	$Revision: 1.10 $ $Date: 2009/01/09 10:50:54 $ $Author: cvsroot $
 */
public class XMLValidator implements Serializable, IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.10 $ $Author: cvsroot $";
	private static final String ERROR_SOURCE = XMLValidator.class.getName();

	/**
	 * Cache for oracle.xml.parser.v2.DOMParser instances
	 */
	private static Cache m_schemaCache;
	private static final Object lock = new Object();

	private String m_xsdUrl;
	private DOMParser m_dp;

	protected static Cache getCache()
	{
		if (null == m_schemaCache)
		{
			synchronized (lock)
			{
				if (null == m_schemaCache)
				{
					CacheManager mng = CacheManager.create();
					String sCacheName = DOMParser.class.getName();
					m_schemaCache = mng.getCache(sCacheName);
					if (null == m_schemaCache)
					{
						mng.addCache(sCacheName);
						m_schemaCache = mng.getCache(sCacheName);
					}
				}
			}
		}

		return m_schemaCache;
	}

	public XMLValidator(String xsdUrl, DOMParser dp)
	{
		m_xsdUrl = xsdUrl;
		m_dp = dp;
	}

	public String getXsdUrl()
	{
		return m_xsdUrl;
	}

	public String toString()
	{
		return "XML Validator " + getXsdUrl();
	}

	public CProperties toProperties()
	{
		return new CProperties()
			.setProperty("validationXSD", getXsdUrl());
	}

	/**
	 * Validate xml structure using given xsd.
	 *
	 * @param szXML			for example, "<data_node><name>John</name></data_node>"
	 * @params szUrlXSD	for example, "http://localhost/desings/n-age/base/xsd/personal_information.xsd"
	 *
	 * @return true	if xml structure is valid.
	 */
	public boolean validate(String szXML)
	{
		boolean bResult = true;	// Validation Ok
		try
		{
			m_dp.parse( new ByteArrayInputStream(szXML.getBytes()) );
		}
		catch (MalformedURLException e)
		{
			CTraceLog.error(e, ERROR_SOURCE+".validate()", toProperties(), szXML);
			bResult = true;	// If XSD not found, validation is Ok
		}
		catch ( XMLParseException pe )
		{
			// Formats full error message
			CProperties params = toProperties();
			int num = pe.getNumMessages();
			for (int i=0; i < num; i++)
			{
				String sMessage = pe.formatErrorMessage(i);
				if ( sMessage != null )
				{
					params.setProperty("message"+i, sMessage);
				}
			}
			CTraceLog.error(pe, ERROR_SOURCE+".validate()", params, szXML);
			bResult = false;
		}
		catch (Throwable e)
		{
			CTraceLog.error(e, ERROR_SOURCE+".validate()", toProperties(), szXML);
			bResult = false;
		}

		return bResult;
	}

	public static boolean validate(String szXML, String szUrlXSD)
	{
		XMLValidator validator = getValidator(szUrlXSD);
		return validator.validate(szXML);
	}

	public static void clearCache()
	{
		getCache().removeAll();
	}


	public static XMLValidator getValidator(String szUrlXSD)
	{
		final XMLValidator xsd;

		Element el = getCache().get(szUrlXSD);
		if (el == null)
		{
			xsd = parseXSD(szUrlXSD);
			el = new Element(szUrlXSD, xsd);
			getCache().put(el);
		}
		else
		{
			xsd = (XMLValidator) el.getValue();
		}

		return xsd;
	}

	protected static XMLValidator parseXSD(String sUrlXSD)
		//throws MalformedURLException, XSDException, XMLParseException
	{
		try
		{
			NetTracking.registerUrl(sUrlXSD);
			URL urlValidation = new URL(sUrlXSD);

			//Build Schema Object
			XSDBuilder builder = new XSDBuilder();
			XMLSchema schemadoc = (XMLSchema) builder.build( urlValidation );

			//Parse the input XML document with Schema Validation
			DOMParser dp  = new DOMParser();

			// Set Schema Object for Validation
			dp.setXMLSchema( schemadoc );
			dp.setValidationMode( XMLConstants.SCHEMA_VALIDATION );
			dp.setPreserveWhitespace(true);

			return new XMLValidator(sUrlXSD, dp);
		}
		catch (MalformedURLException urle)
		{
			throw new CRuntimeException("Invalid XSD url: " + sUrlXSD, urle);
		}
		catch (XSDException xsde)
		{
			throw new CRuntimeException("Invalid XSD schema: " + sUrlXSD, xsde,
				new CProperties().setProperty("xsdUrl", sUrlXSD));
		}
		catch (Exception ex)
		{
			throw new CRuntimeException("Invalid XSD schema: " + sUrlXSD, ex,
				new CProperties().setProperty("xsdUrl", sUrlXSD));
		}
	}

}