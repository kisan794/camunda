/*
 * @(#)$RCSfile: CFastXMLComposer.java,v $ $Revision: 1.12 $ $Date: 2014/11/22 08:16:40 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/CFastXMLComposer.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev			2006-03-31	created
 *	A.Solntsev			2006-04-04	Added method addProperties()
 *	S.Prokopov			2007-10-22	added constructor with indent
 *	M.Abdulganejev	2008-03-12	Removed currently opened tag check in openTag()
 *	M.Suhhoruki			2008-03-19	Encode &, <, > char in text. CDATA content is not encoded.
 *	M.Abdulganejev	2008-03-26	Added addText(String sText, boolean doEncode)
 *	M.Suhhoruki			2008-03-19	added addProperties(CProperties, String, String, String)
 *	A.Solntsev			2008-11-14	Moved main-method to a unit test
 *	M.Abdulganejev	2009-02-16	StringBuffer changed to StringBuilder to improve performance
 *	E.Shatohhin			2009-02-18	Added UTF8 header & made public
 *	E.Shatohhin			2009-02-21	Attribute data is now encoded
 *	A.Solntsev			2009-12-09	Removed method finalize()
 *	S.Dubrov				2012-07-23	added encodeAttribute method to encode ", ', <, >, & chars in attribute values
 *	V.Hahhulin			2014-11-01	Bugfix: generated XML starts with empty line, if provided header was empty
 */
package hireright.sdk.xml.utils;

import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

import java.util.HashSet;
import java.util.Set;

/**
 * Utility class for fast composing XML using only StringBuffer.
 * So it can only append any values to the internal StringBuffer.
 * 
 * See main-method and unit tests for examples of usage.
 * 
 * NB! It's recommended to use XML Injector instead!
 * Use this class ONLY if you extremely need speed.
 * 
 * @author Andrei Solntsev
 * @version $Revision: 1.12 $, $Date: 2014/11/22 08:16:40 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/CFastXMLComposer.java,v $
 */
public class CFastXMLComposer 
{
	protected static final String CLASS_VERSION = "$Revision: 1.12 $ $Author: cvsroot $";
	
	/*
	 * TODO	 Add the following functionality:
	 * 1. Estimate XMl size in constructor (used for StringBuffer initialization)
	 */
	
	public static final String STANDARD_XML_HEADER = "<?xml version=\"1.0\"?>";
	public static final String STANDARD_XML_HEADER_UTF8 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	
	private static final String LEFT_BRACE = "<";
	private static final String RIGHT_BRACE = ">";
	private static final String SPACE = " ";
	private String CR = "\n";
	
	private static final int MAX_INDENT_LEVEL = 99;
	private static final String[] INDENT_SPACE = new String[1+MAX_INDENT_LEVEL];
	private static final String[] INDENT_TAB = new String[1+MAX_INDENT_LEVEL];

	public static final int INDENT_TYPE_NONE = 0;
	public static final int INDENT_TYPE_SPACE = 1;
	public static final int INDENT_TYPE_TAB = 2;
	
	static
	{
		INDENT_SPACE[0] = "";
		INDENT_TAB[0] = "";
		
		for (int i=1; i<= MAX_INDENT_LEVEL; i++)
		{
			INDENT_SPACE[i] = INDENT_SPACE[i-1] + "  ";
			INDENT_TAB[i] = INDENT_TAB[i-1] + "\t";
		}
	}
	
	private StringBuilder m_sbXML;
	private int m_nIndentType;
	private int m_nIndentLevel = 0;
	
	private String m_sCurrentlyOpenedTag = null;
	private Set<String> m_currentTagAttributes = new HashSet<String>();
	
	public CFastXMLComposer()
	{
		this(STANDARD_XML_HEADER);
	}
	
	public CFastXMLComposer(String sXmlHeader)
	{
		this(sXmlHeader, INDENT_TYPE_SPACE);
	}
	
	/**
	 * Constructor
	 * <p>
	 * @param sXmlHeader		XML header
	 * @param nIndentType		indent type
	 */
	public CFastXMLComposer(String sXmlHeader, int nIndentType)
	{
		m_nIndentType = nIndentType;

		if (m_nIndentType == INDENT_TYPE_NONE)
		{
			CR = "";
		}

		m_sbXML = new StringBuilder(sXmlHeader).append(CR);
	}
	
	/**
	 * Constructor with indent and without XML header 
	 * <p>
	 * @param nIndentType	indent type
	 */
	public CFastXMLComposer(int nIndentType)
	{
		this("", nIndentType);
	}

	private String getIndent(int i)
	{
		int width = i;
		if (width >= MAX_INDENT_LEVEL)
			width = MAX_INDENT_LEVEL;
		
		switch (m_nIndentType)
		{
			case INDENT_TYPE_SPACE:
				return INDENT_SPACE[width];
				
			case INDENT_TYPE_TAB:
				return INDENT_TAB[width];
			
			default:
				return "";
		}
	}
	
	public CFastXMLComposer startTag(String sTagName)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel++))
			.append(LEFT_BRACE).append(sTagName).append(RIGHT_BRACE)
			.append(CR);
		return this;
	}

	public CFastXMLComposer startTag(String sTagName, String sAttribName, String sAttribValue)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel++))
			.append(LEFT_BRACE).append(sTagName)
			.append(SPACE).append(sAttribName)
			.append("=\"").append( encode(sAttribValue) ).append("\"")
			.append(RIGHT_BRACE)
			.append(CR);
		return this;
	}
	
	public CFastXMLComposer startTag(String sTagName, String sAttribName1, String sAttribValue1
			, String sAttribName2, String sAttribValue2)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel++))
			.append(LEFT_BRACE).append(sTagName)
			.append(SPACE).append(sAttribName1)
			.append("=\"").append( encode(sAttribValue1) ).append("\"")
			.append(SPACE).append(sAttribName2)
			.append("=\"").append( encode(sAttribValue2) ).append("\"")
			.append(RIGHT_BRACE)
			.append(CR);
		return this;
	}
	
	public CFastXMLComposer startTag(String sTagName, String sAttribName1, String sAttribValue1,
			String sAttribName2, String sAttribValue2,
			String sAttribName3, String sAttribValue3)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel++))
			.append(LEFT_BRACE).append(sTagName)
			.append(SPACE).append(sAttribName1)
			.append("=\"").append( encode(sAttribValue1) ).append("\"")
			.append(SPACE).append(sAttribName2)
			.append("=\"").append( encode(sAttribValue2) ).append("\"")
			.append(SPACE).append(sAttribName3)
			.append("=\"").append( encode(sAttribValue3) ).append("\"")
			.append(RIGHT_BRACE)
			.append(CR);
		return this;
	}
	
	public CFastXMLComposer startTag(String sTagName, String sAttribName1, String sAttribValue1,
			String sAttribName2, String sAttribValue2,
			String sAttribName3, String sAttribValue3,
			String sAttribName4, String sAttribValue4)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel++))
			.append(LEFT_BRACE).append(sTagName)
			.append(SPACE).append(sAttribName1)
			.append("=\"").append( encode(sAttribValue1) ).append("\"")
			.append(SPACE).append(sAttribName2)
			.append("=\"").append( encode(sAttribValue2) ).append("\"")
			.append(SPACE).append(sAttribName3)
			.append("=\"").append( encode(sAttribValue3) ).append("\"")
			.append(SPACE).append(sAttribName4)
			.append("=\"").append( encode(sAttribValue4) ).append("\"")
			.append(RIGHT_BRACE)
			.append(CR);
		return this;
	}
	
	public CFastXMLComposer openTag(String sTagName)
	{
		/*if (m_sCurrentlyOpenedTag != null)
			throw new IllegalStateException("Before opening tag " + sTagName +   
					" please close currently opened tag " + m_sCurrentlyOpenedTag);
		*/
		m_sCurrentlyOpenedTag = sTagName;
		
		m_sbXML
			.append(getIndent(m_nIndentLevel++))
			.append(LEFT_BRACE).append(sTagName);
		
		return this;
	}
	
	public CFastXMLComposer closeTag(String sTagName)
	{
		// Check currently opened tag name
		if (m_sCurrentlyOpenedTag == null)
			throw new IllegalStateException("Cannot close tag " + sTagName + " since it's not opened.");
		
		if (!m_sCurrentlyOpenedTag.equals(sTagName))
			throw new IllegalStateException("Cannot close tag " + sTagName + 
					" since another tag is currently opened: " + m_sCurrentlyOpenedTag);
		
		m_sCurrentlyOpenedTag = null;
		m_currentTagAttributes.clear();
		
		m_sbXML
			.append(RIGHT_BRACE)
			.append(CR);
		
		return this;
	}
	
	public CFastXMLComposer addAttribute(String sAttribName, String sAttribValue)
	{
		if (m_currentTagAttributes.contains(sAttribName))
			throw new IllegalStateException("Cannot add attribute " + sAttribName + " multiple times");
		
		m_currentTagAttributes.add(sAttribName);
		
		m_sbXML.append(SPACE).append(sAttribName)
			.append("=\"").append( encode(sAttribValue) ).append("\"");
		
		return this;
	}
	
	public CFastXMLComposer addAttribute(String sAttribName, String sAttribValue, boolean encode)
	{
		if (m_currentTagAttributes.contains(sAttribName))
			throw new IllegalStateException("Cannot add attribute " + sAttribName + " multiple times");

		m_currentTagAttributes.add(sAttribName);

		m_sbXML.append(SPACE).append(sAttribName).append("=\"");
		m_sbXML.append(encode ? encodeAttribute(sAttribValue) : sAttribValue);
		m_sbXML.append("\"");

		return this;
	}

	public CFastXMLComposer addText(String sText)
	{
		m_sbXML.append(encode(CStringUtils.trim(sText)));
		return this;
	}
	
		public CFastXMLComposer addText(String sText, boolean doEncode)
	{
		m_sbXML.append((doEncode) ? encode(CStringUtils.trim(sText)) : CStringUtils.trim(sText));
		return this;
	}
		
	public CFastXMLComposer endTag(String sTagName)
	{
		m_sbXML
			.append(getIndent(--m_nIndentLevel))
			.append(LEFT_BRACE).append("/").append(sTagName).append(RIGHT_BRACE)
			.append(CR);
		return this;
	}
	
	public CFastXMLComposer addTag(String sTagName)
	{
		return addTag(sTagName, null);
	}


	public CFastXMLComposer addTag(String sTagName, String sText)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel))
			.append(LEFT_BRACE).append(sTagName).append(RIGHT_BRACE)
			.append(encode(CStringUtils.trim(sText)))
			.append(LEFT_BRACE).append("/").append(sTagName).append(RIGHT_BRACE)
			.append(CR);
		return this;
	}
	
	public CFastXMLComposer addCDataTag(String sTagName, String sText)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel))
			.append(LEFT_BRACE).append(sTagName).append(RIGHT_BRACE)
			.append("<![CDATA[")
			.append(sText)
			.append("]]>")
			.append(LEFT_BRACE).append("/").append(sTagName).append(RIGHT_BRACE)
			.append(CR);
		return this;
	}
	
	public CFastXMLComposer addTag(String sTagName, String sAttribName, String sAttribValue, String sText)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel))
			.append(LEFT_BRACE).append(sTagName)
			.append(SPACE).append(sAttribName)
			.append("=\"").append( encode(sAttribValue) ).append("\"")
			.append(RIGHT_BRACE)
			.append(encode(CStringUtils.trim(sText)))
			.append(LEFT_BRACE).append("/").append(sTagName).append(RIGHT_BRACE)
			.append(CR);
		return this;
	}
	
	public CFastXMLComposer addTag(String sTagName, String sAttribName1, String sAttribValue1, 
			String sAttribName2, String sAttribValue2, String sText)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel))
			.append(LEFT_BRACE).append(sTagName)
			.append(SPACE).append(sAttribName1)
			.append("=\"").append( encode(sAttribValue1) ).append("\"")
			.append(SPACE).append(sAttribName2)
			.append("=\"").append( encode(sAttribValue2) ).append("\"")
			.append(RIGHT_BRACE)
			.append(encode(CStringUtils.trim(sText)))
			.append(LEFT_BRACE).append("/").append(sTagName).append(RIGHT_BRACE)
			.append(CR);
		return this;
	}
	
	public CFastXMLComposer addTag(String sTagName, String sAttribName1, String sAttribValue1, 
			String sAttribName2, String sAttribValue2, 
			String sAttribName3, String sAttribValue3, String sText)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel))
			.append(LEFT_BRACE).append(sTagName)
			.append(SPACE).append(sAttribName1)
			.append("=\"").append( encode(sAttribValue1) ).append("\"")
			.append(SPACE).append(sAttribName2)
			.append("=\"").append( encode(sAttribValue2) ).append("\"")
			.append(SPACE).append(sAttribName3)
			.append("=\"").append( encode(sAttribValue3) ).append("\"")
			.append(RIGHT_BRACE)
			.append(encode(CStringUtils.trim(sText)))
			.append(LEFT_BRACE).append("/").append(sTagName).append(RIGHT_BRACE)
			.append(CR);
		return this;
	}
	
	public CFastXMLComposer addTag(String sTagName, String sAttribName1, String sAttribValue1, 
			String sAttribName2, String sAttribValue2, 
			String sAttribName3, String sAttribValue3, 
			String sAttribName4, String sAttribValue4, String sText)
	{
		m_sbXML
			.append(getIndent(m_nIndentLevel))
			.append(LEFT_BRACE).append(sTagName)
			.append(SPACE).append(sAttribName1)
			.append("=\"").append( encode(sAttribValue1) ).append("\"")
			.append(SPACE).append(sAttribName2)
			.append("=\"").append( encode(sAttribValue2) ).append("\"")
			.append(SPACE).append(sAttribName3)
			.append("=\"").append( encode(sAttribValue3) ).append("\"")
			.append(SPACE).append(sAttribName4)
			.append("=\"").append( encode(sAttribValue4) ).append("\"")
			.append(RIGHT_BRACE)
			.append(encode(CStringUtils.trim(sText)))
			.append(LEFT_BRACE).append("/").append(sTagName).append(RIGHT_BRACE)
			.append(CR);
		return this;
	}

	public CFastXMLComposer addProperties(CProperties properties)
	{
		return addProperties(properties, "Properties", "Property", "name");
	}

	public CFastXMLComposer addProperties(CProperties properties, String sPropertiesTagName,
			String sPropertyTagName, String sNameAttributeName)
	{
		startTag(sPropertiesTagName);
		
		for (String sPropertyName : properties.keys())
		{
			addTag(sPropertyTagName, sNameAttributeName, sPropertyName, properties.getProperty(sPropertyName));
		}

		endTag(sPropertiesTagName);
		
		return this;
	}

	@Override
	public String toString()
	{
		return m_sbXML.toString();
	}

	public static String encode(String str)
	{
		String sData = CStringUtils.nvl(str).replaceAll("&(?!amp;)", "&amp;");
		sData = sData.replaceAll("<", "&lt;");
		sData = sData.replaceAll(">", "&gt;");
		return sData;
	}

	public static String encodeAttribute(String str)
	{
		char[] chars = str.toCharArray();
		StringBuilder sb = new StringBuilder((int) (str.length() * 1.5));
		for (char c : chars)
		{
			switch (c)
			{
				case '"':
					sb.append("&quot;");
					break;
				case '&':
					sb.append("&amp;");
					break;
				case '\'':
					sb.append("&apos;");
					break;
				case '<':
					sb.append("&lt;");
					break;
				case '>':
					sb.append("&gt;");
					break;
				
				default:
					sb.append(c);
			}
		}
		return sb.toString();
	}

	public static CFastXMLComposer createNonIndentedUTF8Header()
	{
		return new CFastXMLComposer( STANDARD_XML_HEADER_UTF8, INDENT_TYPE_NONE );
	}
}
