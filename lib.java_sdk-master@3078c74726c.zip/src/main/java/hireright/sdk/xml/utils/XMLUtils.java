/*
 * @(#)$RCSfile: XMLUtils.java,v $ $Revision: 1.6 $ $Date: 2007/09/14 09:05:22 $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2001-11-14	S.Ignatov	created
 *  2006-11-02  A.Solntsev  implements Serializable
 */
package hireright.sdk.xml.utils;

import java.io.Serializable;

import hireright.sdk.xml.parser.TreeNode;
import hireright.sdk.xml.parser.XMLTreeNode;

/**
 * Some functions for XMLTree Nodes and Attribute Nodes data manipulations.
 * 
 * @author Ignatov Sergei
 */
public class XMLUtils implements Serializable
{
	/**
	 * Return value of XMLTreeNode or Default if node(value) not exsists.
	 *
	 */
	public static String nodeValue(TreeNode node)
	{
		return nodeValue(node, null);
	}

	public static String nodeValue(TreeNode node, String szDefault)
	{
		if(node == null)
			return szDefault;
		
		String szRetValue = (String) node.getData();
		
		if (szRetValue == null)
			return szDefault;
		
		return szRetValue;
	}
	
	/**
	 * Return count of existance of node(Attribute or Node) with given Path and value. 
	 *
	 */
	public static int nodeChildsCount(XMLTreeNode nodeRoot, String sPath, int nValue)
	{
		int nBracePos = sPath.indexOf('{');
		String sNodeTag = sPath;
		String sNodeAttribute = "";
		int nResult = 0;
		
		if(nBracePos != -1)
		{
			sNodeTag = sPath.substring(0, nBracePos);
			sNodeAttribute = sPath.substring(nBracePos + 1, sPath.length() - 1);
		}
		
		int counter = 0;
		XMLTreeNode childNode = null;
		while((childNode = nodeRoot.getChildNodeByTag(sNodeTag, ++counter)) != null)
		{
			String szValue = null;
			try
			{
				if(nBracePos != -1)
					szValue = childNode.getAttribText(sNodeAttribute);
				else
					szValue = (String) childNode.getData();
				
				if((new Integer(szValue)).intValue() == nValue)
				{
					nResult++;
				}
			}
			catch(Exception e)
			{
			}
		}
		
		return nResult;
		
	}		
	
	/**
	 * Replace strings &lt;, &gt;, &amp;, &apos;, &quot; to <, >, &, ', " chars. 
	 *
	 */
	public static String encodeTextData(String sValue)
	{
		if(sValue == null)
			return null;
			
		String sOutput = "";
		String sBuffer = "";
		boolean waitForBuffer = false;
		char c;

		for(int nCounter = 0; nCounter < sValue.length(); nCounter++)
		{
			c = sValue.charAt(nCounter);
			switch(c)
			{
				case '&':
					waitForBuffer = true;
				default:
					if(waitForBuffer)
						sBuffer = sBuffer + c;
					else
						sOutput = sOutput + c;
					break;
			}
			if(waitForBuffer)
			{
				if(waitForBuffer && sBuffer.compareTo("&lt;") == 0)
				{
					sOutput = sOutput + "<";
					sBuffer = "";
					waitForBuffer = false;
				}
				if(waitForBuffer && sBuffer.compareTo("&gt;") == 0)
				{
					sOutput = sOutput + ">";
					sBuffer = "";
					waitForBuffer = false;
				}
				if(waitForBuffer && sBuffer.compareTo("&amp;") == 0)
				{
					sOutput = sOutput + "&";
					sBuffer = "";
					waitForBuffer = false;
				}
				if(waitForBuffer && sBuffer.compareTo("&apos;") == 0)
				{
					sOutput = sOutput + "'";
					sBuffer = "";
					waitForBuffer = false;
				}
				if(waitForBuffer && sBuffer.compareTo("&quot;") == 0)
				{
					sOutput = sOutput + "\"";
					sBuffer = "";
					waitForBuffer = false;
				}
				if(waitForBuffer && sBuffer.length() > 5)
				{
					sOutput = sOutput + sBuffer;
					sBuffer = "";
					waitForBuffer = false;
				}
			}
		}
		if(sBuffer.length() > 0)
			sOutput = sOutput + sBuffer;
		return sOutput;
	}
	
	/**
	 * Replace <, >, &, ', " chars to &lt;, &gt;, &amp;, &apos;, &quot; strings. 
	 *
	 */
	public static String decodeTextData(String sValue)
	{
		if(sValue == null)
			return null;
			
		String sOutput = "";
		char c;
		
		for(int nCounter = 0; nCounter < sValue.length(); nCounter++)
		{
			c = sValue.charAt(nCounter);
			switch(c)
			{
				case '<':
					sOutput = sOutput + "&lt;";
					break;
				case '>':
					sOutput = sOutput + "&gt;";
					break;
				case '&':
					sOutput = sOutput + "&amp;";
					break;
				case '\'':
					sOutput = sOutput + "&apos;";
					break;
				case '"':
					sOutput = sOutput + "&quot;";
					break;
				default:
					sOutput = sOutput + c;
					break;
			}
		}
		
		return sOutput;
	}
	
	/**
	 * Built list of nodes, grouped by name and index(of same name),
	 * based on parameter nodes childs.
	 */
	public static XMLTreeNode normaliseList(XMLTreeNode node)
	{
		// top node for results
		XMLTreeNode resultNode = new XMLTreeNode();
		
		// result nodes exists child.
		XMLTreeNode nodeLikeThis = null;
		
		// cicle variable, for childs of given node.
		XMLTreeNode childNode = (XMLTreeNode) node.firstChildNode();
		while(childNode != null)
		{
			if((nodeLikeThis = resultNode.getChildNodeLike(childNode)) != null)
			{ //use existing node, add node for storing data
				XMLTreeNode nodeForStoring = new XMLTreeNode();
				nodeForStoring.setXMLTag(childNode.getXMLTag());
				nodeForStoring.setData(childNode);
				nodeLikeThis.addChildNode(nodeForStoring);
			}
			else
			{ //create node, node like this
				nodeLikeThis = new XMLTreeNode();
				nodeLikeThis.setXMLTag(childNode.getXMLTag());
				nodeLikeThis.setXMLNamespace(childNode.getXMLNamespace());
				
				//use created node, add node for storing data
				XMLTreeNode nodeForStoring = new XMLTreeNode();
				nodeForStoring.setXMLTag(childNode.getXMLTag());
				nodeForStoring.setData(childNode);
				
				nodeLikeThis.addChildNode(nodeForStoring);
				
				resultNode.addChildNode(nodeLikeThis);
			}
			childNode = (XMLTreeNode) childNode.getNext();
		}
		
		return resultNode;
	}
	
}