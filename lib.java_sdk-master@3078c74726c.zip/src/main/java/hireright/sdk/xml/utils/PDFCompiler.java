/*
 * @(#)$RCSfile: PDFCompiler.java,v $ $Revision: 1.14 $ $Date: 2008/03/26 15:52:15 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/utils/PDFCompiler.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	200x-aa-bb	A.Keks			created
 *	2004-01-20	A.Solntsev		Fixed old bug with reading from Input Stream.
 *														Code is formatted according to last standards.
 *	2004-12-14	A.Solntsev		Added error parameters.
 *	2005-09-23	S.Kocherovets	Added 'pdf_convert_0_20_5' supporting.
 *	2006-02-17	A.Solntsev		Removed writing useless message "PDF generating time" to CFileLog.
 *	2006-04-24	A.Solntsev		Added "out.close();" in method makePost().
 *	2006-05-04	A.Solntsev		Moved to package hireright.sdk.transform
 *	2008-03-23	A.Solntsev		Fixed exception handling: throw exception instead of logging 
 */
package hireright.sdk.xml.utils;

import hireright.sdk.html.parser.XMLObjectException;
import hireright.sdk.transform.HTMLCompiler;
import hireright.sdk.transform.PDFException;
import hireright.sdk.transform.XsltException;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;

import java.net.URL;

/**
 *	Class description goes here.
 *
 *  @author		Anton Keks
 *  @deprecated Moved to package hireright.sdk.transform; <br/>
 *  					Use class hireright.sdk.transform.PDFCompiler
 */
public class PDFCompiler
{
	protected static final String CLASS_VERSION = "$Revision: 1.14 $ $Author: asolntsev $";
	
	public static byte[] convertXML(String szXML, URL urlXSL) throws XMLObjectException
	{
		return convertXML(szXML, urlXSL.toString());
	}

	/**
	 * 
	 * @deprecated Use class hireright.sdk.transform.PDFCompiler
	 * @param szXML
	 * @param szXSLURL
	 * @return
	 * @throws CRuntimeException wrapping XsltException
	 */
	public static byte[] convertXML(String szXML, String szXSLURL) 
	{
		try
		{
			return convertXML(szXML, szXSLURL, false);
		}
		catch (XsltException e)
		{
			throw new CRuntimeException(e, e.getProperties(), e.getData());
		}
		catch (PDFException e)
		{
			throw new CRuntimeException(e, e.getProperties(), e.getData());
		}
	}

	public static byte[] convertXML(String szXML, String szXSLURL, boolean isFOP5Used) throws XsltException, PDFException
	{
		final String szFO = HTMLCompiler.getHTMLDocumentFromStringAsString(szXML, szXSLURL);
		if (szFO == null || szFO.trim().length() == 0)
		{
			CProperties params = new CProperties().setProperty("szXSLURL", szXSLURL);
			throw new XsltException("FO generating failed", params, szXML);
		}
		
		return hireright.sdk.transform.PDFCompiler.convertFO2PDF(szFO, isFOP5Used);
	}
}
