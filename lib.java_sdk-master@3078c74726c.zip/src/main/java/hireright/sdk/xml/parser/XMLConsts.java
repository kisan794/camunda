package hireright.sdk.xml.parser;

/**
 *last changed 2002/01/08
 */
public class XMLConsts
{
	// nodes types. number values as order in xml structure.
	public static final int TYPE_PROCESSING_INSTRUCTION = 100;   // node like <?xml version="1.0"?>
	public static final int TYPE_COMMENTS = 110;		     // node like <!-- comments -->
	public static final int TYPE_DOC_TYPE_DEFINITION = 120;	     // node like <!DOCTYPE >
	public static final int TYPE_CDATA = 130;		     // node like <![CDATA[ c data ]]>
	public static final int TYPE_TEXT = 140;	     	     // node like Text
	public static final int TYPE_NODE = 150;	     	     // node like <Node>
	public static final int TYPE_UNKNW = 160;	     	     // unknown type node
	public static final int TYPE_NODE_CLOSING = 170;	     // node like </Node>
	public static final int TYPE_ATTRIBUTE = 180;
	public static final int TYPE_ROOT = 190;
	
	public static final int PARSE_FAILED = 200;
	
	public static final int MIN_PROCESS_INSTR_LENGTH = 6;
	public static final int MIN_COMMENT_LENGTH = 8;
	public static final int MIN_CDATA_LENGTH = 13;
	public static final int MIN_DTD_LENGTH = 11;
	public static final int MIN_NODE_LENGTH = 3;
	
	public static final int MIN_PREDETERM_LENGTH = MIN_NODE_LENGTH;
	
	public static final int SECT_TAG_NAME = 0;
	public static final int SECT_TAG_ID = 1;
	public static final int SECT_TAG_VALUE = 2;
	public static final int SECT_TAG_VALUE_ID = 3;
	public static final int SECT_ATTRIBUTE = 4;
	public static final int SECT_ATTRIBUTE_VALUE = 5;
	public static final int SECT_FAILED = -1;
	public static final int SECT_PARSED = -2;
	public static final int SECT_INPROGRESS = -3;
	
	public static final int NODE_BYPATH_NOT_FOUND = 0;
	public static final int NODE_BYPATH_FOUND = 1;
	
	public static final int ALL_LEVELS = -1;
	
	public static boolean MAKE_NICE_OUTPUT = true;
	
}