/*
 * @(#)$RCSfile: TreeNode.java,v $ $Revision: 1.8 $ $Date: 2009/07/10 12:27:28 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/parser/TreeNode.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2001-11-14	S.Ignatov	created
 *  2004-11-18  A.Solntsev  Added logging to TraceLog.
 *  2006-11-02  A.Solntsev  implements Serializable
 */
package hireright.sdk.xml.parser;

import java.io.Serializable;

public class TreeNode implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: asolntsev $";
	
	protected Serializable m_objData = null;
	protected int m_nTag = 0;
	protected TreeNode m_objPrevious = null;
	protected TreeNode m_objNext = null;
	protected TreeNode m_objParent = null;
	protected int m_nHashCode = this.hashCode();

	public TreeNode lastChildNode()
	{
		TreeNode tempNode = null;
		
		try
		{
			tempNode = (TreeNode) m_objData;
		
			while(tempNode != null && tempNode.getNext() != null)
				tempNode = tempNode.getNext();
		}
		catch(Exception e)
		{
		}
		
		return tempNode;
	}
	
	public TreeNode firstChildNode()
	{
		TreeNode tempNode = null;
		
		try
		{
			tempNode = (TreeNode) m_objData;
		
			while(tempNode != null && tempNode.getPrevious() != null)
				tempNode = tempNode.getPrevious();
		}
		catch(Exception e)
		{
		}
		
		return tempNode;
	}	
	
	/**
	 * WARNING this adds new node, if You add node from other tree it will make timebomb
	 */
	public int addChildNode(TreeNode node)
	{
		int nResult = 0;
		node.setPrevious(null);
		node.setNext(null);
		node.setParent(this);
		
		if (m_objData == null)
		{
			m_objData = node;
			return nResult;
		}
		
		TreeNode tempNode = lastChildNode();

		node.setPrevious(tempNode);
		tempNode.setNext(node);
		
		return nResult;
	}
	
	public TreeNode getParent()
	{
		return m_objParent;
	}

	public void setParent(TreeNode propValue)
	{
		m_objParent = propValue;
	}	
	
	public Serializable getData()
	{
		return m_objData;
	}

	public void setData(Serializable propValue)
	{
		m_objData = propValue;
	}
	
	public int getTag()
	{
		return m_nTag;
	}

	public void setTag(int propValue)
	{
		m_nTag = propValue;
	}
	
	public TreeNode getPrevious()
	{
		if (m_objPrevious == this)
			return null;
		return m_objPrevious;
	}

	public void setPrevious(TreeNode propValue)
	{
		m_objPrevious = propValue;
	}

	public TreeNode getNext()
	{
		if (m_objNext == this)
			return null;		
		return m_objNext;
	}

	public void setNext(TreeNode propValue)
	{
		m_objNext = propValue;
	}
	
	protected void copyMembersData(TreeNode node)
	{
		node.setTag(this.getTag());
		node.setData(this.getData());
		node.setNext(this.getNext());
		node.setPrevious(this.getPrevious());
		node.setParent(this.getParent());
		node.setHashCode(this.getHashCode());
	}	

	@Override
	public Object clone()
	{
		TreeNode newNode = new TreeNode();
		copyMembersData(newNode);
		return newNode;
	}

	/**
	 * FIXME Implement this method
	 */
	@Override
	public String toString()
	{
		return String.valueOf( m_objData );
	}
	
	public int getHashCode()
	{
		return m_nHashCode;
	}
	
	public void setHashCode(int nHashCode)
	{
		m_nHashCode = nHashCode;
	}	
	
	public TreeNode getChildNodeByHashCode(int nHashCode, int nNodeIndex)
	{
		TreeNode tempNode = (TreeNode) getData();
		while (tempNode != null && tempNode.getPrevious() != null)
			tempNode = tempNode.getPrevious();
			
		int counter = 1;
		while(tempNode != null)
		{
			if(tempNode.getHashCode() == nHashCode)
			{
				if(nNodeIndex == counter)
					return tempNode;
				counter++;
			}
			tempNode = tempNode.getNext();
		}					
		
		return null;		
	}
	
	/**
	 * Remove node between two other nodes.
	 *
	 */
	public void removeChild(TreeNode remNode)
	{
		
		if(remNode == null)
			return;
			
		remNode.setData(null);
			
		TreeNode prevNode = remNode.getPrevious();
		TreeNode nextNode = remNode.getNext();
		
		if(prevNode == null && nextNode == null)
		{
			this.setData(null);
			return;
		}

		if(prevNode != null && nextNode == null)
		{
			remNode.setPrevious(null);
			prevNode.setNext(null);
			return;
		}
		
		if(prevNode == null && nextNode != null)
		{
			nextNode.setPrevious(null);
			remNode.setNext(null);
			this.setData(nextNode);
			return;
		}
		
		if(prevNode != null && nextNode != null)
		{
			remNode.setNext(null);
			remNode.setPrevious(null);
			nextNode.setPrevious(prevNode);
			prevNode.setNext(nextNode);
		}		
	}
}
