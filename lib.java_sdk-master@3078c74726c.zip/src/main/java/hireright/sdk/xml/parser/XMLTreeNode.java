/*
 * @(#)$RCSfile: XMLTreeNode.java,v $ $Revision: 1.9 $ $Date: 2008/11/21 11:30:12 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/parser/XMLTreeNode.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2001-11-14	S.Ignatov	created
 *  2006-11-02  A.Solntsev  implements Serializable
 *  2008-02-15	A.Solntsev	Added method parseValidNode() which throws RuntimeException
 *  2008-02-15	A.Solntsev	Method dublicate() does not throw CloneNotSupportedException
 *  2008-03-10	A.Solntsev	Added method getChildNodeTextByTag(String sTagName)
 *  2008-11-13	A.Solntsev	Added checks for infinite loop
 */
package hireright.sdk.xml.parser;

import java.io.Serializable;

import hireright.sdk.util.CRuntimeException;
import hireright.sdk.xml.utils.XMLUtils;

/**
 * XMLTreeNode class is the primary datatype for XMLObject data model. It represents 
 * a single node of any type, except attribute node, in the document tree.
 *
 * @author Sergei Ignatov
 * @version $Revision: 1.9 $ $Date: 2008/11/21 11:30:12 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/parser/XMLTreeNode.java,v $
 */
public class XMLTreeNode extends TreeNode implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	///////////////////////////////////////////////////////////////////////////////
	//
	//  Members
	
	/**
	 * Namespace of xml tag name, as <namespace:prefix>.
	 */
	protected String m_szXMLNamespace = "";
	/**
	 * Prefix of xml tag name, as <namespace:prefix>.
	 */	
	protected String m_szXMLTag = "";
	/**
	 * java.util.LinkedList, contains attributes of this node.
	 */
	protected TreeNode m_attrList = new TreeNode();
	/**
	 * internal variable for parsing: strings data type parsed or not, like CDATA, comments.
	 */
	protected boolean m_boolMetaData = false;
	/**
	 * Node type: text, CDATA, normal node as described in XMLOpt.
	 */	
	protected int m_textMode = XMLOpt.TEXT_NONE;
	/**
	 *  internal variable for parsing: contains node data or childs or not.
	 */
	protected int m_taggedMode = XMLOpt.NODE_STANDALONE;
	/**
	 *  internal variable for parsing: buffer for accumulate chars.
	 */
	protected final static int SZBUFFER_SIZE = 128;
	protected StringBuffer m_szTempBuffer = new StringBuffer(SZBUFFER_SIZE);
	/**
	 * internal variable for parsing: current section of attribute, what is parsed;
	 */
	protected int m_nAttribSection = 0;
	/**
	 * internal variable for parsing: current attribute value ends - " or '
	 */
	protected char m_cAtrSymbol = '0';
	
	
	///////////////////////////////////////////////////////////////////////////////
	//
	//  Constructors
	
	/**
	 * Construct empty XMLTreeNode with null data, tag, etk.
	 *
	 */
	public XMLTreeNode()
	{
	}
	
	/**
	 * Construct XMLTreeNode and set its tag, namespase and attributes from given string.
	 * string look like "<xml_namespace:xml_tag attribute1="attr1" attribute2='attr1'>" or "some_text", 
	 * but not like "<xml_tag>some data</xml_tag>".
	 *
	 * @param string String to parse example: "<xml_namespace:xml_tag attribute1="attr1" attribute2='attr1'>".
	 */
	public XMLTreeNode(String string) throws XMLObjectException
	{
		parse(string);
	}
	
	public static XMLTreeNode parseValidNode(String string)
	{
		try
		{
			XMLTreeNode node = new XMLTreeNode();
			node.parse(string);
			return node;
		}
		catch (XMLObjectException e)
		{
			throw new CRuntimeException(e, null, string);
		}
	}
	
	
	///////////////////////////////////////////////////////////////////////////////
	//
	//  Methods
	
	/**
	 * Extract node tag values, attributes from given string into node data structures.
	 * 
	 * @param string String to parse example: "<xml_namespace:xml_tag attribute1="attr1" attribute2='attr1'>".
	 *
	 * @see XMLTreeNode#XMLTreeNode(String) constructor.
	 */
	public void parse(String string) throws XMLObjectException
	{
		int nLen = string.length();
		
		if(nLen == 0)
			throw new XMLObjectException("Null length node");
		
		if(string.charAt(0) == XMLOpt.TAG_SYMBOL_START && 
		   !(string.startsWith("<!")))
		{
			if(string.charAt(nLen - 1) != XMLOpt.TAG_SYMBOL_END)
				throw new XMLObjectException("Tag not closed " + string);
			
			m_textMode = XMLOpt.TEXT_NONE;
			parseTaggedNode(string);
		}
		else
			parseTextNode(string);
	}

	/**
	 * Parse procedure for nodes generated from "<XXXXXXX XXX="XXX">" strings
	 *
	 * @param string String to parse.
	 */
	protected void parseTaggedNode(String string) throws XMLObjectException
	{
		int nLen = string.length();
		if(nLen < 3)
			throw new XMLObjectException("Invalid node length " + string);
			
		m_taggedMode = XMLOpt.NODE_OPENED;
		
		char cPreLastChar = string.charAt(nLen - 2);
		switch(cPreLastChar)
		{
			case '?':
				if(nLen < 4)
					throw new XMLObjectException("Invalid node length " + string);
				nLen = 2;

				m_taggedMode = XMLOpt.NODE_STANDALONE;
				break;
			case '/':
				if(nLen < 4)
					throw new XMLObjectException("Invalid node length " + string);
				nLen = 2;
				m_taggedMode = XMLOpt.NODE_STANDALONE;
				break;
			default:
				nLen = 1;
				break;
		}
	
		m_textMode = XMLOpt.TEXT_NONE;
		m_boolMetaData = false;
		m_szTempBuffer = new StringBuffer(SZBUFFER_SIZE);
		m_nAttribSection = 0;
		
		boolean isTagNameSection = true;
				
		nLen = string.length() - nLen;
		for(int i = 1; i < nLen; i++)
		{
			char c = string.charAt(i);
			if(isTagNameSection)
			{
				isTagNameSection = collectTagNameSection(i, nLen, c);
			}
			else
			{
				collectTagAttributesSection(i, c);
			}
		}
		
		if(m_nAttribSection != 0)
			throw new XMLObjectException("Invalid node attributes " + string);
	}
	
	/**
	 * Parse procedure for tag name section of node string. Using m_szTempBuffer for accumulate chars.
	 *
	 * @param i position of current processing char.
	 * @param j total length of parsed string.
	 * @param c current processing char, at this position, i.
	 */
	protected boolean collectTagNameSection(int i, int j, char c) throws XMLObjectException
	{
		boolean boolResult = true;
		switch(c)
		{
			case 0xD:
			case 0xA:
			case 0x9:
			case ' ':
				if(i == 1)
					throw new XMLObjectException("Character '" + c + "' not allowed here " + m_szTempBuffer.toString());
				parseTagName(m_szTempBuffer.toString());
				m_szTempBuffer = new StringBuffer(SZBUFFER_SIZE);
				boolResult = false;
				break;
			case XMLOpt.METADATA_SYMBOL:
				if(i != 1)
					throw new XMLObjectException("Character '" + c + "' not allowed here " + m_szTempBuffer.toString());
				else
					m_boolMetaData = true;
				break;
			case XMLOpt.NAMESPACE_DIVIDER:
				if(i == 1)
					throw new XMLObjectException("Invalid namespace " + m_szTempBuffer.toString());
				m_szTempBuffer.append(c);
				break;
			case '/':
				if(i == 1)
				{
					m_taggedMode = XMLOpt.NODE_CLOSED;
					break;
				}
			default:
				m_szTempBuffer.append(c);
				break;
		}
		
		if( m_szTempBuffer.length() > 0 && (j - 1) == i)
		{
			parseTagName(m_szTempBuffer.toString());
			m_szTempBuffer = new StringBuffer(SZBUFFER_SIZE);
			boolResult = false;		
		}
		return boolResult;
	}
	
	/**
	 * Parse procedure for attributes section of node string.
	 *
	 */
	protected void collectTagAttributesSection(int i, char c) throws XMLObjectException
	{
		switch(c)
		{
			case 0xD:
			case 0xA:
			case 0x9:
			case ' ':
				switch(m_nAttribSection)
				{	
					case 1:
						m_nAttribSection = 2;
						break;
					case 5:
						m_szTempBuffer.append(c);
						break;
					default:
						break;
				}
				break;
			case '=':
				switch(m_nAttribSection)
				{	
					case 0:
						throw new XMLObjectException("Invalid symbol " + c + " " + m_szTempBuffer.toString());
					case 1:
					case 2:
						m_szTempBuffer.append(c);
						m_nAttribSection = 4;
						break;
					case 4:
						throw new XMLObjectException("Invalid symbol " + c + " " + m_szTempBuffer.toString());
					case 5:
						m_szTempBuffer.append(c);
						break;						
					default:
						break;
				}
				break;
			case '\'':
				if(m_cAtrSymbol == '0')
					m_cAtrSymbol = '\'';
			case '"':
				if(m_cAtrSymbol == '0')
					m_cAtrSymbol = '"';
				if((c == '\'' && m_cAtrSymbol == '\'') ||
					(c == '"' && m_cAtrSymbol == '"'))
				{
					switch(m_nAttribSection)
					{	
						case 0:
						case 1:
						case 2:
							throw new XMLObjectException("Invalid symbol " + c + " " + m_szTempBuffer.toString());
						case 4:
							m_szTempBuffer.append(c);
							m_nAttribSection = 5;
							break;
						case 5:
							m_szTempBuffer.append(c);
							parseTagAttribute(m_szTempBuffer.toString());
							m_szTempBuffer = new StringBuffer(SZBUFFER_SIZE);
							m_nAttribSection = 0;
							m_cAtrSymbol = '0';
							break;						
						default:
							break;
					}
					break;
				}
			default:
				switch(m_nAttribSection)
				{	
					case 0:
						m_nAttribSection = 1;
					case 1:
					case 5:
						m_szTempBuffer.append(c);
						break;
					case 2:
					case 4:
						throw new XMLObjectException("Invalid symbol " + c + " " + m_szTempBuffer.toString());
					default:
						break;
				}					
		}			
	}
	
	/**
	 * Parse procedure for tag name.
	 *
	 */
	protected void parseTagName(String string) throws XMLObjectException
	{
		if(string.charAt(string.length()-1) == XMLOpt.NAMESPACE_DIVIDER)
			throw new XMLObjectException("Empty node name " + string);
		
		int nPos = string.indexOf(XMLOpt.NAMESPACE_DIVIDER);
		if(nPos != -1)
		{
			setXMLNamespace(string.substring(0, nPos));
			setXMLTag(string.substring(nPos + 1));
			if(m_szXMLTag.indexOf(XMLOpt.NAMESPACE_DIVIDER) != -1)
				throw new XMLObjectException("Illegal symbol " + XMLOpt.NAMESPACE_DIVIDER + " in node name " + string);
		}
		else
		{
			setXMLNamespace("");
			setXMLTag(string);
		}
	}
	
	/**
	 * Parse procedure for attribute
	 *
	 */
	protected void parseTagAttribute(String string)
	{
		int nPos = string.indexOf('=');
		String szParamName = string.substring(0, nPos);
		String szParamValue = string.substring(nPos + 2, string.length() - 1);
		TreeNodeAttrib node = new TreeNodeAttrib();
		node.setName(szParamName);
		node.setData(XMLUtils.encodeTextData(szParamValue));
		m_attrList.addChildNode(node);
	}
	
	/**
	 * Parse procedure non <> elements
	 *
	 */
	protected void parseTextNode(String string) throws XMLObjectException
	{
		m_textMode = XMLOpt.TEXT_NORMAL;
		
		if(string.startsWith("<![CDATA["))
		{
			if(string.endsWith("]]>"))
			{
				m_textMode = XMLOpt.TEXT_CDATA;
				setData(new String(string.substring(9, string.length() - 3)));
				return;
			}
			else
				throw new XMLObjectException("Invalid CDATA section " + string);
		}
		
		if(string.startsWith("<!DOCTYPE "))
		{
			if(string.endsWith(">"))
			{
				m_textMode = XMLOpt.TEXT_DOCTYPE;
				setData(new String(string.substring(10, string.length() - 1)));
				return;
			}
			else
				throw new XMLObjectException("Invalid DOCTYPE section " + string);
		}		
		
		setData(new String(XMLUtils.encodeTextData(string)));
	}	
	
	/**
	 * Procedure for dublicating node structure
	 *
	 */
	protected void copyMembersData(XMLTreeNode node)
	{
		super.copyMembersData(node);
		node.setXMLNamespace(this.getXMLNamespace());
		node.setXMLTag(this.getXMLTag());
		node.setMetadata(m_boolMetaData);
		node.setTextMode(m_textMode);
		if(m_textMode != XMLOpt.TEXT_NONE)
			node.m_objData = (String) this.m_objData;
	}
	
	/**
	 * Mean what node contains CDATA, or some other non parsing data.
	 *
	 */
	public void setMetadata(boolean param)
	{
		m_boolMetaData = param;
	}
	
	/**
	 * Mode of node data: text, simple node or somth. else.
	 *
	 */
	public void setTextMode(int param)
	{
		m_textMode = param;
	}

	/**
	 * Return first attribute node from list.
	 *
	 */	
	public TreeNodeAttrib firstAttribNode()
	{
		TreeNodeAttrib tempAttrNode = (TreeNodeAttrib) m_attrList.getData();
		while(tempAttrNode != null && tempAttrNode.getPrevious() != null)
			tempAttrNode = (TreeNodeAttrib) tempAttrNode.getPrevious();		
		return tempAttrNode;
	}
	
	/**
	 * Procedure for cloning this node
	 *
	 */
	public Object clone() 
	{
		XMLTreeNode node = new XMLTreeNode();
		copyMembersData(node);

		TreeNodeAttrib tempAttrNode = firstAttribNode();
		
		node.m_attrList = new TreeNode();
		while(tempAttrNode != null)
		{
			node.m_attrList.addChildNode((TreeNode) tempAttrNode.clone());
			tempAttrNode = (TreeNodeAttrib) tempAttrNode.getNext();
		}					
		
		return node;
	}
	
	/**
	 * Procedure for cloning this node
	 *
	 */
	public XMLTreeNode dublicate() 
	{
		XMLTreeNode node = (XMLTreeNode) this.clone();
		
		Object nodeData = this.getData();

		if(nodeData != null && nodeData.getClass().getName().endsWith(".parser.XMLTreeNode"))
		{
			node.setData(null);				
			XMLTreeNode childNode = (XMLTreeNode) nodeData;
			while(childNode != null)
			{
				node.addChildNode(childNode.dublicate());
				childNode = (XMLTreeNode) childNode.getNext();
			}
		}
		
		return node;
	}	
	
	/**
	 * Remove child by path.
	 *
	 */
	public void removeChildNode(String szNodeTagValue)
	{
		removeChild(this.getChildNodeByPath(szNodeTagValue));
	}	
	
	/**
	 * Remove attribute with propValue name from this node attributes
	 *
	 */
	public void removeAttribNode(String propValue)
	{
		TreeNodeAttrib tempAttrNode = firstAttribNode();
		while(tempAttrNode != null)
		{
			if(tempAttrNode.getName().equals(propValue))
			{
				this.m_attrList.removeChild(tempAttrNode);
				return;
			}
			tempAttrNode = (TreeNodeAttrib) tempAttrNode.getNext();
		}							
	}
	
	/**
	 * Returns attribute with propValue name from this node attributes
	 *
	 */
	public TreeNodeAttrib getAttribNode(String propValue)
	{
		TreeNodeAttrib tempAttrNode = firstAttribNode();
			
		while(tempAttrNode != null)
		{
			if(tempAttrNode.getName().equals(propValue))
				return tempAttrNode;
			tempAttrNode = (TreeNodeAttrib) tempAttrNode.getNext();
		}					
		
		return null;
	}
	
	/**
	 * Returns nNodeIndex child node with propValue name from this node childs. 
	 * nNodeIndex values starts from 1. 
	 *
	 */
	public XMLTreeNode getChildNodeByTag(String propValue, int nNodeIndex)
	{
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();
			
		int counter = 1;
		while(tempNode != null)
		{
			if(tempNode.getXMLTag().equals(propValue) || propValue.length() == 0)
			{
				if(nNodeIndex == counter)
					return tempNode;
				counter++;
			}
			tempNode = (XMLTreeNode) tempNode.getNext();
		}
		
		return null;
	}	
	
	public XMLTreeNode getChildNodeLike(XMLTreeNode node)
	{
		if(node == null)
			return null;
			
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();
			
		while(tempNode != null)
		{
			if(tempNode.getXMLTag().equals(node.getXMLTag()) && 
				tempNode.getXMLNamespace().equals(node.getXMLNamespace()))
				return tempNode;
			tempNode = (XMLTreeNode) tempNode.getNext();
		}
		
		return null;
	}	
	
	/**
	 * Returns XMLNamespace of tag <xml_namespace:xml_tag_value>
	 *
	 */
	public String getXMLNamespace()
	{
		return m_szXMLNamespace;
	}

	/**
	 * Set XMLNamespace of tag <xml_namespace:xml_tag_value>
	 *
	 */
	public void setXMLNamespace(String propValue)
	{
		m_szXMLNamespace = propValue;
		if(m_szXMLNamespace == null)
			m_szXMLNamespace = "";
	}
	
	/**
	 *
	 */	
	public String getXMLTag()
	{
		return m_szXMLTag;
	}
	
	/**
	 *
	 */	
	public String getXMLTagBody()
	{
		return m_szXMLTag;
	}

	/**
	 *
	 */
	public void setXMLTag(String propValue)
	{
		m_szXMLTag = propValue;
		if(m_szXMLTag == null)
			m_szXMLTag = "";
	}
	
	/**
	 *
	 */	
	public int getNodeType()
	{
		return m_textMode;
	}
	
	/**
	 *
	 */	
	public int getTagMode()
	{	
		return m_taggedMode;
	}
	
	public boolean isMetaData()
	{
		return m_boolMetaData;
	}

	/**
	 * Returns text of xml stucture under this code.
	 *
	 */
	public String toString()
	{
		String szRResult = "";
		String szLResult = "";
		String szLResultF = "";
		
		switch(m_textMode) 
		{
			case XMLOpt.TEXT_NONE:
				szRResult += "" + XMLOpt.TAG_SYMBOL_END;
				szLResult = "" + XMLOpt.TAG_SYMBOL_START + szLResult;
				szLResultF = XMLOpt.TAG_SYMBOL_START + "/" + szLResultF;
				break;
			case XMLOpt.TEXT_NORMAL:
				return XMLUtils.decodeTextData((String) getData());
			case XMLOpt.TEXT_CDATA:
				return "<![CDATA[" + ((String) getData()) + "]]>";
			case XMLOpt.TEXT_DOCTYPE:
				return "<!DOCTYPE " + ((String) getData()) + ">";
			case XMLOpt.TEXT_PCDATA:
				return "<![PCDATA[" + ((String) getData()) + "]]>";
			default:
				break;
		}

		if(m_boolMetaData)
		{
			szRResult = "" + XMLOpt.METADATA_SYMBOL + szRResult;
			szLResult +=  "" + XMLOpt.METADATA_SYMBOL;
			szLResultF +=  "" + XMLOpt.METADATA_SYMBOL;
		}

		if(m_szXMLNamespace.length()>0)
		{
			szLResult += m_szXMLNamespace + XMLOpt.NAMESPACE_DIVIDER;
			szLResultF += m_szXMLNamespace + XMLOpt.NAMESPACE_DIVIDER;
		}

		if(m_szXMLTag.length()>0)
		{
			szLResult += m_szXMLTag;
			szLResultF += m_szXMLTag;
		}
		else
		{
			szRResult = "";
			szLResult = "";
			szLResultF = "";
		}

		// attributes
		TreeNodeAttrib tempAttrNode = firstAttribNode();
		while(tempAttrNode != null)
		{
			szLResult = szLResult + " " + tempAttrNode.toString();
			tempAttrNode = (TreeNodeAttrib) tempAttrNode.getNext();
		}

		Object data = getData();
		String szData = "";
		if(data!= null && data.getClass().getName().equals("java.lang.String"))
		{// text
			szData = (String) data;
		}
		else
		{// subnodes
			TreeNode tempNode = firstChildNode();
			while(tempNode != null)
			{
				szData += tempNode.toString();
				tempNode = tempNode.getNext();
			}
		}

		if(szData.length() != 0)
		{
			switch(m_textMode)
			{
				case 1:
					return szData;
				default:
					return szLResult + szRResult + szData + szLResultF + szRResult;
			}
		}

		if(m_boolMetaData)
			return szLResult + szRResult;

		return szLResult + " /" + szRResult;
	}

	/**
	 * Return first child node of this node with given name.
	 * @param sTagName
	 */
	public XMLTreeNode getChildNodeByTag(String sTagName)
	{
		return getChildNodeByTag(sTagName, 1);
	}
	
	public String getChildNodeTextByTag(String sTagName)
	{
		XMLTreeNode node = getChildNodeByTag(sTagName, 1);
		return (node == null) ? null : node.getText();
	}

	/**
	 * Return first node under this node tree with given name.
	 *
	 */
	public XMLTreeNode getChildNodeByTagEx(String propValue)
	{
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();

		while(tempNode != null)
		{
			if(tempNode.getXMLTag().equals(propValue))
			{
				return tempNode;
			}
			else
			{
				XMLTreeNode tempNodeCh = tempNode.getChildNodeByTagEx(propValue);
				if(tempNodeCh != null)
					return tempNodeCh;
			}
			tempNode = (XMLTreeNode) tempNode.getNext();
		}

		return null;
	}
	
	/**
	 * Return node under this node tree by Path.
	 *
	 * @param sPathValue path like "test/f1/f2" or "test/f1/f2[2]/f3d/f4{retain}" or even "test/f1/[1]"
	 *
	 */
	public TreeNode getChildNodeByPath(String sPathValue)
	{
		String sSearchPathPart = null;
		XMLTreeNode processedNode = this;
		
		try
		{		
			if(!sPathValue.endsWith("/"))
				sPathValue = sPathValue + "/";
			int nBkSlashPos = -1;
			
			while((nBkSlashPos = sPathValue.indexOf('/')) != -1)
			{
				sSearchPathPart = sPathValue.substring(0, nBkSlashPos);
				sPathValue = sPathValue.substring(nBkSlashPos + 1);
				String szTagName = sSearchPathPart;
				String szTagIndex = "";
				if(sSearchPathPart.indexOf('[') != -1)
				{
					szTagName = sSearchPathPart.substring(0, sSearchPathPart.indexOf('['));
					szTagIndex =  sSearchPathPart.substring(sSearchPathPart.indexOf('[') + 1, sSearchPathPart.length() - 1);
				}
				String szAttributeName = "";
				if(szTagIndex.indexOf('{') != -1)
				{
					szAttributeName =  szTagIndex.substring(szTagIndex.indexOf('{') + 1, szTagIndex.length() - 1);
					szTagIndex = szTagIndex.substring(0, szTagIndex.indexOf('{'));
				}
				if(szTagName.indexOf('{') != -1)
				{
					szAttributeName =  szTagName.substring(szTagName.indexOf('{') + 1, szTagName.length() - 1);
					szTagName = szTagName.substring(0, szTagName.indexOf('{'));
				}			
			
				int nNodeIndex;
				try
				{
					nNodeIndex = (new Integer(szTagIndex)).intValue();
				}
				catch(Exception e)
				{
					nNodeIndex = 1;
				}
			
				//if(szTagName.length() > 0)
					processedNode = processedNode.getChildNodeByTag(szTagName, nNodeIndex);
			
				if(processedNode == null)
					return null;
				
				if(szAttributeName.length() > 0)
					return processedNode.getAttribNode(szAttributeName);
			
			}
		}
		catch (RuntimeException ee)
		{
			// FIXME  This is a bad design!
		}
	
		return processedNode;
	}	

	/**
	 * Add attribute node to this node attributes.
	 *
	 */
	public void addAttribNode(TreeNodeAttrib propValue)
	{
		TreeNodeAttrib tempAttrNode = getAttribNode(propValue.getName());

		if(tempAttrNode != null)
		{
			removeAttribNode(propValue.getName());
		}

		m_attrList.addChildNode(propValue);
	}

	/**
	 *
	 */
	public void removeAttribNodeEx(String propValue)
	{
		this.removeAttribNode(propValue);

		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();

		while(tempNode != null)
		{
			tempNode.removeAttribNodeEx(propValue);
			tempNode = (XMLTreeNode) tempNode.getNext();
		}

	}

	/**
	 *
	 */
	public String getAttribText(String propValue)
	{
		TreeNodeAttrib node = getAttribNode(propValue);
		if(node == null)
			return null;

		return (String) node.getData();
	}

	/**
	 *
	 */
	public String getText()
	{
		String szResult = "";

		TreeNode tempNode = firstChildNode();
		
		while(tempNode != null)
		{
			Object data = tempNode.getData();
			if(data != null && data.getClass().getName().equals("java.lang.String"))
			{
				szResult += data.toString();
			}
			
			tempNode = tempNode.getNext();
		}
		
		return szResult;
	}
	
	/**
	 *
	 */
	public TreeNode getTextNode()
	{
		TreeNode tempNode = firstChildNode();
		
		while(tempNode != null)
		{
			Object data = tempNode.getData();
			if(data != null && data.getClass().getName().equals("java.lang.String"))
			{
				return tempNode;
			}
			
			tempNode = tempNode.getNext();
		}
		
		return null;
	}
	

	public void mergeXMLNodeHash(XMLTreeNode xmlNode)
	{
		// get fine structure.
		XMLTreeNode nodeMerge = XMLUtils.normaliseList(this);
		
		// process nodes, contains in nodeMerge
		XMLTreeNode childNodeTopLevel = (XMLTreeNode) nodeMerge.firstChildNode();
		while(childNodeTopLevel != null)
		{
			XMLTreeNode childNode = (XMLTreeNode) childNodeTopLevel.firstChildNode();
			XMLTreeNode childNodeSrc = xmlNode.getChildNodeLike(childNode);			
			if(childNodeSrc != null)
				while(childNode != null)
				{
					XMLTreeNode childRealNode = (XMLTreeNode) childNode.getData();
					childRealNode.setHashCode(childNodeSrc.getHashCode());
					childRealNode.mergeXMLNodeHash(childNodeSrc);
					childNode = (XMLTreeNode) childNode.getNext();
				}
			childNodeTopLevel = (XMLTreeNode) childNodeTopLevel.getNext();
		}
	}
}