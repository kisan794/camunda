package hireright.sdk.xml.parser;

import hireright.sdk.xml.utils.XMLUtils;

/**
 *
 * Object for storage XML node`s attribute in form NAME=DATA.
 *
 * last changed 2001/11/14
 *
 */
public class TreeNodeAttrib extends TreeNode
{
	
	protected String m_szName = null;
	
	public String getName()
	{
		return m_szName;
	}

	public void setName(String propValue)
	{
		m_szName = propValue;
	}

	public String toString()
	{
		String szData = (String) getData();
		if(szData == null)
			szData = "";
			
		return getName() + "=\"" + XMLUtils.decodeTextData(szData) + "\"";
	}
    
	protected void copyMembersData(TreeNodeAttrib node)
	{
		super.copyMembersData(node);
		node.setName(this.getName());
	}
	
	public Object clone() 
	{
		TreeNodeAttrib node = new TreeNodeAttrib();
		copyMembersData(node);
		return node;
	}    

}