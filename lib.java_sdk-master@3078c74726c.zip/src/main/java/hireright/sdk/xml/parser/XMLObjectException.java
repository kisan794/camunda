/*
 * @(#)$RCSfile: XMLObjectException.java,v $ $Revision: 1.7 $ $Date: 2008/11/21 11:32:56 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/parser/XMLObjectException.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2001-11-14	S.Ignatov		created
 *  2008-02-18	A.Solntsev	Added constructor XMLObjectException(Throwable cause, String sUrl)
 */
package hireright.sdk.xml.parser;

import java.net.URL;

import hireright.sdk.util.CException;
import hireright.sdk.util.CProperties;

/**
 *
 * last changed 2001/11/14
 * 
 * @author Sergei Ignatov
 * @version $Revision: 1.7 $ $Date: 2008/11/21 11:32:56 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/parser/XMLObjectException.java,v $
 */
public class XMLObjectException extends CException
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
	public XMLObjectException(String s)
	{
		super(s);
	}
	
	public XMLObjectException(Throwable cause, URL url)
	{
		super(cause, new CProperties().setProperty("url", url));
	}
	
	public XMLObjectException(Throwable cause, String sInvalidXml)
	{
		super(cause, new CProperties().setProperty("sInvalidXmlLength", sInvalidXml.length()), sInvalidXml);
	}
	
	public XMLObjectException(String sErrorMessage, Throwable cause, String sInvalidXml)
	{
		super(sErrorMessage, cause, new CProperties().setProperty("sInvalidXmlLength", sInvalidXml.length()), sInvalidXml);
	}
}