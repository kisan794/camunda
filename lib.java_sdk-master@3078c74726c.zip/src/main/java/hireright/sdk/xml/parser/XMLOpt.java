package hireright.sdk.xml.parser;

/**
  *
  * last changed 2001/11/14
  *
  */
public class XMLOpt
{
	
	public static final char TAG_SYMBOL_START = '<';
	public static final char TAG_SYMBOL_END = '>';	
	public static final char NAMESPACE_DIVIDER = ':';
	public static final char METADATA_SYMBOL = '?';
	
	public static final int TEXT_NONE = 0;
	public static final int TEXT_NORMAL = 1;
	public static final int TEXT_CDATA = 2;
	public static final int TEXT_PCDATA = 3;
	public static final int TEXT_COMMENT = 4;
	public static final int TEXT_DOCTYPE = 5;
	
	public static final int NODE_OPENED = 0;
	public static final int NODE_CLOSED = 1;
	public static final int NODE_STANDALONE = 2;
}