/*
 * @(#)$RCSfile: XMLObject.java,v $ $Revision: 1.10 $ $Date: 2008/11/21 11:32:42 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/parser/XMLObject.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2001-11-14	...
 *	2004-01-20	A.Solntsev	Fixed old bug with reading from URL.
 *  2004-11-18  A.Solntsev  Added logging to TraceLog.
 *	2007-xx-yy	A.Solntsev  Improved performance: reusing the same StringBuffer instance
 *	2008-02-18	A.Solntsev  Added methods parseValidXml(), parseValidXmlUrl which throw RuntimeException
 */
package hireright.sdk.xml.parser;

import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.URL;

/**
 * Class for XML Document`s primary parsing.
 * Can parse xml`s as URL to data or STRING data.
 *
 * @version $Revision: 1.10 $ $Date: 2008/11/21 11:32:42 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/parser/XMLObject.java,v $
 */
public class XMLObject implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.10 $ $Author: cvsroot $";
	
	/* Constants */
	protected static int BUFFER_SIZE = 256;

	/* Class members */
	protected XMLTreeNode m_rootNode = new XMLTreeNode();
	protected final StringBuffer m_szbTempBuffer = new StringBuffer();
	protected boolean m_isNodeStartChar;
	protected boolean m_boolNodeIsTagged;
	protected int m_boolRawData = XMLOpt.TEXT_NONE;
	protected int m_nCounter;
	protected int m_nDTDLevel;

	/**
	 * Construct empty object.
	 *
	 */
	public XMLObject()
	{
	}

	/**
	 * Construct object and parse xml from given url source.
	 *
	 * @throws XMLObjectException
	 */
	public XMLObject(URL url) throws XMLObjectException
	{
		parse(url);
	}

	/**
	 * Construct object and parse xml from string.
	 *
	 * @throws XMLObjectException
	 */
	public XMLObject(String string) throws XMLObjectException
	{
		parse(string);
	}

	/**
	 * Parse xml from given url source.
	 *
	 * @throws XMLObjectException
	 */
	public void parse(URL url) throws XMLObjectException
	{
    char[] cbuf = new char[BUFFER_SIZE];
		try
		{
			InputStreamReader reader = new InputStreamReader(url.openStream());
			int off = 0;
			int len = BUFFER_SIZE;

			initParsing();

			while((len = reader.read(cbuf, off, len)) != -1)
			{
				for(int i = 0; i < len; i++)
				{
					addChar(cbuf[i]);
				}
			}

			doneParsing();
		}
		catch (IOException e)
		{
			throw new XMLObjectException(e, url);
		}
	}

	/**
	 * The same as {@link #parse(URL)} except that it throws RuntimeException in case of invalid XML
	 *
	 * @param url
	 */
	public void parseValidXml(URL url)
	{
		try
		{
			parse(url);
		}
		catch (XMLObjectException xmle)
		{
			throw new CRuntimeException(xmle);
		}
	}
	
	/**
	 * The same as {@link #parse(URL)} except that it throws RuntimeException in case of invalid XML
	 *
	 * @param sUrl
	 */
	public void parseValidXmlUrl(String sUrl)
	{
		try
		{
			parse( new URL(sUrl) );
		}
		catch (XMLObjectException xmle)
		{
			throw new CRuntimeException(xmle);
		}
		catch (IOException ioe)
		{
			throw new CRuntimeException(ioe);
		}
	}

	/**
	 * Parse xml from string.
	 * 
	 * @throws XMLObjectException
	 */
	public void parse(String string) throws XMLObjectException 
	{
		assert string != null : "XML string is null";
		
		try 
		{
			initParsing();

			for (int i = 0; i < string.length(); i++) 
			{
				addChar(string.charAt(i));
			}

			doneParsing();
		} 
		catch (Exception e) 
		{
			CProperties params = new CProperties();
			params.setProperty("stringLength", string.length());

			throw new XMLObjectException(e, string);
		}
	}

	/**
	 * Procedure to collect input from all parse procedures.
	 * Primary parsing of xml document. Extact node parts of XML.
	 *
	 * @throws XMLObjectException
	 */
	protected int addChar(char c) throws XMLObjectException
	{
			if(m_isNodeStartChar)
			{		/* if this first char of parsed element. just start collecting data. */
				m_isNodeStartChar = false;
				m_szbTempBuffer.append(c);
				if(c == XMLOpt.TAG_SYMBOL_START)
					m_boolNodeIsTagged = true;
				else
					m_boolNodeIsTagged = false;
			}
			else
			{		/* if continue collecting data. */
				if(m_boolRawData != XMLOpt.TEXT_NONE)
				{	/* if current data CDATA, DTD or COMMENTS */
					addCharRawData(c);
				}
				else
				{	/* if current data normal TAG or TEXT */
						switch(c)
						{
								case XMLOpt.TAG_SYMBOL_START:
									if(m_boolNodeIsTagged)
										throw new XMLObjectException("Invalid Character " + XMLOpt.TAG_SYMBOL_START + " at " + m_szbTempBuffer.toString());

									createNode(m_szbTempBuffer.toString());
									m_szbTempBuffer.append(c);
									m_isNodeStartChar = false;
									m_boolNodeIsTagged = true;
									break;
								case XMLOpt.TAG_SYMBOL_END:
									m_szbTempBuffer.append(c);

									if(!m_boolNodeIsTagged)
										throw new XMLObjectException("Invalid Character " + XMLOpt.TAG_SYMBOL_END + " at " + m_szbTempBuffer.toString());

									createNode(m_szbTempBuffer.toString());
									m_isNodeStartChar = true;
									break;
								default:
									m_szbTempBuffer.append(c);

									switch(c)
									{
										case '[': /* check for CDATA sections */
											if(m_szbTempBuffer.length() == 9 && m_szbTempBuffer.toString().compareTo("<![CDATA[") == 0)
												m_boolRawData = XMLOpt.TEXT_CDATA;
											break;

										case '-': /* check for COMMENTS sections */
											if(m_szbTempBuffer.length() == 4 && m_szbTempBuffer.toString().compareTo("<!--") == 0)
												m_boolRawData = XMLOpt.TEXT_COMMENT;
											break;

										case 'E': /* check for DTD sections */
											if(m_szbTempBuffer.length() == 9 && m_szbTempBuffer.toString().compareTo("<!DOCTYPE") == 0)
											{
												m_boolRawData = XMLOpt.TEXT_DOCTYPE;
												m_nDTDLevel = 1;
											}
											break;
										default:
									}
									break;
						}
				}
			}

			return 0;
	}

	/**
	 * Part of procedure of input from parse procedures.
	 * Process CDATA, COMMENTS, DTD chars: collect and detect end of section.
	 *
	 * @throws XMLObjectException
	 */
	protected void addCharRawData(char c) throws XMLObjectException
	{
		m_szbTempBuffer.append(c);

		switch(m_boolRawData)
		{
			case XMLOpt.TEXT_CDATA:
				if(c == '>' && m_szbTempBuffer.toString().endsWith("]]>"))
				{
					createNode(m_szbTempBuffer.toString());
					m_boolRawData = XMLOpt.TEXT_NONE;
					m_isNodeStartChar = true;
				}
				break;
			case XMLOpt.TEXT_COMMENT:
				if(c == '>' && m_szbTempBuffer.toString().endsWith("-->"))
				{
					m_boolRawData = XMLOpt.TEXT_NONE;
					m_isNodeStartChar = true;
				}
				break;
			case XMLOpt.TEXT_DOCTYPE:
				switch(c)
				{
					case '>': m_nDTDLevel--;
						if(m_nDTDLevel == 0)
						{
							m_boolRawData = XMLOpt.TEXT_NONE;
							m_isNodeStartChar = true;
						}
						break;
					case '<': m_nDTDLevel++;
						break;
					default:
				}
				break;
			default:
		}
	}

	protected void initParsing()
	{
		m_rootNode = new XMLTreeNode();
	    m_szbTempBuffer.setLength(0);
	    m_isNodeStartChar = true;
	    m_nCounter = 0;
	    m_boolRawData = XMLOpt.TEXT_NONE;
	}

	protected void doneParsing()
	{
	    m_szbTempBuffer.setLength(0);

	    while (m_rootNode.getParent() != null)
			m_rootNode = (XMLTreeNode) m_rootNode.getParent();

		onDoneParsing();
	}

	protected void createNode(String string) throws XMLObjectException
	{
		String szTrimmed = string.trim();

		if(szTrimmed.length()==0)
		{
			m_szbTempBuffer.setLength(0);
			return;
		}

		XMLTreeNode node = new XMLTreeNode(szTrimmed);
		switch(node.getNodeType())
		{
			case XMLOpt.TEXT_NONE:
				switch(node.getTagMode())
				{
					case XMLOpt.NODE_STANDALONE:
						m_rootNode.addChildNode(node);
						onNodeAdded(node);
						break;
					case XMLOpt.NODE_OPENED:
						m_rootNode.addChildNode(node);
						m_rootNode = node;
						onNodeAdded(node);
						break;
					case XMLOpt.NODE_CLOSED:
						m_rootNode = (XMLTreeNode) m_rootNode.getParent();
						break;
				}
				break;
			default:
				m_rootNode.addChildNode(node);
				break;
		}

		m_nCounter++;
		m_szbTempBuffer.setLength(0);
	}

	public XMLTreeNode getRootNode()
	{
		return m_rootNode;
	}

	public void mergeHashCodes(XMLObject xmlObject)
	{
		mergeHashCodes(xmlObject.getRootNode());
	}

	public void mergeHashCodes(XMLTreeNode xmlNode)
	{
		getRootNode().mergeXMLNodeHash(xmlNode);
	}

	public void onNodeAdded(@SuppressWarnings("unused") XMLTreeNode node)
	{
	}

	public void onDoneParsing()
	{
	}
}