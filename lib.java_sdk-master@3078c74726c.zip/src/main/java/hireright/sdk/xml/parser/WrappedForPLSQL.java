package hireright.sdk.xml.parser;

import java.util.LinkedList;
import hireright.sdk.xml.utils.XMLUtils;

/**
 *
 * last changed 2001/11/14
 *
 */

public class WrappedForPLSQL
{
	protected static java.util.LinkedList m_xmlObjectsList;
	
	/**
	 * Initialisation of wrapper, return XMLObject ID. 
	 *
	 */
	public static int init()
	{
		if(m_xmlObjectsList == null)
			m_xmlObjectsList = new LinkedList();
		
		m_xmlObjectsList.add((Object) (new XMLObject()));
		
		return m_xmlObjectsList.size() - 1;
	}
	
	protected static boolean check(int nObjectID)
	{
		if(nObjectID >= 0 && nObjectID < m_xmlObjectsList.size())
			return true;
		
		return false;
	}

	/**
	 * Remove unused XMLObject. 
	 *
	 */		
	public static int done(int nObjectID)
	{
		if(!check(nObjectID))
			return -1;
		
		XMLObject xmlObject = (XMLObject) m_xmlObjectsList.get(nObjectID);
		m_xmlObjectsList.remove(nObjectID);
		xmlObject = null;
		
		return 0;
	}	
	
	/**
	 *
	 */
	public static int parseString(int nObjectID, String sXMLTextBody)
	{
		try
		{
			if(!check(nObjectID))
				return -1;
		
			XMLObject xmlObject = (XMLObject) m_xmlObjectsList.get(nObjectID);
			xmlObject.parse(sXMLTextBody);
		
			return 0;
		}
		catch(Exception e)
		{
			return -1;
		}
	}
	
	/**
	 *
	 */	
	public static int parseUrl(int nObjectID, String sXMLUrl)
	{
		try
		{		
			if(!check(nObjectID))
				return -1;
		
			XMLObject xmlObject = (XMLObject) m_xmlObjectsList.get(nObjectID);
			xmlObject.parse(new java.net.URL(sXMLUrl));
		
			return 0;
		}
		catch(Exception e)
		{
			return -1;
		}			
	}	
	
	/**
	 * Return value of xml node, or it attribute as String.
	 */
	public static String getXMLValueByPath(int nObjectID, String sPath, String sDefault)
	{
		try
		{		
			if(!check(nObjectID))
				return sDefault;
		
			XMLObject xmlObject = (XMLObject) m_xmlObjectsList.get(nObjectID);
			TreeNode treeNode = xmlObject.getRootNode().getChildNodeByPath(sPath);
			return XMLUtils.nodeValue(treeNode, sDefault);
		}
		catch(Exception e)
		{
			return sDefault;
		}			
	}
}