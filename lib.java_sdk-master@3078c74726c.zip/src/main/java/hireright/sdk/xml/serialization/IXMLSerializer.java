/*
 * @(#)$RCSfile: IXMLSerializer.java,v $ $Revision: 1.2 $ $Date: 2008/10/29 09:07:15 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/serialization/IXMLSerializer.java,v $
 *
 * Copyright 2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Plohotnichenko	2008-04-18	Created.
 */

package hireright.sdk.xml.serialization;

import java.io.Serializable;

public interface IXMLSerializer
{
	/**
	 * @return Object's root node name.
	 */
	public String getRootNodeName();
	/**
	 * @return XML representation of the object.
	 */
	public String toXML(final Serializable object);
}
