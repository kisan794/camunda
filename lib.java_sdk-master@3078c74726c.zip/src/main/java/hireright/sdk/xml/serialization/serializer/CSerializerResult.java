package hireright.sdk.xml.serialization.serializer;
/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	Jan 18, 2016	Created
 *	alogachyov	2018-05-14		Remove invalid xml symbols
 * 	V.Tsetsnev	2021-10-20		HRG-174238 Copied class from order_configuration_sdk
 */

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CStringUtils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CSerializerResult
{
	private String m_sMimeType;
	private InputStream m_content;
	
	CSerializerResult(String sMimeType, InputStream content)
	{
		m_sMimeType = sMimeType;
		m_content = content;
	}
	
	public String getMimeType()
	{
		return m_sMimeType;
	}
	
	public InputStream getContent()
	{
		return m_content;
	}
	
	public String toString()
	{
		StringBuffer sb=new StringBuffer();
		
		try
		{
			String read;

			BufferedReader br = new BufferedReader(new InputStreamReader(m_content, "UTF-8"));
			while((read=br.readLine()) != null) 
			{
				sb.append(removeInvalidXMLCharacters(read));
			}
	
			br.close();
		}
		
		catch(Throwable ex)
		{
			CTraceLog.error(ex);
		}
		
		return sb.toString();
	}
	
	private static String removeInvalidXMLCharacters(String sNodeValue) 
	{
		if (CStringUtils.isEmpty(sNodeValue))
		{
			return sNodeValue;
		}

		StringBuffer result = new StringBuffer();
		
		for (int i = 0; i < sNodeValue.length(); i++) 
		{
			char sCurrent = sNodeValue.charAt(i);
			if ((sCurrent == 0x9) 
				|| (sCurrent == 0xA) 
				|| (sCurrent == 0xD) 
				|| ((sCurrent >= 0x20) && (sCurrent <= 0xD7FF))
				|| ((sCurrent >= 0xE000) && (sCurrent <= 0xFFFD)) 
				|| ((sCurrent >= 0x10000) && (sCurrent <= 0x10FFFF)))
			{
				result.append(sCurrent);
			}
		}
		return result.toString();
	}
}