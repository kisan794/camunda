package hireright.sdk.xml.serialization.serializer;
/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	Jan 18, 2016	Created
 * 	V.Tsetsnev	2021-10-20		HRG-174238 Copied class from order_configuration_sdk, added getSerializedInputStream
 */

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CRuntimeException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.transform.TransformerFactory;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class CXMLSerializer<T> extends CAbstractSerializer<T>
{
	private final static String MIME_XML ="application/xml";

	protected static final TransformerFactory m_transformerFactory = TransformerFactory.newInstance();
	protected JAXBContext m_jaxbContext = null;
	
	public CXMLSerializer(Class... classesToBebound)
	{
		try
		{
			m_jaxbContext = JAXBContext.newInstance(classesToBebound);
		}
		catch(Throwable ex)
		{
			CTraceLog.fatal(ex);
		}
	}
	
	@Override
	public CSerializerResult serialize(T sourceBean) throws CSerializerException
	{
		if (m_jaxbContext == null)
		{
			throw new CRuntimeException("JAXBContext is empty");
		}
		
		try
		{
			Marshaller marshaller = m_jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			marshaller.marshal(sourceBean,output);
			
			return new CSerializerResult(MIME_XML, new ByteArrayInputStream(output.toByteArray()));
		}
		catch (Throwable ex)
		{
			throw new CSerializerException(ex);
		}
	}

	public static <T> InputStream getSerializedInputStream(T object) throws CSerializerException
	{
		CXMLSerializer<Object> serializer = new CXMLSerializer<>(object.getClass());
		return serializer.serialize(object).getContent();
	}
}
