/*
 * @(#)$RCSfile: CObjectListXMLSerializer.java,v $ $Revision: 1.2 $ $Date: 2008/10/29 09:07:18 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/serialization/CObjectListXMLSerializer.java,v $
 *
 * Copyright 2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Plohotnichenko	2008-04-18	Created.
 */

package hireright.sdk.xml.serialization;

import hireright.sdk.xml.utils.CFastXMLComposer;

import java.io.Serializable;
import java.util.List;

public class CObjectListXMLSerializer
{
	private static final String LIST_ROOT_NODE_POSTFIX = "List";

	/**
	 * @return XML representation of the object.
	 */
	public static String toXML(final List<?> listObjects, IXMLSerializer serializer)
	{
		CFastXMLComposer composer = new CFastXMLComposer(CFastXMLComposer.INDENT_TYPE_NONE);

		composer.startTag(serializer.getRootNodeName() + LIST_ROOT_NODE_POSTFIX);

		for(Object obj: listObjects)
		{
			composer.addText(serializer.toXML((Serializable)obj), false);
		}

		composer.endTag(serializer.getRootNodeName() + LIST_ROOT_NODE_POSTFIX);

		return composer.toString();
	}
}
