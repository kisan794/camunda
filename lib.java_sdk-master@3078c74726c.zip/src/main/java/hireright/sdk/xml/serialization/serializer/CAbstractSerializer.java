/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	Jan 18, 2016	Created
 * 	V.Tsetsnev	2021-10-20		HRG-174238 Copied class from order_configuration_sdk
 */
package hireright.sdk.xml.serialization.serializer;

public abstract class CAbstractSerializer<T>
{
	public abstract CSerializerResult serialize(T sourceBean) throws CSerializerException;
}
