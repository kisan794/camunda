package hireright.sdk.xml.serialization.deserializer;
/*
 * @(#)$RCSfile: $ $Revision: $ $Date: $ $Author: $
 *
 * Copyright 2001-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	alogachyov	Jan 18, 2016	Created
 * 	V.Tsetsnev	2021-10-20		HRG-174238 Copied class from order_configuration_sdk
 */

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CRuntimeException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.TransformerFactory;
import java.io.InputStream;

public class CXMLDeserializer<T> extends CAbstractDeserializer<T>
{
	protected static final TransformerFactory m_transformerFactory = TransformerFactory.newInstance();
	protected JAXBContext m_jaxbContext = null;
	
	public CXMLDeserializer(Class... classesToBebound)
	{
		try
		{
			m_jaxbContext = JAXBContext.newInstance(classesToBebound);
		}
		catch(Throwable ex)
		{
			CTraceLog.fatal(ex);
		}
	}
	
	@Override
	public T deserialize(InputStream source) throws CDeserializerException
	{
		if (m_jaxbContext == null)
		{
			throw new CRuntimeException("JAXBContext is empty");
		}
		
		try
		{
			Unmarshaller unmarshaller = m_jaxbContext.createUnmarshaller();
			return (T) unmarshaller.unmarshal(source);
		}
		catch (Throwable ex)
		{
			throw new CDeserializerException(ex);
		}
	}
}
