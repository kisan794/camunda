/*
 * @(#)$RCSfile: CSingleElementGenerator.java,v $ $Revision: 1.2 $ $Date: 2015/05/09 08:53:12 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/dom/CSingleElementGenerator.java,v $
 * Copyright 2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2015-01-28	created
 */
package hireright.sdk.xml.dom;

import hireright.sdk.util.IGenerator;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Node;
import org.xml.sax.SAXException;

/**
 * Generates single XML element with specified name and value.
 * @author apodlipski
 */
public class CSingleElementGenerator implements IGenerator<Node>
{
	private String m_name;
	private String m_value;

	public CSingleElementGenerator(String elementName, String value)
	{
		m_name = elementName;
		m_value = value;
	}
	
	/**
	 * IGenerator<Node> contract implementation.
	 */
	public Node generate() throws SAXException, IOException, ParserConfigurationException
	{	
		return CXMLHelper.parse("<" + m_name + ">" + (m_value != null ? m_value : "") + "</" + m_name + ">");
	}
}
