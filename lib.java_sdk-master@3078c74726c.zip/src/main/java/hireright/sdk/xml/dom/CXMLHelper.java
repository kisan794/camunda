/*
 * @(#)$RCSfile: CXMLHelper.java,v $ $Revision: 1.5 $ $Date: 2015/11/02 20:16:22 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/dom/CXMLHelper.java,v $
 * Copyright 2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2014-10-07	created
 */

package hireright.sdk.xml.dom;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URL;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Various methods to assist in XML/XSLT tasks using DOM model.
 * @author apodlipski
 */

public class CXMLHelper
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	private static final Log log = LogFactory.getLog(CXMLHelper.class);
	
	public static void printDocument(Node doc, OutputStream out) 
	{
		try
		{
		    getTransformer(null).transform(new DOMSource(doc), new StreamResult(new OutputStreamWriter(out, "UTF-8")));
		}
		catch (Exception e)
		{
			log.error("Error printing the document!", e);
		}
	}
	
	private static Transformer getTransformer(Source source) throws TransformerConfigurationException
	{
		return getTransformer(source, false);
	}
	
	private static Transformer getTransformer(Source source, boolean omitDeclaration) throws TransformerConfigurationException
	{
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = (source != null ? tf.newTransformer(source) : tf.newTransformer());
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, omitDeclaration ? "yes" : "no");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		return transformer;
	}
	
	public static Node transform(Node doc, Source xsltSource) 
		throws TransformerConfigurationException, TransformerException, IOException, ParserConfigurationException, SAXException
	{
		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		getTransformer(xsltSource).transform(new DOMSource(doc), new StreamResult(new OutputStreamWriter(byteStream, "UTF-8")));
		//log.info("Transformation result: " + byteStream.toString("UTF-8"));
		return parse(byteStream.toString("UTF-8"));
	}
	
	public static Node parse(String xml) throws IOException, ParserConfigurationException, SAXException
	{
		InputSource is = new InputSource();
		is.setCharacterStream(new StringReader(xml));
		return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is);
	}
	
	/**
	 * Strips specified XML of any namespaces.
	 * @param xml
	 * @return
	 */
	public static Node stripNamespaces(Source xmlSource) throws TransformerException, TransformerConfigurationException
	{
		DOMResult result = new DOMResult();
		InputStream is = CXMLHelper.class.getResourceAsStream("/stripNamespaces.xslt");
		//printInputStream(is, "Loaded XSLT");
		Source xsltSource = new StreamSource(is);		
		getTransformer(xsltSource).transform(xmlSource, result);
		return result.getNode();
	}
	
	public static void printInputStream(InputStream is, String message)
	{
		try
		{
			log.info(message + ": " + IOUtils.toString(is, "UTF-8"));
		}
		catch (IOException e)
		{
			CTraceLog.error(e);
		}
	}
	
	/**
	 * Joins two XMLs into new XML with root node having specified name.
	 * @param node1
	 * @param node2
	 * @param nameForRootNode
	 * @return
	 * @throws IOException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 */
	public static Node joinDocuments(String nameForRootNode, Node... nodes) throws IOException, SAXException, ParserConfigurationException
	{
		Document newDoc = createDocument(nameForRootNode);
		for (Node node : nodes)
		{
			Node n = node.getFirstChild();
			newDoc.getDocumentElement().appendChild(newDoc.importNode(n, true));
		}
		return newDoc;
	}

	public static Document toDocument(String nameForRootNode, Node node) throws ParserConfigurationException, IOException, SAXException
	{
		Document newDoc = createDocument(nameForRootNode);
		newDoc.getDocumentElement().appendChild(newDoc.importNode(node, true));
		return newDoc;
	}

	public static Document createDocument(String nameForRootNode) throws IOException, SAXException, ParserConfigurationException
	{
		InputSource is = new InputSource();
		is.setCharacterStream(new StringReader("<" + nameForRootNode + "></" + nameForRootNode + ">"));
		return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is);
	}
	
	/**
	 * @param xpath
	 * @return
	 */
	public static String evaluateXpath(Node xml, String xpathValue) throws XPathExpressionException
	{
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		XPathExpression expr = xpath.compile(xpathValue);
		return (String) expr.evaluate(xml, XPathConstants.STRING);
	}
	
	public static Node getNodeByXpath(Node xml, String xpathValue) throws XPathExpressionException
	{
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		XPathExpression expr = xpath.compile(xpathValue);
		return (Node) expr.evaluate(xml, XPathConstants.NODE);
	}

	/**
	 * Serializes specified DOM node into a string.
	 * @param node
	 * @return
	 */
	public static String node2string(Node node)
	{
		try
		{
			StringWriter writer = new StringWriter();
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			transformer.transform(new DOMSource(node), new StreamResult(writer));
			return writer.toString();
		}
		catch (Exception e)
		{
			throw new CRuntimeException(e);
		}
	}

	public static byte[] node2bytes(Node node)
	{
		try
		{
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			StreamResult result = new StreamResult(bos);
			transformer.transform(new DOMSource(node), result);
			return bos.toByteArray();
		}
		catch (Exception e)
		{
			throw new CRuntimeException(e);
		}
	}
	
	/**
	 * Updates single node in specified XML with a new value, if it differs from the old one.
	 * Node must exist is XML.
	 * @param xml source XML.
	 * @param xpath XPath expression for locating the node.
	 * @param newValue new value.
	 */
	public static boolean updateIfDiffers(Node xml, String xpath, String newValue) throws XPathExpressionException
	{
		Node n = CXMLHelper.getNodeByXpath(xml, xpath);
		if (n != null)
		{
			String oldValue = CStringUtils.trim(n.getTextContent());
			String newValueTrimmed = CStringUtils.trim(newValue);
			if (!CStringUtils.isEmpty(newValueTrimmed) && (oldValue == null || !oldValue.equalsIgnoreCase(newValueTrimmed)))
			{
				n.setTextContent(newValueTrimmed);
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Obtains an InputStream object that can be used to read from the XML.
	 * @param xml
	 * @return
	 * @throws TransformerException
	 * @throws TransformerFactoryConfigurationError
	 */
	public static InputStream streamFrom(Node xml) throws TransformerException, TransformerFactoryConfigurationError
	{
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		TransformerFactory.newInstance().newTransformer().transform(new DOMSource(xml), new StreamResult(outputStream));
		return new ByteArrayInputStream(outputStream.toByteArray());
	}
	
	/**
	 * Validates XML using provided schema. 
	 * Using URL instead of InputStream as a schema source allows for easier includes processing.  
	 * @param xmlInput source of XML document.
	 * @param schemaURL URL to schema definition; can contain includes.
	 * @throws IOException
	 * @throws SAXException
	 */
	public static void validate(InputStream xmlInput, URL schemaURL) throws IOException, SAXException
	{
		SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema schema = schemaFactory.newSchema(schemaURL);
		Validator validator = schema.newValidator();
		validator.validate(new StreamSource(xmlInput));
	}		

	public static void toStream(Node xml, OutputStream output) throws TransformerException 
	{
    getTransformer(null, true).transform(new DOMSource(xml), new StreamResult(output));
	}
	
	/**
	 * 
	 * @param xml
	 * @param file
	 * @throws TransformerException 
	 * @throws IOException 
	 */
	public static void saveToFile(Node xml, File file) throws TransformerException, IOException
	{
		FileOutputStream output = null;
		try
		{
			output = new FileOutputStream(file);
			toStream(xml, output);
			output.flush();
		}
		finally
		{
			try
			{
				if (output != null) output.close();
			}
			catch (IOException e)
			{
				log.error("Error closing stream: ", e);
			}
		}
	}

}
