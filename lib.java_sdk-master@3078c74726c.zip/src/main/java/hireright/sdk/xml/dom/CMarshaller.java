/*
 * @(#)$RCSfile: CMarshaller.java,v $ $Revision: 1.3 $ $Date: 2015/11/02 20:14:41 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/xml/dom/CMarshaller.java,v $
 * Copyright 2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2014-10-17	created
 */
package hireright.sdk.xml.dom;

import hireright.sdk.debug.CTraceLog;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * Implements behavior to marshal/unmarshal POJOs to/from XML documents using standard JAXB binding.
 * @author apodlipski
 */
public final class CMarshaller
{
	private String m_jaxbContextPath;
	
	public CMarshaller(String jaxbContextPath)
	{
		m_jaxbContextPath = jaxbContextPath;
	}
	
	public CMarshaller(Class c)
	{
		m_jaxbContextPath = c.getPackage().getName();
	}
	
	/**
	 * Marshals specified object into XML document.
	 * @param o Java object to marshal.
	 * @return Document XML document with object serialization.
	 * @throws JAXBException
	 */
	public Document marshal(Object o) throws JAXBException
	{
		JAXBContext jc = JAXBContext.newInstance(m_jaxbContextPath);
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		
		try
		{
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.newDocument();

			m.marshal(o, doc);
			return doc;
		}
		catch(Exception e)
		{
			return null;
		}
	}
		
	/**
	 * Unmarshals Java object from specified XML document.  
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	public Object unmarshal(Node xml) throws TransformerException, JAXBException
	{		
		JAXBContext jc = JAXBContext.newInstance(m_jaxbContextPath);
		try
		{
			return jc.createUnmarshaller().unmarshal(xml); 
		}
		catch (JAXBException e)
		{
			CTraceLog.error(e);
			throw e;
		}
	}
}
