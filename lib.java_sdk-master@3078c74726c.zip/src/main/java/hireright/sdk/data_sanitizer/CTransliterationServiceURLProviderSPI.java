/*
 *
 * Copyright 2001-2017 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * D.Stybuk							2021-03-16	HRG-257220:	Created
 */

package hireright.sdk.data_sanitizer;

import hireright.lib.data_sanitizer.client.ITransliterationServiceURLProviderSPI;
import hireright.objects.utilities.CDomain;
import hireright.objects.utilities.CDomainFactory;
import hireright.sdk.util.CStringUtils;

public class CTransliterationServiceURLProviderSPI implements ITransliterationServiceURLProviderSPI
{
	public static final String BASE_DOMAIN_ID = "BASE";
	public static final String DATA_SANITIZER_SERVICE_ENTRY_POINT_ACTION = "DATA SANITIZER SERVICE ENTRY POINT";
	
	private String m_serviceURL;
	
	public CTransliterationServiceURLProviderSPI()
	{
		/*
		 * The default constructor is needed for SPI work.
		 */
	}
	
	@Override
	public String getServiceURL()
	{
		if (CStringUtils.isEmpty(m_serviceURL))
		{
			CDomain baseDomain = CDomainFactory.getDomain(BASE_DOMAIN_ID);
			m_serviceURL = baseDomain.getDomainEntryPoint(DATA_SANITIZER_SERVICE_ENTRY_POINT_ACTION, null);
		}
		
		return m_serviceURL;
	}
}
