/*
 * @(#)$RCSfile: PDFCompiler.java,v $ $Revision: 1.9 $ $Date: 2012/08/24 07:25:56 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/PDFCompiler.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	200x-aa-bb	A.Keks			created
 *	2004-01-20	A.Solntsev		Fixed old bug with reading from Input Stream.
 *														Code is formatted according to last standards.
 *	2004-12-14	A.Solntsev		Added error parameters.
 *	2005-09-23	S.Kocherovets	Added 'pdf_convert_0_20_5' supporting.
 *	2006-02-17	A.Solntsev		Removed writing useless message "PDF generating time" to CFileLog.
 *	2006-04-24	A.Solntsev		Added "out.close();" in method makePost().
 *	2006-04-24	A.Solntsev		Moved to package hireright.sdk.transform
 *	2007-09-07	A.Solntsev		Added alternative methods that throw exception instead of returning null
 *	2007-11-26	A.Solntsev		NetTracking.registerUrl();
 *	2008-03-23	A.Solntsev		Fixed exception handling: throw exception instead of logging
 *	2009-01-20	A.Solntsev		PDFCompiler: Added URL when throwing PDFException
 *	2009-04-07	Y. Shneykin		convertFO2PDF(String szFO, boolean isFOP5Used) now uses convertion servlet, 
 *										specified in szFO as root namespace parameter (see converterVersionPattern constant).
 *	2012-08-14	V.Polyakov		Added logic in convertFO2PDF() for replacing non-breaking character &nbsp; with &#160;   
 */
package hireright.sdk.transform;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.TransformerException;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.format_util.CFString;
import hireright.sdk.net.NetTracking;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;


/**
 *	Class description goes here.
 *
 *  @author		Anton Keks
 *  @version	$Revision: 1.9 $ $Date: 2012/08/24 07:25:56 $ $Author: cvsroot $
 * 	@source		$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/PDFCompiler.java,v $
 */
public class PDFCompiler
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	/* Class members */
	private static String m_szPDFServlet;
	private static String m_szPDFServlet0_20_5;
	private static String m_szHost;
	private static String m_szHost0_20_5;
	
	/**
	 * Pattern for searching converter version.
	 */
	private static final Pattern converterVersionPattern = 
			Pattern.compile("xmlns:fopversion=\"http://hireright.com/xslfo/version/(\\w*)");

	/**
	 * Get PDF convertors parameters.
	 * @throws PDFException if table JAVA_SETTINGS doesn't contain some required properties
	*/
	public static void getParameters() throws PDFException
	{
		m_szPDFServlet = PDFSettings.getPDFConvertorServletURL();
		m_szPDFServlet0_20_5 = PDFSettings.getPDFConvertor0_20_5ServletURL();
		m_szHost = PDFSettings.getPDFConvertorServletHost();
		m_szHost0_20_5 = PDFSettings.getPDFConvertor0_20_5ServletHost();
	}

	/**
	 * @deprecated Use method {@link #convertXML2PDF(String, URL)} which
	 * 			throws PDFException instead of returning null
	 *
	 * @param szXML
	 * @param urlXSL
	 * @return
	 */
	public static byte[] convertXML(String szXML, URL urlXSL)
	{
		return convertXML(szXML, urlXSL.toString());
	}

	public static byte[] convertXML2PDF(String szXML, URL urlXSL) throws PDFException
	{
		return convertXML2PDF(szXML, urlXSL.toString(), false);
	}

	/**
	 * @deprecated Use method {@link #convertXML2PDF(String, String)} which
	 * 			throws PDFException instead of returning null
	 * @param szXML
	 * @param szXSLURL
	 * @return
	 */
	public static byte[] convertXML(String szXML, String szXSLURL)
	{
		return convertXML(szXML, szXSLURL, false);
	}

	public static byte[] convertXML2PDF(String szXML, String szXSLURL) throws PDFException
	{
		return convertXML2PDF(szXML, szXSLURL, false);
	}

	/**
	 * Transform xml data by xslt. It is used 2 pdf convertors.
	 *
	 * @deprecated Use method {@link #convertXML2PDF(String, String, boolean)} which
	 * 			throws PDFException instead of returning null
	 *
	 * @param szXML			xml data.
	 * @param szXSLURL		url xslt data.
	 * @param isFOP5Used	whether pdf_convert_0_20_5 is used.
	 * @return PDF data; null if exception occurred
	 */
	public static byte[] convertXML(String szXML, String szXSLURL, boolean isFOP5Used)  
	{
		try
		{
			final String szFO = HTMLCompiler.getHTMLDocumentFromStringAsString(szXML, szXSLURL);
			return convertFO2PDF(szFO, isFOP5Used);
		}
		// if (szFO == null || szFO.trim().length() == 0)
		catch (XsltException e) 
		{
			CProperties params = new CProperties().setProperty("szXSLURL", szXSLURL);
			throw new CRuntimeException(e, params, szXML);
		}
		catch (PDFException e)
		{
			CProperties params = new CProperties().setProperty("szXSLURL", szXSLURL);
			throw new CRuntimeException(e, params, szXML);
		}
	}

	public static final String correctHTMLCode(String htmlDoc)
	{
		CFString cfString = new hireright.sdk.format_util.CFString(htmlDoc);
		cfString.replace("&apos;", "'");
/*
		cfString.replace("[[CDATA_START]]", "<![CDATA[");
		cfString.replace("[[CDATA_END]]", "]]>");
		cfString.replace("<space/>", "&nbsp;");
		cfString.replace("<nulltag/>", ""); // Just remove all nulltag's (used for forming correct textareas)
		cfString.replace("&#39;", "'");
		cfString.replace("&#38;", "&");
		cfString.replace("/>", " />");
*/
		return cfString.toString();
	}

	/**
	 * Transform xml data by xslt. It is used 2 pdf convertors.
	 *
	 * @param szXML			xml data (row XML, not FOP!)
	 * @param sXsltUrl		url xslt data.
	 * @param isFOP5Used	whether pdf_convert_0_20_5 is used.
	 * @return  PDF data
	 * @throws PDFException
	 */
	public static byte[] convertXML2PDF(String szXML, String sXsltUrl, boolean isFOP5Used) throws PDFException
	{
		String szFO;
		try
		{
			szFO = HTMLTransformer.transform(szXML, sXsltUrl);
		}
		catch (TransformerException xsltEx)
		{
			throw new PDFException("Invalid XSLT: " + sXsltUrl, xsltEx, getErrorParams(sXsltUrl, isFOP5Used));
		}

		if (szFO == null || szFO.trim().length() == 0)
		{
			throw new PDFException("FO generating failed", getErrorParams(sXsltUrl, isFOP5Used), szXML);
		}

		return convertFO2PDF(szFO, isFOP5Used);
	}

	/**
	 * @param szFO XML in FOP format
	 * @param isFOP5Used true/false: if use Apache FOP 0.20.5 or 0.20.1
	 * @return null if some exception happened
	 * @deprecated Use method {@link #convertFO2PDF(String, boolean)} which
	 * 			throws PDFException instead of returning null
	 */
	public static byte[] convertFO(String szFO, boolean isFOP5Used)
	{
		try
		{
			return convertFO2PDF(szFO, isFOP5Used);
		}
		catch (PDFException pdfEx)
		{
			CTraceLog.error(pdfEx, PDFCompiler.class.getName() + ".convertFO()", pdfEx.toProperties(), pdfEx.getData());
			return null;
		}
	}

	/**
	 * Converts FO to PDF using default converter or specified in FO one.
	 * 
	 * @param szFO String   xslfo as string
	 * @param isFOP5Used boolean   if no converter is specified in FO, uses this condition for choosing converter.
	 * @return PDF Data
	 * @throws PDFException
	 */
	public static byte[] convertFO2PDF(String szFO, boolean isFOP5Used) throws PDFException
	{

		if (szFO.length() < 10)
		{
			throw new PDFException("Not a valid FO: " + szFO, getErrorParams(null, isFOP5Used));
		}
		szFO = CStringUtils.nonBreakingSpaceCharacterToCode(szFO);
		getParameters();
		
		final String szPDFServlet;
		final String szHost;
		String converterVersion = getXSLFOConverterVersion(szFO);
		if (converterVersion != null)
		{
			szPDFServlet = PDFSettings.getPDFConvertorServletURL(converterVersion);
			szHost = PDFSettings.getPDFConvertorServletHost(converterVersion);
		}
		else
		{
			//If convertor version is not found, use default.
			szPDFServlet = (isFOP5Used) ? m_szPDFServlet0_20_5 : m_szPDFServlet;
			szHost = (isFOP5Used) ? m_szHost0_20_5 : m_szHost;
		}

		try
		{
			NetTracking.registerUrl(szPDFServlet);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			out = makePost(szFO, new URL(szPDFServlet), szHost);
			byte[] content = out.toByteArray();
			content = getPDF(szPDFServlet, content);
			return content;
		}
		catch (IOException e)
		{
			throw new PDFException(e, getErrorParams(null, isFOP5Used), szFO);
		}
	}
	
	/**
	 * Gets converter vesion from FO using pattern.
	 * 
	 * @param szFO xslfo as string to get version from.
	 * @return String version of convertor. null if no converter declaration found.
	 */
	private static String getXSLFOConverterVersion(String szFO)
	{
		Matcher matcher = converterVersionPattern.matcher(szFO);
		if (matcher.find())
		{
			return matcher.group(1);
		}
		return null;
	}

	private static CProperties getErrorParams(String szXSLURL, boolean isFOP5Used)
	{
		final String szPDFServlet = (isFOP5Used)? m_szPDFServlet0_20_5 : m_szPDFServlet;
		CProperties params = new CProperties();
		params.setProperties(PDFSettings.getProperties());
		params.setProperty("szXSLURL", szXSLURL);
		params.setProperty("isFOP5Used", isFOP5Used);
		params.setProperty("pdfServlet", szPDFServlet);
		return params;
	}

	private static byte[] getPDF(String szPDFServlet, byte[] arr) throws PDFException
	{
		ByteArrayOutputStream res = new ByteArrayOutputStream();

		int pos = 0;
		while (pos < arr.length)
		{
			if( arr[pos] == 0x25 ) // if begin with symbol '%'
			{
				if( (arr[pos + 1] == 0x50) && (arr[pos + 2] == 0x44)
					&& (arr[pos + 3] == 0x46) ) // and follows symbols are P, D and F
				{
					// then it is a beginning of PDF document
					res.write(arr, pos, arr.length - pos);
					return res.toByteArray();
				}
			}
			pos++;
		}

		throw new PDFException("No PDF document from server response " + szPDFServlet, getByteArrayAsProperties(arr));
	}

	public static CProperties getByteArrayAsProperties(byte[] arr)
	{
		CProperties params = new CProperties();
		params.setProperty("array", "unknown");
		try
		{
			params.setProperty("array", new String(arr));
		}
		catch (Exception e) {}
		return params;
	}

	private static ByteArrayOutputStream makePost(String szData, URL postUrl, String szHost)
		throws IOException
	{
		PrintWriter out = null;
		HttpURLConnection httpConnection = null;
		DataInputStream disResponce = null;

		try
		{
			//open connection
			httpConnection = (HttpURLConnection) postUrl.openConnection();
			httpConnection.setRequestMethod("POST");

			httpConnection.setDoOutput(true);
			httpConnection.setRequestProperty("Content-type", "text/xml");
			httpConnection.setRequestProperty("Accept", "*/*");
			//httpConnection.setRequestProperty("Accept-Charset", "utf-8, iso_8859-1");
			//httpConnection.setRequestProperty("Accept-Encoding", "gzip, deflate");
			httpConnection.setRequestProperty("User-Agent", "ne-skazhu");
			httpConnection.setRequestProperty("Host", szHost);
			httpConnection.setRequestProperty("Connection", "close");


			//post request
			out = new PrintWriter(httpConnection.getOutputStream());
			out.println(correctHTMLCode(szData));

			out.flush();
			out.close();

			//get responce
			disResponce = new DataInputStream(httpConnection.getInputStream());

			ByteArrayOutputStream bout = new ByteArrayOutputStream();

			final int nBufSize = 2048;
			byte[] buffer = new byte[nBufSize];
			int nRead;

			while ((nRead = disResponce.read(buffer, 0, nBufSize)) >= 0)
					bout.write(buffer, 0, nRead);

			bout.flush();
			bout.close();
			return bout;
		}
		finally
		{
			if (httpConnection != null)
			{
				httpConnection.disconnect();
				httpConnection = null;
			}
			if (disResponce != null)
			{
				disResponce.close();
				disResponce = null;
			}
			if (out != null)
			{
				out.close();
				out = null;
			}
		}
	}
}
