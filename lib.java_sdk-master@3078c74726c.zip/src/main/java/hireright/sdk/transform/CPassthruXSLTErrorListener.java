/*
 * @(#)$RCSfile: CPassthruXSLTErrorListener.java,v $ $Revision: 1.2 $ $Date: 2013/02/27 10:13:50 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/CPassthruXSLTErrorListener.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	M. Suhhoruki		2013-02-13 Created as CXSLTErrorListener alternative
 */
package hireright.sdk.transform;

import javax.xml.transform.ErrorListener;
import javax.xml.transform.TransformerException;

/**
 * 1. Raises any warnings, errors to caller (doesn't happen by default :/)
 * 2. Doesn't not log exception (this is caller's responsibility)
 * 
 * @author msuhhoruki
 *
 */
public final class CPassthruXSLTErrorListener implements ErrorListener
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	public void warning(TransformerException transformerException) throws TransformerException
	{
		throw transformerException;
	}

	public void error(TransformerException transformerException) throws TransformerException
	{
		throw transformerException;
	}

	public void fatalError(TransformerException transformerException) throws TransformerException
	{
		throw transformerException;
	}
}
