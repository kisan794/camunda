/*
 * @(#)$RCSfile: PDFSettings.java,v $ $Revision: 1.6 $ $Date: 2009/05/11 14:57:08 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/PDFSettings.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2002-03-20	A.Vasiljev	created
 *  2002-10-31	A.Nesterov	hireright.tables.CTJavaSettings replaced with hireright.settings.fields.CFJavaSettings
 * 	2003-01-28	A.Nesterov	added support for settings reloading
 * 	2003-02-26	A.Nesterov	Added automatic settings reloading
 * 	2005-02-01	I.suits			removed debugLogsEnabled() method
 * 	2005-09-23	S.Kocherovets	Added support for 'pdf_convert_0_20_5' PDF convertor web application.
 * 	2006-05-04	A.Solntsev		Moved upper from package hireright.settings
 * 	2006-08-03	A.Solntsev		implements Observer, registers itself in class GeneralSettings.
 * 								Added method getPDFTransformer().
 * 	2007-09-07	A.Solntsev		All methods throw PDFException instrad of loggin it.
 * 	2009-04-07	Y.Shneykin		Added methods for getting specific PDFConvertor properties from general settings.
 */
package hireright.sdk.transform;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Observable;
import java.util.Observer;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IHasProperties;
import hireright.settings.GeneralSettings;

/**
 * A PDFSettings class.
 * @author alekseiv
 * @author $Revision: 1.6 $ $Date: 2009/05/11 14:57:08 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/PDFSettings.java,v $
 */
public class PDFSettings implements Serializable, Observer, IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: asolntsev $";
	
	private static final String SETTING_NAME_PDF_CONVERTER = "PDF_TRANSFORMER";
	private static final String SETTING_NAME_PDF_CONVERTOR_URL = "PDF_CONVERTOR_SERVLET_URL";
	private static final String SETTING_NAME_PDF_CONVERTOR_HOST = "PDF_CONVERTOR_SERVLET_HOST";
	private static final String SETTING_NAME_PDF_CONVERTOR_0_20_5_URL = "PDF_CONVERTOR_0_20_5_SERVLET_URL";
	private static final String SETTING_NAME_PDF_CONVERTOR_0_20_5_HOST = "PDF_CONVERTOR_0_20_5_SERVLET_HOST";

	private static final String EXCEPTIONS_LOG_FILE = "pdf_exceptions.log";
	private static final String DEBUG_LOG_FILE = "pdf_debug.log";

	private static PDFSettings m_instance = null;

	private String m_sPDFTransformerURL;
	private URL m_urlPDFTransformer;

	private String m_szPDFConvertorServletURL;
	private String m_szPDFConvertor0_20_5ServletURL;
	private String m_szPDFConvertorServletHost;
	private String m_szPDFConvertor0_20_5ServletHost;

	/**
	 * Load PDF settings from DB.
	 */
	private static final PDFSettings getInstance()
	{
		if (m_instance == null)
		{
			synchronized (PDFSettings.class)
			{
				if (m_instance == null)
				{
					m_instance = new PDFSettings();
					m_instance.readSettings();
				}
			}
		}
		return m_instance;
	}

	public static String getExceptionsLogFile()
	{
		return EXCEPTIONS_LOG_FILE;
	}

	public static String getDebugLogFile()
	{
		return DEBUG_LOG_FILE;
	}

	protected PDFSettings()
	{
		GeneralSettings.registerObserver(this);
	}

	private static void checkRequiredProperty(String sPropName, String sPropValue) throws PDFException
	{
		if (sPropValue == null)
			throw new PDFException("Property " + sPropName + " is missing",
				new CProperties(GeneralSettings.getProperties()));
	}

	private final void readSettings()
	{
		m_sPDFTransformerURL = GeneralSettings.getProperty(SETTING_NAME_PDF_CONVERTER);
		m_urlPDFTransformer = null;

		String szPDFConvertorServletURL = GeneralSettings.getProperty(SETTING_NAME_PDF_CONVERTOR_URL);
		String szPDFConvertor0_20_5ServletURL = GeneralSettings.getProperty(SETTING_NAME_PDF_CONVERTOR_0_20_5_URL);
		String szPDFConvertorServletHost = GeneralSettings.getProperty(SETTING_NAME_PDF_CONVERTOR_HOST);
		String szPDFConvertor0_20_5ServletHost = GeneralSettings.getProperty(SETTING_NAME_PDF_CONVERTOR_0_20_5_HOST);

		try
		{
			checkRequiredProperty(SETTING_NAME_PDF_CONVERTOR_URL, szPDFConvertorServletURL);
			checkRequiredProperty(SETTING_NAME_PDF_CONVERTOR_0_20_5_URL, szPDFConvertor0_20_5ServletURL);
			checkRequiredProperty(SETTING_NAME_PDF_CONVERTOR_HOST, szPDFConvertorServletHost);
			checkRequiredProperty(SETTING_NAME_PDF_CONVERTOR_0_20_5_HOST, szPDFConvertor0_20_5ServletHost);

			m_szPDFConvertorServletURL = szPDFConvertorServletURL;
			m_szPDFConvertor0_20_5ServletURL = szPDFConvertor0_20_5ServletURL;
			m_szPDFConvertorServletHost = szPDFConvertorServletHost;
			m_szPDFConvertor0_20_5ServletHost = szPDFConvertor0_20_5ServletHost;
		}
		catch (PDFException pdfEx)
		{
			CTraceLog.fatal(pdfEx, getClass().getName() + ".readSettings()", pdfEx.toProperties(), pdfEx.getData());
		}
	}

	public void update(Observable o, Object arg)
	{
		readSettings();
	}
	
	/**
	 * Gets servlet url of specified converter.
	 * 
	 * @param convertorVersion		version of converter.
	 * @return String Servlet		url of specified converter.
	 * @throws PDFException
	 */
	public static String getPDFConvertorServletURL(String convertorVersion) 
			throws PDFException
	{
		return getConverterProperty(convertorVersion, "SERVLET_URL");
	}
	
	/**
	 * Gets servlet host of specified converter.
	 * 
	 * @param convertorVersion		version of converter.
	 * @return String		servlet host of specified converter.
	 * @throws PDFException
	 */
	public static String getPDFConvertorServletHost(String convertorVersion) 
			throws PDFException
		{
		return getConverterProperty(convertorVersion, "SERVLET_HOST");
	}

	/**
	 * Gets convertor property from general settings for specified 
	 * converterVersion and propertyPostfix.
	 * 
	 * @param converterVersion		version of converter 
	 * @param propertyPostfix		specified property postfix.
	 * @return String		property value.
	 * @throws PDFException		if converterVersion is null or empty. If there is no 
	 * 							such converter property in general settings.property
	 */
	private static String getConverterProperty(String converterVersion, String propertyPostfix)
			throws PDFException
	{
		if(CStringUtils.isEmpty(converterVersion))
		{
			throw new PDFException("convertorVersion can not be empty.",
					new CProperties(GeneralSettings.getProperties()));
		}
		StringBuffer stringBuffer = new StringBuffer("PDF_CONVERTOR_");
		stringBuffer.append(converterVersion)
				.append("_")
				.append(propertyPostfix);
		return getPropertyValueFromGeneralSettings(stringBuffer.toString());
	}
	
	/**
	 * Gets specified property value from general settings.
	 * 
	 * @param property		Property name
	 * @return String		property value.
	 * @throws PDFException		if there is no such property in general settings.
	 */
	private static String getPropertyValueFromGeneralSettings(String property)
			throws PDFException
	{
		String propertyValue = GeneralSettings.getProperty(property);
		if(CStringUtils.isEmpty(propertyValue))
		{
			throw new PDFException("There is no such property '" + property + 
					"' in GeneralSettings.", new CProperties(GeneralSettings.getProperties()));
		}
		return propertyValue;
	}

	public static String getPDFConvertorServletURL() throws PDFException
	{
		checkRequiredProperty(SETTING_NAME_PDF_CONVERTOR_URL, getInstance().m_szPDFConvertorServletURL);
		return getInstance().m_szPDFConvertorServletURL;
	}

	public static String getPDFConvertor0_20_5ServletURL() throws PDFException
	{
		checkRequiredProperty(SETTING_NAME_PDF_CONVERTOR_0_20_5_URL, getInstance().m_szPDFConvertor0_20_5ServletURL);
		return getInstance().m_szPDFConvertor0_20_5ServletURL;
	}

	public static String getPDFConvertorServletHost() throws PDFException
	{
		checkRequiredProperty(SETTING_NAME_PDF_CONVERTOR_HOST, getInstance().m_szPDFConvertorServletHost);
		return getInstance().m_szPDFConvertorServletHost;
	}

	public static String getPDFConvertor0_20_5ServletHost() throws PDFException
	{
		checkRequiredProperty(SETTING_NAME_PDF_CONVERTOR_0_20_5_HOST, getInstance().m_szPDFConvertor0_20_5ServletHost);
		return getInstance().m_szPDFConvertor0_20_5ServletHost;
	}

	public static String getPDFTransformerUrl() throws PDFException
	{
		checkRequiredProperty(SETTING_NAME_PDF_CONVERTER, getInstance().m_sPDFTransformerURL);
		return getInstance().m_sPDFTransformerURL;
	}

	/**
	 * This method reads settings from JAVA_SETTINGS table
	 *
	 * @throws	CRuntimeException if failed to read settings from table JAVA_SETTINGS,
	 * 			or property "PDF_TRANSFORMER" contains invalid URL.
	 */
	public static URL getPDFTransformer()
	{
		if (getInstance().m_urlPDFTransformer == null)
		{
			try
			{
				getInstance().m_urlPDFTransformer = new URL(getInstance().m_sPDFTransformerURL);
			}
			catch (MalformedURLException urle)
			{
				getInstance().m_urlPDFTransformer = null;
				throw new CRuntimeException("Property " + SETTING_NAME_PDF_CONVERTER + " contains invalid URL",
						urle, new CProperties().setProperty("url", getInstance().m_sPDFTransformerURL));
			}

		}

		return getInstance().m_urlPDFTransformer;
	}

	public CProperties toProperties()
	{
		return new CProperties()
			.setProperty(SETTING_NAME_PDF_CONVERTER, this.m_sPDFTransformerURL)
			.setProperty(SETTING_NAME_PDF_CONVERTOR_URL, this.m_szPDFConvertorServletURL)
			.setProperty(SETTING_NAME_PDF_CONVERTOR_0_20_5_URL, this.m_szPDFConvertor0_20_5ServletURL)
			.setProperty(SETTING_NAME_PDF_CONVERTOR_HOST, this.m_szPDFConvertorServletHost)
			.setProperty(SETTING_NAME_PDF_CONVERTOR_0_20_5_HOST, this.m_szPDFConvertor0_20_5ServletHost);
	}

	@Override
	public String toString()
	{
		return "PDF Settings [" + m_sPDFTransformerURL + "]";
	}

	public static CProperties getProperties()
	{
		return getInstance().toProperties();
	}
}
