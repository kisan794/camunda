/*
 * @(#)$RCSfile: XsltException.java,v $ $Revision: 1.2 $ $Date: 2008/03/26 15:52:50 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/XsltException.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   A.Solntsev				2008-03-10	Created
 */
package hireright.sdk.transform;

import hireright.sdk.util.CException;
import hireright.sdk.util.CProperties;

/**
 *
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $, $Date: 2008/03/26 15:52:50 $, $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/XsltException.java,v $
 */
public class XsltException extends CException
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: asolntsev $";
	
	public XsltException(String sMessage, CProperties params, String sXml)
	{
		super(sMessage, params, sXml);
	}
	
	public XsltException(Throwable cause, CProperties params, String sXml)
	{
		super(cause, params, sXml);
	}
}
