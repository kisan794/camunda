/*
 * @(#)$RCSfile: PDFTransformer.java,v $ $Revision: 1.8 $ $Date: 2008/05/09 14:15:54 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/PDFTransformer.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2003-01-15	Anton Keks				Initial revision
 *  2004-05-28	Andrei Solntsev		Removed "rIn.ready()"
 *  2006-03-05	Andrei Solntsev		Removed "throws Exception"
 *  2006-08-03	Andrei Solntsev		Use GeneralSettings for accessing table JAVA_SETTINGS
 *  2007-11-26	A.Solntsev				NetTracking.registerUrl();
 *  2008-05-08	A.Solntsev				Common code for posting content to URL has been moved to class IOUtils
 */
package hireright.sdk.transform;

import hireright.sdk.io.IOUtils;
import hireright.sdk.net.NetTracking;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * A class for converting HTML to PDF.
 * Uses external FastCGI script, which is written in C,
 * see in CVS: sources/c/fcgi_html2pdf
 *
 * PDF Content can be returned as String, array of bytes or
 * written directly into provided Writer.
 *
 * Both HTML content and URL of HTML file may be provided
 * for conversion.
 *
 * See documentation in CVS: docs/sdk/java/PDFTransformer.doc
 *
 * @author Anton Keks
 * @version $Revision: 1.8 $ $Date: 2008/05/09 14:15:54 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/PDFTransformer.java,v $
 */
public class PDFTransformer implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	/**
	 * Transform HTML to PDF, passing the whole HTML source directly as a String
	 * Returning PDF content as String
	 * @throws CRuntimeException if failed to read settings from table JAVA_SETTINGS
	 * @throws IOException
	 */
	public static final String transform(String szHTMLSource) throws IOException
	{
		// Read settings if not available
		URL urlPDFTransformer = PDFSettings.getPDFTransformer();
		NetTracking.registerUrl(urlPDFTransformer);
		
		return IOUtils.postHtml( urlPDFTransformer, szHTMLSource );
	}

	/**
	 * Transform HTML to PDF, passing the whole HTML source directly as a String
	 * Returning transformed PDF as an array of bytes
	 *
	 * @throws CRuntimeException if failed to read settings from table JAVA_SETTINGS
	 * @throws IOException
	 */
	public static final byte[] transformToBytes(String szHTMLSource) throws IOException
	{
		URL urlPDFTransformer = PDFSettings.getPDFTransformer();
		NetTracking.registerUrl(urlPDFTransformer);
		
		return IOUtils.postHtmlReturningBytes( urlPDFTransformer, szHTMLSource );
	}

	/**
	 * Transforms HTML to PDF and writes output into provided Writer
	 * @throws CRuntimeException if failed to read settings from table JAVA_SETTINGS
	 * @throws IOException
	 */
	public static final void transform(String szHTMLSource, Writer wOut) throws IOException
	{
		// Read settings if not available
		URL urlPDFTransformer = PDFSettings.getPDFTransformer();
		NetTracking.registerUrl(urlPDFTransformer);

		HttpURLConnection httpConnection = (HttpURLConnection) urlPDFTransformer.openConnection();
		httpConnection.setRequestMethod(IOUtils.HTTP_METHOD_POST);
		httpConnection.setRequestProperty(IOUtils.HTTP_HEADER_CONTENT_TYPE, IOUtils.CONTENT_TYPE_HTML);
		httpConnection.setDoOutput(true);

		IOUtils.printText(httpConnection.getOutputStream(), szHTMLSource);

		InputStreamReader rIn = new InputStreamReader(httpConnection.getInputStream());
		char[] caBuffer = new char[10*1024];	// 10 kb buffer

		// Read content line by line and output into the provided writer
		while (true)	// Removed "rIn.ready()"
		{
			int nRead = rIn.read(caBuffer);

			if (nRead < 0)
				break;

			wOut.write(caBuffer, 0, nRead);
		}

		wOut.flush();

		// Close the HTTP connection
		httpConnection.disconnect();
	}

	/**
	 * Transform HTML to PDF, getting HTML source from the specified URL
	 *
	 * @throws CRuntimeException if failed to read settings from table JAVA_SETTINGS
	 * @throws IOException
	 */
	public static final String transform(URL urlHTMLSource) throws IOException
	{
		return transform(urlHTMLSource.toString());
	}

	/**
	 * Transform HTML to PDF, getting HTML source from the specified URL
	 *
	 * @throws CRuntimeException if failed to read settings from table JAVA_SETTINGS
	 * @throws IOException
	 */
	public static final byte[] transformToBytes(URL urlHTMLSource) throws IOException
	{
		return transformToBytes(urlHTMLSource.toString());
	}

	/**
	 * Transform HTML to PDF, getting HTML source from the specified URL
	 *
	 * @throws CRuntimeException if failed to read settings from table JAVA_SETTINGS
	 * @throws IOException
	 */
	public static final void transform(URL urlHTMLSource, Writer wOut) throws IOException
	{
		transform(urlHTMLSource.toString(), wOut);
	}

}
