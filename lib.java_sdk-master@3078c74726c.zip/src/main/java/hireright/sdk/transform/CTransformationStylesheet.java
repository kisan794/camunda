/*
 * @(#)$RCSfile: CTransformationStylesheet.java,v $ $Revision: 1.2 $ $Date: 2010/01/08 08:52:30 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/CTransformationStylesheet.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *
 * A.Podlipski		2006-08-25	created
 * A.Solntsev		2006-12-27	implements Serializable; removed "throws Exception"
 * D.Murashev		2009-12-10	Moved to Java SDK
 */
package hireright.sdk.transform;

import hireright.sdk.transform.HTMLTransformer;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;

import javax.xml.transform.TransformerException;

/**
 * Primitive XSLT transformation stylesheet container.
 * @version "$Revision: 1.2 $, $Date: 2010/01/08 08:52:30 $, $Author: cvsroot $"
 * @author Aleksei Podlipski
 */
public class CTransformationStylesheet implements Serializable
{
	/**
	 * URL specifying where stylesheet .xslt file is located. For example:
	 * http://dev04.hireright.ee/common/vendor_signup/xslt/vendor_customer.xslt
	 */
	protected String m_sLocationURL;
	
	/**
	 * Default constructor
	 * @param sStylesheetURL URL where stylesheet is located
	 */
	public CTransformationStylesheet(String sStylesheetURL)
	{
		m_sLocationURL = sStylesheetURL;
	}
	
	/**
	 * Applies XSLT stylesheet to specified XML document.
	 * @param sXML source XML
	 * @return String with transformation result
	 * 
	 * @throws  IOException in case of invalid URL/ unexisting XSLT
	 * @throws TransformerException if XSLT exists but is invalid
	 */
	public String applyToXML(String sXML) throws IOException, TransformerException
	{
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		new HTMLTransformer(new URL(this.m_sLocationURL)).transform(sXML, outputStream);
		
		return outputStream.toString();
	}	
}