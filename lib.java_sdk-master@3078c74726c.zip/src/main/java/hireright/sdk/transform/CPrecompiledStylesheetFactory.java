/*
 * @(#)$RCSfile: CPrecompiledStylesheetFactory.java,v $ $Revision: 1.2 $ $Date: 2012/12/14 09:20:19 $ $Author: cvsroot $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  N.Danilov			2012-11-21		Created
 */
package hireright.sdk.transform;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CRuntimeException;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;



public class CPrecompiledStylesheetFactory 
{
	
	protected static final Object lock = new Object();	
	
	public static CPrecompiledTransformationStylesheet getPrecompiledStylesheet(String sURL)
	{
		Element el = getCache().get(sURL);
		if (el != null)
		{
			return (CPrecompiledTransformationStylesheet) el.getObjectValue();
		}
		else
		{
			return null;
		}
	}
	
	
	public static CompilationResult compileStylesheet(String sURL) throws MalformedURLException, IOException, ParseException
	{
		URL url = new URL(sURL);
		String lastModified = url.openConnection().getHeaderField("Last-Modified");
		SimpleDateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz");
		Date requestDate = format.parse(lastModified);
		
		CPrecompiledTransformationStylesheet stylesheet;
		stylesheet = getPrecompiledStylesheet(sURL);
		
		//no precompiled stylsheet for given URL exists, compile it and store in cache
		if (stylesheet == null || stylesheet.getCompilationTime() < requestDate.getTime())
		{
			try
			{
				Source source = new StreamSource(url.openConnection().getInputStream(), sURL);
				long compilationStart = System.currentTimeMillis();
				Transformer transformer = getTransformerFactory().newTransformer(source);
				CPrecompiledTransformationStylesheet precompiledStylesheet = new CPrecompiledTransformationStylesheet(transformer);
				long compilationEnd = System.currentTimeMillis();
				getCache().put(new Element(sURL,precompiledStylesheet));
				return new CompilationResult(Result.COMPILATION_SUCCESSFUL, compilationEnd-compilationStart, null);
			}
			catch (TransformerConfigurationException e)
			{
				CTraceLog.error(e, "Could not compile stylesheet " + sURL);
				return new CompilationResult(Result.COMPILATION_ERROR, 0L, e.getMessage());
			}
				
		}
		else
		{
			return new CompilationResult(Result.COMPILATION_NOT_NEEDED, 0L, null);
		}
	}
	
	
	private static Cache getCache()
	{
		Cache cache;
		synchronized (lock)
		{
				CacheManager cacheManager = CacheManager.create();
				final String sCacheName = CPrecompiledTransformationStylesheet.class.getName();
				cache = cacheManager.getCache(sCacheName);
				if (cache == null)
				{
					cacheManager.addCache(sCacheName);
					cache = cacheManager.getCache(sCacheName);
				}
		}
		return cache;
		
	}
	
	private static TransformerFactory getTransformerFactory()
	{

		TransformerFactory transformerFactory;
		try
		{
			transformerFactory = (TransformerFactory) Class.forName("org.apache.xalan.xsltc.trax.TransformerFactoryImpl").newInstance();
			return transformerFactory;
		}
		catch (Exception e)
		{
			throw new CRuntimeException("Error instantinating TransformerFactory", e);
		}
	}
	
	enum Result {
		COMPILATION_SUCCESSFUL("Success"), 
		COMPILATION_ERROR("Compilation error"), 
		COMPILATION_NOT_NEEDED("Compilation not needed");
		
		
		private String name;

		private Result(String name)
		{
			this.name = name;
		}
		public String getName()
		{
			return name;
		}
	};
	
	public static class CompilationResult
	{
		long m_compilationTime;
		String m_errorMessage;
		Result m_result;
		
		public CompilationResult(Result result, long compilationTime, String message)
		{
			m_result = result;
			m_compilationTime = compilationTime;
			m_errorMessage = message;
		}
		
		public long getCompilationTime()
		{
			return m_compilationTime;
			
		}
		
		public String getErrorMessage()
		{
			return m_errorMessage;
			
		}		
		
		public String getResultString()
		{
			return m_result.getName();
		}
		
	}
}
