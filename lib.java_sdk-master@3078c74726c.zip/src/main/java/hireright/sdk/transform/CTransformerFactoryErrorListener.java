/*
 * @(#)$RCSfile: CTransformerFactoryErrorListener.java,v $ $Revision: 1.3 $ $Date: 2009/07/10 09:26:21 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/CTransformerFactoryErrorListener.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2008-07-08	M.Elshin		Created
 *  2020-08-05	V.Ozernov		HRG-129092 change log level ERROR/FATAL -> WARNING for cases when current attempt is the first and the exception caused by IOException
 */
package hireright.sdk.transform;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IHasProperties;

import javax.xml.transform.ErrorListener;
import javax.xml.transform.TransformerException;


/**
 * Class that logs all errors and warnings during XSLT transformation.\
 * Intended to handle errors of TransformerFactory
 *
 * @author Michail Elshin
 * @version $Revision: 1.3 $ $Date: 2009/07/10 09:26:21 $ $Author: asolntsev $
 */
public class CTransformerFactoryErrorListener implements ErrorListener, IHasProperties
{
		protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: asolntsev $";

		private final Class<?> m_errorSourceClass;
		private final String m_sXsltUrl;
		private int m_nAttempt = 0;

		/**
		* Creates new instance.
		*
		* @param clazz Class that is used for obtaining source of error.
		* @param sXsltUrl URL of XSLT
		*/
		public CTransformerFactoryErrorListener(Class<?> clazz, String sXsltUrl)
		{
			this.m_errorSourceClass = clazz;
			this.m_sXsltUrl = sXsltUrl;
		}

		/**
		 * Creates new instance.
		 * @param sXsltUrl URL of XSLT
		 */
		public CTransformerFactoryErrorListener(String sXsltUrl)
		{
				this(CXSLTErrorListener.class, sXsltUrl);
		}

		/**
		 * Creates new instance.
		 * @param clazz Class that is used for obtaining source of error.
		 */
		public CTransformerFactoryErrorListener(Class<?> clazz)
		{
				this(clazz, CStringUtils.EMPTY_STRING);
		}


		public CProperties toProperties()
		{
			return new CProperties()
					.setProperty(HTMLTransformer.PROP_SAX_PARSER, System.getProperty(HTMLTransformer.PROP_SAX_PARSER))
					.setProperty(HTMLTransformer.PROP_TRANSFORMER_TYPE, System.getProperty(HTMLTransformer.PROP_TRANSFORMER_TYPE))
					.setProperty("xsltUrl", m_sXsltUrl)
					.setProperty("attempt", m_nAttempt);
		}

		/**
		* Logs warning
		*
		* @param transformerException
		* @throws TransformerException
		*/
		public void warning(TransformerException transformerException) throws TransformerException
		{
				CTraceLog.warning(getMessage(transformerException), getSource(), toProperties(), getLogPayload());
		}

		/**
		* Logs error
		*
		* @param transformerException
		* @throws TransformerException
		*/
		public void error(TransformerException transformerException) throws TransformerException
		{
				if (isNextAttemptExpected(transformerException))
				{
						CTraceLog.warning(getMessage(transformerException), getSource(), toProperties(), getLogPayload());
				}
				else
				{
						CTraceLog.error(getMessage(transformerException), getSource(), toProperties(), getLogPayload());
				}
		}

		/**
		* Logs fatal error
		*
		* @param transformerException
		* @throws TransformerException
		*/
		public void fatalError(TransformerException transformerException) throws TransformerException
		{
				if (isNextAttemptExpected(transformerException))
				{
						CTraceLog.warning(getMessage(transformerException), getSource(), toProperties(), getLogPayload());
				}
				else
				{
						CTraceLog.fatal(getMessage(transformerException), getSource(), toProperties(), getLogPayload());
				}
		}

		/**
		* Returns description of error.
		*
		* @param transformerException
		* @return description of error
		*/
		protected String getMessage(TransformerException transformerException)
		{
				try
				{
						return transformerException.getMessageAndLocation();
				}
				catch (Throwable t)
				{
						CTraceLog.error(t, getSource(), toProperties());
						try
						{
								return transformerException.getMessage();
						}
						catch(Throwable t2)
						{
								return "Unknown message and location";
						}
				}
		}

		protected boolean isNextAttemptExpected(TransformerException transformerException)
		{
				return m_nAttempt == 1
						&& transformerException != null
						&& HTMLTransformer.isTransformerExceptionCausedByIOException(transformerException);
		}

		/**
		 * Returns class name that started XSLT transformation.
		 *
		 * @return class name
		 */
		protected String getSource()
		{
				if (m_errorSourceClass == null)
				{
						return null;
				}
				else
				{
						return m_errorSourceClass.getName();
				}
		}

		protected String getLogPayload()
		{
			return CStringUtils.EMPTY_STRING;
		}

		protected void setAttempt(int nAttempt)
		{
				m_nAttempt = nAttempt;
		}
}
