/*
 * @(#)$RCSfile: HTMLTransformer.java,v $ $Revision: 1.23 $ $Date: 2013/06/28 06:52:34 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/HTMLTransformer.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	unknown		unknown			created
 *  2002-12-06	Alex Rudenko	minor changes
 *  2005-08-29	A.Solntsev		EHCache library is used for caching transformers.
 *  2005-10-19	D.Belorunov		ErrorListener is used for transformation.
 *	2006-09-22	A.Solntsev		Added more information wile logging invalid XSLT
 *	2006-11-04	A.Solntsev		Use new class XsltNormalizer for non-Oracle SAX parsers
 *	2006-11-23	A.Solntsev		Now class CXSLTErrorListener holds URL of current XSLT
 *	2007-03-13	A.Solntsev		Added XML Source when logging errors
 *	2007-06-22	A.Solntsev		Removed dependency on hireright.sdkex.as_cache
 *	2007-09-07	A.Solntsev		Added convinient method "public String transform(String sXML, String sXsltUrl)"
 *	2007-10-19	M.Suhhoruki		Added "public void transform(javax.xml.transform.Source in, Writer out)"
 *	2007-11-02	M.Karpov			Added transform() method with Node as param
 *	2007-11-26	A.Solntsev		NetTracking.registerUrl();
 *	2007-11-27	M.Suhhoruki		Added setParameter method to specify transformer parameters
 *	2008-01-02	A.Solntsev		Added m_xsltErrorsRegistry
 *	2008-07-07	M.Elshin			TransformerFactory was set with error listener, to handle it's errors
 *														These changes were made in getTransformerFactory() method.
 *	2009-01-30	A.Podlipski		forcing usage of Oracle XSLT transformer
 *	2009-12-29	M.Suhhoruki		Added java.sdk.transformer system property to override Oracle transformer use
 *	2010-08-27	A.Arekhin			Used java.sdk.transformer system property to override Oracle transformer
 *	2011-08-11	M.Suhhoruki		JXSAXParserFactory moved to forName+catch
 *	2012-03-14	M.Suhhoruki		getTransformerFactory: throw runtime replaced by TransformerFactory.newInstance();
 *	2012-06-01	E.Shatohhin		Added possibility to override transfomer for thread
 *	2013-02-13	M.Suhhoruki		ErrorListener implementation is configurable
 *	A.Plohotnichenko	2013-06-13	Second attempt to load template is made if first one fails.
 *	V.Ozernov			2018-07-31	HIVPE-48903 Fixed XSLT transformation from a XSLT passed as string on new Oracle parser
 *	V.Ozernov			2020-02-07	HIVPE-101806 Added second attempt of transformation in case of IOException
 *	V.Ozernov			2020-07-22	HRG-129619 Fixed second attempt of transformation
 *  V.Ozernov			2020-08-05	HRG-129092 change log level ERROR/FATAL -> WARNING for cases when current attempt is the first and the exception caused by IOException
 */
package hireright.sdk.transform;

import hireright.lib.logging.util.lang.ExceptionUtils;
import hireright.sdk.debug.CStackTrace;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.net.NetTracking;
import hireright.sdk.util.CFileContent;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;
import hireright.settings.GeneralSettings;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringReader;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.transform.ErrorListener;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Templates;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.w3c.dom.Node;
import org.xml.sax.InputSource;

/**
 * A class for transforming an XML to HTML using XSL
 * Uses SAX XML parser, so is faster than analoguous HTMLCompiler class.
 * HTMLTransformer has caching support as well.
 *
 * @author Anton Keks
 * @since 2001 created
 * @version $Revision: 1.23 $ $Date: 2013/06/28 06:52:34 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/HTMLTransformer.java,v $
 */
public class HTMLTransformer implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.23 $ $Author: cvsroot $";
	
	protected static final Object lock = new Object();
	private static Cache m_xsltCache = null;
	private static boolean m_bIsXsltCacheEnabled = true;

	/**
	 * Configures transformer implementation.
	 * Default is Oracle transformer.
	 * Supported values:
	 * 		1. sysdefault = uses transformer in javax.xml.transform.TransformerFactory system property
	 * Possible values to implement:
	 * 		2. oracle
	 * 		3. xalan
	 * 		4. saxon
	 */
	
	public static final String XALAN_TRANSFORMER = "XALAN";
	
	protected static final String PROP_TRANSFORMER_TYPE = "java.sdk.transformer";
	protected static final String PROP_SAX_PARSER = "javax.xml.parsers.SAXParserFactory";
	protected static final String ORACLE_PARSER = "oracle.xml.jaxp.JXSAXParserFactory";

	protected final String m_sXsltUrl;
	protected final ErrorListener m_xsltErrorListener;
	protected final Transformer m_XSLTransformer;
	
	/**
	 * Value of java.sdk.transformer system property.
	 * Forces HTMLTransformer to use javax.xml.transform.TransformerFactory system property
	 * when creating transformer instance.
	 */
	private static final String TRANSFORMER_SYSDEFAULT = "sysdefault";
	
	private static final ThreadLocal<String> m_transformerTypeOverride = new ThreadLocal<String>();
	
	/* Constructors ***********************************************************************/

	/**
	 * It's recommended to use constructors with URL because in case of error
	 * Reader doesn't allow to log location of invalid XSLT.
	 * @param rdXSL
	 * @throws TransformerConfigurationException
	 */
	public HTMLTransformer(Reader rdXSL) throws TransformerConfigurationException
	{
		m_sXsltUrl = "unknown (java.io.Reader)";
		Source sourceXSL = new StreamSource(rdXSL);
		TransformerFactory transformerFactory = getTransformerFactory();
		m_XSLTransformer = transformerFactory.newTransformer(sourceXSL);

		m_xsltErrorListener = new CXSLTErrorListener(HTMLTransformer.class, m_sXsltUrl);
		m_XSLTransformer.setErrorListener(m_xsltErrorListener);
	}

	/**
	 * Note that only this contructor uses caching!
	 * (And caching must be enabled)
	 * @param urlXSL eg. "http://test01.hireright.ee/designs/n-age/nokia/xsl/personal_information.xslt"
	 * @throws TransformerConfigurationException if given XSLT is invalid
	 */
	public HTMLTransformer(URL urlXSL) throws TransformerConfigurationException
	{
		NetTracking.registerUrl(urlXSL);

		// If caching is enabled, then this will use it
		m_sXsltUrl = urlXSL.toString();
		m_XSLTransformer = getCachedTransformer(m_sXsltUrl);

		m_xsltErrorListener = new CXSLTErrorListener(HTMLTransformer.class, m_sXsltUrl);
		m_XSLTransformer.setErrorListener(m_xsltErrorListener);
	}
	
	public HTMLTransformer(URL urlXSL, ErrorListener errorListener) throws TransformerConfigurationException
	{
		NetTracking.registerUrl(urlXSL);

		// If caching is enabled, then this will use it
		m_sXsltUrl = urlXSL.toString();
		m_XSLTransformer = getCachedTransformer(m_sXsltUrl);
		m_xsltErrorListener = errorListener;
		if (m_xsltErrorListener != null)
		{
			m_XSLTransformer.setErrorListener(m_xsltErrorListener);
		}
	}

	/**
	 *
	 * @param szXSLSource Content of XSLT as is
	 * @throws TransformerConfigurationException
	 */
	public HTMLTransformer(String szXSLSource) throws TransformerConfigurationException
	{
		m_sXsltUrl = "unknown (java.io.Reader)";
		Source sourceXSL = createStreamSource(szXSLSource);
		TransformerFactory transformerFactory = getTransformerFactory();
		m_XSLTransformer = transformerFactory.newTransformer(sourceXSL);

		m_xsltErrorListener = new CXSLTErrorListener(HTMLTransformer.class, m_sXsltUrl);
		m_XSLTransformer.setErrorListener(m_xsltErrorListener);
	}

	/**
	 * Note that only this contructor uses caching!
	 * (And caching must be enabled)
	 * @param urlXSL eg. "http://test01.hireright.ee/designs/n-age/nokia/xsl/personal_information.xslt"
	 * @param sTransformerType Use specified transformer
	 * @throws TransformerConfigurationException if given XSLT is invalid
	 */
	public HTMLTransformer(URL urlXSL, String sTransformerType) throws TransformerConfigurationException
	{
		NetTracking.registerUrl(urlXSL);

		// If caching is enabled, then this will use it
		m_sXsltUrl = urlXSL.toString();

		m_XSLTransformer = getCachedTransformer(m_sXsltUrl, sTransformerType);

		m_xsltErrorListener = new CXSLTErrorListener(HTMLTransformer.class, m_sXsltUrl);
		m_XSLTransformer.setErrorListener(m_xsltErrorListener);		

	}	
	
	public String getXsltUrl()
	{
		return m_sXsltUrl;
	}

	/* Methods transform() ***********************************************************************/

	public void transform(String szXMLSource, OutputStream outputStream) throws TransformerException
	{
		setErrorListenerXMLSource(szXMLSource);
		try
		{
			Result resultHTML = new StreamResult(outputStream);
			doTransform(CXMLSourceSupplier.fromString(szXMLSource), resultHTML);
		}
		catch (TransformerException e)
		{
			registerError(getXsltUrl(), szXMLSource, e);
			throw e;
		}
		finally
		{
			setErrorListenerXMLSource(null);
		}
	}

	public void transform(String szXMLSource, Writer writer) throws TransformerException
	{
		setErrorListenerXMLSource(szXMLSource);
		try
		{
			Result resultHTML = new StreamResult(writer);
			doTransform(CXMLSourceSupplier.fromString(szXMLSource), resultHTML);
		}
		catch (TransformerException e)
		{
			registerError(getXsltUrl(), szXMLSource, e);
			throw e;
		}
		finally
		{
			setErrorListenerXMLSource(null);
		}
	}

	/** 
	 *	Process the source tree to the output result.
	 *
	 * @param node The DOM node that will contain the Source tree.
	 * @param writer  A valid Writer reference.
	 * @throws TransformerException If an unrecoverable error occurs
	 * during the course of the transformation.
	 */
	public void transform(Node node, Writer writer) throws TransformerException
	{
		setErrorListenerXMLSourceNode(node);
		try
		{
			Result resultHTML = new StreamResult(writer);
			doTransform(CXMLSourceSupplier.fromDomNode(node), resultHTML);
		}
		catch (TransformerException e)
		{
			registerError(getXsltUrl(), node.toString(), e);
			throw e;
		}
		finally
		{
			setErrorListenerXMLSourceNode(null);
		}
	}
	
	public void transform(URL urlXML, OutputStream outputStream) throws TransformerException
	{
		setErrorListenerXMLSource(urlXML.toString());
		try
		{
			Result resultHTML = new StreamResult(outputStream);
			doTransform(CXMLSourceSupplier.fromURL(urlXML), resultHTML);
		}
		finally
		{
			setErrorListenerXMLSource(null);
		}
	}

	public void transform(URL urlXML, Writer writer) throws TransformerException
	{
		setErrorListenerXMLSource(urlXML.toString());
		try
		{
			Result resultHTML = new StreamResult(writer);
			doTransform(CXMLSourceSupplier.fromURL(urlXML), resultHTML);
		}
		finally
		{
			setErrorListenerXMLSource(null);
		}
	}

	private void doTransform(CXMLSourceSupplier xmlSourceSupplier, Result resultHTML) throws TransformerException
	{
			try
			{
					setErrorListenerTransformAttempt(1);
					m_XSLTransformer.transform(xmlSourceSupplier.get(), resultHTML);
			}
			catch(TransformerException e)
			{
					// Second attempt in case of IOException
					if (isTransformerExceptionCausedByIOException(e))
					{
							setErrorListenerTransformAttempt(2);
							m_XSLTransformer.transform(xmlSourceSupplier.get(), resultHTML);
							CTraceLog.warning("Transformation is done on second attempt.",
									HTMLTransformer.class.getName() + ".doTransform()",
									new CProperties().setProperty("xsltUrl", m_sXsltUrl));
					}
					else
					{
							throw e;
					}
			}
	}

	protected static boolean isTransformerExceptionCausedByIOException(TransformerException transformerException)
	{
			Throwable cause = transformerException.getException();
			try // Oracle-specific extraction of the cause
			{
					int nCauseLevel = 0;
					while(nCauseLevel++ < 100 && cause instanceof oracle.xml.util.XMLException)
					{
							cause = ((oracle.xml.util.XMLException) cause).getException(0);
					}
			}
			catch(Throwable t)
			{
					cause = transformerException.getException();
			}

			return ExceptionUtils.unwrap((cause != null ? cause : transformerException), java.io.IOException.class) != null;
	}

	private static void registerError(String sXsltUrl, String sXmlSource, @SuppressWarnings("unused") Throwable error)
	{
		// do nothing
	}
	
	public String transform(String sXML) throws TransformerException
	{
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		try
		{
			transform(sXML, outputStream);
			outputStream.flush();
			return outputStream.toString();
		}
		catch (TransformerException e)
		{
			registerError(getXsltUrl(), sXML, e);
			throw e;
		}
		catch (IOException ioe)
		{
			registerError(getXsltUrl(), sXML, ioe);
			throw new TransformerException(ioe);
		}
		catch (Throwable e)
		{
			registerError(getXsltUrl(), sXML, e);
			throw new TransformerException(e);
		}
		finally
		{
			try {outputStream.close();} catch (IOException ioe) {}
		}
	}
	
	public static String transform(String sXML, String sXsltUrl) throws TransformerException
	{
		final HTMLTransformer transformer;
		try
		{
			transformer = new HTMLTransformer(new URL(sXsltUrl));
		}
		catch (MalformedURLException urlEx)
		{
			registerError(sXsltUrl, "-", urlEx);
			throw new TransformerException(urlEx);
		}
		
		return transformer.transform( sXML );
	}

	public void transform(Source in, Writer out)
		throws TransformerException
	{
		Result resultHTML = new StreamResult(out);
		m_XSLTransformer.transform(in, resultHTML);
	}

	/**
	 * Set transformer parameter.
	 * 
	 * @param sParamName
	 * @param paramValue
	 */
	public void setParameter(String sParamName, Object paramValue)
	{
		m_XSLTransformer.setParameter(sParamName, paramValue);
	}
	/* Static members ***********************************************************************/
	protected static TransformerFactory getTransformerFactory()
	{
		return getTransformerFactory(CStringUtils.EMPTY_STRING);
	}

	protected static TransformerFactory getTransformerFactory(String sTransformerType)
	{
			return getTransformerFactory(sTransformerType, new CTransformerFactoryErrorListener(HTMLTransformer.class));
	}

	protected static TransformerFactory getTransformerFactory(String sTransformerType, ErrorListener errorListener)
	{
		if( m_transformerTypeOverride.get() != null )
		{
			sTransformerType = m_transformerTypeOverride.get();
		}
		
		TransformerFactory transformerFactory = null;
		if (CStringUtils.isEmpty(sTransformerType))
		{
			sTransformerType = System.getProperty(PROP_TRANSFORMER_TYPE);
		}
		if (XALAN_TRANSFORMER.equals(sTransformerType))
		{
			transformerFactory = new org.apache.xalan.processor.TransformerFactoryImpl();
		}
		else if (TRANSFORMER_SYSDEFAULT.equalsIgnoreCase(sTransformerType))
		{
			transformerFactory = TransformerFactory.newInstance();
		}		
		else
		{
			/*
			 * APodlipski 2009-01-30: Force usage of Oracle XSLT transformer, since any other 
			 * won't work with invalid XSLT templates.
			 * MSuhhoruki 2011-08-11 changed to Class.forName
			 */
			try
			{
				transformerFactory = (TransformerFactory) Class.forName("oracle.xml.jaxp.JXSAXTransformerFactory").newInstance();
			}
			catch (Exception e)
			{
				// for HTMLTransformers on IAS that use default parser but can't define container args (too risky)
				transformerFactory = TransformerFactory.newInstance();
				//  throw CRuntimeException.wrap(e);
			}
		}
		
		transformerFactory.setErrorListener(errorListener);
		return transformerFactory;
	}

	public static void setCacheTransformers(boolean bCache)
	{
		m_bIsXsltCacheEnabled = bCache;
	}

	public static Transformer getCachedTransformer(String sXsltUrl) throws TransformerConfigurationException
	{
		return getCachedTransformer(sXsltUrl, CStringUtils.EMPTY_STRING);
	}
	
	public static Transformer getCachedTransformer(String sXsltUrl, String sTransformerType) throws TransformerConfigurationException
	{
		if (!m_bIsXsltCacheEnabled)
			return parseXslt(sXsltUrl, sTransformerType).newTransformer();

		final Templates tXSL;
		String sSource = "0";
		Element el = getCache().get(sXsltUrl);
		if (el == null )
		{
			tXSL = parseXslt(sXsltUrl, sTransformerType);
			el = new Element(sXsltUrl, tXSL);
			getCache().put(el);
			sSource = "1";
		}
		else
		{
			tXSL = (Templates) el.getObjectValue();
			sSource = "2";
		}

		if(tXSL == null)
		{
			CTraceLog.error("tXSL for " + sTransformerType + ":" + sXsltUrl  + " is null, " + sSource, HTMLTransformer.class.getName() + ".load()");
		}
						
		
		// This just copies the transformer object to be therad-safe
		return tXSL.newTransformer();
	}

	public static void resetCache()
	{
		getCache().removeAll();
	}

	public static boolean isOracleParserAvailable()
	{
		String sSaxParser = System.getProperty(PROP_SAX_PARSER);
		if (sSaxParser == null)
			return false;
		else if (!sSaxParser.equals(ORACLE_PARSER))
			return false;

		Class<?> oracleParser;
		try
		{
			oracleParser = Class.forName(sSaxParser);
		}
		catch (Exception e)
		{
			return false;
		}

		if (!javax.xml.parsers.SAXParserFactory.class.isAssignableFrom(oracleParser))
			throw new RuntimeException(sSaxParser + "is not standard SAX parser");
		return true;
	}

	public static boolean isOracleParser(TransformerFactory xsltFactory)
	{
		return xsltFactory.getClass().getName().equals("oracle.xml.jaxp.JXSAXTransformerFactory");

	}

	private static Cache getCache()
	{
		if (m_xsltCache == null)
		{
			synchronized (lock)
			{
				if (m_xsltCache == null)
				{
					CacheManager cacheManager = CacheManager.create();
					final String sCacheName = HTMLTransformer.class.getName();
					m_xsltCache = cacheManager.getCache(sCacheName);
					if (m_xsltCache == null)
					{
						cacheManager.addCache(sCacheName);
						m_xsltCache = cacheManager.getCache(sCacheName);
					}
				}
			}
		}

		return m_xsltCache;
	}
	
	/**
	 * Override transformer type. This is needed to make transformation of "invalid" xslt work using oracle parser.
	 * VERY IMPORTANT: reset this override after use in try/finally!
	 *
	 * @param sTransformerType
	 */
	public static void setCurrentThreadTransformerTypeOverride( String sTransformerType )
	{
		m_transformerTypeOverride.set( sTransformerType );
	}
	
	/*
	private static final class CTransformerCache extends CCache
	{
		// TODO	remove this member, and configure HTML Cache in file "ehcache.xml"
		private boolean m_bIsXsltCacheEnabled = true;

		CTransformerCache()
		{
			super(HTMLTransformer.class);
		}

		Templates loadXslt(String sXsltUrl)
		{
			CXsltTemplates templates;
			if (m_bIsXsltCacheEnabled)
				templates = (CXsltTemplates) get(sXsltUrl, new CArguments(sXsltUrl));
			else
				templates = (CXsltTemplates) load(new CArguments(sXsltUrl));

			return templates.getTemplates();
		}

		public void setCacheEnabled(boolean bCache)
		{
			m_bIsXsltCacheEnabled = bCache;
			// TODO	Use method super.setCacheEnabled(bCache);
		}
	}
	*/

	protected static Templates parseXslt(String sXsltUrl)
	{
		return parseXslt(sXsltUrl, CStringUtils.EMPTY_STRING);
	}

	/**
	 * Loads and parses XSL templates. Two attempts are made.
	 * @param sXsltUrl XSL file URL
	 * @param sTransformerType XSL transformer type
	 * @return Templates XSL templates
	 */
	protected static Templates parseXslt(String sXsltUrl, String sTransformerType)
	{
		CTransformerFactoryErrorListener errorListener = new CTransformerFactoryErrorListener(HTMLTransformer.class, sXsltUrl);
		TransformerFactory xsltFactory = getTransformerFactory(sTransformerType, errorListener);
		int nAttempt = 1;
		try
		{
				boolean bDoSecondAttempt;
				Exception firstAttemptException;
				try
				{
						errorListener.setAttempt(nAttempt);
						return parseTemplates(sXsltUrl, xsltFactory);
				}
				catch (IOException e)
				{
						bDoSecondAttempt = true;
						firstAttemptException = e;
				}
				catch (TransformerConfigurationException e)
				{
						bDoSecondAttempt = isTransformerExceptionCausedByIOException(e);
						firstAttemptException = e;
				}
				catch (Exception e)
				{
						bDoSecondAttempt = ExceptionUtils.unwrap(e, java.io.IOException.class) != null;
						firstAttemptException = e;
				}

				if (bDoSecondAttempt)
				{
						CTraceLog.warning(firstAttemptException, HTMLTransformer.class.getName() + ".load()",
								new CProperties()
										.setProperty("TransformerFactory", xsltFactory.getClass().getName())
										.setProperty("xsltUrl", sXsltUrl)
										.setProperty("attempt", nAttempt));

						// Second attempt
						errorListener.setAttempt(++nAttempt);
						return parseTemplates(sXsltUrl, xsltFactory);
				}
				else
				{
						throw firstAttemptException;
				}
		}
		catch (Exception e)
		{
				CProperties params = new CProperties()
						.setProperty("TransformerFactory", xsltFactory.getClass().getName())
						.setProperty("xsltUrl", sXsltUrl)
						.setProperty("attempt", nAttempt);

				CTraceLog.error(e, HTMLTransformer.class.getName() + ".load()", params);
				// Throw an exception with invalid XSLT content
				throw new CRuntimeException("Invalid XSLT [" + sXsltUrl + "]", e, HTMLTransformer.class.getName() + ".load()", params);
		}
	}

	/**
	 * Parses XSL template using given transformer factory.
	 * @param sXsltUrl XSL file URL
	 * @param xsltFactory Transformer factory instance
	 * @return Templates XSL templates
	 * @throws Exception any exception
	 */
	private static Templates parseTemplates(String sXsltUrl, TransformerFactory xsltFactory)
			throws IOException, TransformerConfigurationException
	{
		Source sourceXSL;

		if (isOracleParser(xsltFactory))
		{
			sourceXSL = new StreamSource(sXsltUrl);
		}
		else
		{
			// String sXsltContent = CFileContent.getContent(sXsltUrl);
			// sXsltContent = sXsltContent.replaceAll("&nbsp;", "&#160;");
			// sourceXSL =  new StreamSource(new StringReader(sXsltContent));
			Reader reader = new InputStreamReader(new URL(sXsltUrl).openStream());
			Reader normalizer = new XsltNormalizer(new BufferedReader(reader));
			sourceXSL = new StreamSource(normalizer, sXsltUrl);
		}

		return xsltFactory.newTemplates(sourceXSL);
	}

	/**
	 * Loads content of given XSL file as string or stack trace of exception if any occurred.
	 * @param sXsltUrl
	 */
	private static String getContentOrTracelog(String sXsltUrl)
	{
		String sXsltContent;
		try
		{
			sXsltContent = CFileContent.getContent(sXsltUrl);
		}
		catch (Exception ioe)
		{
			registerError(sXsltUrl, "-", ioe);
			sXsltContent = CStackTrace.getStackTrace(ioe);
		}
		return sXsltContent;
	}

	private void setErrorListenerXMLSource(String sXMLSource) 
	{
		if (m_xsltErrorListener instanceof CXSLTErrorListener)
		{
			((CXSLTErrorListener) m_xsltErrorListener).setXmlSource(sXMLSource);
		}
	}
	
	private void setErrorListenerXMLSourceNode(Node node) 
	{
		if (m_xsltErrorListener instanceof CXSLTErrorListener)
		{
			((CXSLTErrorListener) m_xsltErrorListener).setXmlSource(node);
		}
	}

	private void setErrorListenerTransformAttempt(int nAttempt)
	{
			if (m_xsltErrorListener instanceof CXSLTErrorListener)
			{
					((CXSLTErrorListener) m_xsltErrorListener).setAttempt(nAttempt);
			}
	}
	
	/**
	 * Creates StreamSource for given content of XSLT passed as string
	 * @param szXSLSource Content of XSLT as is
	 */
	private static StreamSource createStreamSource(String szXSLSource)
	{
		String sHttpResRoot = null;
		try
		{
			sHttpResRoot = GeneralSettings.getHttpResRoot();
		}
		catch(Throwable e)
		{
			CTraceLog.warning("Can not get HTTP Resource Root. Undefined System ID will be used",
					HTMLTransformer.class.getName() + ".getHttpResourceRoot");
		}
		
		if (CStringUtils.isNotEmpty(sHttpResRoot))
		{
			return new StreamSource(new StringReader(szXSLSource), sHttpResRoot);
		}
		else
		{
			return new StreamSource(new StringReader(szXSLSource));
		}
	}

	private abstract static class CXMLSourceSupplier
	{
			abstract Source get();

			static CXMLSourceSupplier fromString(final String sXML)
			{
					return new CXMLSourceSupplier() {
							@Override Source get()
							{
									return new SAXSource(new InputSource(new StringReader(sXML)));
							}
					};
			}

			static CXMLSourceSupplier fromDomNode(final Node domNode)
			{
					return new CXMLSourceSupplier() {
							@Override Source get()
							{
									return new DOMSource(domNode);
							}
					};
			}

			static CXMLSourceSupplier fromURL(final URL urlXML)
			{
					return new CXMLSourceSupplier() {
							@Override Source get()
							{
									return new SAXSource(new InputSource(urlXML.toString()));
							}
					};
			}
	}
}

