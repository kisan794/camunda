/*
 * @(#)$RCSfile: HTMLCompiler.java,v $ $Revision: 1.12 $ $Date: 2008/03/26 15:52:25 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/HTMLCompiler.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2001				A.Keks				created
 *	2002-05-27	A.Keks				removed member variables
 *	2004-12-14	A.Solntsev		Added tracelog Parameters. Fixed tracelog source.
 *	2007-10-23	A.Solntsev		Findbugs: Removed creating unused instance of XMLDocument
 *	2007-11-26	A.Solntsev		NetTracking.registerUrl();
 *	2008-03-23	A.Solntsev		Fixed exception handling: throw exception instead of logging
 */
package hireright.sdk.transform;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.format_util.CFString;
import hireright.sdk.net.NetTracking;
import hireright.sdk.util.CProperties;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URL;

import oracle.xml.parser.v2.DOMParser;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XSLProcessor;
import oracle.xml.parser.v2.XSLStylesheet;
import oracle.xml.util.XMLException;

import org.w3c.dom.Node;
import org.xml.sax.SAXException;

/**
 * de-pre-cated use hireright.sdk.transform.HTMLTransformer instead
 * @version $Revision: 1.12 $ $Date: 2008/03/26 15:52:25 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/HTMLCompiler.java,v $
 */
public class HTMLCompiler
{
	protected static final String CLASS_VERSION = "$Revision: 1.12 $ $Author: asolntsev $";
	
	/**
	 * This is a protected function to do the general preparation for processing
	 * This is called by private function to do the actual processing to XMLDocument or String
	 *
	 * @param rdXMLSource			java.io.Reader
	 * @param rdXMLSourceAdd		java.io.Reader
	 * @param strBaseURL			java.lang.String
	 * @return XMLDocument (?)
	 */
	protected static final XMLDocument prepareHTMLDocumentFromReader(
									Reader rdXMLSource, Reader rdXMLSourceAdd, String strBaseURL)
	{
		try
		{
			DOMParser parser = new DOMParser();

			// Parse xsl and xml documents

			parser.setPreserveWhitespace(true);

			// parser input XML file
			if (strBaseURL != null)
				parser.setBaseURL(new java.net.URL(strBaseURL));
			parser.parse(rdXMLSource);
			XMLDocument xmlDoc = parser.getDocument();

			// parser input XML additional file

			if (rdXMLSourceAdd != null)
			{
				parser.parse(rdXMLSourceAdd);
				XMLDocument xmlDocAdd = parser.getDocument();
				//Node xmlnode = xmlDocAdd.getSrcRoot().getFirstChild();
				Node xmlnode = xmlDocAdd.getFirstChild();
				Node importNodeResult = xmlDoc.importNode(xmlnode, true);
				//Node node = xmlDoc.getSrcRoot().getChildNodes().item(2);
				Node node = xmlDoc.getChildNodes().item(2);
				node.appendChild(importNodeResult);
			}

			return xmlDoc;
		}
		catch (oracle.xml.parser.v2.XMLParseException pe)
		{
			CProperties params = new CProperties()
					.setProperty("strBaseURL", strBaseURL);

			// Formats full error message
			int num = pe.getNumMessages();

			StringBuffer sb = new StringBuffer(512*num);
			for (int i=0; i < num; i++)
			{
				sb.append("\n\n === Error Message ").append(i).append(" : === \n").append(pe.formatErrorMessage(i));
			}
			CTraceLog.fatal(pe, HTMLCompiler.class.getName() + ".prepareHTMLDocumentFromReader()", params, sb.toString());
		}
		catch (Exception e)
		{
			CProperties params = new CProperties()
					.setProperty("strBaseURL", strBaseURL);
			CTraceLog.fatal(e, HTMLCompiler.class.getName() + ".prepareHTMLDocumentFromReader()", params);
		}
		return null;
	}

	public static final String correctHTMLCode(String htmlDoc)
	{
		try
		{
			CFString cfString = new hireright.sdk.format_util.CFString(htmlDoc);
			cfString.replace("&apos;", "'");
/*			cfString.replace("[[CDATA_START]]", "<![CDATA[");
			cfString.replace("[[CDATA_END]]", "]]>");
			cfString.replace("<space/>", "&nbsp;");
			cfString.replace("<nulltag/>", ""); // Just remove all nulltag's (used for forming correct textareas)
			cfString.replace("&#39;", "'");
			cfString.replace("&#38;", "&");
			cfString.replace("/>", " />");
*/
		return cfString.toString();
		}
		catch (Exception e)
		{
			CTraceLog.fatal(e, HTMLCompiler.class.getName() + ".correctHTMLCode()", htmlDoc);
			return "";
		}
	}

	public static final XMLDocument getHTMLDocumentFromReader(Reader rdXMLSource,
										Reader rdXMLSourceAdd, String strXSLURL, String strBaseURL)
	{
		NetTracking.registerUrl(strBaseURL);
		NetTracking.registerUrl(strXSLURL);

		// Prepare for processing
		XMLDocument	xmlDoc = prepareHTMLDocumentFromReader(rdXMLSource, rdXMLSourceAdd, strBaseURL);
		// Returns values to xmlDoc, xslSSheet and processor

		XMLDocument	outDoc = null;

		try
		{
			// create an output document to hold the result
			outDoc = new XMLDocument();

			// Process XSL
			DOMParser parser = new DOMParser();
			parser.setPreserveWhitespace(true);
			parser.parse(strXSLURL);
			XSLProcessor processor = new XSLProcessor();

			processor.showWarnings(true);
			processor.setErrorStream(System.err);
			outDoc.appendChild(processor.processXSL(new XSLStylesheet(parser.getDocument(), new URL(strXSLURL)), xmlDoc));
		}
		catch (Exception e)
		{
			CProperties params = new CProperties()
						.setProperty("strXSLURL", strXSLURL)
						.setProperty("strBaseURL", strBaseURL);
			CTraceLog.fatal(e, HTMLCompiler.class.getName() + ".getHTMLDocumentFromReader()", params);
		}

		return outDoc;
	}

	public static final XMLDocument getHTMLDocumentFromReader(Reader rdXMLSource, String strXSLURL)
	{
		return	getHTMLDocumentFromReader(rdXMLSource, null, strXSLURL, null);
	}

	public static final String getHTMLDocumentFromReaderAsString(Reader rdXMLSource,
				Reader rdXMLSourceAdd, String strXSLURL, String strBaseURL) throws XsltException 
	{
		NetTracking.registerUrl(strBaseURL);
		NetTracking.registerUrl(strXSLURL);

		// Prepare for processing
		XMLDocument	xmlDoc = prepareHTMLDocumentFromReader(rdXMLSource, rdXMLSourceAdd, strBaseURL);
		// Returns values to xmlDoc, xslSSheet and processor

		StringWriter swOut = new StringWriter(4096);
		PrintWriter pwOut = new PrintWriter(swOut);

		try
		{
			// Process XSL
			DOMParser parser = new DOMParser();
			parser.setPreserveWhitespace(true);
			parser.parse(strXSLURL);
			XSLProcessor processor = new XSLProcessor();

			// display any warnings that may occur
			processor.showWarnings(true);
			processor.setErrorStream(System.err);
			processor.processXSL(new XSLStylesheet(parser.getDocument(), new URL(strXSLURL)), xmlDoc, pwOut);
		}
		catch (XMLException e)
		{
			CProperties params = new CProperties()
					.setProperty("strXSLURL", strXSLURL)
					.setProperty("strBaseURL", strBaseURL);
			// CTraceLog.fatal(e, HTMLCompiler.class.getName() + ".getHTMLDocumentFromReaderAsString()", params, String.valueOf(xmlDoc));
			throw new XsltException(e, params, String.valueOf(xmlDoc));
		}
		catch (SAXException e)
		{
			CProperties params = new CProperties()
				.setProperty("strXSLURL", strXSLURL)
				.setProperty("strBaseURL", strBaseURL);
			throw new XsltException(e, params, String.valueOf(xmlDoc));
		}
		catch (IOException e)
		{
			CProperties params = new CProperties()
				.setProperty("strXSLURL", strXSLURL)
				.setProperty("strBaseURL", strBaseURL);
			throw new XsltException(e, params, String.valueOf(xmlDoc));
		}

		return correctHTMLCode(swOut.toString());
	}

	public static final String getHTMLDocumentFromReaderAsString(Reader rdXMLSource, String strXSLURL) throws XsltException
	{
		return getHTMLDocumentFromReaderAsString(rdXMLSource, null, strXSLURL, null);
	}

	public static final XMLDocument getHTMLDocument(String strXMLURL, String strXSLURL) throws IOException
	{
		NetTracking.registerUrl(strXMLURL);
		URL url = new URL(strXMLURL);
		return getHTMLDocumentFromReader(new InputStreamReader(url.openStream()), strXSLURL);
	}

	public static final String getHTMLDocumentAsString(String strXMLURL, String strXSLURL) throws IOException, XsltException
	{
		NetTracking.registerUrl(strXMLURL);
		URL url = new URL(strXMLURL);
		return getHTMLDocumentFromReaderAsString(new InputStreamReader(url.openStream()), strXSLURL);
	}

	public static final String getHTMLDocumentFromStringAsString(String strXMLSource, String strXSLURL) throws XsltException
	{
		return getHTMLDocumentFromStringAsString(strXMLSource, null, strXSLURL, null);
	}

	public static final String getHTMLDocumentFromStringAsString(String strXMLSource, String strXMLSourceAdd, String strXSLURL, 
			String strBaseURL) throws XsltException
	{
		return getHTMLDocumentFromReaderAsString(new StringReader(strXMLSource) , strXMLSourceAdd != null ? 
				new StringReader(strXMLSourceAdd) : null, strXSLURL, strBaseURL);
	}
}

