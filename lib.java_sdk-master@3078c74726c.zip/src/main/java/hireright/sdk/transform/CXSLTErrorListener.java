/*
 * @(#)$RCSfile: CXSLTErrorListener.java,v $ $Revision: 1.7 $ $Date: 2009/07/10 09:27:08 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/CXSLTErrorListener.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2005-10-19	D.Belorunov		Created
 *  2006-11-23	A.Solntsev		Now class CXSLTErrorListener holds URL of current XSLT
 *  2007-03-13	A.Solntsev		Added XML Source when logging errors
 *  2007-10-19	M.Karpov		Added XML Source as org.w3c.dom.Node, for better perfomance
 *  2020-02-07	V.Ozernov		HIVPE-101806 Added transformAttempt for logging
 *  2020-08-05	V.Ozernov		HRG-129092 change log level ERROR/FATAL -> WARNING for cases when current attempt is the first and the exception caused by IOException
 */
package hireright.sdk.transform;

import hireright.sdk.xml.utils.CXMLDOMActions;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IHasProperties;

import javax.xml.transform.ErrorListener;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Node;

/**
 * Class that logs all errors and warnings during XSLT transformation.
 *
 * @author Denis Belorunov
 * @version $Revision: 1.7 $ $Date: 2009/07/10 09:27:08 $ $Author: asolntsev $
 */
public class CXSLTErrorListener extends CTransformerFactoryErrorListener implements ErrorListener, IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: asolntsev $";
	
	/**
	 * Contains the entire XML being transformed.
	 * It's used for logging if present.
	 */
	private String m_sXmlSource = null;

	/**
	 * Contains the entire XML being transformed.
	 * It's used for logging if present.
	 */
	private Node m_sXmlSourceAsNode = null;

	/**
	 * Creates new instance.
	 * @param sXsltUrl URL of XSLT
	 */
	public CXSLTErrorListener(String sXsltUrl)
	{
		this(CXSLTErrorListener.class, sXsltUrl);
	}

	/**
	 * Creates new instance.
	 *
	 * @param clazz Class that is used for obtaining source of error.
	 * @param sXsltUrl URL of XSLT
	 */
	public CXSLTErrorListener(Class<?> clazz, String sXsltUrl)
	{
		super(clazz, sXsltUrl);
	}

	public CProperties toProperties()
	{
		return super.toProperties()
			.setProperty("xmlSource", CStringUtils.truncate(m_sXmlSource, 20))
			.setProperty("m_sXmlSourceAsNode", 
					m_sXmlSourceAsNode != null ?
							CStringUtils.truncate(CXMLDOMActions.xmlToString(m_sXmlSourceAsNode), 20) : null);
	}

	/**
	 * Logs warning
	 *
	 * @param transformerException
	 * @throws TransformerException
	 */
	@Override
	public void warning(TransformerException transformerException) throws TransformerException
	{
			super.warning(transformerException);
	}

	/**
	 * Logs error
	 *
	 * @param transformerException
	 * @throws TransformerException
	 */
	public void error(TransformerException transformerException) throws TransformerException
	{
			super.error(transformerException);
			throw transformerException;
	}

	/**
	 * Logs fatal error
	 *
	 * @param transformerException
	 * @throws TransformerException
	 */
	public void fatalError(TransformerException transformerException) throws TransformerException
	{
			super.fatalError(transformerException);
			throw transformerException;
	}

	@Override
	protected String getLogPayload()
	{
			return getXmlSource();
	}

	/**
	 * Return xml source depending on what is set
	 * 
	 * @return String representation of xml source
	 */
	private String getXmlSource()
	{
		return m_sXmlSourceAsNode != null ? CXMLDOMActions.xmlToString(m_sXmlSourceAsNode) : m_sXmlSource;
	}

	protected void setXmlSource(String sXmlSource)
	{
		m_sXmlSource = sXmlSource;
	}
	
	protected void setXmlSource(Node node)
	{
		m_sXmlSourceAsNode = node;
	}

}
