/*
 * @(#)$RCSfile: IPDFBuilderSPI.java,v $ $Revision: 1.2 $ $Date: 2014/11/01 08:24:34 $ $Author: cvsroot $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	atanasenko	03.10.2014	Created
 */
package hireright.sdk.transform.pdf.spi;

import hireright.sdk.transform.pdf.CPDFBuilderType;
import hireright.sdk.transform.pdf.IPDFBuilder;

public interface IPDFBuilderSPI {
	
	public CPDFBuilderType getType();
	
	public IPDFBuilder createBuilder(String baseUrl);
	
}
