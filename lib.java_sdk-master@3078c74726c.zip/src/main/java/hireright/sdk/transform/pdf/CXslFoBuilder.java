/*
 * @(#)$RCSfile: CXslFoBuilder.java,v $ $Revision: 1.3 $ $Date: 2010/10/01 06:46:49 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/pdf/CXslFoBuilder.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	2010-09-08	O.Chursina			initial version
  */
package hireright.sdk.transform.pdf;


import hireright.sdk.transform.PDFCompiler;
import hireright.sdk.transform.PDFException;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;

/**
 * Convert Html to PDF using XSLFO
 * 
 * @deprecated use new class @hireright.sdk.transform.pdf.CXHtmlRendererBuilder
 */
@Deprecated 
public class CXslFoBuilder extends CAbstractPDFBuilder
{
	CXslFoBuilder()
	{
	}
	
	/**
	 * @see IPDFBuilder#createPDF(String, java.net.URL, OutputStream)
	 */
	public void createPDF(String sHtmlInput, OutputStream outputPDF) throws PDFException
	{
		throw new CRuntimeException("["+ this.getClass().getName() + "]" + " Unsupported method");
	}

	/**
	 * @see CAbstractPDFBuilder#createPDF(String, java.net.URL, OutputStream)
	 */
	public void createPDF(String xmlData, URL templateURL, OutputStream outputPDF) throws PDFException
	{
		try
		{
			outputPDF.write(PDFCompiler.convertXML2PDF(xmlData, templateURL));
		}
		catch (IOException e) 
		{
			CProperties errProperties = new CProperties();
			throw new PDFException(e.getMessage(), errProperties);
		}
		
	}

}
