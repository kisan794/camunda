/*
 * @(#)$RCSfile: CPDFBuilderType.java,v $ $Revision: 1.3 $ $Date: 2012/09/07 07:31:13 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/pdf/CPDFBuilderType.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	2010-09-08	O.Chursina			initial version
 * 	2012-09-08	S.Ignatov				XHTML_PREPARED type
 */
package hireright.sdk.transform.pdf;

/**
 * 
 * Enum contains all types of PDF generators that used within HireRight. 
 * 
 * @author Olga_Chursina
 *
 */
public enum CPDFBuilderType
{
		FAST_CGI,
		XHTML_RENDERER, 
		XSL_FO,
		XHTML_PREPARED,
		WEBKIT_RENDERER
}
