/*
 * @(#)$RCSfile: IPDFBuilder.java,v $ $Revision: 1.2 $ $Date: 2010/09/21 11:46:48 $ $Author: ochursina_epam $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/pdf/IPDFBuilder.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	2010-09-08	O.Chursina			initial version
  */
package hireright.sdk.transform.pdf;

import hireright.sdk.transform.PDFException;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;

public interface IPDFBuilder
{
	/**
	 * Creates pdf from input (x)html
	 * 
	 * @param sHtmlInput html input
	 * @param outputPDF pdf output
	 * @throws IOException
	 */
	public void createPDF(String sHtmlInput, OutputStream outputPDF) throws PDFException;
	
	/**
	 * Creates pdf from input data, stylesheet and writes it into the output.
	 *
	 * @param xmlData input data for template.
	 * @param templateURL url of template.
	 * @param outputPDF pdf output
	 * @throws IOException
	 */
	public void createPDF(String xmlData, URL templateURL, OutputStream outputPDF) throws PDFException;
}
