/*
 * @(#)$RCSfile: CAbstractPDFBuilder.java,v $ $Revision: 1.3 $ $Date: 2010/10/01 06:46:37 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/pdf/CAbstractPDFBuilder.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	2010-09-08	O.Chursina			initial version
  */ 
package hireright.sdk.transform.pdf;

import hireright.sdk.transform.HTMLTransformer;
import hireright.sdk.transform.PDFException;
import hireright.sdk.util.CProperties;

import java.io.OutputStream;
import java.net.URL;

import javax.xml.transform.TransformerException;

/**
 * 
 * Represents an abstract builder for PDF documents.
 * 
 * @author Olga_Chursina
 *
 */
public abstract class CAbstractPDFBuilder implements IPDFBuilder
{
	
	protected String m_baseUrl = "";
	
	protected CAbstractPDFBuilder(String baseUrl)
	{
		this.m_baseUrl = baseUrl;
	}
	
	protected CAbstractPDFBuilder()
	{
	}
	
	/**
	 * @see IPDFBuilder#createPDF(String, java.net.URL, OutputStream)
	 */
	public void createPDF(String xmlData, URL templateURL, OutputStream outputPDF) throws PDFException
	{
		String sHtmlInput = "";
		
		try
		{
			sHtmlInput = HTMLTransformer.transform(xmlData, templateURL.toString());
		}
		catch (TransformerException e) 
		{
			CProperties errProperties = new CProperties();
			throw new PDFException(e.getMessage(), errProperties);
		}
		
		createPDF(sHtmlInput, outputPDF);
	}

}
