/*
 * @(#)$RCSfile: CPDFBuilderFactory.java,v $ $Revision: 1.5 $ $Date: 2014/11/01 08:24:05 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/pdf/CPDFBuilderFactory.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	2010-09-08	O.Chursina			initial version
 * 	2012-09-08	S.Ignatov				added CPreparedXhtmlRendererBuilder
 */
package hireright.sdk.transform.pdf;


import hireright.sdk.transform.pdf.spi.IPDFBuilderSPI;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.imageio.spi.ServiceRegistry;

public class CPDFBuilderFactory
{
	/** Factory instance */
	private static class Holder
	{
		private static final CPDFBuilderFactory factoryInstance = new CPDFBuilderFactory();
	}
	
	/**
	 * Map with pdf builder implementations.
	 */
	private final Map<CPDFBuilderType, IPDFBuilderSPI> m_pdfBuilderMap;
	
	private CPDFBuilderFactory()
	{
		m_pdfBuilderMap = new HashMap<CPDFBuilderType, IPDFBuilderSPI>();
		registerBuilders();
	}
	
	/**
	 * Get an instance of transformation tracer.
	 * 
	 * @return Transformation tracer instance.
	 */
	public static CPDFBuilderFactory getInstance()
	{
		return Holder.factoryInstance;
	}
	
	/**
	 * Gets builder for sprcified builder type
	 * 
	 * @param builder type.
	 * @return IPDFBuilder builder for specified type.
	 */
	public IPDFBuilder getBuilder(CPDFBuilderType builderType)
	{
		return getBuilder(builderType, null);
	}
	
	/**
	 * Gets builder for sprcified builder type
	 * 
	 * @param builder type.
	 * @return IPDFBuilder builder for specified type.
	 */
	public IPDFBuilder getBuilder(CPDFBuilderType builderType, String baseUrl)
	{
		if(m_pdfBuilderMap.containsKey(builderType))
		{
			IPDFBuilderSPI spi = m_pdfBuilderMap.get(builderType);
			if(spi != null)
			{
				return spi.createBuilder(baseUrl);
			}
		}
		throw new IllegalStateException("No PDF builder of type " + builderType + ", available types: " + m_pdfBuilderMap.keySet());
	}
	
	/**
	 * Registers CPDFBuilder implementations.
	 */
	protected final void registerBuilders()
	{
		Iterator<IPDFBuilderSPI> it = ServiceRegistry.lookupProviders(IPDFBuilderSPI.class);
		while(it.hasNext())
		{
			IPDFBuilderSPI spi = it.next();
			m_pdfBuilderMap.put(spi.getType(), spi);
		}
	}
}
