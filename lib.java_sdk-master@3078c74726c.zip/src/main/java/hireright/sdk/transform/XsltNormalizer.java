/*
 * @(#)$RCSfile: XsltNormalizer.java,v $ $Revision: 1.3 $ $Date: 2007/09/14 09:01:03 $ $Author: asolntsev $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev	2006-11-05	Created XsltNormalizer for non-ORacle SAX parsers
 */
package hireright.sdk.transform;

import java.io.BufferedReader;
import java.io.IOException;

/**
 * Class removes all "&nbsp;" entries from origianl XSLT file.
 * "&nbsp;" is not XSLT-compliant. It's supported only by Oracle parser.
 * Insteaf of "&nbsp;" a standard entry "&#160;" should be used. 
 * 
 * @author asolntsev
 * @since Nov 5, 2006
 */
public class XsltNormalizer extends BufferedReader
{
	public XsltNormalizer(BufferedReader delegatingReader)
	{
		super(delegatingReader);
	}
	
	public String readLine() throws IOException
	{
		String sLine = super.readLine();
		sLine = replace(sLine);
		return sLine;
	}
	
	static String replace(String sFileRow)
	{
		return sFileRow.replaceAll("&nbsp;", "&#160;");
		// sFileRow = sFileRow.replaceAll("&nbsp;", " ");
		// return sFileRow;
	}
}
