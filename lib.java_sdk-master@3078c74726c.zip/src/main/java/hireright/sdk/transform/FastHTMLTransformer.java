/*
 * @(#)$RCSfile: FastHTMLTransformer.java,v $ $Revision: 1.5 $ $Date: 2007/09/14 09:00:43 $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2001				Anton Keks				Created.
 *  2004-05-28	Andrei Solntsev		Removed "brIn.ready()"
 */

package hireright.sdk.transform;

import java.io.*;
import java.net.*;

/**
 * A class for transforming an XML to HTML using XSL
 * Uses external FastCGI script for transforming data which is written in C
 *
 * @author Anton Keks
 * 2001 created
 */
public class FastHTMLTransformer
{
	public static final String transform(String szXSLURL, String szXMLSource) throws Exception
	{
		/////////////////////////////////////////////////////////////////////////
		///// TODO: hardcoded address!!!!!!!!!!!!!!!!!!
		///// It must be moved to GeneralSettings
		/////////////////////////////////////////////////////////////////////////
		URL urlTransformer = new URL("http://oraapp01/fcgi-bin/fcgi_transformer");

		HttpURLConnection httpConn;
		PrintWriter pwOut;
		BufferedReader brIn;
		StringBuffer szReturn;

		httpConn = (HttpURLConnection) urlTransformer.openConnection();
		httpConn.setRequestMethod("POST");
		httpConn.setDoOutput(true);

		pwOut = new PrintWriter(httpConn.getOutputStream());

		// Output the first parameter (XSL URL)
		pwOut.print("xsl=" + szXSLURL);

		// Output the second parameter (XML Source)
		pwOut.print("&xml=");
		pwOut.print(szXMLSource);

		pwOut.flush();

		brIn = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));

		szReturn = new StringBuffer();

		String buf;
		while ( (buf=brIn.readLine()) != null )	// Removed "brIn.ready()"
		{
			szReturn.append(buf);
			szReturn.append('\n');
		}

		httpConn.disconnect();

		return szReturn.toString();
	}

	public static final void transform(String szXSLURL, String szXMLSource, Writer wOut) throws Exception
	{
		URL urlTransformer = new URL("http://oraapp01/fcgi-bin/fcgi_transformer");

		HttpURLConnection httpConn;
		PrintWriter pwOut;
		BufferedReader brIn;

		httpConn = (HttpURLConnection) urlTransformer.openConnection();
		httpConn.setRequestMethod("POST");
		httpConn.setDoOutput(true);

		pwOut = new PrintWriter(httpConn.getOutputStream());

		// Output the first parameter (XSL URL)
		pwOut.print("xsl=" + szXSLURL);

		// Output the second parameter (XML Source)
		pwOut.print("&xml=");
		pwOut.print(szXMLSource);

		pwOut.flush();

		brIn = new BufferedReader(new InputStreamReader(httpConn.getInputStream()));

		String buf;
		while ( (buf=brIn.readLine()) != null )	// Removed "brIn.ready()"
		{
			wOut.write(buf);
			wOut.write('\n');
		}

		httpConn.disconnect();
	}
}

