/*
 * @(#)$RCSfile: PDFException.java,v $ $Revision: 1.5 $ $Date: 2008/07/07 15:06:51 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/PDFException.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	2001				A.Keks				created
 *	2004-12-14	A.Solntsev		Added constructor (String, Throwable)
 *	2006-05-04	A.Solntsev		moved to package hireright.transform
 *	2006-05-05	A.Solntsev		Added constructors (..., byte[]) and method getBytes()
 *	2007-09-07	A.Solntsev		Added more constructors
 *	2008-02-28	A.Solntsev		Removed usage of deprecated CException constructors
 *	2008-07-03	P.Bushuk		Remove declaration of m_sData member in PDFException class, beacuse it is alredy in super class.
 */
package hireright.sdk.transform;

import hireright.sdk.util.CException;
import hireright.sdk.util.CProperties;

/**
 * Class implementing Exception while generating PDF document.
 *
 * @author	Anton Keks
 * @version $Revision: 1.5 $ $Date: 2008/07/07 15:06:51 $ $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/transform/PDFException.java,v $
 */
public class PDFException extends CException
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";

	private byte[] m_pdfBytes;

	public PDFException(String szErrorMessage, CProperties properties)
	{
		super(szErrorMessage, properties);
	}

	/**
	 *
	 * @param szErrorMessage
	 * @param pdfBytes array of bytes that occurred to be invalid PDF
	 *
	 * @since java_sdk_v2-6-9
	 */
	public PDFException(String szErrorMessage, byte[] pdfBytes)
	{
		super(szErrorMessage, (CProperties) null);
		m_pdfBytes = pdfBytes;
	}

	public PDFException(String szErrorMessage, Throwable cause, CProperties properties)
	{
		super(szErrorMessage, cause, properties);
	}

	public PDFException(String szErrorMessage, CProperties properties, String sFOPData)
	{
		super(szErrorMessage, properties, sFOPData);
	}

	public PDFException(Throwable cause, CProperties properties, String sFOPData)
	{
		super(cause, properties, sFOPData);
	}

	/**
	 *
	 * @param szErrorMessage
	 * @param pdfBytes	array of bytes that occurred to be invalid PDF
	 * @param cause
	 *
	 * @since java_sdk_v2-6-9
	 */
	public PDFException(String szErrorMessage, Throwable cause, byte[] pdfBytes)
	{
		super(szErrorMessage, cause);
		m_pdfBytes = pdfBytes;
	}

	public String getData()
	{
		if (super.getData() == null && m_pdfBytes != null)
			return new String(m_pdfBytes);

		return super.getData();
	}

	public byte[] getBytes()
	{
		return m_pdfBytes;
	}
}

