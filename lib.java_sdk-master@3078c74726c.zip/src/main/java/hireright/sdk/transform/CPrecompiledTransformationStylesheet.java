/*
 * @(#)$RCSfile: CPrecompiledTransformationStylesheet.java,v $ $Revision: 1.2 $ $Date: 2012/12/14 09:20:28 $ $Author: cvsroot $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  N.Danilov			2012-11-21		Created
 */
package hireright.sdk.transform;

import javax.xml.transform.Transformer;

public class CPrecompiledTransformationStylesheet 
{
	Transformer m_transformer;
	long m_timestamp;

	public CPrecompiledTransformationStylesheet(Transformer transformer)
	{
		this.m_transformer = transformer;
		this.m_timestamp = System.currentTimeMillis();
	}
	
	public Transformer getTransformer()
	{
		return m_transformer;
	}
	public long getCompilationTime()
	{
		return m_timestamp;
	}
}
