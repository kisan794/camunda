/*
 * @(#)$RCSfile: CHTTPPoster.java,v $ $Revision: 1.14 $ $Date: 2009/05/22 06:38:58 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/net/CHTTPPoster.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This	software is	the	confidential and proprietary information
 * of	HireRight, Inc.	Use	is subject to	license	terms.
 *
 * History:
 * 	A.Rudenko		2002-12-10	first stable revision
 *	D.Travin		2003-04-21	HTTP 1.1 Basic Authentication support added
 *	D.Travin		2003-04-22	HTTP 1.1 Proxy Authorization supported
 *	S.Ignatov		2003-11-03	custom Request Properties added; Content-type set method added
 *	Anton Keks		2004-07-21	Superfluous string creation removed to prevent NullPointerExceptions
 *	A.Solntsev		2007-11-26	NetTracking.registerUrl
 *	A.Solntsev		2009-03-09	CHTTPPoster implements Interruptible (now it's possible to break current post if it hangs)
 *	A.Solntsev		2009-04-06	Now supports FileUrlConnection in addition to HttpUrlConnection
 */
package hireright.sdk.net;

import hireright.sdk.util.Base64Encoder;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.IHasProperties;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

/**
 * This class supports publication of messages to any Messaging Gateway.
 * <PRE>
 *
 * Example Usage:
 *          // Instantiate the publisher.
 *          hrPub = new HRPublisher();
 *
 *          String xmlData = "&lt;?xml version=\&quot;1.0\&quot;?&gt;&lt;BUS_EXP_APPR_MSG&gt;.......&lt;/BUS_EXP_APPR_MSG&gt;";
 *          hrPub.setData(xmlData);
 *
 *          // Compress data, compose XML and then publish.
 *          hrPub.publish("http://WebServer/servlets/gateway");
 *
 *          // Check and retrieve response
 *          if (hrPub.getResponseCode() == HttpURLConnection.HTTP_OK)
 *          {
 *              String content = hrPub.getResponseContent();
 *              // Process content
 *              .......
 *              .......
 *          }
 * </PRE>
 * 
 * @author Alexander Rudenko
 * @version $Revision: 1.14 $ $Date: 2009/05/22 06:38:58 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/net/CHTTPPoster.java,v $
 */
public class CHTTPPoster implements IHasProperties	//, sun.nio.ch.Interruptible
{
	protected static final String CLASS_VERSION = "$Revision: 1.14 $ $Author: asolntsev $";
	
    /** Size of byte array buffer. */
    private static final int BUFFER_SIZE = 100;

    /** Composed XML in UTF-8. */
    private byte[]  m_CompleteXML;

    /** HTTP response code from the gateway. */
    private int     m_ResponseCode;

    /** HTTP response message from the gateway. */
    private String  m_ResponseMessage;

    /** Type of the response content from the gateway. */
    private String  m_ResponseContentType;

    /** Length of the response content from the gateway. */
    private int     m_ResponseContentLength;

    /** The response content in UTF-8 from the gateway. */
    private byte[]  m_ResponseContent;

	/** additional request properties	*/
	private String m_sBasicAuthUserID;
	private String m_sProxyAuthUserID;
	private String m_sProxyAuthPasswd;
	private String m_sBasicAuthPasswd;

	/** content type for post */
	private String m_sContentType = "text/xml; charset=iso_8859-1";

	/** all request properties */
	private final Map<String, String> m_requestProperties = new HashMap<String, String>();

	private String m_sUrl;
	private URL urlObj;
	private HttpURLConnection httpUC;
    
    /**
     * Constructs HTTPPoster
     */
    public void HTTPPoster()
    {
        reset();
    }

    /**
     * Sets the complete XML msg (bypassing all formatting).
     *
     * @param str the fully formatted XML message.
     */
	public void setData(String str) throws CHTTPPosterException
	{
		try
		{
			m_CompleteXML = str.toString().getBytes("UTF8");
		}
		catch (UnsupportedEncodingException exc)
		{
    	throw new CHTTPPosterException("UTF-8 not supported", exc);
		}
	}

		/**
		 *	Sets basic authentication request properties to be sent in header.
		 * @param userID
		 * @param passwd
		 */
		public void setBasicAuthenticationProperties( String userID, String passwd )
		{
			m_sBasicAuthUserID = userID;
			m_sBasicAuthPasswd = passwd;
		}

		public void setProxyAuthenticationProperties( String userID, String passwd )
		{
			m_sProxyAuthUserID = userID;
			m_sProxyAuthPasswd = passwd;
		}

		/** set content type of request */
		public void setContentType(String sContentType)
		{
			m_sContentType = sContentType;
		}

		/** set content type of request */
		public void setRequestProperty(String sPropertyName, String sPropertyValue)
		{
			m_requestProperties.put(sPropertyName, sPropertyValue);
		}

	public void publish(String url) throws CHTTPPosterException
	{
		publish(url, 0);
	}
	
	/**
	 * Method allows to break current post if it hangs.
	 */
	public void interrupt()
	{
		if (httpUC != null)
		{
			httpUC.disconnect();
		}
	}
	
	/**
     * Publishes the XML message
     *
     * @param url   The URL of the application messaging gateway.
     */
    public void publish(String url, int timeoutMs) throws CHTTPPosterException
    {
    	m_sUrl = url;
        int bytesRead;
        byte[] inputBuffer;
        InputStream ins;
        ByteArrayOutputStream baos;

        // Publish using HTTP Post
        try
        {
        	NetTracking.registerUrl(url);
            urlObj = new URL(url);
            final URLConnection uc = urlObj.openConnection();
            if (uc instanceof HttpURLConnection)
            {
            	httpUC = (HttpURLConnection) uc;
            	httpUC.setRequestMethod("POST");
            }
            
            uc.setDoOutput(true);
            uc.setRequestProperty("Content-type", m_sContentType);
            // Accept any text responses (text/xml preferred)
            uc.setRequestProperty("Accept", "text/xml, text/html, text/*");
            // Accept utf-8 or iso_8859-1 (latin1) responses
            uc.setRequestProperty("Accept-Charset", "utf-8, iso_8859-1");
            
            /**
             * Workaround against bug in JDK:
             * @see http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4352956 
             */
            uc.setRequestProperty("User-Agent", "Mozilla/4.5");
            if (timeoutMs > 0)
            {
            	uc.setConnectTimeout(timeoutMs);
            	uc.setReadTimeout(timeoutMs);
            }

            if ( m_sProxyAuthUserID != null)
			{
				String password =  m_sProxyAuthUserID + ":" + m_sProxyAuthPasswd;
				String encodedPassword = Base64Encoder.encode(password.getBytes());
				uc.setRequestProperty("Proxy-Authorization", "Basic " + encodedPassword );
			}

			if ( m_sBasicAuthUserID != null)
			{
				String password =  m_sBasicAuthUserID + ":" + m_sBasicAuthPasswd;
				String encodedPassword = Base64Encoder.encode(password.getBytes());
				uc.setRequestProperty( "Authorization", "Basic " + encodedPassword );
			}

			// put custom request properties
			for ( String sPropertyName : m_requestProperties.keySet() )
			{
				uc.setRequestProperty( sPropertyName, m_requestProperties.get( sPropertyName ) );
			}

			if (uc instanceof HttpURLConnection)
			{
				final OutputStream out = uc.getOutputStream();
				// uc.getOutputStream().write(m_CompleteXML);
				for ( int i = 0; i < m_CompleteXML.length; i++ )
				{
					out.write( m_CompleteXML[i] );
				}
				out.flush();
				out.close();
			}
            
			ins = uc.getInputStream();
            inputBuffer = new byte[BUFFER_SIZE];
            baos = new ByteArrayOutputStream();
            while ((bytesRead = ins.read(inputBuffer)) != -1)
                baos.write(inputBuffer, 0, bytesRead);

            m_ResponseContent = baos.toByteArray();

            m_ResponseContentType = uc.getContentType();
            m_ResponseContentLength = uc.getContentLength();
            
            if (httpUC != null)
            {
            	m_ResponseCode = httpUC.getResponseCode();
	            m_ResponseMessage = httpUC.getResponseMessage();
	            httpUC.disconnect();
            }
        }
        catch (Exception exc)
        {
            throw new CHTTPPosterException(exc, toProperties());
        }
    }

    public String getUrl()
    {
    	return m_sUrl;
    }
    
    public URL getURL()
    {
    	return urlObj;
    }
    
    /**
     * Gets the gateway HTTP response code.
     *
     * @return  The response code as a number. Examples of possible values:
     *          java.net.HttpURLConnection.HTTP_OK, java.net.HttpURLConnection.HTTP_NOT_FOUND.
     *          For other possible values, see java.net.HttpURLConnection.
     */
    public int getResponseCode()
    {
        return m_ResponseCode;
    }

    /**
     * Gets the gateway HTTP response message.
     *
     * @return  The response message as a string.
     */
    public String getResponseMessage()
    {
        return m_ResponseMessage;
    }

    /**
     * Gets the gateway HTTP response content type.
     *
     * @return  The response content type as a string.
     */
    public String getResponseContentType()
    {
        return m_ResponseContentType;
    }

    /**
     * Gets the gateway HTTP response content length.
     *
     * @return  The response content length.
     */
    public int getContentLength()
    {
        return m_ResponseContentLength;
    }

    /**
     * Gets the gateway HTTP response content as a string.
     *
     * @return  The response content as a string.
     */
    public String getResponseContent() throws CHTTPPosterException
    {
        try
        {
            return new String(m_ResponseContent, "UTF8");
        }
        catch (UnsupportedEncodingException exc)
        {
            throw new CHTTPPosterException("UTF-8 not supported", exc);
        }
    }

    /**
     * Gets the gateway HTTP response content as an array of bytes.
     *
     * @return  The response content as an array of bytes.
     */
    public byte[] getResponseBytes()
    {
        int i;
        byte[] bytes = new byte[m_ResponseContent.length];
        for (i = 0; i < m_ResponseContent.length; i++)
            bytes[i] = m_ResponseContent[i];
        return bytes;
    }

    /**
     * Sets all fields of the PsftPublisher to their initial state.
     */
    public final void reset()
    {
    	m_CompleteXML = null;
    	m_requestProperties.clear();
    	m_sContentType = "text/xml; charset=iso_8859-1";
  	}

	public CProperties toProperties()
	{
		CProperties params = new CProperties()
			.setProperties(m_requestProperties)
			.setProperty("url", m_sUrl)
			.setProperty("basicAuthPasswd", m_sBasicAuthPasswd)
			.setProperty("basicAuthUserID", m_sBasicAuthUserID)
			.setProperty("contentType", m_sContentType)
			.setProperty("proxyAuthPasswd", m_sProxyAuthPasswd)
			.setProperty("proxyAuthUserID", m_sProxyAuthUserID);
		if (m_ResponseCode > 0)
		{
			params.setProperty("responseCode", m_ResponseCode);
			params.setProperty("responseContentType", m_ResponseContentType);
			if (m_ResponseContentLength > 0)
				params.setProperty("responseContentLength", m_ResponseContentLength);
		}
		return params;
	}
}

