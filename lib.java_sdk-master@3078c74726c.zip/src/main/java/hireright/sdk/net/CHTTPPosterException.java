/*
 * @(#)$RCSfile: CHTTPPosterException.java,v $ $Revision: 1.7 $ $Date: 2009/03/10 14:21:09 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/net/CHTTPPosterException.java,v $
 *
 * Copyright 2001-2008 by	HireRight, Inc.	All	rights reserved.
 *
 * This	software is	the	confidential and proprietary information
 * of	HireRight, Inc.	Use	is subject to	license	terms.
 *
 * History:
 *	A.Rudenko		2002-12-10		first stable revision
 */
package hireright.sdk.net;

import hireright.sdk.util.CException;
import hireright.sdk.util.IHasProperties;

/**
 * This class represents exceptions thrown by HTTPPoster.
 * @author Alexander Rudenko
 * @version $Revision: 1.7 $ $Date: 2009/03/10 14:21:09 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/net/CHTTPPosterException.java,v $
 */
public class CHTTPPosterException extends CException
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
	/**
	 * Constructs a HTTPPosterException with the specified detail message.
	 *
	 * @param msg   The detail message.
	 */
	public CHTTPPosterException( String msg )
	{
		super( msg );
	}

	public CHTTPPosterException( String msg, Throwable cause )
	{
		super( msg, cause );
	}
	
	public CHTTPPosterException( Throwable cause )
	{
		super( cause );
	}
	
	public CHTTPPosterException( Throwable cause, IHasProperties properties )
	{
		super( cause, properties );
	}
}

