/*
 * @(#)$RCSfile: NetTracking.java,v $ $Revision: 1.4 $ $Date: 2008/09/05 10:16:12 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/net/NetTracking.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-11-26	created
 */
package hireright.sdk.net;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * @author asolntsev
 * @since Nov 26, 2007
 * @version $Revision: 1.4 $ $Date: 2008/09/05 10:16:12 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/net/NetTracking.java,v $
 */
public class NetTracking
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: asolntsev $";
	
	public static final ThreadLocal<List<String>> m_currentThreadURLs = new ThreadLocal<List<String>>();

	public static void startTracking()
	{
		m_currentThreadURLs.set( new ArrayList<String>() );
	}

	public static List<String> finishTracking()
	{
		List<String> urls = m_currentThreadURLs.get();
		m_currentThreadURLs.set( null );
		return urls;
	}

	public static void registerUrl(String sUrl)
	{
		if (m_currentThreadURLs.get() != null)
			m_currentThreadURLs.get().add(sUrl);
	}

	public static void registerUrl(URL url)
	{
		if (url != null)
			registerUrl(url.toString());
	}
}
