/*
 * @(#)$RCSfile: TreeNode.java,v $ $Revision: 1.11 $ $Date: 2009/12/18 07:12:50 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/TreeNode.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  2004-06-09	S.Prokopov		Fixed method removeChild when null is passed.
 *  2005-02-16	A.Solntsev		Removed "CloneNotSupportedException"
 *  2006-02-07	S.Kocherovets	copyMembersData() copies hash code optional.
 *  2006-06-16	A.Solntsev		Optimizations and renamings
 *  2007-11-19	A.Solntsev		Bugfix & additional checks in method removeChild()
 *  2008-11-13	A.Solntsev		Added checks for infinite loop
 *	2009-12-09	A.Solntsev		Removed method finalize()
 */
package hireright.sdk.html.parser;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringWriter;

/**
 * Tree Node
 *
 * @author  Sergei Ignatov
 * @version $Revision: 1.11 $ $Date: 2009/12/18 07:12:50 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/TreeNode.java,v $
 */
public class TreeNode implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.11 $ $Author: cvsroot $";
	
	/**
	 * SOME child node.
	 * Other child nodes can be accessed by their getNext() and getPrevious() methods.
	 */
	// private TreeNode m_childNode = null;
	
	private TreeNode m_firstChild = null;
	private TreeNode m_lastChild = null;

	private TreeNode m_previousTreeNode = null;
	private TreeNode m_nextTreeNode = null;
	private TreeNode m_parentTreeNode = null;
	private int m_nHashCode = 0; // this.hashCode();

	public TreeNode lastChildNode()
	{
		TreeNode tempNode = m_lastChild;

		/*while (tempNode != null && tempNode.getNextNode() != null)
		{
			tempNode = tempNode.getNextNode();
		}*/

		return tempNode;
	}

	public TreeNode firstChildNode()
	{
		TreeNode tempNode = m_firstChild;

		/*while (tempNode != null && tempNode.getPrevious() != null)
			tempNode = tempNode.getPrevious();
		*/

		return tempNode;
	}

	public TreeNode addChildNode(TreeNode node)
	{
		return addChildNodeTail(node);
	}

	public TreeNode addChildNodeTail(TreeNode node)
	{
		return addChildNodeTail(node, false);
	}

	public TreeNode addChildNodeTail(TreeNode node, boolean isShared)
	{
		if (!isShared && node.getParent() != null)
			node.getParent().removeChild(node);

		node.setPrevious(null);
		node.setNext(null);
		node.setParent(this);

		if (m_firstChild == null)
		{
			m_firstChild = node;
			m_lastChild = node;
			afterNodeAdded(node);
			return node;
		}
		else if (m_lastChild == null)
		{
			throw new IllegalStateException("First child is not null, but last child null");
		}

		TreeNode tempNode = lastChildNode();

		node.setPrevious(tempNode);
		tempNode.setNext(node);
		m_lastChild = node;

		afterNodeAdded(node);
		return node;
	}

	public TreeNode addChildNodeHead(TreeNode node)
	{
		if (node.getParent() != null)
			node.getParent().removeChild(node);

		node.setPrevious(null);
		node.setNext(null);
		node.setParent(this);

		if (m_firstChild == null)
		{
			m_firstChild = node;
			m_lastChild = node;
			afterNodeAdded(node);
			return node;
		}
		else if (m_lastChild == null)
		{
			throw new IllegalStateException("First child is not null, but last child null");
		}

		TreeNode tempNode = m_firstChild;

		tempNode.setPrevious(node);
		node.setNext(tempNode);
		m_firstChild = node;

		afterNodeAdded(node);
		return node;
	}

	public TreeNode addAfter(TreeNode node)
	{
		node.setPrevious(this);
		node.setNext(this.getNextNode());
		this.setNext(node);
		
		if (getParent() != null)
		{
			TreeNode lastNode = getParent().lastChildNode();
			if (this == lastNode)
				getParent().m_lastChild = node;
		}

		afterNodeAdded(node);
		return node;
	}

	public TreeNode addBefore(TreeNode node)
	{
		node.setNext(this);
		node.setPrevious(this.getPrevious());
		this.setPrevious(node);

		if (getParent() != null)
		{
			TreeNode firstNode = getParent().firstChildNode();
			if (this == firstNode)
				getParent().m_firstChild = node;
		}

		afterNodeAdded(node);
		return node;
	}

	protected final TreeNode addToParent(TreeNode node)
	{
		if (getParent() != null && getParent() != node)
			getParent().removeChild(node);
		
		this.setPrevious(null);
		this.setNext(null);
		this.setParent(node);

		node.addChildNodeTail(this);
		return node;
	}

	/**
	 * To be overridden in subclasses (e.g. XMLTreeNode)
	 * @param node
	 */
	protected void beforeNodeRemoved(TreeNode node)
	{
	}

	/**
	 * This method is overridden is XMLTreeNode.
	 *
	 * @param node
	 */
	protected void afterNodeAdded(TreeNode node)
	{
	}

	public TreeNode getParent()
	{
		return m_parentTreeNode;
	}

	public TreeNode getRoot()
	{
		TreeNode parentNode = this;

		for (int cntLoop=0; parentNode.getParent() != null; cntLoop++)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			parentNode = parentNode.getParent();
		}

		return parentNode;
	}

	public final void setParent(TreeNode parentTreeNode)
	{
		m_parentTreeNode = parentTreeNode;
	}

	/**
	 * Method returns FIRST child node.
	 * @return null if this node doesn't have any children
	 */
	protected final TreeNode getChildTreeNode()
	{
		return m_firstChild;
	}

	public TreeNode getPreviousNode()
	{
		if (m_previousTreeNode == this)
			return null;
		return m_previousTreeNode;
	}

	public TreeNode getPrevious()
	{
		return getPreviousNode();
	}

	public void setPrevious(TreeNode previousNode)
	{
		m_previousTreeNode = previousNode;
	}

	/**
	 * @deprecated Use method {@link #getNextNode()} which returns TreeNode instead of java.lang.Object
	 * @return next tree node
	 */
	public java.lang.Object getNext()
	{
		return getNextNode();
	}

	public TreeNode getNextNode()
	{
		if (m_nextTreeNode == this)
			return null;
		return m_nextTreeNode;
	}

	public void setNext(TreeNode nextNode)
	{
		m_nextTreeNode = nextNode;
	}

	/**
	 * Copy the node's data to the passed node.
	 * @param node the passed node.
	 * @param isCloningHashCode if coping of the hash code is needed.
	 */
	protected void copyMembersData(TreeNode node, boolean isCloningHashCode)
	{
		/*node.setChildNode(this.getChildTreeNode());
		node.setNext(this.getNextNode());
		node.setPrevious(this.getPrevious());
		node.setParent(this.getParent());*/
		if (isCloningHashCode)
		{
			node.setHashCode(this.getHashCode());
		}
	}

	public int getHashCode()
	{
		if (m_nHashCode == 0)
			m_nHashCode = hashCode();
		return m_nHashCode;
	}

	private final void setHashCode(int nHashCode)
	{
		m_nHashCode = nHashCode;
	}

	private boolean isChild(TreeNode isChild)
	{
		// Check if this is really a child node
		boolean isReallyChild = false;
		
		int cntLoop=0;
		for (TreeNode child = m_firstChild; child != null; )
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if (child == isChild)
			{
				// It's ok. Found.
				isReallyChild = true;
				break;
			}
			child = child.getNextNode();
		}

		return isReallyChild;
	}

	/**
	 * Remove node between two other nodes.
	 * <p>
	 * @param remNode	node to remove
	 */
	public void removeChild(TreeNode remNode)
	{
		if (remNode == null)
			return;

		beforeNodeRemoved(remNode);
		
		if (m_firstChild == remNode && m_lastChild == remNode)
		{
			m_firstChild = null;
			m_lastChild = null;
		}
		else if (m_firstChild == remNode )
		{
			m_firstChild = m_firstChild.getNextNode();
		}
		else if (m_lastChild == remNode )
		{
			m_lastChild = m_lastChild.getPreviousNode();
		}
		else
		{
			// Check if this is really a child node
			if (!isChild(remNode))
			{
				// System.out.println("WARNING: Trying to delete child node which is not really a child!");
				// System.out.println("  remNode = [" + remNode + "]");
				return;
			}
		}
		

		TreeNode prevNode = remNode.getPrevious();
		TreeNode nextNode = remNode.getNextNode();

		remNode.setParent(null);
		remNode.setNext(null);
		remNode.setPrevious(null);
		// TODO Remove listener (if implemented)

		if (prevNode == null && nextNode == null)
		{
			this.m_firstChild = null;
			this.m_lastChild = null;
		}

		else if (prevNode != null && nextNode == null)
		{
			prevNode.setNext(null);
		}
		else if (prevNode == null && nextNode != null)
		{
			nextNode.setPrevious(null);
		}

		else // if (prevNode != null && nextNode != null)
		{
			nextNode.setPrevious(prevNode);
			prevNode.setNext(nextNode);
		}
	}


	/**
	 * FIXME This method should be abstract or event removed from this class.
	 *
	 * @param out
	 * @since Jun 16, 2006
	 */
	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
	}

	/**
	 * @since java_sdk_v2-6-14
	 */
	@Override
	public String toString()
	{
		StringWriter writer	= null;
		PrintWriter	printWriter	= null;

		try
		{
			writer = new StringWriter();
			printWriter	= new PrintWriter(writer);
			print(printWriter, false, XMLOutputStyle.DEFAULT);
			printWriter.flush();
		}
		finally
		{
			if (printWriter != null)
			{
				printWriter.close();
				printWriter = null;
			}
		}
		return writer.toString();
	}

	protected final void release()
	{
		m_firstChild = null;
		m_lastChild = null;
		m_previousTreeNode = null;
		m_nextTreeNode = null;
		m_parentTreeNode = null;
		m_nHashCode = 0;
	}
}