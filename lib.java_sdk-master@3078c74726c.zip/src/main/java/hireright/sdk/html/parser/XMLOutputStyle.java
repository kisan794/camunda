package hireright.sdk.html.parser;

import java.io.Serializable;

public final class XMLOutputStyle implements Serializable
{
	private final String m_sName;
	private final int m_nCode;
	
	private XMLOutputStyle(int nCode, String sName)
	{
		m_nCode = nCode;
		m_sName = sName;
	}
	
	public int getCode()
	{
		return m_nCode;
	}
	
	public String toString()
	{
		return m_sName;
	}
	
	/**
	 * Public constants for output type.
	 * use them before calling method XHTMLInjector.toString()
	 */
	public static final XMLOutputStyle DEFAULT = new XMLOutputStyle(0, "default");
	public static final XMLOutputStyle WEB = new XMLOutputStyle(1, "web");
}
