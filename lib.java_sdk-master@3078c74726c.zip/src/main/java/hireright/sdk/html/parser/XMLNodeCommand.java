/*
 * @(#)$RCSfile: XMLNodeCommand.java,v $ $Revision: 1.5 $ $Date: 2009/12/18 07:14:20 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLNodeCommand.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov					2002-02-12	Created
 *	A.Solntsev				2006-10-31	Really implements Serializable (removed non-serializable java.io.PrintWriter member)
 *	A.Solntsev				2009-12-09	All members are final now
 */
package hireright.sdk.html.parser;

import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.utils.XMLUtils;

import java.io.PrintWriter;
import java.io.Serializable;

/**
 * Generic XML Node. All manipulation with XMLNodes, except parsing 
 * and outputting. Those operations done by XMLTreeNode descedants.
 * WARNING some changes in getNodeByType() !!! affect invalid execution of mergeXML(), appendXML()
 * 
 * @author Sergei Ignatov
 * @since February 2002
 * @version $Revision: 1.5 $ $Date: 2009/12/18 07:14:20 $ $Author: cvsroot $
 */
class XMLNodeCommand implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	public static final int		CMD_OUT_REPLACE_TEXT = XMLConsts.CMD_OUT_REPLACE_TEXT;
	
	private final int m_nCmd;
	private final String m_sParam1;
	private final String m_sParam2;
	
	private String		m_sResult;
		
	private XMLNodeCommand()
	{
		m_nCmd = 0;
		m_sParam1 = null;
		m_sParam2 = null;
	}
	
	public XMLNodeCommand(int nCmd, String sParam1, String sParam2)
	{
		m_nCmd = nCmd;
		m_sParam1 = sParam1;
		m_sParam2 = sParam2;
	}
	
	public void process(XMLTreeNode node, PrintWriter outPrintWriter)
	{
		switch(m_nCmd)
		{
			case CMD_OUT_REPLACE_TEXT:
			{
				cmdReplaceNodeText(node, outPrintWriter);
				break;
			}
			default:
		}
	}
	
	public void cmdReplaceNodeText(XMLTreeNode node, PrintWriter outPrintWriter)
	{
		if (outPrintWriter != null)
		{
			XMLUtils.printReplace(node.toString(), m_sParam1, m_sParam2, outPrintWriter, 1);
		}
		else
		{
			m_sResult = XMLUtils.replace(node.toString(), m_sParam1, m_sParam2);
		}
	}
	
	public String getStringResult()
	{
		return m_sResult;
	}
}
