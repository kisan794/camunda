/*
 * @(#)$RCSfile: XMLTextTreeNode.java,v $ $Revision: 1.7 $ $Date: 2009/12/18 07:13:25 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLTextTreeNode.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 * 
 * History:
 * 
 *	S.Ignatov				2004-12-24	toString(), print changed.
 *	A.Solntsev			2006-06-19	Refactoring
 *	A.Solntsev			2009-12-09	Removed method finalize(); StringBuffer -> StringBuilder
 */
package hireright.sdk.html.parser;

import hireright.sdk.html.utils.XMLUtils;

/**
 * Node representation for text XML Nodes values, for attribute values.
 * Unlike other XMLTreeNode children, this class holds the text as the "XML Tag" property.
 * 
 * @author		Sergei Ignatov
 * @version		"$Revision: 1.7 $, $Date: 2009/12/18 07:13:25 $, $Author: cvsroot $"
 */
public class XMLTextTreeNode extends XMLTreeNode
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
	private StringBuilder m_sbParseData; // = new StringBuilder();
	private int m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
	
	public int getType()
	{
		return XMLConsts.TYPE_TEXT;
	}	
	
	/**
	 * @deprecated  Use constructor with tag name / text
	 * TODO Remove this method
	 */
	public XMLTextTreeNode()
	{
	}
	
	/**
	 * @deprecated  Use constructor with tag name / text
	 * TODO Remove this method
	 */
	private XMLTextTreeNode(String sSource) throws XMLObjectException
	{
		parse(sSource);
	}
	
	/**
	 * 
	 * @param sTagName
	 * @param sText
	 * @since java_sdk_v2-6-14
	 */
	public XMLTextTreeNode(String sTagName, String sText)
	{
		super(sTagName);
		if (sText != null)
			setXMLTag(sText);
	}
	
	public void parse(String sSource) throws XMLObjectException
	{
		try
		{
			onStartParsing();
			m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
			super.parse(sSource);
		}
		finally
		{
			postParse();
		}
	}

	public int parseAppend(char c)
	{
		switch (m_nCurrentSection)
		{
			case XMLConsts.SECT_TAG_NAME:
				switch(c)
				{
					case '<':
						setXMLTag(XMLUtils.encodeTextData(m_sbParseData.toString().trim()));
						return XMLConsts.SECT_PARSED;
					case ' ':
					case '	':
					case 0x0D:
					case 0x0A:
						if(m_sbParseData.length() == 0)
							return XMLConsts.SECT_INPROGRESS;
					default:
						m_sbParseData.append(c);
						return XMLConsts.SECT_INPROGRESS;
				}
		}
		return XMLConsts.SECT_FAILED;
	}
	
	public String toString()
	{
		// XMLTreeNode rootNode = (XMLTreeNode) this.getRoot(); // long operation!
		
		//if (rootNode != null && rootNode.getType() == XMLConsts.TYPE_ROOT)
		//	return XMLUtils.decodeTextData(getXMLTag(), ((XMLRootTreeNode) rootNode).getOutputSpecific());
			
		return XMLUtils.decodeTextData(getXMLTag());
	}
	
	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		/*XMLTreeNode rootNode = (XMLTreeNode) this.getRoot(); // long operation!
		if (rootNode != null && rootNode.getType() == XMLConsts.TYPE_ROOT)
		{
			out.print(XMLUtils.decodeTextData(getXMLTag(), ((XMLRootTreeNode) rootNode).getOutputSpecific()));
		}
		else
		{
			out.print(XMLUtils.decodeTextData(getXMLTag()));
		}
		*/
		
		// TODO rewrite method "decodeTextData" to append to given StringBuffer
		// instead of creating the new one.
		out.print(XMLUtils.decodeTextData(getXMLTag(), style));
	}
	
	final XMLTreeNode addToParentXmlNode(XMLTreeNode node) throws XMLObjectException
	{
		XMLTreeNode temp = super.addToParentXmlNode(node);
		// I guess that always temp == node
		if (temp != node)
		{
			//System.out.println("temp = " + temp);
			//System.out.println("node = " + node);
		}
		return node;
	}
	
	public final void setXMLTag(String propValue)
	{
		XMLTreeNode parent = (XMLTreeNode) getParent();
		if (parent != null && parent.getType() == XMLConsts.TYPE_ATTRIBUTE)
			((TreeNodeAttrib) parent).resetResult();
		super.setXMLTag(propValue);
	}		
	
	protected void onStartParsing()
	{
		m_sbParseData = reuse(m_sbParseData);
	}
	
	public void postParse()
	{
		m_sbParseData = null;
	}
}