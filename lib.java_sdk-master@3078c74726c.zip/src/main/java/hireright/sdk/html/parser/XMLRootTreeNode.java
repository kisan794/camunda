/*
 * @(#)$RCSfile: XMLRootTreeNode.java,v $ $Revision: 1.5 $ $Date: 2008/11/21 11:31:32 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLRootTreeNode.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   S.Ignatov    	XXXX-XX-XX  Created
 *   A.Solntsev		2008-11-13	Added checks for infinite loop
 */
package hireright.sdk.html.parser;

import hireright.sdk.html.utils.*;

/**
 * One root node for XMLObject clause. Just node with special toString() method.
 * 
 * @author  Sergei Ignatov
 * @version $Revision: 1.5 $, $Date: 2008/11/21 11:31:32 $ $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLRootTreeNode.java,v $
 */
public class XMLRootTreeNode extends XMLTreeNode
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	private XMLOutputStyle m_outputSpecific = XMLOutputStyle.DEFAULT;

	/**
	 * XML Object to which this root node belongs
	 */
	private XMLObject m_xmlObject;

	public XMLRootTreeNode()
	{
		super("ROOT");
	}

	public XMLRootTreeNode(XMLObject xml)
	{
		super("ROOT");
		setXMLObject(xml);
	}

	@Override
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		int counter = 0;
		for (TreeNode childNode = getFistChildNode(); childNode != null; childNode = childNode.getNextNode())
		{
			assert ++counter < 10000 : "Infinite loop";
			sb.append(childNode.toString());
		}
		return sb.toString();
	}

	public void print(java.io.PrintWriter out, boolean bNiceOutput)
	{
		print(out, bNiceOutput, getOutputSpecific());
	}

	@Override
	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		int counter = 0;
		for (TreeNode childNode = getFistChildNode(); childNode != null; childNode = childNode.getNextNode())
		{
			assert ++counter < 10000 : "Infinite loop";
			childNode.print(out, bNiceOutput, style);
		}
	}

	@Override
	public int getType()
	{
		return XMLConsts.TYPE_ROOT;
	}

	public XMLOutputStyle getOutputSpecific()
	{
		return m_outputSpecific;
	}

	/**
	 * @deprecated Use method {@link #setOutputStyle(XMLOutputStyle)}
	 * @param outputStyle
	 */
	public void setOutputSpecific(final int outputStyle)
	{
		if (outputStyle ==  XMLUtils.SPECIFIC_DEFAULT)
			m_outputSpecific = XMLOutputStyle.DEFAULT;
		else if (outputStyle ==  XMLUtils.SPECIFIC_WEB_BROW)
			m_outputSpecific = XMLOutputStyle.WEB;
		else
			throw new IllegalArgumentException("Unknown output style: " + outputStyle);
	}

	/**
	 *
	 * @param outputStyle Either XMLOutputStyle.SPECIFIC_DEFAULT or XMLOutputStyle.SPECIFIC_WEB_BROW
	 */
	public void setOutputStyle(final XMLOutputStyle outputStyle)
	{
		m_outputSpecific = outputStyle;
	}

	@Override
	public int parseAppend(char c) throws XMLObjectException
	{
		return XMLConsts.SECT_FAILED;
	}

	/**
	 * TODO	Make this method protected. Currently it's used only in class CHttpParametersStorage.
	 *
	 * @param xmlObject
	 */
	public final void setXMLObject(XMLObject xmlObject)
	{
		m_xmlObject = xmlObject;
	}

	@Override
	public XMLObject getXMLObject()
	{
		return m_xmlObject;
	}
}