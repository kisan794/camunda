/*
 * @(#)$RCSfile: TreeNodeAttrib.java,v $ $Revision: 1.8 $ $Date: 2009/12/18 07:14:40 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/TreeNodeAttrib.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2002-07-26	Sergei Ignatov		created
 *	2006-08-xx	Andrei Solntsev		refactoring
 *	2007-12-04	Andrei Solntsev		Added method getAttribValue()
 *	2009-12-09	A.Solntsev				Removed member StringBuilder m_sbResult
 */
package hireright.sdk.html.parser;

/**
 *
 * Object for storage XML node`s attribute in form NAME=DATA.
 *
 * @author Sergei Ignatov
 * @version $Revision: 1.8 $ $Date: 2009/12/18 07:14:40 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/TreeNodeAttrib.java,v $
 */
public class TreeNodeAttrib extends XMLTreeNode
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	/**
	 * @deprecated Use cpnstructor with name/value
	 */
	public TreeNodeAttrib()
	{
		super(null, null);
	}

	protected TreeNodeAttrib(String sAttrName, String sAttrValue)
	{
		super(sAttrName, sAttrValue);

		// XMLTextTreeNode textNode = new XMLTextTreeNode(null, sAttrValue);
		// this.addChildNode(textNode);
	}

	protected void resetResult()
	{
		// not used?
	}

	public int getType()
	{
		return XMLConsts.TYPE_ATTRIBUTE;
	}

	public String getName()
	{
		return getXMLTag();
	}

	public String getAttribValue()
	{
		if (getFistChildNode() == null)
			return null;
		return getFistChildNode().getXMLTag();
	}

	public void setXMLTag(String propValue)
	{
		resetResult();
		super.setXMLTag(propValue);
	}

	protected void afterNodeAdded(TreeNode node)
	{
		resetResult();
		super.afterNodeAdded(node);
	}

	@Override
	public String toString()
	{
		StringBuilder sbResult = new StringBuilder();
		sbResult.append(getXMLTag());
		sbResult.append("=\"");
		TreeNode tempNode = this.getChildNode();

		if (tempNode != null)
			//sbResult.append(tempNode.getXMLTag());
			sbResult.append(tempNode.toString());
		else
		{
			//sbResult.append("ERROR");

			// it happens when attribute doesn't have a value
			sbResult.append("");
		}

		sbResult.append("\"");

		return sbResult.toString();
	}

	@Override
	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		out.print(getXMLTag());
		out.print("=\"");
		TreeNode tempNode = this.getChildNode();
		if (tempNode != null)
		{
			// out.print(tempNode.toString());
			tempNode.print(out, bNiceOutput, style);
		}
		else
		{
			// out.print("ERROR");

			// it happens when attribute doesn't have a value
			out.print("");
		}
		out.print("\"");
	}

	public void postParse()
	{
	}
}