/*
 * @(#)$RCSfile: XMLConsts.java,v $ $Revision: 1.7 $ $Date: 2011/12/16 09:29:49 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLConsts.java,v $
 *
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	 2002-02-15	Sergei Ignatov		changed XMLTreeNode.getChildByType()
 *	 2002-06-10	Sergei Ignatov		added constant CMD_OUT_REPLACE_TEXT
 *	 2002-07-26	Anton Keks				default setting changed
 *   2003-02-26	Sergei Ignatov		formatted output, do not tag it
 *   2005-01-03	Andrei Solntsev		Removed formatted output. Use XMLObject.toString(true) instead.
 *   2011-12-05	Peter Sizov			Added clearable node types
 */

package hireright.sdk.html.parser;


/**
 *	Public class holding XML constants.
 *
 *	@author		Sergei Ignatov
 */
public class XMLConsts
{
	// nodes types. number values as order in xml structure.
	public static final int TYPE_PROCESSING_INSTRUCTION = 1;   // node like <?xml version="1.0"?>
	public static final int TYPE_COMMENTS = 2;		     // node like <!-- comments -->
	public static final int TYPE_DOC_TYPE_DEFINITION = 4;	     // node like <!DOCTYPE >
	public static final int TYPE_CDATA = 8;		     // node like <![CDATA[ c data ]]>
	public static final int TYPE_TEXT = 16;	     	     // node like Text
	public static final int TYPE_NODE = 32;	     	     // node like <Node>
	public static final int TYPE_UNKNW = 64;	     	     // unknown type node
	public static final int TYPE_NODE_CLOSING = 128;	     // node like </Node>
	public static final int TYPE_ATTRIBUTE = 256;
	public static final int TYPE_ROOT = 512;

	public static final int PARSE_FAILED = 200;

	public static final int MIN_PROCESS_INSTR_LENGTH = 6;
	public static final int MIN_COMMENT_LENGTH = 8;
	public static final int MIN_CDATA_LENGTH = 13;
	public static final int MIN_DTD_LENGTH = 11;
	public static final int MIN_NODE_LENGTH = 3;

	public static final int MIN_PREDETERM_LENGTH = MIN_NODE_LENGTH;

	public static final int SECT_TAG_NAME = 0;
	public static final int SECT_TAG_ID = 10;
	public static final int SECT_TAG_VALUE = 20;
	public static final int SECT_TAG_VALUE_ID = 30;
	public static final int SECT_ATTRIBUTE = 40;
	public static final int SECT_ATTRIBUTE_OPERATION = 50;
	public static final int SECT_ATTRIBUTE_VALUE = 60;
	public static final int SECT_FAILED = -10;
	public static final int SECT_PARSED = -20;
	public static final int SECT_INPROGRESS = -30;

	public static final int NODE_BYPATH_NOT_FOUND = 0;
	public static final int NODE_BYPATH_FOUND = 1;

	public static final int ALL_LEVELS = -1;
	public static final int ADD_TO_TAIL = -1;

	/**
	 *	It is dangerous to set this variable constantly true.
	 *	It produces invalid javascripts in XHTML's.
	 *
	 *	To print XML's in nice format, use method
	 *	<code>XMLObject.toString(true)</code>
	 */
	// public static boolean MAKE_NICE_OUTPUT = false;

	public static final int CMD_OUT_REPLACE_TEXT = 1;

	//node types that can be cleared
	public static enum CLEARABLE_NODES
	{
		ATTRIBUTE {int getNodeType() {return TYPE_ATTRIBUTE;}}, 
		NODE {int getNodeType() {return TYPE_NODE;}};
		abstract int getNodeType();
	}
}