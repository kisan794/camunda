/*
 * @(#)$RCSfile: XMLNodeClosingTreeNode.java,v $ $Revision: 1.6 $ $Date: 2009/12/18 07:14:29 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLNodeClosingTreeNode.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	Sergei Ignatov		2002-01-04	Created
 *	A.Solntsev				2006-06-19	Refactoring
 *	A.Solntsev				2009-12-09	StringBuffer -> StringBuilder
 */
package hireright.sdk.html.parser;

/**
 * Special node only for parsing. This node doesn`t exsits in parsed XML tree.
 * 
 * @author  Sergei Ignatov
 * @version $Revision: 1.6 $ $Date: 2009/12/18 07:14:29 $ $Author: cvsroot $
 */
public class XMLNodeClosingTreeNode extends XMLTreeNode
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	private StringBuilder m_sbParseData; // = new StringBuilder();
	private int m_nLength = 0;
	private int m_nCurrentSection = XMLConsts.SECT_TAG_NAME;

	public int getType()
	{
		return XMLConsts.TYPE_NODE_CLOSING;
	}

	/**
	 *
	 * @param sTagName
	 * @param sText
	 * @since java_sdk_v2-6-14
	 */
	public XMLNodeClosingTreeNode(String sTagName, String sText)
	{
		super(sTagName, sText);
	}

	protected void onStartParsing()
	{
		m_sbParseData = reuse(m_sbParseData);
	}
	
	public void parse(String sSource) throws XMLObjectException
	{
		try
		{
			onStartParsing();
			m_nLength = 0;
			m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
			super.parse(sSource);
		}
		finally
		{
			postParse();
		}
	}

	@Override
	public int parseAppend(char c)
	{
		m_nLength++;
		if(m_nLength < 3) // skip </
			return XMLConsts.SECT_PARSED;

		switch(m_nCurrentSection)
		{
			case XMLConsts.SECT_TAG_NAME:
				switch(c)
				{
					case ' ':
					case '	':
					case 0x0D:
					case 0x0A:
						if(m_sbParseData.length() > 0)
						{
							m_nCurrentSection = XMLConsts.SECT_TAG_VALUE_ID;
							return XMLConsts.SECT_INPROGRESS;
						}
						else
							return XMLConsts.SECT_FAILED;
					case '/':
						return XMLConsts.SECT_FAILED;
					case '>':
						setXMLTag(m_sbParseData.toString());
						return XMLConsts.SECT_PARSED;
					default:
						m_sbParseData.append(c);
						return XMLConsts.SECT_INPROGRESS;
				}
			case XMLConsts.SECT_TAG_VALUE_ID:
				switch(c)
				{
					case ' ':
					case '	':
					case 0x0D:
					case 0x0A:
						return XMLConsts.SECT_INPROGRESS;
					case '>':
						setXMLTag(m_sbParseData.toString());
						return XMLConsts.SECT_PARSED;
					default:
						return XMLConsts.SECT_FAILED;
				}
		}
		return XMLConsts.SECT_FAILED;
	}

	@Override
	public String toString()
	{
		return ("</" + getXMLTag() + ">");
	}

	@Override
	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		out.print("</");
		out.print(getXMLTag());
		out.print(">");
		if (bNiceOutput)
			out.print('\n'); // ?
	}

	/**
	 * @throws XMLObjectException if closing node doesn't match with currently open node
	 */
	final XMLTreeNode addToParentXmlNode(XMLTreeNode node) throws XMLObjectException
	{
		if (node == null)
		{
			// how can it happen?
			return null;
		}

		String sCurrentlyOpenTag = node.getXMLTag();

		if (!sCurrentlyOpenTag.equals(this.getXMLTag()))
			throw new XMLObjectException("Tag is not closed: " + sCurrentlyOpenTag + "/" + this.getXMLTag());

		return (XMLTreeNode) node.getParent();
	}

	public void postParse()
	{
		m_sbParseData = null;
	}
}