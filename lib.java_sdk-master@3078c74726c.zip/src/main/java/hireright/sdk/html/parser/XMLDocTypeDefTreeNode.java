/*
 * @(#)$RCSfile: XMLDocTypeDefTreeNode.java,v $ $Revision: 1.9 $ $Date: 2009/12/18 07:12:21 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLDocTypeDefTreeNode.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	Sergei Ignatov		2004-06-08	java_sdk_v2-5-4: toString changed - fixed output.
 *	A.Solntsev				2006-06-19	Refactoring
 *	A.Solntsev				2009-12-09	StringBuffer -> StringBuilder
 */
package hireright.sdk.html.parser;

/**
 * This class represents document type definitions node in xml tree.
 *
 * @author  Sergei Ignatov
 * @version $Revision: 1.9 $ $Date: 2009/12/18 07:12:21 $ $Author: cvsroot $
 */
public class XMLDocTypeDefTreeNode extends XMLTreeNode
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	private static final String DOC_TYPE_LABEL = "<!DOCTYPE";
	
	private StringBuilder m_sbParseData; // = new StringBuilder();
	private int m_nLength = 0;
	private int m_nBraceIn = 0;
	
	@Override
	public int getType()
	{
		return XMLConsts.TYPE_DOC_TYPE_DEFINITION;
	}
	
	/**
	 * 
	 * @param sTagName
	 * @param sText
	 * @since java_sdk_v2-6-14
	 */
	public XMLDocTypeDefTreeNode(String sTagName, String sText)
	{
		super(sTagName, sText);
	}
	
	protected void onStartParsing()
	{
		m_sbParseData = reuse(m_sbParseData);
	}
	
	@Override
	public void parse(String sSource) throws XMLObjectException
	{
		try
		{
			onStartParsing();
			m_nLength = 0;
			super.parse(sSource);
		}
		finally
		{
			postParse();
		}
	}

	@Override
	public int parseAppend(char c)
	{
		m_nLength++;
		if(m_nLength < 4) // skip <!D
			return XMLConsts.SECT_PARSED;
		else
		{
			if(m_nLength < (DOC_TYPE_LABEL.length() + 1))
			{
				if(DOC_TYPE_LABEL.charAt(m_nLength-1) != c)
					return XMLConsts.SECT_FAILED;
				else
					return XMLConsts.SECT_INPROGRESS;
			}
		}
		
		switch(c)
		{
			case '<':
				m_nBraceIn++;
				m_sbParseData.append(c);
				return XMLConsts.SECT_INPROGRESS;
			case '>':
				m_nBraceIn--;
				if(m_nBraceIn == -1)
				{
					setXMLTag(m_sbParseData.toString());
					return XMLConsts.SECT_PARSED;
				}
				m_sbParseData.append(c);
				return XMLConsts.SECT_INPROGRESS;
			default:
				m_sbParseData.append(c);
				return XMLConsts.SECT_INPROGRESS;
		}
	
	}
	
	@Override
	public String toString()
	{
		return DOC_TYPE_LABEL + getXMLTag() + ">";
	}
	
	@Override
	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		out.print(DOC_TYPE_LABEL);
		out.print(getXMLTag());
		out.println(">");
	}		

	@Override
	public void postParse()
	{
		m_sbParseData = null;
	}
}