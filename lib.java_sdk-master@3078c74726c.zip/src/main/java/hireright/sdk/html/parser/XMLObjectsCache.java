/*
 * @(#)$RCSfile: XMLObjectsCache.java,v $ $Revision: 1.5 $ $Date: 2008/11/21 11:32:28 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLObjectsCache.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 2002-01-14	S.Ignatov		created
 * 2005-08-29	A.Solntsev		Completely rewritten. EHCache library is used.
 * 2007-06-22	A.Solntsev		Removed dependency on hireright.sdkex.as_cache
 * 2020-10-08	A.Naboyshchikov		HRG-137372: use XMLObjectFactory in parsing adding second attempt to read XML
 */
package hireright.sdk.html.parser;
import java.net.MalformedURLException;
import java.net.URL;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

/**
 * Class implements object cache for xml documents (instances of XMLObject)
 *
 * @author Sergei Ignatov
 * @since 2002-01-14
 * @version $Revision: 1.5 $ $Date: 2008/11/21 11:32:28 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLObjectsCache.java,v $
 */
public class XMLObjectsCache
{
	private static XMLObjectsCache m_instance = null;

	private final Cache m_cache;
	private static final Object lock = new Object();

	protected XMLObjectsCache(Cache cache)
	{
		m_cache = cache;
	}

	public static XMLObjectsCache getInstance()
	{
		if (m_instance == null)
		{
			synchronized (lock)
			{
				if (m_instance == null)
				{
					CacheManager mng = CacheManager.create();
					String sCacheName = XMLObject.class.getName();
					Cache cache = mng.getCache(sCacheName);
					if (cache == null)
					{
						mng.addCache(sCacheName);
						cache = mng.getCache(sCacheName);
					}

					m_instance = new XMLObjectsCache(cache);
				}
			}
		}
		return m_instance;
	}

	/**
	 *
	 * @param sXmlUrl
	 * @return cached XMLObject
	 * @throws XMLObjectRuntimeException
	 */
	public XMLObject getXMLObject(String sXmlUrl)
	{
		final XMLObject xml;

		Element el = getInstance().m_cache.get(sXmlUrl);
		if (el != null)
		{
			xml = (XMLObject) el.getValue();
		}
		else
		{
			xml = parseXml(sXmlUrl);
			if (xml != null)
			{
				el = new Element(sXmlUrl, xml);
				getInstance().m_cache.put(el);
			}
		}

		// Take copy of cached object. Client classes can change it.
		return (xml == null) ? null : new XMLObject(xml);
	}

	/**
	 * @param sXmlUrl
	 * @return newly parsed XMLObject
	 * @throws XMLObjectRuntimeException if given URL doesn't exist or contains invalid XML
	 */
	protected XMLObject parseXml(String sXmlUrl)
	{
		return XMLObjectFactory.getXMLObjectFromURL(sXmlUrl);
	}
}
