/*
 * @(#)$RCSfile: XMLCDATATreeNode.java,v $ $Revision: 1.8 $ $Date: 2009/12/18 07:12:47 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLCDATATreeNode.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 * 
 * History:
 *	S.Ignatov					2004-12-24	toString(), print changed.
 *	A.Solntsev				2009-12-09	StringBuffer -> StringBuilder
 */
package hireright.sdk.html.parser;

import hireright.sdk.html.utils.*;

/**
 * Node representation for CDATA values.
 * @author		Sergei Ignatov
 * @version		"$Revision: 1.8 $, $Date: 2009/12/18 07:12:47 $, $Author: cvsroot $"
 */
public class XMLCDATATreeNode extends XMLTreeNode
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	private StringBuilder m_sbParseData;	//  = new StringBuilder();
	private int m_nLength = 0;
	private int m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
	private static final String CDATA_LABEL = "<![CDATA[";
	private static final String CDATA_LABEL_END = "]]>";
	
	public int getType()
	{
		return XMLConsts.TYPE_CDATA;
	}
	
	/**
	 * TODO Remove this method
	 */
	private XMLCDATATreeNode()
	{
	}
	
	/**
	 * TODO Remove this method
	 */
	private XMLCDATATreeNode(String sSource) throws XMLObjectException
	{
		parse(sSource);
	}
	
	/**
	 * 
	 * @param sTagName
	 * @param sText
	 * @since java_sdk_v2-6-14
	 */
	public XMLCDATATreeNode(String sTagName, String sText)
	{
		super(sTagName, sText);
	}
	
	protected void onStartParsing()
	{
		m_sbParseData = reuse(m_sbParseData);
	}
	
	public void parse(String sSource) throws XMLObjectException
	{
		onStartParsing();
		m_nLength = 0;
		m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
		super.parse(sSource);
		postParse();
	}

	public int parseAppend(char c)
	{
		m_nLength++;
		if(m_nLength < 4) // skip <![
			return XMLConsts.SECT_PARSED;
		else
		{
			if(m_nLength < (CDATA_LABEL.length() + 1))
			{
				if(CDATA_LABEL.charAt(m_nLength-1) != c)
					return XMLConsts.SECT_FAILED;
				else
					return XMLConsts.SECT_INPROGRESS;
			}
		}
			
		switch(m_nCurrentSection)
		{
			// parse --> <![CDATA[ <-- jjdjdj ]]>  part of xml element 
			case XMLConsts.SECT_TAG_NAME:
				switch(c)
				{
					case ']':
						m_sbParseData.append(c);
						m_nCurrentSection = XMLConsts.SECT_TAG_VALUE;
						return XMLConsts.SECT_INPROGRESS;
					default:
						m_sbParseData.append(c);
						return XMLConsts.SECT_INPROGRESS;
				}
			// parse <![CDATA[ --> jjdjdj <-- ]]>  part of xml element 
			case XMLConsts.SECT_TAG_VALUE:
				switch(c)
				{			
					case ']':
						m_sbParseData.append(c);
						m_nCurrentSection = XMLConsts.SECT_TAG_VALUE_ID;
						return XMLConsts.SECT_INPROGRESS;
					default:
						m_sbParseData.append(c);
						m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
						return XMLConsts.SECT_INPROGRESS;
				}
			// parse <![CDATA[ jjdjdj --> ]]> <-- part of xml element 
			case XMLConsts.SECT_TAG_VALUE_ID:
				switch(c)
				{			
					case ']':
						m_sbParseData.append(c);
						m_nCurrentSection = XMLConsts.SECT_TAG_VALUE_ID;
						return XMLConsts.SECT_INPROGRESS;
					case '>':
						m_sbParseData.setLength(m_sbParseData.length() - 2);
						setXMLTag(m_sbParseData.toString());
						return XMLConsts.SECT_PARSED;
					default:
						m_sbParseData.append(c);
						m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
						return XMLConsts.SECT_INPROGRESS;
				}				
		}
		return XMLConsts.SECT_FAILED;
	}
	
	public String toString()
	{
		//XMLTreeNode rootNode = (XMLTreeNode) this.getRoot();
		
		//if(rootNode != null && rootNode.getType() == XMLConsts.TYPE_ROOT 
		//  && ((XMLRootTreeNode) rootNode).getOutputSpecific() == XMLUtils.SPECIFIC_WEB_BROW)
		return "<![CDATA[" + getXMLTag() + "]]>";
	}
	
	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		//XMLTreeNode rootNode = (XMLTreeNode) this.getRoot(); // long operation!
		
		//if(rootNode != null && rootNode.getType() == XMLConsts.TYPE_ROOT 
		//  && ((XMLRootTreeNode) rootNode).getOutputSpecific() == XMLUtils.SPECIFIC_WEB_BROW)
		if (XMLOutputStyle.WEB == style)
		{
			out.print(getXMLTag());
		}
		else
		{
			out.print("<![CDATA[");
			out.print(getXMLTag());
			out.print("]]>");
		}
	}	
	
	@Override
	public void postParse()
	{
		m_sbParseData = null;
	}	
}