/*
 * @(#)$RCSfile: XMLAttributesSection.java,v $ $Revision: 1.9 $ $Date: 2009/12/18 07:12:33 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLAttributesSection.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov				2002-02-12	Created
 *	A.Solntsev			2006-06-19	implements Serializable
 *	A.Solntsev			2009-12-09	Removed method finalize(); StringBuffer -> StringBuilder
 */
package hireright.sdk.html.parser;

import java.io.Serializable;
import java.util.*;

import hireright.sdk.html.utils.*;

/**
 *
 * @author Sergei Ignatov
 * @version $Revision: 1.9 $ $Date: 2009/12/18 07:12:33 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLAttributesSection.java,v $
 */
public class XMLAttributesSection implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	private StringBuilder m_sbAttribute = new StringBuilder();
	private StringBuilder m_sbAttributeValue = new StringBuilder();
	private char m_valChar = '0';
	private int m_nCurrentSection = XMLConsts.SECT_ATTRIBUTE;

	private List<String> m_attributesList = new ArrayList<String>(5);

	private boolean endAttributeValueReached = false;

	protected int parseAppend(char c)
	{
		switch (m_nCurrentSection)
		{
			case XMLConsts.SECT_ATTRIBUTE:
				switch(c)
				{
					case '=':
						m_nCurrentSection = XMLConsts.SECT_ATTRIBUTE_VALUE;
						m_valChar = '0';
						endAttributeValueReached = false;
						return m_nCurrentSection;
					case ' ':
					case '	':
					case 0x0D:
					case 0x0A:
						if(m_sbAttribute.length() != 0)
							endAttributeValueReached = true;
						return m_nCurrentSection;
					default:
						if(endAttributeValueReached)
							return XMLConsts.SECT_FAILED;
						m_sbAttribute.append(c);
				}
				return m_nCurrentSection;
			case XMLConsts.SECT_ATTRIBUTE_VALUE:
				switch(c)
				{
					case '"':
					case '\'':
						if(m_valChar == '0')
							m_valChar = c;
						else
							if(m_valChar == c)
							{
								m_attributesList.add(m_sbAttribute.toString());
								m_attributesList.add(XMLUtils.encodeTextData(m_sbAttributeValue.toString()));
								m_sbAttribute.setLength(0);
								m_sbAttributeValue.setLength(0);
								m_nCurrentSection = XMLConsts.SECT_ATTRIBUTE;
								endAttributeValueReached = false;
							}
							else
								m_sbAttributeValue.append(c);
						return m_nCurrentSection;
					case ' ':
					case '	':
					case 0x0D:
					case 0x0A:
						if(m_sbAttributeValue.length() == 0)
							return m_nCurrentSection;
					default:
						if(m_valChar != '0')
							m_sbAttributeValue.append(c);
						else
							return XMLConsts.SECT_FAILED;

				}
		}
		return m_nCurrentSection;
	}

	/**
	 * Method returns List o fstring pairs: {"name1", "value1", "name2", "value2", ...}
	 * @since Jun 19, 2006
	 */
	protected final List<String> getParsingResult()
	{
		return m_attributesList;
	}

	protected final void release()
	{
		if (m_sbAttribute != null)
		{
			m_sbAttribute.setLength(0);
			m_sbAttribute = null;
		}

		if (m_sbAttributeValue != null)
		{
			m_sbAttributeValue.setLength(0);
			m_sbAttributeValue = null;
		}

		if (m_attributesList != null)
		{
			m_attributesList.clear();
			m_attributesList = null;
		}
	}

	protected static XMLAttributesSection reuse(XMLAttributesSection attrs)
	{
		if (attrs == null)
			return new XMLAttributesSection();

		attrs.m_sbAttribute.setLength(0);
		attrs.m_sbAttributeValue.setLength(0);
		attrs.m_valChar = '0';
		attrs.m_nCurrentSection = XMLConsts.SECT_ATTRIBUTE;
		attrs.m_attributesList.clear();
		attrs.endAttributeValueReached = false;

		return attrs;
	}

	public String toString()
	{
		return m_attributesList.toString() + "; currentlyReading: " +
			m_sbAttribute + "=" + m_sbAttributeValue;
	}
}