/*
 * @(#)$RCSfile: XMLTreePathParser.java,v $ $Revision: 1.8 $ $Date: 2007/11/30 09:25:55 $ $Author: asolntsev $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   S.Ignatov		XXXX-XX-XX  Created
 *   S.Ignatov		2004-02-17  sPath changed to private m_sPath
 *   A.Solntsev		2007-02-16	All members made private; added getters.
 */
package hireright.sdk.html.parser;

import java.io.Serializable;

/**
 * This class extract first section of xml path.
 * And store it into members.
 * where path is [section] / [section] / ... [section]/
 * where section is [tag_name] + [[tag_index]] + [=tag_value + [value_index]] + [attribute + [=value] ] /
 * it is mean
 * tag1/="tag2value"//tag3[1]/[]/tag4="I"/tag5[2]="me"[3]/tag6{attr="mine"}/tag7{want_more}/tag8="and more"/{kick_it}/
 *
 * @author  Sergei Ignatov
 * @version $Revision: 1.8 $, $Date: 2007/11/30 09:25:55 $
 */
public class XMLTreePathParser implements Serializable
{
	/* full path to parse */
	private String  m_sPath;

	private String  sTagName;
	private String  sTagID;
	private int     nTagID;
	private String  sTagValue;
	private String  sTagValueID;
	private int     nTagValueID;
	private String  sAttribute;
	private String  sAttributeValue;
	private String  sNewPath;

	private StringBuffer m_sectionBuffer;

	private boolean m_isValueBody = false;
	private char m_valueChar = '0';

	/**
	 * path value to parse setter
	 *
	 * @param sPath path to parse value
	 */
	public void setParsePath(String sPath)
	{
		m_sPath = sPath;
	}

	/**
	 * main parsing procedure.
	 * @return COMMENT ME (some status?)
	 */
	public int parse()
	{
		// reset buffer.
		if (m_sectionBuffer == null)
			m_sectionBuffer = new StringBuffer();
		else
			m_sectionBuffer.setLength(0);

		char charAt;

		// reset result values.
		resetValues();

		// define vars, set current section
		int nNewSection = XMLConsts.SECT_FAILED;
		int nCurrentSection = sectInitProc(m_sPath);

		// get chars while section not finished or path not ended
		boolean done = false;
		for(int counter = (nCurrentSection==XMLConsts.SECT_PARSED?1:0); counter < m_sPath.length() && !done; counter++)
		{
			charAt = m_sPath.charAt(counter);
			switch(nCurrentSection)
			{       // process chars, in depends of current section
				case XMLConsts.SECT_TAG_NAME:
					nNewSection = sectTagNameProc(charAt);
					break;
				case XMLConsts.SECT_TAG_ID:
					nNewSection = sectTagIDProc(charAt);
					break;
				case XMLConsts.SECT_TAG_VALUE:
					nNewSection = sectTagValueProc(charAt);
					break;
				case XMLConsts.SECT_TAG_VALUE_ID:
					nNewSection = sectTagValueIDProc(charAt);
					break;
				case XMLConsts.SECT_ATTRIBUTE:
					nNewSection = sectAttributeProc(charAt);
					break;
				case XMLConsts.SECT_ATTRIBUTE_VALUE:
					nNewSection = sectAttributeValueProc(charAt);
					break;
				case XMLConsts.SECT_PARSED:
					m_sectionBuffer.append(charAt);
					nNewSection = XMLConsts.SECT_PARSED;
					break;
				default:
					nNewSection = XMLConsts.SECT_FAILED;
					break;

			}

			if(nNewSection == XMLConsts.SECT_FAILED)
				done = true;
			else
				nCurrentSection = nNewSection;
		}

		sNewPath = m_sectionBuffer.toString();

		if(sTagID.length() > 0)
			nTagID = Integer.parseInt(sTagID);

		if(sTagValueID.length() > 0)
			nTagValueID = Integer.parseInt(sTagValueID);

		if(sTagValue.length() > 0)
			sTagValue = sTagValue.substring(1, sTagValue.length() - 1);

		if(sAttributeValue.length() > 0)
			sAttributeValue = sAttributeValue.substring(1, sAttributeValue.length() - 1);

		return nNewSection;
	}

	private final void resetValues()
	{
		sTagName = "";
		sTagID = "";
		sTagValue = "";
		sTagValueID = "";
		sAttribute = "";
		sAttributeValue = "";
		sNewPath = "";
		m_valueChar = '0';
	}

	private int sectInitProc(String sPath)
	{
		char firstChar = sPath.charAt(0);
		switch(firstChar)
		{
			case '/':
				return XMLConsts.SECT_PARSED;
			case '[':
				return XMLConsts.SECT_TAG_ID;
			case '=':
			case '\'':
			case '"':
				return XMLConsts.SECT_TAG_VALUE;
			case '{':
				return XMLConsts.SECT_ATTRIBUTE;
			default:
				return XMLConsts.SECT_TAG_NAME;
		}
	}

	/**
	 * procedure for TagName processing.
	 *
	 */
	private int sectTagNameProc(char charAt)
	{
		switch(charAt)
		{
			case '[':
			case '{':
			case '=':
			case '/':
				sTagName = m_sectionBuffer.toString();
				m_sectionBuffer.setLength(0);
				switch(charAt)
				{
					case '[':
						return XMLConsts.SECT_TAG_ID;
					case '=':
						return XMLConsts.SECT_TAG_VALUE;
					case '{':
						return XMLConsts.SECT_ATTRIBUTE;
					case '/':
						return XMLConsts.SECT_PARSED;
				}
			default: m_sectionBuffer.append(charAt);
				return XMLConsts.SECT_TAG_NAME;
		}
	}

	/**
	 * procedure for TagID processing, section like ([)index]
	 *
	 */
	private int sectTagIDProc(char charAt)
	{
		switch(charAt)
		{
			case '[':
			case ']':
				return XMLConsts.SECT_TAG_ID;
			case '=':
			case '{':
			case '/':
				sTagID = m_sectionBuffer.toString();
				m_sectionBuffer.setLength(0);
				switch(charAt)
				{
					case '=':
						return XMLConsts.SECT_TAG_VALUE;
					case '{':
						return XMLConsts.SECT_ATTRIBUTE;
					case '/':
						return XMLConsts.SECT_PARSED;
				}
			default: m_sectionBuffer.append(charAt);
				return XMLConsts.SECT_TAG_ID;
		}
	}

	/**
	 * procedure for TagValue processing, section like (=)"somet[h{ing"
	 *
	 */
	private int sectTagValueProc(char charAt)
	{
		switch(charAt)
		{
			case '"':
			case '\'':
				if(m_valueChar == '0')
				{
					m_valueChar = charAt;
					m_isValueBody = true;
				}
				else
				{
					if(m_valueChar == charAt)
						m_isValueBody = false;

					m_sectionBuffer.append(charAt);
					return XMLConsts.SECT_TAG_VALUE;
			    }
			case '[':
			case '{':
			case '/':
				if(!m_isValueBody)
				{
					sTagValue = m_sectionBuffer.toString();
					m_sectionBuffer.setLength(0);
					m_valueChar = '0';
					switch(charAt)
					{
						case '[':
							return XMLConsts.SECT_TAG_VALUE_ID;
						case '{':
							return XMLConsts.SECT_ATTRIBUTE;
						case '/':
							return XMLConsts.SECT_PARSED;
					}
				}
			default: m_sectionBuffer.append(charAt);
				return XMLConsts.SECT_TAG_VALUE;
		}
	}

	/**
	 * procedure for TagValueID processing, section like ([)index]
	 *
	 */
	private int sectTagValueIDProc(char charAt)
	{
		switch(charAt)
		{
			case ']':
				return XMLConsts.SECT_TAG_VALUE_ID;
			case '{':
			case '/':
				sTagValueID = m_sectionBuffer.toString();
				m_sectionBuffer.setLength(0);
				switch(charAt)
				{
					case '{':
						return XMLConsts.SECT_ATTRIBUTE;
					case '/':
						return XMLConsts.SECT_PARSED;
				}
			default: m_sectionBuffer.append(charAt);
				return XMLConsts.SECT_TAG_VALUE_ID;
		}
	}

	/**
	 * procedure for Attributes processing, section like ({)dsfdsfdsfsdf}
	 *
	 */
	private int sectAttributeProc(char charAt)
	{
		switch(charAt)
		{
			case '}': // end of attribute
				return XMLConsts.SECT_ATTRIBUTE;
			case '=':
			case '/':
				sAttribute = m_sectionBuffer.toString();
				if(sAttribute.charAt(0) == '{')
					sAttribute = sAttribute.substring(1);
				m_sectionBuffer.setLength(0);
				switch(charAt)
				{
					case '=':
						return XMLConsts.SECT_ATTRIBUTE_VALUE;
					case '/':
						return XMLConsts.SECT_PARSED;
				}
			default: m_sectionBuffer.append(charAt);
				return XMLConsts.SECT_ATTRIBUTE;
		}
	}

	/**
	 * procedure for AttributesValue processing, section like (=)"dsfdsfdsfsdf"}
	 *
	 */
	private int sectAttributeValueProc(char charAt)
	{
		switch(charAt)
		{
			case '"':
			case '\'':
				if(m_valueChar == '0')
				{
					m_valueChar = charAt;
					m_isValueBody = true;
				}
				else
				{
					if(m_valueChar == charAt)
						m_isValueBody = false;

					m_sectionBuffer.append(charAt);
					return XMLConsts.SECT_ATTRIBUTE_VALUE;
			    }
			case '}':
			case '/':
				if(!m_isValueBody)
				{
					switch(charAt)
					{
						case '}':
							return XMLConsts.SECT_ATTRIBUTE_VALUE;
						case '/':
							sAttributeValue = m_sectionBuffer.toString();
							m_sectionBuffer.setLength(0);
							return XMLConsts.SECT_PARSED;
					}
				}
			default: m_sectionBuffer.append(charAt);
				return XMLConsts.SECT_ATTRIBUTE_VALUE;
		}
	}

	public String toString()
	{
		return
			"m_sPath = "+ m_sPath + "; \n" +
			"sTagName = " + sTagName + "; \n" +
			"sTagID = " + sTagID + "; \n" +
			"sTagValue = " + sTagValue + "; \n" +
			"sTagValueID = " + sTagValueID + "; \n" +
			"sAttribute = " + sAttribute + "; \n" +
			"sAttributeValue = " + sAttributeValue + "; \n" +
			"sNewPath = " + sNewPath;
	}

	/**
	 * @return the sTagName
	 */
	public String getTagName()
	{
		return sTagName;
	}

	/**
	 * @return the sTagID
	 */
	public String getTagID()
	{
		return sTagID;
	}

	/**
	 * @return the nTagID
	 */
	public int getTagId()
	{
		return nTagID;
	}

	/**
	 * @return the nTagValueID
	 */
	public int getTagValueId()
	{
		return nTagValueID;
	}

	/**
	 * @return the sTagValue
	 */
	public String getTagValue()
	{
		return sTagValue;
	}

	/**
	 * @return the sTagValueID
	 */
	public String getTagValueID()
	{
		return sTagValueID;
	}

	/**
	 * @return the sAttribute
	 */
	public String getAttribute()
	{
		return sAttribute;
	}

	/**
	 * @return the sAttributeValue
	 */
	public String getAttributeValue()
	{
		return sAttributeValue;
	}

	/**
	 * @return the sNewPath
	 */
	public String getNewPath()
	{
		return sNewPath;
	}
}