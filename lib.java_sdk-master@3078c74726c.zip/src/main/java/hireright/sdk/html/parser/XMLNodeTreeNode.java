/*
 * @(#)$RCSfile: XMLNodeTreeNode.java,v $ $Revision: 1.8 $ $Date: 2009/12/18 07:13:32 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLNodeTreeNode.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov					2002-02-12  Created
 *	A.Solntsev				2006-10-31	implements Serializable
 *	A.Solntsev				2008-11-13	Added checks for infinite loop
 *	A.Solntsev				2009-12-09	Removed method finalize(); StringBuffer -> StringBuilder 
 */
package hireright.sdk.html.parser;

/**
 * Real node from tree. There are base nodes, like <something>.
 * 
 * @author  Sergei Ignatov
 * @version $Revision: 1.8 $ $Date: 2009/12/18 07:13:32 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLNodeTreeNode.java,v $
 */
public class XMLNodeTreeNode extends XMLTreeNode
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	private StringBuilder m_sbParseData;
	private int m_nLength = 0;
	private int m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
	private int m_nAttributeSection = XMLConsts.SECT_ATTRIBUTE;
	private XMLAttributesSection m_attributes;
	private boolean m_isParsedWithChilds = true;

	@Override
	public int getType()
	{
		return XMLConsts.TYPE_NODE;
	}

	public XMLNodeTreeNode(String sTagName, String sText)
	{
		super(sTagName, sText);
	}

	/**
	 * After creating empty node, client needs to call methods setTag() and setValue()/addchildNode().
	 *
	 * @deprecated Use constructor with tag name and value.
	 */
	public XMLNodeTreeNode()
	{
		super(null, null);
	}
	/*
	public XMLNodeTreeNode(String sSource) throws XMLObjectException
	{
		parse(sSource);
	}*/

	@Override
	public final void parse(String sSource) throws XMLObjectException
	{
		try
		{
			onStartParsing();
			m_nLength = 0;
			m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
			m_nAttributeSection = XMLConsts.SECT_ATTRIBUTE;
			m_attributes = XMLAttributesSection.reuse(m_attributes);
			super.parse(sSource);
		}
		finally
		{
			postParse();
		}
	}

	@Override
	public final int parseAppend(char c)
	{
		m_nLength++;
		if (m_nLength < 2) // skip <
			return XMLConsts.SECT_PARSED;

		switch(m_nCurrentSection)
		{
			case XMLConsts.SECT_TAG_NAME:
			{
				switch(c)
				{
					case ' ':
					case '	':
					case 0x0D:
					case 0x0A:
					{
						m_nCurrentSection = XMLConsts.SECT_ATTRIBUTE;
						setXMLTag(m_sbParseData.toString());
						m_sbParseData = null;	// reuse(m_sbParseData);
						m_attributes = XMLAttributesSection.reuse(m_attributes);
						return XMLConsts.SECT_INPROGRESS;
					}
					case '/':
					{
						m_isParsedWithChilds = false;
						setXMLTag(m_sbParseData.toString());
						m_nCurrentSection = XMLConsts.SECT_TAG_VALUE_ID;
						return XMLConsts.SECT_INPROGRESS;
					}
					case '>':
					{
						setXMLTag(m_sbParseData.toString());
						return XMLConsts.SECT_PARSED;
					}
					default:
					{
						m_sbParseData.append(c);
						return XMLConsts.SECT_INPROGRESS;
					}
				}
			}
			case XMLConsts.SECT_TAG_VALUE_ID:
			{
				switch(c)
				{
					case '>':
						return XMLConsts.SECT_PARSED;
					default:
						return XMLConsts.SECT_FAILED;
				}
			}
			case XMLConsts.SECT_ATTRIBUTE:
			{
				switch(c)
				{
					case '/':
					{
						if (m_nAttributeSection != XMLConsts.SECT_ATTRIBUTE_VALUE)
						{
							m_isParsedWithChilds = false;
							m_nCurrentSection = XMLConsts.SECT_ATTRIBUTE_VALUE;
							return XMLConsts.SECT_INPROGRESS;
						}
						break;
					}
					case '>':
					{
						if(m_nAttributeSection != XMLConsts.SECT_ATTRIBUTE_VALUE)
						{
							appendAttributes(m_attributes);
							m_attributes.release();
							m_attributes = null;

							return XMLConsts.SECT_PARSED;
						}
						break;
					}
				}

				m_nAttributeSection = m_attributes.parseAppend(c);
				if (m_nAttributeSection == XMLConsts.SECT_FAILED)
					return XMLConsts.SECT_FAILED;

				return XMLConsts.SECT_INPROGRESS;
			}
			case XMLConsts.SECT_ATTRIBUTE_VALUE:
			{
				switch(c)
				{
					case '>':
						appendAttributes(m_attributes);
						m_attributes.release();
						m_attributes = null;

						return XMLConsts.SECT_PARSED;
					default:
						return XMLConsts.SECT_FAILED;
				}
			}
		}

		return XMLConsts.SECT_FAILED;
	}

	@Override
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		StringBuffer sbTabs = new StringBuffer();

		try
		{
			makeTree(sb, sbTabs, false);
			return sb.toString();
		}
		finally
		{
			sbTabs.setLength(0);
			sb.setLength(0);
		}
	}

	@Override
	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		printTree(out, bNiceOutput, style);
	}

	public void printTree(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		boolean isCloseAppended = false;
		out.print("<");
		out.print(getXMLTag());
		printAttributesSectionString(out, bNiceOutput, style);
		// childs section begin
		XMLTreeNode childNode = this.getChildXmlNode();
		//int nLastNodeType = XMLConsts.TYPE_UNKNW;
		
		int cntLoop=0;
		while (childNode != null)
		{
			assert ++cntLoop < 1000 : "Infinite loop";
			
			switch (childNode.getType())
			{
				case XMLConsts.TYPE_ATTRIBUTE:
				{
					break;
				}
				case XMLConsts.TYPE_NODE:
				{
					//nLastNodeType = XMLConsts.TYPE_NODE;
					if (!isCloseAppended)
					{
						isCloseAppended = true;
						out.print(">");
					}
					((XMLNodeTreeNode) childNode).print(out, bNiceOutput, style);
					break;
				}
				default:
				{
					if(!isCloseAppended)
					{
						isCloseAppended = true;
						out.print(">");
					}

					XMLNodeCommand command = getCommand(XMLNodeCommand.CMD_OUT_REPLACE_TEXT);
					if(command != null)
					{
						command.process(childNode, out);
					}
					else
					{
						// out.print(childNode.toString());
						childNode.print(out, bNiceOutput, style);
					}

					break;
				}
			}
			childNode = (XMLTreeNode) childNode.getNextNode();
		}
		// childs section end;
		if (!isCloseAppended)
		{
			out.print(" />");
		}
		else
		{
			out.print("</");
			out.print(getXMLTag());
			out.print(">");
		}
		
		if (bNiceOutput)
			out.print('\n'); //?
	}

	private void makeTree(StringBuffer sb, StringBuffer sbTabs, boolean bNiceOutput)
	{
		if (bNiceOutput && sbTabs.length() > 0)
		{
			sb.append(sbTabs);
		}

		boolean isCloseAppended = false;

		sb.append("<");
		sb.append(getXMLTag());
		printAttributes(sb);

		// childs section begin
		int nLastNodeType = XMLConsts.TYPE_UNKNW;
		
		int cntLoop=0;
		for (XMLTreeNode childNode = this.getChildXmlNode(); childNode != null; )
		{
			assert ++cntLoop < 1000 : "Infinite loop";
			switch (childNode.getType())
			{
				case XMLConsts.TYPE_ATTRIBUTE:
				{
					break;
				}
				case XMLConsts.TYPE_NODE:
				{
					nLastNodeType = XMLConsts.TYPE_NODE;
					if(!isCloseAppended)
					{
						isCloseAppended = true;
						sb.append(">");
						if (bNiceOutput)
							sb.append("\n");
					}
					sbTabs.append("	");
					((XMLNodeTreeNode) childNode).makeTree(sb, sbTabs, bNiceOutput);
					sbTabs.setLength(sbTabs.length() - 1);
					break;
				}
				default:
				{
					if (!isCloseAppended)
					{
						isCloseAppended = true;
						sb.append(">");
					}
					//
					XMLNodeCommand command = getCommand(XMLNodeCommand.CMD_OUT_REPLACE_TEXT);
					if (command != null)
					{
						command.process(childNode, null);
						sb.append(command.getStringResult());
					}
					else
						sb.append(childNode.toString());
					//
					break;
				}
			}
			childNode = (XMLTreeNode) childNode.getNextNode();
		}
		// childs section end;
		if(!isCloseAppended)
		{
			sb.append(" />");
		}
		else
		{
			if (bNiceOutput && nLastNodeType == XMLConsts.TYPE_NODE && sbTabs.length() > 0)
				sb.append(sbTabs.toString());
			sb.append("</");
			sb.append(getXMLTag());
			sb.append(">");
		}
		if (bNiceOutput)
		{
			sb.append("\n");
		}
	}

	@Override
	final XMLTreeNode addToParentXmlNode(XMLTreeNode node) throws XMLObjectException
	{
		if (m_isParsedWithChilds)
		{
			super.addToParentXmlNode(node);
			return this;
		}
		else
		{
			super.addToParentXmlNode(node);
			return node;
		}
	}

	@Override
	public void postParse()
	{
		// m_sbParseData.setLength(0); // it takes time!
		m_sbParseData = null;
	}
	
	protected void onStartParsing()
	{
		m_sbParseData = reuse(m_sbParseData);
	}
}