/*
 * @(#)$RCSfile: XMLTreeNode.java,v $ $Revision: 1.28 $ $Date: 2011/12/16 09:29:54 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLTreeNode.java,v $
 *
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   S.Ignatov    	XXXX-XX-XX  Created
 *   A.Solntsev		2003-10-10	added method addChildNode(String szTagName, String szText).
 *   S.Ignatov    	2004-02-17  modified getChildNodeByPathEx, nodeByPathCompare and added more getChildNodeByPath
 *   A.Keks			2004-03-11	added method clearText
 *   A.Solntsev		2004-03-19	Added method setText(String sValue, int nNodeType, int nDefaultNodeType).
 *   A.Solntsev		2004-04-08	Method addChildNode(String szTagName, String szText) is repaired.
 *	 A.Solntsev		2004-06-10	Method clearText() is repaired. Now it removes child nodes.
 *   Anton Keks		2004-08-30	Many speed optimizations of duplicateBranchInto()
 *	 A.Solntsev		2005-02-16	Removed "CloneNotSupportedException"
 *	 V.Nikitin		2005-11-16	Methods "getElementValue" and "setElementValue" were added
 *	 S.Kocherovets	2006-02-07	Cloning/Duplicating of nodes copies hash code optional.
 *   A.Solntsev		2006-06-19	New exception throwing framework
 *   A.Solntsev		2006-11-06	Added several methods: nodeValue(), getValue(), toProperties(), toString()
 *   A.Solntsev		2008-01-07	Added public method getFirstChildNode()
 *   E.Semagin		2008-03-20	Added public method addChildNodesTail(XMLTreeNode node)
 *   A.Solovyev		2008-10-31	Added public method addChildNode (String szTagName, String szText, int nNodeType)
 *   A.Solntsev		2008-11-13	Added checks for infinite loop
 *   A.Solntsev		2009-01-15	Added method getChildNodesByTag(final String xmlTag) for convenient for-loops
 *   A.Solntsev		2009-03-10	Fixed NPE in method getChildNodeByPath()
 *   A.Solntsev		2009-04-06	Constructors are deprecated
 *   A.Solntsev		2009-12-09	Removed method finalize(); StringBuffer -> StringBuilder 
 *   P.Sizov		2011-12-05	Added clearChildNodes() for recursively child nodes cleanup  
 *   P.Vammus		2017-03-27	HIVPE-13295: nodeByPathCompare() additional NPE check added.
 */
package hireright.sdk.html.parser;

import hireright.sdk.html.parser.XMLConsts.CLEARABLE_NODES;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedList;
import java.util.Vector;

/**
 * Generic XML Node. All manipulation with XMLNodes, except parsing
 * and outputting. Those operations done by XMLTreeNode descedants.
 * 
 * NB! Ideally, this class should be abstract. But currently I cannot do it, because it's
 * instantiated in several classes.
 *
 * @author  Sergei Ignatov
 * @version $Revision: 1.28 $, $Date: 2011/12/16 09:29:54 $ $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLTreeNode.java,v $
 */
public class XMLTreeNode extends TreeNode
{
	protected static final String CLASS_VERSION = "$Revision: 1.28 $ $Author: cvsroot $";

	private static final int RESULTS_AS_NODE = 0;
	private static final int RESULTS_AS_VECTOR = 1;

	private String m_sXMLTag;
	
	/**
	 * COMMENT ME
	 */
	protected XMLNodeCommand m_command;

	/**
	 * @deprecated Don't create this class directly, use one of subclasses,
	 * 		e.g. XMLNodeTreeNode
	 */
	@Deprecated
	public XMLTreeNode()
	{
		this(null);
	}

	/**
	 * @deprecated Don't create this class directly, use one of subclasses,
	 * 		e.g. XMLNodeTreeNode
	 */
	@Deprecated
	public XMLTreeNode(String sTagName)
	{
		m_sXMLTag = sTagName;
		if (m_sXMLTag == null)
		{
			m_sXMLTag = "";
			// System.out.println("WARNING! Created XML Tree Node with null tag");
		}
	}

	/**
	 * @deprecated Don't create this class directly, use one of subclasses,
	 * 		e.g. XMLNodeTreeNode
	 */
	@Deprecated
	public XMLTreeNode(String sTagName, String sText)
	{
		this(sTagName);
		if (sText != null && sText.length() > 0)
		{
			XMLTreeNode textNode = XMLTreeNodeParser.getNodeForType(XMLConsts.TYPE_TEXT, sText);

			// TODO Change to "setChildNode()"
			addChildNodeTail(textNode);
		}
	}

	public int getType()
	{
		return XMLConsts.TYPE_UNKNW;
	}

	/**
	 * Method seems to return SOME child node.
	 * @deprecated Use method {@link #getFirstChildNode()} instead.
	 * @return XMLTreeNode
	 */
	public Object getData()
	{
		return getFirstChildNode();
	}

	protected XMLTreeNode getChildXmlNode()
	{
		return (XMLTreeNode) super.firstChildNode();
	}

	protected XMLTreeNode getFistChildNode()
	{
		return (XMLTreeNode) super.firstChildNode();
	}

	/**
	 * I would not recommended to use this method because it makes your program much more complex.
	 * It introduces knowledge about internal structure of XMLObject to your program.
	 *
	 * @return the first child node of this node
	 */
	public XMLTreeNode getFirstChildNode()
	{
		return (XMLTreeNode) super.firstChildNode();
	}

	/**
	 * @return same as getFirstChildNode()
	 */
	public XMLTreeNode getChildNode()
	{
		return (XMLTreeNode) super.getChildTreeNode();
	}

	public void parse(String sSource) throws XMLObjectException
	{
		for (int counter = 0; counter < sSource.length(); counter++)
			parseAppend(sSource.charAt(counter));
	}

	/**
	 * Method should be overridden in subclasses
	 * TODO Make this method abstract
	 * @param c used in subclasses
	 * @return COMMENT ME
	 * @throws XMLObjectException in subclasses
	 */
	@SuppressWarnings("unused")
	public int parseAppend(char c) throws XMLObjectException
	{
		return XMLConsts.SECT_FAILED;
	}

	void appendAttributes(XMLAttributesSection attributes)
	{
		String sAttribName, sAttribValue;
		for (Iterator<String> it = attributes.getParsingResult().iterator(); it.hasNext(); )
		{
			sAttribName = it.next();
			sAttribValue = it.next();

			this.addChildNode(new TreeNodeAttrib(sAttribName, sAttribValue));
		}
	}

	protected final StringBuffer printAttributes(StringBuffer sbResult)
	{
		XMLTreeNode childNode = this.getChildXmlNode();
		int cntLoop = 0;
		while (childNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			if (childNode.getType() == XMLConsts.TYPE_ATTRIBUTE)
			{
				sbResult.append(' ');
				sbResult.append(childNode.toString());
			}
			childNode = childNode.getNextXmlNode();
		}

		return sbResult;
	}

	void printAttributesSectionString(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		XMLTreeNode childNode = getChildXmlNode();
		
		int cntLoop = 0;
		while (childNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if (childNode.getType() == XMLConsts.TYPE_ATTRIBUTE)
			{
				out.print(' ');
				//out.print(childNode.toString());
				childNode.print(out, bNiceOutput, style);
			}
			childNode = childNode.getNextXmlNode();
		}
	}

	/**
	 * FIXME make method final (since it's called from constructor)
	 *
	 * @param sTagName
	 */
	public void setXMLTag(String sTagName)
	{
		String sOldValue = m_sXMLTag;

		m_sXMLTag = sTagName;
		if (m_sXMLTag == null)
			m_sXMLTag = "";

		// If new tag is the same as old, it's no reason to notify listeners
		if (sOldValue == null && sTagName == null)
			return;
		if (sOldValue != null && sTagName != null && sOldValue.equals(sTagName))
			return;

		int nNodeType = this.getType();

		if (nNodeType != XMLConsts.TYPE_TEXT && nNodeType != XMLConsts.TYPE_CDATA)
		{
			XMLObject xmlObject = XML_STRUCTURE_CHANGE_LISTENER.get();
			if ( xmlObject == null)
			{
				xmlObject = getXMLObject(); // long method
			}

			if (xmlObject != null)
			{
				xmlObject.onXMLTagChanged(this, sOldValue);
			}
		}

		sOldValue = null;
	}

	public final String getXMLTag()
	{
		return m_sXMLTag;
	}

	public String getXMLTagBody()
	{
		return getXMLTag();
	}

	public String getXMLNamespace()
	{
		if(m_sXMLTag.indexOf(':') != -1)
			return m_sXMLTag.substring(0, m_sXMLTag.indexOf(':') - 1);

		return "";
	}

	public void setXMLNamespace(String propValue)
	{
		String sNameSpace = CStringUtils.nvl(propValue);

		if (sNameSpace.length() > 0)
			sNameSpace = sNameSpace + ":";

		String sXMLTag = getXMLTag();
		if(sXMLTag.indexOf(':') != -1)
			sXMLTag = sNameSpace + ":" + sXMLTag.substring(0, sXMLTag.indexOf(':') + 1);
		else
			sXMLTag = sNameSpace + sXMLTag;

		this.setXMLTag(sXMLTag);
	}

	public List<XMLTreeNode> getChildNodesListByTag(String propValue)
	{
		List<XMLTreeNode> result = new ArrayList<XMLTreeNode>();
		XMLTreeNode tempNode = getFirstChildNode();
		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if (tempNode.getType() != XMLConsts.TYPE_ATTRIBUTE && tempNode.getXMLTag().equals(propValue))
			{
				result.add(tempNode);
			}
			tempNode = tempNode.getNextXmlNode();
		}
		return result;
	}
	
	/**
	 * Recursively clear child nodes content.
	 * @param nNodeType type of node for cleaning
	 */
	public void clearChildNodes(CLEARABLE_NODES nNodeType)
	{
		clearChild(nNodeType.getNodeType(), 0);
	}
	
	/**
	 * Recursively clear child nodes content with infinite call check.
	 * @param nNodeType type of node for cleaning
	 * @param deepValue number of recursive calls
	 * @return number of this recursive call
	 */
	private int clearChild(int nNodeType, int deepValue)
	{
		assert ++deepValue < 100 : "Infinite recursive call";
		
		if (getChildNodeByType(nNodeType) == null)
		{
			return deepValue;
		}
		else
		{
			int cntLoop = 0;
			XMLTreeNode tempNode = getChildNode();
			while (tempNode != null)
			{
				assert ++cntLoop < 10000 : "Infinite loop";
				//found child node, try go deeper
				if (tempNode.getType() == XMLConsts.TYPE_NODE)
				{
					//node have no child, clear node value 
					if (tempNode.getChildNodeByType(XMLConsts.TYPE_NODE) == null 
							&& tempNode.getType() == nNodeType)
					{
						tempNode.clearText();
					}
					else
					{
						//recursively call with deep check 
						tempNode.clearChild(nNodeType, deepValue);
					}
				}
				//found clearable child node
				else if (tempNode.getType() == nNodeType)
				{
					tempNode.clearText();
				}
				tempNode = tempNode.getNextXmlNode();
			}
		}
		return deepValue;
	}
	
	public Iterable<XMLTreeNode> getChildNodesByTag(final String xmlTag)
	{
		final XMLTreeNode firstChild = getFirstChildNode();
		
		return new Iterable<XMLTreeNode>()
		{
			public Iterator<XMLTreeNode> iterator()
			{
				return new Iterator<XMLTreeNode>()
				{
					XMLTreeNode currentNode = findNext(firstChild);
					
					public boolean hasNext()
					{
						return currentNode != null;
					}
					public XMLTreeNode next()
					{
						XMLTreeNode result = currentNode;
						currentNode = findNext(currentNode.getNextXmlNode());
						return result;
					}
					public void remove()
					{
						throw new UnsupportedOperationException("Method remove is not supported");
					}
					private XMLTreeNode findNext(XMLTreeNode current)
					{
						XMLTreeNode tempNode = current;
						int cntLoop = 0;
						while (tempNode != null)
						{
							assert ++cntLoop < 10000 : "Infinite loop";
							
							if (tempNode.getType() != XMLConsts.TYPE_ATTRIBUTE && tempNode.getXMLTag().equals(xmlTag))
							{
								return tempNode;
							}
							tempNode = tempNode.getNextXmlNode();
						}
						return null;
					}
				};
			}
		};
	}
	
	/**
	 * Method returns the first child node with given tag.
	 * @param propValue
	 * @return null if no child node found with given tag
	 */
	public XMLTreeNode getChildNodeByTag(String propValue)
	{
		return getChildNodeByTag(propValue, 1);
	}

	/**
	 * de-precated It's easier to use method getChildNodesByTag(String xmlTag)
	 * 	 to iterate over all nodes with given name
	 * 
	 * @param propValue tag name
	 * @param nNodeIndex node number (1..N)
	 * @return
	 */
	public XMLTreeNode getChildNodeByTag(String propValue, int nNodeIndex)
	{
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();

		int counter = 1;
		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if (tempNode.getType() != XMLConsts.TYPE_ATTRIBUTE && tempNode.getXMLTag().equals(propValue))
			{
				if (nNodeIndex == counter)
					return tempNode;
				counter++;
			}
			tempNode = tempNode.getNextXmlNode();
		}

		return null;
	}

	public XMLTreeNode getChildNodeByTagEx(String propValue)
	{
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();

		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if(tempNode.getType() != XMLConsts.TYPE_ATTRIBUTE)
			{
				if(tempNode.getXMLTag().equals(propValue))
					return tempNode;
				else
				{
					XMLTreeNode tempNodeCh = tempNode.getChildNodeByTagEx(propValue);
					if (tempNodeCh != null)
						return tempNodeCh;
				}
			}
			tempNode = tempNode.getNextXmlNode();
		}

		return null;
	}

	/**
	 * @param sAttribName
	 * @return TreeNodeAttrib
	 * NOT RECOMMENDED	Don't use this method. Use method getAttribText() instead.
	 */
	public TreeNodeAttrib getAttribNode(String sAttribName)
	{
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();

		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if (tempNode.getType() == XMLConsts.TYPE_ATTRIBUTE &&
					tempNode.getXMLTag().equals(sAttribName))
				return (TreeNodeAttrib) tempNode;

			tempNode = tempNode.getNextXmlNode();
		}

		return null;
	}

	public boolean hasAttribute(String sAttribName)
	{
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();

		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if (tempNode.getType() == XMLConsts.TYPE_ATTRIBUTE &&
					tempNode.getXMLTag().equals(sAttribName))
				return true;

			tempNode = tempNode.getNextXmlNode();
		}

		return false;
	}


	/**
	 * FIXME Remove this method
	 */
	private TreeNodeAttrib getAttribNodeWithValue(String sAttribName)
	{
		return getAttribNode(sAttribName);
	}

	public String getAttribText(String propValue)
	{
		TreeNodeAttrib node = getAttribNode(propValue);
		if (node == null || node.firstChildNode() == null)
			return null;

		return ((XMLTreeNode) node.firstChildNode()).getXMLTag();
	}

	public String getText()
	{
		return getText(XMLConsts.TYPE_TEXT);
	}

	public String getText(int nNodeType)
	{
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();

		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if((tempNode.getType() & nNodeType) == tempNode.getType())
				return tempNode.getXMLTag();

			tempNode = tempNode.getNextXmlNode();
		}

		return "";
	}

	public void setText(String sValue)
	{
		setText(sValue, XMLConsts.TYPE_TEXT);
	}

	/**
	 * Sets the value of given XML Node.
	 *
	 * If node already has value of one of types nNodeType, it will be reset
	 * to sValue.
	 *
	 * If node does not have value of types nNodeType, will be created
	 * new value of type:
	 * 	a) TEXT, if nNodeType contains type TEXT.
	 *  b) Otherwise, lowest bit of bitmask nNodeType.
	 *
	 * @param	nNodeType	bit-mask of types, for example,
	 * 				XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA
	 *
	 * @param	sValue	new value for this node
	 */
	public void setText(String sValue, int nNodeType)
	{
		int nDefaultNodeType = XMLConsts.TYPE_TEXT;
		if ((nNodeType & nDefaultNodeType) == 0)
		{
			nDefaultNodeType = getLowestBit(nNodeType);
		}
		setText(sValue, nNodeType, nDefaultNodeType);
	}

	/**
	 * Returns the lowest non-zero bit.
	 * For example, if bitmask = 1044 = (1024 | 16 | 4),
	 * then the result is 4.
	 *
	 * If bitmask is eqaul to 0, returns 0.
	 *
	 * @param	bitmask	is an integer number.
	 */
	public static int getLowestBit(int bitmask)
	{
		/*
		 * This method should be located in another class...
		 */
		if (bitmask == 0)
			return 0;

		int bit = 1;
		while ((bit & bitmask) == 0)
			bit <<= 1;
		return bit;
	}

	/**
	 * Sets the value of given XML Node.
	 *
	 * If node already has value of one of types nNodeType, it will be reset
	 * to sValue.
	 *
	 * If node does not have value of types nNodeType, will be created
	 * new value of type nDefaultNodeType.
	 *
	 * @param	nNodeType	bit-mask of types, for example,
	 * 				XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA
	 *
	 * @param	nDefaultNodeType	bit-value of type, for example,
	 * 				XMLConsts.TYPE_CDATA
	 *        NB! It should not contain several bits, but only one!
	 *
	 */
	public void setText(String sValue, int nNodeType, int nDefaultNodeType)
	{
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();
		XMLTreeNode resultNode = null;

		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if ((tempNode.getType() & nNodeType) == tempNode.getType())
			{
				resultNode = tempNode;
				break;
			}

			tempNode = tempNode.getNextXmlNode();
		}

		if (resultNode == null)
		{
			resultNode = XMLTreeNodeParser.getNodeForType(nNodeType, sValue);
			if(resultNode == null)
				resultNode = XMLTreeNodeParser.getNodeForType(
						getLowestBit(nDefaultNodeType), sValue);
			addChildNodeTail(resultNode);
		}

		resultNode.setXMLTag(sValue);
	}

	public XMLTreeNode getNextXmlNode()
	{
		return (XMLTreeNode) getNextNode();
	}

	/**
	 * Removes TEXT and CDATA childnodes
	 */
	public void clearText()
	{
		XMLTreeNode textNode = null;
		XMLTreeNode nextNode = (XMLTreeNode) firstChildNode();

		int cntLoop = 0;
		while (nextNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			textNode = nextNode;
			nextNode = textNode.getNextXmlNode();

			if(textNode.getType() == XMLConsts.TYPE_CDATA || textNode.getType() == XMLConsts.TYPE_TEXT)
			{
				removeChild(textNode);
			}
		}
	}

	static final ThreadLocal<XMLObject> XML_STRUCTURE_CHANGE_LISTENER = new ThreadLocal<XMLObject>();

	@Override
	protected void beforeNodeRemoved(TreeNode node)
	{
		XMLObject xmlObject = XML_STRUCTURE_CHANGE_LISTENER.get();
		if ( xmlObject == null)
		{
			xmlObject = getXMLObject(); // long method
		}

		if (xmlObject != null)
			xmlObject.onNodeRemoved((XMLTreeNode) node);
		super.beforeNodeRemoved(node);
	}

	@Override
	protected void afterNodeAdded(TreeNode node)
	{
		XMLObject xmlObject = XML_STRUCTURE_CHANGE_LISTENER.get();
		if ( xmlObject == null)
		{
			xmlObject = getXMLObject(); // long method
		}

		if (xmlObject != null)
			xmlObject.onNodeAdded((XMLTreeNode) node);
		super.afterNodeAdded(node);
	}

	public void removeChildNode(String szNodeTagValue)
	{
		XMLTreeNode node = (XMLTreeNode) getChildNodeByPath(szNodeTagValue);
		removeChild(node);
	}

	/**
	 * TODO	Is this method really used?
	 */
	public void removeAttribNode(String sAttribName)
	{
		XMLTreeNode node = getAttribNode(sAttribName);
		if (node != null)
			removeChild(node);
	}

	/**
	 * TODO	Is this method really used?
	 * @param sAttribName
	 */
	public void removeAttribNodeEx(String sAttribName)
	{
		removeAttribNode(sAttribName);
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();
		
		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if(tempNode.getType() != XMLConsts.TYPE_ATTRIBUTE)
				tempNode.removeAttribNodeEx(sAttribName);

			tempNode = tempNode.getNextXmlNode();
		}
	}

	/**
	 * Return node under this node tree by Path.
	 *
	 * @param sPathValue path like "test/f1/f2" or "test/f1/f2[2]/f3d/f4{retain}" or even "test/f1/[1]"
	 * "data='TExtMe'/level1{attr1=\"nice structure\"}/level2='level2_value'/level3/level4/[1]"
	 *
	 * @returns TreeNode, according to path, or null if such node is not found
	 */
	public XMLTreeNode getChildXmlNodeByPath(String sXPath)
	{
		return (XMLTreeNode) getChildNodeByPath(sXPath);
	}

	/**
	 * @deprecated Use method {@link #getChildXmlNodeByPath(String)} which 
	 * 	returns XMLTreeNode instead of TreeNode
	 */
	public TreeNode getChildNodeByPath(String sPathValue)
	{
		// prepare path
		String fixedPath = sPathValue;
		if (!sPathValue.endsWith("/"))
			fixedPath = sPathValue + "/";

		NodeByPathResult getResult = new NodeByPathResult();
		getResult.nResultsMode = RESULTS_AS_NODE;
		getResult.nNodeIndex = 1;

		getResult = getChildNodeByPathEx(getResult, fixedPath);
		return getResult.resultNode;
	}

	/**
	 * Return node under this node tree by Path.
	 *
	 * @param sPathValue path like "test/f1/f2" or "test/f1/f2[2]/f3d/f4{retain}" or even "test/f1/[1]"
	 * "data='TExtMe'/level1{attr1=\"nice structure\"}/level2='level2_value'/level3/level4/[1]"
	 *
	 * @returns TreeNode, according to path, or null if such node is not found
	 */
	public XMLTreeNode getChildXmlNodeByPath(String sPathValue, int nIndex)
	{
		return (XMLTreeNode) getChildNodeByPath(sPathValue, nIndex);
	}
	
	/**
	 * @deprecated Use method {@link #getChildXmlNodeByPath(String, int)} which 
	 * 	returns XMLTreeNode instead of TreeNode
	 */
	public TreeNode getChildNodeByPath(String sPathValue, int nIndex)
	{
		// prepare path;
		String fixedPath = sPathValue;
		if (!sPathValue.endsWith("/"))
			fixedPath = sPathValue + "/";

		NodeByPathResult getResult = new NodeByPathResult();
		getResult.nResultsMode = RESULTS_AS_NODE;
		getResult.nNodeIndex = nIndex;

		getResult = getChildNodeByPathEx(getResult, fixedPath);
		return getResult.resultNode;
	}

	/**
	 * @deprecated Use method {@link #getChildNodesByPath(String)} which returns List instead of Vector.
	 */
	@Deprecated
	public Vector<XMLTreeNode> getChildNodesListByPath(String sPathValue)
	{
		return new Vector<XMLTreeNode>(getChildNodesByPath(sPathValue));
	}
	
	/**
	 * Return nodes list under this node tree by Path.
	 *
	 * @param sPathValue path like "test/f1/f2" or "test/f1/f2[2]/f3d/f4{retain}" or even "test/f1/[1]"
	 * "data='TExtMe'/level1{attr1=\"nice structure\"}/level2='level2_value'/level3/level4/[1]"
	 * @return vector of TreeNodes
	 */
	public List<XMLTreeNode> getChildNodesByPath(String sPathValue)
	{
		// prepare path;
		String fixedPath = sPathValue;
		if(!sPathValue.endsWith("/"))
			fixedPath = sPathValue + "/";

		NodeByPathResult getResult = new NodeByPathResult();
		getResult.nNodeIndex = 1;
		getResult.nResultsMode = RESULTS_AS_VECTOR;
		getResult.vResults = new ArrayList<XMLTreeNode>();

		getResult = getChildNodeByPathEx(getResult, fixedPath);

		return getResult.vResults;
	}

	private class NodeByPathResult implements Serializable
	{
		private XMLTreeNode resultNode;
		private int nResultCode = XMLConsts.NODE_BYPATH_NOT_FOUND;
		private int nAnyNameTagCounter = 0;
		private int nSameNameTagCounter = 0;
		private int nSameValueCounter = 0;
		private int nResultsMode;
		private int nNodeIndex;
		private List<XMLTreeNode> vResults;
	}

	/**
	 * search for child node, using path value
	 *
	 * @param searchParameters structure filled with seacrh parameters
	 * @param sPathValue path to find nodes
	 */
	private NodeByPathResult getChildNodeByPathEx(NodeByPathResult searchParameters, String sPathValue)
	{
		// init path parser
		XMLTreePathParser pathParser = new XMLTreePathParser();
		// set value to parse
		pathParser.setParsePath(sPathValue);
		// parse first node expesion
		pathParser.parse();

		// loop child nodes
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();
		
		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			// compare non attribute nodes (attributes is part of comparsion)
			if (tempNode.getType() != XMLConsts.TYPE_ATTRIBUTE && tempNode.nodeByPathCompare(searchParameters, pathParser))
			{
				// if path ended (last node was compared)
				if (pathParser.getNewPath().length() == 0)
				{
					// check mode of results presentation
					if (searchParameters.nResultsMode == RESULTS_AS_VECTOR)
					{
						// collect results in vector and continue (results is vector)
						searchParameters.vResults.add(searchParameters.resultNode);
						searchParameters.resultNode = null;
					}
					else
					{
						// single node is result
						// reduce matched path node index
						searchParameters.nNodeIndex--;
						if (searchParameters.nNodeIndex == 0)
						{
							// search is finished
							searchParameters.nResultCode = XMLConsts.NODE_BYPATH_FOUND;

							// return results
							return searchParameters;
						}
						else
						{
							// continue search, index not matched
							searchParameters.nResultCode = XMLConsts.NODE_BYPATH_NOT_FOUND;
							searchParameters.resultNode = null;
						}
					}
				}
				else
				{
					// if path does`t ends (more entries in path need to be compared)
					NodeByPathResult searchParametersInt = new NodeByPathResult();
					searchParametersInt.nNodeIndex = searchParameters.nNodeIndex;
					searchParametersInt.vResults = searchParameters.vResults;
					searchParametersInt.nResultsMode = searchParameters.nResultsMode;

					// go into recursive search
					searchParametersInt = tempNode.getChildNodeByPathEx(searchParametersInt, pathParser.getNewPath());

					if(searchParametersInt.nResultCode == XMLConsts.NODE_BYPATH_FOUND)
					{
						// we got results, search is over
						return searchParametersInt;
					}
					else
					{
						// continue search
						searchParameters.nNodeIndex = searchParametersInt.nNodeIndex;
					}
				}
			}
			tempNode = tempNode.getNextXmlNode();
		}

		// node not found
		searchParameters.nResultCode = XMLConsts.NODE_BYPATH_NOT_FOUND;
		searchParameters.resultNode = null;

		return searchParameters;
	}

	/**
	 * compare xml tree node against part of path passed to getNodeByPath procedure
	 *
	 */
	private boolean nodeByPathCompare(NodeByPathResult getResult, XMLTreePathParser pathParser)
	{

		// increment total node index under parent, used if only index specified to search
		getResult.nAnyNameTagCounter++;

		// check any tag index, if node name not specified
		if (pathParser.getTagName().length() == 0 && pathParser.getTagID().length() != 0
				&& getResult.nAnyNameTagCounter != pathParser.getTagId())
			return false;

		// check name + name[index]
		if (pathParser.getTagName().length() != 0)
		{
			// check tag name if specified
			if (pathParser.getTagName().equals(this.getXMLTag()))
			{
				// increment same name nodes counter
				getResult.nSameNameTagCounter++;

				// check same name nodes tag index
				if(pathParser.getTagID().length() != 0 && getResult.nSameNameTagCounter != pathParser.getTagId())
				{
					// index doesn`t match
					return false;
				}
			}
			else
			{
				// name doesn`t match
				return false;
			}
		}

		// check node value
		if (pathParser.getTagValue().length() != 0)
		{
			// check for tag text value
			if (pathParser.getTagValue().equals(this.getText()))
			{
				// increment same values counter
				getResult.nSameValueCounter++;

				// check index of tag value with index
				if(pathParser.getTagValueID().length() != 0 && getResult.nSameValueCounter != pathParser.getTagValueId())
				{
					// tag value index doesn`t match
					return false;
				}
			}
			else
			{
				// tag value doesn`t match
				return false;
			}
		}

		// set passed node as result node
		getResult.resultNode = this;

		XMLTreeNode attribute = null;
		// check for attribute
		if(pathParser.getAttribute().length() != 0)
			if((attribute = this.getAttribNode(pathParser.getAttribute())) == null)
				return false;

		// check for attribute value
		if(attribute != null)
		{
			if (pathParser.getNewPath().length() == 0)
				getResult.resultNode = attribute;
			
			XMLTreeNode firstChildNode = (XMLTreeNode) attribute.firstChildNode();
			
			if(firstChildNode == null){ return false; }

			if (pathParser.getAttributeValue().length() != 0 && !firstChildNode.getXMLTag().equals(pathParser.getAttributeValue()))
			{
				return false;
			}
		}
		else
		{
			if(pathParser.getAttributeValue().length() != 0)
			{
				if((attribute = this.getAttribNodeWithValue(pathParser.getAttributeValue())) == null)
					return false;
				if(pathParser.getNewPath().length() == 0)
					getResult.resultNode = attribute;
			}
		}

		return true;
	}


	@Override
	public boolean equals(Object obj)
	{
		return obj != null && (obj instanceof XMLTreeNode) &&
			equals((XMLTreeNode) obj);
	}

	public boolean equals(XMLTreeNode eqNode)
	{
		return eqNode != null &&
			m_sXMLTag.equals(eqNode.m_sXMLTag) &&
			getType() == eqNode.getType();
	}
	
	@Override
	public int hashCode()
	{
		return getType() * CStringUtils.nvl(m_sXMLTag).hashCode();
	}

	/**
	 * this adds command, what will   COMMENT ME
	 */
	public void addOutputCmd(@SuppressWarnings("unused") XMLNodeCommand cmd)
	{
		//may be overridden in subclasses
	}

	/**
	 * FIXME  Remove or modify this method. It shoule not add new nodes.
	 */
	public void addAttribNode(String sName, String sValue)
	{
		removeAttribNode(sName);
		XMLTreeNode attributeNode = XMLTreeNodeParser.getNodeForType(
				XMLConsts.TYPE_ATTRIBUTE, sName, sValue);
		// attributeNode.setXMLTag(sName);
		// attributeNode.setText(sValue);
		addChildNode(attributeNode);
	}

	private final void addAttribNode(TreeNodeAttrib attribNode)
	{
		attribNode.setParent(this);
		TreeNodeAttrib tempAttrNode = getAttribNode(attribNode.getXMLTag());

		if (tempAttrNode != null)
			removeAttribNode(attribNode.getXMLTag());

		addChildNode(attribNode);
	}

	/*
	 * Method adds to node a child node <szTagName>szText</szTagName>.
	 * If error occurs (what generally cannot happen), returns null.
	 */
	public XMLTreeNode addChildNode (String szTagName, String szText)
	{
		XMLTreeNode newNode = XMLTreeNodeParser.getNodeForType(XMLConsts.TYPE_NODE,
				szTagName, szText);

		// This mixes both TEXT and CDATA values
		// newNode.setText(szText, XMLConsts.TYPE_CDATA, XMLConsts.TYPE_CDATA);

		addChildNodeTail(newNode, false);
		return newNode;
	}
	
	/**
	* Method adds to node a child node with data surrounded by special text. 
	* For example <szTagName><![CDATA[szText]]></szTagName>.
	 * 
	* @param szTagName - name of new node
	* @param szText - text in new node
	* @param nNodeType - type of special text
	* @return New node. If error occurs (what generally cannot happen), returns null.
	 *  
	* @see XMLConsts#TYPE_CDATA
	*/
	public XMLTreeNode addChildNode (String szTagName, String szText, int nNodeType)
	{
		XMLTreeNode newNode = XMLTreeNodeParser.getNodeForType(XMLConsts.TYPE_NODE,
				szTagName);

		newNode.setText(szText, nNodeType);

		addChildNodeTail(newNode, false);
		return newNode;
	}
	
	/**
	 * Duplicate the node.
	 * @return return duplicated node.
	 */
	public XMLTreeNode dublicate()
	{
		return dublicate(true);
	}

	/**
	 * Duplicate the node, copy the node's hash code if needed.
	 * @param isCloningHashCode if coping of the hash code is needed.
	 * @return duplicated node.
	 */
	public XMLTreeNode dublicate(boolean isCloningHashCode)
	{
		XMLTreeNode clonedNode = clone(isCloningHashCode);

		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();
		
		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			clonedNode.addChildNode(tempNode.dublicate(isCloningHashCode));
			tempNode = tempNode.getNextXmlNode();
		}

		return clonedNode;
	}

	/**
	 * Clone the node.
	 * @return the cloned node.
	 */
	@Override
	protected Object clone()
	{
		return clone(true);
	}

	/**
	 * Clone the node, copy the node's hash code if needed.
	 * @param isCloningHashCode if coping of the hash code is needed.
	 * @return the cloned node.
	 */
	protected XMLTreeNode clone(boolean isCloningHashCode)
	{
		XMLTreeNode xmlTreeNode = XMLTreeNodeParser.getNodeForType(getType(), getXMLTag()/*, getText()*/ );
		copyMembersData(xmlTreeNode, isCloningHashCode);
		return xmlTreeNode;
	}

	/**
	 * Copy the node's data to the passed node.
	 * @param node the passed node.
	 */
	protected void copyMembersData(XMLTreeNode node)
	{
		copyMembersData(node, true);
	}

	/**
	 * Copy the node's data to the passed node.
	 * @param node the passed node.
	 * @param isCloningHashCode if coping of the hash code is needed.
	 */
	protected void copyMembersData(XMLTreeNode node, boolean isCloningHashCode)
	{
		super.copyMembersData(node, isCloningHashCode);
		node.setXMLTag(getXMLTag());
	}

	/**
	 */
	public XMLTreeNode getChildNodeLike(XMLTreeNode node)
	{
		if (node == null)
			return null;

		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();

		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if (tempNode.getXMLTag().equals(node.getXMLTag()) && tempNode.getType() == node.getType())
				return tempNode;
			tempNode = tempNode.getNextXmlNode();
		}
		return null;
	}

	/**
	 * return last node of this type of less.
	 */
	public XMLTreeNode getChildNodeByType(int nNodeTypes)
	{
		return getChildNodeByType(nNodeTypes, true);
	}

	public XMLTreeNode getChildNodeByType(int nNodeTypes, boolean includeTypes)
	{
		XMLTreeNode tempNode = this.getChildXmlNode();

		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if (includeTypes)
			{
				if ((tempNode.getType() & nNodeTypes) == tempNode.getType())
					return tempNode;
			}
			else
			{
				if ((tempNode.getType() & nNodeTypes) != tempNode.getType())
					return tempNode;
			}


			tempNode = tempNode.getNextXmlNode();
		}

		return null;
	}

	public int getIndexForXMLTag()
	{
		int nResult = 1;
		XMLTreeNode parentNode = (XMLTreeNode) getParent();
		XMLTreeNode node = parentNode.getChildXmlNode();
		
		int cntLoop = 0;
		while (node != this)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if (node.equals(this))
			{
				if(node == this)
					return nResult;
				nResult++;
			}

			node = node.getNextXmlNode();
		}

		return nResult;
	}

	public String getPathForNode(XMLTreeNode lastBranchNode)
	{
		XMLTreeNode parentNode = (XMLTreeNode) lastBranchNode.getParent();
		StringBuffer sbPath = new StringBuffer();
		sbPath.insert(0, lastBranchNode.getXMLTag() + '[' + lastBranchNode.getIndexForXMLTag() + ']');

		int cntLoop = 0;
		while (parentNode != this)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			sbPath.insert(0, parentNode.getXMLTag() + '[' + parentNode.getIndexForXMLTag() + "]/");
			parentNode = (XMLTreeNode) parentNode.getParent();
		}

		return sbPath.toString();
	}

	public XMLTreeNode getParentNode()
	{
		return (XMLTreeNode) super.getParent();
	}
	
	public XMLTreeNode dublicateBranchInto(XMLTreeNode lastBranchNode, XMLTreeNode nodeToDublicateInto, int nBranchIndex)
	{
		// collect path
		XMLTreeNode parentNode = (XMLTreeNode) lastBranchNode.getParent();
		LinkedList<NodeByPathResult> nodesCollection = new LinkedList<NodeByPathResult>();

		// Collect nodes to duplicate
		NodeByPathResult nodeElement = new NodeByPathResult();
		nodeElement.resultNode = lastBranchNode;

		if (parentNode != this) // Speed Optimization (in other case, this will be overwritten anyway)
			nodeElement.nSameNameTagCounter = lastBranchNode.getIndexForXMLTag();

		nodesCollection.add(nodeElement);

		int cntLoop = 0;
		while (parentNode != this)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			nodeElement = new NodeByPathResult();
			nodeElement.resultNode = parentNode;
			nodeElement.nSameNameTagCounter = parentNode.getIndexForXMLTag();
			nodesCollection.add(nodeElement);
			parentNode = (XMLTreeNode) parentNode.getParent();

			if(parentNode == null)
				return null;
		}

		nodeElement.nSameNameTagCounter = nBranchIndex;

		// follow path and create nodes
		XMLTreeNode thisNode = nodeToDublicateInto;

		int cntLoop3 = 0;
		do
		{
			assert ++cntLoop3 < 10000 : "Infinite loop";
			
			nodeElement = nodesCollection.getLast();
			nodesCollection.removeLast();

			XMLTreeNode foundNode = null;

			if (nodeElement.nSameNameTagCounter != XMLConsts.ADD_TO_TAIL)
			{
				// Try to find an existing node in case it's index was specified
				foundNode = thisNode.getChildNodeByTag(nodeElement.resultNode.getXMLTag(), nodeElement.nSameNameTagCounter);
			}

			if (foundNode != null)
			{
				// Node exists - let's continue
				thisNode = foundNode;
			}
			else
			{
				// We should create a node
				int nNumberOfNodesToAdd = 1;

				if (nodeElement.nSameNameTagCounter != XMLConsts.ADD_TO_TAIL)
				{
					// find number of children with the given XML tag
					nNumberOfNodesToAdd = nodeElement.nSameNameTagCounter - thisNode.getChildNodesCount(nodeElement.resultNode.getXMLTag());
				}

				while (--nNumberOfNodesToAdd >= 0)
				{
					XMLTreeNode createdNode = (XMLTreeNode) nodeElement.resultNode.clone();
					thisNode.addChildNode(createdNode);

					// Duplicate children
					XMLTreeNode child = (XMLTreeNode) nodeElement.resultNode.firstChildNode();
					
					int cntLoop2 = 0;
					while (child != null)
					{
						assert ++cntLoop2 < 10000 : "Infinite loop";
						
						switch (child.getType())
						{
							case XMLConsts.TYPE_ATTRIBUTE:
								TreeNodeAttrib clonedChild = (TreeNodeAttrib) child.dublicate();
								createdNode.addAttribNode(clonedChild);
								break;
						}
						child = child.getNextXmlNode();
					}

					// Remember last created node
					foundNode = createdNode;
				}

				thisNode = foundNode;
			}
		}
		while (nodesCollection.size() > 0);

		return thisNode;
	}

	public XMLTreeNode dublicateBranch(XMLTreeNode lastBranchNode, int nBranchIndex)
	{
		return dublicateBranchInto(lastBranchNode, this, nBranchIndex);
	}

	/**
	 * @deprecated Use method getXMLObject()
	 * @return XML Object to which this XML Node belongs
	 */
	public final XMLObject getXMLObjectRoot()
	{
		return getXMLObject();
	}

	public XMLObject getXMLObject()
	{
		XMLRootTreeNode root = getRootNode();
		if (root != null)
			return getRootNode().getXMLObject();

		return null;
	}

	XMLRootTreeNode getRootNode()
	{
		XMLTreeNode root = (XMLTreeNode) getRoot();
		if (root != null && root.getType() == XMLConsts.TYPE_ROOT)
			return (XMLRootTreeNode) root;

		return null;
	}
	
	public String getSystemId()
	{
		XMLObject xmlObject = getXMLObject();
		if (xmlObject != null)
			return xmlObject.getSystemId();
		
		return null;
	}

	/**
	*
	*/
	public void addCommand(XMLNodeCommand command)
	{
		m_command = command;
	}

	public XMLNodeCommand getCommand(@SuppressWarnings("unused") int nCmdType)
	{
		return m_command;
	}

	public int getChildNodesCount(String sXMLTag)
	{
		XMLTreeNode tempNode = (XMLTreeNode) firstChildNode();

		int counter = 0;
		int cntLoop = 0;
		while (tempNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			if(tempNode.getType() != XMLConsts.TYPE_ATTRIBUTE &&
			tempNode.getXMLTag().equals(sXMLTag))
			{
				counter++;
			}
			tempNode = tempNode.getNextXmlNode();
		}
		return counter;
	}

	protected void onStartParsing()
	{
		// Overridden in subclasses
	}
	
	public void postParse()
	{
		// May be overridden in subclasses
	}

	/**
	 * Return element value by XPath
	 *
	 * @param xpath String XPath to element
	 * @return String Value of element
	 */
	public String getElementValue(String xpath)
	{
		XMLTreeNode child = (XMLTreeNode) getChildNodeByPath(xpath);
		return (child == null)? null : 
			child.getText(XMLConsts.TYPE_CDATA + XMLConsts.TYPE_TEXT);
	}

	/**
	 * Set element value by Xpath
	 *
	 * @param xpath String XPath to element
	 * @param value String Value of element
	 */
	public void setElementValue(String xpath, String value)
	{
		((XMLTreeNode) getChildNodeByPath(xpath)).setText(
			value, XMLConsts.TYPE_CDATA);
	}

	XMLTreeNode addToParentXmlNode(XMLTreeNode node) throws XMLObjectException
	{
		return (XMLTreeNode) super.addToParent(node);
	}

	/**
	 * @since java_sdk_v2-6-21
	 * @return Value of this xml node (of type TEXT or CDATA)
	 */
	public String getValue()
	{
		return getText(XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA);
	}

	/**
	 * Utility method for safe getting value of node.
	 *
	 * @param node
	 * @param szDefault
	 * @return Text value of <code>node</code> (of type CDATA or TEXT)
	 * @since java_sdk_v2-6-21
	 */
	public static String nodeValue(XMLTreeNode node, String szDefault)
	{
		if (node == null)
			return szDefault;

		String szRetValue = node.getText(XMLConsts.TYPE_CDATA + XMLConsts.TYPE_TEXT);

		if (szRetValue == null || szRetValue.length() == 0)
			return szDefault;

		return szRetValue;
	}

	/**
	 * @since java_sdk_v2-6-21
	 */
	@Override
	public String toString()
	{
		return "<" + getXMLTag() + ">" + getValue() + "</" + getXMLTag() + ">";
	}

	@Override
	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		out.print("<");
		out.print(getXMLTag());
		out.print(">");
		out.print(getValue());
		out.print("</");
		out.print(getXMLTag());
		out.print(">");
	}

	/**
	 * Helper method for reusing StringBuffers during parsing XML.
	 * If sb is null, method creates new StirngBuffer.
	 * Otherwise, method clears <code>sb</code> and returns it.
	 *
	 * @param sb any StringBuffer.
	 * @return the same StringBuffer, if it's not null
	 *
	 * @since java_sdk_v2-6-14
	 */
	protected StringBuilder reuse(StringBuilder sb)
	{
		if (sb == null)
			return new StringBuilder();

		sb.setLength(0);
		return sb;
		// return new StringBuffer();
	}

	/**
	 * @since java_sdk_v2-6-14
	 */
	public CProperties toProperties()
	{
		return new CProperties()
			.setProperty("tag", getXMLTag())
			.setProperty("value", getChildXmlNode());
	}

	/**
	 * Add all child nodes from node.
	 * @param node xml node which contains nodes to add
	 *
	 * @since java_sdk_v2-9-3
	 */
	public void addChildNodesTail(XMLTreeNode node)
	{
		XMLTreeNode childNode = node.getFirstChildNode();
		
		int cntLoop = 0;
		while (childNode != null)
		{
			assert ++cntLoop < 10000 : "Infinite loop";
			
			XMLTreeNode nextNode = childNode.getNextXmlNode();
			addChildNodeTail(childNode);
			childNode = nextNode;
		}
	}
}
