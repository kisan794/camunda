/*
 * @(#)$RCSfile: XMLObjectRuntimeException.java,v $Revision: 1.6 $ $Date: 2008/11/21 11:31:12 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLObjectRuntimeException.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-06-25	created
 * 	A.Solntsev			2008-08-28	Added constructor (String sMessage, Throwable cause, CProperties params)
 */
package hireright.sdk.html.parser;

import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;

/**
 * @author asolntsev
 * @since Jun 25, 2007
 * @version $Revision: 1.6 $ $Date: 2008/11/21 11:31:12 $ $Author: cvsroot $
 */
public class XMLObjectRuntimeException extends CRuntimeException
{
	protected XMLObjectRuntimeException(XMLObjectException cause)
	{
		super(cause, cause.toProperties(), cause.getData());
	}
	
	public XMLObjectRuntimeException(String sMessage, Throwable cause, CProperties params)
	{
		super(sMessage, cause, params);
	}

	public XMLObjectRuntimeException(Throwable cause, CProperties params, String sContent)
	{
		super(cause, params, sContent);
	}
	
	public XMLObjectRuntimeException(Throwable cause, String sXmlUrl)
	{
		super(cause, new CProperties().setProperty("sXmlUrl", sXmlUrl));
	}
	
	
}
