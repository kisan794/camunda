package hireright.sdk.html.parser;

/*
 * Copyright 2001-2020 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Naboyshchikov	2020-09-22	HRG-126805: created
 */

import hireright.lib.logging.util.lang.ExceptionUtils;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.html.utils.XHTMLInjector;
import hireright.sdk.util.CProperties;

import java.net.MalformedURLException;
import java.net.URL;

public class XMLObjectFactory
{

		/**
		 * Method to create XMLObject form URL to XML file. 
		 * In case of IOException while reading this file the second attempt will be performed.
		 * 
		 * @param urlOfSourceXMLData
		 * @return
		 */
		public static XMLObject getXMLObjectFromURL(URL urlOfSourceXMLData) throws XMLObjectException
		{
				XMLObject xmlObject;
				try
				{
						xmlObject = new XMLObject(urlOfSourceXMLData);
				}
				catch(XMLObjectException e)
				{
						if(ExceptionUtils.unwrap(e, java.io.IOException.class) != null)
						{
								xmlObject = new XMLObject(urlOfSourceXMLData);
								CProperties properties = new CProperties();
								if(urlOfSourceXMLData != null)
								{
										properties.setProperty("URL", urlOfSourceXMLData.getPath());
								}
								CTraceLog.warning("XML object was loaded from URL on the second attempt", XHTMLInjector.class.getName(),
										properties);
						}
						else
						{
								throw e;
						}
				}
				return xmlObject;
		}
		
		/**
		 * Method to create XMLObject form String URL to XML file. 
		 * In case of IOException while reading this file the second attempt will be performed.
		 * 
		 * @param sUrlOfSourceXMLData
		 * @return
		 */
		public static  XMLObject getXMLObjectFromURL(String sUrlOfSourceXMLData)
		{
			try
			{
				return getXMLObjectFromURL(new URL(sUrlOfSourceXMLData));
			}
			catch (MalformedURLException | XMLObjectException urle)
			{
				throw new XMLObjectRuntimeException(urle, sUrlOfSourceXMLData);
			}
		}
}
