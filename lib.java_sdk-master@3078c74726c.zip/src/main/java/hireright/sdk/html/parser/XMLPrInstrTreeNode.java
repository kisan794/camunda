/*
 * @(#)$RCSfile: XMLPrInstrTreeNode.java,v $ $Revision: 1.6 $ $Date: 2009/12/18 07:12:37 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLPrInstrTreeNode.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov				2002-02-12	Created
 *	A.Solntsev			2009-12-09	Removed method finalize(); StringBuffer -> StringBuilder 
 */
package hireright.sdk.html.parser;

/**
 * node like <?tag attribute='1.0'?>
 * processing instruction parsing, outputting.
 * last changed 2002/01/04
 */
public class XMLPrInstrTreeNode extends XMLTreeNode
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	private StringBuilder m_sbParseData;
	private int m_nLength = 0;
	private int m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
	private int m_nAttributeSection = XMLConsts.SECT_ATTRIBUTE;
	private XMLAttributesSection m_attributes = new XMLAttributesSection();
	
	public int getType()
	{
		return XMLConsts.TYPE_PROCESSING_INSTRUCTION;
	}	
	
	/**
	 * TODO Remove this method
	 */
	private XMLPrInstrTreeNode()
	{
	}
	
	/**
	 * TODO Remove this method
	 */
	private XMLPrInstrTreeNode(String sSource) throws XMLObjectException
	{
		parse(sSource);
	}
	
	/**
	 * 
	 * @param sTagName
	 * @param sText
	 * @since java_sdk_v2-6-14
	 */
	public XMLPrInstrTreeNode(String sTagName, String sText)
	{
		super(sTagName, sText);
	}

	
	public final void parse(String sSource) throws XMLObjectException
	{
		try
		{
			onStartParsing();
			m_nLength = 0;
			m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
			m_nAttributeSection = XMLConsts.SECT_ATTRIBUTE;
			m_attributes = XMLAttributesSection.reuse(m_attributes);
			super.parse(sSource);
		}
		finally
		{
			postParse();
		}
	}
	
	public int parseAppend(char c)
	{
		m_nLength++;
		if(m_nLength < 3) // skip <?
			return XMLConsts.SECT_PARSED;
			
		switch(m_nCurrentSection)
		{
			case XMLConsts.SECT_TAG_NAME:
				switch(c)
				{
					case ' ':
					case '	':
					case 0x0D:
					case 0x0A:
						m_nCurrentSection = XMLConsts.SECT_ATTRIBUTE;
						setXMLTag(m_sbParseData.toString());
						m_sbParseData = reuse(m_sbParseData);
						m_attributes = XMLAttributesSection.reuse(m_attributes);
						return XMLConsts.SECT_INPROGRESS;
					case '?':
						m_nCurrentSection = XMLConsts.SECT_TAG_VALUE_ID;
						return XMLConsts.SECT_INPROGRESS;
					default:
						m_sbParseData.append(c);
						return XMLConsts.SECT_INPROGRESS;
				}
			case XMLConsts.SECT_TAG_VALUE_ID:
				switch(c)
				{
					case '>':
						return XMLConsts.SECT_PARSED;
					default:
						return XMLConsts.SECT_FAILED;
				}
			case XMLConsts.SECT_ATTRIBUTE:
				switch(c)
				{
					case '?':
						if(m_nAttributeSection != XMLConsts.SECT_ATTRIBUTE_VALUE)
						{
							m_nCurrentSection = XMLConsts.SECT_ATTRIBUTE_VALUE;
							return XMLConsts.SECT_INPROGRESS;
						}
					default:
						m_nAttributeSection = m_attributes.parseAppend(c);
						if(m_nAttributeSection == XMLConsts.SECT_FAILED)
							return XMLConsts.SECT_FAILED;
						return XMLConsts.SECT_INPROGRESS;
				}
			case XMLConsts.SECT_ATTRIBUTE_VALUE:
				switch(c)
				{
					case '>':							
						appendAttributes(m_attributes);
						m_attributes.release();
						m_attributes = null;
						
						return XMLConsts.SECT_PARSED;
					default:
						return XMLConsts.SECT_FAILED;
				}
		}
		return XMLConsts.SECT_FAILED;
	}

	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		StringBuffer sbTabs = new StringBuffer();
		makeTree(sb, sbTabs, false);
		return sb.toString();
	}
	
	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		printTree(out, bNiceOutput, style);
	}
	
	public void printTree(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		out.print("<?");
		out.print(getXMLTag());
		printAttributesSectionString(out, bNiceOutput, style);
		out.print("?>");
	}	
	
	public void makeTree(StringBuffer sb, StringBuffer sbTabs, boolean bNiceOutput)
	{
		sb.append("<?");
		sb.append(getXMLTag());
		printAttributes(sb);
		
		sb.append("?>");
		if (bNiceOutput)
			sb.append("\n");
			
		if (bNiceOutput)
			sbTabs.append("	");
	}

	protected void onStartParsing()
	{
		m_sbParseData = reuse(m_sbParseData);
	}
	
	public void postParse()
	{
		m_sbParseData = null;
	}
}