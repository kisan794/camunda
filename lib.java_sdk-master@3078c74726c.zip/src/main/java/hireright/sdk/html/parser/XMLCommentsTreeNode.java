/*
 * @(#)$RCSfile: XMLCommentsTreeNode.java,v $ $Revision: 1.7 $ $Date: 2009/12/18 07:14:34 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLCommentsTreeNode.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	S.Ignatov					2003-10-23	parsing changed, allowed to parse any comment
 *	A.Solntsev				2007-08-03	When printing to HTML, remove comments from toString()
 *	A.Solntsev				2009-12-09	StringBuffer -> StringBuilder
 */
package hireright.sdk.html.parser;

import java.io.Serializable;

/**
 * represents node like <!-- something -->
 *
 * @author Sergei Ignatov
 * @version $Revision: 1.7 $ $Date: 2009/12/18 07:14:34 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLCommentsTreeNode.java,v $
 */
public class XMLCommentsTreeNode extends XMLTreeNode implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
	private static final String LABEL_START = "<!--";
	private static final String LABEL_END = "-->";
	private static final String COMMENTS_REMOVED = "";	// for debug: "<!-- comments removed -->";

	private StringBuilder m_sbParseData; // = new StringBuilder();
	private int m_nLength = 0;
	private int m_nCurrentSection = XMLConsts.SECT_TAG_NAME;


	public int getType()
	{
		return XMLConsts.TYPE_COMMENTS;
	}

	/**
	 * TODO Remove this constructor
	 */
	public XMLCommentsTreeNode()
	{
	}

	/**
	 * TODO Remove this constructor
	 * @throws XMLObjectException
	 */
	public XMLCommentsTreeNode(String sSource) throws XMLObjectException
	{
		parse(sSource);
	}

	/**
	 *
	 * @param sTagName
	 * @param sText
	 * @since java_sdk_v2-6-14
	 */
	public XMLCommentsTreeNode(String sTagName, String sText)
	{
		super(sTagName, sText);
	}

	protected void onStartParsing()
	{
		m_sbParseData = reuse(m_sbParseData);
	}
	
	public final void parse(String sSource) throws XMLObjectException
	{
		try
		{
			onStartParsing();
			m_nLength = 0;
			m_nCurrentSection = XMLConsts.SECT_TAG_NAME;
			super.parse(sSource);
		}
		finally
		{
			postParse();
		}
	}

	/**
	 * method for parsing html comments, char by char
	 * @param c
	 * @return COMMENT ME
	 */
	public int parseAppend(char c)
	{
		m_nLength++;

		// comments start check
		if (m_nLength < 4)
		{
			// parser knows, what first 3 symbols are <!-
			return XMLConsts.SECT_PARSED;
		}
		else
		{
			// so we need to check only 4`th symbol
			if(m_nLength == 4 && c!='-')
				return XMLConsts.SECT_FAILED;
		}

		// comments parsing
		// starts with 4`th symbol
		switch (m_nCurrentSection)
		{
			// section <!--
			case XMLConsts.SECT_TAG_NAME:
			{
				switch(c)
				{
					// only last symbol of <!-- allowed
					case '-':
						// go parse comments body
						m_nCurrentSection = XMLConsts.SECT_TAG_VALUE;
						return XMLConsts.SECT_INPROGRESS;
					default:
						// unknown xml section
						return XMLConsts.SECT_FAILED;
				}
			}
			// parse comments body
			case XMLConsts.SECT_TAG_VALUE:
			{
				switch(c)
				{
					// appears to be comments end.
					case '-':
						// go to comments end
						m_sbParseData.append(c);
						m_nCurrentSection = XMLConsts.SECT_TAG_VALUE_ID;
						return XMLConsts.SECT_INPROGRESS;
					// comments body data
					default:
						m_sbParseData.append(c);
						// continue body data
						m_nCurrentSection = XMLConsts.SECT_TAG_VALUE;
						return XMLConsts.SECT_INPROGRESS;
				}
			}
			// parse comments end
			case XMLConsts.SECT_TAG_VALUE_ID:
			{
				switch(c)
				{
					// continue parse comments
					case '-':
						// continue comments end
						m_sbParseData.append(c);
						m_nCurrentSection = XMLConsts.SECT_TAG_VALUE_ID;
						return XMLConsts.SECT_INPROGRESS;
					// finish parse comments
					case '>':
						// check end
						if(m_sbParseData.length() > 1 &&
							m_sbParseData.charAt(m_sbParseData.length()-1) == '-' &&
							m_sbParseData.charAt(m_sbParseData.length()-2) == '-')
						{
							// comments parsed
							m_sbParseData.setLength(m_sbParseData.length() - 2);
							setXMLTag(m_sbParseData.toString());
							return XMLConsts.SECT_PARSED;
						}
						else
						{
							// continue to comments body
							m_sbParseData.append(c);
							m_nCurrentSection = XMLConsts.SECT_TAG_VALUE;
							return XMLConsts.SECT_INPROGRESS;
						}
					// any char except '-', '>'
					default:
						m_sbParseData.append(c);
						m_nCurrentSection = XMLConsts.SECT_TAG_VALUE;
						return XMLConsts.SECT_INPROGRESS;
				}
			}
		}
		return XMLConsts.SECT_FAILED;
	}

	protected boolean doHideComments(XMLOutputStyle style)
	{
		/*XMLTreeNode rootNode = (XMLTreeNode) this.getRoot();

		return rootNode != null
			&& rootNode.getType() == XMLConsts.TYPE_ROOT
			&& ((XMLRootTreeNode) rootNode).getOutputSpecific() == XMLUtils.SPECIFIC_WEB_BROW;
		*/
		return XMLOutputStyle.WEB == style;
	}

	public String toString()
	{
		return (LABEL_START + getXMLTag() + LABEL_END);
	}

	public void print(java.io.PrintWriter out, boolean bNiceOutput, XMLOutputStyle style)
	{
		if (doHideComments(style))
		{
			out.print(COMMENTS_REMOVED);
		}
		else
		{
			out.print(LABEL_START);
			out.print(COMMENTS_REMOVED);
			out.println(LABEL_END);
		}
	}

	public void postParse()
	{
		m_sbParseData = null;
	}
}