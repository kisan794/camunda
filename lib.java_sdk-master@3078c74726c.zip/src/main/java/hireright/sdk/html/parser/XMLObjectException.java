/*
 * @(#)$RCSfile: XMLObjectException.java,v $ $Revision: 1.9 $ $Date: 2010/01/08 08:52:17 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLObjectException.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	S.Ignatov					2002-01-14	created
 *	A.Solntsev				2005-03-09	added javadoc
 *	A.Solntsev				2006-06-06	Enhanced logging: extends CException (added properties, sources, invalid XML, URL, row#, column#)
 *	A.Solntsev				2009-04-03	Fixed NPE in constructor: CStringUtils.truncate(100)
 *	A.Solntsev				2009-12-09	extends CRuntimeException
 *	M.Kuznetsov				2019-08-06	added additional exception info
 */
package hireright.sdk.html.parser;

import hireright.sdk.debug.CStackTrace;
import hireright.sdk.util.CFileContent;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;

import java.net.URL;

/**
 * Class implements XML Exception.
 * It occurs when XML Parser gets invalid XML.
 */
public class XMLObjectException extends CRuntimeException
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
	private String m_sInvalidXmlUrl;
	private int m_nRow;
	private int m_nColumn;
	private int m_nCharactersRead;
	private char m_cInvalidCharacter;

	/*
	 * Currently class stores only error message.
	 *
	 * @deprecated	It should also contain unparsed String that gave an error.
	 */
	public XMLObjectException(String s)
	{
		super(s);
	}

	public XMLObjectException(String s, String sInvalidXML)
	{
		super(s, (CProperties) null, sInvalidXML);
		m_sInvalidXmlUrl = CStringUtils.truncate( String.valueOf(sInvalidXML), 100 );
	}

	public XMLObjectException(Exception e, URL urlInvalidXml)
	{
		super(
				e.getMessage() + String.format(
						" [ for the %s ]",
						urlInvalidXml == null
								? "null"
								: urlInvalidXml.toString()),
				e,
				new CProperties().setProperty("url", urlInvalidXml),
				readUrl(urlInvalidXml));
		m_sInvalidXmlUrl = String.valueOf(urlInvalidXml);
	}

	public XMLObjectException(Exception e, String sXmlURI)
	{
		super(e, 
				new CProperties().setProperty("url", sXmlURI));
		m_sInvalidXmlUrl = sXmlURI;
	}

	public XMLObjectException(XMLObjectException xmle, int column, int row, int nCharactersRead, char invalidCharacter)
	{
		super(xmle.getMessage() + " at row " + row + ", column " + column + xmle.atUrl(),
			new CProperties()
				.setProperties(xmle.getProperties())
				.setProperty("row", row)
				.setProperty("column", column)
				.setProperty("invalidChar", invalidCharacter),
			xmle.getData());

		m_sInvalidXmlUrl = xmle.getInvalidXmlURL();
		m_nRow = row;
		m_nColumn = column;
		m_nCharactersRead = nCharactersRead;
		m_cInvalidCharacter = invalidCharacter;
	}

	private static String readUrl(URL url)
	{
		try
		{
			return CFileContent.getContent(url);
		}
		catch (Exception ioe)
		{
			return CStackTrace.getStackTrace(ioe);
		}
	}

	public int getCharactersRead()
	{
		return m_nCharactersRead;
	}

	public int getColumnNr()
	{
		return m_nColumn;
	}

	public int getRowNr()
	{
		return m_nRow;
	}

	public char getInvalidCharacter()
	{
		return m_cInvalidCharacter;
	}

	public String getInvalidXmlURL()
	{
		return m_sInvalidXmlUrl;
	}

	private String atUrl()
	{
		if (m_sInvalidXmlUrl == null)
			return "";
		return " at " + m_sInvalidXmlUrl;
	}

	/**
	 * Package-private method. Used in class XMLOject.
	 * @param asInvalidCharacter the cInvalidCharacter to set
	 */
	void setInvalidCharacter(char asInvalidCharacter)
	{
		m_cInvalidCharacter = asInvalidCharacter;
	}

	/**
	 * Package-private method. Used in class XMLOject.
	 * @param asCharactersRead the nCharactersRead to set
	 */
	void setCharactersRead(int asCharactersRead)
	{
		m_nCharactersRead = asCharactersRead;
	}

	/**
	 * Package-private method. Used in class XMLOject.
	 * @param asColumn the nColumn to set
	 */
	void setColumn(int asColumn)
	{
		m_nColumn = asColumn;
	}

	/**
	 * Package-private method. Used in class XMLOject.
	 * @param asRow the nRow to set
	 */
	void setRow(int asRow)
	{
		m_nRow = asRow;
	}

	/**
	 * Package-private method. Used in class XMLOject.
	 * @param asInvalidXmlUrl the sInvalidXmlUrl to set
	 */
	void setInvalidXmlUrl(String asInvalidXmlUrl)
	{
		m_sInvalidXmlUrl = asInvalidXmlUrl;
	}
}