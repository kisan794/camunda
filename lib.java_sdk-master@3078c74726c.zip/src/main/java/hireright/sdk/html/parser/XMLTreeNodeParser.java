/*
 * @(#)$RCSfile: XMLTreeNodeParser.java,v $ $Revision: 1.6 $ $Date: 2009/12/18 07:13:55 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLTreeNodeParser.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	S.Ignatov				2002-01-04	created
 *	A.Solntsev			2006-06-16	Added new method getNodeForType(String sTagName, String sText)
 *	A.Solntsev			2009-05-15	StringBuffer -> StringBuilder
 *	A.Solntsev			2009-12-09	Removed method finalize()
 */
package hireright.sdk.html.parser;

/**
 * This class detects possible Node type, by it`s first chars and returns
 * new nodes objects for given types.
 *
 * @author Sergei Ignatov
 * @since 2002-01-04
 * @version $Revision: 1.6 $ $Date: 2009/12/18 07:13:55 $ $Author: cvsroot $
 */
public class XMLTreeNodeParser
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";

	static int preDetermNodeTypeProc(StringBuilder sSource)
	{
		if (sSource.length() == 0)
			return XMLConsts.PARSE_FAILED;

		char firstChar = sSource.charAt(0);
		switch(firstChar)
		{
			case '<':
				if (sSource.length() < 2)
					return XMLConsts.PARSE_FAILED;
				char secondChar = sSource.charAt(1);
				switch(secondChar)
				{
					case '/':
						return XMLConsts.TYPE_NODE_CLOSING;
					case '?':
						return XMLConsts.TYPE_PROCESSING_INSTRUCTION;
					case '!':
						if(sSource.length() < 3)
							return XMLConsts.PARSE_FAILED;
						char thirdChar = sSource.charAt(2);
						switch(thirdChar)
						{
							case '-':
								return XMLConsts.TYPE_COMMENTS;
							case '[':
								return XMLConsts.TYPE_CDATA;
							case 'D':
								return XMLConsts.TYPE_DOC_TYPE_DEFINITION;
							default:
								return XMLConsts.PARSE_FAILED;
						}
					default:
						return XMLConsts.TYPE_NODE;
				}
			default:
				return XMLConsts.TYPE_TEXT;
		}
	}

	public static XMLRootTreeNode createRootNode(XMLObject xml)
	{
		return new XMLRootTreeNode(xml);
	}

	/**
	 * @deprecated Use method getNodeForType(int nNodeType, String sTagName, String sText)
	 */
	public static XMLTreeNode getNodeForType(int nNodeType)
	{
		return getNodeForType(nNodeType, null, null);
	}

	/**
	 * de-precated?  Use method getNodeForType(int nNodeType, String sTagName, String sText)
	 */
	public static XMLTreeNode getNodeForType(int nNodeType, String sTagName)
	{
		return getNodeForType(nNodeType, sTagName, null);
	}

	public static XMLTreeNode getNodeForType(int nNodeType, String sTagName, String sText)
	{
		switch(nNodeType)
		{
			case XMLConsts.TYPE_PROCESSING_INSTRUCTION:
				return new XMLPrInstrTreeNode(sTagName, sText);
			case XMLConsts.TYPE_COMMENTS:
				return new XMLCommentsTreeNode(sTagName, sText);
			case XMLConsts.TYPE_CDATA:
				return new XMLCDATATreeNode(sTagName, sText);
			case XMLConsts.TYPE_DOC_TYPE_DEFINITION:
				return new XMLDocTypeDefTreeNode(sTagName, sText);
			case XMLConsts.TYPE_TEXT:
				return new XMLTextTreeNode(sTagName, sText);
			case XMLConsts.TYPE_NODE:
				return new XMLNodeTreeNode(sTagName, sText);
			case XMLConsts.TYPE_NODE_CLOSING:
				return new XMLNodeClosingTreeNode(sTagName, sText);
			case XMLConsts.TYPE_ROOT:
			{
				// Tt happens when cloning XMLObject
				return new XMLRootTreeNode();
			}
			case XMLConsts.TYPE_ATTRIBUTE:
				return new TreeNodeAttrib(sTagName, sText);
			case XMLConsts.PARSE_FAILED:
			default:
				return null;

		}
	}

	static XMLTreeNode parseAppend(int nNodeType, StringBuilder s) throws XMLObjectException
	{
		XMLTreeNode detectedNode = getNodeForType(nNodeType);
		detectedNode.onStartParsing();

		for(int counter = 0; counter < s.length(); counter++)
			detectedNode.parseAppend(s.charAt(counter));

		return detectedNode;
	}
}