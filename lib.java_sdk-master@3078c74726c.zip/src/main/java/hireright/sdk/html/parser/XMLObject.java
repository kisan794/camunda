/*
 * @(#)$RCSfile: XMLObject.java,v $ $Revision: 1.28 $ $Date: 2013/08/09 06:33:05 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLObject.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	 2002-07-26	Sergei Ignatov		added method void parse(Reader reader)
 *	 2002-07-26	Sergei Ignatov		method void parse(URL url) now can really throw exception
 *	 2002-09-18	Sergei Ignatov		Java Doc added. Hashtable of XMLTag names added.
 *	 2002-09-24	Sergei Ignatov		Total Code Rebuilded.
 *	 2004-01-20	Andrei Solntsev		Fixed old bug with reading from URL. Code is formatted according to last standards.
 *   2004-04-16	Andrei Solntsev		Removed unused CloneNotSupportedException
 *	 2004-11-30 Aleksei Velizhanin	Added method getNodeByTagAttribute() to search node by tag and attribute with value
 *   2005-01-04	Andrei Solntsev		added method toString(boolean bNiceOutput)
 *   2005-01-25	Andrei Solntsev		added try-catch to method toString(boolean bNiceOutput)
 *   2004-04-16	Andrei Solntsev		Removed unused CloneNotSupportedException; Added static method toString(XMLObject xml)
 *	 2005-08-29	Andrei Solntsev		Added copy-constructor
 *	 2006-06-17	Andrei Solntsev		Vector -> ArrayList
 *   2006-06-19	Andrei Solntsev		If parsing failed, XMLObjectException contains exact information about row#, column#, not-closed tag etc.
 *   2006-10-31	Andrei Solntsev		Added m_sURL member for logging URL of this XML
 *   2006-11-07 Andrei Solntsev		replace "&nbsp;" to "&#160;"
 *   2006-12-27	Andrei Solntsev		Added 2 factory method for parsing URL
 *   2007-11-19	Andrei Solntsev		Added method getNodesByAttribute()
 *   2007-11-24	Andrei Solntsev		Throw exception in case of unclosed attribute
 *   2007-11-26	Andrei Solntsev		NetTracking.registerUrl();
 *   2007-12-04	Andrei Solntsev		Fix NullPointerException in method getNodeByTagAttribute(XMLObject.java:718): TraceLog id="58489475"
 *   2008-01-28	Andrei Solntsev		Added methods for reading XML from java.io.File
 *   2008-08-26	Andrei Solntsev		using generics; added method getSystemId()
 *   2008-08-28	Andrei Solntsev		throw XMLObjectRuntimeException instead of CRuntimeException
 *   2008-11-13	A.Solntsev				Added checks for infinite loop
 *   2009-03-12	A.Solntsev				Removed method release() (not used anywhere)
 *   2009-05-15	A.Solntsev				StringBuffer -> StringBuilder
 *   2009-12-09	A.Solntsev				Removed method finalize(); 
 *   2009-12-09	A.Solntsev				Removed "m_detectedNode.setParent" to improve performance (as a result of profiling)
 *   2010-05-24	A.Tanasenko				Streams are read using explicit ISO-8859-1 encoding (for use in UTF-8 environment).
 *   2013-07-15 K.Ovchinnikov		Added updateAttributeValues()
 *   2020-10-06 A.Naboyshchikov		HRG-126805: move doneParsing() outside of finally
 *   2023-06-15 D.Stybuk					HRG-265608: Added encoding charset for source
 */
package hireright.sdk.html.parser;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.net.NetTracking;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IHasProperties;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Stack;

/**
 * Class for XML Data manipulations. Parse and Output of XML documents.
 * Operations with XML tree nodes.
 *
 * Parsing
 *		XMLObject allow parsing data from documents accessed by URL,
 *		from String data, from java.io.Reader.
 *		To parse xml data you need to create new XMLObject with one
 *		of next constructors:
 *			XMLObject(URL url), where URL is URL to xml data
 *			XMLObject(String string), where string is text xml data, not URL.
 *		or call one of methods:
 *			parse(Reader reader)
 *			parse(URL url)
 *			parse(String string)
 *
 *	Output
 *		To output data of XMLObject call methods toString() or print().
 *		print method dosn't generate temporary structures and dosn`t format
 *		output. toString method return data depend on XMLConsts.MAKE_NICE_OUTPUT
 *		constant.
 *
 *	Nodes Manipulating
 *
 *		to find XML Node inside xml document tree use
 *			getNodeByPath(), getNodeByAttribute(), getNodeByTag(), getNodeByTagAttribute
 *			last 3 methods find node in internal XMLObject hashtables.
 *
 *		to get count of nodes with same XML tag use
 *			getAttributesCount(), getNodesCount()
 *
 *		to remove XML node from xml document use
 *			removeAttribute(), removeNodeByTag()
 *
 * @author  Sergei Ignatov
 * @version $Revision: 1.28 $, $Date: 2013/08/09 06:33:05 $, $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/parser/XMLObject.java,v $
 */
public class XMLObject implements Serializable, IHasProperties
{
	protected static final String CLASS_VERSION = "$Revision: 1.28 $ $Author: cvsroot $";

	/* Constants */
	protected static final int BUFFER_SIZE = 256;
	
	/* Class members */
	protected XMLRootTreeNode m_rootNode;

	// Used during parsing. The node which is currently being parsed.
	protected XMLTreeNode m_currentlyParsedNode;

	private Stack<XMLTreeNode> m_parsingTagsPath = new Stack<XMLTreeNode>();

	protected StringBuilder m_sbTempBuffer;
	protected int m_nNodeType = XMLConsts.PARSE_FAILED;
	protected boolean m_readyToDetectEnd;
	protected XMLTreeNode m_detectedNode;

	/**
	 * URL of this XML (if it's being read from exteranl URL or file)
	 * Used for logging and throwing exceptions in case of invalid XML.
	 */
	protected String m_sSystemId;
	
	/**
	 * The encoding charset for resources read from a stream.
	 * Mandatory when default system encoding is UTF-8,
	 * since majority of resources are saved in ISO-8859-1 (windows-1252).
	 * The default is ISO-8859-1.
	 */
	protected String m_sCharsetName = StandardCharsets.ISO_8859_1.name();

	private Map<String, Integer> m_allAttributesOccurrences;
	
	/* direct links to nodes */
	private final Map<String, Map<String, List<XMLTreeNode>>> m_allAttributesNames
		= new HashMap<String, Map<String, List<XMLTreeNode>>>();

	/**
	 * Contains mappings String -> List<XMLTreeNode>
	 * (node name -> node).
	 */
	private final Map<String, List<XMLTreeNode>> m_allTagsNames = new HashMap<String, List<XMLTreeNode>>();

	// Used during parsing XML
	private int m_nRow;
	private int m_nColumn;
	private int m_nCharactersRead;


	/**
	 *  Set new root node and data of tree structure inside XMLObject and rebuild internal
	 * XMLObject`s hashtables of tags and attributes. Old XMLObject data will be lost.
	 *
	 * @param rootNode new xml root node.
	 * TODO Make this method private. Currenty it's used in CCountryRegionInjector
	 */
	public final void setRootNode(XMLRootTreeNode rootNode)
	{
		m_rootNode = rootNode;
		m_rootNode.setXMLObject( this );
		resetSearchIndexes();
	}
	

	/**
	 * @deprecated Use method setRootNode(XMLRootTreeNode rootNode).
	 * @param rootNode
	 */
	public final void setRootNode(XMLTreeNode rootNode)
	{
		// This is a risky trick. Try to avoid it!
		if (rootNode instanceof XMLRootTreeNode)
		{
			setRootNode( (XMLRootTreeNode) rootNode);
		}
		else
		{
			// TODO: this.removeAllChildren()
			XMLRootTreeNode newRootNode = XMLTreeNodeParser.createRootNode(this);
			setRootNode(newRootNode);
			newRootNode.addChildNodeHead(rootNode);
			m_sSystemId = "created with root node " + rootNode.getXMLTag();	// URL is unknown
		}
	}

	/**
	 *  Construct empty XMLObject. Empty XMLObject does not contain root node nor any data.
	 */
	public XMLObject()
	{
		m_sSystemId = null;	// unknown
	}

	/**
	 * Copy-constructor
	 * @param obj	XMLObject to take copy of
	 */
	public XMLObject(XMLObject obj)
	{
		if (obj != null)
		{
			// how can they be null?
			if (obj.getRootNode() != null)
			{
				m_rootNode = (XMLRootTreeNode) obj.getRootNode().dublicate();
				m_rootNode.setXMLObject(this);
				resetSearchIndexes();
				// getRootTreeNode().setXMLObject(this);
			}
			m_sSystemId = obj.m_sSystemId;
		}
	}

	/**
	 *  Construct XMLObject with data from given url source.
	 *
	 *  @param url path to XML structured data.
	 *	@throws	XMLObjectException
	 *
	 */
	public XMLObject(URL url) throws XMLObjectException
	{
		NetTracking.registerUrl(url);
		m_sSystemId = url.toString();
		parse(url);
	}
	
	/**
	 *  Construct XMLObject with data from given url and charset of source.
	 *
	 *  @param url path to XML structured data.
	 *  @param sCharsetName charset name of source.
	 *	@throws	XMLObjectException
	 *
	 */
	public XMLObject(URL url, String sCharsetName) throws XMLObjectException
	{
		NetTracking.registerUrl(url);
		m_sSystemId = url.toString();
		
		if (CStringUtils.isNotEmpty(sCharsetName))
		{
			m_sCharsetName = sCharsetName;
		}
		
		parse(url);
	}

	public XMLObject(File file) throws XMLObjectException
	{
		try
		{
			NetTracking.registerUrl( file.toURL() );
			m_sSystemId = file.toURL().toString();
			parse(new FileInputStream(file), m_sSystemId);
		}
		catch (IOException e)
		{
			throw new XMLObjectException(e, file.getAbsolutePath());
		}
	}

	/**
	 *  Construct XMLObject with data from string.
	 *
	 *  @param  string XML structured data.
	 * @throws XMLObjectException
	 * @throws NullPointerException	if string is null
	 *
	 */
	public XMLObject(String string) throws XMLObjectException
	{
		parse(string);
	}

	/**
	 * Construct XMLObject with data read from given InputStream.
	 *
	 * @param in any java.io.InputStream -
	 * 		typically this is URLInputStream which reads XML from external URL.
	 *
	 * @param sXmlURI Descriptor of this java.io.InputStream - for example, URL of external XML object.
	 * 		This is used for throwing exception in case of invalid XML.
	 *
	 * @throws XMLObjectException if XML is invalid
	 *
	 * @since Oct 31, 2006
	 */
	public XMLObject(InputStream in, String sXmlURI) throws XMLObjectException
	{
		parse(in, sXmlURI);
	}

	public final void parse(InputStream in, String sXmlURI) throws XMLObjectException
	{
		m_sSystemId = sXmlURI;
		Reader reader;
		// always load external resources with ISO charset
		// TODO: add some decision logic, if resources are saved with utf
		try
		{
			reader = new InputStreamReader(in, m_sCharsetName);
		}
		catch(UnsupportedEncodingException e)
		{
			throw new IllegalArgumentException(e);
		}
		
		parseReader(reader, sXmlURI);
	}

	/**
	 * Construct XMLObject with data read from given Reader.
	 *
	 * @param in any java.io.Reader -
	 * 		typically this is URLInputStream which reads XML from external URL.
	 *
	 * @param sXmlURI Descriptor of this java.io.InputStream - for example, URL of external XML object.
	 * 		This is used for throwing exception in case of invalid XML.
	 *
	 * @throws XMLObjectException if XML is invalid
	 * @since Oct 31, 2006
	 */
	public XMLObject(Reader in, String sXmlURI) throws XMLObjectException
	{
		NetTracking.registerUrl(sXmlURI);
		m_sSystemId = sXmlURI;
		parseReader(in, sXmlURI);
	}

	public final void parseReader(Reader in, String sXmlURI) throws XMLObjectException
	{
		try
		{
			parse(in);
		}
		catch (IOException e)
		{
			throw new XMLObjectException(e, sXmlURI);
		}
		finally
		{
			close(in);
		}
	}

	protected static final void close(Reader in)
	{
		if (in != null)
		{
			try {in.close();} catch (IOException ioe) {}
		}
	}

	protected static final void close(InputStream in)
	{
		if (in != null)
		{
			try {in.close();} catch (IOException ioe) {}
		}
	}

	/**
	 *  Construct object from XMLTreeNode.
	 *
	 * @param node top data node of XML structured data.
	 */
	public XMLObject(XMLTreeNode node)
	{
		assert node != null : "node is null";

		XMLRootTreeNode rootNode = XMLTreeNodeParser.createRootNode(this);
		setRootNode(rootNode);
		rootNode.addChildNodeHead(node);
		m_sSystemId = "created with root node " + node.getXMLTag();	// URL is unknown
	}

	/**
	 *  Parse xml from given Reader. one-way parsing.
	 *
	 * @param reader2 data source for XMLObject.
	 * @throws IOException, XMLObjectException
	 *
	 */
	protected final void parse(Reader reader2) throws IOException, XMLObjectException
	{
		initParsing();
		Reader reader = new BufferedReader(reader2);

		char[] cb = new char[1];
		try
		{
			while (reader.read(cb, 0, 1) != -1)
			{
				addChar(cb[0]);
			}
			doneParsing();
		}
		finally
		{
				resetParsingState();
				close(reader);
		}
	}

		private void resetParsingState()
		{
				XMLTreeNode.XML_STRUCTURE_CHANGE_LISTENER.remove();
				m_sbTempBuffer = null;
		}

		/**
	 *  Parse xml from given url source.
	 *
	 * @param url URL to acess XML data.
	 * @throws XMLObjectException
	 *
	 */
	public final void parse(URL url) throws XMLObjectException
	{
		try
		{
			m_sSystemId = url.toString();
			parse(url.openStream(), url.toString());
		}
		catch (IOException e)
		{
			/* This is made just for compatibility with existing code */
			throw new XMLObjectException(e, url);
		}
	}

	/**
	 * Parse xml from string.
	 *
	 * @param  string XML structured data.
	 * @throws XMLObjectException
	 * @throws NullPointerException	if string is null
	 */
	public void parse(String string) throws XMLObjectException
	{
		m_sSystemId = CStringUtils.truncate(string, 100);
		String sXml = string; // string.replaceAll("&nbsp;", "&#160;"); // do we meed it?

		try
		{
			initParsing();
			for(int i = 0; i < sXml.length(); i++)
			{
				addChar(sXml.charAt(i));
			}
			doneParsing();
		}
		finally
		{
				resetParsingState();
		}
	}

	/**
	 * Procedure to collect input from all parse procedures.
	 * Primary parsing of xml document. Extact node parts of XML.
	 *
	 * @param c char to append to parse buffer.
	 * @throws XMLObjectException COMMENT ME
	 */
	private final void addChar(char c) throws XMLObjectException
	{
		m_nCharactersRead++;
		m_nColumn++;
		if (c == '\n')
		{
			m_nColumn = 1;
			m_nRow++;
		}

		if (m_sbTempBuffer.length() > 0 ||
			(c != ' ' && c != '	' && c != 0x0D && c != 0x0A))
			m_sbTempBuffer.append(c);

		try
		{
			if (m_sbTempBuffer.length() <= XMLConsts.MIN_PREDETERM_LENGTH)
			{/* can detect type of node at this point */
				if(m_detectedNode == null)
				{/* but only, if type not detected yet */
					m_nNodeType = XMLTreeNodeParser.preDetermNodeTypeProc(m_sbTempBuffer);
					if(m_nNodeType != XMLConsts.PARSE_FAILED)
					{
						m_detectedNode = XMLTreeNodeParser.parseAppend(m_nNodeType, m_sbTempBuffer);

						// zachem?
						// m_detectedNode.setParent(m_currentlyParsedNode); // Removed by A.Solntsev 2009-11-16
						//if (m_nNodeType != XMLConsts.TYPE_NODE_CLOSING)
						//	m_detectedNode.addToParent(m_currentlyParsedNode);
					}
				}
				else
				{/* try detect end of node. */
					appendToDetected(c);
				}
			}
			else
			{/* length longer, than needed to detection, so if not done yet, will be done neither */
				if (m_detectedNode == null)
				{/* undefined node type */
					// TODO	Add more information (properties) to the exception
					throw new XMLObjectException("invalid node type: " + m_sbTempBuffer.toString(), m_sSystemId);
				}
				else
				{/* try detect end of node. */
					appendToDetected(c);
				}
			}
		}
		catch (XMLObjectException xmle)
		{
			// Enrich exception with column # and row #
			// throw new XMLObjectException(xmle, m_nColumn, m_nRow, m_nCharactersRead, c);
			xmle.setColumn(m_nColumn);
			xmle.setRow(m_nRow);
			xmle.setCharactersRead(m_nCharactersRead);
			xmle.setInvalidCharacter(c);

			throw xmle;
		}
		catch (OutOfMemoryError outOfMemory)
		{
			CTraceLog.fatal(outOfMemory, getClass().getName() + ".addChar()", toProperties());
			throw outOfMemory;
		}
	}

	private static StringBuilder reuse(StringBuilder sb)
	{
		if (sb == null)
			return new StringBuilder();

		sb.setLength(0);
		return sb;
		// return new StringBuilder();
	}

	/**
	 * procedure calls, when one node extracted from data source.
	 *
	 * @param c last char passed to parse buffer.
	 * @throws XMLObjectException
	 *
	 */
	protected final void appendToDetected(char c) throws XMLObjectException
	{
		int result = m_detectedNode.parseAppend(c);
		switch(result)
		{
			case XMLConsts.SECT_FAILED:
				m_detectedNode.postParse();
				m_detectedNode = null;
				m_nNodeType = XMLConsts.PARSE_FAILED;
				m_sbTempBuffer = reuse(m_sbTempBuffer);
				break;
			case XMLConsts.SECT_PARSED:
				m_detectedNode.postParse();
				TreeNode previousParsedNode = m_currentlyParsedNode;
				m_currentlyParsedNode = m_detectedNode.addToParentXmlNode(m_currentlyParsedNode);

				if (m_currentlyParsedNode == m_detectedNode)
					m_parsingTagsPath.add(m_currentlyParsedNode);
				else if (m_currentlyParsedNode == previousParsedNode.getParent())
					m_parsingTagsPath.pop();

				m_detectedNode = null;
				m_nNodeType = XMLConsts.PARSE_FAILED;
				m_sbTempBuffer = reuse(m_sbTempBuffer);
				if(c == '<')
					addChar('<');
				break;
			default:
		}
	}

	/**
	 *	Resets all XMLObject data. Prepares internal structures for parsing.
	 *
	 */
	private final void initParsing()
	{
		m_nRow = 1;
		m_nColumn = 1;
		m_nCharactersRead = 0;

		resetParsingState();

		m_rootNode = XMLTreeNodeParser.createRootNode(null); //this or null?
		m_currentlyParsedNode = m_rootNode;
		m_parsingTagsPath.add(m_currentlyParsedNode);

		m_sbTempBuffer = reuse(m_sbTempBuffer);
		m_readyToDetectEnd = false;
	}

	/**
	*
	* Finalize parsing process.
	*
	* @throws XMLObjectException
	*/
	private final void doneParsing() throws XMLObjectException
	{
		if (m_parsingTagsPath.size() > 1)
		{
			StringBuilder sbPath = new StringBuilder();
			for (int i=1; i<m_parsingTagsPath.size(); i++)
			{
				XMLTreeNode node = m_parsingTagsPath.get(i);
				sbPath.append(node.getXMLTag()).append("/");
			}
			if (m_detectedNode == null)
				sbPath.append("null");
			else
				sbPath.append(m_detectedNode.getXMLTag());
			throw new XMLObjectException("Tag " + sbPath + " is not closed");
		}

		if (m_rootNode != null)	// How can it be null?
		{
			// m_rootNode = (XMLRootTreeNode) m_rootNode.getRoot();
			getRootTreeNode().setXMLObject(this);
		}

		// hashtablesRebuild(); // Let's create indexes later (only by request)
		onDoneParsing();
	}

	/**
	 *  Returns root node of XML document
	 *  @return root node of this XML
	 */
	public final XMLTreeNode getRootNode()
	{
		return m_rootNode;
	}

	/**
	 *  Returns root node of XML document
	 *  @return root node of this XML
	 */
	public XMLRootTreeNode getRootTreeNode()
	{
		return m_rootNode;
	}

	/**
	 * Handler. Executed before any node removed.
	 *
	 * @param node node, removed from data structure of XMLObject.
	 *
	 */
	public void onNodeRemoved(XMLTreeNode node)
	{
		synchronized ( this )
		{
			unregisterNodesTree(node);
		}
	}

	/**
	 * Handler. Executed after any new node added Node added.
	 *
	 * @param node node, added to data structure of XMLObject.
	 */
	public void onNodeAdded(XMLTreeNode node)
	{
		synchronized ( this )
		{
			registerNodesTree(node);
		}
	}

	public void onXMLTagChanged(XMLTreeNode node, String sOldValue)
	{
		synchronized ( this )
		{
			switch (node.getType())
			{
				case XMLConsts.TYPE_NODE:
					unregisterTagNode(node, sOldValue);
					registerTagNode(node);
					break;
				case XMLConsts.TYPE_ATTRIBUTE:
					unregisterAttribute(node, sOldValue);
					registerAttribute(node);
					break;
			}
		}
	}

	/**
	 *  Find nodes for removing in data of XMLObject.
	 * call procedure to remove finded nodes.
	 *
	 * @param treeRoot node to remove.
	 */
	protected final void unregisterNodesTree(XMLTreeNode treeRoot)
	{
		if (treeRoot == null)
		{
			// How can it happen?
			return;
		}
		else if (m_allAttributesOccurrences == null)
			return;

		switch(treeRoot.getType())
		{
			case XMLConsts.TYPE_ATTRIBUTE:
				unregisterAttribute(treeRoot);
				return;
			case XMLConsts.TYPE_NODE:
				unregisterTagNode(treeRoot);
		}

		XMLTreeNode childNode = treeRoot.getChildXmlNode();

		int counter=0;
		while (childNode != null)
		{
			assert ++counter < 1000 : "Infinite loop";

			switch (childNode.getType())
			{
				case XMLConsts.TYPE_ATTRIBUTE:
					unregisterAttribute(childNode);
					break;
				default:
					unregisterNodesTree(childNode);
			}

			childNode = (XMLTreeNode) childNode.getNextNode();
		}
	}

	/**
	 *  Find all attributes of this node and all attributes of
	 * children of this node. Then add links to attributes to hashtable.
	 *
	 * @param treeRoot parent node of attributes to add.
	 */
	protected final void registerNodesTree(XMLTreeNode treeRoot)
	{
		if (treeRoot == null)
		{
			// How can it happen?
			return;
		}
		else if (m_allAttributesOccurrences == null)
			return;

		switch(treeRoot.getType())
		{
			case XMLConsts.TYPE_ATTRIBUTE:
				registerAttribute(treeRoot);
				return;
			case XMLConsts.TYPE_NODE:
				registerTagNode(treeRoot);
		}

		XMLTreeNode childNode = treeRoot.getChildXmlNode();

		int counter=0;
		while (childNode != null)
		{
			assert ++counter < 10000 : "Infinite loop";
			registerNodesTree(childNode);
			childNode = (XMLTreeNode) childNode.getNextNode();
		}
	}

	/**
	 * Returns first node with given XML tag.
	 *
	 * @param sXMLTag xml tag value.
	 * @return the first node with given tag
	 */
	public XMLTreeNode getNode(String sXMLTag)
	{
		return getNode(sXMLTag, 1);
	}

	private List<XMLTreeNode> getNodesWithTag(String sXMLTag)
	{
		return getTagsMap().get(sXMLTag);
	}

	/**
	 *  Returns  n-th node with given XML tag.
	 *
	 * @param sXMLTag xml tag value.
	 * @param nIndex index of node inside array of nodes with same xml tag.
	 * @return the nIndex'th node with given tag
	 */
	public XMLTreeNode getNode(String sXMLTag, int nIndex)
	{
		List<XMLTreeNode> nodesWithTag = getNodesWithTag(sXMLTag);
		if (nodesWithTag == null)
			return null;

		if (nodesWithTag.size() < nIndex)
			return null;

		return nodesWithTag.get(nIndex - 1);
	}

	/**
	 * Returns  first node with given XML tag and given attribute
	 * with given value.
	 *
	 * @param sXMLTag 		Tag name
	 * @param sAttrName		Attribute Name
	 * @param sAttrVal		Attribute Value
	 * @return 				Found Node or null
	 */
	public XMLTreeNode getNodeByTagAttribute(String sXMLTag, String sAttrName, String sAttrVal)
	{
		List<XMLTreeNode> nodesWithTag = getNodesWithTag(sXMLTag);
		if (nodesWithTag == null)
			return null;

		TreeNodeAttrib attribNode;
		for (XMLTreeNode node : nodesWithTag)
		{
			attribNode = node.getAttribNode(sAttrName);
			if (attribNode != null && CStringUtils.equals(attribNode.getAttribValue(), sAttrVal))
			{
				return node;
			}
		}
		return null;
	}

	/**
	 *  Add xml-tag node into hashtable of xml-tags of this object.
	 *
	 * @param node node to add to hashtable.
	 *
	 */
	private void registerTagNode(XMLTreeNode node)
	{
		if (m_allAttributesOccurrences == null)
			return;
		
		List<XMLTreeNode> nodesWithTag = m_allTagsNames.get( node.getXMLTag() );
		if (nodesWithTag == null)
		{
			nodesWithTag = new ArrayList<XMLTreeNode>();
			m_allTagsNames.put(node.getXMLTag(), nodesWithTag);
		}

		nodesWithTag.add(node);
	}
	
	private void initSearchIndexes()
	{
		if (m_allAttributesOccurrences == null)
		{
			synchronized ( this )
			{
				if (m_allAttributesOccurrences == null)
				{
					rebuildSearchIndex();
				}
			}
		}
	}
	
	private final Map<String, Map<String, List<XMLTreeNode>>> getAttibutesMap()
	{
		initSearchIndexes();		
		return m_allAttributesNames;
	}
	
	private final Map<String, Integer> getAttibutesOccurrences()
	{
		initSearchIndexes();		
		return m_allAttributesOccurrences;
	}
	
	private final Map<String, List<XMLTreeNode>> getTagsMap()
	{
		initSearchIndexes();		
		return m_allTagsNames;
	}

	/**
	 *  Aad attribute node into hashtable of attributes of this XMLObject.
	 *
	 * @param node attribute node to add to hashtable.
	 *
	 */
	private void registerAttribute(XMLTreeNode node)
	{
		assert node.getType() == XMLConsts.TYPE_ATTRIBUTE;
		
		if (m_allAttributesOccurrences == null)
			return;
		
		Integer cnt = m_allAttributesOccurrences.get( node.getXMLTag() );
		if (cnt == null)
			m_allAttributesOccurrences.put( node.getXMLTag(), Integer.valueOf(1) );
		else
			m_allAttributesOccurrences.put( node.getXMLTag(), Integer.valueOf(1+cnt.intValue()) );

		Map<String, List<XMLTreeNode>> hashtableNames = m_allAttributesNames.get(node.getXMLTag());
		if (hashtableNames == null)
		{
			hashtableNames = new HashMap<String, List<XMLTreeNode>>();
			m_allAttributesNames.put(node.getXMLTag(), hashtableNames);
		}

		List<XMLTreeNode> vectorValues = hashtableNames.get(node.getText());
		if (vectorValues == null)
		{
			vectorValues = new ArrayList<XMLTreeNode>(3);
			hashtableNames.put(node.getText(), vectorValues);
		}
		vectorValues.add(node);
		// node.setXMLObject(this);
	}

	/**
	 * Remove xml-tag node from hashtable of xml-tags of this object.
	 *
	 * @param tagNode node to remove from hashtable.
	 */
	protected void unregisterTagNode(XMLTreeNode tagNode)
	{
		unregisterTagNode(tagNode, tagNode.getXMLTag());
	}

	/**
	 * Remove xml-tag node from hashtable of xml-tags of this object.
	 *
	 * @param tagNode node to remove from hashtable.
	 * @param sXMLTag key to find node.
	 */
	protected void unregisterTagNode(XMLTreeNode tagNode, String sXMLTag)
	{
		if (m_allAttributesOccurrences == null)
			return;
		
		List<XMLTreeNode> nodesWithTag = getNodesWithTag(sXMLTag);
		if (nodesWithTag == null)
			return;

		// nodesWithTag.remove(tagNode);
		XMLTreeNode node;
		for (Iterator<XMLTreeNode> it = nodesWithTag.iterator(); it.hasNext(); )
		{
			node = it.next();
			if (node == tagNode)
			{
				it.remove();
				return;
			}
		}
	}

	private void unregisterAttribute(XMLTreeNode attribute)
	{
		unregisterAttribute(attribute, attribute.getText());
	}

	/**
	 * Remove attribute node from hashtable of attributes of this XMLObject.
	 *
	 * @param attribute node to remove from hashtable.
	 */
	private void unregisterAttribute(final XMLTreeNode attribute, final String sAttrValue)
	{
		if (m_allAttributesOccurrences == null)
			return;
		
		Integer cnt = m_allAttributesOccurrences.get( attribute.getXMLTag() );
		if (cnt != null)
			m_allAttributesOccurrences.put( attribute.getXMLTag(), Integer.valueOf(cnt.intValue()-1) );
		
		Map<String, List<XMLTreeNode>> hashtableNames = m_allAttributesNames.get(attribute.getXMLTag());
		if(hashtableNames == null)
		{
			return;
		}

		List<XMLTreeNode> vectorValues = hashtableNames.get(sAttrValue);
		if (vectorValues == null)
		{
			return;
		}

		// vectorValues.remove(attribute); // Don't!
		XMLTreeNode node;
		for (Iterator<XMLTreeNode> it = vectorValues.iterator(); it.hasNext(); )
		{
			node = it.next();
			if (node == attribute)
			{
				it.remove();
				break;
			}
		}
	}

	/**
	 * Returns the FIRST node with given attribute.
	 *
	 * PS. To get list of all nodes with given attribute, use method
	 *
	 * @param sAttribute attribute name.
	 * @param sValue attribute value.
	 * @return null if such node is not found
	 */
	public XMLTreeNode getNodeByAttribute(String sAttribute, String sValue)
	{
		return getNodeByAttribute(sAttribute, sValue, 1);
	}

	/**
	 * XMLTreeNode
	 * @param sAttribute
	 * @param sValue
	 * @return list of XMLTreeNode instances
	 */
	public Collection<XMLTreeNode> getNodesByAttribute(String sAttribute, String sValue)
	{
		Map<String, List<XMLTreeNode>> hashtableNames = getAttibutesMap().get(sAttribute);
		if (hashtableNames == null)
		{
			return null;
		}

		List<XMLTreeNode> vectorValues = hashtableNames.get(sValue);
		return vectorValues == null ? 
				Collections.<XMLTreeNode>emptyList() : Collections.unmodifiableList(vectorValues);
	}

	/**
	 *  Returns first node with given attribute name.
	 *
	 * @param sAttribute attribute name.
	 * @return null if such node is not found
	 */
	public XMLTreeNode getNodeByAttribute(String sAttribute)
	{
		return getNodeByAttribute(sAttribute, 1);
	}

	/**
	 * Updates attributes with a given 'sValue' by 'sNewValue'.
	 */
	public void updateAttributeValues(String sAttribute, String sValue, String sNewValue)
	{
		Map<String, List<XMLTreeNode>> valuesMap = getAttibutesMap().get(sAttribute);
		if (valuesMap == null)
		{
			return;
		}
		
		List<XMLTreeNode> nodes = valuesMap.get(sValue);
		if (nodes == null)
		{
			return;
		}
		
		for (XMLTreeNode node : nodes)
		{
			node.setText(sNewValue);
		}
		
		valuesMap.put(sNewValue, nodes);
		valuesMap.remove(sValue);
	}
	
	/**
	 *  !!!! warning invalid function name must be smth.like removeAttribute !!!!
	 * Remove All Attribute nodes.
	 *
	 * @deprecated use removeAttribute()
	 * @param sAttribute attribute name.
	 *
	 */
	public void removeNodeByAttribute(String sAttribute)
	{
		removeAllAttributes(sAttribute);
	}

	/*public final void removeNode(XMLTreeNode subtreeRoot)
	{
		unregisterNodesTree(subtreeRoot);
		subtreeRoot.getParent().removeChild(subtreeRoot);
	}*/

	/**
	 * remove all nodes with attribute name=value
	 * @param szAttributeName name of attribute (not null)
	 * @param szAttributeValue value of attribute (not null!)
	 */
	public void removeNodesByAttribute(String szAttributeName, String szAttributeValue)
	{
		XMLTreeNode node = getNodeByAttribute(szAttributeName, szAttributeValue);

		int counter=0;
		while (node != null)
		{
			assert ++counter < 1000 : "Infinite loop";
			node.getParent().removeChild(node);	// removeNode(node);
			node = getNodeByAttribute(szAttributeName, szAttributeValue);
		}
	}

	/**
	 *  Remove All Attribute nodes.
	 *
	 * @param sAttribute attribute name.
	 */
	public void removeAttribute(String sAttribute)
	{
		removeAllAttributes(sAttribute);
	}

	/**
	 * Remove All Attribute nodes with given name.
	 *
	 * @param sAttribute attribute name.
	 */
	public void removeAllAttributes(String sAttribute)
	{
		Map<String, List<XMLTreeNode>> hashtableNames = getAttibutesMap().get(sAttribute);
		if (hashtableNames == null || hashtableNames.isEmpty())
		{
			return;
		}

		for (Iterator<List<XMLTreeNode>> it = hashtableNames.values().iterator(); it.hasNext(); )
		{
			List<XMLTreeNode> vectorValues = it.next();
			for (Iterator<XMLTreeNode> it2 = vectorValues.iterator(); it2.hasNext();)
			{
				XMLTreeNode nodeToRemove = it2.next();
				it2.remove();
				if (nodeToRemove.getParent() == null)
				{
					CTraceLog.warning("Trying to remove attribute which doesn't have parrent: [" +
							nodeToRemove + "]", getClass().getName()+".removeAllAttributes()", toProperties());
				}
				else
				{
					nodeToRemove.getParent().removeChild(nodeToRemove);
					// removeNode(nodeToRemove);
				}
			}
			if (vectorValues.isEmpty())
			{
				it.remove();
			}
		}
	}

	/**
	 *  Remove all nodes with given xmlTag.
	 *
	 * @param sXMLTag attribute name.
	 *
	 */
	public void removeNode(String sXMLTag)
	{
		removeNode(sXMLTag, Integer.MAX_VALUE, true);
	}

	/**
	 *  Remove node with given xmlTag and index.
	 *
	 * @param sXMLTag attribute name.
	 * @param index index of attribute in the array of attributes with same name.
	 *
	 */
	public void removeNode(String sXMLTag, int index)
	{
		removeNode(sXMLTag, index, false);
	}

	/**
	 *  Remove node(s) with given xmlTag and index.
	 *
	 * @param sXMLTag attribute name.
	 * @param index index of attribute in the array of attributes with same name.
	 * @param allRemove if true - remove all nodes & index ignored
	 *
	 */
	protected void removeNode(String sXMLTag, int index, boolean allRemove)
	{
		// NB! This method can potentially work slowly!
		List<XMLTreeNode> nodesWithTag = getNodesWithTag(sXMLTag);
		if (nodesWithTag == null)
			return;

		int nRealIndex = index-1;

		int vSize  = nodesWithTag.size() - 1;
		for (int i=0; i<=vSize; i++)
		{
			if (allRemove)
			{
				XMLTreeNode nodeToRemove = nodesWithTag.remove(vSize - i);
				nodeToRemove.getParent().removeChild(nodeToRemove);	// removeNode(nodeToRemove);
			}
			else if(i == nRealIndex)
			{
				XMLTreeNode nodeToRemove = nodesWithTag.remove(i);
				nodeToRemove.getParent().removeChild(nodeToRemove);	// removeNode(nodeToRemove);
				break;
			}
		}
	}

	/**
	 *  Returns node with given attribute.
	 *
	 * @param sAttribute attribute name.
	 * @param index index inside array of attributes with same name.
	 * 	NB! Order of nodes is not defined
	 *
	 * @return null if such node is not found
	 */
	public XMLTreeNode getNodeByAttribute(String sAttribute, int index)
	{
		Map<String, List<XMLTreeNode>> hashtableNames = getAttibutesMap().get(sAttribute);
		if(hashtableNames == null || index < 1)
		{
			return null;
		}
		int nRealIndex = index-1;

		int counterLocal = 0;

		for (List<XMLTreeNode> vectorValues : hashtableNames.values() )
		{
			for (XMLTreeNode node : vectorValues )
			{
				if (counterLocal == nRealIndex)
					return (XMLTreeNode) node.getParent();

				counterLocal++;
			}
		}

		return null;
	}

	/**
	 *  Returns node with given attribute.
	 *
	 * @param sAttribute attribute name.
	 * @param sValue attribute value.
	 * @param index index inside array of attributes with same name & value.
	 * @return null if such node is not found
	 */
	public XMLTreeNode getNodeByAttribute(String sAttribute, String sValue, int index)
	{
		//TODO: replace with call of public XMLTreeNode getAttribute(String sAttribute, int index)
		Map<String, List<XMLTreeNode>> hashtableNames = getAttibutesMap().get(sAttribute);
		if(hashtableNames == null || index < 1)
		{
			return null;
		}
		int nRealIndex = index-1;
		List<XMLTreeNode> vectorValues = hashtableNames.get(sValue);
		if (vectorValues == null)
		{
			return null;
		}

		if (vectorValues.size() <= nRealIndex)
			return null;

		return (XMLTreeNode) vectorValues.get(nRealIndex).getParent();
	}

	/**
	 *  returns count of nodes with given xml tag.
	 *
	 * @param sXMLTag xml tag value.
	 * @return 0 if no such nodes found
	 */
	public int getNodesCount(String sXMLTag)
	{
		List<XMLTreeNode> nodesWithTag = getNodesWithTag(sXMLTag);

		if (nodesWithTag == null)
			return 0;

		return nodesWithTag.size();
	}

	/**
	 *  returns count of attributes with given attribute.
	 *
	 * @param sAttribute attribute name.
	 * @param sValue attribute value.
	 * @return 0 if no such nodes found
	 */
	public int getAttributesCount(String sAttribute, String sValue)
	{
		Map<String, List<XMLTreeNode>> hashtableNames = getAttibutesMap().get(sAttribute);
		if(hashtableNames == null)
			return 0;

		List<XMLTreeNode> vectorValues = hashtableNames.get(sValue);
		if (vectorValues == null)
			return 0;

		return vectorValues.size();
	}

	/**
	 *  returns count of attributes with given attribute name and any value.
	 *
	 * @param sAttribute attribute name.
	 * @return 0 if no such nodes found
	 */
	public int getAttributesCount(String sAttribute)
	{
		/*Map<String, List<XMLTreeNode>> hashtableNames = getAttibutesMap().get(sAttribute);
		if(hashtableNames == null)
		{
			return 0;
		}
		int nCount = 0;

		for (List<XMLTreeNode> vectorValues : hashtableNames.values())
		{
			if (vectorValues != null)
				nCount += vectorValues.size();
		}
		return nCount;*/
		Integer cnt = getAttibutesOccurrences().get( sAttribute );
		return cnt == null ? 0 : cnt.intValue();
	}

	/**
	 *  Returns attribute node with given name and index.
	 *
	 * @param sAttribute attribute name.
	 * @param index index inside array of attributes with same name.
	 * @return null if such node is not found
	 */
	public XMLTreeNode getAttribute(String sAttribute, int index)
	{
		Map<String, List<XMLTreeNode>> hashtableNames = getAttibutesMap().get(sAttribute);
		if(hashtableNames == null || index < 1)
		{
			return null;
		}
		int nRealIndex = index-1;

		int counterLocal = 0;

		for (List<XMLTreeNode> vectorValues : hashtableNames.values())
		{
			for (XMLTreeNode node : vectorValues)
			{
				if (counterLocal == nRealIndex)
					return node;
				counterLocal++;
			}
		}

		return null;
	}

	/**
	 *  Returns value of attribute with given name and index.
	 *
	 * @param sAttribute attribute name.
	 * @param index index inside array of attributes with same name.
	 * @return null if such node is not found
	 */
	public String getAttributeValue(String sAttribute, int index)
	{
		XMLTreeNode node = getAttribute(sAttribute, index);
		if(node == null)
			return null;
		return node.getText();
	}

	/**
	 *  Handler. Method executes when parsing finished.
	 */
	public void onDoneParsing()
	{
	}

	/**
	 *	Method returns "nice" String-representation of XMLObject (wrapping, line-breaking).
	 *
	 *	NB! This method is not entirely tested.
	 *	So it can be used ONLY for debugging purposes.
	 *
	 * @param bNiceOutput if true, XML is formatted
	 * @return string-representation of this XML;
	 */
	public String toString(boolean bNiceOutput)
	{
		if (getRootNode() == null)
			return "";

		// return getRootNode().toString();
		StringWriter writer	= new StringWriter();
		PrintWriter	printWriter	= new PrintWriter(writer);

		try
		{
			print(printWriter, bNiceOutput);
			printWriter.flush();
		}
		finally
		{
			printWriter.close();
			printWriter = null;
		}
		return writer.toString();
	}

	/**
	 * Returns text representation of xml data tree.
	 *
	 * @return string-representation of this XML;<br/>
	 * returns empty string is root node is null.
	 */
	@Override
	public String toString()
	{
		return toString(false);
	}

	/**
	 * Static method for safe formatting XML.
	 * Method returns formatted String-representation of given XML.
	 * @param xml		XMLObject, may be null
	 * @return 	null if parameter xml is null.
	 */
	public static String toString(XMLObject xml)
	{
		if (xml == null)
			return null;

		try
		{
			return xml.toString(true);
		}
		catch (Exception e)
		{
			try
			{
				return xml.toString();
			}
			catch (Exception ee)
			{
				return ee.toString();
			}
		}
	}



	/**
	 *  Returns node from xml by biven path.
	 *
	 * @param sPathValue path to node. Path is not XML path compatible.
	 * Path format is  [section] / [section] / ... [section]/  , where
	 * section format is
	 * [tag_name] + [[tag_index]] + [=tag_value + [value_index]] + [attribute + [=value] ]
	 * attributes writes in brackets {}.
	 * example of path:
	 * tag1/="tag2value"//tag3[1]/[]/tag4="I"/tag5[2]="me"[3]/tag6{attr="mine"}/tag7{want_more}/tag8="and more"/{kick_it}/
	 *
	 * @return null if no such node found
	 */
	public XMLTreeNode getNodeByPath(String sPathValue)
	{
		return getRootNode().getChildXmlNodeByPath(sPathValue);
	}

	/**
	 * Clone this XMLObject with all data.
	 *
	 * @deprecated Use copy constructor instead of method clone().
	 * @return clone of this XMLObject
	 */
	@Deprecated
	@Override
	public Object clone()
	{
		XMLObject xmlObject = new XMLObject();
		xmlObject.m_sSystemId = m_sSystemId;
		xmlObject.m_rootNode = (XMLRootTreeNode) getRootNode().dublicate();
		xmlObject.m_rootNode.setXMLObject(this);
		// xmlObject.hashtablesRebuild();
		xmlObject.resetSearchIndexes();
		// xmlObject.getRootTreeNode().setXMLObject(xmlObject);
		return xmlObject;
	}

	private final void resetSearchIndexes()
	{
		synchronized ( this )
		{
			if (m_allAttributesOccurrences != null)
			{
				m_allAttributesOccurrences.clear();
				m_allAttributesOccurrences = null;
			}
			
			m_allAttributesNames.clear();
			m_allTagsNames.clear();
		}
	}
	
	/**
	 * Clean search index. It's needed only if you think that index has came into wrong state.
	 * I think you never need this method.
	 * 
	 * @deprecated It was used only in CApplicationMultiplySectionController
	 */
	@Deprecated
	public final void hashtablesRebuild()
	{
		clearSearchIndex();
	}
	
	public final void clearSearchIndex()
	{
		synchronized ( this )
		{
			m_allAttributesNames.clear();
			m_allTagsNames.clear();

			if (m_allAttributesOccurrences != null)
				m_allAttributesOccurrences.clear();

			m_allAttributesOccurrences = null;
		}
	}
	
	/**
	 * Rebuild hashtables of attributes and xml-tags of this XMLObject.
	 */
	private final void rebuildSearchIndex()
	{
		clearSearchIndex();
		
		XMLTreeNode.XML_STRUCTURE_CHANGE_LISTENER.set(this);
		// XMLTreeNode.XML_STRUCTURE_CHANGE_LISTENER.set(null);	// fix by A.Solntsev 2009-12-08 (I hope it will improve performance)
		
		try
		{
			m_allAttributesOccurrences = new HashMap<String, Integer>();
			registerNodesTree(m_rootNode);
		}
		finally
		{
			XMLTreeNode.XML_STRUCTURE_CHANGE_LISTENER.set(null);
		}
	}

	/**
	 * Print data of this XMLObject.
	 *
	 * @param out PrintWriter for data output.
	 * @param bNiceOutput
	 */
	public void print(PrintWriter out, boolean bNiceOutput)
	{
		if (m_rootNode == null)
			return;

		m_rootNode.print(out, bNiceOutput);
	}

	protected static CProperties toProp(String sXmlUrl)
	{
		return new CProperties()
			.setProperty("url", sXmlUrl);
	}

	public CProperties toProperties()
	{
		return new CProperties()
			.setProperty("url", m_sSystemId)
			.setProperty("row#", m_nRow)
			.setProperty("column#", m_nColumn)
			.setProperty("charactersRead", m_nCharactersRead);
	}

	public String getSystemId()
	{
		return m_sSystemId;
	}

	/**
	 * Method parses given URL and returns parsed XMLObject.
	 *
	 * The key difference from constructors that this method throws only
	 * Runtime exceptions. This is useful for XMLs that are always valid.
	 *
	 * @param sXmlUrl URL of XMl which should be always valid
	 * @return XMLObject
	 */
	public static XMLObject parseUrl(String sXmlUrl)
	{
		return XMLObjectFactory.getXMLObjectFromURL(sXmlUrl);
	}

	/**
	 * Method parses given URL and returns parsed XMLObject.
	 *
	 * The key difference from constructors that this method throws only
	 * Runtime exceptions. This is useful for XMLs that are always valid.
	 *
	 * @param xmlURL URL of XMl which should be always valid
	 * @return XMLObject
	 * @throws XMLObjectRuntimeException if URL is unexisting or XML is invalid
	 */
	public static XMLObject parseUrl(URL xmlURL)
	{
		try
		{
			return new XMLObject(xmlURL);
		}
		catch (XMLObjectException xmle)
		{
			throw new XMLObjectRuntimeException("Invalid XML: " + xmlURL, xmle, toProp(xmlURL.toString()));
		}
	}

	/**
	 * Method parses given File and returns parsed XMLObject.
	 *
	 * The key difference from constructors that this method throws only
	 * Runtime exceptions. This is useful for XMLs that are always valid.
	 *
	 * @param file
	 * @return
	 * @throws XMLObjectRuntimeException
	 */
	public static XMLObject parseFile(File file)
	{
		try
		{
			return new XMLObject(file);
		}
		catch (XMLObjectException xmle)
		{
			throw new XMLObjectRuntimeException("Invalid XML: " + file.getAbsolutePath(), xmle, toProp(file.toString()));
		}
	}

	public static XMLObject parseValidXml(String sXml)
	{
		try
		{
			return new XMLObject(sXml);
		}
		catch (XMLObjectException xmle)
		{
			throw new XMLObjectRuntimeException(xmle);
		}
	}
}
