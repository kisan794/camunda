/*
 * @(#)$RCSfile: CHttpParametersSet.java,v $ $Revision: 1.18 $ $Date: 2012/07/27 07:43:22 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CHttpParametersSet.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	2004-09-07	A.Solntsev			Class CHttpParametersStorage is completely rewritten.
 *  2005-01-21	A.Solntsev			Method getParameter(String sParamID, int nIndex) fixed.
 *  2005-01-21	A.Solntsev			Added support for sections without "index" attribute.
 *  2005-01-25	A.Solntsev			Method putParameterIntoXML() now returns false
 *  														instead of throwing CXMLTemplateException.
 *  2005-03-10	A.Solntsev			putParameter(String, String) throws IllegalArgumentException
 *  2005-07-22	S.Vasilyev			putParameterIntoXML and getXMLElementByHTMLParameter
 *  														changed - LogTrace entried changed to debug
 *	2005-07-26	A.Solntsev			Trace Logging moved to CFormParser (one log
 *  														per page, instead of one per element).
 *	2006-03-20	V.Nikitin			Make class public. Supports any root tag.
 *	2007-01-09	A.Solntsev			implements Serializable
 *	2007-03-xx	A.Solntsev			Added list of invalid elements IDs (like "edu_end_date#2")
 *	2007-10-01	A.Lipatov			type of parameter "aInvalidElements" for method addValidationSummary()
 *														was changed from List to Collection.
 *	2007-11-20	A.Solntsev			Removed method finalize() which erases object m_xmlData.
 *	2007-12-06	E.Tonkoshkurov	Updated parseIndex() method: WARNING has only invalid XML node
 *															instead of whole application XML.
 *	2009-12-09	A.Solntsev			Vector -> List
 *	2012-07-12	M.Konstantinov	added support with immutable nodes
 */
package hireright.sdk.html.utils;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

/**
 *
 * @author Andrei Solntsev
 * @since Apr 11, 2007
 * @version $Revision: 1.18 $ $Date: 2012/07/27 07:43:22 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CHttpParametersSet.java,v $
 */
public class CHttpParametersSet implements IHttpParametersStorage, Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.18 $ $Author: cvsroot $";
	
	private static final String DATA_NODE_TAG = "data_node";
	private static final String ROOT_TAG = "ROOT";
	private static final String ATTRIBUTE_NAME = "name";

	//Reserved parameter names
	private static final String TOTALS_PARAM_NAME = "validation_total";
	private static final String XA_NUM_VALID = "num_valid";
	private static final String XA_NUM_INVALID = "num_invalid";
	private static final String XA_NUM_INVALID_REQUIRED = "num_invalid_required";
	private static final String XA_INVALID_ELEMENTS = "invalid_elements";
	
	private static final String ATTRIBUTE_IMMUTABLE = "immutable";

	private final XMLObject m_xmlData;

	/**
	 * This class is package-private.
	 * Use CHttpParametersStorageFactory.getFactory() to access it.
	 * @param xmlData
	 */
	public CHttpParametersSet(XMLObject xmlData)
	{
		m_xmlData = xmlData;
	}

	public XMLObject getData()
	{
		return m_xmlData;
	}

	public String getDataAsString()
	{
		return (getData() == null)? null : getData().toString(true);
	}

	public boolean putParameter(String sParameterName, String sParameterValue)
	{
		if (sParameterName == null || sParameterName.trim().length()==0)
		{
			//CProperties params = new CProperties().setProperty("parameterValue", sParameterValue);
			//CTraceLog.warning(new IllegalArgumentException("Empty parameter name"), getClass().getName()+".putParameter()", params, null);
			return false;
		}

		// NB! If first action succeeded, we DO NOT call the second.
		return (tryToUpdateNodeByUniqueName(sParameterName, sParameterValue))
							|| putParameterIntoXML(sParameterName, sParameterValue);
	}

	/**
	 *	This feature is done to support new HTTP parameters format.
	 *	@param nodeUniqueName attribute "name" value which precisly indicates the node to update with nodeValue
	 *
	 *  @param nodeValue value of the node to set
	 */
	private boolean tryToUpdateNodeByUniqueName(String nodeUniqueName, String nodeValue)
	{
		XMLTreeNode node = getData().getNodeByAttribute(ATTRIBUTE_NAME, nodeUniqueName );
		if (node != null)
		{
			if(CStringUtils.equals(node.getAttribText(ATTRIBUTE_IMMUTABLE), "true")) 
			{
				CTraceLog.error("Attempt to write immutable node", CHttpParametersSet.class.getName(), new CProperties().setProperty("name", nodeUniqueName).setProperty("value", nodeValue));
				return true;
			}
			node.clearText();	// Just to make sure we have not both TEXT and CDATA
			node.setText(nodeValue, XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT, XMLConsts.TYPE_CDATA);

			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * create parameter node or find parameter node and set it value
	 * @param sParameterName parameter name in format "NAMEx" where x - numeric indexes
	 * @param sParameterValue value of the parameter
	 */
	private boolean putParameterIntoXML(String sParameterName, String sParameterValue)
	{
		XMLTreeNode node = getXMLElementByHTMLParameter(sParameterName);
		if (node == null)
		{
			//throw new CXMLTemplateException("Cannot put parameter: " + sParameterName + "=\"" + sParameterValue + "\"", getData());

			//CTraceLog.debug(
			//	new IllegalArgumentException("Cannot put parameter: " + sParameterName + "=\"" + sParameterValue + "\"").toString(),
			//	getClass().getName()+".putParameterIntoXML()", null, getDataAsString());

			// Or we simply should
			return false;
		}

		setNodeText(node, sParameterValue);
		return true;

	}

	private void setNodeText(XMLTreeNode xmlNode, String szNodeValue)
	{
		xmlNode.clearText();	// To make sure we have not both TEXT and CDATA
		xmlNode.setText(szNodeValue,
							XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT, XMLConsts.TYPE_CDATA);
	}

	private void setAttribute(String sParamID, int nIndex, String sName, String sValue)
	{
		if(sParamID == null || sName == null)
			return;

		XMLTreeNode node = getData().getNode(sParamID, nIndex);

		if(node != null)
			node.addAttribNode(sName, sValue);
	}

	@Override
	public String toString()
	{
		return getData().toString(true);
	}


	/**
	 * Used in validator. Gets node by path.
	 * @param sPath path, see XMLObject
	 * @param nIndex the exact node (could be more than 1 if path returns more than one node)
	 * @return XMLTreeNode or null
	 */

	public XMLTreeNode getNodeByPath(String sPath, int nIndex)
	{
		return getData().getRootNode().getChildXmlNodeByPath(sPath, nIndex);
	}

	public XMLTreeNode getNodeByPath(String sPath)
	{
		return getData().getRootNode().getChildXmlNodeByPath(sPath);
	}


	/**
	 * return parameter node with PARAMETER_NAME=sParamID
	 * this method is used in CValidator
	 * @param sParamID
	 * @return XMLTreeNode or null
	 */
	public XMLTreeNode getParameter(String sParamID)
	{
		return getParameter(sParamID, 1);	// NB!   This is big mistake!!!!!
	}

	/**
	 * This is the new function.
	 * Currently I don't know how to use it - depends on how CValidator works
	 *
	 * @param szHTMLParameter	"edu_name", "edu_name2", "edu_name3_4", "edu_name1_2_3", ...
	 * 				(any number of indicies delimited by underscore)
	 *
	 * @return XML Element mapped to this HTML Parameter
	 */
	private XMLTreeNode getXMLElementByHTMLParameter(String szHTMLParameter)
	{
		if (szHTMLParameter == null || szHTMLParameter.trim().length()==0)
			return null;

		CValueWithIndecies multiIndexedValue = new CValueWithIndecies(szHTMLParameter);
		String szElementTag = multiIndexedValue.getValue();
		String[] aszHierarchy	= buildHierarchy(szElementTag);

		XMLTreeNode parentNode = getNodeByHierarchy(aszHierarchy, multiIndexedValue.getIndecies());
		if (parentNode == null)
		{
			// Last hope:  if element "state2" not found above, it's possible
			// to find element with the whole name "state2"  (such elements are deprecated).
			return getData().getNode(szHTMLParameter);
		}

		XMLTreeNode element = parentNode.getChildNodeByTag(szElementTag);
		if (element == null)
		{
			// This should not happen.
			// For safety, we remain it here for some time.
			// TODO: S.Prokopov Uncomment it when com vxml's are updated
			// This happens for COM for each note, so validation take unreasonable time
			/*CProperties params = new CProperties().setProperty("HTMLParameter", szHTMLParameter);
			CTraceLog.debug(
						new IllegalArgumentException("XML Element not found. New element created. Please add it to XML Template!").toString(),
						getClass().getName() + ".getXMLElementByHTMLParameter()", params, getDataAsString());*/
			element = parentNode.addChildNode(szElementTag, "");
		}
		return element;
	}

	/**
	 * COMMENT ME
	 *
	 * @param szElementTag				"edu_city"
	 * @return array of Strings		{"edu_address", "education"}
	 */
	protected String[] buildHierarchy(String szElementTag)
	{
		XMLTreeNode node = getData().getNode(szElementTag);
		if (node == null)
		{
			// TODO	TraceLog?  Or what?
			return null;
		}

		String[] parents = new String[100];		// Maximal path length
		int i = 0;
		do
		{
			XMLTreeNode parent = (XMLTreeNode) node.getParent();
			if (parent == null) {
				break;
			}
			String tag = parent.getXMLTag();
			if (DATA_NODE_TAG.equals(tag) || ROOT_TAG.equals(tag))
				break;

			parents[i++] = tag;
			node = parent;
		} while (true);

		String[] retValue = new String[i];
		System.arraycopy(parents, 0, retValue, 0, i);

		parents = null; // Help garbage collector ?

		return retValue;
	}

	/**
	 * Given hierarchy and indecies, finds out needed XML Element.
	 * For example, let's
	 * 	- aszHierarchy = {"education", "address"},
	 *  - anIndecies = {3, 2}
	 *
	 * Then method returns XML Element equvalent to this:
	 * 	 <xsl:select value="data_node/educqation[3]/address[2]" />
	 *
	 * @param aszHierarchy
	 * @param anIndecies
	 * @return XMLTreeNode or null
	 */
	protected XMLTreeNode getNodeByHierarchy(String[] aszHierarchy, int[] anIndecies)
	{
		/*
		 * We could use XML-Path instead, but I am afraid it doesn't work correctly.
		 */
		if ( (aszHierarchy==null || aszHierarchy.length==0) &&
				(anIndecies==null || anIndecies.length==0) )
		{
			return getData().getNode(DATA_NODE_TAG);
		}

		if (aszHierarchy == null)
		{
			// It means that XML Element "edu_name" is not found at all.
			return null;
		}

		if (aszHierarchy.length != anIndecies.length)
		{
			//	TODO	CTraceLog?
			// System.out.println("Error: invalid length of indecies array");
			return null;
		}

		XMLTreeNode node = getData().getNode(DATA_NODE_TAG);
		if (node == null) {
			node = getData().getRootNode();
		}
		for (int i = aszHierarchy.length-1; i>=0; i--)
		{
			XMLTreeNode child = null;
			for (int j=1; ; j++)
			{
				child = node.getChildNodeByTag(aszHierarchy[i], j);
				if (child == null)
					break;

				int nIndex = parseIndex(child.getAttribText("index"));

				if (nIndex == anIndecies[i])
					break;
			}
			if (child == null)
			{
				// TODO		Trace Log?
				return null;
			}

			node = child;
		}

		return node;
	}

	/**
	 * If sIndex contains a number, returns this number.
	 * If sIndex is null, returns 1 (default value for sections that havn't index,
	 * for example, <DrivingLicense> on Background page).
	 *
	 * If sIndex contains something other except number,
	 * writes warning to tracelog and returns 1.
	 *
	 * @param sIndex
	 * @return 	1 by default (if sIndex is null or nonnumber)
	 */
	private int parseIndex(String sIndex)
	{
		int nIndex = 1;
		try
		{
			if (sIndex != null)
				nIndex = Integer.parseInt(sIndex);
		}
		catch (NumberFormatException e)
		{
			CProperties params = new CProperties().setProperty("index", sIndex);
			CTraceLog.warning(e, getClass().getName()+".getNodeByHierarchy()", params,
					getData().getNodeByAttribute("index", sIndex).toString());
			nIndex = 1;
		}
		return nIndex;
	}


	/**
	 * returns nodes max count from results
	 * this method is used in CValidator
	 * @param sParamID
	 * @return 0 if no such nodes found
	 */
	public int getParameterCount(String sParamID)
	{
		return getData().getNodesCount(sParamID);
	}

	/**
	 * this method is used in CValidator
	 * @param sParamID
	 * @param nIndex
	 * @return	null	if node can not be found
	 */
	public XMLTreeNode getParameter(String sParamID, int nIndex)
	{
		if(sParamID == null || nIndex < 1)
			return null;

		/**
		 * 1. Step
		 * If sParamID is "edu_graduate", nIndex=2, then we try to find
		 * element <edu_graduate> in section <education index="2">.
		 */
		XMLTreeNode node = getXMLElementByHTMLParameter(sParamID + nIndex);

		/**
		 * 2. Step
		 * If sParamID is "personal_first_name", then we try to find node
		 * 	/data_node/personal_first_name
		 *
		 * I think it can be only in case nIndex = 1.
		 */
		if (node == null)
		{
			// TODO: S.Prokopov Uncomment it when com vxml's are updated
			// This happens for COM for each note, so validation take unreasonable time
			/*if (nIndex != 1)
			{
				CProperties params = new CProperties()
							.setProperty("nIndex", String.valueOf(nIndex))
							.setProperty("sParamID", sParamID);
				CTraceLog.warning("nIndex > 1", getClass().getName()+".getParameter()", params, getDataAsString());
			}*/
			node = getData().getNode(sParamID, nIndex);
		}

		return node;
	}


	/**
	 * Returns list of nodes that match specified path
	 * @param sPathValue node path
	 * @return List of nodes or null if not found
	 */
	public List<XMLTreeNode> getNodesByPath(String sPathValue)
	{
		return m_xmlData.getRootNode().getChildNodesByPath(sPathValue);
	}
	
	/**
	 * @deprecated Use method {@link #getNodesByPath(String)} instead
	 */
	@Deprecated
	public Vector<XMLTreeNode> getNodesListByPath(String sPathValue)
	{
		return m_xmlData.getRootNode().getChildNodesListByPath(sPathValue);
	}

	/**
	 * Method can be called by some validator.
	 * It injects into XML Storage three values:
	 *
	 * @param	nTotalValid					number of valid parameters
	 * @param	nTotalInvalid				number of invalid parameters
	 * @param	nTotalInvalidRequired		number of invalid required parameters
	 * @param	cInvalidElements		 	collection of invalid elements IDs (like "edu_end_date#2")
	 *
	 * @throws CXMLTemplateException	if XML Template does not contain element <validation_total>
	 */
	public void addValidationSummary(int nTotalValid, int nTotalInvalid, int nTotalInvalidRequired,
		Collection<String> cInvalidElements)
		throws CXMLTemplateException
	{
		if (this.getParameter(TOTALS_PARAM_NAME) == null)
		{
			CProperties params = new CProperties();
			params.setProperty("totalValid", String.valueOf(nTotalValid));
			params.setProperty("totalInvalid", String.valueOf(nTotalInvalid));
			params.setProperty("totalInvalidRequired", String.valueOf(nTotalInvalidRequired));
			throw new CXMLTemplateException("Element <"+TOTALS_PARAM_NAME+"> is not found", params, getData());
		}

		setAttribute(TOTALS_PARAM_NAME, 1, XA_NUM_VALID, Integer.toString(nTotalValid));
		setAttribute(TOTALS_PARAM_NAME, 1, XA_NUM_INVALID, Integer.toString(nTotalInvalid));
		setAttribute(TOTALS_PARAM_NAME, 1, XA_NUM_INVALID_REQUIRED, Integer.toString(nTotalInvalidRequired));
		setAttribute(TOTALS_PARAM_NAME, 1, XA_INVALID_ELEMENTS, cInvalidElements.toString());
	}
}
