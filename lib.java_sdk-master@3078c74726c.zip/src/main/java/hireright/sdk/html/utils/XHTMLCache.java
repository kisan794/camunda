/*
 * @(#)$RCSfile: XHTMLCache.java,v $ $Revision: 1.15 $ $Date: 2010/01/08 08:52:39 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/XHTMLCache.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	unknown		Anton Keks		Created
 *	2005-02-16	A.Solntsev		Removed "throws Exception"
 *	2005-08-29	A.Solntsev		Now EHCache library is used.
 *	2006-06-07	A.Solntsev		Improved throwing of exception (saving original stack trace)
 *	2007-06-22	A.Solntsev		Removed dependency on hireright.sdkex.as_cache
 *	2007-11-09	A.Solntsev		Added method getXHTMLInjector(URL szURL, boolean bCreateNew)
 */
package hireright.sdk.html.utils;

import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import hireright.sdk.debug.CStackTrace;
import hireright.sdk.html.parser.XMLObjectException;
import hireright.sdk.html.parser.XMLObjectRuntimeException;
import hireright.sdk.util.CFileContent;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;

/**
 * A Class for caching already parsed XHTML documents
 *
 * @author Anton Keks
 * @version $Revision: 1.15 $ $Date: 2010/01/08 08:52:39 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/XHTMLCache.java,v $
 */
public class XHTMLCache implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.15 $ $Author: cvsroot $";
	
	private static XHTMLCache m_instance = null;
	private static final Object lock = new Object();

	private final Cache m_cache;
	protected XHTMLCache(Cache cache)
	{
		m_cache = cache;
	}

	protected static XHTMLCache getInstance()
	{
		if (null == m_instance)
		{
			synchronized (lock)
			{
				if (null == m_instance)
				{
					CacheManager mng = CacheManager.create();
					String sCacheName = XHTMLInjector.class.getName();
					Cache cache = mng.getCache(sCacheName);
					if (null == cache)
					{
						mng.addCache(sCacheName);
						cache = mng.getCache(sCacheName);
					}

					m_instance = new XHTMLCache(cache);
				}
			}
		}

		return m_instance;
	}

	public static void resetCache()
	{
		getInstance().m_cache.removeAll();
	}

	public static void resetCache(String szURL)
	{
		getInstance().m_cache.remove(szURL);
	}

	/**
	 * COMMENT ME
	 * @param szURL
	 * @return cached XHTMLInjector object
	 *
	 * @throws RuntimeException if XHTML is invalid
	 */
	public static XHTMLInjector getXHTMLInjector(String szURL)
	{
		return getXHTMLInjector(parseURL(szURL), false);
	}

	public static XHTMLInjector getXHTMLInjector(URL xhtmlURL)
	{
		return getXHTMLInjector(xhtmlURL, false);
	}

	public static XHTMLInjector getXHTMLInjector(String szURL, boolean bCreateNew)
	{
		return getXHTMLInjector(parseURL(szURL), bCreateNew);
	}

	/**
	 * COMMENT ME
	 * @param szURL
	 * @param bCreateNew
	 * @return XHTMLInjector with given URL
	 *
	 * @throws NullPointerException if szURL is null
	 * @throws RuntimeException if XHTML is invalid
	 */
	public static XHTMLInjector getXHTMLInjector(URL szURL, boolean bCreateNew)
	{
		if (szURL == null)
			throw new IllegalArgumentException("URL must not be null");

		if (bCreateNew)
			return parseXHTML(szURL);

		final XHTMLInjector cachedInjector;
		Element el = getInstance().m_cache.get(szURL);
		if (el == null)
		{
			cachedInjector = parseXHTML(szURL);
			el = new Element(szURL, cachedInjector);
			getInstance().m_cache.put(el);
		}
		else
			cachedInjector = (XHTMLInjector) el.getValue();

		// Create a copy of cached injector before returning it
		return new XHTMLInjector( cachedInjector );
	}

	private static String readUrlContent(URL sUrl)
	{
		try
		{
			return CFileContent.getContent(sUrl);
		}
		catch (Exception ioe)
		{
			return CStackTrace.getStackTrace(ioe);
		}
	}

	private static String readUrlContent(String sUrl)
	{
		try
		{
			return CFileContent.getContent(sUrl);
		}
		catch (Exception ioe)
		{
			return CStackTrace.getStackTrace(ioe);
		}
	}

	private static CProperties toProperties(URL sURL)
	{
		return new CProperties().setProperty("xhtmlUrl", sURL);
	}

	private static CProperties toProperties(String sURL)
	{
		return new CProperties().setProperty("xhtmlUrl", sURL);
	}

	/**
	 *
	 * @param sURL
	 * @return new URL
	 * @throws XMLObjectRuntimeException
	 */
	private static URL parseURL(String sURL)
	{
		try
		{
			return new URL(sURL);
		}
		catch (MalformedURLException urlEx)
		{
			throw new XMLObjectRuntimeException(urlEx, toProperties(sURL), readUrlContent(sURL));
		}
	}

	/**
	 * Do not call this method directly - use mthods getXHTMLInjector(...)
	 * This method is used by Object Cache framework.
	 *
	 * @throws CRuntimeException if XHTML is invalid
	 */
	protected static XHTMLInjector parseXHTML(URL sURL)
	{
		XHTMLInjector injector;

		try
		{
			injector = new XHTMLInjector(sURL);
		}
		catch (XMLObjectException xmle)
		{
			throw new XMLObjectRuntimeException(xmle, toProperties(sURL), readUrlContent(sURL));
		}

		return injector;
	}
}

