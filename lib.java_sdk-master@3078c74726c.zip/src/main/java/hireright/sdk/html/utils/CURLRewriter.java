/*
 * @(#)$RCSfile: CURLRewriter.java,v $ $Revision: 1.7 $ $Date: 2009/07/10 09:27:03 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CURLRewriter.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History
 * 	Anton Keks				2004-07-22	Created
 * 	A.Solntsev				2008-01-15	Bugfixes; added more methods.
 */
package hireright.sdk.html.utils;

import hireright.sdk.util.CStringUtils;

/**
 * Utility class with functions to preform URL rewriting
 * in HTML content, eg. to insert session keys
 *
 * @author Anton Keks
 * @version $Revision: 1.7 $ $Date: 2009/07/10 09:27:03 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CURLRewriter.java,v $
 */
public class CURLRewriter 
{
	public static final String SESSION_KEY_PREFIX = ";jsessionid=";
	
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: asolntsev $";

	/**
	 * Processes HTML content passed as String and adds 
	 * specified session keys to the names of a specified
	 * servlet
	 * @return processed content 
	 */
	public static String addSessionKeys(String sHTMLContent, String sSessionKey, String sServletName)	
	{
		if (CStringUtils.isEmpty(sHTMLContent) && CStringUtils.isEmpty(sServletName))
			return SESSION_KEY_PREFIX + sSessionKey;
		if (sHTMLContent.indexOf(sServletName) < 0)
			return sHTMLContent;
		
		// Initialize resulting string buffer
		StringBuilder sbResult = new StringBuilder(sHTMLContent);
		addSessionKeys(sbResult, sSessionKey, sServletName);
		return sbResult.toString();
	}
	
	@Deprecated
	public static void addSessionKeys(StringBuffer sbHTMLContent, String sSessionKey, String sServletName)
	{
		addSessionKeys(sbHTMLContent, sSessionKey, sServletName, SESSION_KEY_PREFIX);
	}
	
	public static void addSessionKeys(StringBuilder sbHTMLContent, String sSessionKey, String sServletName)
	{
		addSessionKeys(sbHTMLContent, sSessionKey, sServletName, SESSION_KEY_PREFIX);
	}
	
	/**
	 * 
	 * @deprecated use method with StringBuilder {@link #addSessionKeys(StringBuilder, String, String, String)}
	 */
	@Deprecated
	public static void addSessionKeys(StringBuffer sbHTMLContent, String sSessionKey, String sServletName, String sSessionKeyPrefix)
	{
		// Remember the length of the servlet name
		int nServletNameLength = sServletName.length();
		
		if (sbHTMLContent.length() == 0 && sServletName.length() == 0)
		{
			sbHTMLContent.append(SESSION_KEY_PREFIX + sSessionKey);
			return;
		}
		
		int nPosition = sbHTMLContent.indexOf(sServletName);
		while (nPosition >= 0)
		{
			// Increase the position by the length of servlet
			nPosition += nServletNameLength;
			
			if (sbHTMLContent.length() < nPosition + SESSION_KEY_PREFIX.length() || 
					!sbHTMLContent.substring( nPosition, nPosition + SESSION_KEY_PREFIX.length() ).equals( SESSION_KEY_PREFIX ))
			{
				// Append data to the buffer
				sbHTMLContent.insert( nPosition, sSessionKeyPrefix + sSessionKey);
			}
			
			// Remember the old position
			// nOldPosition = nPosition;
			// Find new position
			nPosition = sbHTMLContent.indexOf(sServletName, nPosition);
		}		
		
		// Append all remaining stuff
		// sbResult.append(sHTMLContent.substring(nOldPosition));
	}
	
	public static void addSessionKeys(StringBuilder sbHTMLContent, String sSessionKey, String sServletName, String sSessionKeyPrefix)
	{
		// Remember the length of the servlet name
		int nServletNameLength = sServletName.length();
		
		if (sbHTMLContent.length() == 0 && sServletName.length() == 0)
		{
			sbHTMLContent.append(SESSION_KEY_PREFIX + sSessionKey);
			return;
		}
		
		int nPosition = sbHTMLContent.indexOf(sServletName);
		while (nPosition >= 0)
		{
			// Increase the position by the length of servlet
			nPosition += nServletNameLength;
			
			if (sbHTMLContent.length() < nPosition + SESSION_KEY_PREFIX.length() || 
					!sbHTMLContent.substring( nPosition, nPosition + SESSION_KEY_PREFIX.length() ).equals( SESSION_KEY_PREFIX ))
			{
				// Append data to the buffer
				sbHTMLContent.insert( nPosition, sSessionKeyPrefix + sSessionKey);
			}
			
			// Remember the old position
			// nOldPosition = nPosition;
			// Find new position
			nPosition = sbHTMLContent.indexOf(sServletName, nPosition);
		}		
		
		// Append all remaining stuff
		// sbResult.append(sHTMLContent.substring(nOldPosition));
	}
	
	/*
	public static void main(String[] argv)
	{
		// Small test :-)
		String sTmp = "<html><a href='/oseserv/abcservlet?megacool=123'>blahblah</a><script>var URL='abcservlet'</script></html>";
		System.out.println(addSessionKeys(sTmp, "SESSION", "abcservlet"));
	}
	*/
}
