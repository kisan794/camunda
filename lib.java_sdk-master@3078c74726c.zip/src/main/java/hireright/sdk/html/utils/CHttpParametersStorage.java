/*
 * @(#)$RCSfile: CHttpParametersStorage.java,v $ $Revision: 1.25 $ $Date: 2015/11/02 20:16:36 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CHttpParametersStorage.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 2003.09.24 	S.Ignatov		completely rewritten.
 * 2004.01.29 	D.Travin		a little bit redesigned, logic forked
 * 2004-03-11	A.Keks			nasty bug with clearing of checkboxes fixed
 * 2004-03-19	A.Solntsev		Fixed bug with setText(TEXT / CDATA).
 * 2004-06-08	A.Solntsev		Removed oldered ATTRIBUTE_TAG_SOURCE = "knewsrc"
 * 2004-06-10	A.Solntsev		Added node.clearText() to make sure we have not
 *    													both TEXT and CDATA (sometimes we had such bug)
 * 2004-06-10	A.Solntsev		Fixed bug with setText(TEXT / CDATA) once more.
 * 2004-07-28	A.Podlipski		temporary fix: clearance made optional to prevent data loss
 * 2004-08-26	S.Prokopov		removed temporary fix.
 * 2004-11-29	A.Solntsev		Class is completely rewritten (CHttpParametersSet).
 *													For compatibility with old XMLs, this class is left too.
 * 2005-03-10	A.Solntsev		putParameter(String, String) throws IllegalArgumentException
 * 2005-07-26	A.Solntsev		Trace Logging moved to CFormParser (one log
 *  												per page, instead of one per element).
 * 2005-10-22	A.Solntsev		Removed usage of HttpServletRequest
 * 2006-06-07	A.Solntsev		Optimization and API enhancements of XMLObject
 * 2007-01-09	A.Solntsev		implements Serializable
 * 2007-03-xx	A.Solntsev		Added list of invalid elements IDs (like "edu_end_date#2")
 * 2007-10-01	A.Lipatov			type of parameter "aInvalidElements" for method addValidationSummary()
 * 													was changed from List to Collection.
 * 2007-11-20	A.Solntsev		Removed from method finalize() erasing objects m_xmlData and m_xmlTemplate.
 * 2009-12-09	A.Solntsev		Vector -> List
 * 2012-07-12	M.Konstantinov	added support with immutable nodes
 * 2015-08-03	S.Ignatov		immutable nodes log extended with complete data.
 */
package hireright.sdk.html.utils;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.parser.XMLTreeNodeParser;
import hireright.sdk.html.utils.CValueWithIndex;

import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import hireright.sdk.html.validator.CValidator;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

/**
*
* @author Sergei Ignatov
* @since Apr 11, 2007
* @version $Revision: 1.25 $ $Date: 2015/11/02 20:16:36 $ $Author: cvsroot $
* @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CHttpParametersStorage.java,v $
*/
public class CHttpParametersStorage implements IHttpParametersStorage, Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.25 $ $Author: cvsroot $";
	
/**
 * ! important !
 * add new parameters only throw addParameter(String sName, String sValue),
 * do not use methods of hireright.sdk.html.parser.* classes
 *
 * class intended to pass http parametres of web form into xml structure, based on template.
 *
 * it receives http parameters in format "paramter_name_{INDEX{_INDEX{_INDEX{...}}}}" or "paramter_name{INDEX{_INDEX{...}}}"
 * and applies parameter`s value into xml structure.
 *
 * example:
 *
 *   parameter
 *     first_name_2_2="N/A"
 *
 *   template
 *     <data_node>
 *       <education>
 *         <first_name><![CDATA[]]></first_name>
 *       </education>
 *     </data_node>
 *
 *   result
 *     <data_node>
 *       <education index="1"/>
 *       <education index="2">
 *         <first_name><![CDATA[]]></first_name>
 *         <first_name><![CDATA[N/A]]></first_name>
 *       </education>
 *     </data_node>
 *
 * differences from previous versions
 *   allow to use parameters with more than one level of sections
 *   parameter name format valid forms paramter_name_XXXX and paramter_nameXXXX
 *   coping attributes of data node from template to data xml
 *
 * <pre>
 * History:
 * 		2003.09.24 	S.Ignatov			completely rewritten.
 * </pre>
 */
	private static final String DATA_NODE_TAG = "data_node";
	private static final String DATA_GROUP_ATTRIBUTE = "data_group";
	private static final String ATTRIBUTE_TAG_SOURCE = "knewsrc";
	private static final String ATTRIBUTE_TAG_INDEX = "index";
	private static final String ATTRIBUTE_CLEARANCE = "clearance";
	private static final String ATTRIBUTE_NAME = "name";
	private static final String ATTRIBUTE_IMMUTABLE = "immutable";
	
	

	//Reserved parameter names
	public static final String TOTALS_PARAM_NAME = "validation_total";
	private static final String XA_NUM_VALID = "num_valid";
	private static final String XA_NUM_INVALID = "num_invalid";
	private static final String XA_NUM_INVALID_REQUIRED = "num_invalid_required";
	private static final String XA_INVALID_ELEMENTS = "invalid_elements";

	/**
	 * @serial
	 */
	private XMLObject 			m_xmlData = new XMLObject();

	/**
	 * @serial
	 */
	private XMLObject 			m_xmlTemplate = new XMLObject();

	/**
	 * create empty http parameters storage object
	 */
	public CHttpParametersStorage()
	{
		createXMLStructure();
	}

	/**
	 * create http parameters storage object
	 * using template for storing data
	 *
	 * @param xmlTemplate
	 */
	public CHttpParametersStorage(XMLObject xmlTemplate)
	{
		m_xmlTemplate = xmlTemplate;
		createXMLStructure();
	}

	public final XMLObject getTemplate()
	{
		return m_xmlTemplate;
	}

	public XMLObject getData()
	{
		return m_xmlData;
	}

	/**
	 * return <?xml... XMLTreeNode for xml data from template
	 * @param xmlNode
	 * @return empty list if no parents found
	 */
	private XMLTreeNode getTemplateProcInstructions()
	{
		if (getTemplate() == null || getTemplate().getRootNode() == null)
			return null;
		XMLTreeNode xmlHeaderNode = getTemplate().getRootNode().getChildNodeByType(XMLConsts.TYPE_PROCESSING_INSTRUCTION);
		return xmlHeaderNode;
	}

	/**
	 * returns node with name, which match to sParameterName
	 */
	private XMLTreeNode getParameterNodeFromTemplate(String sParameterName)
	{
		// initialisation
		boolean isContinueNodeFinding = true;
		String sRealName = sParameterName;
		String sRealNameOld = sParameterName;

		// find first
		XMLTreeNode findedNode = getTemplate().getNode(sRealName, 1);
		if (findedNode != null)
			return findedNode;

		// find all next
		while(isContinueNodeFinding)
		{
			// devine character and numeric parts of name
			CValueWithIndex valueWithIndex = new CValueWithIndex(sRealName);
			sRealNameOld = sRealName;
			sRealName = valueWithIndex.getValue();

			// find node with name without numeric index
			findedNode = getTemplate().getNode(sRealName, 1);

			// check for node, like NODENAME_, or NODENAME
			if(findedNode == null && sRealName.endsWith("_"))
			{
				sRealName = sRealName.substring(0, sRealName.length() - 1);
				findedNode = getTemplate().getNode(sRealName, 1);
			}

			// is node found ?
			if(findedNode != null)
			{
				return findedNode;
			}
			// not found, check that possible to continue
			else
			{
				if(sRealName.equals(sRealNameOld) || sRealName.length() == 0)
					isContinueNodeFinding = false;
			}
		}

		// node, which match sParameterName was not found. create new one.
		findedNode = XMLTreeNodeParser.getNodeForType(XMLConsts.TYPE_NODE, sParameterName, null);
		findedNode.setParent(getTemplate().getNode(DATA_NODE_TAG, 1));

		return findedNode;

	}

	/**
	 * returns array of parents XMLTreeNodes
	 * @param xmlNode
	 * @return empty list if no parents found
	 */
	protected List<XMLTreeNode> getNodeParents(XMLTreeNode xmlNode)
	{

		List<XMLTreeNode> vectorResult = new LinkedList<XMLTreeNode>();
		XMLTreeNode parentNode = xmlNode;

		while(parentNode != null && !parentNode.getXMLTag().equals(DATA_NODE_TAG))
		{
			vectorResult.add(0, parentNode);
			parentNode = (XMLTreeNode) parentNode.getParent();
		}

		return vectorResult;
	}

	/**
	 * find or create node, defined by nodeFromTemplate and sIndexes parameters.
	 */
	private XMLTreeNode getParameterNodeFromData(XMLTreeNode nodeFromTemplate, String sIndexes)
	{
		// original parameter name is
		String sSourceParameterName = nodeFromTemplate.getXMLTag() + sIndexes;

		// A.Solntsev	2004-06-08		I don't for what it was needed. I think it can be removed.
		// is node with this paramter exists
		//XMLTreeNode nodeFromData = getData().getNodeByAttribute(ATTRIBUTE_TAG_SOURCE, sSourceParameterName);
		//if(nodeFromData != null)
		//	return nodeFromData;
		XMLTreeNode nodeFromData = null;

		// find all parents of template node
		List<XMLTreeNode> parentsOfNodeFromTemplate = getNodeParents(nodeFromTemplate);
		XMLTreeNode parentNodeToAddFromData = getData().getNode(DATA_NODE_TAG, 1);
		StringTokenizer stIndexes = new StringTokenizer(sIndexes, "_");

			String sCurrentIndex = "";
		// find or create node / level loop
		for (XMLTreeNode parentNodeTemplate : parentsOfNodeFromTemplate)
		{
			// get level parent node from template.
			XMLTreeNode parentNodeData = null;
			int nFinalSectionIndex = 1;
			if(stIndexes.hasMoreTokens())
			{
				String sTokenTagName = stIndexes.nextToken();
				nFinalSectionIndex = Integer.parseInt(sTokenTagName);
			}

			// loop sections
			for(int nSectionIndex = 1; nSectionIndex <= nFinalSectionIndex; nSectionIndex++)
			{
				// get level parent node from data.
				parentNodeData = parentNodeToAddFromData.getChildNodeByTag(parentNodeTemplate.getXMLTag(), nSectionIndex);
				if(parentNodeData == null)
				{
					parentNodeData = XMLTreeNodeParser.getNodeForType(XMLConsts.TYPE_NODE,
							parentNodeTemplate.getXMLTag(), null);

					if (nodeFromTemplate != parentNodeTemplate)
					{
						String sGlobalIndex = "" + nSectionIndex;
						if(sCurrentIndex.length() > 0)
							sGlobalIndex = sCurrentIndex + "_" + sGlobalIndex;
						parentNodeData.addAttribNode(ATTRIBUTE_TAG_INDEX, sGlobalIndex);
					}
					parentNodeToAddFromData.addChildNode(parentNodeData);
				}
			}
			if(sCurrentIndex.length() > 0)
				sCurrentIndex = sCurrentIndex + "_" + nFinalSectionIndex;
			else
				sCurrentIndex = "" + nFinalSectionIndex;

			parentNodeToAddFromData = parentNodeData;
			nodeFromData = parentNodeData;
		}

		if (nodeFromData != null)
			nodeFromData.addAttribNode(ATTRIBUTE_TAG_SOURCE, sSourceParameterName);

		return nodeFromData;
	}

	private void nodePostProcess(XMLTreeNode nodeParameterFromData,
		XMLTreeNode nodeParameterFomTemplate, String sParameterValue)
	{
		// data group attributes
		if (sParameterValue != null && sParameterValue.length() > 0)
		{
			String sDataGroups = nodeParameterFomTemplate.getAttribText(DATA_GROUP_ATTRIBUTE);
			if(sDataGroups != null && sDataGroups.length() > 0)
			{
				StringTokenizer stDataGroups = new StringTokenizer(sDataGroups);

				while(stDataGroups.hasMoreTokens())
				{
					String sTokenTagName = stDataGroups.nextToken();
					XMLTreeNode groupNode = ((XMLTreeNode) nodeParameterFromData.getParent()).getChildNodeByTag(sTokenTagName);

					if(groupNode != null) // if already created
					{
						groupNode.clearText();	// To make sure we have not both TEXT and CDATA
						groupNode.setText("true", XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT, XMLConsts.TYPE_CDATA);
					}
					else	// if not exists
					{
						groupNode = ((XMLTreeNode) nodeParameterFromData.getParent()).addChildNode(sTokenTagName, "true");
					}
				}
			}
		}

		//
	}

	/**
	 *	This feature is done to support new HTTP parameters format.
	 *	@param nodeUniqueName attribute "name" value which precisly indicates the node to update with nodeValue
	 *
	 *  @param nodeValue value of the node to set
	 */
	private boolean tryToUpdateNodeByUniqueName(String nodeUniqueName, String nodeValue)
	{
		XMLTreeNode node = getData().getNodeByAttribute(ATTRIBUTE_NAME, nodeUniqueName );
		if (node != null)
		{
			if(CStringUtils.equals(node.getAttribText(ATTRIBUTE_IMMUTABLE), "true")) 
			{
				CTraceLog.error("Attempt to write immutable node", 
						CHttpParametersSet.class.getName(), 
						new CProperties().setProperty("name", nodeUniqueName).setProperty("value", nodeValue),
						this.toString() );
				return true;
			}
			
			node.clearText();	// Just to make sure we have not both TEXT and CDATA
			node.setText(nodeValue, XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT, XMLConsts.TYPE_CDATA);

			return true;
		}
		else
		{
			return false;
		}
	}

	public boolean putParameter(String sParameterName, String sParameterValue)
		throws IllegalArgumentException
	{
		if (sParameterName == null || sParameterName.trim().length()==0)
		{
			//CProperties params = new CProperties().setProperty("parameterValue", sParameterValue);
			//CTraceLog.warning(new IllegalArgumentException("Empty parameter name"), getClass().getName()+".putParameter()", params, null);
			return false;
		}

		if (!tryToUpdateNodeByUniqueName(sParameterName, sParameterValue))
		{
			putParameterIntoXML(sParameterName, sParameterValue);
		}

		// This old implementation of IHttpParametersStorage always returns true.
		// If element not found in xml, method creates it.
		return true;
	}

	/**
	 * create parameter node or find parameter node and set it value
	 * @param sParameterName parameter name in format "NAME_XX_XX_XX_..." where XX - numeric indexes
	 * @param sParameterValue value of the parameter
	 * @return new node to which parameter has been stored
	 */
	public XMLTreeNode putParameterIntoXML(String sParameterName, String sParameterValue)
	{
		// get node from template
		XMLTreeNode nodeParameterFomTemplate = getParameterNodeFromTemplate(sParameterName);

		// get indexes part of parameter name
		String sIndexes = sParameterName.substring(nodeParameterFomTemplate.getXMLTag().length());

		// get or create node from template
		XMLTreeNode nodeParameterFromData = getParameterNodeFromData(nodeParameterFomTemplate, sIndexes);

		// set node from data xml value
		nodeParameterFromData.clearText();	// To make sure we have not both TEXT and CDATA
		nodeParameterFromData.setText(sParameterValue,
							XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT, XMLConsts.TYPE_CDATA);

		// post process node
		nodePostProcess(nodeParameterFromData, nodeParameterFomTemplate, sParameterValue);

		return nodeParameterFromData;
	}

	/**
	 * create new node in results xml tree
	 * @param sParameterName parameter like "parameterindex" or "parameter"
	 * @param sParameterValue
	 * @return (new) node to which parameter has been stored
	 */
	public XMLTreeNode createChildNode(String sParameterName, String sParameterValue)
	{
		return putParameterIntoXML(sParameterName, sParameterValue);
	}

	/**
	 * initialisation method
	 * create structure for storing data
	 *
	 * some code is commented out to work with new logic
	 */
	private final void createXMLStructure()
	{
		// if empty form template exists
		if (getTemplate() != null)
		{
			m_xmlData = new XMLObject( getTemplate() );


			// set value of m_rootDataXmlTreeNode with new value.
			/*
			XMLTreeNode dataXMLTreeNode = getData().getNode(DATA_NODE_TAG, 1);
			dataXMLTreeNode.setData(null);
			XMLTreeNode attributeNode = getTemplate().getNode(DATA_NODE_TAG, 1).getChildNodeByType(XMLConsts.TYPE_ATTRIBUTE);
			while(attributeNode != null)
			{
				if(attributeNode.getType() == XMLConsts.TYPE_ATTRIBUTE)
					dataXMLTreeNode.addAttribNode(attributeNode.getXMLTag(), attributeNode.getText());
				attributeNode = (XMLTreeNode) attributeNode.getNext();
			}
			m_xmlData.hashtablesRebuild();
			*/
		}
		else
		{
			// if empty form template does not exist
			// construct new
			XMLTreeNode dataNode = XMLTreeNodeParser.getNodeForType(XMLConsts.TYPE_NODE, DATA_NODE_TAG);
			m_xmlData = new XMLObject(dataNode);
		}
	}

	/**
	 * returns nodes max count from results
	 * this method is used in CValidator3
	 * @param sParamID
	 * @return number of parameters with given name
	 */
	public int getParameterCount(String sParamID)
	{
		XMLTreeNode parentNode = getParameterNodeFromTemplate(sParamID);
		if(!((XMLTreeNode) parentNode.getParent()).getXMLTag().equals(DATA_NODE_TAG))
			parentNode = (XMLTreeNode) parentNode.getParent();

		return getData().getNodesCount(parentNode.getXMLTag());
	}



	/**
	 * Create, replace attribute for node with PARAMETER_NAME=sParamID.
	 * Used in CValidator.
	 *
	 * @param sParamID
	 * @param sName
	 * @param sValue
	 */
	public void setAttribute(String sParamID, String sName, String sValue)
	{
		setAttribute(sParamID, 1, sName, sValue);
	}

	/**
	 * used in CValidator
	 * @param sParamID
	 * @param nIndex
	 * @param sName
	 * @param sValue
	 */
	public void setAttribute(String sParamID, int nIndex, String sName, String sValue)
	{
		if(sParamID == null || sName == null)
			return;

		XMLTreeNode node = getData().getNode(sParamID, nIndex);

		if(node != null)
			node.addAttribNode(sName, sValue);
	}

	/**
	 * remove attribute for node with PARAMETER_NAME=sParamID
	 * @param sParamID
	 * @param sName
	 */
	public void removeAttribute(String sParamID, String sName)
	{
		removeAttribute(sParamID, sName);
	}

	public void removeAttribute(String sParamID, int nIndex,  String sName)
	{
		if(sParamID == null || sName == null)
			return;

		XMLTreeNode node = getData().getNode(sParamID, nIndex);

		if(node != null)
			node.removeAttribNode(sName);
	}

	/**
	 * get attribute value for node with PARAMETER_NAME=sParamID
	 *
	 * @param sParamID
	 * @param sName
	 * @return value of attribute
	 */
	public String getAttributeValue(String sParamID, String sName)
	{
		return getAttributeValue(sParamID, 1, sName);
	}

	public String getAttributeValue(String sParamID, int nIndex,  String sName)
	{
		if(sParamID == null || sName == null)
			return null;

		XMLTreeNode node = getData().getNode(sParamID, nIndex);

		if(node == null)
			return null;

		return node.getAttribText(sName);
	}

	/**
	 * return parameter node with PARAMETER_NAME=sParamID
	 * this method is used in CValidator
	 *
	 * @param sParamID
	 * @return XML Node with given tag name
	 */
	public XMLTreeNode getParameter(String sParamID)
	{
		return getParameter(sParamID, 1);
	}

	/**
	 * this method is used in CValidator
	 *
	 * @param sParamID
	 * @param nIndex
	 * @return the <code>nIndex</code>'th XML Node with given tag name
	 */
	public XMLTreeNode getParameter(String sParamID, int nIndex)
	{
		if (sParamID == null)
			return null;

		XMLTreeNode parentNodeFromTemplate = getParameterNodeFromTemplate(sParamID);
		if(parentNodeFromTemplate == null)
			return null;

		parentNodeFromTemplate = (XMLTreeNode) parentNodeFromTemplate.getParent();
		if (parentNodeFromTemplate.getXMLTag().equals(DATA_NODE_TAG))
		{
			return getData().getNode(sParamID, nIndex);
		}

		parentNodeFromTemplate =  getData().getNode(parentNodeFromTemplate.getXMLTag(), nIndex);
		if (parentNodeFromTemplate == null)
			return null;

		return parentNodeFromTemplate.getChildNodeByTag(sParamID);
	}

	/**
	 * Used in validator. Gets node by path.
	 * @param sPath path, see XMLObject
	 * @return null if no such node found
	 */
	public XMLTreeNode getNodeByPath(String sPath)
	{
		return m_xmlData.getRootNode().getChildXmlNodeByPath(sPath);
	}

	/**
	 * Used in validator. Gets node by path.
	 * @param sPath path, see XMLObject
	 * @param nIndex the exact node (could be more than 1 if path returns more than one node)
	 * @return null if no such node found
	 */
	public XMLTreeNode getNodeByPath(String sPath, int nIndex)
	{
		return m_xmlData.getRootNode().getChildXmlNodeByPath(sPath, nIndex);
	}

	/**
	 * show contents of this XML
	 * @return String XML
	 */
	@Override
	public String toString()
	{
		String sNodeProcInstr = "";
		XMLTreeNode nodeProcInstr = getData().getRootNode().getChildNodeByType(XMLConsts.TYPE_PROCESSING_INSTRUCTION);
		if (nodeProcInstr == null)
		{
			nodeProcInstr = getTemplateProcInstructions();
			if (nodeProcInstr != null)
				sNodeProcInstr = nodeProcInstr.toString();
		}

		return (sNodeProcInstr + getData().toString(true));
	}

	/**
	 * show contents of
	 * do not add nodes to this XMLObject directly.
	 * @return XML with injected data
	 */
	public XMLObject getXMLObject()
	{
		return getData();
	}

	/**
	 * Adds new parameter into storage.
	 * Used in CValidator.
	 *
	 * @param sName
	 * @param sValue
	 * @return added parameter node
	 */
	public XMLTreeNode addParameter(String sName, String sValue)
	{

		return putParameterIntoXML(sName, sValue);
	}

	/**
	 * used in CValidator
	 * @param sName
	 * @param nIndex
	 * @param sValue
	 * @return node to which value has been stored.
	 */
	public XMLTreeNode addParameter(String sName, int nIndex, String sValue)
	{
		if(nIndex != 1)
			return putParameterIntoXML(sName + nIndex, sValue);

		return putParameterIntoXML(sName, sValue);
	}

	/**
	 * preload parameters storage with XML data.
	 *
	 * @param xmlData	<code>XMLObject</code> xml data for storage
	 */
	public void setData(XMLObject xmlData)
	{
		// check for empty data
		if(xmlData == null || xmlData.getRootNode() == null || xmlData.getRootNode().getChildNodeByTag(DATA_NODE_TAG) == null)
			return;

		// reset checkboxes
		int count = xmlData.getAttributesCount(ATTRIBUTE_CLEARANCE);
		for (int i=1; i<=count; i++)
		{
			XMLTreeNode checkboxNode = xmlData.getNodeByAttribute(ATTRIBUTE_CLEARANCE, i);
			checkboxNode.clearText();
		}

		xmlData.removeAttribute(CValidator.XA_VALID);

		m_xmlData = xmlData;
	}

	/**
	 * Returns list of nodes that match specified path
	 * @param sPathValue node path
	 * @return List of nodes or null if not found
	 */
	public List<XMLTreeNode> getNodesByPath(String sPathValue)
	{
		return m_xmlData.getRootNode().getChildNodesByPath(sPathValue);
	}
	
	/**
	 * @deprecated Use method {@link #getNodesByPath(String)} instead
	 */
	@Deprecated
	public Vector<XMLTreeNode> getNodesListByPath(String sPathValue)
	{
		return m_xmlData.getRootNode().getChildNodesListByPath(sPathValue);
	}

	/**
	 * Method can be called by some validator.
	 * It injects into XML Storage three values:
	 *
	 * @param	nTotalValid					number of valid parameters
	 * @param	nTotalInvalid				number of invalid parameters
	 * @param	nTotalInvalidRequired		number of invalid required parameters
	 * @param	cInvalidElements		 	collection of invalid elements IDs (like "edu_end_date#2")
	 */
	public void addValidationSummary(int nTotalValid, int nTotalInvalid, int nTotalInvalidRequired,
		Collection<String> cInvalidElements)
	{
		if (this.getParameter(TOTALS_PARAM_NAME) == null)
		{
			this.addParameter(TOTALS_PARAM_NAME, null);
		}

		setAttribute(TOTALS_PARAM_NAME, 1, XA_NUM_VALID, Integer.toString(nTotalValid));
		setAttribute(TOTALS_PARAM_NAME, 1, XA_NUM_INVALID, Integer.toString(nTotalInvalid));
		setAttribute(TOTALS_PARAM_NAME, 1, XA_NUM_INVALID_REQUIRED, Integer.toString(nTotalInvalidRequired));
		setAttribute(TOTALS_PARAM_NAME, 1, XA_INVALID_ELEMENTS, cInvalidElements.toString());
	}
}
