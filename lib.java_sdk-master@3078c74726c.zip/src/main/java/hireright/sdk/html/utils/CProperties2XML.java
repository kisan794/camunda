/*
 * @(#)$RCSfile: CProperties2XML.java,v $ $Revision: 1.9 $ $Date: 2009/12/18 07:13:49 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CProperties2XML.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Larin			2006-05-06	Created
 *	D.Belorunov		2006-12-20	toXMLTreeNode() methods added
 *	A.Solntsev		2009-02-11	Removed method main(): this code was moved to unit-test a long time ago
 */
package hireright.sdk.html.utils;

import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.parser.XMLTreeNodeParser;
import hireright.sdk.util.CProperties;

import java.util.Set;

/**
 * This class provides the toXML() static method for generating properties
 * XML string representation.
 * An XML format must be specified by version.
 * <p/>
 * For example, the following code generates properties XML string
 * with new naming conventions (Properties/Property):<br/>
 * <code>
 * String propertiesXML = CProperties2XML.
 * toXML(templatePage.m_Properties, CProperties2XML.VERSION_1_1);
 * </code>
 * 
 * @author Artem Larin
 * @version $Revision: 1.9 $ $Date: 2009/12/18 07:13:49 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CProperties2XML.java,v $
 */
public class CProperties2XML
{
	protected static final String CLASS_VERSION = "$Revision: 1.9 $ $Author: cvsroot $";
	
// ------------------------------ FIELDS ------------------------------

	/**
	 * Defines version 1.0 for properties (old XML naming convention,
	 * properties/property).
	 * Example:
	 * <pre>
	 * &lt;properties version="1.0">
	 * 	&lt;property name="id">1&lt;/property>
	 * 	&lt;property name="prop">value&lt;/property>
	 * &lt;/properties>
	 * </pre>
	 */
	public final static int VERSION_1_0 = 1;

	/**
	 * Defines version 1.1 for properties (new XML naming convention
	 * Properties/Property).
	 * Example:
	 * <pre>
	 * &lt;Properties version="1.1">
	 * 	&lt;Property name="id">1&lt;/Property>
	 * 	&lt;Property name="prop">value&lt;/Property>
	 * &lt;/Properties>
	 * </pre>
	 */
	public final static int VERSION_1_1 = 11;

// -------------------------- STATIC METHODS --------------------------

	/**
	 * Returns XML representation (String) of specified properties object.
	 * @param properties CProperties instance to be converted into XML
	 * @param nVersion	 version which defines XML format
	 * @return XML string representation or null
	 *         if no properties object was specified
	 * @see #VERSION_1_0
	 * @see #VERSION_1_1
	 */
	public static String toXML(CProperties properties, int nVersion)
	{
		/**
		 * Check for null.
		 * If properties is null, throw exception
		 * (old CProperties.toXML() method had the same behaviour).
		 */
		if (properties == null)
		{
			throw new IllegalArgumentException("Properties is null");
		}

		/**
		 * Generate XML depending on version number.
		 */
		String szResult;
		switch (nVersion)
		{
			case VERSION_1_0:
				szResult = toXML(properties, "properties", "property", "name");
				break;
			case VERSION_1_1:
				szResult = toXML(properties, "Properties", "Property", "name");
				break;
			default:
				throw new IllegalArgumentException("Unknown version");
		}
		return szResult;
	}

	/**
	 * Returns XML representation of CProperties object, alphabetically sorted.
	 * @param properties				 CProperties instance to make XML representation
	 * @param sPropertiesTagName a tag name for root tag "properties"
	 * @param sPropertyTagName	 a tag name for each property
	 * @param sNameAttributeName an attribute name for property
	 * @return String XML or null if no properties defined
	 *         <properties>
	 *         <property name="id">1</property>
	 *         ......
	 *         </properties>
	 */
	private static String toXML(CProperties properties, String sPropertiesTagName,
					String sPropertyTagName, String sNameAttributeName)
	{
		/**
		 * Check arguments for validity.
		 */
		if (properties == null)
		{
			throw new IllegalArgumentException("Null properties object");
		}
		if (sPropertiesTagName == null)
		{
			throw new IllegalArgumentException("Null properties tag name");
		}
		if (sPropertyTagName == null)
		{
			throw new IllegalArgumentException("Null property tag name");
		}
		if (sNameAttributeName == null)
		{
			throw new IllegalArgumentException("Null name attribute name");
		}

		/**
		 * Assemble XML string with properties.
		 */
		StringBuilder sb = new StringBuilder();

		Set<String> keys = properties.keys();
		if (!keys.isEmpty())
		{
			sb.append("<").append(sPropertiesTagName).append(">");
			for (String szKey : keys)
			{
				String szValue = properties.getProperty(szKey);

				sb.append("<").append(sPropertyTagName).append(" ")
								.append(sNameAttributeName).append("=\"").append(szKey)
								.append("\">");
				sb.append(szValue);
				sb.append("</").append(sPropertyTagName).append(">");
			}
			sb.append("</").append(sPropertiesTagName).append(">");
		}

		return sb.toString();
	}

	/**
	 * Returns XML representation (XMLTreeNode) of specified properties object.
	 * @param properties CProperties instance to be converted into XML
	 * @param nVersion	 version which defines XML format
	 * @return XML XMLTreeNode representation or null
	 *         if no properties object was specified
	 * @see #VERSION_1_0
	 * @see #VERSION_1_1
	 */
	public static XMLTreeNode toXMLTreeNode(CProperties properties, int nVersion)
	{
		if (properties == null)
			return null;

		/**
		 * Generate XML depending on version number.
		 */
		XMLTreeNode result;
		switch (nVersion)
		{
			case VERSION_1_0:
				result = toXMLTreeNode(properties, "properties", "property", "name");
				break;
			case VERSION_1_1:
				result = toXMLTreeNode(properties, "Properties", "Property", "name");
				break;
			default:
				throw new IllegalArgumentException("Unknown version");
		}

		return result;
	}

	/**
	 * Returns XML representation of CProperties object, alphabetically sorted.
	 * @param properties				 CProperties instance to make XML representation
	 * @param sPropertiesTagName a tag name for root tag "properties"
	 * @param sPropertyTagName	 a tag name for each property
	 * @param sNameAttributeName an attribute name for property
	 * @return XMLTreeNode or null if no properties defined
	 *         <properties>
	 *         <property name="id">1</property>
	 *         ......
	 *         </properties>
	 */
	private static XMLTreeNode toXMLTreeNode(CProperties properties, String sPropertiesTagName,
					String sPropertyTagName, String sNameAttributeName)
	{
		/**
		 * Check arguments for validity.
		 */
		if (properties == null)
		{
			throw new IllegalArgumentException("Null properties object");
		}
		if (sPropertiesTagName == null)
		{
			throw new IllegalArgumentException("Null properties tag name");
		}
		if (sPropertyTagName == null)
		{
			throw new IllegalArgumentException("Null property tag name");
		}
		if (sNameAttributeName == null)
		{
			throw new IllegalArgumentException("Null name attribute name");
		}

		/**
		 * Assemble XML with properties.
		 */
		XMLTreeNode propertiesNode = XMLTreeNodeParser.getNodeForType( XMLConsts.TYPE_NODE, sPropertiesTagName, null );

		for ( String szKey : properties.keys() )
		{
			String szValue = properties.getProperty( szKey );

			XMLTreeNode propertyNode = XMLTreeNodeParser.getNodeForType( XMLConsts.TYPE_NODE, sPropertyTagName, szValue );
			propertyNode.addAttribNode( sNameAttributeName, szKey );
			propertiesNode.addChildNodeTail( propertyNode );
		}

		return propertiesNode;
	}
}
