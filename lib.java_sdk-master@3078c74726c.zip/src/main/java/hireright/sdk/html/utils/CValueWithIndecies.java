/*
 * @(#)$RCSfile: CValueWithIndecies.java,v $ $Revision: 1.6 $ $Date: 2008/09/05 10:15:03 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CValueWithIndecies.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	2004-10-14	A.Solntsev		created
 * 	2007-01-09	A.Solntsev		implements Serializable
 */
package hireright.sdk.html.utils;

import java.io.Serializable;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.6 $, $Date: 2008/09/05 10:15:03 $, $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CValueWithIndecies.java,v $
 */
public class CValueWithIndecies implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: asolntsev $";

	private final int[] m_anIndecies;
	private final String m_sValue;
	
	public CValueWithIndecies(String sIndexedValue)
	{
		int[] indicies = new int[sIndexedValue.length()];
		int i = 0;
		
		String szParameterName = sIndexedValue;
		CValueWithIndex indexValue;
		do
		{
			indexValue = new CValueWithIndex(szParameterName);
			if (!indexValue.hasIndex())
				break;
			
			indicies[i++] = indexValue.getIndex();
			szParameterName = indexValue.getValue();
			while (szParameterName.endsWith("_"))
				szParameterName = szParameterName.substring(0, szParameterName.length()-1);
		} while (true);
		

		m_sValue = szParameterName;

		m_anIndecies = new int[i];
		System.arraycopy(indicies, 0, m_anIndecies, 0, i);
	}
	
	public int[] getIndecies()
	{
		return m_anIndecies;
	}
	
	public String getValue()
	{
		return m_sValue;
	}	
}