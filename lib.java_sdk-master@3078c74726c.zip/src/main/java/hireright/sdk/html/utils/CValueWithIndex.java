/*
 * @(#)$RCSfile: CValueWithIndex.java,v $ $Revision: 1.7 $ $Date: 2008/09/05 10:11:44 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CValueWithIndex.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2002-01-14	S.Ignatov		created
 * 	2004-10-13	A.Solntsev		Added method public boolean hasIndex()
 * 	2007-01-09	A.Solntsev		implements Serializable
 */
package hireright.sdk.html.utils;
import java.io.Serializable;

/**
 * @author S.Ignatov
 * @version $Revision: 1.7 $, $Date: 2008/09/05 10:11:44 $, $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CValueWithIndex.java,v $
 */
public class CValueWithIndex implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: asolntsev $";
	
	protected static String NUMBERS = "0123456789";

	protected int m_nIndex;
	protected boolean m_bHasIndex;
	protected String m_sValue;
	
	public CValueWithIndex(String sIndexedValue)
	{
		m_nIndex = 1;		// This is error. If there is no index, use method hasIndex()
		m_bHasIndex = false;
		m_sValue = "";
		
		int k = sIndexedValue.length() - 1;
		while (k>=0 && NUMBERS.indexOf(sIndexedValue.charAt(k)) != -1)
			k--;
		
		m_sValue = sIndexedValue.substring(0, k + 1);

		if(k + 1 != sIndexedValue.length())
		{
			m_nIndex = Integer.parseInt(sIndexedValue.substring(k + 1));
			m_bHasIndex = true;
		}
	}
	
	public int getIndex()
	{
		return m_nIndex;
	}
	
	public String getValue()
	{
		return m_sValue;
	}	
	
	public boolean hasIndex()
	{
		return m_bHasIndex;
	}
}