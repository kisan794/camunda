/*
 * @(#)$RCSfile: IHttpParametersStorage.java,v $ $Revision: 1.11 $ $Date: 2009/12/18 07:14:10 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/IHttpParametersStorage.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	2004-09-07	A.Solntsev		Class CHttpParametersStorage is completely rewritten.
 *	2005-01-25	A.Solntsev		Removed "throws CXMLTemplateException".
 *	2005-03-10	A.Solntsev		putParameter(String, String) throws IllegalArgumentException
 * 	2007-03-xx	A.Solntsev		addValidationSummary(): Added list of invalid elements IDs (like "edu_end_date#2")
 *	2007-10-01	A.Lipatov			type of parameter "aInvalidElements" for method addValidationSummary()
 *														was changed from List to Collection.
 *	2008-08-26	A.Solntsev		Usign generics
 *	2009-12-09	A.Solntsev		Vector -> List
 */
package hireright.sdk.html.utils;

import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLTreeNode;

import java.util.Collection;
import java.util.List;
import java.util.Vector;

/**
 * This interface implements some abstract storage, which can store Http
 * parameters (which came from HttpRequest) to internal storage, usually XML.
 *
 * For example, http parameters:
 * 			first_name=John
 *      last_name=Smith
 *      dob=1966/12/01
 * Resulting XML Storage could be:
 * 			<person>
 *      	<FirstName>John</FirstName>
 *        <LastName>Smith</LastName>
 *        <dob>1966/12/01</dob>
 *      </person>
 *
 *
 * Known implementations:
 * 		1. hireright.sdk.html.utils.CHttpParametersStorage	(2002 year)
 *    2. hireright.sdk.html.utils.CHttpParametersSet			(2004 year)
 *
 *
 * @author	Andrei Solntsev
 * @version $Revision: 1.11 $ $Date: 2009/12/18 07:14:10 $ $Author: cvsroot $
 */
public interface IHttpParametersStorage
{
	/**
	 * Method finds in XML Storage a place for parameter sParameterName (formally,
	 * one of xml elements with name <sParameterName>, depending on index) and
	 * assigns given value to it.
	 *
	 * @param sParameterName	for example, "personal_first_name" or "edu_name2".
	 * @param sParameterValue	for example, "John"
	 *
	 * @return false	If failed to find a place for given element. Usually it
	 * 		means that given eleent presents on form but doesn't present in xml.
	 *
	 * @throws IllegalArgumentException	if sParameterName is null or empty
	 */
	public boolean putParameter(String sParameterName, String sParameterValue)
		throws IllegalArgumentException;

	/**
	 * COMMENT ME
	 * @param sPath
	 * @return COMMENT ME
	 */
	public XMLTreeNode getNodeByPath(String sPath);

	/**
	 * COMMENT ME
	 * @param sPath
	 * @param nIndex
	 * @return COMMENT ME
	 */
	public XMLTreeNode getNodeByPath(String sPath, int nIndex);

	/**
	 * COMMENT ME
	 * @param sParamID
	 * @return COMMENT ME
	 */
	public XMLTreeNode getParameter(String sParamID);

	/**
	 * COMMENT ME
	 * @param sPathValue
	 * @return COMMENT ME
	 */
	public List<XMLTreeNode> getNodesByPath(String sPathValue);

	/**
	 * @deprecated Use method {@link #getNodesByPath(String)} instead
	 * @param sPathValue
	 * @return java.lang.Vector
	 */
	@Deprecated
	public Vector<XMLTreeNode> getNodesListByPath(String sPathValue);

	/**
	 * COMMENT ME
	 * @return COMMENT ME
	 */
	public XMLObject getData();


	/**
	 * Following methods are called by CValidator.
	 * Javadoc describes how CVAlidator uses them.
	 */

	/**
	 * Method returns total number of XML Elements with tag = sXMLTagName
	 * @param sXMLTagName	or example, "personal_first_name" or "edu_city"
	 * @return Number of elements with given tag in the whole XML Document.
	 */
	//	TODO	Rename to getXMLElementsCount
	public int getParameterCount(String sXMLTagName);


	/**
	 * IF XML has 3 elements "personal_othername", then this method returns i'th
	 * of them.
	 * @param sXMLTagName		XML Tag name
	 * @param nIndex			between 1 and getParameterCount(sXMLTagName);
	 * @return COMMENT ME
	 */
	//	TODO	Remove this method! this is unsafe.
	//				Use iterator instead.
	public XMLTreeNode getParameter(String sXMLTagName, int nIndex);

	/**
	 * Method can be called by some validator.
	 * It injects into XML Storage three values:
	 *
	 * @param	nTotalValid					number of valid parameters
	 * @param	nTotalInvalid				number of invalid parameters
	 * @param	nTotalInvalidRequired		number of invalid required parameters
	 * @param	cInvalidElements		 	collection of invalid elements IDs (like "edu_end_date#2")
	 */
	public void addValidationSummary(int nTotalValid, int nTotalInvalid, int nTotalInvalidRequired,
		Collection<String> cInvalidElements);
}
