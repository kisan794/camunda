/*
 * @(#)$RCSfile: XMLUtils.java,v $ $Revision: 1.22 $ $Date: 2011/11/18 10:22:16 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/XMLUtils.java,v $
 *
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	2001-11-14	S.Ignatov			created
 * 	2003-12-11	D.Bogdel			added utility function formatNode()
 * 	2004-01-20	A.Solntsev		Fixed old bug with reading from URL. Code is formatted according to last standards.
 * 	2006-06-19	A.Solntsev		Fixed performance issue in methods replace(), encode()/decode().
 * 	2006-06-19	A.Solntsev		Removed method loadData()
 * 	2006-11-06	A.Solntsev		Don't decode &#160; - like characters: it was decoed to &amp;#160;
 * 	2006-12-15	P.Bushuk			StringIndexOutOfBoundsException fix in method decodeTextData(String sValue, int specific).
 * 	2007-06-13	A.Larin				Added the method getDataNode()
 *	2007-11-20	A.Solntsev		Using new class XMLOutputStyle instead of (int specific)
 *	2010-04-17	Y.Shneykin		Added methods for node cloning and downside clearing of text nodes/attributes.
 *	2011-09-28	E.Kapustin		Fixed processing for ampersand on end of string in decodeTextData().
 *	2011-11-08	K.Ovchinnikov	Added multiline mode for ampersand processing in decodeTextData().
 *	2017-11-27	T.Prikk			Added childNodeValue(node, childNodeTagName, defaultValue)
 */
package hireright.sdk.html.utils;

import java.io.Serializable;
import java.util.regex.Pattern;

import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.parser.XMLOutputStyle;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.util.CStringUtils;

/**
 * Some functions for XMLTree Nodes and Attribute Nodes data manipulations.
 *
 * @author Sergei Ignatov
 * @since 2001-11-14
 * @version $Revision: 1.22 $ $Date: 2011/11/18 10:22:16 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/XMLUtils.java,v $
 */
public class XMLUtils implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.22 $ $Author: cvsroot $";
	
	/**
	 * Defines a name of the data node root tag.
	 */
	private static final String XML_DATA_NODE = "data_node";
	
	/* Constants */

	protected static final String NUMBERS = "0123456789";

	protected static final String AMPNBSP = "&amp;nbsp;";

	protected static final String FORMAT_DELIMITER 			= ": ";
	protected static final String FORMAT_NEWLINE 				= "\r\n";
	protected static final String FORMAT_DEFAULT_VALUE 	= "";
	
	/**
	 * Attribute
	 */
	public static String ATTRIBUTE_KEEP_VALUE = "keep_value";
	
	/**
	 * Attribute 'yes' value.
	 */
	public static final String ATTRIBUTE_YES_VALUE = "yes";
	
	/**
	 * Clone attribute name.
	 */
	public static String ATTRIBUTE_CLONE = "clone";

	/**
	 * Public constants for output type.
	 * use them before calling method XHTMLInjector.toString()
	 */
	public static final int SPECIFIC_DEFAULT = 0;
	public static final int SPECIFIC_WEB_BROW = 1;

	/**
	 * Pattern for XML entities.
	 */
	private static final Pattern XML_ENTITIES_PATTERN = 
		Pattern.compile("^(&#[0-9]{2,4};|&nbsp;|&amp;|&lt;|&gt;|&apos;|&quot;).*", Pattern.DOTALL);

	/**
	 * not tested
	 *
	 * The same as XMLTreeNode.nodeValue(XMLTreeNode node, String szDefault)
	 * Method returns value of given XML Node.
	 *
	 * @param	szDefault	this value is returned if XML Node is null or has no value.
	 */
	public static String nodeValue(XMLTreeNode node, String szDefault)
	{
		return XMLTreeNode.nodeValue(node, szDefault);
	}

	/**
	 * Method returns value of given XML Node's child node.
	 *
	 * @param	szChildNodeTag	this is the tag name for the child of the node
	 * @param	szDefault		this value is returned if XML Node is null or has no value.
	 */
	public static String childNodeValue(XMLTreeNode node, String szChildNodeTag, String szDefault)
	{
		if (node == null)
			return szDefault;
		return XMLTreeNode.nodeValue(node.getChildNodeByTag(szChildNodeTag), szDefault);
	}

	/**
	 *	replace inclusions of string with another string
	 *	@return String szSource, in which all substrings szParam are substituted by string szReplacement.
	 *
	 *	@param	szParam					if null, szSource is returned.
	 *	@param	szReplacement		if null, empty string is returned.
	 */
	public static String replace(String szSource, String szParam, String szReplacement)
	{
		if (szParam == null || szSource == null)
			return szSource;

		if (szReplacement == null)
			szReplacement = "";

		return CStringUtils.replace(szSource, szParam, szReplacement);
	}

	public static void printReplace(String szSource, String szParam, String szReplacement, java.io.PrintWriter out)
	{
		printReplace(szSource, szParam, szReplacement, out, Integer.MAX_VALUE);
	}

	public static void printReplace(String szSource, String szParam, String szReplacement, java.io.PrintWriter out, int nCount)
	{
		if(szParam == null)
			out.println(szSource);

		if(szReplacement == null)
			szReplacement = "";

		int index = szSource.indexOf(szParam);
		int prevIndex = 0;
		while (index != -1)
		{
			out.print(szSource.substring(0, index));
			out.print(szReplacement);
			index += szParam.length();
			prevIndex = index;
			index = szSource.indexOf(szParam, index);
			nCount--;
			if (nCount <= 0)
				index = -1;
		}

		out.print(szSource.substring(prevIndex));
	}

	/**
	 * Replace strings &lt;, &gt;, &amp;, &apos;, &quot; to <, >, &, ', " chars.
	 */
	public static String encodeTextData(String sValue)
	{
		if (sValue == null || sValue.indexOf('&') == -1)
			return sValue;

		StringBuffer sbOutput = new StringBuffer();
		StringBuffer sbBuffer = new StringBuffer();

		boolean waitForBuffer = false;
		char c;

		for (int nCounter = 0; nCounter < sValue.length(); nCounter++)
		{
			c = sValue.charAt(nCounter);
			switch(c)
			{
				case '&':
					waitForBuffer = true;
				default:
					if (waitForBuffer)
						sbBuffer.append(c);
					else
						sbOutput.append(c);
					break;
			}

			if (waitForBuffer)
			{
				if (sbBuffer.length() == 4)
				{
					String sBuffer = sbBuffer.toString();

					if ( sBuffer.equals("&lt;"))
					{
						sbOutput.append('<');
						sbBuffer.setLength(0);
						waitForBuffer = false;
					}
					else if (sBuffer.equals("&gt;"))
					{
						sbOutput.append('>');
						sbBuffer.setLength(0);
						waitForBuffer = false;
					}
				}
				else if (sbBuffer.length() == 5)
				{
					String sBuffer = sbBuffer.toString();

					if (sBuffer.compareTo("&amp;") == 0)
					{
						sbOutput.append('&');
						sbBuffer.setLength(0);
						waitForBuffer = false;
					}
				}
				else if (sbBuffer.length() == 6)
				{
					String sBuffer = sbBuffer.toString();

					if (sBuffer.compareTo("&apos;") == 0)
					{
						sbOutput.append('\'');
						sbBuffer.setLength(0);
						waitForBuffer = false;
					}
					else if (sBuffer.compareTo("&quot;") == 0)
					{
						sbOutput.append('"');
						sbBuffer.setLength(0);
						waitForBuffer = false;
					}
				}
				else if (sbBuffer.length() > 5)
				{
					sbOutput.append(sbBuffer);
					sbBuffer.setLength(0);
					waitForBuffer = false;
				}
			}
		}

		if (sbBuffer.length() > 0)
			sbOutput.append(sbBuffer);

		sbBuffer.setLength(0);
		sbBuffer = null;

		try
		{
			return sbOutput.toString();
		}
		finally
		{
			// Help Garbage Collector
			sbOutput.setLength(0);
			sbOutput = null;
		}
	}

	/**
	 * Replace <, >, &, ', " chars to &lt;, &gt;, &amp;, &apos;, &quot; strings.
	 */
	public static String decodeTextData(String sValue)
	{
		return decodeTextData(sValue, SPECIFIC_DEFAULT);
	}

	public static String decodeTextData(String sValue, XMLOutputStyle style)
	{
		return decodeTextData(sValue, style.getCode());
	}
	
	/**
	 * FIXME: redesign this method
	 * @param sValue
	 * @param specific
	 * @return
	 */
	public static String decodeTextData(String sValue, int specific)
	{
 		if (sValue == null)
			return null;

		StringBuffer sOutput = new StringBuffer();
		StringBuffer sTempOutput = new StringBuffer();
		int index = 0;
		char c;

		for (int nCounter = 0; nCounter < sValue.length(); nCounter++)
		{
			c = sValue.charAt(nCounter);
			if (sTempOutput.length() > 0)
			{
				sTempOutput.append(c);
				// check for nbsp, web browser specific only mode
				String sTempOutString = sTempOutput.toString();
				if (AMPNBSP.equals(sTempOutString))
				{
					sOutput.append("&nbsp;");
					sTempOutput.setLength(0);
				}
				else
				{
					if (!AMPNBSP.startsWith(sTempOutString))
					{ // not &nbsp;
						sOutput.append("&amp;");
						sTempOutput.setLength(0);
						nCounter -= index;
					}
					else
					{ //probably &nbsp; continue
						index++;
					}
				}
			}
			else
			{
				switch(c)
				{
					case '<':
						sOutput.append("&lt;");
						break;
					case '>':
						sOutput.append("&gt;");
						break;
					case '&':
						switch (specific)
						{
							case SPECIFIC_WEB_BROW:
								String subStr = sValue.substring(nCounter);
								if (!XML_ENTITIES_PATTERN.matcher(subStr).matches())
								{
									sTempOutput.append("&amp;");
									index = 1;
								}
								else
								{
									sOutput.append(c);
								}
								break;
							default:
								sOutput.append("&amp;");
						}
						break;
					case '\'':
						switch (specific)
						{
							case SPECIFIC_WEB_BROW:
								sOutput.append('\'');
								break;
							default:
								sOutput.append("&apos;");
						}
						break;
					case '"':
						sOutput.append("&quot;");
						break;
					default:
						sOutput.append(c);
						break;
				}
			}
		}

		if (sTempOutput.length() > 0)
			sOutput.append(sTempOutput.toString());

		try
		{
			sTempOutput.setLength(0);
			sTempOutput = null;

			return sOutput.toString();
		}
		finally
		{
			sOutput.setLength(0);
			sOutput = null;
		}
	}

	/**
	 * formatting child node value defined by tag name (szTag)
	 * resulting string looks like:
	 *		[szFieldName]: [nodeValue]\n
	 */

	public static String formatNode(XMLTreeNode node, String szTag, String szFieldName)
	{
		XMLTreeNode nodeResult;
		String szData;
		String szFormattedData = szFieldName + FORMAT_DELIMITER;
		if ((nodeResult = node.getChildNodeByTag(szTag, 1)) != null)
		{
			szData = XMLUtils.nodeValue(nodeResult, FORMAT_DEFAULT_VALUE);
			szFormattedData += szData;
		}
		szFormattedData += FORMAT_NEWLINE;
		return szFormattedData;
	}

	/**
	 * Returns tree node of data_node.
	 * @param xmlForm page XML object
	 * @return tree node of data_node
	 */
	public static XMLTreeNode getDataNode(XMLObject xmlForm)
	{
		return (XMLTreeNode)xmlForm.getRootNode().getChildNodeByPath(XML_DATA_NODE);
	}
	
	/**
	 * Copy all attributes from nodeFrom to nodeTo.
	 *
	 * @param nodeFrom
	 * @param nodeTo
	 */
	public static void copyAttributes(XMLTreeNode nodeFrom, XMLTreeNode nodeTo)
	{
		XMLTreeNode child = (XMLTreeNode) nodeFrom.firstChildNode();
		while (child != null)
		{
			if (XMLConsts.TYPE_ATTRIBUTE == child.getType())
				nodeTo.addAttribNode(child.getXMLTag(), child.getText());
			child = child.getNextXmlNode();
		}
	}

	/**
	 * Clone section and return cloned node.
	 * @param clonableNode the cloning node.
	 * @return the cloned node.
	 */
	public static XMLTreeNode cloneNode(XMLTreeNode clonableNode)
	{
		XMLTreeNode clonedNode = clonableNode.dublicate(false);

		// Clean up nodes and attributes
		cleanUpTree(clonedNode);
		clonedNode.removeAttribNode(ATTRIBUTE_CLONE);
		return clonedNode;
	}
	

	/**
	 * Method recursively cleans up xml tree
	 *
	 * It sets empty node text and CDATA
	 * @param parentNode	<code>XMLTreeNode</code> to clean
	 */
	public static void cleanUpTree(XMLTreeNode parentNode)
	{
		if (parentNode != null)
		{
			// Should we keep the value?
			String keepAttribute = parentNode.getAttribText(ATTRIBUTE_KEEP_VALUE);
			if (keepAttribute == null || !keepAttribute.equals(ATTRIBUTE_YES_VALUE))
			{
				//	 Clear node value
				parentNode.clearText();
			}

			XMLTreeNode childNode = (XMLTreeNode)parentNode.firstChildNode();
			while (childNode != null)
			{
				switch (childNode.getType())
				{
					case XMLConsts.TYPE_ATTRIBUTE:
						break;

					case XMLConsts.TYPE_CDATA:
					case XMLConsts.TYPE_TEXT:
						break;

					default:
						cleanUpTree(childNode);
				}
				childNode = childNode.getNextXmlNode();
			}
		}
	}
	
}