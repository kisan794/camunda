/*
 * @(#)$RCSfile: CNodeWalker.java,v $ $Revision: 1.5 $ $Date: 2008/09/05 10:58:07 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CNodeWalker.java,v $
 *
 * Copyright 2001-2003 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   S.Ignatov?			2003-xx-yy	Created
 */
package hireright.sdk.html.utils;

import java.io.Serializable;

import hireright.sdk.html.parser.*;

/**
 * @author Sergei Ignatov
 * @version $Revision: 1.5 $, $Date: 2008/09/05 10:58:07 $, $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CNodeWalker.java,v $
 */
public class CNodeWalker implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: asolntsev $";
	
	private final XMLTreeNode m_node;
	
	public final static int ACTION_ADD_ATTRIBUTE = 0;
	public final static int ACTION_ADD_TEXT = 1;
	public final static int ACTION_CUT_CDATA = 2;
	public final static int LEVEL_LAST = -2;
	
	public CNodeWalker(XMLTreeNode node)
	{
		m_node = node;
	}
	
	public void doIt(int nAction, int nLevel, String sAtrName, String sAtrValue, String sParam1, String sParam2, boolean doAppend)
	{
		if(m_node == null || nLevel == 0)
			return;
		
		boolean allowApply;
		XMLTreeNode tempNode;
		String sAppendToParam = "";
		String sResult = "";
			
		XMLTreeNode child = (XMLTreeNode) m_node.firstChildNode();
		
		while(child != null)
		{
			if(child.getType() == XMLConsts.TYPE_NODE)
			{
				allowApply = false;
				
				// apply to all nodes
				if(sAtrValue == null)
					allowApply = true;
				else // apply only for nodes with attributes
				{	
					tempNode = child.getAttribNode(sAtrName);
					
					if(tempNode != null && tempNode.getText().equals(sAtrValue))
						allowApply = true;
				}						
				
				// apply only for last nodes
				if(allowApply && nLevel == LEVEL_LAST)
				{
					tempNode = child.getChildNodeByType(XMLConsts.TYPE_NODE);
					if(tempNode != null)
						allowApply = false;
				}
				
				if(allowApply)
				{
					switch(nAction)
					{
						case ACTION_ADD_ATTRIBUTE:
							sResult = sParam2;
							if(doAppend)
							{
								sAppendToParam = child.getAttribText(sParam1);
								if(sAppendToParam != null)
									sResult = sAppendToParam + sParam2;
							}
							child.addAttribNode(sParam1, sResult);
							break;
						case ACTION_ADD_TEXT:
							sResult = sParam1;
							if(doAppend)
							{
								sAppendToParam = child.getText(XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT);
								if(sAppendToParam != null)
									sResult = sAppendToParam + sParam1;
							}						
							child.setText(sResult, XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT, XMLConsts.TYPE_TEXT);
							break;
						case ACTION_CUT_CDATA:
							tempNode = child.getChildNodeByType(XMLConsts.TYPE_CDATA);
							if(tempNode != null && tempNode.getType() == XMLConsts.TYPE_CDATA)
							{
								XMLTreeNode newTextNode = XMLTreeNodeParser.getNodeForType(XMLConsts.TYPE_TEXT);
								newTextNode.setXMLTag(tempNode.getXMLTag());
								child.removeChild(tempNode);
								child.addChildNodeTail(newTextNode);
							}
							break;							
					}
				}
				
				CNodeWalker nodeWalk = new CNodeWalker(child);
				nodeWalk.doIt(nAction, nLevel-1, sAtrName, sAtrValue, sParam1, sParam2, doAppend);
				nodeWalk = null;
			}
			
			child = child.getNextXmlNode();
		}
	}
}