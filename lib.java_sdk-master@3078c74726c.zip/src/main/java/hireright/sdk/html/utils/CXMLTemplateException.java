/*
 * @(#)$RCSfile: CXMLTemplateException.java,v $ $Revision: 1.6 $ $Date: 2008/09/05 10:07:51 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CXMLTemplateException.java,v $
 *
 * Copyright 2001-2005 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * <pre>
 * History:
 *  2004-09-xx 	A.Solntsev		created
 *	2005-01-18	A.Solntsev		Method toString(true) is used.
 *  2005-01-25	A.Solntsev		Added method getErrorParameters().
 * </pre>
 */
package hireright.sdk.html.utils;
import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.util.CProperties;

/**
 * Exception is thrown when XML Template has incomplete list of xml elements,
 * or unknown element has came from Application Form.
 * 
 * @author  Andrei Solntsev
 * @version $Revision: 1.6 $ $Date: 2008/09/05 10:07:51 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CXMLTemplateException.java,v $
 */
public class CXMLTemplateException extends RuntimeException 
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: asolntsev $";
	
	private String m_szData;
	private final CProperties	m_parameters;
  
  public CXMLTemplateException()
  {
    this(null, null, null);
  }

  public CXMLTemplateException(String szMessage)
  {
    this(szMessage, null, null);
  }

  public CXMLTemplateException(String szMessage, CProperties parameters, XMLObject xmlData)
  {
    super(szMessage);
		m_parameters = parameters;
    if (xmlData != null)
    {
    	try
    	{
    		m_szData = xmlData.toString(true);
    	}
    	catch (Exception e)
    	{
    		m_szData = e.getMessage();
    	}
    }
  }
  
  public String getData()
  {
    return m_szData;
  }   

  public CProperties getErrorParameters()
  {
    return m_parameters;
  }   
}