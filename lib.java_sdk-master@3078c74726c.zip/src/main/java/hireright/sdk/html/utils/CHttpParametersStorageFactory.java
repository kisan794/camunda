/*
 * @(#)$RCSfile: CHttpParametersStorageFactory.java,v $ $Revision: 1.5 $ $Date: 2013/04/26 08:31:07 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CHttpParametersStorageFactory.java,v $
 *
 * Copyright 2001-2004 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  2004-11-26		A.Solntsev		created.
 *  2013-04-01		K.Ovchinnikov	added factory method for complemented storage
 */
package hireright.sdk.html.utils;

import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.utils.CHttpParametersSet;
import hireright.sdk.html.utils.CHttpParametersStorage;

/**
 * Class implementing logic of choosing IHttpParametersStorage
 * depending on XML version.
 *
 * @see	getStorage(XMLObject)
 * 
 * @author  Andrei Solntsev
 * @version $Revision: 1.5 $, $Date: 2013/04/26 08:31:07 $, $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CHttpParametersStorageFactory.java,v $
 */
public class CHttpParametersStorageFactory
{
	public static final String DATA_NODE_TAG = "data_node";
	public static final String ATTRIBUTE_XML_VERSION = "version";
	
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";

  /**
   * If XML has no version attribute, old class CHttpParametersStorage is used.
   * If XML has version attribute, the new class CHttpParametersSet is used.
   * They both implement interface IHttpParametersStorage
   * 
   * @param xmlStorage  XML Object to store HttpParameters got form Web Form.
   * @return instance of class implementing interface IHttpParametersStorage
   * 
   * @see hireright.sdk.html.utils.IHttpParametersStorage
   * @see hireright.sdk.html.utils.CHttpParametersStorage
   * @see hireright.sdk.html.utils.CHttpParametersSet
   */
  public static IHttpParametersStorage getStorage(XMLObject xmlStorage)
  {
    //String szTemp = pageData.toString();  // debug
		String szXMLVersion = xmlStorage.getNode(DATA_NODE_TAG).
                              getAttribText(ATTRIBUTE_XML_VERSION);
    
    if (szXMLVersion == null)
    {
      // Old class. It's used for old XML's (before online_application_v1-5)
      return new CHttpParametersStorage(xmlStorage);
    }
    else
    {
      // The new class. It's used for newer XMLs (that contain all XML Elements).
      // Those XML's have attribute "version" >= 2.0
      return new CHttpParametersSet(xmlStorage);
    }
  }
  
  /**
   * Create storage complemented with auxiliary storage   
   */
  public static IHttpParametersStorage getStorage(XMLObject xml, XMLObject complementaryXml)
  {
	  if(complementaryXml == null)
	  {
		  return getStorage(xml);
	  }
	  return new CComplementedHttpParametersSet(xml, complementaryXml);
  }
  
}