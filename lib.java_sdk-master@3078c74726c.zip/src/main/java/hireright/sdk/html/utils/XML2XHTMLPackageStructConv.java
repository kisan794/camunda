/*
 * @(#)$RCSfile: XML2XHTMLPackageStructConv.java,v $ $Revision: 1.6 $ $Date: 2009/02/20 10:25:44 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/XML2XHTMLPackageStructConv.java,v $
 *
 * Copyright 2001-2005 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	 S.Ignatov?		2003-xx-yy	Some old legacy code
 */
package hireright.sdk.html.utils;

/**
 * last changed 
 */
public class XML2XHTMLPackageStructConv
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	private hireright.sdk.xml.parser.XMLTreeNode m_treeNodeFromXMLPack;
	private hireright.sdk.html.parser.XMLTreeNode m_treeNodeFromXHTMLPack;
	
	public static hireright.sdk.html.parser.XMLTreeNode doConversion(hireright.sdk.xml.parser.XMLTreeNode xmlPackNode)
	{
		XML2XHTMLPackageStructConv converter = new XML2XHTMLPackageStructConv();
		return converter.convert(xmlPackNode);
	}
	
	public XML2XHTMLPackageStructConv()
	{
	}
	
	public XML2XHTMLPackageStructConv(hireright.sdk.xml.parser.XMLTreeNode xmlNode)
	{
		m_treeNodeFromXHTMLPack = convert(xmlNode);
	}
		
	public final hireright.sdk.html.parser.XMLTreeNode convert(hireright.sdk.xml.parser.XMLTreeNode xmlNode)
	{
		m_treeNodeFromXMLPack = xmlNode;
		m_treeNodeFromXHTMLPack = convertInt(m_treeNodeFromXMLPack);
		return m_treeNodeFromXHTMLPack;
	}
	
	private hireright.sdk.html.parser.XMLTreeNode convertInt(hireright.sdk.xml.parser.XMLTreeNode xmlNode)
	{
		// result node for conversion
		hireright.sdk.html.parser.XMLTreeNode resultNode = null;
		
		// convert this node
		if(m_treeNodeFromXMLPack.getParent() != null)
		{	// not root
			switch(m_treeNodeFromXMLPack.getNodeType())
			{
				// normal nodes
				case hireright.sdk.xml.parser.XMLOpt.TEXT_NONE:
					if(m_treeNodeFromXMLPack.isMetaData())
						// processing instructions
						resultNode = hireright.sdk.html.parser.XMLTreeNodeParser.getNodeForType
							(hireright.sdk.html.parser.XMLConsts.TYPE_PROCESSING_INSTRUCTION);
					else
						// simple nodes
						resultNode = hireright.sdk.html.parser.XMLTreeNodeParser.getNodeForType
							(hireright.sdk.html.parser.XMLConsts.TYPE_NODE);				
					
					resultNode.setXMLTag(m_treeNodeFromXMLPack.getXMLNamespace() + m_treeNodeFromXMLPack.getXMLTagBody());
					break;
				// text nodes
				case hireright.sdk.xml.parser.XMLOpt.TEXT_NORMAL:
					resultNode = hireright.sdk.html.parser.XMLTreeNodeParser.getNodeForType
						(hireright.sdk.html.parser.XMLConsts.TYPE_TEXT);
					resultNode.setXMLTag((String) m_treeNodeFromXMLPack.getData());
					break;
				// cdata nodes
				case hireright.sdk.xml.parser.XMLOpt.TEXT_CDATA:
					resultNode = hireright.sdk.html.parser.XMLTreeNodeParser.getNodeForType
						(hireright.sdk.html.parser.XMLConsts.TYPE_CDATA);
					resultNode.setXMLTag((String) m_treeNodeFromXMLPack.getData());
					break;
				// comment nodes
				case hireright.sdk.xml.parser.XMLOpt.TEXT_COMMENT:
					resultNode = hireright.sdk.html.parser.XMLTreeNodeParser.getNodeForType
						(hireright.sdk.html.parser.XMLConsts.TYPE_COMMENTS);
					resultNode.setXMLTag((String) m_treeNodeFromXMLPack.getData());
					break;
			}
			
			// convert this node attributes
			hireright.sdk.xml.parser.TreeNodeAttrib tempAttrNode = m_treeNodeFromXMLPack.firstAttribNode();
			
			while(tempAttrNode != null)
			{
				// create attribute
				hireright.sdk.html.parser.TreeNodeAttrib attribute = 
					new hireright.sdk.html.parser.TreeNodeAttrib();
				attribute.setXMLTag(tempAttrNode.getName());
				hireright.sdk.html.parser.XMLTextTreeNode textNode = 
					new hireright.sdk.html.parser.XMLTextTreeNode();
				textNode.setXMLTag((String) tempAttrNode.getData());
				attribute.addChildNode(textNode);
				resultNode.addChildNode(attribute);
				
				tempAttrNode = (hireright.sdk.xml.parser.TreeNodeAttrib) tempAttrNode.getNext();
			}
		}
		else	// root node
		{
			resultNode = hireright.sdk.html.parser.XMLTreeNodeParser.getNodeForType
				(hireright.sdk.html.parser.XMLConsts.TYPE_ROOT);
			resultNode.setXMLTag("ROOT");			
		}
	
		// convert child nodes
		// first child
		hireright.sdk.xml.parser.XMLTreeNode childXML = (hireright.sdk.xml.parser.XMLTreeNode) 
			m_treeNodeFromXMLPack.firstChildNode();
		
		// cicle childs
		while(childXML != null)
		{
			XML2XHTMLPackageStructConv converter = new XML2XHTMLPackageStructConv();
			resultNode.addChildNode(converter.convert(childXML));
			childXML = (hireright.sdk.xml.parser.XMLTreeNode) childXML.getNext();
		}
		
		return resultNode;
	}
}

