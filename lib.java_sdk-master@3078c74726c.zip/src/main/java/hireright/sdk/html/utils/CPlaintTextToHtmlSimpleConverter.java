/*
 *
 * Copyright 2001-2019 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	V.Ozernov		2019-04-25	HIVPE-76233 Created
 */
package hireright.sdk.html.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import hireright.sdk.util.CStringUtils;

/**
 * Simple conversion from plain text to HTML.
 * 1. Replaces special chars (&<>") with HTML entities.
 * 2. Replaces newlines with <br/>.
 * 3. Transforms URLs to anchor tags: www.example.com -> <a href="http://www.example.com">www.example.com</a>.
 * 4. Transforms email addresses to anchor tags: mail@example.com -> <a href="mailto:mail@example.com">mail@example.com</a>. 
 */
public class CPlaintTextToHtmlSimpleConverter
{
	private final static Pattern PATTERN_PLAIN_TEXT_URL = Pattern.compile("(?i)\\b((?:(https?://)|www\\d{0,3}[.]|[a-z0-9.\\-]+[.][a-z]{2,4}/)(?:[^\\s()<>]+|\\(([^\\s()<>]+|(\\([^\\s()<>]+\\)))*\\))+(?:\\(([^\\s()<>]+|(\\([^\\s()<>]+\\)))*\\)|[^\\s`!()\\[\\]{};:\'\".,<>?«»“”‘’]))");
	private final static Pattern PATTERN_PLAIN_TEXT_EMAIL = Pattern.compile("(?i)\\b([A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6})");

	public static String convert(String sPlainText)
	{
		if (CStringUtils.isEmpty(sPlainText))
		{
			return sPlainText;
		}
		
		String sHTML = sPlainText
					.replace("&", "&amp;")
					.replace("<", "&lt;")
					.replace(">", "&gt;")
					.replace("\"", "&quot;")
					.replace("\r\n", "<br/>")
					.replace("\n", "<br/>");
		
		{
			StringBuffer bufStr = new StringBuffer();
			Matcher urlMatcher = PATTERN_PLAIN_TEXT_URL.matcher(sHTML);
			while (urlMatcher.find())
			{
				String sUrlPrefix = CStringUtils.isEmpty(urlMatcher.group(2)) ? "http://" : CStringUtils.EMPTY_STRING;
				urlMatcher.appendReplacement(bufStr, "<a href=\"" + sUrlPrefix + "$1\">$1</a>");
			}
		
			urlMatcher.appendTail(bufStr);
			sHTML = bufStr.toString();
		}

		sHTML = PATTERN_PLAIN_TEXT_EMAIL.matcher(sHTML).replaceAll("<a href=\"mailto:$1\">$1</a>");
		return sHTML;
	}
}
