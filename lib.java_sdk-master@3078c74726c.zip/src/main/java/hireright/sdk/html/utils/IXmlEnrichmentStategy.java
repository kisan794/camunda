/*
 * @(#)$RCSfile: IXmlEnrichmentStategy.java,v $ $Revision: 1.2 $ $Date: 2013/12/13 08:14:35 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/IXmlEnrichmentStategy.java,v $
 * Copyright 2013 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * A.Podlipski		2013-11-19	created
 */
package hireright.sdk.html.utils;

import hireright.sdk.html.parser.XMLObject;

/**
 * XMLObject enricher contract.
 * The idea is to extract XML enriching behavior into own entity to give XML producers more abstraction and re-usability.
 * 
 * NOTE: this is pure *enrichment* strategy; it is not meant to perform XML transformations, clean-up, or injection tasks.
 *  
 * @author apodlipski
 */

public interface IXmlEnrichmentStategy
{
	/** 
	 * Enrich specified XML by adding more data to it. 
	 */
	public void enrich(XMLObject xml);
}
