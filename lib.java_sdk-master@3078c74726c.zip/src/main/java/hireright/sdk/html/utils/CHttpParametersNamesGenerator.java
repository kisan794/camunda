/*
 * @(#)$RCSfile: CHttpParametersNamesGenerator.java,v $ $Revision: 1.6 $ $Date: 2008/09/05 10:14:00 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot_shared/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CHttpParametersNamesGenerator.java,v $
 *
 * Copyright 2001-2016 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	2005-06-28		A.Solntsev	Created
 *	S.Prokopov		2007-07-27	Added short value generation for name attribute 
 *	E.Kaschavstev	2016-03-17	EV470718 : updated functionality when parameter m_bResetAttributes set in false.
 *	H.Lukashenka	2016-03-25	EV473302 : updated functionality when parameter m_bResetAttributes set in false - Phase 2.
 */
package hireright.sdk.html.utils;

import hireright.sdk.html.parser.TreeNodeAttrib;
import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLTreeNode;

import java.io.Serializable;

/**
 * Class that can generate unique attributes "name" for all elements in
 * given XML. If some element already has attribute "name", currently it
 * remains unchaged.
 * 
 * TODO	Possibily we need to clear all existing	"name" attributes.
 * 
 * @author	Andrei Solntsev
 * @since		java_sdk_v2-5-27, 2005-06-28
 * @version $Revision: 1.6 $, $Date: 2008/09/05 10:14:00 $, $Author: asolntsev $
 * @source	$Source: /usr/local/cvsroot_shared/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CHttpParametersNamesGenerator.java,v $
 */
public class CHttpParametersNamesGenerator implements Serializable
{
	private static final long serialVersionUID = -4802834319441822942L;

	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: asolntsev $";
	
	public static final String DATA_NODE = "data_node";
	public static final String NAME = "name";
	
	/**
	 * Attribute for data_node to store next ID number for newly added nodes.
	 */
	public static final String ATTR_NODE_NEXT_ID_NUMBER = "nodeNextIDNumber";
	
	/**
	 * Prefix for uniq value
	 */
	private String m_sPrefix;
	
	/**
	 * Flag that indetifies where to generate short names
	 */
	private boolean m_bShortNames = false;
	
	/**
	 * Force reset name attibute and set new value
	 */
	private boolean m_bResetAttributes = false;
	
	private boolean m_bIsSequenceNotAddedAsAttribute = false;

	/**
	 * Public static method that checks if unique names are already generated
	 * for given xml. If not, it runs generating names.
	 * 
	 * @param xml	XMLObject, not null.
	 */
	public static void updateNames(XMLObject xml)
	{
		XMLTreeNode dataNode = xml.getNode(DATA_NODE);
		if (dataNode != null)
		{
			String sName = dataNode.getAttribText(NAME);
			if (sName == null || sName.trim().length() < 1)
			{
				new CHttpParametersNamesGenerator(xml).generateUniqueNames();
			}
		}
	}
	
	/*
	 * Class members: xml and internal counter (in order to guarantee unique names).
	 */
	private XMLObject m_xml;
	private int m_sequence;
	private long m_date;
	
	/**
	 * Constructor
	 * 
	 * @param xml
	 */
	public CHttpParametersNamesGenerator(XMLObject xml)
	{
		m_xml = xml;
		m_sequence = 1;
		m_date = System.currentTimeMillis();
	}
	
	/**
	 * Constructor
	 * 
	 * @param xml		xml to prepare
	 */
	public CHttpParametersNamesGenerator(
			XMLObject xml, 
			String sPrefix, 
			boolean bShortNames, 
			boolean bResetAttributes)
	{
		this(xml);
		m_bShortNames = bShortNames;
		m_bResetAttributes = bResetAttributes;
		m_sPrefix = sPrefix;
		
		// If for data_node we do not need to reset 'name' attributes then
		// to avoid non-unique names we need to read 
		// from data_node attribute 'nodeNextIDNumber' the next allowed ID number if exists.
		// If 'nodeNextIDNumber' doesn't exist it is necessary to reset 'name' attributes
		// even though m_bResetAttributes = false (case when application was created before 
		// updated name generation algorithm is turned on).
		if (!m_bResetAttributes)
		{
			XMLTreeNode data_node = m_xml.getNode(DATA_NODE);
			if (data_node != null)
			{
				TreeNodeAttrib attr = data_node.getAttribNode(ATTR_NODE_NEXT_ID_NUMBER);
				if (attr != null)
				{
					m_sequence = Integer.parseInt(attr.getText());
				}
				else
				{
					m_bIsSequenceNotAddedAsAttribute = true;
				}
			}
		}
	}
	
	/**
	 * Method runs throw entire XML and generates unique attributes "name"
	 * for all elements.
	 */
	public void generateUniqueNames()
	{
		XMLTreeNode root = m_xml.getRootNode();
		generateUniqueNames(root);
		
		// We always need to store the next allowed ID number
		// in data_node attribute 'nodeNextIDNumber'.
		XMLTreeNode dataNode = m_xml.getNode(DATA_NODE);
		if (dataNode != null)
		{
			TreeNodeAttrib attr = dataNode.getAttribNode(ATTR_NODE_NEXT_ID_NUMBER);
			if (attr != null)
			{
				attr.setText(String.valueOf(m_sequence));
			}
			else
			{
				dataNode.addAttribNode(ATTR_NODE_NEXT_ID_NUMBER, String.valueOf(m_sequence));
			}
		}
	}
	
	/**
	 * Protected method generates "name" attributes for given node
	 * and all its children.
	 * 
	 * @param root	node in XML Tree.
	 */
	protected void generateUniqueNames(XMLTreeNode root)
	{
		if (root.getType() == XMLConsts.TYPE_NODE)
		{
			// In case of when application has no stored parameter m_sequence as data_node attr 'nodeNextIDNumber'
			// (m_bIsSequenceNotAddedAsAttribute = true) it is necessary to reset 'name' attributes
			// even though m_bResetAttributes = false
			if (root.getAttribNode(NAME) == null || m_bResetAttributes || m_bIsSequenceNotAddedAsAttribute)
			{
				root.addAttribNode(NAME, generateName(root));
			}
		}

		XMLTreeNode child = (XMLTreeNode) root.firstChildNode();
		while (child != null)
		{
			generateUniqueNames(child);
			child = child.getNextXmlNode();
		}
	}

	/**
	 * Returns uniq name
	 * <p>
	 * @param root	xml tree root
	 * @return <code>String</code>
	 */
	private String generateName(XMLTreeNode root)
	{
		return m_bShortNames ?
				m_sPrefix + m_sequence++ :
				"_" + m_date + "_" + root.getXMLTag() + "_" + m_sequence++;
	}

}