/*
 * @(#)$RCSfile: XHTMLInjector.java,v $ $Revision: 1.22 $ $Date: 2009/12/18 07:13:13 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/XHTMLInjector.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	S.Ignatov			2003-03-17	added removeOutFirstDummyNode(String szAttribute)
 * 	A.Solntsev		2003-10-17	added comments
 * 	A.Solntsev		2005-05-09	Removed "throws CloneNotSupportedException, XMLObjectException".
 * 	A.Solntsev		2005-05-04	Removed "throws Exception".
 * 	A.Solntsev		2005-06-28	More safe implementation: checking for null-values.
 * 	A.Solntsev		2006-01-10	Added more methods for convinience.
 *  							Removed "throws XMLObjectException" in method resetOutput().
 *	A.Solntsev		2006-10-31	Added new constructor XHTMLInjector(Reader reader, String sURL)
 *	A.Solntsev		2006-11-06	removed "extends XMLObject"
 *	D.Belorunov		2007-05-15	removeNodesByAttribute() now changes output XMLObject.
 *	A.Solntsev		2007-11-19	Bugfix in method removeOutNode()
 *	A.Solntsev		2007-11-26	NetTracking.registerUrl();
 *	M.Elshin			2008-01-18	following method was added to inject attribute to node with specified
 *														index: injectAttribute(String, String, int, String)
 *	A.Solntsev		2008-02-18	Added method parseValidXhtml(String sXhtml)
 *	M.Karpov			2008-03-12	Removed final attribute from toString(boolean bNiceOutput) method
 *	A.Solntsev		2008-04-04	Fixed NPE in method removeOutNode (see traceLog #66360555)
 *	A.Solntsev		2008-08-25	Bugfix in XHTMLInjector (infinite loop in method removeOutNodes)
 *	A.Solntsev		2008-08-28	Throw XMLObjectRuntimeException instead of RuntimeException
 *	A.Solntsev		2009-03-12	Removed method resetOutput() (not used anywhere)
 *	A.Naboyshchikov	2020-09-22	HRG-126805: add second attempt for loading XML from URL (catch IOException) 
 */
package hireright.sdk.html.utils;

import hireright.sdk.debug.CTraceLog;
import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLObjectException;
import hireright.sdk.html.parser.XMLObjectFactory;
import hireright.sdk.html.parser.XMLObjectRuntimeException;
import hireright.sdk.html.parser.XMLOutputStyle;
import hireright.sdk.html.parser.XMLRootTreeNode;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.net.NetTracking;
import hireright.sdk.util.CProperties;

import java.io.Reader;
import java.io.Serializable;
import java.net.URL;

/**
 * Class for implementing XML Object, which allows operation like
 * injecting/dublicating new branches.
 *
 * XHTMLInjector works with two XMLObjects:
 *	1 - source (or template) - base XMLOject, on which will be applied XHTMLInjector operations.
 *	2 - Output XMLObject - where results of operations are stored.
 *
 *  NB! Indexes of nodes start from 1.
 *
 *  getNodeLast(String sId), injectValueLast(String sId, String sValue[, boolean doAppend]), replaceInValueLast(String sId, String sValueToReplace, String sReplacement)
 *  	injectValue(String sId, int nIndex, String sValue), replaceInValue(String sId, int nIndex, String sValueToReplace, String sReplacement)
 *    injectValue(String sId, String sValue)
 *    replaceInValue(String sId, String sValueToReplace, String sReplacement)
 *
 * @author Sergei Ingatov
 * @since 2003
 * @version $Revision: 1.22 $ $Date: 2009/12/18 07:13:13 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/XHTMLInjector.java,v $
 */
public class XHTMLInjector implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.22 $ $Author: cvsroot $";
	
	private XMLObject m_inputXMLObject;
	protected XMLObject m_outputXMLObject;

	public static final String ID_ATTRIBUTE = "id";

	private String m_sBaseAttribute = ID_ATTRIBUTE;

	public static final int APPEND_REPLACE = 0;
	public static final int APPEND_TO_END = 1;
	public static final int APPEND_TO_BEGIN = 2;

	public static final int LEVEL_LAST = CNodeWalker.LEVEL_LAST;

	/**
	 * Method makes object's clone.
	 * @return copy of this XHTMLInjector
	 * @deprecated Use copy constructor instead of method clone()
	 */
	public Object clone()
	{
		return new XHTMLInjector(this);
	}

	/**
	 * Empty constructor.
	 * @deprecated Use constructor with URL parameter.
	 */
	public XHTMLInjector()
	{
		super();
	}
	
	/**
	 * Constructor.
	 * Makes a copy from given xmlObject.
	 *
	 * @param	xmlObject
	 *
	 * @throws NullPointerException if xmlObject is null
	 * @throws IllegalArgumentException has no elements
	 */
	public XHTMLInjector(XMLObject xmlObject)
	{
		if (xmlObject == null)
			throw new IllegalArgumentException("Cannot create XMLInjector based on empty XML");

		if (xmlObject.getRootNode() == null || xmlObject.getRootNode().firstChildNode() == null)
			throw new IllegalArgumentException("Cannot create XMLInjector based on empty XML");

		m_inputXMLObject = xmlObject;	// or new XMLObject(xmlObject); ?
		m_outputXMLObject = new XMLObject(xmlObject);

		// setRootNode(xmlObject.getRootTreeNode().dublicate());
		// onDoneParsing();
	}


	/*protected final void setRootNode(XMLTreeNode rootNode)
	{
		m_inputXMLObject.setRootNode(rootNode);
	}*/

	protected XMLObject getInputXmlObject()
	{
		return m_inputXMLObject;
	}

	/**
	 * Copy costructor
	 * @param copyMe XHTMLInjector to be cloned
	 * @since Oct 31, 2006
	 */
	public XHTMLInjector(XHTMLInjector copyMe)
	{
		this( new XMLObject(copyMe.getInputXmlObject()) );
		setBaseAttributeName(copyMe.m_sBaseAttribute);
	}

	/**
	 * @param urlOfSourceXMLData any URL containing valid XML resource
	 * @throws XMLObjectException if XML is invalid
	 */
	public XHTMLInjector(URL urlOfSourceXMLData)
		throws XMLObjectException
	{
			this(XMLObjectFactory.getXMLObjectFromURL(urlOfSourceXMLData));
	}

	/**
	 * @deprecated Use constructor with URL parameter.
	 * @param url
	 * @throws XMLObjectException
	 * @since Nov 6, 2006
	 */
	public final void parse(URL url) throws XMLObjectException
	{
		NetTracking.registerUrl(url);
		m_inputXMLObject = new XMLObject(url);
		m_outputXMLObject = new XMLObject(m_inputXMLObject);
	}

	/**
	 * @deprecated Use constructor with String parameter.
	 * @param sXmlContent
	 * @throws XMLObjectException
	 * @since Nov 6, 2006
	 */
	public final void parse(String sXmlContent) throws XMLObjectException
	{
		m_inputXMLObject = new XMLObject(sXmlContent);
		m_outputXMLObject = new XMLObject(m_inputXMLObject);
	}

	public final void removeNodesByAttribute(String szAttributeName, String szAttributeValue)
	{
		m_outputXMLObject.removeNodesByAttribute(szAttributeName, szAttributeValue);
	}

	public final XMLTreeNode getRootNode()
	{
		return m_inputXMLObject.getRootNode();
	}

	/**
	 * @param reader any java.io.Reader -
	 * 		typically this is URLInputStream which reads XML from external URL.
	 *
	 * @param sURL Descriptor of this java.io.InputStream - for example, URL of external XML object.
	 * 		This is used for throwing exception in case of invalid XML.
	 *
	 * @throws XMLObjectException if XML is invalid
	 */
	public XHTMLInjector(Reader reader, String sURL) throws XMLObjectException
	{
		this( new XMLObject(reader, sURL) );
	}

	/**
	 * @param sSourceXMLStringData COMMENT ME
	 * @throws XMLObjectException if XML is invalid
	 */
	public XHTMLInjector(String sSourceXMLStringData)
		throws XMLObjectException
	{
		m_inputXMLObject = new XMLObject(sSourceXMLStringData);
		m_outputXMLObject = new XMLObject(m_inputXMLObject);
	}

	/**
	 * @deprecated This method return node of the original XML Object which is not changed.
	 * Any operations on this node will not result in output XML.
	 *
	 * @param sXMLTag
	 * @return
	 */
	public XMLTreeNode getNode(String sXMLTag)
	{
		return m_inputXMLObject.getNode(sXMLTag);
	}

	/**
	 * @deprecated This method return node of the original XML Object which is not changed.
	 * Any operations on this node will not result in output XML.
	 *
	 * @param sAttribute
	 * @param sValue
	 * @return
	 */
	public XMLTreeNode getNodeByAttribute(String sAttribute, String sValue)
	{
		return m_inputXMLObject.getNodeByAttribute(sAttribute, sValue);
	}

	/**
	 * NB! Shouldn't this method be protected?
	 */
	/*public void onDoneParsing()
	{
		m_outputXMLObject = new XMLObject(this.getInputXmlObject());
		//m_outputXMLObject.getRootNode().setXMLObject(m_outputXMLObject);
	}*/

	/**
	 * Output Objects for direct operations.
	 */
	public XMLTreeNode getOutputRootNode()
	{
		return m_outputXMLObject.getRootNode();
	}

	public XMLObject getOutputXMLObject()
	{
		return m_outputXMLObject;
	}

	/**
	 * return last created node with attribute id="sId"
	 */
	public XMLTreeNode getNodeLast(String sId)
	{
		int index = 1;
		XMLTreeNode nodeLast;
		XMLTreeNode node = nodeLast = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, index);

		while(node != null)
		{
			index++;
			nodeLast = node;
			node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, index);
		}

		return nodeLast;
	}

	/**
	 * Private methods: set text value for given node.
	 */
	private boolean injectValue(XMLTreeNode node, String sValue)
	{
		return injectValue(node, sValue, false);
	}

	private boolean injectValue(XMLTreeNode node, String sValue, boolean doAppend)
	{
		if(node == null)
			return false;

		if(doAppend)
			sValue = node.getText(XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT) + sValue;
		node.setText(sValue, XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT);
		return true;
	}

	private boolean replaceInValue(XMLTreeNode node, String sValueToReplace, String sReplacement)
	{
		if(node == null)
			return false;
		String sValue = node.getText(XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT);
		sValue = XMLUtils.replace(sValue, sValueToReplace, sReplacement);
		node.setText(sValue, XMLConsts.TYPE_CDATA | XMLConsts.TYPE_TEXT);
		return true;
	}

	/**
	 * set text value (create text node) of last created node with attribute id="sId"
	 */
	public boolean injectValueLast(String sId, String sValue)
	{
		return injectValueLast(sId, sValue, false);
	}

	/**
	 * Transform nValue to String and inject into XML.
	 * @param sId
	 * @param nValue	Any Integer.
	 * 					null-value is transformed to "null".
	 * @return boolean if XML Element with given id is found
	 */
	public boolean injectValueLast(String sId, Integer nValue)
	{
		return injectValueLast(sId, String.valueOf(nValue), false);
	}

	/**
	 * set or append to current text value (create text node) of last created node with attribute id="sId"
	 */
	public boolean injectValueLast(String sId, String sValue, boolean doAppend)
	{
		return injectValue(getNodeLast(sId), sValue, doAppend);
	}

	/**
	 * replace part of text value (create text node) of last created node with attribute id="sId"
	 */
	public boolean replaceInValueLast(String sId, String sValueToReplace, String sReplacement)
	{
		return replaceInValue(getNodeLast(sId), sValueToReplace, sReplacement);
	}

	/**
	 * set text value (create text node) of nIndex`s node with attribute id="sId"
	 * index starts from 1.
	 */
	public boolean injectValue(String sId, int nIndex, String sValue)
	{
		XMLTreeNode node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, nIndex);
		return injectValue(node, sValue);
	}

	public boolean replaceInValue(String sId, int nIndex, String sValueToReplace, String sReplacement)
	{
		XMLTreeNode node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, nIndex);
		return replaceInValue(node, sValueToReplace, sReplacement);
	}

	/**
	 * Set text value (create text node) of all nodes with attribute id="sId"
	 * (indexes start from 1).
	 *
	 * Function always returns true.
	 */
	public boolean injectValue(String sId, String sValue)
	{
		int index = 1;
		while (injectValue(sId, index, sValue))
			index++;
		return true;
	}

	/**
	 * set text value (create text node) of all nodes with attribute id="sId"
	 * (indexes start from 1).
	 *
	 * Function always returns true.
	 */
	public boolean replaceInValue(String sId, String sValueToReplace, String sReplacement)
	{
		int index = 1;
		while (replaceInValue(sId, index, sValueToReplace, sReplacement))
			index++;
		return true;
	}

	/**
	 * create attribute for last created node with attribute id="sId"
	 */
	public boolean injectAttributeLast(String sId, String sAttributeName, String sAttributeValue)
	{
		return injectAttributeLast(sId, sAttributeName, sAttributeValue, false);
	}

	/**
	 * create attribute or append to attribute value for last created node with attribute id="sId"
	 */
	public boolean injectAttributeLast(String sId, String sAttributeName, String sAttributeValue, boolean doAppend)
	{
		XMLTreeNode nodeLast = getNodeLast(sId);

		if(nodeLast == null)
			return false;

		if(doAppend)
		{
			String attrText = nodeLast.getAttribText(sAttributeName);
			if(attrText == null)
				attrText = "";
			sAttributeValue = attrText + sAttributeValue;
			attrText =null;
		}

		nodeLast.addAttribNode(sAttributeName, sAttributeValue);

		return true;
	}

	/**
	 * Private method: replaces in given node's attribute's value all given substrings.
	 */
	private boolean replaceInAttribute(XMLTreeNode node, String sAttributeName, String sValueToReplace, String sReplacement)
	{
		if (node == null)
			return false;

		String attrText = node.getAttribText(sAttributeName);
		if(attrText != null)
		{
			attrText = XMLUtils.replace(attrText, sValueToReplace, sReplacement);
			node.addAttribNode(sAttributeName, attrText);
		}
		return true;
	}


	/**
	 * replace part of string with another string for last created node with attribute id="sId"
	 */
	public boolean replaceInAttributeLast(String sId, String sAttributeName, String sValueToReplace, String sReplacement)
	{
		return replaceInAttribute(getNodeLast(sId), sAttributeName, sValueToReplace, sReplacement);
	}

	public boolean replaceInAttribute(String sId, int index, String sAttributeName, String sValueToReplace, String sReplacement)
	{
		XMLTreeNode node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, index);
		if (node == null)
			return false;

		while (node != null)
		{
			String attrText = node.getAttribText(sAttributeName);
			if(attrText == null)
				attrText = "";
			attrText = XMLUtils.replace(attrText, sValueToReplace, sReplacement);
			node.addAttribNode(sAttributeName, attrText);
			attrText = null;

			index++;
			node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, index);
		}

		return true;
	}


	/**
	 * Create attribute for all nodes with attribute id="sId"
	 * If this attribute already exists, it's replaced by the new value.
	 *
	 * @see #APPEND_REPLACE
	 *
	 * @param sId COMMENT ME
	 * @param sAttributeName name of attribute
	 * @param sAttributeValue (new) value of attribute
	 */
	public boolean injectAttribute(String sId, String sAttributeName, String sAttributeValue)
	{
		return injectAttribute(sId, sAttributeName, sAttributeValue, APPEND_REPLACE);
	}

	public boolean injectAttribute(String sId, String sAttributeName, String sAttributeValue, boolean doAppend)
	{
		return injectAttribute(sId, sAttributeName, sAttributeValue, (doAppend?APPEND_TO_END:APPEND_REPLACE));
	}

	/**
	 * Inject attribute in node with specified name and specified index.
	 * @param sId node name to inject attribute to.
	 * @param sAttributeName name of attribute.
	 * @param nodeIndex index of node to inject attribute to.
	 * @param sAttributeValue attribute value to inject.
	 * @return true if such node exists otherwise false.
	 */
	public boolean injectAttribute(String sId, String sAttributeName, int nodeIndex, String sAttributeValue)
	{
		XMLTreeNode node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, nodeIndex);
		if(node == null)
			return false;
		node.addAttribNode(sAttributeName, sAttributeValue);
		return true;
	}

	public boolean injectAttribute(String sId, String sAttributeName, String sAttributeValue, int nAppendPosition)
	{
		int index = 1;
		XMLTreeNode node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, index);
		if (node == null)
			return false;
		
		while (node != null)
		{
			switch(nAppendPosition)
			{
				case APPEND_REPLACE:
				{
					node.addAttribNode(sAttributeName, sAttributeValue);
					break;
				}
				case APPEND_TO_END:
				{
					String attrText = node.getAttribText(sAttributeName);
					if(attrText == null)
						attrText = "";
					node.addAttribNode(sAttributeName, attrText + sAttributeValue);
					attrText = null;
					break;
				}
				case APPEND_TO_BEGIN:
				{
					String attrText = node.getAttribText(sAttributeName);
					if(attrText == null)
						attrText = "";
					node.addAttribNode(sAttributeName, sAttributeValue + attrText);
					attrText = null;
					break;
				}
			}
			index++;
			node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, index);
		}

		return true;
	}

	/**
	 * For all nodes with id=sId:
	 * in attribute sAttributeName replaces all substrings sValueToReplace by string sReplacement.
	 *
	 * @return	Method always returns true.
	 */
	public boolean replaceInAttribute(String sId, String sAttributeName, String sValueToReplace, String sReplacement)
	{
		int index = 1;
		while (replaceInAttribute(sId, index, sAttributeName, sValueToReplace, sReplacement))
			index++;
		return true;
	}

	/**
	 * Transform nValue to String and replace into XML element's attribute.
	 * @param sId
	 * @param sAttributeName
	 * @param sValueToReplace
	 * @param nReplacement	Any Integer.
	 * 						null-value is transformed to "null".
	 * @return if XML Element with given id is found and has attribute with given name
	 */
	public boolean replaceInAttribute(String sId, String sAttributeName, String sValueToReplace, Integer nReplacement)
	{
		return replaceInAttribute(sId, sAttributeName, sValueToReplace, String.valueOf(nReplacement));
	}

	/**
	 * create attribute for all childs of all nodes with attribute id="sId"
	 */
	public boolean injectAttributeToChilds(String sId, String sAttributeName, String sAttributeValue)
	{
		int index = 1;
		XMLTreeNode node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, index);
		if(node == null)
			return false;

		while(node != null)
		{
			XMLTreeNode childNode = node.getFirstChildNode();
			while(childNode != null)
			{
				if(childNode.getType() == XMLConsts.TYPE_NODE)
					childNode.addAttribNode(sAttributeName, sAttributeValue);

				childNode = childNode.getNextXmlNode();
			}
			index++;
			node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sId, index);
		}

		return true;
	}

	/**
	 * Private method: adds an atribute for all children of given node.
	 */
	private boolean injectAttributeToChildren(XMLTreeNode node, String sAttributeName, String sAttributeValue)
	{
		if(node == null)
			return false;

		XMLTreeNode childNode = node.getFirstChildNode();
		while (childNode != null)
		{
			if(childNode.getType() == XMLConsts.TYPE_NODE)
				childNode.addAttribNode(sAttributeName, sAttributeValue);

			childNode = childNode.getNextXmlNode();
		}

		return true;
	}


	/**
	 * create attribute for all childs of last created node with attribute id="sId"
	 * v.1
	 */
	public boolean injectAttributeLastToChilds(String sId, String sAttributeName, String sAttributeValue)
	{
		return injectAttributeToChildren(getNodeLast(sId), sAttributeName, sAttributeValue);
	}

	/**
	 * create attribute for all childs of last created node with attribute id="sId" or for all with rec.deep = level
	 * v.2
	 * sChildId = null if for all childs;
	 * level = XHTMLInjector.LAST_LEVEL if only for last childs in tree
	 * doAppend = true if append to current value
	 */
	public boolean injectAttributeLastToChilds(String sId, int level, String sAttributeName, String sAttributeValue)
	{
		return injectSomethingLastToChilds(CNodeWalker.ACTION_ADD_ATTRIBUTE, sId, null, level, sAttributeName, sAttributeValue, false);
	}

	public boolean injectAttributeLastToChilds(String sId, int level, String sAttributeName, String sAttributeValue, boolean doAppend)
	{
		return injectSomethingLastToChilds(CNodeWalker.ACTION_ADD_ATTRIBUTE, sId, null, level, sAttributeName, sAttributeValue, doAppend);
	}

	public boolean injectAttributeLastToChilds(String sId, String sChildId, int level, String sAttributeName, String sAttributeValue)
	{
		return injectSomethingLastToChilds(CNodeWalker.ACTION_ADD_ATTRIBUTE, sId, sChildId, level, sAttributeName, sAttributeValue, false);
	}

	public boolean injectAttributeLastToChilds(String sId, String sChildId, int level, String sAttributeName, String sAttributeValue, boolean doAppend)
	{
		return injectSomethingLastToChilds(CNodeWalker.ACTION_ADD_ATTRIBUTE, sId, sChildId, level, sAttributeName, sAttributeValue, doAppend);
	}

	public boolean injectValueLastToChilds(String sId, int level, String sValue)
	{
		return injectSomethingLastToChilds(CNodeWalker.ACTION_ADD_TEXT, sId, null, level, sValue, null, false);
	}

	public boolean injectValueLastToChilds(String sId, int level, String sValue, boolean doAppend)
	{
		return injectSomethingLastToChilds(CNodeWalker.ACTION_ADD_TEXT, sId, null, level, sValue, null, doAppend);
	}

	public boolean injectValueLastToChilds(String sId, String sChildId, int level, String sValue)
	{
		return injectSomethingLastToChilds(CNodeWalker.ACTION_ADD_TEXT, sId, sChildId, level, sValue, null, false);
	}

	public boolean injectValueLastToChilds(String sId, String sChildId, int level, String sValue, boolean doAppend)
	{
		return injectSomethingLastToChilds(CNodeWalker.ACTION_ADD_TEXT, sId, sChildId, level, sValue, null, doAppend);
	}

	private boolean injectSomethingLastToChilds(int nAction, XMLTreeNode node, String sChildId, int level, String sParam1, String sParam2, boolean doAppend)
	{
		if(node == null)
			return false;

		CNodeWalker nodeWalk = new CNodeWalker(node);
		nodeWalk.doIt(nAction, level, m_sBaseAttribute, sChildId, sParam1, sParam2, doAppend);
		nodeWalk = null;

		return true;
	}

	protected boolean injectSomethingLastToChilds(int nAction, String sId, String sChildId, int level, String sParam1, String sParam2, boolean doAppend)
	{
		XMLTreeNode node = getNodeLast(sId);
		return injectSomethingLastToChilds(nAction, node, sChildId, level, sParam1, sParam2, doAppend);
	}

	/**
	 * this method converts all CDATA nodes into TEXT nodes, output will be as TEXT node output &amp; e.t.k.
	 */
	public boolean removeCDATA()
	{
		XMLTreeNode node = getOutputRootNode();
		return injectSomethingLastToChilds(CNodeWalker.ACTION_CUT_CDATA, node, null, Integer.MAX_VALUE, null, null, false);
	}

	/**
	 * remove all attributes with name szAttribute
	 */
	public void removeOutAttributes(String szAttribute)
	{
		getOutputXMLObject().removeAllAttributes(szAttribute);
	}

	/**
	 * Private method. Removes given node.
	 * @param node some node in this XML Object
	 * @return	true, if node!=null.
	 */
	private boolean removeOutNode(XMLTreeNode node)
	{
		if (node == null)
			return false;

		// m_outputXMLObject.removeNode(node);
		// -- TODO: Find all similar methods in XHTMLInjector
		if (node.getParent() != null)
		{
			node.getParent().removeChild(node);
			return true;
		}
		
		// I don't know how it can happen
		{
			CProperties params = new CProperties();
			params.setProperties( m_inputXMLObject );
			params.setProperty( "baseAttribute", m_sBaseAttribute );
			CTraceLog.error( "Node has no parent", getClass().getName()+".removeOutNodes()", 
					params, XMLObject.toString(m_outputXMLObject) );
		}
		return false;
	}

	/**
	 * Method removes ALL nodes with attribute id=szAttribute
	 */
	public void removeOutNodes(String szAttribute)
	{
		XMLTreeNode node;
		for (int i=0; (node = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, szAttribute)) != null; i++)
		{
			if (i > 1000)
			{
				CProperties params = new CProperties();
				params.setProperties( m_inputXMLObject );
				params.setProperty( "baseAttribute", m_sBaseAttribute );
				params.setProperty( "attribute", szAttribute );
				CTraceLog.error( "Infinite loop", getClass().getName()+".removeOutNodes()", 
						params, XMLObject.toString(m_outputXMLObject) );
				return;
			}
			removeOutNode(node);
		}
		
		/*int i=0;
		Collection<XMLTreeNode> nodesToRemove = m_outputXMLObject.getNodesByAttribute(m_sBaseAttribute, szAttribute);
		for (XMLTreeNode node : nodesToRemove)
		{
			if (++i > 1000)
			{
				CProperties params = new CProperties();
				params.setProperties( m_inputXMLObject );
				params.setProperty( "baseAttribute", m_sBaseAttribute );
				params.setProperty( "attribute", szAttribute );
				CTraceLog.error( "Infinite loop", getClass().getName()+".removeOutNodes()", 
						params, XMLObject.toString(m_outputXMLObject) );
				return;
			}
			removeOutNode(node);
		}*/
	}

	/**
	 * remove first created node with attribute id=szAttribute
	 */
	public boolean removeOutNodeFirst(String szAttribute)
	{
		return removeOutNode(m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, szAttribute));
	}

	/**
	 * remove last created node with attribute id=szAttribute
	 */
	public boolean removeOutNodeLast(String szAttribute)
	{
		return removeOutNode(getNodeLast(szAttribute));
	}

	/**
	 * remove first node with same name as last for parent with last node
	 *
	 *  example: removeOutFirstDummyNode(child1);
	 *  parent1
	 *        +-- child1
	 *
	 *	parent2
	 *        +-- child1 (node from template)<- this will be removed
	 *        +-- child1 (created with dublicateBranch())
	 *        +-- child1 (created with dublicateBranch())
	 */
	public void removeOutFirstDummyNode(String szAttribute)
	{
		XMLTreeNode node = getNodeLast(szAttribute);
		if(node == null)
			return;

		XMLTreeNode parent = (XMLTreeNode) node.getParent();
		node = parent.getChildNodeByTag(node.getXMLTag());
		parent.removeChild(node);
		parent = null;
		node = null;
	}

	/**
	 * create new branch, based on given (from sIdStart to sIdEnd), and add/set to last node
	 * attribute id="sNewNodeID".
	 *
	 * @param sIdStart index of new branch. Started from 1(first always created on parsing). (?)
	 * @param sIdEnd (?)
	 */
	public boolean dublicateBranch(String sIdStart, String sIdEnd)
	{
		return dublicateBranch(sIdStart, sIdEnd, "sNewNodeID", XMLConsts.ADD_TO_TAIL, false);
	}

	public boolean dublicateBranch(String sIdStart, String sIdEnd, String sNewNodeID)
	{
		return dublicateBranch(sIdStart, sIdEnd, sNewNodeID, XMLConsts.ADD_TO_TAIL, false);
	}

	public boolean dublicateBranchLast(String sIdStart, String sIdEnd, String sNewNodeID)
	{
		return dublicateBranch(sIdStart, sIdEnd, sNewNodeID, XMLConsts.ADD_TO_TAIL, true);
	}

	public boolean dublicateBranchLast(String sIdEnd)
	{
		return dublicateBranchLast(sIdEnd, sIdEnd);
	}

	public boolean dublicateBranchLast(String sIdEnd, String sNewNodeID)
	{
		XMLTreeNode startNodeParent = this.getNodeByAttribute(m_sBaseAttribute, sIdEnd);
		if(startNodeParent != null)
		{
			startNodeParent = (XMLTreeNode) startNodeParent.getParent();
			return dublicateBranch(startNodeParent.getAttribText(m_sBaseAttribute), sIdEnd, sNewNodeID, XMLConsts.ADD_TO_TAIL, true);
		}

		return false;
	}

	public boolean dublicateBranch(String sIdStart, String sIdEnd, String sNewNodeID, int nNewBranchIndex)
	{
		return dublicateBranch(sIdStart, sIdEnd, sNewNodeID, nNewBranchIndex, false);
	}

	public boolean dublicateBranch(String sIdStart, String sIdEnd, String sNewNodeID, int nNewBranchIndex, boolean dublLastBranch)
	{
		try
		{
			XMLTreeNode endNode = this.getNodeByAttribute(m_sBaseAttribute, sIdEnd);
			XMLTreeNode outStartNode = null;
			if (dublLastBranch)
				outStartNode = getNodeLast(sIdStart);
			else
				outStartNode = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sIdStart);

			XMLTreeNode nodee = this.getNodeByAttribute(m_sBaseAttribute, sIdStart);
			if (nodee == null)
				return false;

			XMLTreeNode node = nodee.dublicateBranchInto(endNode, outStartNode,
																													nNewBranchIndex);
			if (node == null)
				return false;

			XMLTreeNode childOfDubl = endNode.getFirstChildNode();
			while(childOfDubl != null)
			{
				if(childOfDubl.getType() != XMLConsts.TYPE_ATTRIBUTE)
					node.addChildNode(childOfDubl.dublicate());
				childOfDubl = childOfDubl.getNextXmlNode();
			}

			node.addAttribNode(m_sBaseAttribute, sNewNodeID);
		}
		catch (RuntimeException e)
		{
			//e.printStackTrace();
			return false;
		}

		return true;
	}

	public XMLTreeNode dublicateBranchReturnNode(String sIdStart, String sIdEnd)
	{
		return dublicateBranchReturnNode(sIdStart, sIdEnd, XMLConsts.ADD_TO_TAIL);
	}

	public XMLTreeNode dublicateBranchReturnNode(String sIdStart, String sIdEnd, int nNewBranchIndex)
	{
		XMLTreeNode endNode = this.getNodeByAttribute(m_sBaseAttribute, sIdEnd);
		XMLTreeNode outStartNode = m_outputXMLObject.getNodeByAttribute(m_sBaseAttribute, sIdStart);
		//XMLTreeNode outStartNode = getNodeLast(sIdStart);

		XMLTreeNode node = (this.getNodeByAttribute(m_sBaseAttribute, sIdStart)).dublicateBranchInto(
			endNode,
			outStartNode,
			nNewBranchIndex);

		if(node == null)
			return null;

		try
		{
			XMLTreeNode dublicatedNode = endNode.dublicate();
			XMLTreeNode childOfDubl = dublicatedNode.getFirstChildNode();
			while(childOfDubl != null)
			{
				if(childOfDubl.getType() != XMLConsts.TYPE_ATTRIBUTE)
					node.addChildNode(childOfDubl);
				childOfDubl = childOfDubl.getNextXmlNode();
			}
		}
		catch(Exception e)
		{
			return null;
		}

		return node;
	}

	@Override
	public String toString()
	{
		((XMLRootTreeNode) m_outputXMLObject.getRootNode()).setOutputStyle(XMLOutputStyle.WEB);
		return m_outputXMLObject.toString();
	}

	public String toString(boolean bNiceOutput)
	{
		((XMLRootTreeNode) m_outputXMLObject.getRootNode()).setOutputStyle(XMLOutputStyle.WEB);
		return m_outputXMLObject.toString(bNiceOutput);
	}

	public final void setBaseAttributeName(String sAttributeName)
	{
		m_sBaseAttribute = sAttributeName;
	}
	
	/**
	 * 
	 * @param sXhtml
	 * @return
	 * @throws XMLObjectRuntimeException if XHTML appears to be invalid
	 */
	public static XHTMLInjector parseValidXhtml(String sXhtml)
	{
		try
		{
			return new XHTMLInjector(sXhtml);
		}
		catch (XMLObjectException e)
		{
			throw new XMLObjectRuntimeException(e, null, sXhtml);
		}
	}
}

