/*
 * @(#)$RCSfile: CComplementedHttpParametersSet.java,v $ $Revision: 1.3 $ $Date: 2013/06/28 06:52:25 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CComplementedHttpParametersSet.java,v $
 *
 * Copyright 2001-2013 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *   K.Ovchinnikov			2013-04-01	Created
 *   K.Ovchinnikov			2013-06-06	Fixed problems with priorities of storages
 */
package hireright.sdk.html.utils;

import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLTreeNode;

import java.util.Collection;
import java.util.List;
import java.util.Vector;

/**
 * Represents a proxy of CHttpParametersSet complemented with auxiliary data which allows
 * to resolve both base and complementary XML paths. At first it tries to resolve given parameters of base XML
 * and if no data found treats to the complementary XML. 
 * 
 * @author Kirill Ovchinnikov
 * @version $Revision: 1.3 $ $Date: 2013/06/28 06:52:25 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/CComplementedHttpParametersSet.java,v $
 */
public class CComplementedHttpParametersSet implements IHttpParametersStorage
{

	/** class source version **/
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: cvsroot $";

	private CHttpParametersSet m_baseStorage;
	private CHttpParametersSet m_complementaryStorage;

	/**
	 * @param baseXml
	 * @param complementaryXml
	 */
	public CComplementedHttpParametersSet(XMLObject baseXml, XMLObject complementaryXml)
	{
		this.m_baseStorage = new CHttpParametersSet(baseXml);

		XMLObject xmlObject = new XMLObject("<data_node>" + 
				complementaryXml.toString()	+ "</data_node>");
		this.m_complementaryStorage = new CHttpParametersSet(xmlObject);
	}

	/* (non-Javadoc)
	 * @see hireright.sdk.html.utils.IHttpParametersStorage#putParameter(java.lang.String, java.lang.String)
	 */
	public boolean putParameter(String sParameterName, String sParameterValue)
			throws IllegalArgumentException
	{
		return m_baseStorage.putParameter(sParameterName, sParameterValue);
	}

	/* (non-Javadoc)
	 * @see hireright.sdk.html.utils.IHttpParametersStorage#getNodeByPath(java.lang.String)
	 */
	public XMLTreeNode getNodeByPath(String sPath)
	{
		XMLTreeNode node = m_baseStorage.getNodeByPath(sPath);
		return node != null ? node : m_complementaryStorage.getNodeByPath(sPath);
	}

	/* (non-Javadoc)
	 * @see hireright.sdk.html.utils.IHttpParametersStorage#getNodeByPath(java.lang.String, int)
	 */
	public XMLTreeNode getNodeByPath(String sPath, int nIndex)
	{
		XMLTreeNode node = m_baseStorage.getNodeByPath(sPath, nIndex);
		return node != null ? node : m_complementaryStorage.getNodeByPath(sPath, nIndex);
	}

	/* (non-Javadoc)
	 * @see hireright.sdk.html.utils.IHttpParametersStorage#getNodesByPath(java.lang.String)
	 */
	public List<XMLTreeNode> getNodesByPath(String sPathValue)
	{
		List<XMLTreeNode> nodes = m_baseStorage.getNodesByPath(sPathValue);
		return nodes != null && !nodes.isEmpty() ? nodes : m_complementaryStorage
				.getNodesByPath(sPathValue);
	}

	/* (non-Javadoc)
	 * @see hireright.sdk.html.utils.IHttpParametersStorage#getNodesListByPath(java.lang.String)
	 */
	@Deprecated
	public Vector<XMLTreeNode> getNodesListByPath(String sPathValue)
	{
		Vector<XMLTreeNode> nodes = m_baseStorage.getNodesListByPath(sPathValue);
		return nodes != null && !nodes.isEmpty() ? nodes : m_complementaryStorage
				.getNodesListByPath(sPathValue);
	}

	/* (non-Javadoc)
	 * @see hireright.sdk.html.utils.IHttpParametersStorage#getData()
	 */
	public XMLObject getData()
	{
		return m_baseStorage.getData();
	}

	/* (non-Javadoc)
	 * @see hireright.sdk.html.utils.IHttpParametersStorage#getParameterCount(java.lang.String)
	 */
	public int getParameterCount(String sXMLTagName)
	{
		int cnt = m_baseStorage.getParameterCount(sXMLTagName);
		return cnt != 0 ? cnt : m_complementaryStorage.getParameterCount(sXMLTagName);
	}

	/* (non-Javadoc)
	 * @see hireright.sdk.html.utils.IHttpParametersStorage#getParameter(java.lang.String)
	 */
	public XMLTreeNode getParameter(String sParamID)
	{
		XMLTreeNode parameter = m_baseStorage.getParameter(sParamID);
		return parameter != null ? parameter : m_complementaryStorage.getParameter(sParamID);
	}

	/* (non-Javadoc)
	 * @see hireright.sdk.html.utils.IHttpParametersStorage#getParameter(java.lang.String, int)
	 */
	public XMLTreeNode getParameter(String sXMLTagName, int nIndex)
	{
		XMLTreeNode parameter = m_baseStorage.getParameter(sXMLTagName, nIndex);
		return parameter != null ? parameter : m_complementaryStorage.getParameter(sXMLTagName,
				nIndex);
	}

	/* (non-Javadoc)
	 * @see hireright.sdk.html.utils.IHttpParametersStorage#addValidationSummary(int, int, int, java.util.Collection)
	 */
	public void addValidationSummary(int nTotalValid, int nTotalInvalid, int nTotalInvalidRequired,
			Collection<String> cInvalidElements)
	{
		m_baseStorage.addValidationSummary(nTotalValid, nTotalInvalid, nTotalInvalidRequired,
				cInvalidElements);
	}
}
