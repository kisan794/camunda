/*
 * @(#)$RCSfile: XML2Properties.java,v $ $Revision: 1.8 $ $Date: 2009/12/18 07:14:47 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/utils/XML2Properties.java,v $
 *
 * Copyright 2001-2005 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	 A.Solntsev		2005-10-21	Some methods moved here from class CProperties.
 */
package hireright.sdk.html.utils;

import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.util.CProperties;

/**
 *	Class for building CProperties from given XMLTreeNode.
 */
public class XML2Properties
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";

	/**
	 * Node name for properties.
	 */
	public static final String PROPERTIES_NODE_NAME = "properties";
	
	/**
	 * Name for property 'name' attribute.
	 */
	private static final String ATTRIBUTE_NAME = "name";
	
	/**
	 * Node name for property.
	 */
	private static final String TAG_PROPERTY = "property";
	
	/**
		 * Construtor from XML
		 * @param nodeProperties 
		 * <properties>
		 *      <property name="id">
		 *          345
		 *      </property>
		 *      ......
		 * </properties>
		 */
	public static CProperties buildProperties(XMLTreeNode nodeProperties)
	{
		CProperties properties = new CProperties();

		XMLTreeNode nodeProperty = null;
		
		if (nodeProperties != null)
			nodeProperty = (XMLTreeNode) nodeProperties.firstChildNode();

		while (nodeProperty != null)
		{
			if (nodeProperty.getType() == XMLConsts.TYPE_NODE)
			{
				// property's text is value
				String sValue = nodeProperty.getText( XMLConsts.TYPE_TEXT + XMLConsts.TYPE_CDATA );
				// attribute "name" is a key
				String sName = nodeProperty.getAttribText( ATTRIBUTE_NAME );
				if ( sValue != null && sName != null )
					properties.setProperty( sName, sValue );
			}
			nodeProperty = nodeProperty.getNextXmlNode();
		}
		
		return properties;
	}
	
	/**
	 * FIXME It seems that this method does exactly the same as {@link #buildProperties(XMLTreeNode)}.
	 * 
	 * Constructor parses given xmlTreeNode.
	 * 
	 * @param propertiesNode        XMLTreeNode of following structure:
	 * <Properties>
	 * 		<Property name="property_name_1">property_value_1</Property>
	 * 		<Property name="property_name_2">property_value_2</Property>
	 * </Properties>
	 */
	public static CProperties parseProperties(XMLTreeNode propertiesNode)
	{
		final CProperties result = new CProperties();
		for (XMLTreeNode propertyNode : propertiesNode.getChildNodesByTag(TAG_PROPERTY))
		{
			result.setProperty( propertyNode.getAttribText(ATTRIBUTE_NAME), propertyNode.getText() );
		}
		return result;
	}
}