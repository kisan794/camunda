/*
 * @(#)$RCSfile: CXMLNodeComparisonResult.java,v $ $Revision: 1.3 $ $Date: 2009/08/28 06:58:25 $
 * $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/comparator/CXMLNodeComparisonResult.java,v $
 *
 * Copyright 2006-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *
 * E.Tonkoshkurov	2009-04-12	Created.
 */
package hireright.sdk.html.comparator;

import java.io.Serializable;

/**
 * Incapsulates comparison result for two XML nodes. Contains their values, XPath
 * and result itself.
 *
 * @author Evgeny_Tonkoshkurov
 * @version $Revision: 1.3 $ $Date: 2009/08/28 06:58:25 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/comparator/CXMLNodeComparisonResult.java,v $
 */
public class CXMLNodeComparisonResult implements Serializable
{
	/** Enumeration with all possible comparison results. */
	public enum ComparisonResult {NOT_CHANGED, MODIFIED, COMPARABLE_NODE_IS_ABSENT}

	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: asolntsev $";
	
	private final String m_sOriginalNodeValue;
	private final String m_sUpdatedNodeValue;
	private final ComparisonResult m_comparisonResult;
	private final String m_sNodeXPath;

	/**
	 * Creates new instance. Constructor has package level access.
	 *
	 * @param originalNodeValue value of the original node.
	 * @param updatedNodeValue value of the updated node.
	 * @param result enum with comparison result.
	 * @param xPath XPath for original and updated nodes.
	 */
	CXMLNodeComparisonResult(
			String originalNodeValue, String updatedNodeValue, ComparisonResult result, String xPath)
	{
		m_sOriginalNodeValue = originalNodeValue;
		m_sUpdatedNodeValue = updatedNodeValue;
		m_comparisonResult = result;
		m_sNodeXPath = xPath;
	}

	/**
	 * Returns value of the original XML node.
	 *
	 * @return String with original node value.
	 */
	public String getOriginalNodeValue()
	{
		return m_sOriginalNodeValue;
	}

	/**
	 * Returns value of the updated XML node.
	 *
	 * @return String with updated node value.
	 */
	public String getUpdatedNodeValue()
	{
		return m_sUpdatedNodeValue;
	}

	/**
	 * Returns ComparisonResult.NOT_CHANGED if original and updated
	 * nodes values are equal or ComparisonResult.MODIFIED otherwise.
	 *
	 * @return enum with comparison result.
	 */
	public ComparisonResult getComparisonResult()
	{
		return m_comparisonResult;
	}

	/**
	 * Returns XPath for compared nodes.
	 *
	 * @return String with XPath.
	 */
	public String getNodeXPath()
	{
		return m_sNodeXPath;
	}

	@Override
	public String toString()
	{
		return getClass().getSimpleName() + "[" + m_sNodeXPath + ", " + m_comparisonResult + "]";
	}
}
