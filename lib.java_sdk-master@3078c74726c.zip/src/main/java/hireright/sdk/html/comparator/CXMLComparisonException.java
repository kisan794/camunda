/*
 * @(#)$RCSfile: CXMLComparisonException.java,v $ $Revision: 1.2 $ $Date: 2009/05/22 06:39:16 $
 * $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/comparator/CXMLComparisonException.java,v $
 *
 * Copyright 2006-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *
 * E.Tonkoshkurov	2009-04-12	Created.
 */
package hireright.sdk.html.comparator;

import hireright.sdk.util.CException;
import hireright.sdk.util.CProperties;

/**
 * Exception for errors during XML comparison.
 *
 * @author Evgeny_Tonkoshkurov
 * @version $Revision: 1.2 $ $Date: 2009/05/22 06:39:16 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/comparator/CXMLComparisonException.java,v $
 */
public class CXMLComparisonException extends CException
{
	/**
	 * Creates new instance with error description.
	 *
	 * @param message String with error description.
	 */
	public CXMLComparisonException(String message)
	{
		super(message);
	}

	/**
	 * Creates new instance with error description and properties.
	 *
	 * @param message String with error description.
	 * @param properties CProperties with error properties.
	 */
	public CXMLComparisonException(String message, CProperties properties)
	{
		super(message, properties);
	}
}
