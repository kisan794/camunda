/*
 * @(#)$RCSfile: CXMLComparator.java,v $ $Revision: 1.6 $ $Date: 2015/11/02 20:14:36 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/comparator/CXMLComparator.java,v $
 *
 * Copyright 2006-2015 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *
 *	E.Tonkoshkurov	2009-04-12	Created.
 *	E.Tonkoshkurov	2009-08-14	Updated to handle siblings with the same name not by their "index"
 *															attribute but by their order in the given XMLs.
 *	S.Kemaev				2009-09-15	Updated, toString() method usage changed to custom method getXPathRepresentation()
 *	A.Solntsev			2009-12-09	Vector -> List
 */
package hireright.sdk.html.comparator;

import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.util.CStringUtils;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Class for comparing XMLs with identical structure. Comparison result is List
 * with result for every pair of simple XML nodes with values: are these values
 * equal or different.
 *
 * @author Evgeny_Tonkoshkurov
 * @version $Revision: 1.6 $ $Date: 2015/11/02 20:14:36 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/comparator/CXMLComparator.java,v $
 */
public class CXMLComparator implements Serializable 
{
	private static final long serialVersionUID = 6395262775757878618L;
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	private static final String ERROR_NULL_NODE = "Some of compared nodes are equal to null.";

	private static final String BACKSLASH = "/";

	/**
	 * Goes through given XML nodes and all children, compare their values
	 * and returns List with comparison result for all pairs of XML nodes
	 * with values. Original and updated nodes should have identical structure
	 * (child count, tag names etc.). Nodes from the same level with the same 
	 * tag will be compared in the same order as they appear in XML.
	 *
	 * @param originalNode XML node with original values.
	 * @param updatedNode XML node with values to compare.
	 * @return List with comparison result.
	 * @throws CXMLComparisonException in case of different XML nodes or null as parameter.
	 */
	public List<CXMLNodeComparisonResult> compare(
			XMLTreeNode originalNode, XMLTreeNode updatedNode)
			throws CXMLComparisonException
	{
		if ((originalNode == null) || (updatedNode == null))
		{
			throw new CXMLComparisonException(ERROR_NULL_NODE);
		}
		return compareNodes(originalNode, updatedNode, "");
	}

	/**
	 * Checks given nodes and compares their values. Returns comparison
	 * result or recursively calls itself if given nodes contain child nodes.
	 * In such case given nodes should have the same count and XML tags of
	 * child nodes.
	 *
	 * @param originalNode XML node with original values.
	 * @param updatedNode XML node with values to compare.
	 * @param xPathToParent XPath to parents of these nodes.
	 * @return List with comparison result.
	 * @throws CXMLComparisonException in case of different XML nodes.
	 */
	private List<CXMLNodeComparisonResult> compareNodes(
			XMLTreeNode originalNode, XMLTreeNode updatedNode, String xPathToParent)
			throws CXMLComparisonException
	{
		List<CXMLNodeComparisonResult> resultsList = new ArrayList<CXMLNodeComparisonResult>();
		String sXPath = getXPathToNode(xPathToParent, originalNode);

		List<XMLTreeNode> originalChildNodes = originalNode.getChildNodesListByPath(BACKSLASH);
		if ((originalChildNodes.size() == 0)
				|| ((originalChildNodes.size() == 1) && isTextNode(originalChildNodes.get(0))))
		{
			// Current node doesn't have children. We should compare its value
			// with value from updated node:
			String sOriginalNodeValue = originalNode.getValue();
			String sUpdatedNodeValue = updatedNode.getValue();
			CXMLNodeComparisonResult.ComparisonResult comparisonResult =
					(CStringUtils.equals(sOriginalNodeValue, sUpdatedNodeValue)) ?
							CXMLNodeComparisonResult.ComparisonResult.NOT_CHANGED :
							CXMLNodeComparisonResult.ComparisonResult.MODIFIED;
			resultsList.add(new CXMLNodeComparisonResult(
					sOriginalNodeValue, sUpdatedNodeValue, comparisonResult, sXPath));
		}
		else
		{
			// Current node has children. We should recursively call current
			// method for all child nodes:
			for (XMLTreeNode currentOriginalChild: originalChildNodes)
			{
				CNodeIndex nodeIndex = new CNodeIndex(currentOriginalChild);
				XMLTreeNode currentUpdatedChild = 
						nodeIndex.getRelatedChildNode(updatedNode, currentOriginalChild.getXMLTag());
				if (currentUpdatedChild == null || 
						!CStringUtils.equals(currentOriginalChild.getXMLTag(), currentUpdatedChild.getXMLTag()))
				{
					CXMLNodeComparisonResult missingComparableNodeResult =
							new CXMLNodeComparisonResult(
									currentOriginalChild.getValue(),
									CStringUtils.EMPTY_STRING,
									CXMLNodeComparisonResult.ComparisonResult.COMPARABLE_NODE_IS_ABSENT,
									sXPath);
					resultsList.add(missingComparableNodeResult);
				}
				else
				{
					resultsList.addAll(compareNodes(currentOriginalChild, currentUpdatedChild, sXPath));
				}
			}
		}

		return resultsList;
	}

	/**
	 * Checks given XML node to be simple text node without children. Such node
	 * can be Text- or CDATA-node.
	 *
	 * @param node XNLTreeNode to check.
	 * @return true if node has type XMLConsts.TYPE_TEXT or XMLConsts.TYPE_CDATA.
	 */
	private boolean isTextNode(XMLTreeNode node)
	{
		return ((node.getType() == XMLConsts.TYPE_TEXT)
				|| (node.getType() == XMLConsts.TYPE_CDATA));
	}

	/**
	 * Returns XPath to specified node. If there are several siblings with
	 * the same name then each sibling will have square brackets with the number.
	 * "Unique" nodes won't have such numbers.
	 *
	 * @param xPathToParent String with XPath to parent node.
	 * @param node XMLTreeNode to get XPath.
	 * @return String with XPath to given node.
	 */
	private String getXPathToNode(String xPathToParent, XMLTreeNode node)
	{
		String sXPath = xPathToParent + BACKSLASH + node.getXMLTag();
		if (hasSiblingsWithSameTag(node))
		{
			CNodeIndex index = new CNodeIndex(node);
			sXPath += index.getXPathRepresentation();
		}
		return sXPath;
	}

	/**
	 * Checks if there are other nodes with the same tag as given node on the same level
	 * as given (sibling nodes).
	 * 
	 * @param nodeToCheck node with tag and level for search.
	 * @return true if there are sibling nodes with the same tag.
	 */
	private boolean hasSiblingsWithSameTag(XMLTreeNode nodeToCheck)
	{
		XMLTreeNode parentNode = nodeToCheck.getParentNode();
		int nNodesWithSameNameCount = 
				parentNode.getChildNodesListByTag(nodeToCheck.getXMLTag()).size();
		return nNodesWithSameNameCount > 1;
	}

	/**
	 * Auxiliary class for operations related to nodes index. Index - is a node's position 
	 * between siblings with the same tag.
	 * Class is static because there is no need to have connection with Comparator instance.
	 */
	private static class CNodeIndex implements Serializable
	{
		private static final long serialVersionUID = 6160666104762970398L;
	
		private int m_nIndex;

		/**
		 * Creates new index for given node.
		 * 
		 * @param node XML node to create index for.
		 */
		CNodeIndex(XMLTreeNode node)
		{
			XMLTreeNode parentNode = node.getParentNode();
			m_nIndex = 0;
			for (XMLTreeNode currentNode: parentNode.getChildNodesByTag(node.getXMLTag()))
			{
				m_nIndex++;
				// We check by node's memory address because of two reasons:
				// 1. XMLTreeNode.equals() is bad: it just compares nodes tags and types. So two
				// different nodes with the same tag but different children will be "equals".
				// 2. We get parent node not from constructor parameter but from given node, so we
				// can be sure that child nodes List will contain the same object as we have in the
				// given "node" pointer.
				if (node == currentNode)
				{
					break;
				}
			}
		}

		/**
		 * Returns child of the given parent node with specified tag and at the index
		 * specified in the current CNodeIndex instance.
		 * If given parent doesn't contain children with specified tag or current index
		 * is too big then method will return null.
		 * 
		 * @param parentNode XML node to check for required child.
		 * @param childTag String with tag for required child.
		 * @return found node with specified tag and at the current position or null.
		 */
		XMLTreeNode getRelatedChildNode(XMLTreeNode parentNode, String childTag)
		{
			Iterator<XMLTreeNode> iterator = parentNode.getChildNodesByTag(childTag).iterator();
			XMLTreeNode childNode = null;
			int currentIndex = 0;
			while (currentIndex++ < m_nIndex)
			{
				if (iterator.hasNext())
				{
					childNode = iterator.next();
				}
				else
				{
					// Index is too big and there is no child with specified tag at 
					// the required position. We should return null:
					return null;
				}
			}
			return childNode;
		}
		
		/**
		 * Returns String representation of the node's position as it's used in XPath.
		 * 
		 * @return  String in the following format: "[node_position]"
		 */
		public String getXPathRepresentation()
		{
			return new StringBuilder("[").append(m_nIndex).append("]").toString();
		}

		/**
		 * Returns String representation of the node
		 * 
		 * @return String.
		 */
		@Override
		public String toString()
		{
			return getClass().getSimpleName() + "[" + m_nIndex + "]";
		}
	}
}
