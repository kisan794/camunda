/*
 * @(#)$RCSfile: CNodeMaskMarker.java,v $ $Revision: 1.2 $ $Date: 2013/08/09 06:32:59 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/mask/CNodeMaskMarker.java,v $
 *
 * Copyright 2001-2013 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  2013-07-15 K.Ovchinnikov			Created
 */
package hireright.sdk.html.mask;

import hireright.sdk.consts.Logical;
import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLTreeNode;

/**
 * Class for marking nodes as masked/unmasked.
 *
 * @author  Kirill Ovchinnikov
 * @version $Revision: 1.2 $ $Date: 2013/08/09 06:32:59 $ $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/mask/CNodeMaskMarker.java,v $
 */
public class CNodeMaskMarker
{

	/** class source version **/
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	private static final String ATTR_NAME_MASK_MODE = "isMaskable";
	
	/**
	 * Marks node as 'unmasked'.
	 */
	public static void markUnmasked(XMLTreeNode node)
	{
		if(node != null)
		{
			String attrText = node.getAttribText(ATTR_NAME_MASK_MODE);
			if(attrText == null || Logical.TRUE_FULL_LOWER_CASE.equals(attrText))
			{
				node.addAttribNode(ATTR_NAME_MASK_MODE, Logical.FALSE_FULL_LOWER_CASE);
			}
		}
	}

	/**
	 * Marks all children nodes as 'masked'.
	 */
	public static void markAllChildrenMasked(XMLObject xmlObject)
	{
		xmlObject.updateAttributeValues(ATTR_NAME_MASK_MODE,
				Logical.FALSE_FULL_LOWER_CASE, Logical.TRUE_FULL_LOWER_CASE);
	}
	
}
