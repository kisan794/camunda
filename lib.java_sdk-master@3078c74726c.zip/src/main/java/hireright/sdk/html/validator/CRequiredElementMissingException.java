package hireright.sdk.html.validator;

/**
 * @author D.Travin
 * Date: Jun 6, 2003
 * @version experimental
 */
public class CRequiredElementMissingException extends Exception
{
	public CRequiredElementMissingException( String sError )
	{
		super( sError );
	}
}
