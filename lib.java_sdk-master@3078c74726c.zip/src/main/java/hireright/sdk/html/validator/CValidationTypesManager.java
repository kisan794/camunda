/*
 * @(#)$RCSfile: CValidationTypesManager.java,v $ $Revision: 1.12 $ $Date: 2009/08/28 06:58:35 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationTypesManager.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2002.07.22 A.Nesterov	Created
 *	2002.10.01 A.Nesterov	Default library now can be stored as multiple files, listed in LIBRARY_LIST_FILENAME
 *  2003.02.11 A.Nesterov	loadDefaultLibrary() now explictly closes all opened streams
 *  2003.02.11 A.Nesterov	Enchanced exceptions logging
 *  2003.02.17 A.Nesterov	LoadDefaultLibrary() method is now declared as synchronized
 *  2005-08-15 A.Solntsev	Class XHTMLValidatorSettings moved upper to class hireright.sdk.html.validator
 *  2006-10-12 A.Solntsev	Removed static initialization block (its failure causes ClassnotFoundException)
 *  2006-10-31 A.Solntsev	implements Serializable
 *  2007-11-26 A.Solntsev	NetTracking.registerUrl();
 *  2008-08-27 A.Solntsev	Removed using CTraceLog
 *  2008-12-29 A.Solntsev	Added java setting "VALIDATOR_LIB_PATH" (overridden in unit-tests)
 *  2008-12-29 Y.Shneykin	Changed "LIBRARY_LIST_FILENAME".
 */
package hireright.sdk.html.validator;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.net.NetTracking;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.URL;

/**
 * A Manager class for accessing validation types inside librarys.
 *
 * @author Alexander Nesterov
 * @since July 2002
 * @version $Revision: 1.12 $ $Date: 2009/08/28 06:58:35 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationTypesManager.java,v $
 */
public class CValidationTypesManager implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.12 $ $Author: asolntsev $";
	
	/**
	 * Name of file - container of validation library names.
	 */
	private static final String LIBRARY_LIST_FILENAME = "active_libs_forms.lst";

	private static CValidationTypesLibrary m_defaultLibrary;

	/**
	 * This method gets validation type object from default library.
	 *
	 * @param sType type id
	 * @return CValidationType object or null if no matched type found
	 */
	public static CValidationType getValidationType(String sType)
	{
		if (m_defaultLibrary == null)
		{
			synchronized (LIBRARY_LIST_FILENAME)
			{
				if (m_defaultLibrary == null)
				{
					tryLoadDefaultLibrary();
				}
			}
		}

		return m_defaultLibrary.getValidationType(sType);
	}

	/**
	 * @throws RuntimeException if reading VXML failed
	 */
	private static void tryLoadDefaultLibrary()
	{
		final String LOG_SRC = "JAVA:CValidationTypesManager::static";
		// CTraceLog.debug("Loading common validation types library: BEGIN", LOG_SRC);

		try
		{
			m_defaultLibrary = loadDefaultLibrary();
			// CTraceLog.debug("Loading common validation types library: END " + m_defaultLibrary == null ? "(ERROR)" : "(SUCCESS)", LOG_SRC);
		}
		catch (IOException ioe)
		{
			CTraceLog.fatal(ioe, LOG_SRC, "Error loading default library");
			// CTraceLog.debug("Loading common validation types library: END (ERROR)", LOG_SRC);
			throw new CRuntimeException(ioe, CValidationTypesManager.class.getName()+".tryLoadDefaultLibrary()");
		}
	}

	/**
	 *
	 * @return newly created instance of CValidationTypesLibrary
	 * @throws IOException
	 * @throws RuntimeException
	 */
	private static CValidationTypesLibrary loadDefaultLibrary() throws IOException
	{
		//prepare resource path
		StringBuffer sResPathURL = new StringBuffer(XHTMLValidatorSettings.getDefaultTypesLibrarysPathURL());
		int nResPathURLLength = sResPathURL.length();
		String sURL = null;
		BufferedReader streamReader = null;

		try
		{
			//Open list of librarys
			sURL = sResPathURL.append(LIBRARY_LIST_FILENAME).toString();
			sResPathURL.setLength(nResPathURLLength);

			NetTracking.registerUrl(sURL);
			
			streamReader = new BufferedReader(new InputStreamReader((new URL(sURL)).openStream()));
		}
		catch (Exception e)
		{
			if (streamReader!=null)
				streamReader.close();

			CProperties params = new CProperties();
			params.setProperty("url", sURL);
			params.setProperty("libraryList", LIBRARY_LIST_FILENAME);

			CTraceLog.fatal(e, CValidationTypesLibrary.class.getName()+".loadDefaultLibrary()", params);
			throw new CRuntimeException("Cant open libraries listing from: " + sURL,
					e, CValidationTypesManager.class.getName()+".loadDefaultLibrary()", params);
		}

		InputStreamReader libraryFileReader;
		CValidationTypesLibrary library = new CValidationTypesLibrary();

		try
		{
			//load all listed files
			while ((sURL = streamReader.readLine()) != null)
			{
				//create library URL
				sURL = sResPathURL.append(sURL).toString();
				sResPathURL.setLength(nResPathURLLength);
				//load types from file
				libraryFileReader = new InputStreamReader((new URL(sURL)).openStream());
				library.loadTypes(libraryFileReader, sURL);
				libraryFileReader.close();
			}
		}
		catch (Exception e) // XMLObjectException, IOException
		{
			CProperties params = new CProperties();
			params.setProperty("url", sURL);
			params.setProperty("libraryList", LIBRARY_LIST_FILENAME);

			CTraceLog.fatal(e, sURL, params);
			throw new CRuntimeException("Error reading library: " + sURL, e,
				CValidationTypesManager.class.getName()+".loadDefaultLibrary()", params);
		}
		finally
		{
			if (streamReader!=null)
				streamReader.close();
		}

		return library;
	}
}
