/*
 * @(#)$RCSfile: CValidationConfigurationException.java,v $ $Revision: 1.2 $ $Date: 2008/11/21 11:33:18 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationConfigurationException.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	A.Solntsev			2006-11-18	created
 */
package hireright.sdk.html.validator;

import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;

/**
 * @author Andrei Solntsev
 * @version "$Revision: 1.2 $, $Date: 2008/11/21 11:33:18 $, $Author: cvsroot $"
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationConfigurationException.java,v $
 */
public class CValidationConfigurationException extends CRuntimeException
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	public CValidationConfigurationException(String message, Throwable cause)
	{
		super(message, cause);
	}
	
	public CValidationConfigurationException(String message, Throwable cause, CProperties properties)
	{
		super(message, cause, properties);
	}

}
