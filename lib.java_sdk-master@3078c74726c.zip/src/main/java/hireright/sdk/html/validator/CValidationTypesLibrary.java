/*
 * @(#)$RCSfile: CValidationTypesLibrary.java,v $ $Revision: 1.8 $ $Date: 2015/11/02 20:15:52 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationTypesLibrary.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 * 
 * History:
 * 2002.07.22	A.Nesterov		Created
 * 2002.09.30	A.Nesterov		Method init(XMLTreeNode libNode) renamed to loadTypes(XMLTreeNode libNode) and made public
 * 2002.09.30	A.Nesterov		void loadTypes(Reader reader)
 * 2004-01-27	S.Prokopov		Added support for comments in validation library
 * 2006-10-31	A.Solntsev		removed "throws Exception"
 * 2015-07-23 M.Lukyanenko		Added encoding validation mode
 */
package hireright.sdk.html.validator;
import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.parser.XMLObjectException;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.utils.XHTMLInjector;

import java.io.Reader;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * A validation types library class.
 * 
 * @author Alexander Nesterov
 * @since July 2002
 * @version $Revision: 1.8 $ $Date: 2015/11/02 20:15:52 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationTypesLibrary.java,v $
 */
public final class CValidationTypesLibrary implements Serializable
{
	private static final long serialVersionUID = 4337751482864856940L;

	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	/**
	 * @serial contains (String, CValidationType) pairs
	 */
	private Map<String, CValidationType> m_htValidationTypes = new HashMap<String, CValidationType>(10);
	
	public final static String TAG_VALIDATION_TYPES_LIB = "validation_types_lib";
	public final static String ATTRIBUTE_VERSION = "version";
	public final static String ATTRIBUTE_ENCODING = "encoding";
	public final static float VERSION_v1_2 = Float.parseFloat("01.20");
	public final static float VERSION_v1_0 = 1;
	private float m_version = VERSION_v1_0;
	
	/**
	 * Creates library object from XML file.
	 *
	 * XML Example:
	 *
	 * <?xml version="1.0" encoding="UTF-8"?>
	 * 	<validation_types_lib version="01.20">
	 *
	 * 	<validation_type type="ssn_r">
	 * 			<pattern><![CDATA[/d/d/d/d/d/d/d/d/d]]></pattern>
	 * 			<required>true</required>
	 * 	</validation_type>
	 * 	<validation_type type="txt_128">
	 * 			<required>false</required>
	 * 			<min_length>0</min_length>
	 * 			<max_length>128</max_length>
	 * 	</validation_type>
	 * </validation_types_lib>
	 * 
	 * @param reader
	 * @param sURL any String (typically URL of VXML). It will be used for 
	 * 				throwing Exception in case of invalid VXML.
	 *  
	 * @throws XMLObjectException 
	 *
	 */
	public CValidationTypesLibrary(Reader reader, String sURL) throws XMLObjectException
	{
		loadTypes(reader, sURL);
	}
	
	/**
	 * Creates library object from <validation_types_lib> node.
	 *
	 */
	public CValidationTypesLibrary(XMLTreeNode libNode) 
	{
		this(libNode, CValidator.VALIDATION_DEFAULT_ENCODING);
	}

	/**
	 * Creates library object from <validation_types_lib> node.
	 *
	 */
	public CValidationTypesLibrary(XMLTreeNode libNode, String sEncoding) 
	{
		loadTypes(libNode, sEncoding);
	}

	/**
	 * Creates empty library
	 */
	public CValidationTypesLibrary()
	{
	}

	/**
	 * Loads types from XML file.
	 * NB! These types are begin appended to already loaded types. 
	 * 
	 * @throws XMLObjectException 
	 */
	protected final void loadTypes(Reader reader, String sURL) throws XMLObjectException 
	{
		XHTMLInjector injector = new XHTMLInjector(reader, sURL);
		loadTypes(injector.getOutputRootNode().getChildNodeByType(XMLConsts.TYPE_NODE), CValidator.VALIDATION_DEFAULT_ENCODING);
	}

	/**
	 * Loads types from <validation_types_lib> node. Already loaded types are not cleared.
	 */
	public void loadTypes(XMLTreeNode libNode, String sEncoding) 
	{
		XMLTreeNode attributeVersion = libNode.getAttribNode(ATTRIBUTE_VERSION);
		
		if (attributeVersion != null)
		{
			String version = attributeVersion.getText();
			if (version!=null && version.length()>0)
				m_version = Float.parseFloat(version);
		}
		
		XMLTreeNode typeNode = (XMLTreeNode)libNode.firstChildNode();

		while (typeNode != null)
		{
			int nNodeType = typeNode.getType();

			if (nNodeType == XMLConsts.TYPE_NODE)
			{
				CValidationType vtype = new CValidationType(typeNode);
				vtype.setVersion(m_version);
				m_htValidationTypes.put(typeNode.getAttribText("type"), vtype);
			}

			typeNode = typeNode.getNextXmlNode();
		}
	}

	/**
	 * Returns CValidationType object from library
	 *
	 * @param sType type id to search for
	 * @return CValidationType object or null if no matched type found;
	 */
	public final CValidationType getValidationType(String sType)
	{
		return m_htValidationTypes.get(sType);
	}
	
	public String toString()
	{
		return "Validation Types Library " + m_version + " (" + m_htValidationTypes.size() + " types)";
	}
}

