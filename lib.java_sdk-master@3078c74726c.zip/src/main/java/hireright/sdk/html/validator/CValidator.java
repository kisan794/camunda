/*
 * @(#)$RCSfile: CValidator.java,v $ $Revision: 1.39 $ $Date: 2015/11/02 20:15:46 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidator.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *		2002.07.22: Created
 *		2002.10.08 A.Nesterov: 	Added required groups support
 *		2002.10.08 A.Nesterov: 	Removed suppord for IGNORED status
 *		2003.10.08 A.Nesterov: 	Added index conditons support
 *		2003.10.14 A.Podlipski: Added "ignore_index" feature
 *		2003.12.11 A.Nesterov:	Modified parameter list of validate() method
 *
 *  	2004-01-26 S.Prokopov	Added support for validating dates
 *		2004-02-09 S.Prokopov	Removed check isGroup empty for validation group
 *		2004-02-20 A.Nesterov	Added support for XML path based id for validation element
 *		2004-09-07 A.Solntsev	CHttpParametersStorage is rewritten
 *		2005-01-04 A.Plohotnichenko	getParametersCountForGroup, validateValidationGroupByDate
 *								now uses getNodeByPath if element has path based id.
 *    	2005-01-19 A.Nesterov	removed code that throws exceptions
 *    							fixed bugs with validation of missing parameters
 *		2005-01-25 A.Solntsev	Added more properties to CXMLTemplateException.
 *		2005-05-31 P.Bushuk		java_sdk_v2-5-29: Added method validateValidationCompareDate to validate From and To dates in sequential order.
 *								injectInputTips return true if status was changed or added. Otherwise return false.
 *		2005-08-31 V.Nikitin	Method validateElement was updated. Warning "Missing parameter node:" generation moved below.
 *								Goal: if parameter is missing and it is nonrequired no warning message generated.
 *		2005-11-11 A.Plohotnichenko	Validation mode flags are added. Constructors set validation mode.
 *		2006-04-10 I.Suits		Added setValidAttribute() method
 *		2006-05-17 A.Zinovjev	Added node attributes validation support
 *		2006-10-12 A.Solntsev	Used new class CElementValidationResult for injecting detailed info about invalid elements
 *		2007-01-09 A.Solntsev	Added attribute XA_DETAILS
 *		2007-03-xx A.Solntsev	addValidationSummary(): Added list of invalid elements IDs (like "edu_end_date#2")
 *		2007-06-22	E.Tonkoshkurov	validateValidationGroupByDate() method was changed to handle current date shifting
 *		2007-06-19	A.Larin	validateValidationGroupByDate() updated to support ISO dates
 *		2007-02-07	A.Larin	added types date_from, date_to for comparing dates stored in single "date" nodes
 *		2007-10-01	A.Lipatov unnecessary variable m_nTotalInvalid was removed. List m_aInvalidElements 
 *								was converted to Set. Method validate() was updated to add into summary unique 
 *								invalid elements count.
 *	Sergei Prokopov		2007-10-16	added getInvalidElementsQuantity, validate(IHttpParametersStorage, boolean, boolean)
 *		2007-12-06	A.Solntsev	Fixed NullPointerException in method validateValidationGroupByDate()
 *		2007-12-06	E.Tonkoshkurov	Removed application XML saving into WARNING in the validateElement() method.
 *		2008-01-17	M.Karpov		Support for new validation group CValidationGroupElement.TYPE_DATE added
 *		2008-03-05	M.Elshin		addInvalidElementToSet method was added. Support for counting number
 *														of invalid as a single invalid field according to attribute
 *														component_name in element tag was added.
 *		2008-03-19	M.Karpov		Support for new validation group TYPE_DATE_COMPARE_OR_EQUALS added
 *		2008-05-13	E.Tonkoshkurov	Fixed error in the isEmptyGroup() method.
 *		2008-05-28	A.Lipatov		Methods getMonthToValidate() and getDayToValidate() was added to fix 
 *														bug with comparing current date to provided by user date.
 *		2008-08-26	A.Solntsev	Added methods getInvalidElementsCount(), getInvalidElements() for using in unit-tests 
 *		2008-09-01	L.Ruzanova	Method isEmptyGroup() was modified in order to support CValidationGroupElement.
 *		2009-02-06	M.Elshin		Following methods were added getShiftedCurrentDate, getIntegerByString.
 *														Method validateValidationGroupByDate was refactored a little,
 *														logic to treat partially filled date as invalid was added.
 *		2009-02-10	A.Solntsev		Fixed broken logic conditions in validateValidationCompareDate()
 *		2010-05-05	Y.Shneykin		Fixed method processListValidation() to use required group properly 
 *											(search for multiple nodes, not the first one only).
 *		2010-12-06	E.Kapustin		Support for new validation group TYPE_ISO_DATE added
 *		2011-03-09	P.Sizov			Added new attribute for vxml element: attributeRequired.
 *		2012-11-08  M.Hryshyn		Added supporting any_value_provided_group type of validation group
 *		2013-11-20  K.Ovchinnikov	Added shift support for iso dates
*		2014-03-20 N.Danilov		added possibility to-pre validate a document (mark required fields)
*		2015-07-23 M.Lukyanenko		Added encoding validation mode
 *  	2022-11-29  J.Zaporozhets    TYPE_DATE_COMPARE_OR_EQUALS_SECTION validation in section
 */
package hireright.sdk.html.validator;
import hireright.sdk.consts.Constants;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.utils.CXMLTemplateException;
import hireright.sdk.html.utils.IHttpParametersStorage;
import hireright.sdk.html.validator.CValidationElement.CSubElementsList;
import hireright.sdk.util.CDateTime;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

import java.io.Serializable;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Simple XML data validator implementation.
 *
 * @author Alexander Nesterov
 * @author Sergei Prokopov
 * @version "$Revision: 1.39 $, $Date: 2015/11/02 20:15:46 $, $Author: cvsroot $"
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidator.java,v $
 */
public final class CValidator implements Serializable
{
	private static final long serialVersionUID = -4017700708070457619L;

	protected static final String CLASS_VERSION = "$Revision: 1.39 $ $Author: cvsroot $";
	
	//XML Attributes
	public static final String XA_VALID = "valid";
	private static final String XA_ATTR_VALID_POSTFIX = "_valid";
	public static final String XA_DETAILS = "details";

	//Validation mode flags
	public static final int VALIDATION_MODE_FORMAT = 0x0001;
	public static final int VALIDATION_MODE_REQUIRED = 0x0002;
	public static final int VALIDATION_MODE_DUPLICATED = 0x0004;
	public static final int VALIDATION_MODE_ENCODING = 0x0008;

	public static final String VALIDATION_DEFAULT_ENCODING = "UTF-8";
	private CValidationSet	m_validationSet;
	private int						m_nValidationMode;
	private int						m_nTotalValid;
	private Set<String>		m_sInvalidElements;
	
	private boolean m_bPreValidationOnly = false;
	


	private static final String MESSAGE_INVALID_VALUE = "Invalid value";
	
	private static final String MESSAGE_REQUIRED_VALUE = "Required element is empty";

	private static final String ATTR_DOCUMENT_ID = "documentID";

	/**
	 * Constructs validator object using validation set.
	 * <p>
	 * @param validationSet	Validation set to validate with.
	 */
	public CValidator(CValidationSet validationSet)
	{
		m_validationSet = validationSet;
		m_nValidationMode = VALIDATION_MODE_REQUIRED |
						VALIDATION_MODE_FORMAT |
						VALIDATION_MODE_DUPLICATED;
		
		if(!CStringUtils.equalsIgnoreCase(VALIDATION_DEFAULT_ENCODING, validationSet.getValidationEncoding()))
		{
			m_nValidationMode |= VALIDATION_MODE_ENCODING;
		}
	}

	/**
	 * Constructs validator object using validation set.
	 * <p>
	 * @param validationSet	Validation set to validate with.
	 * @param nValidationMode Validation mode flags.
	 */
	public CValidator(CValidationSet validationSet, int nValidationMode)
	{
		m_validationSet = validationSet;
		m_nValidationMode = nValidationMode;
	}

	/**
	 * Assign validation set to validator.
	 * <p>
	 * @param validationSet	to validate with. Can't be null.
	 */
	public void setValidationSet(CValidationSet validationSet)
	{
		m_validationSet = validationSet;
	}

	
	public boolean isPreValidationOnly() 
	{
		return m_bPreValidationOnly;
	}

	public void setPreVaidationOnly(boolean m_bPreValidationOnly) 
	{
		this.m_bPreValidationOnly = m_bPreValidationOnly;
	}
	
	/**
	 * Validates single parameter that match element
	 *
	 * @param element			validation element
	 * @param nIndex			parameter index (1 - based)
	 * @param paramStorage		data to be validated.
	 * @param bInjectInputTips 	set true to inject results back into xml.
	 * @param parameterNode		existing parameter node data for attribute validation
	 */
	private boolean validateSingleParameter(CValidationElement element,
					int nIndex,
					IHttpParametersStorage paramStorage,
					boolean bInjectInputTips,
					XMLTreeNode parameterNode)
	{
		XMLTreeNode attrParamNode = parameterNode;

		if (element.hasPathBasedId())
		{
			// If attribute node information was not provided,
			// then getting node by path
			if (attrParamNode == null)
			{
				attrParamNode = element.isIgnoreIndex() ? paramStorage.getNodeByPath(element.getId(), 1) : paramStorage.getNodeByPath(element.getId(), nIndex);
			}

			// Retrive parameter by path
			return validateElement(element, attrParamNode, nIndex, paramStorage, bInjectInputTips);
		}
		else
		{
			// If attribute node information was not provided,
			// then getting node by id
			if (attrParamNode == null)
			{
				attrParamNode = element.isIgnoreIndex() ? paramStorage.getParameter(element.getId(), 1) : paramStorage.getParameter(element.getId(), nIndex);
			}

			// Retrive parameter by id
			return validateElement(element, attrParamNode, nIndex, paramStorage, bInjectInputTips);
		}
	}

	/**
	 * Validates all parameters that match element
	 * @param element
	 *            validation element
	 * @param paramStorage
	 *            data to be validated.
	 * @param bInjectInputTips
	 *            set true to inject results back into xml.
	 * @param parameterNode
	 *            existing parameter node data for attribute validation
	 */
	private boolean validateAllParameters(CValidationElement element,
					IHttpParametersStorage paramStorage,
					boolean bInjectInputTips,
					XMLTreeNode parameterNode)
	{
		boolean bResult = true;
		int nParamCount = 0;

		if (element.hasPathBasedId())
		{
			// Get list of parameters
			Iterator<XMLTreeNode> iterator = paramStorage.getNodesByPath(element.getId()).iterator();

			// Process one by one
			for (int i = 1; iterator.hasNext(); i++)
			{
				bResult = validateElement(element, (parameterNode != null ? parameterNode
								: (XMLTreeNode) iterator.next()), i, paramStorage, bInjectInputTips)
								&& bResult;

				nParamCount++;
			}
		}
		else
		{
			nParamCount = paramStorage.getParameterCount(element.getId());

			// Try to find multiple nodes with given id
			for (int i = 1; i <= nParamCount; i++)
			{
				bResult = validateElement(element, (parameterNode != null ? parameterNode : (paramStorage
								.getParameter(element.getId(), i))), i, paramStorage, bInjectInputTips)
								&& bResult;
			}
		}

		if (nParamCount == 0)
		{
			// Try parent element parameter
			// or if parameter is missing we still need to validate element
			// Read comments inside validateElement function
			// Additionally, store element validation result info provided
			// parameter node (attrParamNode) if validating attributes

			bResult = validateElement(element, parameterNode, 1, paramStorage, bInjectInputTips);
		}

		return bResult;
	}

	/**
	 * Validates XML
	 * <p>
	 * @param paramStorage			storage with XML object
	 * @param bInjectInputTips	flag to inject results back to xml.
	 * @return <code>boolean</code>
	 */
	public boolean validate(IHttpParametersStorage paramStorage, boolean bInjectInputTips)
	{
		return validate(paramStorage, bInjectInputTips, true);

	}

	/**
	 * Validates XML
	 * <p>
	 * @param paramStorage			injector with data to be validated.
	 * @param bInjectInputTips	flag to inject results back to xml.
	 * @param bInjectResult			flag that identifies when to inject validtion results into XML
	 * @return <code>boolean</code>
	 */
	public boolean validate(IHttpParametersStorage paramStorage, boolean bInjectInputTips, boolean bInjectResult)
	{
		m_nTotalValid = 0;

		if (m_sInvalidElements== null)
			m_sInvalidElements = new HashSet<String>(10);
		else
			m_sInvalidElements.clear();

		boolean bResult = true;
		int nParamCount;

		for (IValidationElement element : m_validationSet.getElements() )
		{
			if (element instanceof CValidationElement)
			{
				bResult = validateAllParameters((CValidationElement) element, paramStorage, bInjectInputTips,
								null)
								&& bResult;
			}
			else if (element instanceof CRequiredGroupElement)
			{
				nParamCount = getParametersCountForGroup((CRequiredGroupElement) element, paramStorage);

				if (nParamCount == 0)
					nParamCount++;

				// Try to find multiple nodes with given id
				for (int i = 1; i <= nParamCount; i++)
					bResult = validateRequiredGroup((CRequiredGroupElement) element, i, paramStorage,
									bInjectInputTips)
									&& bResult;
			}
			else if (element instanceof CValidationGroupElement)
			{
				nParamCount = getParametersCountForGroup((CValidationGroupElement) element, paramStorage);

				if (nParamCount == 0)
					nParamCount++;

				// Try to find multiple nodes with given id
				for (int i = 1; i <= nParamCount; i++)
					bResult = validateValidationGroup((CValidationGroupElement) element, i, paramStorage,
									bInjectInputTips)
									&& bResult;
			}
		}

		if (bInjectResult && !m_bPreValidationOnly)
		{
			int iInvalidElementsCount = m_sInvalidElements.size();
			
			paramStorage.addValidationSummary(m_nTotalValid, iInvalidElementsCount, iInvalidElementsCount, 
					m_sInvalidElements);
		}

		return bResult;
	}

	/**
	 * Returns count of parameter in specified group.
	 * <p>
	 * @param group			of required elements.
	 * @param paramStorage	injector with data to be validated.
	 */
	private final static int getParametersCountForGroup(CGroup group, IHttpParametersStorage paramStorage)
	{
		// Assusme that first parameter count equals count of the others
		for (IValidationElement element : group.getGroupElements())
		{
			if (element instanceof CValidationElement)
			{
				CValidationElement validationElement = (CValidationElement) element;
				if (validationElement.hasPathBasedId())
					return paramStorage.getNodesByPath(validationElement.getId()).size();
				else
					return paramStorage.getParameterCount(((CValidationElement) element).getId());
			}
		}

		return 0;
	}

	/**
	 * Check that required group is empty.
	 * <p>
	 * @param group
	 *            of elements.
	 * @param nIndex
	 *            of element in group.
	 * @param paramStorage
	 *            injector with data to be validated.
	 * @rerturn true if group is empty.
	 */
	private final boolean isEmptyGroup(IGroup group, int nIndex, IHttpParametersStorage paramStorage)
	{
		XMLTreeNode node;

		// Check all parameters for empty value
		for (IValidationElement element : group.getGroupElements())
		{
			if (element instanceof CValidationElement)
			{
				if (!((CValidationElement) element).checkIndexCondition(nIndex))
					continue; // If element condition does not match, skip this element

				if (((CValidationElement) element).hasPathBasedId())
					node = paramStorage.getNodeByPath(((CValidationElement) element).getId(), nIndex);
				else
					node = paramStorage.getParameter(((CValidationElement) element).getId(), nIndex);

				if (node != null && node.getText(XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA).length() != 0)
					return false;
			}
			else if (element instanceof CRequiredGroupElement)
			{
				if (!isEmptyGroup((CRequiredGroupElement) element, nIndex, paramStorage))
					return false;
			}
			else if (element instanceof CValidationGroupElement)
			{
				 if (!isEmptyGroup((CValidationGroupElement) element, nIndex, paramStorage))
				   return false;
			}
		}

		return true;
	}

	/**
	 * Check validation for required group.
	 *
	 * @param group 			of elements.
	 * @param nIndex 			of element.
	 * @param paramStorage 		injector with data to be validated.
	 * @param bInjectInputTips 	flag to inject results back to xml.
	 * @return 					true if group is valid
	 */
	private boolean validateRequiredGroup(CRequiredGroupElement group, int nIndex,
					IHttpParametersStorage paramStorage, boolean bInjectInputTips)
	{
		// If no values, then nothing to validate...
		if (isEmptyGroup(group, nIndex, paramStorage))
			return true; // All OK

		// Validate params we have got...
		boolean bResult = true;

		for (IValidationElement element : group.getGroupElements())
		{
			if (element instanceof CValidationElement)
			{
				bResult = validateSingleParameter((CValidationElement) element, nIndex, paramStorage,
								bInjectInputTips, null)
								&& bResult;
			}
			else if (element instanceof CRequiredGroupElement)
			{
				bResult = validateRequiredGroup((CRequiredGroupElement) element, nIndex, paramStorage,
								bInjectInputTips)
								&& bResult;
			}
			else if (element instanceof CValidationGroupElement)
			{
				bResult = validateValidationGroup((CValidationGroupElement) element, nIndex, paramStorage,
								bInjectInputTips)
								&& bResult;
			}
		}

		return bResult;
	}

	/**
	 * Check validatuin group.
	 *
	 * If one item in group is not valid, then whole group is invalid.
	 *
	 * @param group	of elements
	 * @param nIndex of element.
	 * @param paramStorage 		injector with data to be validated.
	 * @param bInjectInputTips 	flag to inject results back to xml.
	 * @return 					true if group is valid.
	 */
	private boolean validateValidationGroup(CValidationGroupElement group, int nIndex,
					IHttpParametersStorage paramStorage, boolean bInjectInputTips)
	{
		// Validate params we have got...
		boolean bResult = true;
		
		String strValidationType = group.getGroupValidationType();
		
		if (CValidationGroupElement.TYPE_MULTI_SECTION_REQUIRED.equals(strValidationType))
		{
			bResult = validateMultiSectionRequired(group, paramStorage)	&& bResult;
		}

		if (bResult)
		{
			for (IValidationElement element : group.getGroupElements())
			{
				if (element instanceof CValidationElement)
				{
					bResult = validateSingleParameter((CValidationElement) element, nIndex, paramStorage,
									bInjectInputTips, null)
									&& bResult;
				}
				else if (element instanceof CRequiredGroupElement)
				{
					bResult = validateRequiredGroup((CRequiredGroupElement) element, nIndex, paramStorage,
									bInjectInputTips)
									&& bResult;
				}
				else if (element instanceof CValidationGroupElement)
				{
					bResult = validateValidationGroup((CValidationGroupElement) element, nIndex, paramStorage,
									bInjectInputTips)
									&& bResult;
				}
			}
		}
		// Validate group
		if (bResult)
		{
			if (strValidationType.equals(CValidationGroupElement.TYPE_DATE_FROM_NOW)
							|| strValidationType.equals(CValidationGroupElement.TYPE_DATE_TILL_NOW)
							|| strValidationType.equals(CValidationGroupElement.TYPE_DATE_EQUALS_NOW)
							|| strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE_FROM_NOW)
							|| strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE_TILL_NOW)
							|| strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE_EQUALS_NOW)
							|| strValidationType.equals(CValidationGroupElement.TYPE_DATE)
							|| strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE))
			{
				bResult = validateValidationGroupByDate(strValidationType, group, nIndex, paramStorage,
								bInjectInputTips)
								&& bResult;
			}
			else if (strValidationType.equals(CValidationGroupElement.TYPE_DATE_COMPARE))
			{
				bResult = validateValidationCompareDate(group, nIndex, paramStorage, bInjectInputTips, false)
								&& bResult;
			}
			else if (strValidationType.equals(CValidationGroupElement.TYPE_DATE_COMPARE_OR_EQUALS))
			{
				bResult = validateValidationCompareDate(group, nIndex, paramStorage, bInjectInputTips, true)
								&& bResult;
			}
			else if (strValidationType.equals(CValidationGroupElement.TYPE_DATE_COMPARE_OR_EQUALS_SECTION))
			{
				bResult = validateValidationCompareDateSection(group, paramStorage, bInjectInputTips, true)
								&& bResult;
			}			
			else if (strValidationType.equals(CValidationGroupElement.TYPE_ANY_VALUE_PROVIDED_GROUP))
			{
				bResult = validateValidationGroupByAnyValueProvided(group, nIndex, paramStorage);
			}
			
		}

		return bResult;
	}

	/**
	 * Compare dates. From date should be earlier than To date.
	 *
	 * @param group				of elements.
	 * @param nIndex 			of element.
	 * @param paramStorage 		injector with data to be validated.
	 * @param bInjectInputTips	flag to inject results back to xml.
	 * @param bAllowEquals		flag to allow equals dates
	 * @return 					true if validation group is valid
	 */
	private boolean validateValidationCompareDate(CValidationGroupElement group, int nIndex,
					IHttpParametersStorage paramStorage, boolean bInjectInputTips, boolean bAllowEquals)
	{
		// Find day, month and year values
		Integer nYearFrom = null;
		Integer nMonthFrom = null;
		Integer nDayFrom = null;
		Integer nYearTo = null;
		Integer nMonthTo = null;
		Integer nDayTo = null;

		XMLTreeNode nodeYearFrom = null;
		XMLTreeNode nodeMonthFrom = null;
		XMLTreeNode nodeDayFrom = null;
		XMLTreeNode nodeYearTo = null;
		XMLTreeNode nodeMonthTo = null;
		XMLTreeNode nodeDayTo = null;
		CValidationElement dayFromElement = null;
		CValidationElement monthFromElement = null;
		CValidationElement yearFromElement = null;
		CValidationElement dayToElement = null;
		CValidationElement monthToElement = null;
		CValidationElement yearToElement = null;

		XMLTreeNode node = null;

		for (IValidationElement element : group.getGroupElements())
		{
			if (element instanceof CValidationElement)
			{
				if (((CValidationElement) element).hasPathBasedId())
					node = paramStorage.getNodeByPath(((CValidationElement) element).getId(), nIndex);
				else
					node = paramStorage.getParameter(((CValidationElement) element).getId(), nIndex);

				String strType = ((CValidationElement) element).getType();
				String sNodeText = (node == null ? null : node.getText(XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA));

				if (strType != null && strType.length() > 0 && sNodeText != null && sNodeText.length() > 0)
				{
					if (strType.equals(CValidationElement.TYPE_DAY_FROM))
					// Convert to day
					{
						dayFromElement = (CValidationElement) element;
						nDayFrom = new Integer(sNodeText);
						nodeDayFrom = node;
					}
					else if (strType.equals(CValidationElement.TYPE_MONTH_FROM))
					// Convert to month
					{
						monthFromElement = (CValidationElement) element;
						nMonthFrom = new Integer(sNodeText);
						nodeMonthFrom = node;
					}
					else if (strType.equals(CValidationElement.TYPE_YEAR_FROM))
					// Convert to year
					{
						yearFromElement = (CValidationElement) element;
						nYearFrom = new Integer(sNodeText);
						nodeYearFrom = node;
					}
					else if (strType.equals(CValidationElement.TYPE_DAY_TO))
					// Convert to day
					{
						dayToElement = (CValidationElement) element;
						nDayTo = new Integer(sNodeText);
						nodeDayTo = node;
					}
					else if (strType.equals(CValidationElement.TYPE_MONTH_TO))
					// Convert to month
					{
						monthToElement = (CValidationElement) element;
						nMonthTo = new Integer(sNodeText);
						nodeMonthTo = node;
					}
					else if (strType.equals(CValidationElement.TYPE_YEAR_TO))
					// Convert to year
					{
						yearToElement = (CValidationElement) element;
						nYearTo = new Integer(sNodeText);
						nodeYearTo = node;
					}
					else if (strType.equals(CValidationElement.TYPE_DATE_FROM))
					// Parse a date in a single node
					{
						if (sNodeText.length() > 8)
						{
							// Examples: 1/1/1999; 11/1/1999; 11/11/1999
							nDayFrom = CDateTime.getDay(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
							nMonthFrom = CDateTime.getMonth(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
						}
						else
						{
							// Examples: 11/1999; 1/1999
							nMonthFrom = CDateTime.getMonth(CDateTime.TYPE_MM_YYYY, sNodeText);
						}
						nYearFrom = CDateTime.getYear(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
						dayFromElement = (CValidationElement) element;
						monthFromElement = (CValidationElement) element;
						yearFromElement = (CValidationElement) element;
						nodeDayFrom = node;
						nodeMonthFrom = node;
						nodeYearFrom = node;
					}
					else if (strType.equals(CValidationElement.TYPE_DATE_TO))
					// Parse a date in a single node
					{
						if (sNodeText.length() > 8)
						{
							// Examples: 1/1/1999; 11/1/1999; 11/11/1999
							nDayTo = CDateTime.getDay(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
							nMonthTo = CDateTime.getMonth(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
						}
						else
						{
							// Examples: 11/1999; 1/1999
							nMonthTo = CDateTime.getMonth(CDateTime.TYPE_MM_YYYY, sNodeText);
						}
						nYearTo = CDateTime.getYear(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
						dayToElement = (CValidationElement) element;
						monthToElement = (CValidationElement) element;
						yearToElement = (CValidationElement) element;
						nodeDayTo = node;
						nodeMonthTo = node;
						nodeYearTo = node;
					}
				}
			}
		}

		return  isDateValid(
				nYearFrom,
				nMonthFrom,
				nDayFrom,
				nYearTo,
				nMonthTo,
				nDayTo,				
				nodeYearFrom,
				nodeMonthFrom,
				nodeDayFrom,
				nodeYearTo,
				nodeMonthTo,
				nodeDayTo,				
				dayFromElement, monthFromElement, yearFromElement, 
				dayToElement, monthToElement, yearToElement, 
				bInjectInputTips,
				bAllowEquals,
				nIndex);
	}

	/**
	 * Validate date. Checks for dates that dose not exist.
	 * 
	 * @param bResult
	 * @param nYear year
	 * @param nMonth month
	 * @param nDay day
	 * @param nodeDay day node
	 * @param date Calendar
	 * @return true if date exist and false otherwise
	 */
	private boolean validateDate(Integer nYear, Integer nMonth, Integer nDay,
			XMLTreeNode nodeDay, CValidationElement dayElement, int nIndex, Calendar date)
	{
		boolean bResult = true;
		date.setLenient(false);
		try
		{
			date.set(nYear.intValue(), nMonth == null ? 0 : nMonth.intValue() - 1, nDay == null ? 1
					: nDay.intValue());
			date.getTime();
		}
		catch (IllegalArgumentException e)
		{
			if (nodeDay != null)
			{
				injectInputTips(nodeDay, new CElementValidationResult(CValidationType.INVALID,
						"Date does not exist"));
				addInvalidElementToSet(dayElement, nIndex);
//				m_sInvalidElements.add(nodeDay.getXMLTag());
				bResult = false;
			}
		}
		date.setLenient(true);
		return bResult;
	}

	/**
	 * Converts string value to integer.
	 * @param sValue value to convert.
	 * @return integer value representing by input string or null if conversion is impossible.
	 */
	private Integer getIntegerByString(String sValue)
	{
		try
		{
			return Integer.valueOf(sValue);
		}
		catch(NumberFormatException nex)
		{
			return null;
		}
	}

	/**
	 * Return date that is result of shifting current date for some period
	 * specified by input parameters.
	 * @param value shift value.
	 * @param unit shift value unit.
	 * @return shifted date (current date + shift).
	 */
	private Calendar getShiftedCurrentDate(String value, String unit)
	{
		Calendar dateNow = Calendar.getInstance();
		// Current date shifting
		Integer nDateShift = getIntegerByString(value);
		if (nDateShift != null)
		{
			if ((unit == null) || (CValidationElement.isDayTypeAttr(unit)))
			// if attribute is day type attribute or null then we add value to day field
			{
				dateNow.add(Calendar.DAY_OF_MONTH, nDateShift.intValue());
			}
			else if (CValidationElement.isMonthTypeAttr(unit))
			// if attribute month type attribute then we add value to month field
			{
				dateNow.add(Calendar.MONTH, nDateShift.intValue());
			}
			else if (CValidationElement.isYearTypeAttr(unit))
			// if attribute year type attribute then we add value to year field
			{
				dateNow.add(Calendar.YEAR, nDateShift.intValue());
			}
		}
		// reset time to 00:00:00.0
		dateNow.set(Calendar.HOUR_OF_DAY, 0);
		dateNow.set(Calendar.MINUTE, 0);
		dateNow.set(Calendar.SECOND, 0);
		dateNow.set(Calendar.MILLISECOND, 0);
		return dateNow;
	}

	/**
	 * Check validaton group by date.
	 * 
	 * @param strValidationType validation rule for group. It accepts following types:
	 *            date_from_now, date_equals_now, date_till_now
	 * @param group of elements.
	 * @param nIndex of element.
	 * @param paramStorage injector with data to be validated.
	 * @param bInjectInputTips flag to inject results back to xml.
	 * @return true if validation group is valid
	 */
	private boolean validateValidationGroupByDate(
					String strValidationType,
					CValidationGroupElement group,
					int nIndex,
					IHttpParametersStorage paramStorage,
					boolean bInjectInputTips)
	{
		boolean bResult = true;
		if (strValidationType.equals(CValidationGroupElement.TYPE_DATE_FROM_NOW)
						|| strValidationType.equals(CValidationGroupElement.TYPE_DATE_TILL_NOW)
						|| strValidationType.equals(CValidationGroupElement.TYPE_DATE_EQUALS_NOW)
						|| strValidationType.equals(CValidationGroupElement.TYPE_DATE))
		{
			// Find day, month and year values
			Integer nYear = null, nMonth = null, nDay = null;
			XMLTreeNode nodeYear = null, nodeMonth = null, nodeDay = null, node = null;
			CValidationElement dayElement = null;
			CValidationElement monthElement = null;
			CValidationElement yearElement = null;

			String strType, sNodeText; 

			for (IValidationElement element : group.getGroupElements())
			{
				if (element instanceof CValidationElement)
				{
					if(((CValidationElement)element).hasPathBasedId())
						node = paramStorage.getNodeByPath(((CValidationElement)element).getId(), nIndex);
					else
						node = paramStorage.getParameter(((CValidationElement)element).getId(), nIndex);

					strType = ((CValidationElement) element).getType();

					if (!CStringUtils.isEmpty(strType) && node != null)
					{
						sNodeText = node.getText(XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA);
						if (CValidationElement.isDayTypeAttr(strType))
						// Convert to day
						{
							dayElement = (CValidationElement) element;
							nDay = getIntegerByString(sNodeText);
							nodeDay = node;
						}
						else if (CValidationElement.isMonthTypeAttr(strType))
						// Convert to month
						{
							monthElement = (CValidationElement) element;
							nMonth = getIntegerByString(sNodeText);
							nodeMonth = node;
						}
						else if (CValidationElement.isYearTypeAttr(strType))
						// Convert to year
						{
							yearElement = (CValidationElement) element;
							nYear = getIntegerByString(sNodeText);
							nodeYear = node;
						}
					}
				}
			}
			
			boolean bDateValid = true;
			//If one of date part are not empty all others should be provided
			if (nDay != null || nMonth != null || nYear != null)
			{
				// At first check that all fields specified in date group are filled.
				bDateValid = !(dayElement != null && nDay == null) &&
				!(monthElement != null && nMonth == null) &&
				!(yearElement != null && nYear == null);
			}
			else
			{
				//If all fields are empty then skip validation.
				return true;
			}

			if (bDateValid)
			{
				bDateValid = false;
				// check that year is in yyyy format and in range 1900 - 2100
				if (nYear == null || nYear.intValue() < 1900 || nYear.intValue() > 2100)
				{
					return true; // Skip validating
				}
				Calendar dateNow =
					getShiftedCurrentDate(group.getCurrentDateShiftValue(), group.getCurrentDateShiftUnit());
				Calendar dateToCompare = Calendar.getInstance();
				final Integer nMonthToValidate = getMonthToValidate(nMonth, dateNow);
				final Integer nDayToValidate = getDayToValidate(nYear, nDay, dateNow, nMonthToValidate);
				
				bResult &= validateDate(nYear, nMonthToValidate, nDayToValidate, nodeDay, dayElement, 
						nIndex, dateToCompare);

				// reset time to 00:00:00.0
				dateToCompare.set(Calendar.HOUR_OF_DAY, 0);
				dateToCompare.set(Calendar.MINUTE, 0);
				dateToCompare.set(Calendar.SECOND, 0);
				dateToCompare.set(Calendar.MILLISECOND, 0);

				// 0 if dates are equals
				// value less than 0 if dateToCompare is before the dateNow
				// value greater than 0 if dateToCompare is after the dateNow
				int nDateCompareResult = dateToCompare.getTime().compareTo(dateNow.getTime());
	
				// Analyze result
				if (strValidationType.equals(CValidationGroupElement.TYPE_DATE_FROM_NOW) &&
								nDateCompareResult >= 0 ||
								strValidationType.equals(CValidationGroupElement.TYPE_DATE_EQUALS_NOW) &&
												nDateCompareResult == 0 ||
								strValidationType.equals(CValidationGroupElement.TYPE_DATE_TILL_NOW) &&
												nDateCompareResult <= 0 ||
								strValidationType.equals(CValidationGroupElement.TYPE_DATE))
				{
					bDateValid = true;
				}
			}

			boolean bStatusChanged;
			if (!bDateValid)
			// Set validation failed to nodes
			{
				if (nodeYear != null)
				{
					bStatusChanged = false;
					if (bInjectInputTips)
					{
						bStatusChanged = injectInputTips(nodeYear,
										new CElementValidationResult(CValidationType.INVALID, 
												getErrorMessage( strValidationType, "Invalid date (year)")));
					}

					if (bStatusChanged)
					{
						addInvalidElementToSet(yearElement, nIndex);
					}
				}

				if (nodeMonth != null)
				{
					bStatusChanged = false;
					if (bInjectInputTips)
					{
						bStatusChanged = injectInputTips(nodeMonth,
										new CElementValidationResult(CValidationType.INVALID, 
												getErrorMessage( strValidationType, "Invalid date (month)")));
					}

					if (bStatusChanged)
					{
						addInvalidElementToSet(monthElement, nIndex);
					}
				}

				if (nodeDay != null)
				{
					bStatusChanged = false;
					if (bInjectInputTips)
					{
						bStatusChanged = injectInputTips(nodeDay,
										new CElementValidationResult(CValidationType.INVALID, 
												getErrorMessage( strValidationType, "Invalid date (day)")));
					}

					if (bStatusChanged)
					{
						addInvalidElementToSet(dayElement, nIndex);
					}
				}
			}
			bResult = bResult && bDateValid;
		}
		else if (strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE_FROM_NOW)
						|| strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE_TILL_NOW)
						|| strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE_EQUALS_NOW)
						|| strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE))
		{
			// Find day, month and year values
			Integer nYear = null;
			Integer nMonth = null;
			Integer nDay = null;

			XMLTreeNode nodeSingleDate = null;
			CValidationElement singleDateElement = null;
			XMLTreeNode node;

			for (IValidationElement element : group.getGroupElements())
			{
				if (element instanceof CValidationElement)
				{
					if(((CValidationElement)element).hasPathBasedId())
						node = paramStorage.getNodeByPath(((CValidationElement)element).getId(), nIndex);
					else
						node = paramStorage.getParameter(((CValidationElement)element).getId(), nIndex);

					String strType = ((CValidationElement) element).getType();
					String sNodeText = node.getText(XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA);

					if (strType != null &&
									strType.length() > 0 &&
									sNodeText != null &&
									sNodeText.length() > 0)
					{
						// Parse single date according to format
						nMonth = CDateTime.getMonth(strType, sNodeText);
						nDay = CDateTime.getDay(strType, sNodeText);
						nYear = CDateTime.getYear(strType, sNodeText);
						singleDateElement = (CValidationElement) element;
						nodeSingleDate = node;
					}
				}
			}

			// check that year is in yyyy format and NOT in range 1900 - 2100
			if (nYear == null || nYear.intValue() < 1900 || nYear.intValue() > 2100)
			{
				return true; // Skip validating
			}

			Calendar dateNow = getShiftedCurrentDate(group.getCurrentDateShiftValue(),
				group.getCurrentDateShiftUnit());			

			// reset time to 00:00:00.0
			dateNow.set(Calendar.HOUR_OF_DAY, 0);
			dateNow.set(Calendar.MINUTE, 0);
			dateNow.set(Calendar.SECOND, 0);
			dateNow.set(Calendar.MILLISECOND, 0);

			if(nDay == null)
			{
				dateNow.set(Calendar.DAY_OF_MONTH, 1);
			}

			boolean bDateValid = false;
			Calendar dateToCompare = Calendar.getInstance();
			bResult &= validateDate(nYear, 
					nMonth == null ? new Integer(dateNow.get(Calendar.MONTH) + 1) : nMonth,
					nDay == null ? new Integer(1) : nDay,
					nodeSingleDate, singleDateElement, nIndex, dateToCompare);

			// Analyze rezult
			if (strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE))
			{
				bDateValid = true;
			}
			else 
			{
			
				// reset time to 00:00:00.0
				dateToCompare.set(Calendar.HOUR_OF_DAY, 0);
				dateToCompare.set(Calendar.MINUTE, 0);
				dateToCompare.set(Calendar.SECOND, 0);
				dateToCompare.set(Calendar.MILLISECOND, 0);
	
				// 0 if dates are equals
				// value less than 0 if dateToCompare is before the dateNow
				// value greater than 0 if dateToCompare is after the dateNow
				int nDateCompareResult = dateToCompare.getTime().compareTo(dateNow.getTime());
	
				// Analyze rezult
				if (strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE_FROM_NOW) &&
								nDateCompareResult >= 0 ||
								strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE_EQUALS_NOW) &&
												nDateCompareResult == 0 ||
								strValidationType.equals(CValidationGroupElement.TYPE_ISO_DATE_TILL_NOW) &&
												nDateCompareResult <= 0)
				{
					bDateValid = true;
				}
			}

			boolean bStatusChanged;

			if (!bDateValid)
			// Set validation failed to nodes
			{
				if (nodeSingleDate != null)
				{
					bStatusChanged = false;
					if (bInjectInputTips)
					{
						bStatusChanged = injectInputTips(nodeSingleDate,
										new CElementValidationResult(CValidationType.INVALID, "Invalid date"));
					}

					if (bStatusChanged)
					{
						addInvalidElementToSet(singleDateElement, nIndex);
					}
				}
			}

			bResult = bResult && bDateValid;
		}
		return bResult;
	}

	/**
	 * Check validaton group by one of elements is not empty.
	 * 
	 * @param group of elements.
	 * @param nIndex of element.
	 * @param paramStorage injector with data to be validated.
	 * @param bInjectInputTips flag to inject results back to xml.
	 */
	private boolean validateValidationGroupByAnyValueProvided(
			CValidationGroupElement group,
			int nIndex,
			IHttpParametersStorage paramStorage)
	{
		boolean bResult = false;
		XMLTreeNode node;
		Set<CValidationElement> elementsSet = new HashSet<CValidationElement>();
		for (IValidationElement element : group.getGroupElements())
		{
			if (element instanceof CValidationElement)
			{
				if(((CValidationElement) element).hasPathBasedId())
					node = paramStorage.getNodeByPath(((CValidationElement)element).getId(), nIndex);
				else
					node = paramStorage.getParameter(((CValidationElement)element).getId(), nIndex);

				String sNodeText = node.getText(XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA);

				if (!CStringUtils.isEmpty(sNodeText))
				{
					bResult = true;
				}
				elementsSet.add((CValidationElement) element);
			}
		}
		//mark elements as invalid
		if(!bResult)
		{
			for (CValidationElement failed : elementsSet)
			{
				if(((CValidationElement)failed).hasPathBasedId())
					node = paramStorage.getNodeByPath(((CValidationElement)failed).getId(), nIndex);
				else
					node = paramStorage.getParameter(((CValidationElement)failed).getId(), nIndex);
				if (injectInputTips(node,
						new CElementValidationResult(CValidationType.INVALID, MESSAGE_INVALID_VALUE)))
				{
					addInvalidElementToSet(failed, nIndex);
				}
			}
		}
		
		return bResult;
	}
	/**
	 * This method used to get correct month for comparing dates.
	 * 
	 * @param nMonth - month, entered by user.
	 * @param dateNow - current date.
	 * @return month that should be validated.
	 */
	private Integer getMonthToValidate(Integer nMonth, Calendar dateNow)
	{
		if(nMonth == null)
		{
			return new Integer(dateNow.get(Calendar.MONTH) + 1);
		} 
		else
		{
			return nMonth;
		}
	}

	/**
	 * Returns day of month for correct date comparing.
	 * @param nYear - year, provided by user.
	 * @param nDay - day, provided by user or null for <mm, yyyy> format.
	 * @param dateNow - current date. 
	 * @param nMonthToValidate - month, provided by user.
	 * @return day of month.
	 */
	private Integer getDayToValidate(Integer nYear, Integer nDay,
			Calendar dateNow, final Integer nMonthToValidate)
	{
		if((nDay == null) && (nMonthToValidate.intValue() == (dateNow.get(Calendar.MONTH) + 1))
				&& (nYear.intValue() == dateNow.get(Calendar.YEAR)))
		{
			return new Integer(dateNow.get(Calendar.DAY_OF_MONTH));
		} 
		else if (nDay == null)
		{
			return new Integer(1);
		}
		else
		{
			return nDay;
		}
	}

	/**
	 * Element validation.
	 *
	 * @param element			to valdate.
	 * @param parameterNode		current validation element xml tree node.
	 * @param nIndex			of element.
	 * @param paramStorage 		injector with data to be validated.
	 * @param bInjectInputTips	flag to inject results back to xml.
	 * @return 					true if element is valid.
	 */
	private final boolean validateElement(CValidationElement element,
					XMLTreeNode parameterNode,
					int nIndex,
					IHttpParametersStorage paramStorage,
					boolean bInjectInputTips)
	{
		//Check index
		if (!element.checkIndexCondition(nIndex))
			return true; //Do not need to validate if condition is not met
		
		//Validate parameter
		String sElementText;

		if(parameterNode == null)
		{
			/*
			  If parameter is missing we still need to validate element because:

				1. Validation rules defined by validation set must not be affected
						by parameters, or this validation will produce results that user
						does not expect. Validation rules must not be ignored if parameter
						is missing.
				2. Element can be of required type. This must be checked.
				3. Element can have some subelements that must be validated.

				Although following these rules is a must, we have disabled this logic for
				elements with path based id from validation template older then ver 1.5.
				This is done to enshure compatibility with existing vxml files.
			*/

			if (element.hasPathBasedId()
							&& m_validationSet.getVersion() < CValidationSet.VERSION_v1_5)
			{
				return true; //Do not validate this element for compatibility reason
			}

//			Moved below in invalid value section
//			CProperties params = new CProperties();
//			params.setProperties(element.toProperties());
//			params.setProperty("index", String.valueOf(nIndex));
//			params.setProperty("parameterNode", "null");
//			params.setProperty("paramStorage", paramStorage.getClass().getName());
//			CTraceLog.warning(new CXMLTemplateException("Missing parameter node: " + element.getId() + " "),
//													getClass().getName()+".validateElement()", params, paramStorage.getData().toString(true));
//
			sElementText ="";
		}
		else
		{
			if (element.isAttribute())
			{
				//Validation elements represent attribute value
				sElementText = parameterNode.getAttribText(element.getId());

				// Set empty string if no attribute was found with this name
				if (sElementText == null)
				{
					sElementText = "";
				}
			}
			else
			{
				sElementText = parameterNode.getText(XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA);
			}
		}
		
		Boolean isRequired = null;
		String sArrtibuteRequired = element.getAttributeRequired();
		if (sArrtibuteRequired != null && parameterNode.getAttribText(sArrtibuteRequired) != null)
		{
			isRequired = Boolean.parseBoolean(parameterNode.getAttribText(sArrtibuteRequired));
		}
		
		if (m_bPreValidationOnly)
		{
			if (parameterNode.getAttribNode("xFormRequired") == null || !parameterNode.getAttribText("xFormRequired").equals("true"))
			{
				parameterNode.addAttribNode("xFormRequired", 
					String.valueOf(isRequired != null ? isRequired.booleanValue() : element.getValidationType().isRequired()));
			}
		}
		
		
		CElementValidationResult validationResult = element.validate(
				sElementText, nIndex, isRequired, paramStorage, m_nValidationMode, m_validationSet.getValidationEncoding());
		
		int status = validationResult.getStatus();

		// inject Input Tips
		if (bInjectInputTips && parameterNode != null)
		{
			if (element.isAttribute())
			{
				// Tips for attributes into provided parameter node
				injectInputAttributeTips(parameterNode, element.getId(), validationResult);
			}
			else
			{
				injectInputTips(parameterNode, validationResult);
			}
		}

		boolean bValid = (status & CValidationType.INVALID) == 0;

		//update totals
		if (bValid)
			m_nTotalValid++;
		else
		{
			addInvalidElementToSet(element, nIndex);
//			m_sInvalidElements.add(element.getId() + "#" + nIndex);

			//If parameter is missing generate warning
			if (parameterNode == null)
			{
				CProperties params = new CProperties();
				params.setProperties(element.toProperties());
				params.setProperty("index", String.valueOf(nIndex));
				params.setProperty("parameterNode", "null");
				params.setProperty("paramStorage", paramStorage.getClass().getName());
				CTraceLog.warning(new CXMLTemplateException("Missing parameter node: " + element.getId() + " "),
								getClass().getName()+".validateElement()", params);
			}
		}

		//Check attributes to validate
		CValidationElement.CAttributeList attributes = element.getAttributes();
		if (attributes != null)
		{
			bValid = processListValidation(
							attributes.getGroupElements(),
							attributes.isIgnoreIndex(),
							bValid,
							nIndex,
							parameterNode,
							paramStorage,
							bInjectInputTips);
		}

		//Validate subParameters
		List<CSubElementsList> subLists = element.getValidationSubLists();

		if (!subLists.isEmpty())
		{
			CValidationElement.CSubElementsList subElements = element.getMatchedSubList(sElementText);
			if(subElements != null)
			{
				//validate subelements
				bValid = processListValidation(
								subElements.getGroupElements(),
								subElements.isIgnoreIndex(),
								bValid,
								nIndex,
								null,
								paramStorage,
								bInjectInputTips);
			}
		}

		return bValid;

	}

	/**
	 * Processes sub element lists validation (sub elements, attributes)
	 * <p>
	 * @param listIterator		Sub element list iterator.
	 * @param bIgnoreIndex		Is index ignored.
	 * @param bValid			Current validation status.
	 * @param nIndex			Current element index.
	 * @param parameterNode		Current validation element xml tree node.
	 * @param paramStorage		Injector with data to be validated.
	 * @param bInjectInputTips	Flag to inject results back to xml.
	 * @return List validation status
	 */
	private boolean processListValidation(List<IValidationElement> elements,
					boolean bIgnoreIndex,
					boolean bValid,
					int nIndex,
					XMLTreeNode parameterNode,
					IHttpParametersStorage paramStorage,
					boolean bInjectInputTips)
	{
		boolean bResult = bValid;

		for (IValidationElement innerElement : elements)
		{
			if (innerElement instanceof CValidationElement)
			{
				CValidationElement validationElement = (CValidationElement)innerElement;

				if (bIgnoreIndex)
				{
					bResult = validateAllParameters(validationElement, paramStorage, bInjectInputTips, parameterNode) && bResult;
				}
				else
				{
					bResult = validateSingleParameter(validationElement, nIndex, paramStorage, bInjectInputTips, parameterNode) && bResult;
				}
			}
			else if (innerElement instanceof CRequiredGroupElement)
			{
				int nParamCount = getParametersCountForGroup((CRequiredGroupElement) innerElement, paramStorage);

				if (nParamCount == 0)
					nParamCount++;

				// Try to find multiple nodes with given id
				for (int i = 1; i <= nParamCount; i++)
				{
					bResult = validateRequiredGroup(
							(CRequiredGroupElement)innerElement, i, paramStorage, bInjectInputTips) && bResult;
				}
			}
			else if (innerElement instanceof CValidationGroupElement)
			{
				bResult = validateValidationGroup((CValidationGroupElement)innerElement, nIndex, paramStorage, bInjectInputTips) && bResult;
			}
		}

		return bResult;
	}

	/**
	 * Inject input tips.
	 * <p>
	 * If node valudity status was previously set to <code>FALSE</code>
	 * attempt to set it back to <code>TRUE</code> will not succeed.
	 * </p>
	 * @param node				XML node to inject.
	 * @param validationResult	result to inject.
	 * @return 			true if status was changed or added. If no changes - return false.
	 */
	protected static boolean injectInputTips(XMLTreeNode node, CElementValidationResult validationResult)
	{
		String strValid = node.getAttribText(XA_VALID);

		return injectTip(node, XA_VALID, strValid, validationResult);
	}

	/**
	 * Inject attribute input tips.
	 * <p>
	 * If node valudity status was previously set to <code>FALSE</code>
	 * attempt to set it back to <code>TRUE</code> will not succeed.
	 * </p>
	 * @param node				XML node to inject attribute validation status.
	 * @param sAttribute		Attribute name wihout postfix "_valid"
	 * @param validationResult	result to inject.
	 * @return					true if status was changed or added. Otherwise - return false.
	 */
	private static boolean injectInputAttributeTips(XMLTreeNode node, String sAttribute,
					CElementValidationResult validationResult)
	{
		String sAttributeName = sAttribute + XA_ATTR_VALID_POSTFIX;
		String sValid = node.getAttribText(sAttributeName);

		return injectTip(node, sAttributeName, sValid, validationResult);
	}

	/**
	 * Injects status tips.
	 * <p>
	 * If node valudity status was previously set to <code>FALSE</code>
	 * attempt to set it back to <code>TRUE</code> will not succeed.
	 * </p>
	 * @param node				XML node to inject tips.
	 * @param sAttributeName	Validation status attribute name.
	 * @param sValid			Validation status attribute value.
	 * @param validationResult	validation result to inject.
	 * @return					true if status was changed or added. Otherwise - return false.
	 */
	private static boolean injectTip(XMLTreeNode node, String sAttributeName, String sValid, CElementValidationResult validationResult)
	{
		int status = validationResult.getStatus();

		if (sValid == null ||
						sValid.equalsIgnoreCase(Constants.XML_TRUE) && ((status & CValidationType.INVALID) != 0))
		{
			node.addAttribNode(sAttributeName,
							((status & CValidationType.INVALID) != 0) ? Constants.XML_FALSE : Constants.XML_TRUE);

			if (validationResult.getMessage() != null)
			{
				node.addAttribNode(XA_DETAILS, validationResult.getMessage());
			}

			return true;
		}

		return false;
	}

	/**
	 * Injects valid attribute to given node
	 * @param node XMLTreeNode
	 * @param isValid true or false
	 */
	public static void setValidAttribute(XMLTreeNode node, boolean isValid)
	{
		if (isValid)
		{
			node.addAttribNode(XA_VALID, Constants.XML_TRUE);
		}
		else
		{
			node.addAttribNode(XA_VALID, Constants.XML_FALSE);
		}
	}

	/**
	 * Adds to set of invalid elements new entry. If this element has Component Name it means
	 * that there are some elements that should be treated as single then entry is created according
	 * to that Component Name (attribute "component_name" in tag "element").
	 * @param element element that did not pass validation.
	 * @param nIndex index of xml tag validation was applied to.
	 * @return true if there is no such element in the set yet and entry has been added successfully,
	 * if it is already in the set nothing is added and false returns.
	 */
	private boolean addInvalidElementToSet(CValidationElement element, int nIndex)
	{
		String valueForSet = element.getId() + "#" + nIndex;
		if ((element != null) && !CStringUtils.isEmpty(element.getComponentName()))
		{
			valueForSet = element.getComponentName() + "#" + nIndex;
		}
		return m_sInvalidElements.add(valueForSet);
	}
	
	/**
	 * 
	 * @return bit set
	 * 
	 * @see #VALIDATION_MODE_REQUIRED
	 * @see #VALIDATION_MODE_FORMAT
	 * @see #VALIDATION_MODE_DUPLICATED
	 */
	public int getValidationMode()
	{
		return m_nValidationMode;
	}
	
	public int getValidElementsCount()
	{
		return m_nTotalValid;
	}

	/**
	 * Returns number of invalid elements quantity
	 * <p> 
	 * @return <code>int</code>
	 */
	public int getInvalidElementsCount()
	{
		return m_sInvalidElements.size();
	}
	
	/**
	 * Use method {@link #getInvalidElementsCount()}
	 */
	@Deprecated public int getInvalidElementsQuantity()
	{
		return m_sInvalidElements.size();
	}
	
	/**
	 * Returns collection of all invalid elements' names.
	 * Used in unit-tests.
	 * 
	 * @return
	 */
	public Set<String> getInvalidElements()
	{
		return m_sInvalidElements;
	}
	
	protected CValidationSet getValidationSet()
	{
		return m_validationSet;
	}
	
	public String getSource()
	{
		return m_validationSet.getSource();
	}	
	
	
	private boolean validateValidationCompareDateSection(CValidationGroupElement group, 
			IHttpParametersStorage paramStorage, boolean bInjectInputTips, boolean bAllowEquals)
{
	boolean bResult = true;
	// Find day, month and year values
	Integer nYearFrom = null;
	Integer nMonthFrom = null;
	Integer nDayFrom = null;
	Integer nYearTo = null;
	Integer nMonthTo = null;
	Integer nDayTo = null;
	
	XMLTreeNode nodeYearFrom = null;
	XMLTreeNode nodeMonthFrom = null;
	XMLTreeNode nodeDayFrom = null;
	XMLTreeNode nodeYearTo = null;
	XMLTreeNode nodeMonthTo = null;
	XMLTreeNode nodeDayTo = null;
	
	CValidationElement dayFromElement = null;
	CValidationElement monthFromElement = null;
	CValidationElement yearFromElement = null;
	CValidationElement dayToElement = null;
	CValidationElement monthToElement = null;
	CValidationElement yearToElement = null;
	
	XMLTreeNode node = null;
	
	int nCounter = 0; 
	for (IValidationElement element : group.getGroupElements())
	{
		String strType = ((CValidationElement) element).getType();
		if (strType != null && strType.length() > 0)
		{
			if (strType.equals("counter"))
			{
				List<XMLTreeNode> lstNodes = paramStorage.getNodesByPath(((CValidationElement) element).getId());
				if(lstNodes != null & lstNodes.size() > 0 )
				{
					nCounter = lstNodes.size();
					break;
				}
			}
		}
	}
	
	for( int nStartIndex = 1; nStartIndex < nCounter; nStartIndex++)
	{
		int nIndex = nStartIndex;
		for (IValidationElement element : group.getGroupElements())
		{
			nIndex = nStartIndex;
			if (element instanceof CValidationElement)
			{
				String strType = ((CValidationElement) element).getType();

				if (strType != null && strType.length() > 0)
				{
					if (strType.equals(CValidationElement.TYPE_DAY_TO) || 
						(strType.equals(CValidationElement.TYPE_MONTH_TO)) || 
						(strType.equals(CValidationElement.TYPE_YEAR_TO)))
					{
						nIndex = nStartIndex + 1;
					}
				}
				
				if (((CValidationElement) element).hasPathBasedId())
					node = paramStorage.getNodeByPath(((CValidationElement) element).getId(), nIndex);
				else
					node = paramStorage.getParameter(((CValidationElement) element).getId(), nIndex);
				
				String sNodeText = (node == null ? null : node.getText(XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA));
		
				if (strType != null && strType.length() > 0 && sNodeText != null && sNodeText.length() > 0)
				{
					if (strType.equals(CValidationElement.TYPE_DAY_FROM))
					// Convert to day
					{
						dayFromElement = (CValidationElement) element;
						nDayFrom = new Integer(sNodeText);
						nodeDayFrom = node;
					}
					else if (strType.equals(CValidationElement.TYPE_MONTH_FROM))
					// Convert to month
					{
						monthFromElement = (CValidationElement) element;
						nMonthFrom = new Integer(sNodeText);
						nodeMonthFrom = node;
					}
					else if (strType.equals(CValidationElement.TYPE_YEAR_FROM))
					// Convert to year
					{
						yearFromElement = (CValidationElement) element;
						nYearFrom = new Integer(sNodeText);
						nodeYearFrom = node;
					}
					else if (strType.equals(CValidationElement.TYPE_DAY_TO))
					// Convert to day
					{
						dayToElement = (CValidationElement) element;
						nDayTo = new Integer(sNodeText);
						nodeDayTo = node;
					}
					else if (strType.equals(CValidationElement.TYPE_MONTH_TO))
					// Convert to month
					{
						monthToElement = (CValidationElement) element;
						nMonthTo = new Integer(sNodeText);
						nodeMonthTo = node;
					}
					else if (strType.equals(CValidationElement.TYPE_YEAR_TO))
					// Convert to year
					{
						yearToElement = (CValidationElement) element;
						nYearTo = new Integer(sNodeText);
						nodeYearTo = node;
					}
					else if (strType.equals(CValidationElement.TYPE_DATE_FROM))
					// Parse a date in a single node
					{
						if (sNodeText.length() > 8)
						{
							// Examples: 1/1/1999; 11/1/1999; 11/11/1999
							nDayFrom = CDateTime.getDay(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
							nMonthFrom = CDateTime.getMonth(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
						}
						else
						{
							// Examples: 11/1999; 1/1999
							nMonthFrom = CDateTime.getMonth(CDateTime.TYPE_MM_YYYY, sNodeText);
						}
						nYearFrom = CDateTime.getYear(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
						dayFromElement = (CValidationElement) element;
						monthFromElement = (CValidationElement) element;
						yearFromElement = (CValidationElement) element;
						nodeDayFrom = node;
						nodeMonthFrom = node;
						nodeYearFrom = node;
					}
					else if (strType.equals(CValidationElement.TYPE_DATE_TO))
					// Parse a date in a single node
					{
						if (sNodeText.length() > 8)
						{
							// Examples: 1/1/1999; 11/1/1999; 11/11/1999
							nDayTo = CDateTime.getDay(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
							nMonthTo = CDateTime.getMonth(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
						}
						else
						{
							// Examples: 11/1999; 1/1999
							nMonthTo = CDateTime.getMonth(CDateTime.TYPE_MM_YYYY, sNodeText);
						}
						nYearTo = CDateTime.getYear(CDateTime.TYPE_MM_DD_YYYY, sNodeText);
						dayToElement = (CValidationElement) element;
						monthToElement = (CValidationElement) element;
						yearToElement = (CValidationElement) element;
						nodeDayTo = node;
						nodeMonthTo = node;
						nodeYearTo = node;
					}
				}
			}
		}
		
		bResult = bResult && isDateValid(
				nYearFrom,
				nMonthFrom,
				nDayFrom,
				nYearTo,
				nMonthTo,
				nDayTo,				
				nodeYearFrom,
				nodeMonthFrom,
				nodeDayFrom,
				nodeYearTo,
				nodeMonthTo,
				nodeDayTo,				
				dayFromElement, monthFromElement, yearFromElement, 
				dayToElement, monthToElement, yearToElement, 
				bInjectInputTips,
				bAllowEquals,
				nIndex);
	}
	
	return bResult;
}

	
	private boolean validateMultiSectionRequired(CValidationGroupElement group, IHttpParametersStorage paramStorage)
{
	boolean bResult = true;
	
	for (IValidationElement element : group.getGroupElements())
	{
		List<XMLTreeNode> lstNodes = paramStorage.getNodesByPath(((CValidationElement) element).getId());
		for(XMLTreeNode node : lstNodes)
		{
			if(node.getAttribText(ATTR_DOCUMENT_ID) == null)
			{
				bResult = false;
				
				injectInputTips(node,
						new CElementValidationResult(CValidationType.INVALID, MESSAGE_REQUIRED_VALUE));
			}				
		}
	}
	
	return bResult;
}
	
	/**
	 * @return
	 */
	private boolean isDateValid(Integer nYearFrom,
								Integer nMonthFrom,
								Integer nDayFrom,
								Integer nYearTo,
								Integer nMonthTo,
								Integer nDayTo,
								XMLTreeNode nodeYearFrom,
								XMLTreeNode nodeMonthFrom,
								XMLTreeNode nodeDayFrom,
								XMLTreeNode nodeYearTo,
								XMLTreeNode nodeMonthTo,
								XMLTreeNode nodeDayTo,
								CValidationElement dayFromElement,
								CValidationElement monthFromElement,
								CValidationElement yearFromElement,
								CValidationElement dayToElement,
								CValidationElement monthToElement,
								CValidationElement yearToElement,
								boolean bInjectInputTips, 
								boolean bAllowEquals,
								int nIndex) 
	{
		
		boolean bResult = true;
		// check that it is valid format
		//	d,m,y
		//	m,y
		//	y
		if (nYearFrom != null && nYearTo != null)
		{
			boolean bDateValid = false;
			Calendar dateFrom = Calendar.getInstance();
			Calendar dateTo = Calendar.getInstance();
			bResult &= validateDate(nYearFrom, nMonthFrom, nDayFrom, nodeDayFrom, dayFromElement,
					nIndex, dateFrom);
		
			bResult &= validateDate(nYearTo, nMonthTo, nDayTo, nodeDayTo, dayToElement, nIndex, dateTo);
			// reset time to 00:00:00.0
			dateFrom.set(Calendar.HOUR_OF_DAY, 0);
			dateFrom.set(Calendar.MINUTE, 0);
			dateFrom.set(Calendar.SECOND, 0);
			dateFrom.set(Calendar.MILLISECOND, 0);
		
			dateTo.set(Calendar.HOUR_OF_DAY, 0);
			dateTo.set(Calendar.MINUTE, 0);
			dateTo.set(Calendar.SECOND, 0);
			dateTo.set(Calendar.MILLISECOND, 0);
		
			// 0 if dates are equals
			// value less than 0 if dateTo is before the dateFrom
			// value greater than 0 if dateTo is after the dateFrom
			int nDateCompareResult = dateTo.getTime().compareTo(dateFrom.getTime());
		
			// Analyze rezult
			if ((bAllowEquals && nDateCompareResult == 0) || nDateCompareResult > 0)
			{
				bDateValid = true;
			}
		
			boolean bStatusChanged;
			if (!bDateValid)
			// Set validation failed to nodes
			{
				if (nodeYearFrom != null)
				{
					bStatusChanged = false;
					if (bInjectInputTips)
					{
						/**
						 * Descriptions with TODO labels are not used now,
						 * but should be modified if it will be used in future.
						 */
						bStatusChanged = injectInputTips(nodeYearFrom,
										new CElementValidationResult(CValidationType.INVALID, "Invalid date (year from)"));
					}
		
					if (bStatusChanged)
					{
						addInvalidElementToSet(yearFromElement, nIndex);
		//				m_sInvalidElements.add("date_year_from_TODO");
					}
				}
		
				if (nodeMonthFrom != null)
				{
					bStatusChanged = false;
					if (bInjectInputTips)
					{
						bStatusChanged = injectInputTips(nodeMonthFrom,
										new CElementValidationResult(CValidationType.INVALID, "Invalid date (month from)"));
					}
		
					if (bStatusChanged)
					{
						addInvalidElementToSet(monthFromElement, nIndex);
		//				m_sInvalidElements.add("date_months_from_TODO");
					}
				}
		
				if (nodeDayFrom != null)
				{
					bStatusChanged = false;
					if (bInjectInputTips)
					{
						bStatusChanged = injectInputTips(nodeDayFrom,
										new CElementValidationResult(CValidationType.INVALID, "Invalid date (day from)"));
					}
		
					if (bStatusChanged)
					{
						addInvalidElementToSet(dayFromElement, nIndex);
		//				m_sInvalidElements.add("date_day_from_TODO");
					}
				}
		
				if (nodeYearTo != null)
				{
					bStatusChanged = false;
					if (bInjectInputTips)
					{
						bStatusChanged = injectInputTips(nodeYearTo,
										new CElementValidationResult(CValidationType.INVALID, "Invalid date (year to)"));
					}
		
					if (bStatusChanged)
					{
						addInvalidElementToSet(yearToElement, nIndex);
		//				m_sInvalidElements.add("date_year_to_TODO");
					}
				}
		
				if (nodeMonthTo != null)
				{
					bStatusChanged = false;
					if (bInjectInputTips)
					{
						bStatusChanged = injectInputTips(nodeMonthTo,
										new CElementValidationResult(CValidationType.INVALID, "Invalid date (month to)"));
					}
		
					if (bStatusChanged)
					{
						addInvalidElementToSet(monthToElement, nIndex);
		//				m_sInvalidElements.add("date_month_to_TODO");
					}
				}
		
				if (nodeDayTo != null)
				{
					bStatusChanged = false;
					if (bInjectInputTips)
					{
						bStatusChanged = injectInputTips(nodeDayTo,
										new CElementValidationResult(CValidationType.INVALID, "Invalid date (day to)"));
					}
		
					if (bStatusChanged)
					{
						addInvalidElementToSet(yearToElement, nIndex);
		//				m_sInvalidElements.add("date_day_to_TODO");
					}
				}
		
			}
		
			bResult = bResult && bDateValid;
		}
		
		return bResult;
	}
	
	private String getErrorMessage(String type, String defaultMessage)
	{
		if(CValidationGroupElement.TYPE_DATE_TILL_NOW.equals(type))
		{
			return "Date must be in the past";
		}
		
		return defaultMessage;
	}
}
