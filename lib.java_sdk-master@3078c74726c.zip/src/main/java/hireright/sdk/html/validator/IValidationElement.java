/*
 * @(#)$RCSfile: IValidationElement.java,v $ $Revision: 1.2 $ $Date: 2008/09/05 10:58:01 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/IValidationElement.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	A.Solntsev			2008-08-26	created
 */
package hireright.sdk.html.validator;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $, $Date: 2008/09/05 10:58:01 $, $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/IValidationElement.java,v $
 */
public interface IValidationElement
{

}
