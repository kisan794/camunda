/*
 * @(#)$RCSfile: CValidationSet.java,v $ $Revision: 1.18 $ $Date: 2015/11/02 20:16:15 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationSet.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 2002.07.22: 	Created
 * 2002.10.08 	A.Nesterov: 	Added required groups support
 * 2003.08.15 	A.Nesterov: 	Added support for references to external files (<include> tag)
 * 2003.10.08 	A.Nesterov: 	In comments added index conditons description
 * 2004-01-26		S.Prokopov		Added support for validation groups
 * 2005-01-04		A.Solntsev		Fixed CTraceLog usage.
 * 2005-01-20		A.Nesterov		Added version attribute support
 * 2005-05-31		P.Bushuk:			java_sdk_v2-5-29: Added date_compare usage to javadoc
 * 2006-05-17		A.Zinovjev		Added attribute validation support
 * 2006-10-31		A.Solntsev		implements Serializable
 * 2015-07-23		M.Lukyanenko	Added encoding validation mode
 * 2018-11-06	H.Lukashenka		Added new attribute for vxml element: ignore_index
 */
package hireright.sdk.html.validator;

import java.io.Serializable;
import java.net.URL;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import hireright.sdk.html.parser.TreeNode;
import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.parser.XMLObject;
import hireright.sdk.html.parser.XMLObjectsCache;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;

/**
 * Validation set. 
 * 
 * @author Alexander Nesterov
 * @version "$Revision: 1.18 $, $Date: 2015/11/02 20:16:15 $, $Author: cvsroot $"
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationSet.java,v $
 */
public final class CValidationSet implements Serializable
{
	private static final String VALIDATION_SET = "validation_set";

	private static final long serialVersionUID = -9162508732697577487L;

	protected static final String CLASS_VERSION = "$Revision: 1.18 $ $Author: cvsroot $";
	
	public final static float VERSION_v1_5 = 1.5f;
	public final static float VERSION_v1_0 = 1f;
	
	private final static String TAG_ELEMENTS = "elements";
	private final static String TAG_INCLUDE = "include";
	private final static String ATTRIBUTE_VERSION = "version";
	private final static String ATTRIBUTE_ENCODING = "encoding";

	private final String m_sSource;
	
	/**
	 * @serial contains CValidationElement instances
	 */
	private List<IValidationElement> m_elementsList = new LinkedList<IValidationElement>();

	private float m_fVersion = VERSION_v1_0;
	private String m_sValidationEncoding = CValidator.VALIDATION_DEFAULT_ENCODING;

	/**
	 * Creates new validation set from xml.
	 * <p>
	 * Example xml:
	 * <p>
	 *	<pre>
	 *	&lt;?xml version="1.0" encoding="UTF-8"?&gt;
	 *	&lt;validation_set&gt;
	 *
	 *	&lt;validation_types_lib&gt;
	 * 		
	 *		&lt;validation_type type="ssn_r"&gt;
	 * 			&lt;pattern&gt;&lt;![CDATA[/d/d/d/d/d/d/d/d/d]]&gt;&lt;/pattern&gt;
	 *			&lt;required&gt;true&lt;/required&gt;
	 * 		&lt;/validation_type&gt;
	 *		
	 *		&lt;validation_type type="txt_128"&gt;
	 *			&lt;required&gt;false&lt;/required&gt;
	 *			&lt;min_length&gt;0&lt;/min_length&gt;
	 *			&lt;max_length&gt;128&lt;/max_length&gt;
	 *		&lt;/validation_type&gt;
	 *		
	 *		&lt;validation_type type="password2_check"&gt;
	 *			&lt;required&gt;true&lt;/required&gt;
	 *			&lt;min_length&gt;0&lt;/min_length&gt;
	 *			&lt;max_length&gt;16&lt;/max_length&gt;
	 *			&lt;compare&gt;new_password1&lt;compare&gt;
	 *		&lt;/validation_type&gt;
	 *	
	 *	&lt;/validation_types_lib&gt;
	 *
	 *	&lt;elements&gt;
	 *		&lt;element id="test_id_1"&gt;
	 *			&lt;validation_type&gt;
	 *				&lt;pattern&gt;&lt;/pattern&gt;
	 *				&lt;required&gt;false&lt;/required&gt;
	 *				&lt;min_length&gt;11&lt;/min_length&gt;
	 *				&lt;max_length&gt;20&lt;/max_length&gt;
	 *			&lt;/validation_type&gt;
	 *		&lt;/element&gt;
	 *
	 *		&lt;element id="test_id_2" &gt;
	 *			&lt;validation_type type="ssn"&gt;
	 *		&lt;/element&gt;
	 *
	 *		&lt;element id="test_id_2"&gt;
	 *			&lt;pattern&gt;&lt;![CDATA[[a-z]]]&gt;&lt;/pattern&gt;
	 *			&lt;sub_elements&gt;
	 *				
	 *				&lt;elements_set pattern="aaaa"&gt;
	 *					&lt;element&gt;
	 *						&lt;id&gt;param_x&lt;/id&gt;
	 *						&lt;pattern&gt;&lt;/pattern&gt;
	 *						&lt;required&gt;false&lt;/required&gt;
	 *						&lt;min_length&gt;11&lt;/min_length&gt;
	 *						&lt;max_length&gt;20&lt;/max_length&gt;
	 *					&lt;/element&gt;
	 *				&lt;/elements_set&gt;
	 *				
	 *				&lt;elements_set ignore_index="Y" pattern="aaaa"&gt;
	 *					&lt;element&gt;
	 *						&lt;id&gt;param_x&lt;/id&gt;
	 *						&lt;pattern&gt;&lt;/pattern&gt;
	 *						&lt;required&gt;false&lt;/required&gt;
	 *						&lt;min_length&gt;11&lt;/min_length&gt;
	 *						&lt;max_length&gt;20&lt;/max_length&gt;
	 *					&lt;/element&gt;
	 *				&lt;/elements_set&gt;
	 *				
	 *				&lt;elements_set pattern="bbbb"&gt;
	 *					&lt;element&gt;
	 *						&lt;id&gt;param_y&lt;/id&gt;
	 *						&lt;pattern&gt;&lt;/pattern&gt;
	 *						&lt;required&gt;false&lt;/required&gt;
	 *						&lt;min_length&gt;11&lt;/min_length&gt;
	 *						&lt;max_length&gt;20&lt;/max_length&gt;
	 *					&lt;/element&gt;
	 *				&lt;/elements_set&gt;
	 *				
	 *				&lt;elements_set npattern="bbbb"&gt;
	 *					&lt;element id="date" index="1"&gt;
	 *						&lt;validation_type type="date_required"&gt;
	 *					&lt;/element&gt;
	 *					&lt;element id="date" index_not="1"&gt;
	 *						&lt;validation_type type="date_not_required"&gt;
	 *					&lt;/element&gt;
	 *				&lt;/elements_set&gt;
	 *              
	 *			&lt;/sub_elements&gt;
	 *		&lt;/element&gt;
	 *
	 *		&lt;required_group&gt;
	 *			&lt;elements&gt;
	 *				&lt;element id="e1"&gt;
	 *					&lt;validation_type&gt;
	 *						&lt;required&gt;true&lt;/required&gt;
	 *					&lt;/validation_type&gt;
	 *				&lt;/element&gt;
	 *
	 *				&lt;element id="e2"&gt;
	 *					&lt;validation_type&gt;
	 *						&lt;required&gt;true&lt;/required&gt;
	 *					&lt;/validation_type&gt;
	 *				&lt;/element&gt;
	 *
	 *				&lt;required_group&gt;
	 *					&lt;elements&gt;
	 *
	 *						&lt;element id="e11"&gt;
	 *							&lt;validation_type&gt;
	 *								&lt;required&gt;true&lt;/required&gt;
	 *							&lt;/validation_type&gt;
	 *						&lt;/element&gt;
	 *
	 *						&lt;element id="e22"&gt;
	 *							&lt;validation_type&gt;
	 *								&lt;required&gt;true&lt;/required&gt;
	 *							&lt;/validation_type&gt;
	 *						&lt;/element&gt;
	 *
	 *					&lt;/elements&gt;
	 *				&lt;/required_group&gt;
	 *
	 *			&lt;/elements&gt;
	 *			&lt;include&gt;external_elements.xml&lt;/include&gt;
	 *		&lt;/required_group&gt;
	 *      
	 *		&lt;validation_group type = "date_from_now"&gt;
	 *			&lt;elements&gt;
	 *				&lt;element id="position_ready_work_day" type="d"&gt;
	 *					&lt;validation_type type="dd_nonrequired" /&gt;
	 *				&lt;/element&gt;
	 *				
	 *				&lt;element id="position_ready_work_month" type="m"&gt;
	 *					&lt;validation_type type="mm_nonrequired" /&gt;
	 *				&lt;/element&gt;
	 *				&lt;element id="position_ready_work_year" type="y"&gt;
	 *					&lt;validation_type type="yyyy_nonrequired" /&gt;
	 *				&lt;/element&gt;
	 *			&lt;/elements&gt;
	 *		&lt;/validation_group&gt;
	 *
	 *		&lt;validation_group type = "date_compare"&gt;
	 *			&lt;elements&gt;
	 *				&lt;element id="personal_othername_from_year" type="year_from"&gt;
	 *					&lt;validation_type type="yyyy_required" /&gt;
	 *				&lt;/element&gt;
	 *				&lt;element id="personal_othername_from_mm" type="month_from"&gt;
	 *					&lt;validation_type type="mm_required" /&gt;
	 *				&lt;/element&gt;
	 *				&lt;element id="personal_othername_to_mm" type="month_to"&gt;
	 *					&lt;validation_type type="mm_required" /&gt;
	 *				&lt;/element&gt;
	 *				&lt;element id="personal_othername_to_year" type="year_to"&gt;
	 *					&lt;validation_type type="yyyy_required" /&gt;
	 *				&lt;/element&gt;
	 *			&lt;/elements&gt;
	 *		&lt;/validation_group&gt; 
	 *
	 *	&lt;/elements&gt;
	 *
	 *	&lt;/validation_set&gt;
	 *	</pre>
	 *
	 * NOTES:<p>
	 * 			<code>&lt;validation_types_lib&gt;</code> - optional element Type.<br>
	 *          Defined inside <code>&lt;validation_types_lib&gt;,</code> will mask any type with the same name in any other type lib.<br>
	 * 			<code>&lt;min_length>, &lt;max_length&gt;</code> elements are ignored if non empty <code>&lt;pattern&gt;</code> element present.<br>
	 *          <code>&lt;compare&gt;</code> tag allows to specify an element id, so tested value will be compared with value of specified element.<br>
	 *			<p>
	 *			Any <code>&lt;required_group&gt; &lt;elements&gt;</code> construction must contain at least one <code>&lt;element&gt;</code>.<br>
	 *          <p>
	 *          <code>&lt;include&gt;</code> tag allows to insert contents of other file root node.<br>
	 *          <p>
	 *         	<code>&lt;element&gt;</code> tag attributes:<br>
	 *          	<code>id</code> - parameter id string.<br>
	 *          	<code>path</code> - path to XML tag that contains parameter value(alternative to id)<br>
	 *          	<code>index</code> - if this attribute is specified, then this element will be 
	 *              		used for validation of parameter that matches by id and index.<br>
	 *          	<code>index_not</code> - if this attribute is specified, then this element will be 
	 *              		used for validation of parameter that has index other than
	 *                      specified.<br>
	 *              <font>The <code>id</code> attribute has more priority than <code>path</code>.</font><br>
	 *              <b><font color=red>DO NOT USE BOTH <code>index</code> AND <code>index_not</code> ATTRIBUTES.</font></b><br>
	 *          <p>    
	 * 			<code>&lt;elements_set&gt;</code> tag attributes:<br>
	 *          	<code>pattern</code> - describes condition on which elements set will be used for validation.
	 *              <code>npattern</code> - same as pattern but condition will be inverted.
	 *              <code>ignore_index</code> - specifies if all subelements should be checked, regardless of index (Y/N).
	 *          <p>    
	 *          <code>&lt;validation_group&gt;</code> - optional element.<br>
	 *          	Inside this group all elements will be checked for one condition.<br>
	 *              <p>
	 *              supported types:<br>
	 *              <code>date_from_now</code> - input date must be equal or greater than today<br>
	 *              <code>date_till_now</code> - input date must be less than today.<br>
	 *              <code>date_equals_now</code> - input date must be equals with today.<br>
	 *              <code>date_compare</code> - input starting date must be before ending date.<br>
	 *              <p>
	 *              For date type elements must contain attribute type that describes what part of date is in input.<br>
	 *              It is allowed to have following types inside one validation group:<br>
	 *              	d,m,y<br>
	 *                  m,y<br>
	 *                  y<br>
	 *              <br>
	 *              For <code>date_compare</code> type elements must contain attribute type that describes what part of date is in input.<br>
	 *              	<code>day_from</code> - starting day<br>
	 *              	<code>month_from</code> - starting month<br>
	 *              	<code>year_from</code> - starting year<br>
	 *              	<code>day_to</code> - ending day<br>
	 *              	<code>month_to</code> - ending month<br>
	 *              	<code>year_to</code> - ending year<br>
	 *                 
	 * <p>             
	 * @param validationSet	validation set xml.
	 * @return				new CValidationSet instance.
	 */
	public static CValidationSet createFromRootNode(XMLObject validationSetXml) 
	{
		return new CValidationSet(validationSetXml);
	}
	
	public static CValidationSet createFromRootNode(XMLTreeNode validationSet) 
	{
		return new CValidationSet(validationSet.getChildNodeByTag(VALIDATION_SET), validationSet.getSystemId());
	}

	public CValidationSet(XMLObject validationSetXml) 
	{
		this(validationSetXml.getNode(VALIDATION_SET), validationSetXml.getSystemId());
	}
	
	/**
	 * Creates validation set from &lt;validation_set&gt; xml node.
	 * <p>
	 * @param validationSetNode	&lt;validation_set&gt; xml node.
	 */
	protected CValidationSet(XMLTreeNode validationSetNode, String sSourceUrl) 
	{
		m_sSource = sSourceUrl;
		XMLTreeNode attributeVersion = validationSetNode.getAttribNode(ATTRIBUTE_VERSION);
		//parse version info
		if(attributeVersion != null)
		{
			try
			{
				m_fVersion = Float.parseFloat(attributeVersion.getText());
			}
			catch (RuntimeException e)
			{
				throw new CValidationConfigurationException("Bad validation XML version:" + attributeVersion, e);			
			}
		}
		
		XMLTreeNode attributeEncoding = validationSetNode.getAttribNode(ATTRIBUTE_ENCODING);
		//parse version info
		if(attributeEncoding != null)
		{
			setValidationEncoding(attributeEncoding.getText());
		}
		
		
		//get type library
		XMLTreeNode element = validationSetNode.getChildNodeByTag(CValidationTypesLibrary.TAG_VALIDATION_TYPES_LIB);
		
		//create elements
		fillCollectionWithElements(m_elementsList,
								validationSetNode.getChildNodeByTag(TAG_ELEMENTS),
								(element != null) ? new CValidationTypesLibrary(element, getValidationEncoding()) : null);
	}

	/**
	 * Class contructor.
	 * <p>
	 * @param urlValidationSet
	 * @throw Exception
	 */
	public CValidationSet(URL urlValidationSet) 
	{
		m_sSource = urlValidationSet.toString();
		
		XMLObject xmlValidator = XMLObjectsCache.getInstance()
			.getXMLObject(urlValidationSet.toString());
			
		XMLTreeNode validationSetNode = xmlValidator
			.getRootNode().getChildNodeByType(XMLConsts.TYPE_NODE);
		
		XMLTreeNode attributeVersion = validationSetNode.getAttribNode(ATTRIBUTE_VERSION);
		
		if(attributeVersion != null)
		{
			try
			{
				m_fVersion = Float.parseFloat(attributeVersion.getText());
			}
			catch (RuntimeException e)
			{
				throw new CValidationConfigurationException("Bad validation XML version:" + attributeVersion, e);			
			}
		}
	
		//get type library
		XMLTreeNode element = validationSetNode.getChildNodeByTag(CValidationTypesLibrary.TAG_VALIDATION_TYPES_LIB);

		resolveReferencesToExternalXml(validationSetNode, urlValidationSet);
		
		//create elements
		fillCollectionWithElements(m_elementsList,
								(XMLTreeNode)validationSetNode.getChildNodeByTag(TAG_ELEMENTS),
								(element != null) ? new CValidationTypesLibrary(element, getValidationEncoding()) : null);
	}
	
	/**
	 * Resolve refereneces.
	 * <p>
	 * @param validationSetNode
	 * @param urlValidationSet
	 * @throw IllegalArgumentException
	 */
	protected final static void resolveReferencesToExternalXml(XMLTreeNode validationSetNode, URL urlValidationSet) throws IllegalArgumentException
	{
		XMLObject rootObject = validationSetNode.getXMLObject();		
		XMLTreeNode includeNode = rootObject.getNode(TAG_INCLUDE, 1);

		if (includeNode == null)
			return;

		//Cut off filename from the end of URL
		StringBuffer urlStringBuffer = new StringBuffer(urlValidationSet.toString());
		int nURLPathLength = urlStringBuffer.length();

		while(--nURLPathLength > 0)
		{
			if(urlStringBuffer.charAt(nURLPathLength) == '/')
			{
				urlStringBuffer.setLength(++nURLPathLength);
				break;
			}
		}
		
		//Insert node
		try
		{
			includeNode(includeNode, urlStringBuffer);
		
			while((includeNode = rootObject.getNode(TAG_INCLUDE, 1)) != null)
			{	
				urlStringBuffer.setLength(nURLPathLength); //Cut out previous filename
				includeNode(includeNode, urlStringBuffer);
			}
		}
		catch (RuntimeException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			CProperties params = new CProperties();
			params.setProperty("includeNode", includeNode);
			final String errorMsg = "Bad validation XML (include node): " + includeNode;
			throw new CRuntimeException(errorMsg, e, params);
		}
	}

	/**
	 * Include node.
	 * <p>
	 * @param includeNode
	 * @param urlStringBuffer
	 */
	protected final static void includeNode(XMLTreeNode includeNode, StringBuffer urlStringBuffer)
	{
		//Get Replacement Node
		urlStringBuffer.append(includeNode.getText());
		
		String sXMLFileURL = urlStringBuffer.toString();
		XMLTreeNode nodeToInclude = getRootNodeFromFile(sXMLFileURL);

		//Replace target node
		if (nodeToInclude != null)
			replaceNode(includeNode, nodeToInclude);
		else
			throw new IllegalArgumentException("File " + sXMLFileURL + " does not contain a valid XML.");
	}
	
	/**
	 * Returns root node from file.
	 * 
	 * @param sXMLFileURL
	 * @return XMLTreeNode
	 */
	protected final static XMLTreeNode getRootNodeFromFile(String sXMLFileURL)
	{
		XMLObject xmlObject = XMLObjectsCache.getInstance().getXMLObject(sXMLFileURL);
		XMLTreeNode rootNode = xmlObject.getRootNode();
		return rootNode.getChildNodeByType(XMLConsts.TYPE_NODE);
	}

	/**
	 * Replace node.
	 * <p>
	 * @param includeNode
	 * @param sourceNode
	 */
	protected final static void replaceNode(XMLTreeNode includeNode, XMLTreeNode sourceNode)
	{
		XMLTreeNode destinationNode = (XMLTreeNode)includeNode.getParent();
		destinationNode.removeChild(includeNode);

		TreeNode node = sourceNode.firstChildNode();
		TreeNode nodeNext;

		while (node != null)
		{
			nodeNext = node.getNextNode();//this line must be first, this is not a bug
			destinationNode.addChildNode(node);
			node = nodeNext;
		}
	}

	/**
	 * Adds element to validation set
	 * <p>
	 * @param element	to be added
	 */
	public final void add(CValidationElement element)
	{
		m_elementsList.add(element);
	}

	/**
	 * Removes all elements
	 */
	public final void clear()
	{
		m_elementsList.clear();
	}

	/**
	 * Returns list iterator object for this set
	 * @deprecated use method getElements()
	 * @return	iterator list.
	 */
	public final ListIterator<IValidationElement> listIterator ()
	{
		return m_elementsList.listIterator();
	}
	
	public final List<IValidationElement> getElements()
	{
		return Collections.unmodifiableList( m_elementsList );
	}

	/**
	 * Fills collection with CValidationElement and CRequiredGroupElement objects
	 * constructed from node that contains <element> and <required_group> child nodes.
	 * <p>
	 * @param collection
	 * @param listNode
	 * @param typesLibrary
	 */
	static final void fillCollectionWithElements(Collection<IValidationElement> collection, XMLTreeNode listNode, CValidationTypesLibrary typesLibrary)
	{
		XMLTreeNode element = (XMLTreeNode)listNode.firstChildNode();
		String sTag;

		while (element != null)
		{
			sTag = element.getXMLTag();

			if (sTag.equals(CValidationElement.TAG_VALIDATION_ELEMENT))
			{
				collection.add(new CValidationElement(element, typesLibrary));
			}
			else if (sTag.equals(CValidationElement.TAG_VALIDATION_ATTRIBUTE))
			{
				collection.add(new CValidationElement(element, typesLibrary, true));
			}
			else if (sTag.equals(CRequiredGroupElement.REQUIRED_GROUP_TAG))
			{
				collection.add(new CRequiredGroupElement(element, typesLibrary));
			}
			else if (sTag.equals(CValidationGroupElement.VALIDATION_GROUP_TAG))
			{
				collection.add(new CValidationGroupElement(element, typesLibrary));
			}

			element = element.getNextXmlNode();
		}
	}
	
	/**
	 * Returns version of validation set
	 * @return version of validation set
	 */
	public float getVersion()
	{
		return m_fVersion;
	}
	
	/**
	 * Return either URL or source XML of this validation set.
	 * @return
	 */
	public String getSource()
	{
		return m_sSource;
	}

	/**
	 * @param sValidationEncoding
	 */
	private void setValidationEncoding(String sValidationEncoding) 
	{
		m_sValidationEncoding = sValidationEncoding; 
	}
	
	/**
	 * @return
	 */
	public String getValidationEncoding() 
	{		
		return m_sValidationEncoding;
	}
}

