/*
 * @(#)$RCSfile: CGroup.java,v $ $Revision: 1.2 $ $Date: 2008/09/05 10:15:10 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CGroup.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	A.Solntsev			2008-08-26	created
 */
package hireright.sdk.html.validator;

import hireright.sdk.html.parser.XMLTreeNode;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $, $Date: 2008/09/05 10:15:10 $, $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CGroup.java,v $
 */
public class CGroup implements IGroup, Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: asolntsev $";
	
	private static final String TAG_ELEMENTS = "elements";
	
	private final List<IValidationElement> m_groupElements;
	
	protected CGroup(XMLTreeNode groupElementNode, CValidationTypesLibrary primaryLibrary)
	{
		m_groupElements = new ArrayList<IValidationElement>();
		CValidationSet.fillCollectionWithElements(m_groupElements, groupElementNode.getChildNodeByTag(TAG_ELEMENTS), primaryLibrary);
	}
	
	public List<IValidationElement> getGroupElements()
	{
		return m_groupElements; // unmodifiable?
	}
}
