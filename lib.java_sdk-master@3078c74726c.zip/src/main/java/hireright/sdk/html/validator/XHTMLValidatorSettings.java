/*
 * @(#)$RCSfile: XHTMLValidatorSettings.java,v $ $Revision: 1.8 $ $Date: 2010/03/11 21:42:54 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/XHTMLValidatorSettings.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 	2002-10-01	A.Nesterov	Created
 * 	2003-01-28	A.Nesterov	Added support for settings reloading
 * 	2003-02-26	A.Nesterov	Added automatic settings reloading
 *  2005-08-15	A.Solntsev	Now entire table JAVA SETTINGS is loaded at once.
 *  2005-08-15	A.Solntsev	Moved upper to class hireright.sdk.html.validator
 *  2006-10-17	P.Bushuk		A temporary hack for removing double slash from URL.
 *  2008-08-27	A.Solntsev	Removed using CTraceLog
 *  2008-12-29	A.Solntsev	Added java setting "VALIDATOR_LIB_PATH" (overridden in unit-tests)
 *  2010-03-05	A.Solntsev	Use log4j instead of commons-logging.
 */
package hireright.sdk.html.validator;

import java.io.File;
import java.io.Serializable;
import java.util.Observable;
import java.util.Observer;

import org.apache.log4j.Logger;

import hireright.sdk.util.CProperties;
import hireright.settings.GeneralSettings;

/**
 * A Validator Settings class.
 * 
 * @author Alexander Nesterov
 * @since java_sdk_v2-6-9
 * @version $Revision: 1.8 $ $Date: 2010/03/11 21:42:54 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/XHTMLValidatorSettings.java,v $
 */
public class XHTMLValidatorSettings implements Observer, Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.8 $ $Author: cvsroot $";
	
	public static final String SETTING_VXML_HOST = "VALIDATOR_LIB_HOST";
	public static final String SETTING_VXML_PATH = "VALIDATOR_LIB_PATH";
	private static final String REGEXP_REMOVE_DOUBLE_SLASH = "(?<=[^:])/{2,}";
	private static final String SLASH = "/";
	
	private static final Logger log = Logger.getLogger(XHTMLValidatorSettings.class);
	
	private static XHTMLValidatorSettings m_instance = null;
	
	protected String m_sDefTypesLibrarysHost;
	protected String m_sDefTypesLibrarysPath;
	protected String m_sDefTypesLibrarysFullPath;

	private static final XHTMLValidatorSettings getInstance()
	{
		if (m_instance == null)
		{
			synchronized (XHTMLValidatorSettings.class)
			{
				if (m_instance == null)
				{
					m_instance = new XHTMLValidatorSettings();
					GeneralSettings.registerObserver(m_instance);
				}
			}
		}
		
		return m_instance;
	}
	
	private XHTMLValidatorSettings()
	{
		loadSettings();
	}

	public void update(Observable o, Object arg)
	{
		CProperties params = new CProperties();
		if (o != null)
		{
			params.setProperty("observable.class", o.getClass().getName());
			params.setProperty("observable", o.toString());
		}
		if (arg != null)
		{
			params.setProperty("arg.class", arg.getClass().getName());
			params.setProperty("arg", arg.toString());
		}
		// CTraceLog.info("Reload VXML Settings", getClass().getName() + ".update()", params);
		if (log.isDebugEnabled())
		{
			log.debug("Reload VXML Settings: " + params);
		}
		loadSettings();
	}

	/**
	 * @see #SETTING_VXML_PATH
	 * @throws IllegalArgumentException if table JAVA_SETTINGS does not contain property "VALIDATOR_LIB_PATH"
	 */
	private final void loadSettings()
	{
		m_sDefTypesLibrarysPath = GeneralSettings.loadProperty(SETTING_VXML_PATH);
		m_sDefTypesLibrarysHost = GeneralSettings.getProperty(SETTING_VXML_HOST);
		// System.out.println("========== vxml.host=" + m_sDefTypesLibrarysHost + " ==========");

		if (m_sDefTypesLibrarysHost == null)
			m_sDefTypesLibrarysHost = GeneralSettings.getHttpResRoot();
		
		String sFullPath = m_sDefTypesLibrarysHost + m_sDefTypesLibrarysPath;
		
		// Temporary hack: remove double slash
		m_sDefTypesLibrarysFullPath = sFullPath.replaceAll(REGEXP_REMOVE_DOUBLE_SLASH, SLASH);
		m_sDefTypesLibrarysFullPath = sFullPath.replaceAll("\\\\", "\\" + File.separator);
		// m_sDefTypesLibrarysFullPath = sFullPath.replaceAll("\\/", "\\" + File.separator);
		
		if (log.isDebugEnabled())
		{
			log.debug("vxml.host: " + m_sDefTypesLibrarysHost);
			log.debug("vxml.path: " + m_sDefTypesLibrarysPath);
		}
	}

	/**
	 * Returns URL to directory with types library files.
	 */
	public static String getDefaultTypesLibrarysPathURL()
	{
		// Repair "two slashes"
		return getInstance().m_sDefTypesLibrarysFullPath;
	}

	public static String getDefaultTypesLibrarysPath()
	{
		return getInstance().m_sDefTypesLibrarysPath;
	}
}
