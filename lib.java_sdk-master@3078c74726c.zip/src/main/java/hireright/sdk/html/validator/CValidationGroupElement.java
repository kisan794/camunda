/*
 * @(#)$RCSfile: CValidationGroupElement.java,v $ $Revision: 1.12 $ $Date: 2012/11/30 08:18:32 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationGroupElement.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	2004-02-06	S.Prokopov			Created
 *	2005-05-31	P.Bushuk				java_sdk_v2-5-29: Added group validation type 'date_compare'
 *	2006-10-31	A.Solntsev			implements Serializable
 *	2007-06-14	E.Tonkoshkurov	added date shift handling
 *	2007-06-28	A.Larin					added validation rules for ISO date (TYPE_ISO_DATE_XXXXX)
 *	2008-01-17	M.Karpov				New validation TYPE_DATE added
 *	2008-03-19	M.Karpov				New validation TYPE_DATE_COMPARE_OR_EQUALS added
 *	2008-08-26	A.Solntsev			Removed "extends LinkedList"; added "extends CGroup"; added generics.
 *	2010-12-06	E.Kapustin			Added new constant TYPE_ISO_DATE
 *	2012-11-08  M.Hryshyn		Added any_value_provided_group type of validation group
 *  2022-11-29  J.Zaporozhets	TYPE_DATE_COMPARE_OR_EQUALS_SECTION validation in section
 */
package hireright.sdk.html.validator;
import hireright.sdk.html.parser.XMLTreeNode;

import java.io.Serializable;

/**
 * Validation group set.
 * 
 * @author Sergei Prokopov
 * @version "$Revision: 1.12 $, $Date: 2012/11/30 08:18:32 $, $Author: cvsroot $"
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationGroupElement.java,v $
 */
public class CValidationGroupElement extends CGroup implements Serializable, IValidationElement
{
	protected static final String CLASS_VERSION = "$Revision: 1.12 $ $Author: cvsroot $";
	
	/**
	 * Group tag name.
	 */
	public static final String VALIDATION_GROUP_TAG = "validation_group";

	/**
	 * Validation group type attribute
	 */
	private static final String TAG_VALIDATION_TYPE = "type";

	/**
	 * Validate group type. Valid group if all values are more or equals with today.
	 */
	public static final String TYPE_DATE_FROM_NOW = "date_from_now";

	/**
	 * Validate group type. Valid group if date value is more or equal with today.
	 */
	public static final String TYPE_ISO_DATE_FROM_NOW = "iso_date_from_now";

	/**
	 * Validate group type. Valid group if all values are equals with today.
	 */
	public static final String TYPE_DATE_EQUALS_NOW = "date_equals_now";

	/**
	 * Validate group type. Valid group if date value equals with today.
	 */
	public static final String TYPE_ISO_DATE_EQUALS_NOW = "iso_date_equals_now";

	/**
	 * Validate group type. Valid group if all values are less or equals with today.
	 */
	public static final String TYPE_DATE_TILL_NOW = "date_till_now";
	
	/**
	 * Validate group type. Valid group if date value is less or equal with today.
	 */
	public static final String TYPE_ISO_DATE_TILL_NOW = "iso_date_till_now";

	/**
	 * Validate group type. Valid group if From date is before To date.
	 */
	public static final String TYPE_DATE_COMPARE = "date_compare";

	/**
	 * Validate group type. Valid group if From date is before To date. Allow equal values.
	 */
	public static final String TYPE_DATE_COMPARE_OR_EQUALS = "date_compare_or_equals";
	
	/**
	 * Validate group type. Valid group if From date is before To date. Allow equal values.
	 */
	public static final String TYPE_DATE_COMPARE_OR_EQUALS_SECTION = "date_compare_or_equals_section";
	
	
	public static final String TYPE_MULTI_SECTION_REQUIRED = "multi_section_required";

	/**
	 * Validate group type. Valid group if date is real existence date, include leap year check.
	 */
	public static final String TYPE_DATE = "date_valid";

	/**
	 * Validate group type. Valid group if date is real existence date, include leap year check.
	 */
	public static final String TYPE_ISO_DATE = "iso_date_valid";
	
	/**
	 * Validate group type. Valid group if date is real existence date, include leap year check.
	 */
	public static final String TYPE_ANY_VALUE_PROVIDED_GROUP = "any_value_provided_group";
	
	/**
	 * Current date shift value attribute. Used if we should validate input date relative not
	 * to current date, but to some another. For example, if date should be 3 days later than
	 * current, then this attribute will be equal to "3".
	 */
	private static final String DATE_SHIFT_VALUE_ATTR = "shift_value";

	/**
	 * Current date shift unit attribute. Used if we should validate input date relative not
	 * to current date, but to some another. For example, if date should be 3 days later than
	 * current, then this attribute will be equal to "d".
	 */
	private static final String DATE_SHIFT_UNIT_ATTR = "shift_unit";
	
	/**
	 * XMLTreeNode representation of validation group.
	 */
	private final XMLTreeNode m_ElementNode;

	/**
	 * Class contructor.
	 * <p>
	 * @param groupElementNode	validation group element.
	 * @param primaryLibrary	validation library.
	 * @throws RuntimeException
	 */
	public CValidationGroupElement(XMLTreeNode groupElementNode, CValidationTypesLibrary primaryLibrary) throws RuntimeException
	{
		super(groupElementNode, primaryLibrary);
		m_ElementNode = groupElementNode;
	}

	/**
	 * Returns validation type.
	 * <p>
	 * @return	validation group type.
	 */
	public String getGroupValidationType()
	{
		return m_ElementNode.getAttribText(TAG_VALIDATION_TYPE);
	}

	/**
	 * Returns current date shift value
	 * <p>
	 * @return	current date shift value
	 */
	public String getCurrentDateShiftValue()
	{
		return m_ElementNode.getAttribText(DATE_SHIFT_VALUE_ATTR);
	}

	/**
	 * Returns current date shift unit
	 * <p>
	 * @return	current date shift unit
	 */
	public String getCurrentDateShiftUnit()
	{
		return m_ElementNode.getAttribText(DATE_SHIFT_UNIT_ATTR);
	}

	/**
	 * Returns element XML representation.
	 * <p>
	 * @return XMLTreeNode object
	 */
	public XMLTreeNode getElementRootNode()
	{
		return m_ElementNode;
	}
}