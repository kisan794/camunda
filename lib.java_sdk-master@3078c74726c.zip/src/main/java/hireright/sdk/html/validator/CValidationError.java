package hireright.sdk.html.validator;

/*
 * Copyright 2001-2021 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * J.Jegorov	2021-03-17	Created
 */


import java.io.Serializable;

public class CValidationError implements Serializable
{
	
	private  String field;
	private  String message;
	private  String code;
	
	public String getCode()
	{
		return this.code;
	}
	
	public String getMessage()
	{
		return this.message;
	}
	
	public String getField()
	{
		return this.field;
	}
	
	public CValidationError setCode(String code)
	{
		this.code = code;
		return this;
	}
	
	public CValidationError setField(String field)
	{
		this.field = field;
		return this;
	}
	
	public CValidationError setMessage(String message)
	{
		this.message = message;
		return this;
	}
	
	@Override
	public String toString()
	{
		return "CValidationError{" +
				"field='" + field + '\'' +
				", message='" + message + '\'' +
				", code=" + code +
				'}';
	}
}
