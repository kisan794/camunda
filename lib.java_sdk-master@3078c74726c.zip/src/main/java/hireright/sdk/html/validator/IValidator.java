/*
 * Copyright 2001-2021 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * J.Jegorov	2021-03-17	Created
 */
package hireright.sdk.html.validator;


import java.util.List;
import java.util.stream.Collectors;

public interface IValidator<E>
{
	default List<CValidationResult> validateBatch(List<E> eList){
		{
			if (eList == null){
				throw new IllegalArgumentException("List of elements for validation cannot be null!");
			}
			return eList.stream().map(this::validate).collect(Collectors.toList());
		}
	}
	
	CValidationResult validate(E e);
}
