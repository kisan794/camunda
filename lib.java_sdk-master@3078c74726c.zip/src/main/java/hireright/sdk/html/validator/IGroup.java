/*
 * @(#)$RCSfile: IGroup.java,v $ $Revision: 1.2 $ $Date: 2008/09/05 10:14:42 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/IGroup.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * 	A.Solntsev			2008-08-26	created
 */
package hireright.sdk.html.validator;

import java.util.List;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $, $Date: 2008/09/05 10:14:42 $, $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/IGroup.java,v $
 */
public interface IGroup
{
	List<IValidationElement> getGroupElements();
}
