/*
 * @(#)$RCSfile: CValidationElement.java,v $ $Revision: 1.23 $ $Date: 2015/11/02 20:16:09 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationElement.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * 2002.07.22 A.Nesterov:	Created
 * 2002.10.07 A.Nesterov:	constructors now throw RuntimeException instead Exception
 * 2002.10.08 A.Nesterov:	Added required groups support
 * 2002.12.10 A.Nesterov:	Added inverse patterns support
 * 2003.10.08 A.Nesterov:	Added index conditons support
 * 2003.10.14 A.Podlipski:	Added "ignore_index" feature to CSubElementsList
 * 2003.12.11 A.Nesterov:	Modified parameter list of validate() method
 *
 * 2004-02-06 S.Prokopov	Added support for validation groups
 * 2004-02-20 A.Nesterov	Added support for XML path based id for validation element
 * 2005-01-04	A.Solntsev	Fixed CTraceLog usage.
 * 2005-01-25	A.Solntsev	Added method toProperties().
 * 2005-05-31	P.Bushuk	java_sdk_v2-5-29: Added type definitions for date_compare
 * 2005-11-11 	A.Plohotnichenko	nValidationMode passed to validate().
 * 2006-05-17	A.Zinovjev			Added attribute validation support
 * 2006-10-12	A.Solntsev			Used new class CElementValidationResult for injecting detailed info about invalid elements
 * 2007-06-22	E.Tonkoshkurov	Element type constants were changed. New methods to compare them were added.
 * 2007-02-07	A.Larin					Added types date_from, date_to for comparing dates stored in single "date" nodes
 * 2008-03-05 M.Elshin				Storage field for component_name attribute and related methods were added.
 * 2010-02-04 E.Shatohhin			types inheritance support
 * 2011-03-09 P.Sizov				Added new attribute for vxml element: attributeRequired.
 * 2014-03-20 N.Danilov	m_validationType getter
 * 2015-09-30	M.Lukyanenko	Added validation encoding charset 
 * 2018-11-06	H.Lukashenka	Added new attribute for vxml element: ignore_index
 */
package hireright.sdk.html.validator;

import hireright.sdk.consts.Logical;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.utils.IHttpParametersStorage;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IFilter;
import hireright.sdk.util.IHasProperties;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Validation element class.
 *
 * @author Alexander Nesterov
 * @version "$Revision: 1.23 $, $Date: 2015/11/02 20:16:09 $, $Author: cvsroot $"
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationElement.java,v $
 */
final class CValidationElement implements Serializable, IHasProperties, IValidationElement // implements IInitFromProperties
{
	
	private static final long serialVersionUID = -2276808789361996102L;

	private static final String ATTR_IGNORE_INDEX = "ignore_index";
	private boolean m_bIgnoreIndex;
	
	
	/**
	 * Set of attrubutes represented as elements that will be included into
	 * validation process. String value of each attribute will be validated
	 * by container CValidationElement object.
	 *
	 * @author Andrei Zinovjev
	 */
	public static final class CAttributeList implements IGroup, Serializable
	{
		private static final long serialVersionUID = 946509391250173330L;
		private static final String ATTR_IGNORE_INDEX = "ignore_index";
		private static final String VALUE_IGNORE_INDEX_YES = "Y";

		private boolean m_bIgnoreIndex;
		
		private final List<IValidationElement> m_groupElements;

		/**
		 * Constructs CAttributeList object.
		 * @param listNode			Provided XML list node
		 * @param primaryLibrary	Validation types library
		 */
		CAttributeList(XMLTreeNode listNode, CValidationTypesLibrary primaryLibrary)
		{
			String sIgnoreIndex = null;

			sIgnoreIndex = listNode.getAttribText(ATTR_IGNORE_INDEX);
			m_bIgnoreIndex = (sIgnoreIndex != null && sIgnoreIndex.equalsIgnoreCase(VALUE_IGNORE_INDEX_YES));

			m_groupElements = new ArrayList<IValidationElement>();
			CValidationSet.fillCollectionWithElements(m_groupElements, listNode, primaryLibrary);
		}
		
		public List<IValidationElement> getGroupElements()
		{
			return m_groupElements; // unmodifiable?
		}

		/**
		 * Returns is index ignored.
		 * <p>
		 * @return	true if index must be ignored.
		 */
		public boolean isIgnoreIndex()
		{
			return m_bIgnoreIndex;
		}
	}

	/**
	 * Set of subelements that will be included in validation process if
	 * it's pattern will match against string value validated by container
	 * CValidationElement object.
	 *
	 * @author Alexander Nesterov
	 */
	public static final class CSubElementsList implements IGroup, IFilter<String>, Serializable
	{
		private static final long serialVersionUID = 4069164858806445992L;
		private static final String ATTR_PATTERN = "pattern";
		private static final String ATTR_REV_PATTERN = "npattern";
		private static final String ATTR_IGNORE_INDEX = "ignore_index";
		private static final String VALUE_IGNORE_INDEX_YES = "Y";

		private final String m_sRegexpPattern;
		private final Pattern m_pattern;
		private boolean	m_bIsInversePattern;
		private boolean	m_bIgnoreIndex;

		private final List<IValidationElement> m_groupElements;
		
		/*	-- Can be used for debugging
			props.setProperty("pattern", String.valueOf(m_pattern));
			props.setProperty("isInversePattern", String.valueOf(m_bIsInversePattern));
			props.setProperty("ignoreIndex", String.valueOf(m_bIgnoreIndex));
		 */

		/**
		 * Constructs empty CSubElementsList object
		 */
		CSubElementsList(String pattern)
		{
			m_sRegexpPattern = pattern;
			m_pattern = parse(pattern);
			m_groupElements = new ArrayList<IValidationElement>();
		}

		private static final Pattern parse(String sPattern)
		{
			try
			{
				return Pattern.compile(sPattern);
			}
			catch (RuntimeException e)
			{
				throw e;
			}
			catch (Exception e)
			{
				// For compatibility with old versions of Jakarta Regexp (1.2)
				// In version 1.3 and 1.4, it doesn't happen
				CProperties params = new CProperties()
								.setProperty("pattern", sPattern);
				throw new CRuntimeException(e, CSubElementsList.class.getName(), params);
			}
		}

		/**
		 * Constructs CSubElementsList object from xml
		 * @throws CRuntimeException in case of invalid regexp patterm in some xml attribute
		 */
		CSubElementsList(XMLTreeNode listNode, CValidationTypesLibrary primaryLibrary)
		{
			String sAttribute = null;
			String sIgnoreIndex = null;
			try
			{
				sAttribute = listNode.getAttribText(ATTR_PATTERN);

				if (sAttribute == null)
				{
					sAttribute = listNode.getAttribText(ATTR_REV_PATTERN);
					m_bIsInversePattern = true;
				}

				sIgnoreIndex = listNode.getAttribText(ATTR_IGNORE_INDEX);
				m_bIgnoreIndex = (sIgnoreIndex != null && sIgnoreIndex.equalsIgnoreCase(VALUE_IGNORE_INDEX_YES));

				m_sRegexpPattern = sAttribute;
				m_pattern = parse(sAttribute);
				
				m_groupElements = new ArrayList<IValidationElement>();
				CValidationSet.fillCollectionWithElements(m_groupElements, listNode, primaryLibrary);
			}
			catch (RuntimeException e)
			{
				CProperties params = new CProperties();
				params.setProperty("listNode", listNode);
				params.setProperty("sAttribute", sAttribute);
				params.setProperty("sIgnoreIndex", sIgnoreIndex);
				CTraceLog.error(e, getClass().getName()+".CSubElementsList()", params);
				throw new CRuntimeException("Bad validation XML (subelement): " + listNode, e,
								getClass().getName()+".init", params);
			}
		}
		
		public List<IValidationElement> getGroupElements()
		{
			return m_groupElements; // unmodifiable?
		}

		/**
		 * Returns is index ignored.
		 *
		 * @return	true if index must be ignored.
		 */
		public boolean isIgnoreIndex()
		{
			return m_bIgnoreIndex;
		}

		/**
		 * Matches the objects pattern agaist a String.
		 *
		 * @param sValue	String to match against.
		 * @return 			true if string matched.
		 */
		public boolean match(String sValue)
		{
			if (m_bIsInversePattern)
			{
				return !m_pattern.matcher(sValue).matches();
			}

			return m_pattern.matcher(sValue).matches();
		}
		
		public boolean accept(String sValue)
		{
			return match(sValue);
		}

		public String getPattern()
		{
			return m_sRegexpPattern;
		}
	}

	public CProperties toProperties()
	{
		CProperties props = new CProperties();
		props.setProperties(m_validationType.toProperties());
		props.setProperty("id", m_sID);
		props.setProperty("isPathID", String.valueOf(m_bIsPathID));
		props.setProperty("type", m_sType);
		props.setProperty("indexCondition", m_nIndexCondition);
		props.setProperty("indexNotCondition", m_nIndexNotCondition);
		return props;
	}

	public String toString()
	{
		return "Validation Element {id=" + m_sID + ", type="+m_sType+", pathID="+m_bIsPathID+"}";
	}

	private String			m_sID;			//Element id
	private boolean			m_bIsPathID;	//Element id is path
	/** Stores value of component_name attribute. */
	private String m_sComponentName;

	/**
	 * Type of validation element.
	 */
	private String			m_sType;
	
	private String			m_sAttributeRequired;
	
	/**
	 * Flag that shows that current validation element is actually attribute.
	 */
	private boolean			m_bIsAttribute;

	private Integer			m_nIndexCondition;
	private Integer			m_nIndexNotCondition;
	
	/**
	 * @serial
	 */
	private CValidationType	m_validationType;

	/**
	 * @serial contains CSubElementsList instances
	 */
	private List<CSubElementsList>	m_subLists = new LinkedList<CSubElementsList>();

	/**
	 * List of attributes for given node (validation element)
	 * @serial
	 */
	private CAttributeList	m_attributeList;

	//XML format tags and attributes
	private final static String TAG_SUB_ELEMENTS = "sub_elements";
	public	final static String TAG_VALIDATION_ELEMENT = "element";
	private final static String ATTR_TYPE = "type";
	private static final String ATTR_BASE_TYPE = "base_type";
	private final static String ATTR_INDEX = "index";
	private final static String ATTR_INDEX_NOT = "index_not";
	private final static String ATTR_ID = "id";
	private final static String ATTR_PATH = "path";
	private final static String ATTR_ATTRIBUTE_REQUIRED = "attributeRequired";
	/**
	 * 
	 * Attribute of element tag. All elements with the same component_name counts as a single
	 * invalid field, in spite of how many of them are invalid.
	 * */
	private static final String ATTR_COMPONENT_NAME = "component_name";

	/**
	 * Tag name for list of attributes for given element
	 */
	private final static String TAG_ATTRIBUTES = "element_attributes";

	/**
	 * Tag name for attribute description
	 */
	public final static String TAG_VALIDATION_ATTRIBUTE = "element_attribute";

	// Validation element types
	/**
	 * This value is used to identify type of element inside validation group.
	 * In this case element value is year.
	 */
	private final static String TYPE_YEAR_SHORT = "y";
	private final static String TYPE_YEAR_FULL = "year";

	/**
	 * This value is used to identify type of element inside validation group.
	 * In this case element value is month.
	 */
	private final static String TYPE_MONTH_SHORT = "m";
	private final static String TYPE_MONTH_FULL = "month";

	/**
	 * This value is used to identify type of element inside validation group.
	 * In this case element value is day.
	 */
	private final static String TYPE_DAY_SHORT = "d";
	private final static String TYPE_DAY_FULL = "day";

	/**
	 * This value is used to identify type of element inside validation group.
	 * In this case element value is start day.
	 */
	public final static String TYPE_DAY_FROM = "day_from";

	/**
	 * This value is used to identify type of element inside validation group.
	 * In this case element value is start month.
	 */
	public final static String TYPE_MONTH_FROM = "month_from";

	/**
	 * This value is used to identify type of element inside validation group.
	 * In this case element value is start year.
	 */
	public final static String TYPE_YEAR_FROM = "year_from";

	/**
	 * This value is used to identify type of element inside validation group.
	 * In this case element value is end day.
	 */
	public final static String TYPE_DAY_TO = "day_to";

	/**
	 * This value is used to identify type of element inside validation group.
	 * In this case element value is end month.
	 */
	public final static String TYPE_MONTH_TO = "month_to";

	/**
	 * This value is used to identify type of element inside validation group.
	 * In this case element value is end year.
	 */
	public final static String TYPE_YEAR_TO = "year_to";

	/**
	 * Defines a "date from" type of element for comparing dates.
	 */
	public final static String TYPE_DATE_FROM = "date_from";

	/**
	 * Defines a "date to" type of element for comparing dates.
	 */
	public final static String TYPE_DATE_TO = "date_to";

	/**
	 * Constructs CValidationElement object.
	 * <p>
	 * @param sID					element id.
	 * @param validationType		type of validation.
	 * @param nIndexCondition		index condition.
	 * @param nIndexNotCondition	index not in condition.
	 */
	public CValidationElement(String sID, CValidationType validationType, Integer nIndexCondition, Integer nIndexNotCondition)
	{
		m_sID = sID;
		m_nIndexCondition = nIndexCondition;
		m_nIndexNotCondition = nIndexNotCondition;
		m_validationType = validationType;
		m_bIsPathID = false;
	}

	/**
	 * Constructs CValidationElement object.
	 * <p>
	 * @param sID					element id.
	 * @param validationType		type of validation.
	 * @param nIndexCondition		index condition.
	 * @param nIndexNotCondition	index not in condition.
	 * @param bIsPathID				specify true if sID value must be iterpreted as XML path
	 */
	public CValidationElement(String sID,
					CValidationType validationType,
					Integer nIndexCondition,
					Integer nIndexNotCondition,
					boolean bIsPathID)
	{
		m_sID = sID;
		m_nIndexCondition = nIndexCondition;
		m_nIndexNotCondition = nIndexNotCondition;
		m_validationType = validationType;
		m_bIsPathID = bIsPathID;
	}

	/**
	 * Passes data into other constructor for non-attribute elements.
	 * <p>
	 * @param validationElementNode	XML representation of element.
	 * @param primaryLibrary 		validation library.
	 */
	public CValidationElement(XMLTreeNode validationElementNode,
					CValidationTypesLibrary primaryLibrary)
	{
		this(validationElementNode, primaryLibrary, false);
	}

	/**
	 * Constructs CValidationElement object.
	 * <p>
	 * @param validationElementNode	XML representation of element.
	 * @param primaryLibrary		validation library.
	 * @param bIsAttribute			Use new validation element as attribute.
	 */
	public CValidationElement(XMLTreeNode validationElementNode,
					CValidationTypesLibrary primaryLibrary, boolean bIsAttribute)
	{
		String sNumber = null;

		m_bIsAttribute = bIsAttribute;

		setComponentName(validationElementNode.getAttribText(ATTR_COMPONENT_NAME));
		try
		{	//Init m_sID with id or path
			if((m_sID = validationElementNode.getAttribText(ATTR_ID)) == null)
			{
				if ((m_sID = validationElementNode.getAttribText(ATTR_PATH)) != null)
					m_bIsPathID = true;
				else
					throw new RuntimeException("Validation element has no ID" + validationElementNode);
			}

			m_sType = validationElementNode.getAttribText(ATTR_TYPE);

			sNumber = validationElementNode.getAttribText(ATTR_INDEX);

			m_sAttributeRequired = validationElementNode.getAttribText(ATTR_ATTRIBUTE_REQUIRED);
			
			if (sNumber != null)
				m_nIndexCondition = new Integer(sNumber);

			sNumber = validationElementNode.getAttribText(ATTR_INDEX_NOT);
			if (sNumber != null)
				m_nIndexNotCondition = new Integer(sNumber);

			if (m_nIndexCondition != null && m_nIndexNotCondition != null)
				throw new RuntimeException("More than one index condition specified");
			
			String sIgnoreIndex = validationElementNode.getAttribText(ATTR_IGNORE_INDEX);
			m_bIgnoreIndex = (sIgnoreIndex != null && Logical.isTrue(sIgnoreIndex));

			XMLTreeNode elementFieldNode = validationElementNode.getChildNodeByTag(CValidationType.TAG_VALIDATION_TYPE);
			String sType = elementFieldNode.getAttribText(ATTR_TYPE);

			if (sType != null && sType.length() != 0)
			{
				//Get reference from primary library
				if(primaryLibrary == null || (m_validationType = primaryLibrary.getValidationType(sType)) == null)
				{
					//else get reference from CValidationTypesManager
					m_validationType = CValidationTypesManager.getValidationType(sType);
				}
			}
			else
			{
				String sBaseType = elementFieldNode.getAttribText(ATTR_BASE_TYPE);
				if( !CStringUtils.isEmpty( sBaseType ) )
				{
					CValidationType baseType; 
					//Get reference from primary library
					if(primaryLibrary == null || (baseType = primaryLibrary.getValidationType(sBaseType)) == null)
					{
						//else get reference from CValidationTypesManager
						baseType = CValidationTypesManager.getValidationType(sBaseType);
					}
					
					if( baseType != null)
					{
						m_validationType = new CValidationType(elementFieldNode, baseType );
						m_validationType.setVersion( CValidationTypesLibrary.VERSION_v1_2 );
					}
				}
				else
				{
					m_validationType = new CValidationType(elementFieldNode);
				}
			}

			if (m_validationType == null)
				throw new IllegalArgumentException("Unknown validation type: " + sType);

			elementFieldNode = validationElementNode.getChildNodeByTag(TAG_SUB_ELEMENTS, 1);
			if(elementFieldNode != null)
			{
				elementFieldNode = (XMLTreeNode)elementFieldNode.firstChildNode();

				while(elementFieldNode != null)
				{
					m_subLists.add(new CSubElementsList(elementFieldNode, primaryLibrary));
					elementFieldNode = (XMLTreeNode)elementFieldNode.getNextNode();
				}
			}

			// Find attribute elements, use only one group of them
			elementFieldNode = validationElementNode.getChildNodeByTag(TAG_ATTRIBUTES, 1);
			if (elementFieldNode != null)
			{
				m_attributeList = new CAttributeList(elementFieldNode, primaryLibrary);
			}
		}
		catch (CValidationConfigurationException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			CProperties params = new CProperties();
			params.setProperty("validationElementNode", validationElementNode);
			params.setProperty("sNumber", sNumber);
			params.setProperty("m_bIsPathID", String.valueOf(m_bIsPathID));
			params.setProperty("m_sID", m_sID);
			params.setProperty("m_nIndexCondition", m_nIndexCondition);
			params.setProperty("m_nIndexNotCondition", m_nIndexNotCondition);
			throw new CValidationConfigurationException("Bad validation XML: " + validationElementNode, e, params);
		}
	}

	/**
	 * Checks if argument is day type constant.
	 * <p>
	 * @param	attr attribute to check
	 * @return 	true if attr equals to "d" or "day".
	 */
	public static boolean isDayTypeAttr(String attr)
	{
		return ((attr.equals(TYPE_DAY_SHORT)) || (attr.equals(TYPE_DAY_FULL)));
	}

	/**
	 * Checks if argument is month type constant.
	 * <p>
	 * @param	attr attribute to check
	 * @return 	true if attr equals to "m" or "month".
	 */
	public static boolean isMonthTypeAttr(String attr)
	{
		return ((attr.equals(TYPE_MONTH_SHORT)) || (attr.equals(TYPE_MONTH_FULL)));
	}

	/**
	 * Checks if argument is year type constant.
	 * <p>
	 * @param	attr attribute to check
	 * @return 	true if attr equals to "y" or "year".
	 */
	public static boolean isYearTypeAttr(String attr)
	{
		return ((attr.equals(TYPE_YEAR_SHORT)) || (attr.equals(TYPE_YEAR_FULL)));
	}

	/**
	 * Adds subelements to list.
	 * <p>
	 * @param subElementsList	sub elements to add.
	 */
	public void addSubList(CSubElementsList subElementsList)
	{
		m_subLists.add(subElementsList);
	}

	/**
	 * Returns element id.
	 * <p>
	 * @return 	validation element id.
	 */
	public String getId()
	{
		return m_sID;
	}

	/**
	 * Returns true if given validation element is attribute
	 * @return true attribute
	 */
	public boolean isAttribute()
	{
		return m_bIsAttribute;
	}

	/**
	 * Returns validation sub lists.
	 * <p>
	 * @return list of sub lists.
	 */
	public List<CSubElementsList> getValidationSubLists()
	{
		return m_subLists;
	}
	
	public CValidationType getValidationType() 
	{
		return m_validationType;
	}
	

	/**
	 * Returns validation sublist with pattern that matches with string value.
	 *
	 * @param sValue	string value for matching
	 * @return new instance CSubElementsList containing subset of this sublist (only matching elements)
	 */
	public CSubElementsList getMatchedSubList(String sValue)
	{
		for (CSubElementsList subList : m_subLists)
		{
			if (subList.match(sValue))
				return subList;
		}

		return null;
	}

	/**
	 * Returns validation attribute list
	 *
	 * @return attribute list
	 */
	public CAttributeList getAttributes()
	{
		return m_attributeList;
	}

	/**
	 * Validates parameter string. Plese note that this method will not accept null parameters.
	 * <p>
	 * @param sValue		value to validate.
	 * @param nIndex		index of container/parameter that stores value.
	 * @param paramStorage	storage of parameters.
	 * @param nValidationMode validation mode
	 */
	CElementValidationResult validate(String sValue, int nIndex, Boolean bRequired, 
			IHttpParametersStorage paramStorage, int nValidationMode)
	{
		return m_validationType.validate(sValue, nIndex, bRequired, paramStorage, nValidationMode);
	}
	
	/**
	 * Validates parameter string. Plese note that this method will not accept null parameters.
	 * <p>
	 * @param sValue		value to validate.
	 * @param nIndex		index of container/parameter that stores value.
	 * @param paramStorage	storage of parameters.
	 * @param nValidationMode validation mode
	 * @param sEncoding validation encoding mode
	 */
	CElementValidationResult validate(String sValue, int nIndex, Boolean bRequired, 
			IHttpParametersStorage paramStorage, int nValidationMode, String sEncoding)
	{
		return m_validationType.validate(sValue, nIndex, bRequired, paramStorage, nValidationMode, sEncoding);
	}

	/**
	 * Checks index condition.
	 * <p>
	 * @param nIndex	index to check.
	 * @return			true if index matches element.
	 */
	public boolean checkIndexCondition(int nIndex)
	{
		return (m_nIndexCondition == null && m_nIndexNotCondition == null) ||
						(m_nIndexCondition != null && m_nIndexCondition.intValue() == nIndex) ||
						(m_nIndexNotCondition != null && m_nIndexNotCondition.intValue() != nIndex);
	}
	
	/**
	 * Returns type of element.
	 * <p>
	 * @return	type of element.
	 */
	public String getType()
	{
		return m_sType;
	}

	public String getAttributeRequired()
	{
		return m_sAttributeRequired;
	}
	
	/**
	 * Returns true if value, returned by getId(), can be iterpreted as XML path
	 * <p>
	 * @return	true if value, returned by getId(), can be iterpreted as XML path
	 */
	public boolean hasPathBasedId()
	{
		return m_bIsPathID;
	}

	/**
	 * Returns component name.
	 * @return the component name.
	 */
	public String getComponentName()
	{
		return m_sComponentName;
	}

	/**
	 * Sets component name.
	 * @param sComponentName the component name to set.
	 */
	public void setComponentName(String sComponentName)
	{
		m_sComponentName = sComponentName;
	}
	
	/**
	 * Returns is index ignored.
	 * <p>
	 * @return	true if index must be ignored.
	 */
	public boolean isIgnoreIndex()
	{
		return m_bIgnoreIndex;
	}
}
