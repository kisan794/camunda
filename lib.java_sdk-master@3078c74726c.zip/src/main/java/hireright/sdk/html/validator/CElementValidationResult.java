/*
 * @(#)$RCSfile: CElementValidationResult.java,v $ $Revision: 1.4 $ $Date: 2008/09/05 10:15:16 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CElementValidationResult.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *	A.Solntsev	2006-09-15	Created 
 */
package hireright.sdk.html.validator;

import java.io.Serializable;

/**
 * Class CElementValidationResult is used for storing detailed information about invalid elements.
 * Later this info an be used for injecting into xml. 
 * 
 * @author Andrei Solntsev
 * @since Oct 31, 2006
 * @version $Revision: 1.4 $ $Date: 2008/09/05 10:15:16 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CElementValidationResult.java,v $
 */
public class CElementValidationResult implements Serializable
{
	public static final CElementValidationResult VALID = new CElementValidationResult(0);
	
	private final int m_nStatus;
	private final String m_sMessage;
	
	CElementValidationResult(int status)
	{
		this(status, null);
	}
	
	CElementValidationResult(int status, String sMessage)
	{
		m_nStatus = status;
		m_sMessage = sMessage;
	}
	
	public int getStatus()
	{
		return m_nStatus;
	}
	
	public String getMessage()
	{
		return m_sMessage;
	}
	
	@Override
	public String toString()
	{
		return "Status: " + m_nStatus + ", message: " + m_sMessage;
	}
}
