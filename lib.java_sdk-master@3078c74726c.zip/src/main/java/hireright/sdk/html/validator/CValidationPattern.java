/*
 * @(#)$RCSfile: CValidationPattern.java,v $ $Revision: 1.3 $ $Date: 2008/09/05 10:57:47 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationPattern.java,v $
 *
 * Copyright 2001-2008 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	E.Tonkoshkurov		2008-03-26	Created.
 *	A.Solntsev				2008-08-26	Members are final, class is Serializable
 */
package hireright.sdk.html.validator;

import java.io.Serializable;
import java.util.regex.Pattern;

/**
 * Class represents child element for validation type: validation pattern. There are two
 * different kinds of patterns: inverted ("npattern") and not inverted ("pattern").
 *
 * @author Evgeny Tonkoshkurov
 * @version $Revision: 1.3 $ $Date: 2008/09/05 10:57:47 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CValidationPattern.java,v $
 */
public class CValidationPattern implements Serializable
{
	/** Constant with current version of this class and its author. */
	protected static final String CLASS_VERSION = "$Revision: 1.3 $ $Author: asolntsev $";

	/** XML tag for not inverted pattern (used in the other classes from this package). */
	final static String TAG_PATTERN = "pattern";

	/** XML tag for inverted pattern (used in the other classes from this package). */
	final static String TAG_INVERTED_PATTERN = "npattern";

	/** Class member with "true" value if this pattern is inverted. */
	private final boolean m_bInverted;

	/** java.util.regex.Pattern instance for this validation pattern. */
	private final Pattern m_pattern;

	/**
	 * Creates not inverted validation pattern with given Pattern.
	 * 
	 * @param pattern Pattern for this validation pattern.
	 */
	public CValidationPattern(Pattern pattern)
	{
		this(pattern, false);
	}

	public CValidationPattern(String sRegexp)
	{
		this(Pattern.compile( sRegexp ), false);
	}
	
	public CValidationPattern(String sRegexp, boolean inverted)
	{
		this(Pattern.compile( sRegexp ), inverted);
	}
	
	/**
	 * Creates validation pattern with given Pattern and inverted status.
	 *
	 * @param pattern Pattern for this validation pattern.
	 * @param inverted true if this validation pattern should be inverted.
	 */
	public CValidationPattern(Pattern pattern, boolean inverted)
	{
		this.m_pattern = pattern;
		this.m_bInverted = inverted;
	}

	/**
	 * Checks input value according to current validation pattern.
	 *
	 * @param input CharSequence with input value.
	 * @return true if given value mathes pattern.
	 */
	public boolean matches(CharSequence input)
	{
		boolean matchesPattern = m_pattern.matcher(input).matches();
		if (m_bInverted)
		{
			return !matchesPattern;
		}
		return matchesPattern;
	}

	/**
	 * Returns this pattern's reqular expression String.
	 *
	 * @return String with this pattern's regular expression.
	 */
	public String getPatternString()
	{
		return m_pattern.pattern();
	}

	/**
	 * Returns this pattern's Inverted status.
	 *
	 * @return true if this pattern is inverted.
	 */
	public boolean isInverted()
	{
		return m_bInverted;
	}

	/**
	 * Returns this pattern's Pattern instance.
	 *
	 * @return this validation pattern's Pattern instance.
	 */
	public Pattern getPattern()
	{
		return m_pattern;
	}

	/**
	 * Returns pattern description.
	 *
	 * @return String with validation pattern description.
	 */
	public String toString()
	{
		return (isInverted()? TAG_INVERTED_PATTERN:TAG_PATTERN) + ": " + getPatternString();
	}
}
