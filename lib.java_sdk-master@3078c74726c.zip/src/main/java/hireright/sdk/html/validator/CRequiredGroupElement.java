/*
 * @(#)$RCSfile: CRequiredGroupElement.java,v $ $Revision: 1.4 $ $Date: 2008/09/05 10:10:01 $ $Author: asolntsev $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CRequiredGroupElement.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * A.Nesterov			2002-10-04	Created
 * S.Ignatov			2003-09-24	completely rewritten.
 * A.Solntsev			2008-08-26	Removed "extends LinkedList"; added "extends CGroup"; added generics.
 */
package hireright.sdk.html.validator;
import hireright.sdk.html.parser.XMLTreeNode;

import java.io.Serializable;

/**
 * CRequiredGroupElement class.
 *
 * @author Alexander Nesterov
 * @version $Revision: 1.4 $ $Date: 2008/09/05 10:10:01 $ $Author: asolntsev $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/html/validator/CRequiredGroupElement.java,v $
 */
final class CRequiredGroupElement extends CGroup implements Serializable, IValidationElement 
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: asolntsev $";
	
	public static final String REQUIRED_GROUP_TAG = "required_group";
	
	public CRequiredGroupElement(XMLTreeNode groupElementNode, CValidationTypesLibrary primaryLibrary) 
	{
		super(groupElementNode, primaryLibrary);
	}
}

