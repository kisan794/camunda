package hireright.sdk.html.validator;

/*
 * Copyright 2001-2021 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * J.Jegorov	2021-03-17	Created
 * T.Hasan		2021-04-13	HRG-125917: create constructor with isValid parameter
 */

import java.io.Serializable;
import java.util.List;


public class CValidationResult implements Serializable
{
	
	private boolean isValid;
	private List<CValidationError> errors;
	
	public CValidationResult() {}
	
	public CValidationResult(boolean isValid)
	{
		this.isValid = isValid;
	}
	
	public CValidationResult setErrors(List<CValidationError> errors)
	{
		this.errors = errors;
		return this;
	}
	
	public CValidationResult setValid(boolean isValid)
	{
		this.isValid = isValid;
		return this;
	}
	
	public boolean isValid()
	{
		return isValid;
	}
	
	public  List<CValidationError> getErrorList()
	{
		return errors;
	}
}
