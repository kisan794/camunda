/*
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	2002.07.22: Created
 *	2002.10.08 A.Nesterov		Removed suppord for IGNORED status
 *	2002.11.22 A.Nesterov		Fixed bug in method validate(...)\
 *	2003.12.11 A.Nesterov		Added "compare" feature
 *	2005-01-25 A.Solntsev		Added method toProperties().
 *	2005-11-11 A.Plohotnichenko	nValidationMode passed to validate().
 *	2006-10-12 A.Solntsev		Used new class CElementValidationResult for injecting detailed info about invalid elements
 *	2006-10-12 A.Solntsev		Used package java.util.regex.* instead of org.apache.regexp.*
 *	2008-03-26 E.Tonkoshkurov	Added multiple pattern handling. 
 *	2009-07-27 Y.Shneykin		Added field m_sCompareType. Added functionality for different comparing 
 *										of values to values,- not_contains, equals, etc.. Added method validateComparison(),
 *										constructor, taking m_sCompareType and some constants for new constructor.
 *										Added ability to take <compare> textNode as path, not only as id of an element.
 *	2010-02-02 E.Shatohhin	support pattern without CDATA, 
 *										removed incorrect message for empty elements, in case required=false
 *										types inheritance support
 *	2011-03-09 P.Sizov		Added new attribute for vxml element: attributeRequired.
 *	2015-07-23 M.Lukyanenko	Added encoding validation mode
 *	2024-10-11	H.Lukashenka	HRG-321978: Replace two Windows symbols("\r\n") with one symbol("\n") to correctly calculate length of string
 */
package hireright.sdk.html.validator;
import hireright.sdk.html.parser.XMLConsts;
import hireright.sdk.html.parser.XMLTreeNode;
import hireright.sdk.html.utils.IHttpParametersStorage;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CRuntimeException;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.IHasProperties;

import java.io.Serializable;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 
 * @author A.Nesterov
 * @since July 2002
 */
public class CValidationType implements Serializable, IHasProperties
{
	private static final long serialVersionUID = -8425049479264703454L;

	/**
	 * Compare type for value not to contain another value.
	 */
	public static final String COMPARE_TYPE_NOT_CONTAINS = "not_contains";

	/**
	 * Compare type for value not to be equal to another value.
	 */
	public static final String COMPARE_TYPE_EQUALS = "equals";
	
	/**
	 * Compare node attribute name 'type'
	 */
	private static final String COMPARE_NODE_ATTRIBUTE_TYPE = "type";
	
	private final static String TAG_REQUIRED = "required";
	private final static String TAG_MIN_LENGTH = "min_length";
	private final static String TAG_MAX_LENGTH = "max_length";
	private final static String TAG_COMPARE = "compare";
	private final static String TAG_ENCODING = "encoding";
	public final static String TAG_VALIDATION_TYPE = "validation_type";
	private float m_version = CValidationTypesLibrary.VERSION_v1_0;

	private static final int DEFAULT_MIN_LENGTH = 0;
	private static final int DEFAULT_MAX_LENGTH = 256;
	
	/**
	 * Minimum valid length (min number of characters)
	 * Values <= 0 interpreted as undefined.
	 * The default value is 0
	 */
	private final int		m_nMinLength;

	/**
	 * Maximum valid length (max number of characters)
	 * Values <= 0 interpreted as undefined.
	 * The default value is 256
	 */
	private final int		m_nMaxLength;
	
	/**
	 * Marks element as required
	 */
	private final boolean m_bIsRequired;

	/**
	 * Encoding to use when validating this field. Overrides global encoding.
	 */
	private final String m_sEncoding;
	
	private String	m_sCompareElementID;
	private String m_sCompareType;
	private final List<CValidationPattern> m_patternList;

	//Status flags
	public static final int EMPTY = 0x0001;
	public static final int INVALID = 0x0002;

	public CValidationType(boolean bIsRequired, int nMinLength, int nMaxLength, 
			List<CValidationPattern> patternList, String sCompareElementID)
	{
		this(bIsRequired, nMinLength, nMaxLength, patternList, sCompareElementID, null, null);
	}
	
	/**
	 * Constructor. Initializes all parameters.
	 * 
	 * @param bIsRequired          is required flag.
	 * @param nMinLength           minimum length.
	 * @param nMaxLength           maximum length.
	 * @param patternList          list of patterns.
	 * @param sCompareElementID          id of element to compare.
	 * @param sCompareType               type of comparison.
	 * @param sEncoding            encoding to use.
	 */
	public CValidationType(
			boolean bIsRequired, int nMinLength, int nMaxLength, 
			List<CValidationPattern> patternList, String sCompareElementID,
			String sCompareType, String sEncoding)
	{
		m_bIsRequired = bIsRequired;
		m_nMinLength = nMinLength;
		m_nMaxLength = nMaxLength;
		m_patternList = patternList;
		m_sCompareElementID = sCompareElementID;
		m_sCompareType = sCompareType;
		m_sEncoding = sEncoding;
	}
	
	public CValidationType(boolean bIsRequired, CValidationPattern pattern)
	{
		this(bIsRequired, DEFAULT_MIN_LENGTH, DEFAULT_MAX_LENGTH, 
				Arrays.asList( new CValidationPattern[]{pattern}), null); 
	}
	
	public CProperties toProperties()
	{
		CProperties props = new CProperties();
		props.setProperty("patternList", patternListToString());
		props.setProperty("minLength", m_nMinLength);
		props.setProperty("maxLength", m_nMaxLength);
		props.setProperty("isRequired", String.valueOf(m_bIsRequired));
		props.setProperty("compareElementID", m_sCompareElementID);
		props.setProperty("compareType", m_sCompareType);
		props.setProperty("encoding", m_sEncoding);
		return props;
	}
	
	public String toString()
	{
		String sResult = "Validation Type " + (m_bIsRequired? "required":"optional") + " ";
		sResult += patternListToString();
		return sResult;
	}
	
	/**
	 * Constructor
	 */
	public void setVersion(float version)
	{
		m_version = version;
	}
	
	private static int getNodeValue(XMLTreeNode validationTypeNode, String sTagName, int defaultValue)
	{
		XMLTreeNode elementFieldNode = validationTypeNode.getChildNodeByTag(sTagName, 1);
		if (elementFieldNode != null)
			return Integer.parseInt(elementFieldNode.getText());
		
		return defaultValue;
	}
	
	public CValidationType(XMLTreeNode validationTypeNode)
	{
		this(validationTypeNode, null);
	}
	
	/**
	 * Construct new CValidationType using base type and override some settings.
	 * 
	 * TODO: support compare stuff for baseType
	 * 
	 * @param validationTypeNode
	 * @param baseType
	 */
	public CValidationType(XMLTreeNode validationTypeNode, CValidationType baseType) 
	{
		XMLTreeNode elementFieldNode = validationTypeNode.getChildNodeByTag(TAG_REQUIRED, 1);

		if( elementFieldNode != null )
		{
			m_bIsRequired =  elementFieldNode.getText().equals("true");
		}
		else
		{
			m_bIsRequired = baseType != null ? baseType.m_bIsRequired : false;
		}
	
		m_nMinLength = getNodeValue(validationTypeNode, TAG_MIN_LENGTH, 
				baseType != null ? baseType.m_nMinLength : DEFAULT_MIN_LENGTH);
		m_nMaxLength = getNodeValue(validationTypeNode, TAG_MAX_LENGTH, 
				baseType != null ? baseType.m_nMaxLength : DEFAULT_MAX_LENGTH);

		// Generating List with patterns:
		if( baseType != null )
		{
			m_patternList = new ArrayList<CValidationPattern>(baseType.m_patternList);
		}
		else
		{
			m_patternList = new ArrayList<CValidationPattern>();
		}
		
		int nNodesCount = validationTypeNode.getChildNodesCount(CValidationPattern.TAG_PATTERN);
		for (int i = 1; i < nNodesCount + 1; i++)
		{
			elementFieldNode = validationTypeNode
					.getChildNodeByTag(CValidationPattern.TAG_PATTERN, i);
			String sPattern = elementFieldNode.getText(XMLConsts.TYPE_CDATA);
			if ( CStringUtils.isEmpty( sPattern ) )
			{
				sPattern = elementFieldNode.getText().trim();
			}
			if (sPattern.length() > 0)
			{
				m_patternList.add(new CValidationPattern(Pattern.compile(sPattern), false));
			}
		}
		nNodesCount = validationTypeNode.getChildNodesCount(CValidationPattern.TAG_INVERTED_PATTERN);
		for (int i = 1; i < nNodesCount + 1; i++)
		{
			elementFieldNode = validationTypeNode
					.getChildNodeByTag(CValidationPattern.TAG_INVERTED_PATTERN, i);
			String sPattern = elementFieldNode.getText(XMLConsts.TYPE_CDATA);
			if ( CStringUtils.isEmpty( sPattern ) )
			{
				sPattern = elementFieldNode.getText().trim();
			}
			if (sPattern.length() > 0)
			{
				m_patternList.add(new CValidationPattern(Pattern.compile(sPattern), true));
			}
		}

		elementFieldNode = validationTypeNode.getChildNodeByTag(TAG_COMPARE, 1);
		if (elementFieldNode != null)
		{
			String sElementID = elementFieldNode.getText();
			
			if (sElementID.length() == 0)
			{
				throw new CRuntimeException("Element to be compared is empty",
						getClass().getName()+".init", toProperties());
			}

			m_sCompareElementID = sElementID;
			String sCompareType = elementFieldNode.getAttribText(COMPARE_NODE_ATTRIBUTE_TYPE);
			if(!CStringUtils.isEmpty(sCompareType))
			{
				m_sCompareType = sCompareType;
			}
		}

		XMLTreeNode encodingNode = validationTypeNode.getChildNodeByTag(TAG_ENCODING, 1); 
		m_sEncoding = encodingNode == null ? null : encodingNode.getText();
	}

	/**
	 * Validates parameter string. Plese note that this method will not accept null parameters.
	 * @param sValue string value to validate
	 * @param nIndex index of container/parameter that stores value
	 * @param paramStorage storage of parameters
	 * @param nValidationMode validation mode
	 */
	CElementValidationResult validate(
			String sValue, int nIndex, Boolean bRequired, IHttpParametersStorage paramStorage, int nValidationMode)
	{
		return validate(sValue, nIndex, bRequired, paramStorage, nValidationMode, CValidator.VALIDATION_DEFAULT_ENCODING);
	}
	/**
	 * Validates parameter string. Plese note that this method will not accept null parameters.
	 * @param sValue string value to validate
	 * @param nIndex index of container/parameter that stores value
	 * @param paramStorage storage of parameters
	 * @param nValidationMode validation mode
	 * @param sEncoding encoding charset
	 */
	CElementValidationResult validate(
			String sValue, int nIndex, Boolean bRequired, IHttpParametersStorage paramStorage, int nValidationMode, String sEncoding)
	{
		if (bRequired == null)
		{
			bRequired = m_bIsRequired;
		}
		
		// Validate required (not empty) value
		if (sValue.length() == 0)
		{
			if (bRequired && 
					((nValidationMode & CValidator.VALIDATION_MODE_REQUIRED)
							== CValidator.VALIDATION_MODE_REQUIRED))
			{
				return new CElementValidationResult(EMPTY | INVALID, "Required element is empty");
			}
			else
			{
				return new CElementValidationResult(EMPTY);
			}
		}

		// Validate value against pattenrs
		if ((nValidationMode & CValidator.VALIDATION_MODE_FORMAT) == CValidator.VALIDATION_MODE_FORMAT)
		{
			int nLength = sValue.replace("\r\n", "\n").length();
			if (m_patternList.isEmpty())
			{
				if (nLength < m_nMinLength)
				{
					return new CElementValidationResult(
							INVALID, "Required minimal length is not met. Add "+(m_nMinLength-nLength)+" characters.");
				}
				else if (nLength > m_nMaxLength)
				{
					return new CElementValidationResult(
							INVALID, "Maximum length exceeded. Remove " + (nLength-m_nMaxLength)
							+ " characters.");
				}
			}	
			else 
			{
				if (m_version >= CValidationTypesLibrary.VERSION_v1_2 && nLength < m_nMinLength)
				{
					return new CElementValidationResult(
							INVALID, "Required minimal length is not met. Add "+(m_nMinLength-nLength)+" characters.");
				}
				else if (m_version >= CValidationTypesLibrary.VERSION_v1_2 && nLength > m_nMaxLength)
				{
					return new CElementValidationResult(
							INVALID, "Maximum length exceeded. Remove " + (nLength-m_nMaxLength)
							+ " characters.");
				}

				for (CValidationPattern pattern : m_patternList)
				{
					if (!pattern.matches(sValue))
					{
						return new CElementValidationResult(INVALID, "Invalid element value");
					}
				}
				
			}
		}

		//Validate comparable values
		if ((nValidationMode & 
				CValidator.VALIDATION_MODE_DUPLICATED) == CValidator.VALIDATION_MODE_DUPLICATED)
		{
			if (m_sCompareElementID != null)
			{
				XMLTreeNode node = paramStorage.getParameter(m_sCompareElementID, nIndex);
				if (node == null)
				{
					//element can be also specified by it's path.
					node = paramStorage.getNodeByPath(m_sCompareElementID, nIndex);
				}
				//Let's assume that sValue is not empty, because this code is not reacheable if it is.
				if(node == null)
				{
					return new CElementValidationResult(INVALID);
				}
				else 
				{
					String sNodeText = node.getText(XMLConsts.TYPE_TEXT | XMLConsts.TYPE_CDATA);
	
					if (!validateComparison(sValue, sNodeText, m_sCompareType))
					{
						return new CElementValidationResult(INVALID, "Element value: " + sValue 
								+ " doesn't correspond with required rule: " + m_sCompareType 
								+ " to compared node value " + sNodeText);

					}
				}
			}
		}
		
		if (m_sEncoding != null)
		{
			sEncoding = m_sEncoding;
		}
		
		if((nValidationMode & CValidator.VALIDATION_MODE_ENCODING) == CValidator.VALIDATION_MODE_ENCODING && CStringUtils.isNotEmpty(sEncoding))
		{
			
			CharsetEncoder enc = Charset.forName(sEncoding).newEncoder();
			if (!enc.canEncode(sValue))
				return new CElementValidationResult(INVALID, "Invalid encoding type");
		}
		
		return CElementValidationResult.VALID;
	}
	
	/**
	 * Compares values depending on compare type.
	 * 
	 * @param value            value to compare with.
	 * @param comparedValue          compared value.
	 * @param compareType         type of comparison.
	 * @return boolean             true if comparison corresponds with 
	 * 									requirement (type). Otherwise false.
	 */
	private boolean validateComparison(String value, String comparedValue, 
			String compareType)
	{
		if(value == null)
		{
			return false;
		}
		else if(compareType == null || compareType.equals(COMPARE_TYPE_EQUALS))
		{
			return value.equals(comparedValue);
		}
		else if(compareType.equals(COMPARE_TYPE_NOT_CONTAINS))
		{
			return value.indexOf(comparedValue) == -1;
		}
		else
		{
			throw new CRuntimeException("Unknown compare type." + getClass().getName() + 
					".init", toProperties());
		}
	}

	/**
	 * Returns true is element is required
	 */
	public boolean isRequired()
	{
		return m_bIsRequired;
	}

	/**
	 * Returns String with all patterns in this validation type.
	 *
	 * @return String with all patterns (both inverted and not inverted).
	 */
	protected String patternListToString()
	{
		if (m_patternList.isEmpty() )
			return CStringUtils.EMPTY_STRING;
		else if (m_patternList.size() == 1)
		{
			return ((CValidationPattern) m_patternList.get(0)).getPattern().pattern();
		}
		
		StringBuffer sbResult = new StringBuffer();
		for (CValidationPattern pattern : m_patternList)
		{
			sbResult.append(pattern).append(" ");
		}
		return sbResult.toString();
	}
}

