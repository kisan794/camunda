/*
 * @(#)$RCSfile: CThreadLocalMultiSessionContext.java,v $ $Revision: 1.4 $ $Date: 2015/11/02 20:16:45 $ $Author: cvsroot $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   M.Suhhoruki		2014-08-01	sendRequest(CRequestContext ctx)
 */
package hireright.sdk.db2;

import hireright.sdk.db.CHashableConnection;
import hireright.sdk.db3.DB;
import hireright.sdk.db3.DBSyncException;
import hireright.sdk.db3.IDBSync;
import hireright.sdk.debug.CStackTrace;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CClosableRegistry;
import hireright.sdk.util.IClosable;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.transaction.Synchronization;

import org.hibernate.ConnectionReleaseMode;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.context.CurrentSessionContext;
import org.hibernate.context.ThreadLocalSessionContext;
import org.hibernate.engine.SessionFactoryImplementor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copy of @link {@link ThreadLocalSessionContext} with added multiple current sessions support.
 * One current session per CCurrentThreadConnection.getConnection().
 * 
 *  This class also includes CTrackingCurrentSessionContext tracking function.
 *  See {@link CThreadLocalMultiSessionContext#trackSessionCreation}
 */
public class CThreadLocalMultiSessionContext implements CurrentSessionContext
{
	private static final long serialVersionUID = 1L;
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	private static final Logger log = LoggerFactory.getLogger(CThreadLocalMultiSessionContext.class);
	
	private static final Class<?>[] SESS_PROXY_INTERFACES = new Class[]{
			org.hibernate.classic.Session.class,
			org.hibernate.engine.SessionImplementor.class,
			org.hibernate.jdbc.JDBCContext.Context.class,
			org.hibernate.event.EventSource.class };
	
	private boolean trackSessionCreation = true;
	
	/**
	 * A ThreadLocal maintaining current sessions for the given execution thread.
	 * The actual ThreadLocal variable is a java.util.Map to account for the
	 * possibility for multiple SessionFactorys being used during execution of the
	 * given thread.
	 */
	private static final ThreadLocal<Map<SessionKey, SessionInfo>> context = new ThreadLocal<Map<SessionKey, SessionInfo>>();
	
	protected final SessionFactoryImplementor factory;
	
	public CThreadLocalMultiSessionContext(SessionFactoryImplementor factory)
	{
		this.factory = factory;
	}
		
	public boolean isTrackSessionCreation()
	{
		return trackSessionCreation;
	}

	public void setTrackSessionCreation(boolean trackSessionCreation)
	{
		this.trackSessionCreation = trackSessionCreation;
	}

	public final org.hibernate.classic.Session currentSession()
		throws HibernateException
	{
		//DB.logActivity("Getting connection from " + factory.getConnectionProvider());
		Connection conn;
		try
		{
			conn = factory.getConnectionProvider().getConnection();
		}
		catch(SQLException e)
		{
			throw new HibernateException(e);
		}
		
		if (conn == null)
		{
			throw new HibernateException("No connection");
		}
		
		Session current = existingSession(conn, factory);
		if(current == null)
		{
			current = buildOrObtainSession(conn);
			Transaction tx = current.getTransaction();
			
			// wrap the session in the transaction-protection proxy
			if(needsWrapping(current))
			{
				current = wrap(conn, current);
			}
			// register a cleanup synch
			tx.registerSynchronization(buildCleanupSynch(conn, current));
			
			addDBSupportHook(current);
			
			// then bind it
			doBind(conn, current, factory);
		}
		return (org.hibernate.classic.Session) current;
	}
	
	private void addDBSupportHook(final Session session)
	{
		if(DB.isInitialized())
		{
			DB.registerSynchronization(new IDBSync()
			{
				@Override
				public void beforeCommit() throws DBSyncException
				{
					if(session.isOpen() && session.getTransaction().isActive())
					{
						try
						{
							session.flush();
						}
						catch(HibernateException e)
						{
							throw new DBSyncException(e);
						}
					}
				}
				
				@Override
				public void beforeRollback()
				{
					if(session.isOpen() && session.getTransaction().isActive())
					{
						session.clear();
					}
				}
				
				@Override
				public void afterClose()
				{
					if(session.isOpen()) 
					{
						if(session.getTransaction().isActive())
						{
							session.clear();
						}
						HibernateUtils.closeSilently(session);
					}
				}
			});
		}
	}

	protected static boolean sessionExists(Connection conn, SessionFactory factory)
	{
		return factory != null && existingSession(conn, factory) != null;
	}

	protected static String getCreationStackTrace(Connection conn, SessionFactory factory)
	{
		Map<SessionKey, SessionInfo> sessionMap = context.get();
		if(sessionMap == null)
		{
			return null;
		}
		else
		{
			SessionInfo info = sessionMap.get(getSessionKey(conn, factory));
			return info == null ? null : info.getCreationTrace();
		}
	}
	
	private boolean needsWrapping(Session session)
	{
		// try to make sure we don't wrap an already wrapped session
		if(session == null) return false;
		if(!Proxy.isProxyClass(session.getClass())) return true;
		return !(Proxy.getInvocationHandler(session) instanceof TransactionProtectionWrapper);
	}
	
	/**
	 * Getter for property 'factory'.
	 * 
	 * @return Value for property 'factory'.
	 */
	protected SessionFactoryImplementor getFactory()
	{
		return factory;
	}
	
	/**
	 * Strictly provided for subclassing purposes; specifically to allow
	 * long-session support.
	 * <p/>
	 * This implementation always just opens a new session.
	 * 
	 * @return the built or (re)obtained session.
	 */
	protected Session buildOrObtainSession(Connection conn)
	{
		return factory.openSession(conn, isAutoFlushEnabled(), isAutoCloseEnabled(), getConnectionReleaseMode());
	}
	
	protected CleanupSynch buildCleanupSynch(Connection conn, Session session)
	{
		return new CleanupSynch(conn, factory, session);
	}
	
	/**
	 * Mainly for subclass usage. This impl always returns true.
	 * 
	 * @return Whether or not the the session should be closed by transaction
	 *         completion.
	 */
	protected boolean isAutoCloseEnabled()
	{
		return true;
	}
	
	/**
	 * Mainly for subclass usage. This impl always returns true.
	 * 
	 * @return Whether or not the the session should be flushed prior transaction
	 *         completion.
	 */
	protected boolean isAutoFlushEnabled()
	{
		return true;
	}
	
	/**
	 * Mainly for subclass usage. This impl always returns after_transaction.
	 * 
	 * @return The connection release mode for any built sessions.
	 */
	protected ConnectionReleaseMode getConnectionReleaseMode()
	{
		return factory.getSettings().getConnectionReleaseMode();
	}
	
	protected Session wrap(Connection conn, Session session)
	{
		TransactionProtectionWrapper wrapper = new TransactionProtectionWrapper(conn, session);
		Session wrapped = (Session) Proxy.newProxyInstance(Session.class.getClassLoader(), SESS_PROXY_INTERFACES, wrapper);
		wrapper.setWrapped(wrapped);
		return wrapped;
	}
	
	/**
	 * Associates the given session with the current thread of execution.
	 * 
	 * @param session
	 *          The session to bind.
	 */
	protected void bind(Connection conn, Session session)
	{
		SessionFactory factory = session.getSessionFactory();
		cleanupAnyOrphanedSession(conn, factory);
		doBind(conn, session, factory);
	}
	
	protected static Session unbind(Connection conn, SessionFactory factory, Session caller)
	{
		return doUnbind(conn, factory, caller);
	}
	
	private void cleanupAnyOrphanedSession(Connection conn, SessionFactory factory)
	{
		Map<SessionKey, SessionInfo> sessionMap = context.get();
		if (sessionMap == null || sessionMap.isEmpty())
		{
			return;
		}
		
		SessionKey key = getSessionKey(conn, factory);
		SessionInfo session = sessionMap.remove(key);
		if (session == null)
		{
			return;
		}
		
		cleanupOrphanedSession(session.getSession());
		
		if(sessionMap.isEmpty())
		{
			context.set(null);
		}
	}
	
	private void cleanupOrphanedSession(Session orphan)
	{
		if(orphan != null)
		{
			log.warn("Already session bound on call to bind(); make sure you clean up your sessions!");
			try
			{
				if(orphan.getTransaction() != null
						&& orphan.getTransaction().isActive())
				{
					try
					{
						orphan.getTransaction().rollback();
					}
					catch(Throwable t)
					{
						log.debug("Unable to rollback transaction for orphaned session", t);
					}
				}
				orphan.close();
			}
			catch(Throwable t)
			{
				log.debug("Unable to close orphaned session", t);
			}
		}
	}
	
	private static Session existingSession(Connection conn, SessionFactory factory)
	{
		Map<SessionKey, SessionInfo> sessionMap = context.get();
		if(sessionMap == null)
		{
			return null;
		}
		else
		{
			SessionKey key = getSessionKey(conn, factory);
			SessionInfo info = sessionMap.get(key);
			return info == null ? null : info.session;
		}
	}
	
	private void doBind(Connection conn, Session session, SessionFactory factory)
	{
		Map<SessionKey, SessionInfo> sessionMap = context.get();
		if(sessionMap == null)
		{
			sessionMap = new HashMap<SessionKey, SessionInfo>();
			context.set(sessionMap);
		}
		
		String creationTrace = null;
		if (isTrackSessionCreation())
		{
			creationTrace = CStackTrace.getStackTrace("Creation stackTrace");
		}
		SessionKey key = getSessionKey(conn, factory);
		sessionMap.put(key, new SessionInfo(session, creationTrace));
		
		registerCleanup();
		DB.logActivity("Binding session " + key + " -> " + session);
	}
	
	private static Session doUnbind(Connection conn, SessionFactory factory, Session caller)
	{
		Map<SessionKey, SessionInfo> sessionMap = context.get();
		
		SessionKey key = getSessionKey(conn, factory);
		SessionInfo info = null;
		if(sessionMap != null)
		{
			info = sessionMap.remove(key);
			DB.logActivity("Unbinding session " + key + " -> " + (info == null ? null : info.session));
		}
		if(info == null) {
			Exception cause = new RuntimeException("Key: " + key + ", bound sessions:\n" + sessionMap + "; env history: " + DB.getActivities());
			log.error("Cannot unbind session that is not bound", cause);
		}
		
		Session session = null;
		if(info != null)
		{
			session = info.session;
			if(session != caller)
			{
				Exception cause = new RuntimeException("Key: " + key + ", caller: " + caller + ", bound sessions:\n" + sessionMap + "; env history: " + DB.getActivities());
				log.error("Caller session differs from bound session", cause);
			}
		}
		
		if(sessionMap != null && sessionMap.isEmpty())
		{
			context.set(null);
		}
		return session;
	}
	
	/**
	 * JTA transaction synch used for cleanup of the internal session map.
	 */
	private static class CleanupSynch implements Synchronization
	{
		private final SessionFactory factory;
		private final Connection connection;
		private final Session session;
		
		public CleanupSynch(Connection connection, SessionFactory factory, Session session)
		{
			this.factory = factory;
			this.connection = connection;
			this.session = session;
		}
		
		public Connection getConnection()
		{
			return connection;
		}
		
		public SessionFactory getFactory()
		{
			return factory;
		}

		/**
		 * {@inheritDoc}
		 */
		public void beforeCompletion()
		{
		}
		
		/**
		 * {@inheritDoc}
		 */
		public void afterCompletion(int i)
		{
			unbind(getConnection(), getFactory(), session);
		}
	}
	
	private class TransactionProtectionWrapper implements InvocationHandler
	{
		private final Session session;
		private final Connection connection;
		private Session wrapped;
		private String creationTrace;
		
		public TransactionProtectionWrapper(Connection connection, Session session)
		{
			this.session = session;
			this.connection = connection;
			
			if (isTrackSessionCreation())
			{
				creationTrace = CStackTrace.getStackTrace("Creation stackTrace");
			}
		}
		
		public void setWrapped(Session wrapped) {
			this.wrapped = wrapped;
		}

		public Session getSession()
		{
			return session;
		}

		public Connection getConnection()
		{
			return connection;
		}

		/**
		 * {@inheritDoc}
		 */
		public Object invoke(Object proxy, Method method, Object[] args)
				throws Throwable
		{
			try
			{
				// If close() is called, guarantee unbind()
				if("close".equals(method.getName()))
				{
					unbind(getConnection(), getSession().getSessionFactory(), wrapped);
				}
				else if("toString".equals(method.getName()))
				{
					return session.toString() + "@" + Integer.toHexString(System.identityHashCode(session));
				}
				else if("equals".equals(method.getName())
						|| "hashCode".equals(method.getName())
						|| "getStatistics".equals(method.getName())
						|| "isOpen".equals(method.getName()))
				{
					// allow these to go through the the real session no matter what
				}
				else if(!session.isOpen())
				{
					// essentially, if the real session is closed allow any
					// method call to pass through since the real session
					// will complain by throwing an appropriate exception;
					// NOTE that allowing close() above has the same basic effect,
					// but we capture that there simply to perform the unbind...
				}
				else 
				{
					Transaction tx = session.getTransaction();
					
					if(!tx.isActive())
					{
						// limit the methods available if no transaction is active
						if("beginTransaction".equals(method.getName())
								|| "getTransaction".equals(method.getName())
								|| "isTransactionInProgress".equals(method.getName())
								|| "setFlushMode".equals(method.getName())
								|| "getSessionFactory".equals(method.getName()))
						{
							log.trace("allowing method [" + method.getName() + "] in non-transacted context");
						}
						else if("reconnect".equals(method.getName())
								|| "disconnect".equals(method.getName()))
						{
							// allow these (deprecated) methods to pass through
						}
						else if(!tx.wasCommitted() && !tx.wasRolledBack())
						{
							// begin transaction lazily
							session.getTransaction().begin();
						}
						else
						{
							throw new HibernateException(method.getName() + 
									" is not valid without active transaction",
									new RuntimeException(method.getName() + 
											" is not valid without active transaction on " + wrapped + ", conn: " + connection + ", Env history: " + DB.getActivities() + 
											"\n" + creationTrace + 
											"\n" + CHashableConnection.unwrap(connection).getCreationTrace()));
						}
					}
				}
				log.trace("allowing proxied method [" + method.getName() + "] to proceed to real session");
				return method.invoke(session, args);
			}
			catch(InvocationTargetException e)
			{
				if(e.getTargetException() instanceof RuntimeException)
				{
					throw (RuntimeException) e.getTargetException();
				}
				else
				{
					throw e;
				}
			}
		}
	}
	
	private static class SessionInfo
	{
		private final Session session;
		private final String creationTrace;
		
		public SessionInfo(Session session, String creationTrace)
		{
			this.session = session;
			this.creationTrace = creationTrace;
		}
		
		public Session getSession()
		{
			return session;
		}

		public String getCreationTrace()
		{
			return creationTrace;
		}
		
		@Override
		public String toString() {
			return creationTrace;
		}
	}
	
	protected static SessionKey getSessionKey(Connection connection, SessionFactory factory)
	{
		return new SessionKey(connection, factory); //"CN@"+ connection.hashCode() + "_SF@" + factory.hashCode();
	}
	
	private static class SessionKey {
		final Connection connection;
		final SessionFactory factory;
		
		public SessionKey(Connection connection, SessionFactory factory) {
			this.connection = connection;
			this.factory = factory;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((this.connection == null) ? 0 : this.connection.hashCode());
			result = prime * result + ((this.factory == null) ? 0 : this.factory.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if(obj instanceof SessionKey) {
				SessionKey k = (SessionKey) obj;
				
				boolean deq = connection.equals(k.connection);
				boolean eq = deq && factory.equals(k.factory);
				return eq;
			}
			
			return false;
		}
		
		@Override
		public String toString() {
			return "<conn: " + connection + ", factory: " + factory + ">";
		}
	}

	/**
	 * Makes sure there are no old sessions still bound to current thread
	 */
	public static void cleanup() {
		Map<SessionKey, SessionInfo> sessionMap = context.get();
		if(sessionMap != null && !sessionMap.isEmpty())
		{
			Iterator<Map.Entry<SessionKey, SessionInfo>> it = sessionMap.entrySet().iterator();
			while(it.hasNext())
			{
				Map.Entry<SessionKey, SessionInfo> e = it.next();
				SessionInfo info = e.getValue();
				
				it.remove();
				
				String data = e.getKey() + " -> " + info.getSession() + 
						"\nEnv history: " + DB.getActivities() + 
						"\nCreation stacktrace:\n" + info.getCreationTrace();
				
				CTraceLog.error("Orphaned hibernate session", CThreadLocalMultiSessionContext.class.getName(), data);
			}
		}
	}
	
	private static void registerCleanup()
	{
		if(CClosableRegistry.currentThreadInstance() != null)
		{
			CClosableRegistry.registerCurrentThread(new IClosable() {
				@Override
				public void close() {
					cleanup();
				}
			});
		}
	}
}
