/*
 * @(#)$RCSfile: HibernateUtils.java,v $Revision: 1.7 $ $Date: 2010/06/17 21:01:12 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/HibernateUtils.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2008-09-02	created
 *	A.Solntsev			2008-10-10	Fixing rollbackSilently
 *	A.Solntsev			2010-03-08	Added "catch Throwable" to both methods
 *	A.Tanasenko			2010-05-24	Added setNChar method
 *	M.Abdulganejev			2010-06-09	Connection unwrapping methods moved to CConnectionWrapper
 */
package hireright.sdk.db2;

import hireright.sdk.db.CConnection;
import hireright.sdk.db.CCurrentThreadConnection;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import oracle.jdbc.OraclePreparedStatement;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.7 $ $Date: 2010/06/17 21:01:12 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/HibernateUtils.java,v $
 */
public class HibernateUtils
{
	protected static final String CLASS_VERSION = "$Revision: 1.7 $ $Author: cvsroot $";
	
	public static void rollbackSilently(Session session)
	{
		if (session.isOpen())
		{
			try { session.clear(); } // or session.flush() ?
			catch (HibernateException e)
			{
				// CTraceLog.warning(e, getClass()+".tearDown()#session.clear");
			}
			catch (Throwable e)
			{
				Logger.getLogger( HibernateUtils.class ).error( e.getMessage(), e );
			}
			
			CConnection.rollback( CCurrentThreadConnection.getConnection() );
		}
	}
	
	public static void closeSilently(Session session)
	{
		if (session != null && session.isOpen())
		{
			try {session.close(); } 
			catch (HibernateException e)
			{
				// Logger.getLogger( HibernateUtils.class ).error( e.getMessage(), e );
			} 
			catch (Throwable e)
			{
				Logger.getLogger( HibernateUtils.class ).error( e.getMessage(), e );
			}
		}
	}
	
	/**
	 * Marks specified value at specified index in preparedStatement as Oracle FORM_NCHAR.
	 * Unwraps statement as needed, using dbcp or jboss pooling.
	 * 
	 * @param st
	 * @param value
	 * @param index
	 * @throws SQLException
	 */
	public static void setNChar(PreparedStatement st, Object value, int index) throws SQLException
	{
		OraclePreparedStatement ost = CConnectionWrapper.unwrapOracleStatement(st);
		if(ost != null)
		{
			ost.setFormOfUse(index, OraclePreparedStatement.FORM_NCHAR);
		}
		else
		{
			StringBuilder sb = new StringBuilder();
			CConnectionWrapper.unwrapOracleStatement(st, sb);
			
			Logger.getLogger( HibernateUtils.class )
				.error("Unable to unwrap oracle statement from chain:\n" + sb.toString());
		}

	}
	
}
