/*
 * @(#)$RCSfile: HibernateFactoryShutdownHook.java,v $Revision: 1.2 $ $Date: 2009/12/18 07:13:38 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/HibernateFactoryShutdownHook.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 *	A.Solntsev			2009-12-11	created
 */
package hireright.sdk.db2;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * This class needs to be declared in web.xml as follows:
 * <pre>
 * 	&lt;listener>
 *		&lt;listener-class>
 *			hireright.sdk.db2.HibernateFactoryShutdownHook
 *		&lt;/listener-class>
 *	&lt;/listener>
 * </pre>
 * 
 * @author Andrei Solntsev
 * @version $Revision: 1.2 $ $Date: 2009/12/18 07:13:38 $ $Author: cvsroot $
 */
public class HibernateFactoryShutdownHook implements ServletContextListener
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	
	public void contextInitialized( final ServletContextEvent sce )
	{
		// System.out.println("[info] " + getClass().getName() + ": started");
	}
	
	public void contextDestroyed( final ServletContextEvent sce )
	{
		CSessionFactory.shutdown();
		// System.out.println("[info] " + getClass().getName() + ": finished");
	}
}
