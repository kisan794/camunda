/*
 * @(#)$RCSfile: CSessionHelper.java,v $Revision: 1.10 $ $Date: 2015/03/28 08:19:00 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CSessionHelper.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-02-22	created
 * 	A.Solntsev			2007-04-10	Fixed bug: CCurrentThreadConnection.unbind() only if it was binded.
 *	A.Solntsev			2007-06-05	extends CClosableObject
 *	A.Solntsev			2007-11-07	removed methods commit() and rollback(); added javadoc.
 *	V.Lazarev				2008-01-16	Removed binding to CCurrentThreadConnection from hibernate session.
 */
package hireright.sdk.db2;

import java.sql.Connection;

import org.hibernate.Session;

import hireright.sdk.db.CClosableObject;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CProperties;

/**
 * <p>
 * This class is needed ONLY for READ-ONLY operations.
 * If you need to LOAD some object from database, but not sure, if there is open Hibernate transaction,
 * you can use class CSessionHelper.
 *</p>
 *<p>
 * It checks if there is open transaction already, and if not, opens the new one.
 *</p>
 *<p>
 * NB! You MUST close session after after performing your job.<br/>
 * CSessionHelper checks if it opened a new transaction, and if yes, closes it.
 *</p>
 *
 * <pre>
 * <code>
 *  CSessionHelper helper = new CSessionHelper();
 *  try
 *  {
 *  	return helper.getSession().load( ...load your objects... )
 *  }
 *  finally
 *  {
 *  	helper.close();
 *  }
 * </code>
 * </pre>
 *
 * @author Andrei Solntsev
 * @since Feb 22, 2007
 * @version $Revision: 1.10 $ $Date: 2015/03/28 08:19:00 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CSessionHelper.java,v $
 * @deprecated consider using {@link DB}
 */
@Deprecated
public class CSessionHelper extends CClosableObject
{
	protected static final String CLASS_VERSION = "$Revision: 1.10 $ $Author: cvsroot $";
	
	private DB m_db;
	private Session m_session;
	private Connection m_connection;

	public CSessionHelper()
	{
		onOpened("SessionHelper created");
		
		m_db = DB.init();

		m_session = DB.session();
		if (m_session == null)
			throw new IllegalStateException("Current session is null");	// I assume it never happens

		m_connection = DB.connection();
	}

	public Session getSession()
	{
		return m_session;
	}

	/**
	 * Don't use this method. Hibernate is configured to use CCurrentThreadConnection.getConnection().
	 * @return
	 */
	public Connection getConnection()
	{
		return m_connection;
	}

	public void close()
	{
		m_db.close();
		m_db = null;
	}

	@Override
	protected boolean isClosed()
	{
		return m_db == null;
	}

	@Override
	protected void closeSilently()
	{
		// do not try to close here m_session - it may close any current session, even it is not m_session
		// close();
	}

	public CProperties toProperties()
	{
		CProperties params = new CProperties();
		params.setProperty("session", m_session);
		return params;
	}
}
