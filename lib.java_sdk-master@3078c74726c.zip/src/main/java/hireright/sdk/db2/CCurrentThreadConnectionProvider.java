/*
 * @(#)$RCSfile: CCurrentThreadConnectionProvider.java,v $Revision: 1.4 $ $Date: 2015/03/28 08:30:33 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CCurrentThreadConnectionProvider.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Solntsev			2007-12-10	created
 */
package hireright.sdk.db2;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.connection.ConnectionProvider;

import hireright.sdk.db.CCurrentThreadConnection;

/**
 * Custom Hibernate connection provider.
 * It always returns <code>CCurrentThreadConnection.getConnection()</code>,
 * thus providing that hibernate and HireRight DB layer use the same connection.
 * 
 * @author asolntsev
 * @see CCurrentThreadConnection
 * @version $Revision: 1.4 $ $Date: 2015/03/28 08:30:33 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CCurrentThreadConnectionProvider.java,v $ 
 */
public class CCurrentThreadConnectionProvider implements ConnectionProvider 
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";
	
	public void configure(Properties props) throws HibernateException
	{
		// nothing to do?
	}
	
	public Connection getConnection() throws SQLException
	{
		return CCurrentThreadConnection.getConnection();
	}
	
	public void closeConnection(Connection conn) throws SQLException
	{
		// nothing to do?
	}
	
	public void close() throws HibernateException
	{
		// nothing to do?
	}
	
	public boolean supportsAggressiveRelease()
	{
		return true;
	}
	
	public String toString() {
		return String.valueOf(CCurrentThreadConnection.getProvider());
	}
}
