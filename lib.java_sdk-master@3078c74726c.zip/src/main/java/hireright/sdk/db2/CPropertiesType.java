/*
 * @(#)$RCSfile: CPropertiesType.java,v $ $Revision: 1.6 $ $Date: 2015/03/28 08:23:43 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CPropertiesType.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *    2005-07-25	A.Solntsev			created
 *    2006-05-02	V.Lazarev			used new methods from CProperty class. Added comments.
 *	  2013-02-20	A.Putintsev			added TYPE constant
 */
package hireright.sdk.db2;

import hireright.sdk.util.CProperties;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.HibernateException;
import org.hibernate.type.StringType;
import org.hibernate.usertype.UserType;

/**
 * Custom type for Hibernate allowing to read VARCHAR columns as CProperties.
 * @see	hireright.objects.logs.CLogTrace
 * @see	hireright/objects/logs/CLogTrace.hbm.xml
 * 
 * @author asolntsev
 * @version $Revision: 1.6 $ $Date: 2015/03/28 08:23:43 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CPropertiesType.java,v $
 */
public class CPropertiesType implements UserType, Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	public static final String TYPE = "hireright.sdk.db2.CPropertiesType";
	
	/**
	* Return the SQL type codes for the columns mapped by this type. 
	* CPropertiesType type is mapped to VARCHAR type
	* @see java.sql.Types
	* @return int[] the typecodes
	*/
	public int[] sqlTypes()
	{
		return new int[] {Types.VARCHAR};
	}

	/**
	* The class returned by <tt>nullSafeGet()</tt>.
	* @return Class = CProperties 
	*/
	public Class returnedClass()
	{
		return CProperties.class;
	}

	/** Compare two instances of the CProperties class mapped by this type for persistence "equality".
	* 	Equality of the persistent state.
	*/
	public boolean equals(Object x, Object y) throws HibernateException
	{
		if (x==y) return true;
		if (x==null || y==null) return false;
		CProperties prop1 = (CProperties) x;
		CProperties prop2 = (CProperties) y;

		return prop1.equals(prop2);
	}

	/**
	* Retrieve an instance of the mapped class from a JDBC resultset. Implementors
	* should handle possibility of null values.
	* @param rs a JDBC result set
	* @param names the column names
	* @param owner the containing entity
	* @return Object
	* @throws HibernateException
	*/
	public Object nullSafeGet(ResultSet rs, String[] names, Object owner) throws HibernateException, SQLException
	{
		String result = (String) new StringType().nullSafeGet(rs, names[0]);
		return (result == null) ? null : new CProperties(result);
	}

	/**
	* Write an instance of the mapped class to a prepared statement. Implementors
	* should handle possibility of null values. A multi-column type should be written
	* to parameters starting from <tt>index</tt>.
	*
	* @param st a JDBC prepared statement
	* @param value the object to write
	* @param index statement parameter index
	* @throws HibernateException
	* @throws SQLException
	*/
	public void nullSafeSet(PreparedStatement st, Object value, int index) throws HibernateException, SQLException
	{
		if (value == null)
		{
			st.setNull(index, Types.VARCHAR);
		}
		else
		{
			st.setString(index, ((CProperties) value).toString());
		}
	}

	/**
	* Return a deep copy of the persistent state, stopping at entities and at
	* collections. It is not necessary to copy immutable objects, or null
	* values, in which case it is safe to simply return the argument.
	*
	* @param value the object to be cloned, which may be null
	* @return Object a copy
	*/
	public Object deepCopy(Object value) throws HibernateException
	{
		return (value != null) ? new CProperties((CProperties) value) : null;
	}

	/**
	 * The objects of this type is mutable
	 */
	public boolean isMutable()
	{
		return true;
	}

	/**
	* Get a hashcode for the instance, consistent with persistence "equality"
	*/
	public int hashCode(Object x) throws HibernateException
	{
		return ((CProperties) x).hashCode();
	}
	
	/**
	* Reconstruct an object from the cacheable representation. At the very least this
	* method should perform a deep copy if the type is mutable. (optional operation)
	*
	* @param cached the object to be cached
	* @param owner the owner of the cached object
	* @return a reconstructed object from the cachable representation
	* @throws HibernateException
	*/
	public Object assemble(Serializable cached, Object owner) throws HibernateException
	{
		return deepCopy(cached);
	}

	/**
	* Transform the object into its cacheable representation. At the very least this
	* method should perform a deep copy if the type is mutable. That may not be enough
	* for some implementations, however; for example, associations must be cached as
	* identifier values. (optional operation)
	*
	* @param value the object to be cached
	* @return a cachable representation of the object
	* @throws HibernateException
	*/
	public Serializable disassemble(Object value) throws HibernateException
	{
		return (Serializable) deepCopy(value);
	}

	/**
	* During merge, replace the existing (target) value in the entity we are merging to
	* with a new (original) value from the detached entity we are merging. For immutable
	* objects, or null values, it is safe to simply return the first parameter. For
	* mutable objects, it is safe to return a copy of the first parameter. For objects
	* with component values, it might make sense to recursively replace component values.
	*
	* @param original the value from the detached entity being merged
	* @param target the value in the managed entity
	* @return the value to be merged
	*/
	public Object replace(Object original, Object target, Object owner) throws HibernateException
	{
		CProperties properties = null;
		
		if (original != null)
		{
			properties = new CProperties( (CProperties) original);
		}

		return properties;
	}
}
