/*
 * @(#)$RCSfile: CQueryCursor.java,v $ $Revision: 1.3 $ $Date: 2014/04/17 09:02:58 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CQueryCursor.java,v $
 * Copyright 2001-2011 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   A.Tanasenko	2014-02-20	Created
 *   M.Konstantinov	2014-04-14	Added configurable attmept delay
 */

package hireright.sdk.db2;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import hireright.sdk.db2.CSessionFactory;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;

/**
 * Wrapper for Query instance that retrieves objects from db using cursor, getting records by batches and creating objects one-by-one.<br/>
 * Can be provided with a non-null ItemFilter which will decide which items will end up in the result list.<br/>
 * If maxResults is set to non-negative then no more than that number of results will be returned.<br/>
 * This class also takes care of 'ORA-01555: snapshot too old' error. Setting 'attempts' property (default is 1) will specify how many
 * attempts to perform before throwing and exception.
 */
public class CQueryCursor<T>
{
	public static final int DEFAULT_ATTEMPTS = 1;
	
	private QueryFactory queryFactory;
	private ItemFilter<T> filter;
	
	private int attempts = DEFAULT_ATTEMPTS;
	private int attemptDelay = 0;
	private int maxResults = -1;

	public CQueryCursor(final Query query, ItemFilter<T> filter)
	{
		this(new QueryFactory(){
			@Override
			public Query createQuery()
			{
				return query;
			}
		}, filter);
	}
	
	public CQueryCursor(QueryFactory queryFactory, ItemFilter<T> filter)
	{
		if(queryFactory == null) throw new IllegalArgumentException("queryFactory == null");
		this.queryFactory = queryFactory;
		this.filter = filter;
	}
	
	public void setAttempts(int attempts)
	{
		if(attempts < 1) throw new IllegalArgumentException("attempts must be >= 1");
		this.attempts = attempts;
	}
	
	public void setAttemptDelay(int attemptDelay)
	{
		this.attemptDelay = attemptDelay;
	}
	
	
	
	public int getAttempts()
	{
		return attempts;
	}
	
	public void setMaxResults(int maxResults)
	{
		this.maxResults = maxResults;
	}
	public int getMaxResults()
	{
		return maxResults;
	}
	
	private ScrollableResults getResults()
	{
		Query q = queryFactory.createQuery();
		q.setFetchSize(200);
		return q.scroll(ScrollMode.FORWARD_ONLY);
	}
	
	public List<T> execute()
	{
		
		Session session = CSessionFactory.getSessionFactory().getCurrentSession();
		
		ScrollableResults results = null;
		List<T> items = new ArrayList<T>();
		
		int attempts = getAttempts();
		while(attempts-- > 0)
		{
			results = null;
			try
			{
				results = getResults();
				while((maxResults < 0 || items.size() < maxResults) && results.next())
				{
					T item = (T) results.get(0);
					boolean ok = filter == null || filter.accept(item);
					
					if(ok)
					{
						items.add(item);
					}
					
					// detach from session
					session.evict(item);
				}
			}
			catch(HibernateException he)
			{
				if(attempts > 0)
				{
					Throwable t = he.getCause();
					if(t instanceof SQLException)
					{
						SQLException sqle = (SQLException) t;
						if(sqle.getErrorCode() == 1555) // ORA-01555: snapshot too old: rollback segment number  with name "" too small
						{
							items.clear();
							if(attemptDelay > 0) 
							{
								try
								{
									Thread.sleep(attemptDelay);
								} 
								catch (InterruptedException ie) {}
							}
							continue; // retry
						}
					}
				}
				
				throw he;
			}
			finally
			{
				if(results != null) results.close();
			}
			
			break;
		}
		
		return items;
	}
	
	public static interface ItemFilter<T>
	{
		public boolean accept(T item);
	}
	
	public static interface QueryFactory
	{
		public Query createQuery();
	}

}
