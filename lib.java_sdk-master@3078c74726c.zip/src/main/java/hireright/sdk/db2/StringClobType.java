/*
 * @(#)$RCSfile: StringClobType.java,v $ $Revision: 1.4 $ $Date: 2008/07/28 09:47:01 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/StringClobType.java,v $
 *
 * Copyright 2001-2006 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  V. Lazarev	2007-03-12	Created.
 *
 */
package hireright.sdk.db2;

import java.io.Serializable;
import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import oracle.jdbc.driver.OraclePreparedStatement;

import org.hibernate.HibernateException;
import org.hibernate.usertype.UserType;

/**
 * Based on community area design patterns on Hibernate site.
 * Maps java.sql.Clob to a String special casing for Oracle drivers.
 * Hibernate 1.2.1 comes with support for Clobs (and Blobs). 
 * Just use the clob type in your mapping file and java.sql.Clob in your persistent class. 
 * However, due to problems with the Oracle JDBC driver, this support falls short when you try 
 * to store more than 4000 characters in a Clob. The OracleDataSource is required for storing of long data.
 * 
 * @author Vladimir Lazarev 
 * @version $Revision: 1.4 $ $Date: 2008/07/28 09:47:01 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/StringClobType.java,v $
 */
public class StringClobType implements UserType
{
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";

	public int[] sqlTypes() 
	{
		return new int[] { Types.CLOB };
	}

	public Class returnedClass() 
	{
		return String.class;
	}

	public boolean equals(Object x, Object y) 
	{
		return x.equals(y);
	}

	public Object nullSafeGet(ResultSet rs, String[] names, Object owner) throws HibernateException, SQLException 
	{
		String sResult = null;
		Clob clob = rs.getClob(names[0]);

		if (clob != null)
			sResult = clob.getSubString(1, (int) clob.length());

		return sResult;
	}

  public void nullSafeSet(PreparedStatement st, Object value, int index)
    throws HibernateException, SQLException
  {
  	if (value == null) 
  	{
			st.setNull(index, Types.CLOB);
		}
		else 
		{
			if (st instanceof OraclePreparedStatement)
			{
				// Oracle CONNECTION POOL must be used
				((OraclePreparedStatement)st).setStringForClob(index, (String)value);
			}
			else
			{
				(st).setString(index, (String)value);
			}
		}
	}

  /**
	* Reconstruct an object from the cacheable representation. At the very least this
	* method should perform a deep copy if the type is mutable. (optional operation)
	*
	* @param cached the object to be cached
	* @param owner the owner of the cached object
	* @return a reconstructed object from the cachable representation
	* @throws HibernateException
	*/
	public Object assemble(Serializable cached, Object owner) throws HibernateException
	{
		return deepCopy(cached);
	}

	/**
	* Transform the object into its cacheable representation. At the very least this
	* method should perform a deep copy if the type is mutable. That may not be enough
	* for some implementations, however; for example, associations must be cached as
	* identifier values. (optional operation)
	*
	* @param value the object to be cached
	* @return a cachable representation of the object
	* @throws HibernateException
	*/
	public Serializable disassemble(Object value) throws HibernateException
	{
		return (Serializable) deepCopy(value);
	}

	public Object deepCopy(Object value) throws HibernateException 
	{
		 if (value == null) return null;
     return new String((String) value);
  }
 
	/**
	* Get a hashcode for the instance, consistent with persistence "equality"
	*/
	public int hashCode(Object x) throws HibernateException
	{
		return x.hashCode();
	}

  public boolean isMutable()
  {
    return false;
  }
  
  /**
	* During merge, replace the existing (target) value in the entity we are merging to
	* with a new (original) value from the detached entity we are merging. For immutable
	* objects, or null values, it is safe to simply return the first parameter. For
	* mutable objects, it is safe to return a copy of the first parameter. For objects
	* with component values, it might make sense to recursively replace component values.
	*
	* @param original the value from the detached entity being merged
	* @param target the value in the managed entity
	* @return the value to be merged
	*/
	public Object replace(Object original, Object target, Object owner) throws HibernateException
	{
		String value = null;
		
		if (original != null)
		{
			value = new String( (String) original);
		}

		return value;
	}
}
