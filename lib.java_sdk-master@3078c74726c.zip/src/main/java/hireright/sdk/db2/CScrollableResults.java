/*
 * @(#)$RCSfile: CNotificationListEmail.java,v $ $Revision: 1.1.2.3 $ $Date: 2016/02/02 17:22:28 $ $Author: msuhhoruki $
 * $Source: /usr/local/cvsroot/projects_src/components/notification/sdk/src/main/java/hireright/notification/sdk/CNotificationListEmail.java,v $
 *
 * Copyright 2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  M.Suhhoruki	2016-02-03		Created.
 */
package hireright.sdk.db2;

import java.util.Iterator;

import org.hibernate.Criteria;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;

public class CScrollableResults<T> implements Iterable<T>
{
	private final Session m_session; 
	private final Criteria m_query;
	
	public CScrollableResults(Session session, Criteria query)
	{
		m_session = session;
		m_query = query;
	}
	
	@Override
	public Iterator<T> iterator()
	{
		ScrollableResults results = m_query.scroll(ScrollMode.FORWARD_ONLY);
		return new CScrollableResultsIterator<T>(m_session, results);
	}
}