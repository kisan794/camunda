/*
 * @(#)$RCSfile: CNotificationListEmail.java,v $ $Revision: 1.1.2.3 $ $Date: 2016/02/02 17:22:28 $ $Author: msuhhoruki $
 * $Source: /usr/local/cvsroot/projects_src/components/notification/sdk/src/main/java/hireright/notification/sdk/CNotificationListEmail.java,v $
 *
 * Copyright 2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 *  M.Suhhoruki	2016-02-02		Created.
 */
package hireright.sdk.db2;

import java.util.Iterator;

import org.hibernate.ScrollableResults;
import org.hibernate.Session;

public class CScrollableResultsIterator<T> implements Iterator<T>
{
	private final Session m_session;
	private final ScrollableResults m_results;
	private T m_result;
	private Boolean m_bHasNext;
	
	public CScrollableResultsIterator(Session session, ScrollableResults results)
	{
		m_session = session;
		m_results = results;
	}
	
	@Override
	public boolean hasNext()
	{
		if (m_result != null)
		{
			m_session.evict(m_result); // allow gc to free result, this is necessary since we're not using stateless sessions
			m_result = null;
		}
		
		if (m_bHasNext != null)
		{
			return m_bHasNext;
		}
		
		m_bHasNext = m_results.next();
		if (!m_bHasNext)
		{
			m_results.close();
		}
		
		return m_bHasNext;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public T next()
	{
		if (m_bHasNext == null) // iterator.next() called without iterator.hasNext()
		{
			m_results.next();
		}
		
		//T obj = (T) m_results.get(0);
		m_result = (T) m_results.get(0);
		m_bHasNext = null; // force hasNext() to call m_results.next()
		
		return m_result;
	}
	
	@Override
	public void remove()
	{
		throw new UnsupportedOperationException();
	}
}