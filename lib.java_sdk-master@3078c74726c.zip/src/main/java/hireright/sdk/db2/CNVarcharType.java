/*
 * @(#)$RCSfile: CNVarcharType.java,v $Revision: 1.2 $ $Date: 2010/06/03 20:50:03 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CNVarcharType.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Tanasenko			2010-05-20	Created
 */
package hireright.sdk.db2;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.hibernate.dialect.Dialect;
import org.hibernate.type.StringType;

/**
 * Hibernate type for use with nvarchar2 columns
 * 
 * <p>
 * Example usage:
 * <pre>
 *   &lt;property name="name"
 *             type="hireright.sdk.db2.CNVarcharType"&gt;
 *     &lt;column .../&gt;
 *   &lt;/property&gt;
 * </pre>
 * 
 * <pre>
 *   @Type(type="org.hibernate.test.annotations.entity.MonetaryAmountUserType")
 * </pre>
 * </p>
 * 
 * @author atanasenko
 * @version $Revision: 1.2 $ $Date: 2010/06/03 20:50:03 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CNVarcharType.java,v $
 *
 */
public class CNVarcharType extends StringType
{
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";

	@Override
	public String getName()
	{
		return "nstring";
	}

	@Override
	public String objectToSQLString(Object value, Dialect dialect)
			throws Exception
	{
		return "n'" + (String) value + '\'';
	}

	@Override
	public void set(PreparedStatement st, Object value, int index)
			throws SQLException
	{
		super.set(st, value, index);
		HibernateUtils.setNChar(st, value, index);
	}
	
}
