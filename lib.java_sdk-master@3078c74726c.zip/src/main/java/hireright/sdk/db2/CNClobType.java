/*
 * @(#)$RCSfile: CNClobType.java,v $Revision: 1.4 $ $Date: 2010/09/03 08:07:53 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CNClobType.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	A.Tanasenko			2010-05-20	Created
 */
package hireright.sdk.db2;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.type.TextType;

/**
 * Hibernate type for use with nclob columns.
 * 
 * <p>
 * Example usage:
 * <pre>
 *   &lt;property name="results"
 *             type="hireright.sdk.db2.CNClobType"&gt;
 *     &lt;column .../&gt;
 *   &lt;/property&gt;
 * </pre>
 * </p>
 * 
 * @author atanasenko
 * @version $Revision: 1.4 $ $Date: 2010/09/03 08:07:53 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CNClobType.java,v $
 *
 */
public class CNClobType extends TextType
{

	private static final long serialVersionUID = 1L;
	
	protected static final String CLASS_VERSION = "$Revision: 1.4 $ $Author: cvsroot $";

	@Override
	public String getName()
	{
		return "nclob";
	}

	@Override
	public void set(PreparedStatement st, Object value, int index) throws HibernateException, SQLException
	{
		HibernateUtils.setNChar(st, value, index);
		super.set(st, value, index);
	}

}
