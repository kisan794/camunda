/*
 * @(#)$RCSfile: CSessionFactory.java,v $  $Revision: 1.24 $ $Date: 2015/03/28 08:25:57 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CSessionFactory.java,v $
 *
 * Copyright 2001-2009 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	2006-05-02	V.Lazarev			Created.
 *	2006-11-06	A.Solntsev		Static initialization -> lazy initialization
 *	2007-09-04	A.Solntsev		Implemented dynamic search of HBM files in classpath
 *	2008-01-09	V.Lazarev			The implementation for multiple conf-files is included.
 *	2008-04-02	V.Lazarev			The configuration files are filtered by unique name
 *	2008-05-29	A.Solntsev		Added warning if 2 files with the same name are found in classpath
 *	2008-10-31	A.Solntsev		Added method getSessionFactoryIfAny()
 *	2008-11-14	A.Solntsev		Removed shards functionality (it still doesn't work). Restore it once you need.
 *	2009-05-18	A.Solntsev		Added method setSessionFactory (can be used by Spring)
 *	2009-12-11	A.Solntsev		Added method shutdown()
 *	2010-01-05	E.Shatohhin		m_sessionFactory must be declared volatale for Double checked locking
 *  2014-03-27	A.Tanasenko		Added hibernate session tracking*
 *  2014-05-12	A.Sibul		Multiple DB support
 *  2014-06-19	M.Saddarov		Bugfixes for multi db mode
 *  2014-08-01	M.Suhhoruki		Added multi current session mode
 */
package hireright.sdk.db2;

import hireright.sdk.db.CCurrentThreadConnection;
import hireright.sdk.db3.DB;
import hireright.sdk.debug.CTraceLog;
import hireright.sdk.util.CClass;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;

import java.io.Serializable;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

/**
 * This class is intended to provide hibernate session factories.
 * @author	Vladimir Lazarev
 * @version $Revision: 1.24 $ $Date: 2015/03/28 08:25:57 $ $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CSessionFactory.java,v $
 */
public class CSessionFactory implements Serializable
{
	protected static final String CLASS_VERSION = "$Revision: 1.24 $ $Author: cvsroot $";
	
	private static final Object MUTEX = new Object();
	
	private static final long serialVersionUID = 1L;
	
	private static volatile Map<String, SessionFactory> m_sessionFactory = new HashMap<String, SessionFactory>();
	public static final String HIBERNATE_ORACLE_DIALECT = "OracleDialect";
	public static final String HIBERNATE_ORACLE_MYSQL   = "MySQLDialect";
	
	public static final String HIBERNATE_DEFAULT        = "default";
	
	/*
	 * See {@link hireright.sdk.db2.CThreadLocalMultiSessionContext}
	 * Overrides hibernate.current_session_context_class property.
	 *
	private static final String PROPERTY_MULTI_SESSION_MODE = "hr.multi_session_mode";
	*/
	
	/**
	 * Method returns URL to file "/hibernate.cfg.xml" used by Hibernate.
	 * Used for logging and error tracing.
	 *
	 * @return exception.toString() in case of any error
	 */
	public static String findConfig()
	{
		try
		{
			// URL hibernateCfgXml = ConfigHelper.getResourceAsStream("/hibernate.cfg.xml");
			// return String.valueOf(hibernateCfgXml);

			String resource = "/hibernate.cfg.xml";
			String stripped = resource.startsWith("/") ?
					resource.substring(1) : resource;

			URL stream = null;
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			if (classLoader!=null) {
				stream = classLoader.getResource( stripped );
			}
			if ( stream == null ) {
				stream = Environment.class.getResource( resource );
			}
			if ( stream == null ) {
				stream = Environment.class.getClassLoader().getResource( stripped );
			}
			if ( stream == null ) {
				throw new HibernateException( resource + " not found" );
			}
			return String.valueOf(stream);
		}
		catch (Throwable e)
		{
			return e.toString();
		}
	}

	/**
	 * Close all connections, clear caches etc.
	 * 
	 * This method should be called before webapp unload. 
	 */
	public static final void shutdown()
	{
		synchronized (MUTEX)
		{			
			if(null != m_sessionFactory && null != m_sessionFactory)
			{
				for(String sDBKey : m_sessionFactory.keySet()) 
				{
					shutdown(sDBKey);	
				}
				
				m_sessionFactory.clear(); 
			}

		}
	}
	
	public static final void shutdown(String sSessionName)
	{
		synchronized (MUTEX)
		{
			if(!CStringUtils.isEmpty(sSessionName) && null != m_sessionFactory)
			{
				SessionFactory s = m_sessionFactory.get(sSessionName);
				
				if(!s.isClosed())
				{
					s.close();
				}
			}
		}
	}
	
	/**
	 * 
	 * @param psPattern DB specific postfix to pass separate DB identifier corresponding to specific hibernate_%psPattern%.cfg.xml file
	 * @return
	 */
	private static final SessionFactory initSessionFactory(String psPattern)
	{
		try
		{
			String sPattern = "hibernate" + 
					(!"default".equals(psPattern) ? "_" + psPattern : "") + ".cfg.xml";
 			
			Configuration conf = new AutoDetectingConfiguration().addResource(sPattern).configure("/" + sPattern);
			
			// override current session context
			// using multisession context by default
			//boolean bMultiSessionSupport = Logical.isTrue(conf.getProperty(PROPERTY_MULTI_SESSION_MODE));
			conf.setProperty(Environment.CURRENT_SESSION_CONTEXT_CLASS, CThreadLocalMultiSessionContext.class.getName());
			
			return conf.buildSessionFactory();
		}
		catch (HibernateException ex)
		{
			// Make sure you log the exception, as it might be swallowed
			CProperties params = new CProperties();
			//params.setProperty("hibernate.cfg.xml", findConfig());
			params.setProperty("SettingsFactory.codeSource",
					CClass.getCodeSource("org.hibernate.cfg.SettingsFactory"));
			params.setProperty("EHCache.codeSource",
					CClass.getCodeSource("net.sf.ehcache.Cache"));
			params.setProperty("OracleDriver.codeSource",
					CClass.getCodeSource("oracle.jdbc.OracleDriver"));

			CTraceLog.fatal(ex, CSessionFactory.class.getName(), params);
			throw ex;
		}
		catch (LinkageError ex)	// includes NoClassDefFoundError, ...
		{
			// Make sure you log the exception, as it might be swallowed
			CProperties params = new CProperties();
			params.setProperty("SettingsFactory.codeSource",
					CClass.getCodeSource("org.hibernate.cfg.SettingsFactory"));
			params.setProperty("EHCache.codeSource",
					CClass.getCodeSource("net.sf.ehcache.Cache"));
			params.setProperty("OracleDriver.codeSource",
					CClass.getCodeSource("oracle.jdbc.OracleDriver"));

			CTraceLog.fatal(ex, CSessionFactory.class.getName(), params);
			throw ex;
		}
	}	
	
	/**
	 * Return the Hibernate SessionFactory is it is initialized.
	 * @return null if Hibernate is not initialized
	 */
	public static SessionFactory getSessionFactoryIfAny()
	{
		return getSessionFactory();
	}

	public static SessionFactory getSessionFactoryIfAny(String psPattern)
	{
		return getSessionFactory(psPattern);
	}
	
	/**
	 * Returns true is session was created or false otherwise
	 */
	public static final boolean sessionExists()
	{
		return sessionExists(HIBERNATE_DEFAULT);
	}
	
	public static final boolean sessionExists(String psPattern)
	{
		return CThreadLocalMultiSessionContext.sessionExists(CCurrentThreadConnection.getConnection(), getSessionFactoryIfAny(psPattern));
	}
	
	
	public static final String getCreationStackTrace()
	{
		return CThreadLocalMultiSessionContext.getCreationStackTrace(CCurrentThreadConnection.getConnection(), getSessionFactoryIfAny());
	}
	
	/**
	 * Returns the instance SessionFactory; prefer using {@link DB#session()}
	 * @return SessionFactory, always not null.
	 */
	public static SessionFactory getSessionFactory()
	{
		return getSessionFactory(HIBERNATE_DEFAULT);
	}

	/**
	 * Returns the instance SessionFactory for a specified config; prefer using {@link DB#session(String)}
	 * 
	 * @param sHBMConfFilePattern
	 * @return
	 */
	public static SessionFactory getSessionFactory(String sHBMConfFilePattern)
	{
		if (m_sessionFactory.get(sHBMConfFilePattern) == null)
		{
			synchronized (MUTEX)
			{
				if (m_sessionFactory.get(sHBMConfFilePattern) == null)
				{
					SessionFactory customSession = initSessionFactory(sHBMConfFilePattern);
					m_sessionFactory.put(sHBMConfFilePattern, customSession);
				}
			}
		}

		return m_sessionFactory.get(sHBMConfFilePattern);
	}
		
	public static void setSessionFactory(Map<String, SessionFactory> sessionFactory)
	{
		if (m_sessionFactory != null && !m_sessionFactory.isEmpty())
		{
			throw new IllegalStateException("SessionFactory is already set up");
		}

		synchronized (MUTEX)
		{
			m_sessionFactory = sessionFactory;
		}
	}
}