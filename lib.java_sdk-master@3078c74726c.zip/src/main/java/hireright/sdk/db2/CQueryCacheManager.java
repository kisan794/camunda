/*
 * @(#)$RCSfile: CQueryCacheManager.java,v $ $Revision: 1.6 $ $Date: 2008/07/28 09:46:53 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CQueryCacheManager.java,v $
 *
 * Copyright 2001-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *   Sergei Prokopov		2007-03-29	Created
 *   A.Solntsev				2007-06-22	Removed dependency on hireright.sdkex.as_cache
 */
package hireright.sdk.db2;

import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.hibernate.Query;

/**
 * Cache Manager for hibernate Query objects
 *
 * @author  Sergei Prokopov
 * @version $Revision: 1.6 $, $Date: 2008/07/28 09:46:53 $, $Author: cvsroot $
 * @source	$Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CQueryCacheManager.java,v $
 */
public class CQueryCacheManager
{
	protected static final String CLASS_VERSION = "$Revision: 1.6 $ $Author: cvsroot $";
	
	/**
	 * Loader for CDrivingLicenseRequirement object
	 */
	private static Cache m_cache;

	protected static Cache getInstance()
	{
		if (null == m_cache)
		{
			CacheManager cacheManager = CacheManager.create();
			final String sCacheName = CQueryCacheManager.class.getName();

			// Try to find predefined cache with given name
			m_cache = cacheManager.getCache(sCacheName);

			if (m_cache == null)
			{
				// Create cache with default settings.
				cacheManager.addCache(sCacheName);
				m_cache = cacheManager.getCache(sCacheName);
			}
		}

		return m_cache;
	}

	/**
	 * Returns list of objects from current query
	 *
	 * @param query		query object
	 * @param sKey		cache key. Expected format: "ClassName.functionName:ParameterName:ParameterValue"
	 * @return <code>List</code>
	 */
	public static List getList(Query query, String sKey)
	{
		Element el = getInstance().get(sKey);
		if (el == null)
		{
			// Loads object if it's not cached yet
			List cachedQueryResult = query.list();
			el = new Element(sKey, cachedQueryResult);
			getInstance().put(el);
		}
		return (List) el.getValue();
	}
}

