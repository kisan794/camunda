/*
 * @(#)$RCSfile: CHibernateMappingScanner.java,v $ $Revision: 1.2 $ $Date: 2014/05/17 07:17:29 $ $Author: cvsroot $
 *
 * Copyright 2001-2014 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *	atanasenko	27.03.2014	Created
 * Y.Banadyseu	2022-07-07 HRG-156300: fixed scan classes with annotations @Entity that use lambda expressions, refactored.
 */
package hireright.sdk.db2;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.hibernate.MappingException;
import org.hibernate.util.ReflectHelper;
import org.reflections.Reflections;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.util.ClassUtils;

class CHibernateMappingScanner {
	protected static final String CLASS_VERSION = "$Revision: 1.2 $ $Author: cvsroot $";
	private final String basePackage;
	
	public CHibernateMappingScanner(String basePackage) {
		this.basePackage = basePackage;
	}

	public List<CHibernateMappingItem> scan() throws MappingException {
		List<CHibernateMappingItem> items = new ArrayList<>();
		
		// scan classes
		Reflections reflections = new Reflections(basePackage);
		Set<Class<?>> annotatedClasses = reflections.getTypesAnnotatedWith(javax.persistence.Entity.class);
		annotatedClasses.addAll(reflections.getTypesAnnotatedWith(org.hibernate.annotations.Entity.class));
		
		List<String> foundClassesNames = annotatedClasses
			.stream()
			.map(Class::getCanonicalName)
			.collect(Collectors.toList());
		
		for(String className: foundClassesNames) {
			Class<?> loadedClass;
			try {
				loadedClass = ReflectHelper.classForName(className);
			} catch (ClassNotFoundException | NoClassDefFoundError exception) {
				throw new MappingException("Unable to load class declared as <mapping class=\"" + className + "\"/> in the configuration:",	exception);
			}
			items.add(new CHibernateMappingItem(loadedClass));
		}
		
		// scan resources
		ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
		Resource[] resources;
		try {
			resources = resourcePatternResolver.getResources(
				ResourcePatternResolver.CLASSPATH_ALL_URL_PREFIX +
					ClassUtils.convertClassNameToResourcePath(basePackage) +
					"/**/*.hbm.xml");
			
			for(Resource res : resources) {
				items.add(new CHibernateMappingItem(res.getURL()));
			}
		} catch(IOException ex) {
			throw new MappingException("I/O failure during classpath scanning", ex);
		}
		
		return items;
	}
	
	static class CHibernateMappingItem {
		private final boolean isClazz;
		private URL url;
		private Class<?> clazz;
		private final String name;
		
		public CHibernateMappingItem(Class<?> clazz) {
			this.isClazz = true;
			this.clazz = clazz;
			this.name = clazz.getName();
		}
		
		public CHibernateMappingItem(URL url) {
			this.isClazz = false;
			this.url = url;
			this.name = url.getFile();
		}
		
		public String getName() {
			return this.name;
		}
		
		public URL getURL() {
			return url;
		}
		
		public boolean isClass() {
			return isClazz;
		}
		
		public Class<?> getClazz() {
			return clazz;
		}
		
		public boolean isNotClass() {
			return !isClass();
		}
	}
}
