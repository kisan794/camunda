/*
 * @(#)$RCSfile: CConnectionWrapper.java,v $Revision: 1.5 $ $Date: 2015/11/02 20:14:52 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CConnectionWrapper.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 * 	M.Abdulganejev			2010-06-09	created
 * 	M.Suhhoruki				2013-09-10	added org.jboss.jca.adapters.jdbc.WrappedStatement for JBoss 7
 * 	M.Suhhoruki				2014-05-20	unwrapOracleStatement: Proxy support
 * 	M.Suhhoruki				2017-01-19	added org.apache.tomcat.dbcp.dbcp2.DelegatingStatement
 * 	M.Suhhoruki				2017-01-22	added IStatementUnwrapper for dynamic unwrappers
 * 	V.Ozernov				2018-06-20	HIVPE-44349 Class for StatementUnwrapper can also be specified in app server property
 */

package hireright.sdk.db2;

import hireright.sdk.db.CAbstractStatementProxy;
import hireright.dbcp.spi.IStatementUnwrapper;
import hireright.sdk.util.CClass;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.CSystemConfigurationException;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ServiceLoader;

import oracle.jdbc.OraclePreparedStatement;

import org.apache.commons.dbcp.DelegatingStatement;

/**
 * @author Andrei Solntsev
 * @version $Revision: 1.5 $ $Date: 2015/11/02 20:14:52 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CConnectionWrapper.java,v $
 */
public class CConnectionWrapper 
{
	protected static final String CLASS_VERSION = "$Revision: 1.5 $ $Author: cvsroot $";
	
	/**
	 * Allows to configure statement unwrappers:
	 * A WAR should contain:
	 * 1. META-INF/services/hireright.dbcp.spi.IStatementUnwrapper pointing to one or more service providers like hireright.dbcp.tomcat.CTomcatDbcpStatementUnwrapper
	 * 2. OR application server can contain property "hireright.dbcp.spi.IStatementUnwrapper" pointing to provider like hireright.dbcp.tomcat.CTomcatDbcpStatementUnwrapper
	 */
	private static final Collection<IStatementUnwrapper> STATEMENT_UNWRAPPERS;
	static
	{
		try
		{
			STATEMENT_UNWRAPPERS = new LinkedList<IStatementUnwrapper>();
			ServiceLoader<IStatementUnwrapper> spiLoader = ServiceLoader.load(IStatementUnwrapper.class);
			for(IStatementUnwrapper unwrapper : spiLoader)
			{
				STATEMENT_UNWRAPPERS.add(unwrapper);
			}

			String sStatementUnwrapperClassName = System.getProperty("hireright.dbcp.spi.IStatementUnwrapper");
			if (!CStringUtils.isEmpty(sStatementUnwrapperClassName))
			{
				STATEMENT_UNWRAPPERS.add((IStatementUnwrapper)Class.forName(sStatementUnwrapperClassName).newInstance());
			}
		}
		catch (Throwable t)
		{
			throw new CSystemConfigurationException(t); 
		}
	}
	
	public static OraclePreparedStatement requireOracleStatement(Statement st) throws SQLException 
	{	
		OraclePreparedStatement ost = unwrapOracleStatement(st, null);
		if(ost != null)
		{
			return ost;
		}
		
		StringBuilder sb = new StringBuilder();
		sb.append("Requiring " + OraclePreparedStatement.class.getName() + " [" + CClass.getClassVersion(OraclePreparedStatement.class) + "]\n");
		unwrapOracleStatement(st, sb);
		throw new SQLException("Cannot unwrap oracle statement:\n" + sb.toString());
	}
	
	public static OraclePreparedStatement unwrapOracleStatement(Statement st) throws SQLException 
	{	
		return unwrapOracleStatement(st, null);
	}
	
	public static OraclePreparedStatement unwrapOracleStatement(Statement stmt, StringBuilder sb) throws SQLException 
	{	
		if(sb != null)
		{
			if(stmt == null) sb.append("  initial statement is null");
		}
		Statement st = unproxyStatement(stmt);
		
		if(sb != null) 
		{
			if(st == null) sb.append("  statement is null");
			else sb.append("  " + st.getClass().getName() + " [" + CClass.getClassVersion(st.getClass()) + "]\n");
		}
		
		if(st instanceof OraclePreparedStatement)
		{
			// found oracle preparedStatement
			return (OraclePreparedStatement) st;
		}
		else
		{
			Statement unwrappedStatement = unwrapUsingService(st);
			if (unwrappedStatement != null)
			{
				return (OraclePreparedStatement) unwrappedStatement;
			}
			else if(isAssignableTo(st, "org.jboss.resource.adapter.jdbc.WrappedStatement")
					|| isAssignableTo(st, "org.jboss.jca.adapters.jdbc.WrappedStatement"))
			{
				return unwrapDynamic(st, "getUnderlyingStatement", sb);
			}
			else if(st instanceof DelegatingStatement)
			{
				// DBCP pooling
				return unwrapOracleStatement(((DelegatingStatement)st).getDelegate(), sb);
			}
		}
		
		return null;
	}
	
	private static boolean isAssignableTo(Object o, String className) 
	{	
		Class<?> clazz = o.getClass();
		
		while(clazz != null)
		{
			if(clazz.getName().equals(className))
			{
				return true;
			}
			
			for(Class<?> iface: clazz.getInterfaces())
			{
				if(iface.getName().equals(className))
				{
					return true;
				}
			}
			
			clazz = clazz.getSuperclass();
		}
		
		return false;
	}
	
	private static Statement unproxyStatement(Statement stmt)
	{
		return CAbstractStatementProxy.unwrapAll(stmt);
	}
	
	private static OraclePreparedStatement unwrapDynamic(Statement st, String sMethodName, StringBuilder sb)
		throws SQLException
	{
		Statement underlyingStatement;
		try
		{
			Method m = st.getClass().getMethod("getUnderlyingStatement");
			underlyingStatement = (Statement) m.invoke(st);
		}
		catch (Exception e)
		{
			throw new IllegalStateException(e);
		}
		
		return unwrapOracleStatement(underlyingStatement, sb);
	}
	
	private static Statement unwrapUsingService(Statement st)
	{
		if (STATEMENT_UNWRAPPERS == null)
		{
			return null;
		}
		
		Iterator<IStatementUnwrapper> unwrprs = STATEMENT_UNWRAPPERS.iterator();
		if (unwrprs == null || !unwrprs.hasNext())
		{
			return null;
		}
		
		Statement unwrappedStatement = null;
		while (unwrprs.hasNext())
		{
			IStatementUnwrapper unwrpr = unwrprs.next();
			if (unwrpr != null)
			{
				unwrappedStatement = unwrpr.unwrap(st);
				if (unwrappedStatement != null)
				{
					break;
				}
			}
		}
		
		return unwrappedStatement;
	}
}
