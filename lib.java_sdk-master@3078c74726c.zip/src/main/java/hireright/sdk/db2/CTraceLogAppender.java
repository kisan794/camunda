/*
 * @(#)$RCSfile: CTraceLogAppender.java,v $ $Revision: 1.10 $ $Date: 2012/08/24 07:25:42 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/CTraceLogAppender.java,v $
 *
 * Copyright 2005-2007 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 *  A.Solntsev		2005-07-20	Created
 *  A.Solntsev		2006-06-16	Moved to package hireright.sdk.db2
 *  A.Solntsev		2007-01-05	Added handling ILoggableException, Throwable
 *  V.Lazarev			2007-03-28	System property 'process_name' is added to be used as preffix for source  
 *  M.Suhhoruki		2007-11-28	Set log ID for ILoggableException instances
 *	A.Arekhin			2011-08-17	Removed host name resolving
 *	A.Knyazev			2012-08-10	Deprecated in favor of hireright.sdkex.log4j.TraceLogAppender from
 *														tracelog4j.
 *	A.Knyazev			2012-08-10	Removed: class with the same purpose and name is defined in tracelog4j.
 */
