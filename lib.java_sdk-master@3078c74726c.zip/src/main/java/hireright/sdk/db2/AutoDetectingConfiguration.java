/*
 * @(#)$RCSfile: AutoDetectingConfiguration.java,v $ $Revision: 1.14 $ $Date: 2015/11/02 20:14:58 $ $Author: cvsroot $
 * $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/AutoDetectingConfiguration.java,v $
 *
 * Copyright 2001-2010 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information of HireRight, Inc. Use is subject to license
 * terms.
 *
 * History:
 *	A.Solntsev			2007-09-08	created
 *	A.Solntsev			2007-09-18	addJar(): Fixed bug: used file name instead of absolute path
 *	A.Solntsev			2009-02-03	Bugfix for unit-tests; less output.
 *	E.Shatohhin			2010-01-06	AnnotationConfiguration base class for annotations support
 *	A.Solntsev			2010-03-05	Use log4j instead of commons-logging.
 */
package hireright.sdk.db2;

import hireright.sdk.db2.CHibernateMappingScanner.CHibernateMappingItem;
import hireright.sdk.io.CFile;
import hireright.sdk.io.RegexpFileFilter;
import hireright.sdk.util.CStringUtils;
import hireright.sdk.util.WildCardFileFilter;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.dom4j.Attribute;
import org.dom4j.Element;
import org.hibernate.MappingException;
import org.hibernate.cfg.AnnotationConfiguration;

/**
 * @author Andrei Solntsev
 * @since Sep 8, 2007
 * @version $Revision: 1.14 $ $Date: 2015/11/02 20:14:58 $ $Author: cvsroot $
 * @source $Source: /usr/local/cvsroot/projects_src/lib/java_sdk/src/main/java/hireright/sdk/db2/AutoDetectingConfiguration.java,v $
 */
class AutoDetectingConfiguration extends AnnotationConfiguration 
{
	private static final long serialVersionUID = 1L;

	protected static final String CLASS_VERSION = "$Revision: 1.14 $ $Author: cvsroot $";
	
	private static final Logger log = Logger.getLogger(AutoDetectingConfiguration.class);
	
	@Override
	protected void parseMappingElement(Element subelement, String name) {
		Attribute scan = subelement.attribute( "package" );
		if ( scan != null ) {
			log.debug( name + " <- " + scan );
			addScan( scan.getValue() );
		}
		else {
			super.parseMappingElement(subelement, name);
		}
	}


	public void addScan(String value) throws MappingException
	{
		long t = System.currentTimeMillis();
		List<CHibernateMappingItem> items = new CHibernateMappingScanner(value).scan();
		
		t = System.currentTimeMillis() - t;
		log.info("[Auto-Discovery] Scanned package " + value + ", found " + items.size() + " items in " + t + "ms");
		
		Set<String> failedEntities = new LinkedHashSet<String>();
		
		for(CHibernateMappingItem item: items)
		{
			try
			{
				if(item.isClass())
				{
					log.debug( "[Auto-Discovery] Adding annotated class : " + item.getName() );
					addAnnotatedClass(item.getClazz());
				}
				else
				{
					// resource
					log.debug( "[Auto-Discovery] Reading mappings from resource : " + item.getName() );
					addURL(item.getURL());
				}
			}
			catch(MappingException e)
			{
				log.error( "[Auto-Discovery] Error loading mapping : " + item.getName(), e );
				failedEntities.add(item.getName());
			}
		}
		
		if(!failedEntities.isEmpty())
		{
			throw new MappingException("[Auto-Discovery] Following entities failed to load: " + failedEntities);
		}
	}


	@Override
	public AnnotationConfiguration addJar(File jar) throws MappingException
	{
		String sJarFileNamePattern = jar.getName();
		if (sJarFileNamePattern.indexOf('*') == -1)
			return super.addJar(jar);

		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		if (!(cl instanceof URLClassLoader))
		{
			log.warn("Classloader is not instance of URLClassLoader, unable to search jars: " + cl);
			return this;
		}

		URLClassLoader urlCL = (URLClassLoader) cl;
		URL[] urls = urlCL.getURLs();

		FilenameFilter filenameFilter = new WildCardFileFilter(sJarFileNamePattern);
		if (log.isDebugEnabled())
			log.debug("Start scanning classpath for jars: " + CStringUtils.arrayToString(urls));

		URL urlCodeSource;
		for (int i=0; i<urls.length; i++)
		{
			urlCodeSource = urls[i];
			File fCodeSource = new File(urlCodeSource.getPath());
			if (fCodeSource.canRead() && fCodeSource.isFile())
			{
				if (filenameFilter.accept(fCodeSource.getParentFile(), fCodeSource.getName()))
				{
					if (log.isDebugEnabled())
						log.debug(fCodeSource + " scanning jar...");
					try
					{
						super.addJar(fCodeSource);
					}
					catch (org.hibernate.DuplicateMappingException duplEx)
					{
						log.warn("duplicate found while parsing " + jar.getAbsolutePath(), duplEx);
					}
					catch (org.hibernate.MappingException ex)
					{
						log.warn("Failed to read " + jar.getAbsolutePath(), ex);
					}
				}
				else
				{
					log.info(fCodeSource + ": doesn't match pattern " + sJarFileNamePattern);
				}
			}
		}
		return this;
	}

	@Override
	public AnnotationConfiguration addResource(String sHbmFileNamePattern) throws MappingException
	{
		if (sHbmFileNamePattern.indexOf('*') == -1)
			return super.addResource(sHbmFileNamePattern);

		if (!sHbmFileNamePattern.startsWith("*") && !sHbmFileNamePattern.startsWith("/"))
		{
			log.warn("HBM.XML pattern should start either with ** or /, otherwise it hardly matches anything: " + sHbmFileNamePattern);
		}
		
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		if (!(cl instanceof URLClassLoader))
		{
			log.warn("Classloader is not instance of URLClassLoader, unable to search HBM files: " + cl);
			return this;
		}

		URLClassLoader urlCL = (URLClassLoader) cl;
		URL[] urls = urlCL.getURLs();
		
		log.info("Start scanning classpath for hbms: " + CStringUtils.arrayToString(urls));

		URL urlCodeSource;
		for (int i=0; i<urls.length; i++)
		{
			urlCodeSource = urls[i];
			File fCodeSource = new File(urlCodeSource.getPath());
			if (fCodeSource.canRead() && fCodeSource.isDirectory())
			{
				//System.out.println(fCodeSource + " scanning directory for " + sHbmFileNamePattern + " ...");
				log.info(fCodeSource + " scanning directory for " + sHbmFileNamePattern + " ...");

				Collection<String> hbms = CFile.getFileList(fCodeSource, 
						new RegexpFileFilter(fCodeSource, sHbmFileNamePattern), true);

				if (hbms == null || hbms.isEmpty())
				{
					if (fCodeSource.getPath().endsWith("classes"))
					{
						//Collection<String> allFiles = CFile.getFileList(fCodeSource, new AllFilesFilter(), true);
						log.info("  > Dir " + fCodeSource + " does not contain files " + sHbmFileNamePattern
							//+ " ..., see full listing:\n"  + allFiles
								);
					}
					else
					{
						log.info("  > Dir " + fCodeSource + " does not contain files " + sHbmFileNamePattern);
					}
					continue;
				}

				for (String sFileName : hbms)
				{
					try
					{
						log.info("   + " + sFileName);
						super.addInputStream(new FileInputStream(sFileName));
					}
					catch (org.hibernate.DuplicateMappingException duplEx)
					{
						log.warn("duplicate found while parsing " + sFileName, duplEx);
					}
					catch (org.hibernate.MappingException ex)
					{
						log.warn("Failed to read " + sFileName, ex);
					}
					catch (FileNotFoundException fex)
					{
						log.warn("File not found: " + sFileName, fex);
					}
				}
			}
		}
		return this;
	}
}

class AllFilesFilter implements FilenameFilter, FileFilter
{
	public boolean accept(File dir, String name)
	{
		return true;
	}

	public boolean accept(File pathname)
	{
		return true;
	}
}