package hireright.applications.fulfillment_task_api.api.validation;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-09-03  ATS-2278 initial version
 */

import hireright.applications.fulfillment_task_api.api.ITestApi;
import hireright.applications.fulfillment_task_api.api.management.IServiceHealthManager;
import hireright.applications.fulfillment_task_api.api.management.ITestManager;
import hireright.applications.fulfillment_task_api.api.validation.management.CTestManager;

public class CValidatingTestApi implements ITestApi {
    private final ITestApi delegate;

    public CValidatingTestApi(ITestApi delegate) {
        this.delegate = delegate;
    }

    @Override
    public ITestManager getTestManager() {
        return new CTestManager(this.delegate.getTestManager());
    }

    @Override
    public IServiceHealthManager getServiceHealthManager() {
        return this.delegate.getServiceHealthManager();
    }
}
