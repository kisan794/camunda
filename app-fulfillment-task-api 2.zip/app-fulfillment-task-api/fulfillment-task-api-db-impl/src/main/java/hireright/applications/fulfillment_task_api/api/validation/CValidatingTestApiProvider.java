package hireright.applications.fulfillment_task_api.api.validation;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-09-03  ATS-2278 initial version
 */

import hireright.applications.fulfillment_task_api.api.ITestApi;
import hireright.applications.fulfillment_task_api.api.ITestApiProvider;

public class CValidatingTestApiProvider implements ITestApiProvider {
    private final ITestApiProvider delegate;

    public CValidatingTestApiProvider(ITestApiProvider delegate) {
        this.delegate = delegate;
    }

    @Override
    public ITestApi getApi() {
        return new CValidatingTestApi(this.delegate.getApi());
    }
}
