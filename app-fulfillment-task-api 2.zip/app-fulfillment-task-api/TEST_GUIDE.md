# Test Guide - Circuit Breaker & Retry Queue Implementation

## Overview

This guide provides comprehensive information about the test suite for the Circuit Breaker and Retry Queue implementation.

## Test Structure

```
fulfillment-task-api-app/src/test/java/
└── hireright/applications/fulfillment_task_api/rest/recombointegration/
    ├── circuitbreaker/
    │   └── CircuitBreakerServiceTest.java
    ├── retry/
    │   └── RetryMessagePublisherTest.java
    ├── listener/
    │   └── ScreeningRequestListenerTest.java
    ├── service/impl/
    │   └── FulfillmentServiceImplTest.java
    └── integration/
        └── CircuitBreakerRetryIntegrationTest.java
```

## Test Coverage

### 1. CircuitBreakerServiceTest (Unit Tests)

**Purpose**: Tests the circuit breaker state machine and transitions.

**Test Cases**:
- ✅ Initial state should be CLOSED
- ✅ Transition from CLOSED to OPEN when failure threshold reached
- ✅ CLOSED state allows requests
- ✅ OPEN state rejects requests
- ✅ Transition from OPEN to HALF_OPEN after timeout
- ✅ Transition from HALF_OPEN to CLOSED when success threshold reached
- ✅ Transition from HALF_OPEN to OPEN on failure
- ✅ Success in CLOSED state resets failure count
- ✅ Metrics reporting
- ✅ Thread safety with concurrent access
- ✅ Reset functionality
- ✅ Failure rate calculation in sliding window
- ✅ Multiple state transitions

**Key Assertions**:
- State transitions occur at correct thresholds
- Requests are allowed/rejected based on state
- Thread-safe operation under concurrent load
- Metrics accurately reflect circuit state

### 2. RetryMessagePublisherTest (Unit Tests)

**Purpose**: Tests retry queue routing logic and message metadata handling.

**Test Cases**:
- ✅ First failure routes to Retry Queue 1
- ✅ Second failure routes to Retry Queue 2
- ✅ Third failure routes to Retry Queue 3
- ✅ Max retries exceeded routes to DLQ
- ✅ Metadata preservation - first failure time
- ✅ Metadata preservation - subsequent failures
- ✅ Original queue tracking
- ✅ Message body preservation
- ✅ Null task ID handling
- ✅ Empty failure reason handling
- ✅ Retry count increment sequential
- ✅ Concurrent publishing thread safety

**Key Assertions**:
- Messages routed to correct retry queues based on retry count
- Metadata headers correctly set and preserved
- Original message body unchanged
- Thread-safe under concurrent load

### 3. ScreeningRequestListenerTest (Unit Tests)

**Purpose**: Tests listener behavior with circuit breaker and retry integration.

**Test Cases**:
- ✅ Successful processing should ACK message
- ✅ Circuit breaker OPEN should route to retry queue
- ✅ Processing failure should route to retry queue
- ✅ Retry attempt should log retry count
- ✅ Missing task ID should NACK message
- ✅ Circuit breaker null (disabled) should process normally
- ✅ Retry publisher failure should NACK message
- ✅ Channel ACK failure should throw exception
- ✅ Multiple parameters should extract task ID
- ✅ Case-insensitive task ID parameter
- ✅ Circuit breaker metrics logging
- ✅ First failure vs retry different logging

**Key Assertions**:
- Messages acknowledged/rejected appropriately
- Circuit breaker checked before processing
- Failures recorded in circuit breaker
- Retry publisher called on failures
- Task ID extracted correctly from event parameters

### 4. FulfillmentServiceImplTest (Unit Tests)

**Purpose**: Tests fulfillment service with circuit breaker integration.

**Test Cases**:
- ✅ Null task data should return early
- ✅ Successful HTTP response should record success
- ✅ HTTP error response should record failure
- ✅ Exception should record failure
- ✅ Null circuit breaker should not fail
- ✅ Correct URL construction
- ✅ Correct headers with API key
- ✅ Logging called for requests/responses
- ✅ Order history record created
- ✅ Multiple HTTP status codes handled
- ✅ JSON serialization
- ✅ Circuit breaker metrics after success
- ✅ Circuit breaker metrics after failure

**Key Assertions**:
- Circuit breaker records success/failure based on HTTP response
- Async processing completes successfully
- Correct URL and headers sent to external system
- Logging and order history updated
- Works with and without circuit breaker

### 5. CircuitBreakerRetryIntegrationTest (Integration Tests)

**Purpose**: End-to-end integration tests for complete retry flow.

**Test Cases**:
- ✅ End-to-end successful processing
- ✅ Single failure with retry
- ✅ Multiple retries until DLQ
- ✅ Circuit breaker opens after threshold
- ✅ Circuit breaker recovery (OPEN → HALF_OPEN → CLOSED)
- ✅ Metadata tracking through retry flow
- ✅ Concurrent message processing
- ✅ Mixed success and failure scenarios

**Key Assertions**:
- Complete flow from listener to retry queues works
- Circuit breaker integrates correctly with retry mechanism
- Messages progress through R1Q → R2Q → R3Q → DLQ
- Circuit breaker state transitions work in real scenarios
- System handles concurrent load

## Running the Tests

### Prerequisites

- Java 17 or higher
- Maven 3.6+
- JUnit 5
- Mockito 4+

### Run All Tests

```bash
cd fulfillment-task-api-app
mvn clean test
```

### Run Specific Test Class

```bash
# Circuit Breaker tests
mvn test -Dtest=CircuitBreakerServiceTest

# Retry Publisher tests
mvn test -Dtest=RetryMessagePublisherTest

# Listener tests
mvn test -Dtest=ScreeningRequestListenerTest

# Fulfillment Service tests
mvn test -Dtest=FulfillmentServiceImplTest

# Integration tests
mvn test -Dtest=CircuitBreakerRetryIntegrationTest
```

### Run Specific Test Method

```bash
mvn test -Dtest=CircuitBreakerServiceTest#testClosedToOpen_WhenFailureThresholdReached
```

### Run with Coverage

```bash
mvn clean test jacoco:report
```

Coverage report will be available at: `target/site/jacoco/index.html`

## Test Configuration

Test-specific configuration is in `src/test/resources/application-test.yml`:

- Faster timeouts for quicker test execution
- Shorter retry delays (100ms, 200ms, 300ms)
- Circuit breaker timeout of 1 second
- Test-specific queue names

## Dependencies Required

Add to `pom.xml` if not already present:

```xml
<dependencies>
    <!-- JUnit 5 -->
    <dependency>
        <groupId>org.junit.jupiter</groupId>
        <artifactId>junit-jupiter</artifactId>
        <version>5.9.3</version>
        <scope>test</scope>
    </dependency>

    <!-- Mockito -->
    <dependency>
        <groupId>org.mockito</groupId>
        <artifactId>mockito-core</artifactId>
        <version>5.3.1</version>
        <scope>test</scope>
    </dependency>

    <dependency>
        <groupId>org.mockito</groupId>
        <artifactId>mockito-junit-jupiter</artifactId>
        <version>5.3.1</version>
        <scope>test</scope>
    </dependency>

    <!-- Spring Test -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>

    <!-- Spring AMQP Test -->
    <dependency>
        <groupId>org.springframework.amqp</groupId>
        <artifactId>spring-rabbit-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

## Test Scenarios Covered

### Scenario 1: Normal Operation
- Message arrives → Circuit CLOSED → Process successfully → ACK

### Scenario 2: Temporary Failure with Recovery
- Message arrives → Process fails → Route to R1Q → Wait 30s → Retry → Success

### Scenario 3: Circuit Breaker Opens
- 5 consecutive failures → Circuit OPEN → Subsequent requests fail fast

### Scenario 4: Circuit Breaker Recovery
- Circuit OPEN → Wait 60s → HALF_OPEN → 2 successes → CLOSED

### Scenario 5: Max Retries Exceeded
- Fail → R1Q → Fail → R2Q → Fail → R3Q → Fail → DLQ

### Scenario 6: Concurrent Processing
- Multiple messages processed simultaneously → Thread-safe operation

## Assertions and Validations

### Circuit Breaker Validations
- ✅ State transitions at correct thresholds
- ✅ Request allowance based on state
- ✅ Failure/success counting
- ✅ Timeout handling
- ✅ Thread safety

### Retry Queue Validations
- ✅ Correct routing based on retry count
- ✅ Metadata preservation
- ✅ Message body integrity
- ✅ Header management

### Integration Validations
- ✅ End-to-end message flow
- ✅ Component interaction
- ✅ Error propagation
- ✅ Recovery mechanisms

## Troubleshooting

### Tests Failing Due to Timing Issues

If integration tests fail due to timing:
1. Increase timeout values in test configuration
2. Add longer `Thread.sleep()` in async tests
3. Use `verify(mock, timeout(5000))` instead of immediate verification

### Mock Verification Failures

If mock verifications fail:
1. Check that mocks are properly reset between tests
2. Verify argument matchers are correct
3. Use `ArgumentCaptor` for complex assertions

### Async Test Issues

For async processing tests:
1. Use `CompletableFuture.join()` or `get()` to wait for completion
2. Use Mockito's `timeout()` for async verifications
3. Ensure proper thread context propagation

## Best Practices

1. **Isolation**: Each test should be independent
2. **Cleanup**: Reset mocks and state between tests
3. **Assertions**: Use specific assertions with clear messages
4. **Coverage**: Aim for >80% code coverage
5. **Performance**: Keep unit tests fast (<100ms each)
6. **Readability**: Use descriptive test names and comments

## Next Steps

After running tests:

1. Review coverage report
2. Add tests for edge cases if needed
3. Run integration tests against real RabbitMQ (optional)
4. Performance test with high message volume
5. Chaos testing (random failures, network issues)

## Contact

For questions or issues with tests, contact the development team.

