package hireright.applications.fulfillment_task_api.model.recombointegration.request.education;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Contact DTO for institution contact information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"personName", "title"})
public class CContact {

    @JsonProperty("personName")
    private String m_sPersonName;

    @JsonProperty("title")
    private String m_sTitle;

    private CContact() {
    }

    public CContact(Builder builder) {
        m_sPersonName = builder.m_sPersonName;
        m_sTitle = builder.m_sTitle;
    }

    public String getPersonName() {
        return m_sPersonName;
    }

    public String getTitle() {
        return m_sTitle;
    }

    public static final class Builder {

        private String m_sPersonName;
        private String m_sTitle;

        public Builder() {
        }

        public Builder personName(String personName) {
            m_sPersonName = personName;
            return this;
        }

        public Builder title(String title) {
            m_sTitle = title;
            return this;
        }

        public CContact build() {
            return new CContact(this);
        }
    }
}

