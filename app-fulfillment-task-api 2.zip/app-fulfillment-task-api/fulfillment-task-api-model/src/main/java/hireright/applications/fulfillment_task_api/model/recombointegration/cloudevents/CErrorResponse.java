package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.time.Instant;

/**
 * CloudEvents v1.0 compliant error response.
 * Used for returning structured error information following CloudEvents specification.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"specversion", "id", "source", "type", "datacontenttype", "time", "data"})
public class CErrorResponse {

    @JsonProperty("specversion")
    private String m_sSpecVersion = "1.0";

    @JsonProperty("id")
    private String m_sId;

    @JsonProperty("source")
    private String m_sSource = "hrg:hre:fulfillment";

    @JsonProperty("type")
    private String m_sType;

    @JsonProperty("datacontenttype")
    private String m_sDataContentType = "application/json";

    @JsonProperty("time")
    private String m_sTime = Instant.now().toString();

    @JsonProperty("data")
    private CErrorData m_data;

    private CErrorResponse() {
    }

    private CErrorResponse(Builder builder) {
        m_sSpecVersion = builder.m_sSpecVersion;
        m_sId = builder.m_sId;
        m_sSource = builder.m_sSource;
        m_sType = builder.m_sType;
        m_sDataContentType = builder.m_sDataContentType;
        m_sTime = builder.m_sTime;
        m_data = builder.m_data;
    }

    @JsonIgnore
    public String getSpecVersion() {
        return m_sSpecVersion;
    }

    @JsonIgnore
    public String getId() {
        return m_sId;
    }

    @JsonIgnore
    public String getSource() {
        return m_sSource;
    }

    @JsonIgnore
    public String getType() {
        return m_sType;
    }

    @JsonIgnore
    public String getDataContentType() {
        return m_sDataContentType;
    }

    @JsonIgnore
    public String getTime() {
        return m_sTime;
    }

    @JsonIgnore
    public CErrorData getData() {
        return m_data;
    }

    public static final class Builder {

        private String m_sSpecVersion = "1.0";
        private String m_sId;
        private String m_sSource = "hrg:hre:fulfillment";
        private String m_sType;
        private String m_sDataContentType = "application/json";
        private String m_sTime = Instant.now().toString();
        private CErrorData m_data;

        public Builder() {
        }

        public Builder specVersion(String sSpecVersion) {
            m_sSpecVersion = sSpecVersion;
            return this;
        }

        public Builder id(String sId) {
            m_sId = sId;
            return this;
        }

        public Builder source(String sSource) {
            m_sSource = sSource;
            return this;
        }

        public Builder type(String sType) {
            m_sType = sType;
            return this;
        }

        public Builder dataContentType(String sDataContentType) {
            m_sDataContentType = sDataContentType;
            return this;
        }

        public Builder time(String sTime) {
            m_sTime = sTime;
            return this;
        }

        public Builder data(CErrorData data) {
            m_data = data;
            return this;
        }

        public CErrorResponse build() {
            return new CErrorResponse(this);
        }
    }

    /**
     * Create an authentication error response
     */
    public static CErrorResponse authenticationError(String requestId, String message, String reason) {
        return new CErrorResponse.Builder()
                .id(requestId)
                .type("Error.Authentication")
                .data(new CErrorData.Builder()
                        .status(401)
                        .error("Unauthorized")
                        .message(message)
                        .errorCode("AUTH001")
                        .reason(reason)
                        .build())
                .build();
    }

    /**
     * Create a validation error response
     */
    public static CErrorResponse validationError(String requestId, String message, java.util.List<CValidationDetail> details) {
        return new CErrorResponse.Builder()
                .id(requestId)
                .type("Error.Validation")
                .source("hrg:hre:task")
                .data(new CErrorData.Builder()
                        .status(400)
                        .error("Bad Request")
                        .errorCode("REQ001")
                        .message(message)
                        .details(details)
                        .build())
                .build();
    }

    /**
     * Create a generic error response
     */
    public static CErrorResponse genericError(String requestId, String type, int status, String error, String errorCode, String message) {
        return new CErrorResponse.Builder()
                .id(requestId)
                .type(type)
                .data(new CErrorData.Builder()
                        .status(status)
                        .error(error)
                        .errorCode(errorCode)
                        .message(message)
                        .build())
                .build();
    }
}
