package hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Education Qualifications DTO for education verification result data
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"degree", "startDate", "endDate", "educationStatusCode", "educationStatus", "grade",
        "degreeReceived", "degreeDate", "permissionToContact", "spokeWith"})
public class CEducationQualifications {

    @JsonProperty("degree")
    private String m_sDegree;

    @JsonProperty("startDate")
    private String m_sStartDate;

    @JsonProperty("endDate")
    private String m_sEndDate;

    @JsonProperty("educationStatusCode")
    private String m_sEducationStatusCode;

    @JsonProperty("educationStatus")
    private String m_sEducationStatus;

    @JsonProperty("grade")
    private String m_sGrade;

    @JsonProperty("degreeReceived")
    private boolean m_degreeReceived;

    @JsonProperty("degreeDate")
    private String m_sDegreeDate;

    @JsonProperty("permissionToContact")
    private boolean m_permissionToContact;

    @JsonProperty("spokeWith")
    private String m_sSpokeWith;

    private CEducationQualifications() {
    }

    private CEducationQualifications(Builder builder) {
        m_sDegree = builder.m_sDegree;
        m_sStartDate = builder.m_sStartDate;
        m_sEndDate = builder.m_sEndDate;
        m_sEducationStatusCode = builder.m_sEducationStatusCode;
        m_sEducationStatus = builder.m_sEducationStatus;
        m_sGrade = builder.m_sGrade;
        m_degreeReceived = builder.m_degreeReceived;
        m_sDegreeDate = builder.m_sDegreeDate;
        m_permissionToContact = builder.m_permissionToContact;
        m_sSpokeWith = builder.m_sSpokeWith;
    }

    public String getDegree() {
        return m_sDegree;
    }

    public String getStartDate() {
        return m_sStartDate;
    }

    public String getEndDate() {
        return m_sEndDate;
    }

    public String getEducationStatusCode() {
        return m_sEducationStatusCode;
    }

    public String getEducationStatus() {
        return m_sEducationStatus;
    }

    public String getGrade() {
        return m_sGrade;
    }

    public boolean isDegreeReceived() {
        return m_degreeReceived;
    }

    public String getDegreeDate() {
        return m_sDegreeDate;
    }

    public boolean isPermissionToContact() {
        return m_permissionToContact;
    }

    public String getSpokeWith() {
        return m_sSpokeWith;
    }

    public static final class Builder {

        private String m_sDegree;
        private String m_sStartDate;
        private String m_sEndDate;
        private String m_sEducationStatusCode;
        private String m_sEducationStatus;
        private String m_sGrade;
        private boolean m_degreeReceived;
        private String m_sDegreeDate;
        private boolean m_permissionToContact;
        private String m_sSpokeWith;

        public Builder() {
        }

        public Builder degree(String sDegree) {
            m_sDegree = sDegree;
            return this;
        }

        public Builder startDate(String sStartDate) {
            m_sStartDate = sStartDate;
            return this;
        }

        public Builder endDate(String sEndDate) {
            m_sEndDate = sEndDate;
            return this;
        }

        public Builder educationStatusCode(String sEducationStatusCode) {
            m_sEducationStatusCode = sEducationStatusCode;
            return this;
        }

        public Builder educationStatus(String sEducationStatus) {
            m_sEducationStatus = sEducationStatus;
            return this;
        }

        public Builder grade(String sGrade) {
            m_sGrade = sGrade;
            return this;
        }

        public Builder degreeReceived(boolean degreeReceived) {
            m_degreeReceived = degreeReceived;
            return this;
        }

        public Builder degreeDate(String sDegreeDate) {
            m_sDegreeDate = sDegreeDate;
            return this;
        }

        public Builder permissionToContact(boolean permissionToContact) {
            m_permissionToContact = permissionToContact;
            return this;
        }

        public Builder spokeWith(String sSpokeWith) {
            m_sSpokeWith = sSpokeWith;
            return this;
        }

        public CEducationQualifications build() {
            return new CEducationQualifications(this);
        }
    }
}