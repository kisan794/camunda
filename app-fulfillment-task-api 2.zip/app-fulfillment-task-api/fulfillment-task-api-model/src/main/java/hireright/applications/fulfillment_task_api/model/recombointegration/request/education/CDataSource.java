package hireright.applications.fulfillment_task_api.model.recombointegration.request.education;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

/**
 * Data Source DTO for screening data source information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"name", "type", "screenings"})
public class CDataSource {

    @JsonProperty("name")
    private String m_sName;

    @JsonProperty("type")
    private String m_sType;

    @JsonProperty("screenings")
    private List<CScreening> m_screening;

    private CDataSource() {
    }

    public CDataSource(Builder builder) {
        m_sName = builder.m_sName;
        m_sType = builder.m_sType;
        m_screening = builder.m_screening;
    }

    public String getName() {
        return m_sName;
    }

    public String getType() {
        return m_sType;
    }

    public List<CScreening> getScreening() {
        return m_screening;
    }

    public static final class Builder {

        private String m_sName;
        private String m_sType;
        private List<CScreening> m_screening;

        public Builder() {
        }

        public Builder name(String name) {
            m_sName = name;
            return this;
        }

        public Builder type(String type) {
            m_sType = type;
            return this;
        }

        public Builder screening(List<CScreening> screening) {
            m_screening = screening;
            return this;
        }

        public CDataSource build() {
            return new CDataSource(this);
        }
    }
}

