package hireright.applications.fulfillment_task_api.model.recombointegration.listener;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-10  Created
 */

/**
 * @author mkuznetsov
 */
public record Domain(
        String id
) {}