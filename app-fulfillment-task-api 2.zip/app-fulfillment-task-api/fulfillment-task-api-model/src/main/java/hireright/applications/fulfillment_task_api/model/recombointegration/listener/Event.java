package hireright.applications.fulfillment_task_api.model.recombointegration.listener;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-10  Created
 */

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import java.util.List;

/**
 * @author mkuznetsov
 */
public record Event(
        String version,
        String id,
        String typeID,
        @JacksonXmlProperty (localName = "Domain") Domain domain,
        String eventDate,
        @JacksonXmlProperty(localName = "Parameters") List<Parameter> parameters
) {}
