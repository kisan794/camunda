package hireright.applications.fulfillment_task_api.model.recombointegration.request.employment;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Compensation Info DTO for salary and pay information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"currency", "rateOfPay", "averageHoursPerPayPeriod", "dateOfPayIncreaseLast",
        "amountOfPayIncreaseLast", "dateOfPayIncreaseNext", "amountOfPayIncreaseNext"})
public class CCompensationInfo {

    @JsonProperty("currency")
    private String m_sCurrency;

    @JsonProperty("rateOfPay")
    private String m_sRateOfPay;

    @JsonProperty("averageHoursPerPayPeriod")
    private String m_sAverageHoursPerPayPeriod;

    @JsonProperty("dateOfPayIncreaseLast")
    private String m_sDateOfPayIncreaseLast;

    @JsonProperty("amountOfPayIncreaseLast")
    private String m_sAmountOfPayIncreaseLast;

    @JsonProperty("dateOfPayIncreaseNext")
    private String m_sDateOfPayIncreaseNext;

    @JsonProperty("amountOfPayIncreaseNext")
    private String m_sAmountOfPayIncreaseNext;

    private CCompensationInfo() {
    }

    private CCompensationInfo(Builder builder) {
        m_sCurrency = builder.m_sCurrency;
        m_sRateOfPay = builder.m_sRateOfPay;
        m_sAverageHoursPerPayPeriod = builder.m_sAverageHoursPerPayPeriod;
        m_sDateOfPayIncreaseLast = builder.m_sDateOfPayIncreaseLast;
        m_sAmountOfPayIncreaseLast = builder.m_sAmountOfPayIncreaseLast;
        m_sDateOfPayIncreaseNext = builder.m_sDateOfPayIncreaseNext;
        m_sAmountOfPayIncreaseNext = builder.m_sAmountOfPayIncreaseNext;
    }

    public String getCurrency() {
        return m_sCurrency;
    }

    public String getRateOfPay() {
        return m_sRateOfPay;
    }

    public String getAverageHoursPerPayPeriod() {
        return m_sAverageHoursPerPayPeriod;
    }

    public String getDateOfPayIncreaseLast() {
        return m_sDateOfPayIncreaseLast;
    }

    public String getAmountOfPayIncreaseLast() {
        return m_sAmountOfPayIncreaseLast;
    }

    public String getDateOfPayIncreaseNext() {
        return m_sDateOfPayIncreaseNext;
    }

    public String getAmountOfPayIncreaseNext() {
        return m_sAmountOfPayIncreaseNext;
    }

    public static final class Builder {

        private String m_sCurrency;
        private String m_sRateOfPay;
        private String m_sAverageHoursPerPayPeriod;
        private String m_sDateOfPayIncreaseLast;
        private String m_sAmountOfPayIncreaseLast;
        private String m_sDateOfPayIncreaseNext;
        private String m_sAmountOfPayIncreaseNext;

        public Builder() {
        }

        public Builder currency(String sCurrency) {
            m_sCurrency = sCurrency;
            return this;
        }

        public Builder rateOfPay(String sRateOfPay) {
            m_sRateOfPay = sRateOfPay;
            return this;
        }

        public Builder averageHoursPerPayPeriod(String sAverageHoursPerPayPeriod) {
            m_sAverageHoursPerPayPeriod = sAverageHoursPerPayPeriod;
            return this;
        }

        public Builder dateOfPayIncreaseLast(String sDateOfPayIncreaseLast) {
            m_sDateOfPayIncreaseLast = sDateOfPayIncreaseLast;
            return this;
        }

        public Builder amountOfPayIncreaseLast(String sAmountOfPayIncreaseLast) {
            m_sAmountOfPayIncreaseLast = sAmountOfPayIncreaseLast;
            return this;
        }

        public Builder dateOfPayIncreaseNext(String sDateOfPayIncreaseNext) {
            m_sDateOfPayIncreaseNext = sDateOfPayIncreaseNext;
            return this;
        }

        public Builder amountOfPayIncreaseNext(String sAmountOfPayIncreaseNext) {
            m_sAmountOfPayIncreaseNext = sAmountOfPayIncreaseNext;
            return this;
        }

        public CCompensationInfo build() {
            return new CCompensationInfo(this);
        }
    }
}

