package hireright.applications.fulfillment_task_api.model.recombointegration.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"specversion", "id", "source", "type", "datacontenttype", "time", "dataschema", "data"})
public abstract class CDataRequest<DATA> {

    @JsonProperty("specversion")
    protected String m_sSpecVersion;

    @JsonProperty("id")
    protected String m_sId;

    @JsonProperty("source")
    protected String m_sSource;

    @JsonProperty("type")
    protected String m_sType;

    @JsonProperty("datacontenttype")
    protected String m_sDataContentType;

    @JsonProperty("time")
    protected String m_sTime;

    @JsonProperty("dataschema")
    protected String m_sDataSchema;

    @JsonProperty("data")
    protected DATA m_data;

    @JsonIgnore
    public String getSpecVersion() {
        return m_sSpecVersion;
    }

    public String getId() {
        return m_sId;
    }

    public String getSource() {
        return m_sSource;
    }

    public String getType() {
        return m_sType;
    }

    @JsonIgnore
    public String getDataContentType() {
        return m_sDataContentType;
    }

    public String getTime() {
        return m_sTime;
    }

    @JsonIgnore
    public String getDataSchema() {
        return m_sDataSchema;
    }
}
