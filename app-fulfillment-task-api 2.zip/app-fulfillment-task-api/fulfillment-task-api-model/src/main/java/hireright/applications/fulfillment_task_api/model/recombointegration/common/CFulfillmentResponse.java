package hireright.applications.fulfillment_task_api.model.recombointegration.common;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"status", "message"})
public class CFulfillmentResponse {

    @JsonProperty("status")
    private String m_sStatus;

    @JsonProperty("message")
    private String m_sMessage;

    private CFulfillmentResponse() {
    }

    private CFulfillmentResponse(Builder builder) {
        m_sStatus = builder.m_sStatus;
        m_sMessage = builder.m_sMessage;
    }

    public String getStatus() {
        return m_sStatus;
    }

    public String getMessage() {
        return m_sMessage;
    }

    public static final class Builder {

        private String m_sStatus;
        private String m_sMessage;

        public Builder() {
        }

        public Builder status(String sStatus) {
            m_sStatus = sStatus;
            return this;
        }

        public Builder message(String sMessage) {
            m_sMessage = sMessage;
            return this;
        }

        public CFulfillmentResponse build() {
            return new CFulfillmentResponse(this);
        }
    }
}
