package hireright.applications.fulfillment_task_api.model.recombointegration.common;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"audit"})
public class CPropertiesRequest {

    @JsonProperty("audit")
    private boolean m_audit;

    private CPropertiesRequest() {
    }

    private CPropertiesRequest(Builder builder) {
        m_audit = builder.m_audit;
    }

    public boolean isAudit() {
        return m_audit;
    }

    public static final class Builder {

        private boolean m_audit;

        public Builder() {
        }

        public Builder audit(boolean audit) {
            m_audit = audit;
            return this;
        }

        public CPropertiesRequest build() {
            return new CPropertiesRequest(this);
        }
    }
}