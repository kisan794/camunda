package hireright.applications.fulfillment_task_api.model.recombointegration.listener;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-10  Created
 */

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;

/**
 * @author mkuznetsov
 */
public class Parameter {
    @JacksonXmlProperty(isAttribute = true, localName = "name") String name;
    @JacksonXmlText String value;

    public String getValue() {
        return this.value;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
