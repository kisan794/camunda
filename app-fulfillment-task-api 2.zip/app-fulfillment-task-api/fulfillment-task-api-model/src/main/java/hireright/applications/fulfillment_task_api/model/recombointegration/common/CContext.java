package hireright.applications.fulfillment_task_api.model.recombointegration.common;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CClient;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CContextRequest;

@JsonPropertyOrder({"client", "product", "request", "guidelines"})
public class CContext {

    @JsonProperty("client")
    private CClient m_client;

    @JsonProperty("product")
    private CProduct m_product;

    @JsonProperty("request")
    private CContextRequest m_request;

    @JsonProperty("guidelines")
    private CGuidelines m_guidelines;

    private CContext() {
    }

    private CContext(Builder builder) {
        m_client = builder.m_client;
        m_product = builder.m_product;
        m_request = builder.m_request;
        m_guidelines = builder.m_guidelines;
    }

    public CClient getClient() {
        return m_client;
    }

    public CProduct getProduct() {
        return m_product;
    }

    public CContextRequest getRequest() {
        return m_request;
    }

    public CGuidelines getGuidelines() {
        return m_guidelines;
    }

    public static final class Builder {

        private CClient m_client;
        private CProduct m_product;
        private CContextRequest m_request;
        private CGuidelines m_guidelines;

        public Builder() {
        }

        public Builder client(CClient client) {
            m_client = client;
            return this;
        }

        public Builder product(CProduct product) {
            m_product = product;
            return this;
        }

        public Builder request(CContextRequest request) {
            m_request = request;
            return this;
        }

        public Builder guidelines(CGuidelines guidelines) {
            m_guidelines = guidelines;
            return this;
        }

        public CContext build() {
            return new CContext(this);
        }
    }
}