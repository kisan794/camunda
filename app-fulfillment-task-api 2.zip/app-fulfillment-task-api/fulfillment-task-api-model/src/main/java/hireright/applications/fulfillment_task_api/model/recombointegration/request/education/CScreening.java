package hireright.applications.fulfillment_task_api.model.recombointegration.request.education;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Screening DTO for screening service information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"serviceId", "hrSchoolId", "nschSchoolId", "contact", "institution"})
public class CScreening {

    @JsonProperty("serviceId")
    private String m_sServiceId;

    @JsonProperty("hrSchoolId")
    private String m_sHrSchoolId;

    @JsonProperty("nschSchoolId")
    private String m_sNschSchoolId;

    @JsonProperty("contact")
    private CContact m_contact;

    @JsonProperty("institution")
    private CScreeningInstitution m_institution;

    private CScreening() {
    }

    public CScreening(Builder builder) {
        m_sServiceId = builder.m_sServiceId;
        m_sHrSchoolId = builder.m_sHrSchoolId;
        m_sNschSchoolId = builder.m_sNschSchoolId;
        m_contact = builder.m_contact;
        m_institution = builder.m_institution;
    }

    public String getServiceId() {
        return m_sServiceId;
    }

    public String getHrSchoolId() {
        return m_sHrSchoolId;
    }

    public String getNschSchoolId() {
        return m_sNschSchoolId;
    }

    public CContact getContact() {
        return m_contact;
    }

    public CScreeningInstitution getInstitution() {
        return m_institution;
    }

    public static final class Builder {

        private String m_sServiceId;
        private String m_sHrSchoolId;
        private String m_sNschSchoolId;
        private CContact m_contact;
        private CScreeningInstitution m_institution;

        public Builder() {
        }

        public Builder serviceId(String sServiceId) {
            m_sServiceId = sServiceId;
            return this;
        }

        public Builder hrSchoolId(String sHrSchoolId) {
            m_sHrSchoolId = sHrSchoolId;
            return this;
        }

        public Builder nschSchoolId(String sNschSchoolId) {
            m_sNschSchoolId = sNschSchoolId;
            return this;
        }

        public Builder contact(CContact contact) {
            m_contact = contact;
            return this;
        }

        public Builder institution(CScreeningInstitution institution) {
            m_institution = institution;
            return this;
        }

        public CScreening build() {
            return new CScreening(this);
        }
    }
}

