package hireright.applications.fulfillment_task_api.model.recombointegration.request.employment;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Employment Reference Object DTO for related order items
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"type", "id", "organization"})
public class CReferenceObjects {

    @JsonProperty("type")
    private String m_sType;

    @JsonProperty("id")
    private String m_sId;

    @JsonProperty("organization")
    private COrganization m_organization;

    private CReferenceObjects() {
    }

    private CReferenceObjects(Builder builder) {
        m_sType = builder.m_sType;
        m_sId = builder.m_sId;
        m_organization = builder.m_organization;
    }

    public String getType() {
        return m_sType;
    }

    public String getId() {
        return m_sId;
    }

    public COrganization getOrganization() {
        return m_organization;
    }

    public static final class Builder {

        private String m_sType;
        private String m_sId;
        private COrganization m_organization;

        public Builder() {
        }

        public Builder type(String sType) {
            m_sType = sType;
            return this;
        }

        public Builder id(String sId) {
            m_sId = sId;
            return this;
        }

        public Builder organization(COrganization organization) {
            m_organization = organization;
            return this;
        }

        public CReferenceObjects build() {
            return new CReferenceObjects(this);
        }
    }
}
