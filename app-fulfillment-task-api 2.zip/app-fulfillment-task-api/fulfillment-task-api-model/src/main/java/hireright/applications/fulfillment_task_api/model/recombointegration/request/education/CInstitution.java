package hireright.applications.fulfillment_task_api.model.recombointegration.request.education;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CLocation;

@JsonPropertyOrder({"name", "location", "qualifications", "permissionToContact", "spokeWith"})
public class CInstitution {

    @JsonProperty("name")
    private String m_sName;

    @JsonProperty("location")
    private CLocation m_location;

    @JsonProperty("qualifications")
    private CQualification m_qualifications;

    @JsonProperty("permissionToContact")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private boolean m_permissionToContact;

    @JsonProperty("spokeWith")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String m_sSpokeWith;

    private CInstitution() {
    }

    public CInstitution(Builder builder) {
        m_sName = builder.m_sName;
        m_location = builder.m_location;
        m_qualifications = builder.m_qualifications;
        m_permissionToContact = builder.m_permissionToContact;
        m_sSpokeWith = builder.m_sSpokeWith;
    }

    public String getName() {
        return m_sName;
    }

    public CLocation getLocation() {
        return m_location;
    }

    public CQualification getQualifications() {
        return m_qualifications;
    }

    public boolean isPermissionToContact() {
        return m_permissionToContact;
    }

    public String getSpokeWith() {
        return m_sSpokeWith;
    }

    public static final class Builder {

        private String m_sName;
        private CLocation m_location;
        private CQualification m_qualifications;
        private boolean m_permissionToContact;
        private String m_sSpokeWith;

        public Builder() {
        }

        public Builder name(String name) {
            m_sName = name;
            return this;
        }

        public Builder location(CLocation location) {
            m_location = location;
            return this;
        }

        public Builder qualifications(CQualification qualifications) {
            m_qualifications = qualifications;
            return this;
        }

        public Builder permissionToContact(boolean permissionToContact) {
            m_permissionToContact = permissionToContact;
            return this;
        }

        public Builder spokeWith(String spokeWith) {
            m_sSpokeWith = spokeWith;
            return this;
        }

        public CInstitution build() {
            return new CInstitution(this);
        }
    }
}

