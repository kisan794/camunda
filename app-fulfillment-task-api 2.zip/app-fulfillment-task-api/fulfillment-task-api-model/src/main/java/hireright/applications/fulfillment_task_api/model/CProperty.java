package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-26  ATS-1045 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Objects;

public class CProperty implements Serializable {
    @JsonProperty("name")
    private String m_sName;

    @JsonProperty("value")
    private String m_sValue;

    private CProperty() {
    }

    public CProperty(String sName, String sValue) {
        this.m_sName = sName;
        this.m_sValue = sValue;
    }

    private CProperty(Builder builder) {
        this.m_sName = builder.m_sName;
        this.m_sValue = builder.m_sValue;
    }

    public String getName() {
        return this.m_sName;
    }

    public String getValue() {
        return this.m_sValue;
    }

    @Override
    public String toString() {
        return "CProperty{" + "m_sName='" + this.m_sName + '\'' + ", m_sValue='" + this.m_sValue + '\'' + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CProperty cProperty = (CProperty) o;

        if (!Objects.equals(this.m_sName, cProperty.m_sName)) {
            return false;
        }
        return Objects.equals(this.m_sValue, cProperty.m_sValue);
    }

    @Override
    public int hashCode() {
        int result = this.m_sName != null ? this.m_sName.hashCode() : 0;
        result = 31 * result + (this.m_sValue != null ? this.m_sValue.hashCode() : 0);
        return result;
    }

    public enum EField {
        NAME("name");

        private final String m_sValue;

        EField(String sValue) {
            this.m_sValue = sValue;
        }

        public static EField fromValue(String text) {
            if (text == null || text.trim().isEmpty()) {
                return null;
            }

            for (EField entry : values()) {
                if (entry.m_sValue.equalsIgnoreCase(text)) {
                    return entry;
                }
            }

            return null;
        }
    }

    public static final class Builder {
        private String m_sName;
        private String m_sValue;

        public Builder() {
        }

        public Builder(CProperty copy) {
            if (copy == null) {
                return;
            }

            this.m_sName = copy.getName();
            this.m_sValue = copy.getValue();
        }

        public Builder name(String sName) {
            this.m_sName = sName;
            return this;
        }

        public Builder value(String sValue) {
            this.m_sValue = sValue;
            return this;
        }

        public CProperty build() {
            return new CProperty(this);
        }
    }
}
