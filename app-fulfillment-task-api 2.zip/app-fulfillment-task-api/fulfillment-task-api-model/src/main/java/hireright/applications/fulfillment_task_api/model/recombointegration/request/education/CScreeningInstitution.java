package hireright.applications.fulfillment_task_api.model.recombointegration.request.education;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

/**
 * Screening Institution DTO for institution programs in screening data
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"name", "programs"})
public class CScreeningInstitution {

    @JsonProperty("name")
    private String m_sName;

    @JsonProperty("programs")
    private List<CProgram> m_programs;

    private CScreeningInstitution() {
    }

    public CScreeningInstitution(Builder builder) {
        m_sName = builder.m_sName;
        m_programs = builder.m_programs;
    }

    public String getName() {
        return m_sName;
    }

    public List<CProgram> getPrograms() {
        return m_programs;
    }

    public static final class Builder {

        private String m_sName;
        private List<CProgram> m_programs;

        public Builder() {
        }

        public Builder name(String name) {
            m_sName = name;
            return this;
        }

        public Builder programs(List<CProgram> programs) {
            m_programs = programs;
            return this;
        }

        public CScreeningInstitution build() {
            return new CScreeningInstitution(this);
        }
    }
}
