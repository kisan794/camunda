package hireright.applications.fulfillment_task_api.model.recombointegration.common;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Employment Location DTO for organization location information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"city", "region", "country", "postalCode"})
public class CLocation {

    @JsonProperty("city")
    private String m_sCity;

    @JsonProperty("region")
    private String m_sRegion;

    @JsonProperty("country")
    private String m_sCountry;

    @JsonProperty("postalCode")
    private String m_sPostalCode;

    private CLocation() {
    }

    private CLocation(Builder builder) {
        m_sCity = builder.m_sCity;
        m_sRegion = builder.m_sRegion;
        m_sCountry = builder.m_sCountry;
        m_sPostalCode = builder.m_sPostalCode;
    }

    public String getCity() {
        return m_sCity;
    }

    public String getRegion() {
        return m_sRegion;
    }

    public String getCountry() {
        return m_sCountry;
    }

    public String getPostalCode() {
        return m_sPostalCode;
    }

    public static final class Builder {

        private String m_sCity;
        private String m_sRegion;
        private String m_sCountry;
        private String m_sPostalCode;

        public Builder() {
        }

        public Builder city(String sCity) {
            m_sCity = sCity;
            return this;
        }

        public Builder region(String sRegion) {
            m_sRegion = sRegion;
            return this;
        }

        public Builder country(String sCountry) {
            m_sCountry = sCountry;
            return this;
        }

        public Builder postalCode(String sPostalCode) {
            m_sPostalCode = sPostalCode;
            return this;
        }

        public CLocation build() {
            return new CLocation(this);
        }
    }
}
