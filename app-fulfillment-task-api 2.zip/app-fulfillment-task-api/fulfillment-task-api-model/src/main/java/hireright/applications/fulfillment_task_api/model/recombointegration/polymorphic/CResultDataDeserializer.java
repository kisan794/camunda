package hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

/**
 * Custom deserializer for BaseResultData that automatically determines the concrete type
 * based on the presence of specific fields in the JSON payload.
 * <p>
 * Detection logic:
 * - If "employerOrgName" field is present → EmploymentResultData
 * - If "institutionName" field is present → EducationResultData
 * - Otherwise → defaults to EmploymentResultData
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class CResultDataDeserializer extends JsonDeserializer<CBaseResultData> {

    private static final String EMPLOYER_ORG_NAME_FIELD = "employerOrgName";
    private static final String INSTITUTION_NAME_FIELD = "institutionName";
    private static final String POSITION_HISTORY_FIELD = "positionHistory";
    private static final String QUALIFICATIONS_FIELD = "qualifications";
    private static final String CITY_FIELD = "city";
    private static final String REGION_FIELD = "region";
    private static final String COUNTRY_FIELD = "country";

    @Override
    public CBaseResultData deserialize(JsonParser parser, DeserializationContext context)
            throws IOException {

        ObjectMapper mapper = (ObjectMapper) parser.getCodec();
        JsonNode node = mapper.readTree(parser);

        // Extract common fields
        String city = node.has(CITY_FIELD) ? node.get(CITY_FIELD).asText() : null;
        String region = node.has(REGION_FIELD) ? node.get(REGION_FIELD).asText() : null;
        String country = node.has(COUNTRY_FIELD) ? node.get(COUNTRY_FIELD).asText() : null;

        // Determine the type based on the presence of specific fields
        if (node.has(EMPLOYER_ORG_NAME_FIELD) || node.has(POSITION_HISTORY_FIELD)) {
            return getEmploymentResultData(city, region, country, node, mapper);
        } else if (node.has(INSTITUTION_NAME_FIELD) || node.has(QUALIFICATIONS_FIELD)) {
            return getEducationResultData(city, region, country, node, mapper);
        } else {
            // Default to employment if neither field is present
            return new CEmploymentResultData.Builder()
                    .city(city)
                    .region(region)
                    .country(country)
                    .build();
        }
    }

    private static CEducationResultData getEducationResultData(
            String city, String region, String country, JsonNode node, ObjectMapper mapper) throws JsonProcessingException {
        // Education result
        CEducationResultData education = new CEducationResultData.Builder()
                .city(city)
                .region(region)
                .country(country)
                .institutionName(node.has(INSTITUTION_NAME_FIELD)
                        ? node.get(INSTITUTION_NAME_FIELD).asText() : null)
                .build();

        getQualificationData(node, mapper, education);
        return education;
    }

    private static void getQualificationData(JsonNode node, ObjectMapper mapper, CEducationResultData education)
            throws JsonProcessingException {
        // Deserialize qualifications if present
        if (node.has(QUALIFICATIONS_FIELD)) {
            CEducationQualifications qualifications = mapper.treeToValue(
                    node.get(QUALIFICATIONS_FIELD),
                    CEducationQualifications.class
            );
            education.setQualifications(qualifications);
        }
    }

    private static CEmploymentResultData getEmploymentResultData(
            String city, String region, String country, JsonNode node, ObjectMapper mapper) throws JsonProcessingException {
        CEmploymentResultData employment = new CEmploymentResultData.Builder()
                .city(city)
                .region(region)
                .country(country)
                .employerOrgName(node.has(EMPLOYER_ORG_NAME_FIELD)
                        ? node.get(EMPLOYER_ORG_NAME_FIELD).asText() : null)
                .build();

        getPositionHistory(node, mapper, employment);
        return employment;
    }

    private static void getPositionHistory(
            JsonNode node, ObjectMapper mapper, CEmploymentResultData employment) throws JsonProcessingException {
        // Deserialize position history if present
        if (node.has(POSITION_HISTORY_FIELD)) {
            CPositionHistory positionHistory = mapper.treeToValue(
                    node.get(POSITION_HISTORY_FIELD),
                    CPositionHistory.class);
            employment.setPositionHistory(positionHistory);
        }
    }
}
