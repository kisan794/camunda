/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

/**
 * Abstract base class for result data supporting polymorphic deserialization.
 * This enables type-safe handling of both Employment and Education verification results.
 * <p>
 * The type is determined automatically by the presence of specific fields in the JSON:
 * - If "employerOrgName" is present → EmploymentResultData
 * - If "institutionName" is present → EducationResultData
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonDeserialize(using = CResultDataDeserializer.class)
@JsonPropertyOrder({"city", "region", "country"})
public abstract class CBaseResultData {

    /**
     * Common fields for both employment and education results
     */
    @JsonProperty("city")
    protected String m_sCity;

    @JsonProperty("region")
    protected String m_sRegion;

    @JsonProperty("country")
    protected String m_sCountry;

    public String getCity() {
        return m_sCity;
    }

    public String getRegion() {
        return m_sRegion;
    }

    public String getCountry() {
        return m_sCountry;
    }
}

