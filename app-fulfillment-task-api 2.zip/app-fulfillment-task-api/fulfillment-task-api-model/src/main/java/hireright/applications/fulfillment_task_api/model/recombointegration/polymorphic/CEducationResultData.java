package hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * Education-specific result data for education verification results.
 * Contains institution information and qualifications.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonTypeName("EDUCATION")
@JsonPropertyOrder({"city", "region", "country", "institutionName", "qualifications"})
public class CEducationResultData extends CBaseResultData {

    /**
     * Education-specific fields
     */
    @JsonProperty("institutionName")
    private String m_sInstitutionName;

    @JsonProperty("qualifications")
    private CEducationQualifications m_qualifications;

    private CEducationResultData() {
    }

    private CEducationResultData(Builder builder) {
        m_sCity = builder.m_sCity;
        m_sRegion = builder.m_sRegion;
        m_sCountry = builder.m_sCountry;
        m_sInstitutionName = builder.m_sInstitutionName;
        m_qualifications = builder.m_qualifications;
    }

    public String getInstitutionName() {
        return m_sInstitutionName;
    }

    public CEducationQualifications getQualifications() {
        return m_qualifications;
    }

    public void setQualifications(CEducationQualifications m_qualifications) {
        this.m_qualifications = m_qualifications;
    }

    public static class Builder {

        private String m_sCity;
        private String m_sRegion;
        private String m_sCountry;
        private String m_sInstitutionName;
        private CEducationQualifications m_qualifications;

        public Builder() {
        }

        public Builder city(String sCity) {
            this.m_sCity = sCity;
            return this;
        }

        public Builder region(String sRegion) {
            this.m_sRegion = sRegion;
            return this;
        }

        public Builder country(String sCountry) {
            this.m_sCountry = sCountry;
            return this;
        }

        public Builder institutionName(String sInstitutionName) {
            m_sInstitutionName = sInstitutionName;
            return this;
        }

        public Builder qualifications(CEducationQualifications qualifications) {
            m_qualifications = qualifications;
            return this;
        }

        public CEducationResultData build() {
            return new CEducationResultData(this);
        }
    }
}

