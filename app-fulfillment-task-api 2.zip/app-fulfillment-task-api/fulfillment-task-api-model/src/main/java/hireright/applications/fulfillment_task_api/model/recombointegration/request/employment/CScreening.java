package hireright.applications.fulfillment_task_api.model.recombointegration.request.employment;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Employment Screening DTO for screening service information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"sourceReference", "employerOrgName", "city", "region", "country", "positionHistory"})
public class CScreening {

    @JsonProperty("sourceReference")
    private String m_sSourceReference;

    @JsonProperty("employerOrgName")
    private String m_sEmployerOrgName;

    @JsonProperty("city")
    private String m_sCity;

    @JsonProperty("region")
    private String m_sRegion;

    @JsonProperty("country")
    private String m_sCountry;

    @JsonProperty("positionHistory")
    private CPositionHistory m_positionHistory;

    private CScreening() {
    }

    private CScreening(Builder builder) {
        m_sSourceReference = builder.m_sSourceReference;
        m_sEmployerOrgName = builder.m_sEmployerOrgName;
        m_sCity = builder.m_sCity;
        m_sRegion = builder.m_sRegion;
        m_sCountry = builder.m_sCountry;
        m_positionHistory = builder.m_positionHistory;
    }

    public String getSourceReference() {
        return m_sSourceReference;
    }

    public String getEmployerOrgName() {
        return m_sEmployerOrgName;
    }

    public String getCity() {
        return m_sCity;
    }

    public String getRegion() {
        return m_sRegion;
    }

    public String getCountry() {
        return m_sCountry;
    }

    public CPositionHistory getPositionHistory() {
        return m_positionHistory;
    }

    public static final class Builder {

        private String m_sSourceReference;
        private String m_sEmployerOrgName;
        private String m_sCity;
        private String m_sRegion;
        private String m_sCountry;
        private CPositionHistory m_positionHistory;

        public Builder() {
        }

        public Builder sourceReference(String sSourceReference) {
            m_sSourceReference = sSourceReference;
            return this;
        }

        public Builder employerOrgName(String sEmployerOrgName) {
            m_sEmployerOrgName = sEmployerOrgName;
            return this;
        }

        public Builder city(String sCity) {
            m_sCity = sCity;
            return this;
        }

        public Builder region(String sRegion) {
            m_sRegion = sRegion;
            return this;
        }

        public Builder country(String sCountry) {
            m_sCountry = sCountry;
            return this;
        }

        public Builder positionHistory(CPositionHistory positionHistory) {
            m_positionHistory = positionHistory;
            return this;
        }

        public CScreening build() {
            return new CScreening(this);
        }
    }
}