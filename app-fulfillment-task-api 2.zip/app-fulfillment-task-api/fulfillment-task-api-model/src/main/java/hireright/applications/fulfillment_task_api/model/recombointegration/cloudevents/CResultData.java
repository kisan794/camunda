package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CPropertiesResponse;
import hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic.CBaseResultData;

/**
 * Task result data containing decision and result information with polymorphic result data.
 * Supports both Employment and Education verification results through type-safe polymorphism.
 * <p>
 * The resultData field will be deserialized as either:
 * - EmploymentResultData (for employment verification)
 * - EducationResultData (for education verification)
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"decision", "reviewScore", "decisionDescription"})
public class CResultData {

    @JsonProperty("decision")
    private String m_sDecision;

    @JsonProperty("reviewScore")
    private Double m_nReviewScore;

    @JsonProperty("decisionDescription")
    private String m_sDecisionDescription;

    /**
     * Source reference - only populated for employment verification results.
     * This field will be ignored (not serialized) when null for education results.
     */
    @JsonProperty("")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String m_sSourceReference;

    @JsonProperty("")
    private CPropertiesResponse m_properties;

    /**
     * Polymorphic result data - will be deserialized as either:
     * - EmploymentResultData (for employment verification)
     * - EducationResultData (for education verification)
     */
    @JsonProperty("resultData")
    private CBaseResultData m_resultData;

    private CResultData() {
    }

    public CResultData(Builder builder) {
        m_sDecision = builder.m_sDecision;
        m_nReviewScore = builder.m_nReviewScore;
        m_sDecisionDescription = builder.m_sDecisionDescription;
        m_sSourceReference = builder.m_sSourceReference;
        m_properties = builder.m_properties;
        m_resultData = builder.m_resultData;
    }

    public String getDecision() {
        return m_sDecision;
    }

    public Double getReviewScore() {
        return m_nReviewScore;
    }

    public String getDecisionDescription() {
        return m_sDecisionDescription;
    }

    public String getSourceReference() {
        return m_sSourceReference;
    }

    public CPropertiesResponse getProperties() {
        return m_properties;
    }

    public CBaseResultData getResultData() {
        return m_resultData;
    }

    public static final class Builder {

        private String m_sDecision;
        private Double m_nReviewScore;
        private String m_sDecisionDescription;
        private String m_sSourceReference;
        private CPropertiesResponse m_properties;
        private CBaseResultData m_resultData;

        public Builder() {
        }

        public Builder decision(String m_sDecision) {
            this.m_sDecision = m_sDecision;
            return this;
        }

        public Builder reviewScore(Double m_nReviewScore) {
            this.m_nReviewScore = m_nReviewScore;
            return this;
        }

        public Builder decisionDescription(String m_sDecisionDescription) {
            this.m_sDecisionDescription = m_sDecisionDescription;
            return this;
        }

        public Builder sourceReference(String m_sSourceReference) {
            this.m_sSourceReference = m_sSourceReference;
            return this;
        }

        public Builder properties(CPropertiesResponse m_properties) {
            this.m_properties = m_properties;
            return this;
        }

        public Builder resultData(CBaseResultData m_resultData) {
            this.m_resultData = m_resultData;
            return this;
        }

        public CResultData build() {
            return new CResultData(this);
        }
    }
}
