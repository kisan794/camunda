package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * CloudEvents format request for task results
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"specversion", "id", "source", "type", "datacontenttype", "dataschema", "data"})
public class CResultRequest {

    @JsonProperty("specversion")
    private String m_sSpecVersion;

    @JsonProperty("id")
    private String m_sId;

    @JsonProperty("source")
    private String m_sSource;

    @JsonProperty("type")
    private String m_sType;

    @JsonProperty("datacontenttype")
    private String m_sDataContentType;

    @JsonProperty("dataschema")
    private String m_sDataSchema;

    @JsonProperty("data")
    private CResultData m_data;

    private CResultRequest() {
    }

    public CResultRequest(Builder builder) {
        this.m_sSpecVersion = builder.m_sSpecVersion;
        this.m_sId = builder.m_sId;
        this.m_sSource = builder.m_sSource;
        this.m_sType = builder.m_sType;
        this.m_sDataContentType = builder.m_sDataContentType;
        this.m_sDataSchema = builder.m_sDataSchema;
        this.m_data = builder.m_data;
    }

    @JsonIgnore
    public String getSpecVersion() {
        return m_sSpecVersion;
    }

    public String getId() {
        return m_sId;
    }

    public String getSource() {
        return m_sSource;
    }

    public String getType() {
        return m_sType;
    }

    @JsonIgnore
    public String getDataContentType() {
        return m_sDataContentType;
    }

    @JsonIgnore
    public String getDataSchema() {
        return m_sDataSchema;
    }

    public CResultData getData() {
        return m_data;
    }

    public static final class Builder {

        private String m_sSpecVersion;
        private String m_sId;
        private String m_sSource;
        private String m_sType;
        private String m_sDataContentType;
        private String m_sDataSchema;
        private CResultData m_data;

        public Builder() {
        }

        public Builder specVersion(String sSpecVersion) {
            m_sSpecVersion = sSpecVersion;
            return this;
        }

        public Builder id(String sId) {
            m_sId = sId;
            return this;
        }

        public Builder source(String sSource) {
            m_sSource = sSource;
            return this;
        }

        public Builder type(String sType) {
            m_sType = sType;
            return this;
        }

        public Builder dataContentType(String sDataContentType) {
            m_sDataContentType = sDataContentType;
            return this;
        }

        public Builder dataSchema(String sDataSchema) {
            m_sDataSchema = sDataSchema;
            return this;
        }

        public Builder data(CResultData data) {
            m_data = data;
            return this;
        }

        public CResultRequest build() {
            return new CResultRequest(this);
        }
    }
}

