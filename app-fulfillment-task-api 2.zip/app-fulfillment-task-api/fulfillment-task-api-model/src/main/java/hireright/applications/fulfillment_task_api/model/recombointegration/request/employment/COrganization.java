package hireright.applications.fulfillment_task_api.model.recombointegration.request.employment;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CLocation;

/**
 * Organization DTO for employer organization information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"name", "location", "position"})
public class COrganization {

    @JsonProperty("name")
    private String m_sName;

    @JsonProperty("location")
    private CLocation m_location;

    @JsonProperty("position")
    private CPosition m_position;

    private COrganization() {
    }

    private COrganization(Builder builder) {
        m_sName = builder.m_sName;
        m_location = builder.m_location;
        m_position = builder.m_position;
    }

    public String getName() {
        return m_sName;
    }

    public CLocation getLocation() {
        return m_location;
    }

    public CPosition getPosition() {
        return m_position;
    }

    public static final class Builder {

        private String m_sName;
        private CLocation m_location;
        private CPosition m_position;

        public Builder() {
        }

        public Builder name(String sName) {
            m_sName = sName;
            return this;
        }

        public Builder location(CLocation location) {
            m_location = location;
            return this;
        }

        public Builder position(CPosition position) {
            m_position = position;
            return this;
        }

        public COrganization build() {
            return new COrganization(this);
        }
    }
}
