package hireright.applications.fulfillment_task_api.rest.recombointegration.retry;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import hireright.applications.fulfillment_task_api.rest.recombointegration.model.MessageMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;

/**
 * Service for publishing failed messages to retry queues or DLQ.
 * Manages retry logic and message routing based on retry count.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Service
public class RetryMessagePublisher {

    private static final Logger LOG = LoggerFactory.getLogger(RetryMessagePublisher.class);

    private final RabbitTemplate rabbitTemplate;

    @Value("${rabbitmq.exchange}")
    private String exchange;

    @Value("${rabbitmq.routing.retry-1}")
    private String retry1Key;

    @Value("${rabbitmq.routing.retry-2}")
    private String retry2Key;

    @Value("${rabbitmq.routing.retry-3}")
    private String retry3Key;

    @Value("${rabbitmq.routing.screening-dlq}")
    private String dlqKey;

    @Value("${rabbitmq.retry.max-attempts:3}")
    private int maxRetryAttempts;

    @Value("${rabbitmq.queue.screening-requests}")
    private String mainQueue;

    public RetryMessagePublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    /**
     * Publish a failed message to the appropriate retry queue or DLQ.
     *
     * @param originalMessage the original message that failed
     * @param failureReason   the reason for failure
     * @param taskId          the task ID for tracking
     */
    public void publishForRetry(Message originalMessage, String failureReason, String taskId) {
        MessageMetadata metadata = extractMetadata(originalMessage);
        metadata.incrementRetryCount();
        metadata.setLastFailureTime(Instant.now());
        metadata.setLastFailureReason(failureReason);
        metadata.setTaskId(taskId);

        if (metadata.getFirstFailureTime() == null) {
            metadata.setFirstFailureTime(Instant.now());
        }

        if (metadata.getOriginalQueue() == null) {
            metadata.setOriginalQueue(mainQueue);
        }

        int retryCount = metadata.getRetryCount();

        if (retryCount > maxRetryAttempts) {
            // Send to DLQ after max retries exceeded
            publishToDLQ(originalMessage, metadata);
        } else {
            // Send to appropriate retry queue
            publishToRetryQueue(originalMessage, metadata, retryCount);
        }
    }

    /**
     * Publish message to the appropriate retry queue based on retry count.
     *
     * @param originalMessage the original message
     * @param metadata        message metadata
     * @param retryCount      current retry count
     */
    private void publishToRetryQueue(Message originalMessage, MessageMetadata metadata, int retryCount) {
        String routingKey;
        String queueName;

        switch (retryCount) {
            case 1:
                routingKey = retry1Key;
                queueName = "R1Q";
                break;
            case 2:
                routingKey = retry2Key;
                queueName = "R2Q";
                break;
            case 3:
                routingKey = retry3Key;
                queueName = "R3Q";
                break;
            default:
                LOG.error("Unexpected retry count: {}. Sending to DLQ.", retryCount);
                publishToDLQ(originalMessage, metadata);
                return;
        }

        Message retryMessage = buildMessageWithMetadata(originalMessage, metadata);

        LOG.info("Publishing message to {} (attempt {}/{}) - Task ID: {}, Reason: {}",
                queueName, retryCount, maxRetryAttempts, metadata.getTaskId(), metadata.getLastFailureReason());

        rabbitTemplate.send(exchange, routingKey, retryMessage);
    }

    /**
     * Publish message to Dead Letter Queue.
     *
     * @param originalMessage the original message
     * @param metadata        message metadata
     */
    private void publishToDLQ(Message originalMessage, MessageMetadata metadata) {
        Message dlqMessage = buildMessageWithMetadata(originalMessage, metadata);

        LOG.error("Max retry attempts exceeded - Publishing to DLQ - Task ID: {}, Total attempts: {}, " +
                        "First failure: {}, Last failure: {}, Reason: {}",
                metadata.getTaskId(), metadata.getRetryCount(),
                metadata.getFirstFailureTime(), metadata.getLastFailureTime(),
                metadata.getLastFailureReason());

        rabbitTemplate.send(exchange, dlqKey, dlqMessage);
    }

    /**
     * Extract metadata from message headers.
     *
     * @param message the message
     * @return MessageMetadata
     */
    private MessageMetadata extractMetadata(Message message) {
        MessageProperties props = message.getMessageProperties();
        MessageMetadata metadata = new MessageMetadata();

        Object retryCount = props.getHeader(MessageMetadata.HEADER_RETRY_COUNT);
        if (retryCount != null) {
            metadata.setRetryCount(((Number) retryCount).intValue());
        }

        Object firstFailureTime = props.getHeader(MessageMetadata.HEADER_FIRST_FAILURE_TIME);
        if (firstFailureTime != null) {
            metadata.setFirstFailureTime(Instant.parse(firstFailureTime.toString()));
        }

        Object lastFailureTime = props.getHeader(MessageMetadata.HEADER_LAST_FAILURE_TIME);
        if (lastFailureTime != null) {
            metadata.setLastFailureTime(Instant.parse(lastFailureTime.toString()));
        }

        Object lastFailureReason = props.getHeader(MessageMetadata.HEADER_LAST_FAILURE_REASON);
        if (lastFailureReason != null) {
            metadata.setLastFailureReason(lastFailureReason.toString());
        }

        Object originalQueue = props.getHeader(MessageMetadata.HEADER_ORIGINAL_QUEUE);
        if (originalQueue != null) {
            metadata.setOriginalQueue(originalQueue.toString());
        }

        Object taskId = props.getHeader(MessageMetadata.HEADER_TASK_ID);
        if (taskId != null) {
            metadata.setTaskId(taskId.toString());
        }

        return metadata;
    }

    /**
     * Build a new message with updated metadata headers.
     *
     * @param originalMessage the original message
     * @param metadata        updated metadata
     * @return new message with metadata
     */
    private Message buildMessageWithMetadata(Message originalMessage, MessageMetadata metadata) {
        return MessageBuilder.fromMessage(originalMessage)
                .setHeader(MessageMetadata.HEADER_RETRY_COUNT, metadata.getRetryCount())
                .setHeader(MessageMetadata.HEADER_FIRST_FAILURE_TIME,
                        metadata.getFirstFailureTime() != null ? metadata.getFirstFailureTime().toString() : null)
                .setHeader(MessageMetadata.HEADER_LAST_FAILURE_TIME,
                        metadata.getLastFailureTime() != null ? metadata.getLastFailureTime().toString() : null)
                .setHeader(MessageMetadata.HEADER_LAST_FAILURE_REASON, metadata.getLastFailureReason())
                .setHeader(MessageMetadata.HEADER_ORIGINAL_QUEUE, metadata.getOriginalQueue())
                .setHeader(MessageMetadata.HEADER_TASK_ID, metadata.getTaskId())
                .build();
    }

    /**
     * Get the maximum retry attempts configured.
     *
     * @return max retry attempts
     */
    public int getMaxRetryAttempts() {
        return maxRetryAttempts;
    }
}

