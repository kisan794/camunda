/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.log.exception;

public class DataExchangeLoggerException extends RuntimeException {
    private final String transactionId;

    public DataExchangeLoggerException(final String message, final String transactionId) {
        super(message);
        this.transactionId = transactionId;
    }

    public String transactionId() {
        return transactionId;
    }
}
