package hireright.applications.fulfillment_task_api.rest.recombointegration.config;

import jakarta.annotation.PostConstruct;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.jndi.JndiTemplate;

import javax.naming.NamingException;
import javax.sql.DataSource;
import java.util.Properties;

/**
 * @version 1.0
 */
@Configuration
public class DBConfig {


    @Value ("${jdbc.driverClassName}")
    private String m_driverClassName;
    @Value("${java.naming.factory.initial}")
    private String namingFactoryInitial;

    @Value ("${jdbc.cts.url}")
    private String ctsUrl;
    @Value ("${jdbc.cts.user}")
    private String ctsUser;
    @Value ("${jdbc.cts.password}")
    private String ctsPassword;
    @Value ("${jdbc.poll.initial:2}")
    private int ctsPollInit;
    @Value ("${jdbc.poll.max:16}")
    private int ctsPollMax;


    private DataSource getDataSource(String url, String user, String password) {

        BasicDataSource basicDataSource = new BasicDataSource();
        basicDataSource.setDriverClassName(this.m_driverClassName);
        basicDataSource.setUrl(url);
        basicDataSource.setUsername(user);
        basicDataSource.setPassword(password);
        basicDataSource.setInitialSize(this.ctsPollInit); // min pool size
        basicDataSource.setMaxActive(this.ctsPollMax);   // max pool size

        return basicDataSource;
    }

    private void bind(JndiTemplate jndiTemplate, String sJndi, String url, String user, String password)
            throws NamingException {
        final DataSource dataSource = getDataSource(url,  user, password);
        jndiTemplate.bind(sJndi, dataSource);
    }

    @PostConstruct
    public void initJndi() throws NamingException {
        final JndiTemplate jndiTemplate = new JndiTemplate();

        final Properties properties = new Properties();
        properties.setProperty("java.naming.factory.initial", this.namingFactoryInitial);
        System.setProperty("java.naming.factory.initial", this.namingFactoryInitial);
        jndiTemplate.setEnvironment(properties);

        bind(jndiTemplate, "java:comp/env/jdbc/HireRightDS", this.ctsUrl,  this.ctsUser, this.ctsPassword);
    }
}

