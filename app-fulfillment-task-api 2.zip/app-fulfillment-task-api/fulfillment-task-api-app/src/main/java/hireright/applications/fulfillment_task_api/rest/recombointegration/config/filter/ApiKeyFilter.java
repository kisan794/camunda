package hireright.applications.fulfillment_task_api.rest.recombointegration.config.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.security.sasl.AuthenticationException;
import java.io.IOException;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
@Component
public class ApiKeyFilter extends OncePerRequestFilter {

    private static final String API_KEY_HEADER = "x-api-key";

    @Value("${api.key}")
    private String apiKey;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {

        String path = request.getRequestURI();
        if (shouldSkipAuthentication(path)) {
            filterChain.doFilter(request, response);
            return;
        }

        String apiKey = request.getHeader(API_KEY_HEADER);

        if (apiKey == null || !apiKey.equals(this.apiKey)) {
            throw new AuthenticationException("API key is missing or invalid");
        }
        filterChain.doFilter(request, response);
    }

    /**
     * Check if Authentication should be skipped for this path
     */
    private boolean shouldSkipAuthentication(String path) {
        return path.startsWith(this.contextPath + "/actuator") || path.startsWith(
                this.contextPath + "/health") || path.equals("/") || path.startsWith("/swagger")
                || path.startsWith("/v3/api-docs") || path.startsWith(this.contextPath + "/api-docs")
                || path.startsWith(this.contextPath + "/swagger-ui");
    }
}