package hireright.applications.fulfillment_task_api.rest.controller;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import com.hireright.component.spring.rest.db.ReadOnlyTransaction;
import hireright.applications.fulfillment_task_api.api.ITestApiProvider;
import hireright.applications.fulfillment_task_api.model.CHealth;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

@Controller
public class CHealthController extends CAbstractController implements HealthApi {

    public CHealthController(ITestApiProvider apiProvider) {
        super(apiProvider);
    }

    @Override
    @ReadOnlyTransaction
    public ResponseEntity<CHealth> getHealth() {
        CHealth response = execute(null, null, null, api -> api.getServiceHealthManager().getHealth());

        CHealth.EStatus status = response != null ? response.getStatus() : null;

        return CHealth.EStatus.pass.equals(status)
                ? ResponseEntity.ok().body(response)
                : ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
    }

    @Override
    public ResponseEntity<CHealth> getHealthLive() {
        return ResponseEntity.ok().build();
    }

    @Override
    @ReadOnlyTransaction
    public ResponseEntity<CHealth> getHealthReady() {
        CHealth response = execute(null, null, null, api -> api.getServiceHealthManager().getHealth());

        CHealth.EStatus status = response != null ? response.getStatus() : null;

        return CHealth.EStatus.pass.equals(status)
                ? ResponseEntity.ok().build()
                : ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
    }
}
