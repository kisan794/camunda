package hireright.applications.fulfillment_task_api.rest.recombointegration.service;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-16  Created
 */

import hireright.objects.order2.COrderHistory;
import org.springframework.stereotype.Service;

/**
 * @author mkuznetsov
 */
@Service
public class COrderHistoryService {



    public void createHistoryRecord(long orderServiceID, String history) {

        COrderHistory.addServiceHistory(
                orderServiceID,
                "Fulfilment Task API: " + history,
                "HireRight Automation",
                ""
        );
    }
}
