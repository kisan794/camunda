package hireright.applications.fulfillment_task_api.rest.recombointegration.service;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-17  Created
 */

import hireright.components.hrg_core.bdk_hrg_order.bdk_hrg_identifier.CHrgIdentifier;
import hireright.components.hrg_core.bdk_hrg_order.bdk_hrg_identifier.CHrgIdentifierParser;
import hireright.components.hrg_core.bdk_hrg_order.bdk_hrg_identifier.CIdentifierBuilderFactory;
import hireright.objects.objects.IObjectReference;
import hireright.objects.order2.COrderService;
import org.springframework.stereotype.Service;

/**
 * @author mkuznetsov
 */
@Service
public class CIdentifierService {

    private static final String TYPE_TASK = "task";
    private static final String TYPE_ORDER_ITEM = "order-item";

    private final CHrgIdentifierParser parser = new CHrgIdentifierParser();

    private String validateAndGet(String id, String type){
        final CHrgIdentifier hrgIdentifier = this.parser.parse(id);

        /*if (!type.equalsIgnoreCase(hrgIdentifier.getResourceType())){
            throw new IllegalArgumentException("Resource type is not matched: " + hrgIdentifier.getResourceType());
        }*/
        return hrgIdentifier.getResourceID();
    }

    public String build(COrderService orderService) {
        CIdentifierBuilderFactory hrgIdentifierFactory = new CIdentifierBuilderFactory();

        return hrgIdentifierFactory
                .getDefaultBuilder()
                .build(new IObjectReference() {
                    @Override
                    public String getObjectClass() {
                        return TYPE_ORDER_ITEM;
                    }

                    @Override
                    public String getObjectID() {
                        return orderService.getCode();
                    }
                })
                .toString();
    }

    public String getOrderServiceCode(String id){
        return validateAndGet(id, TYPE_ORDER_ITEM);
    }

    public String getTaskID(String id){
        return validateAndGet(id, TYPE_TASK);
    }
}
