package hireright.applications.fulfillment_task_api.rest.recombointegration.service.adapter;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-23  Created
 */

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CResultResponse;
import hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic.CEmploymentResultData;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COrderHistoryService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COsdsService;
import hireright.bdk.order.exception.COrderServiceActionException;
import hireright.objects.is.CMessage;
import hireright.objects.is.api.is_message.CPersistenceFacade;
import hireright.objects.order2.COrderService;
import hireright.objects.order2.service.employment.CEmployment;
import hireright.sdk.db3.DB;
import org.springframework.stereotype.Service;

/**
 * @author mkuznetsov
 */
@Service
public class CEmploymentServiceAdapter extends CAbstractServiceAdapter {

    private enum EmploymentDecisionType {
        CANCELED_PER_REQUESTER("U","X"),
        COMPLETED_WITH_DOCUMENTS("Y","M"),
        COMPLETE_DATA_VERIFIED("Y","N"),
        COMPLETE_SOURCE_FOUND_NO_RECORDS("N","S"),
        CLOSED_NO_DATA_FOUND("N","Y"),
        COMPLETE_SOURCE_FOUND_NO_RECORDS_REVIEW_NOTE_DETAILS_ON_DOCUMENTS("N","D"),
        REVIEW_NOTE_DETAILS_DOCUMENTS_FLAGGED_BY_SOURCE("Y","F"),
        PRODUCT_NOT_AVAILABLE_DUE_TO_OFAC_REGULATIONS("U","W"),
        COMPLETED_WITH_DOCUMENTS_DISCREPANCY("Y","V"),
        CLOSED_SEARCH_NOT_PERFORMED("N","J"),
        CANCELED_PER_APPLICANT("U","Z"),
        COMPLETE_DISCREPANCY("Y","Y"),
        COMPLETE_DATA_FOUND("Y","N"),
        CLOSED_UNABLE_TO_VERIFY("N","Y"),
        CLOSED_NOT_VERIFIED_PER_GUIDELINES("U","N"),
        COMPLETE_SOURCE_VERIFIED_WITH_DISCREPANCY_REVIEW_NOTE_DETAILS_ON_DOCUMENTS("Y","Q"),
        ;

        private final String dataFound;
        private final String discrepancy;

        EmploymentDecisionType(String dataFound, String discrepancy) {
            this.dataFound = dataFound;
            this.discrepancy = discrepancy;
        }

        static EmploymentDecisionType getEducationDecisionType(String name) {
            for (EmploymentDecisionType educationDecisionType : EmploymentDecisionType.values()) {
                if (educationDecisionType.name().equals(name)) {
                    return educationDecisionType;
                }
            }
            return EmploymentDecisionType.CLOSED_UNABLE_TO_VERIFY;
        }
    }

    public CEmploymentServiceAdapter(CPersistenceFacade persistenceFacade,
            COsdsService osdsService,
            LoggingService loggingService,
            COrderHistoryService orderHistoryService,
            ObjectMapper objectMapper) {
        super(persistenceFacade, osdsService, loggingService, orderHistoryService, objectMapper);
    }

    private void mapData(CEmployment employment, CEmploymentResultData data) {

        if (data == null){
            return;
        }

        //employment.setCountry(data.getCountry());
        //employment.setRegionId(data.getRegion());
        //employment.setProvince(data.getCity());

        employment.setRJobTitle(data.getPositionHistory().getTitle());
        employment.setRReason(data.getPositionHistory().getReasonForLeaving());

        employment.setCurrentEmployer("Inactive".equalsIgnoreCase(data.getPositionHistory().getEmployeeStatus()) ? "PREVIOUS"
                : "Active".equalsIgnoreCase(data.getPositionHistory().getEmployeeStatus()) ? "CURRENT" : "UNDEFINED" );
        employment.setRStartDate(parseDate(data.getPositionHistory().getStartDate()));
        employment.setRStartDateType(0);
        employment.setREndDate(parseDate(data.getPositionHistory().getEndDate()));
        employment.setREndDateType(0);
        employment.setSpokeTo(data.getPositionHistory().getSpokeWith());
    }

    public CResultResponse process(String requestId, COrderService orderService, CResultRequest resultRequest) throws
            JsonProcessingException {
        CEmployment employment = CEmployment.load(orderService.getID().longValue());
        if (employment != null) {

            if (resultRequest.getData() != null) {
                mapData(employment, (CEmploymentResultData)resultRequest.getData().getResultData());
                DB.session().update(employment);
            }

            String body = getObjectMapper()
                    .writerWithDefaultPrettyPrinter()
                    .writeValueAsString(resultRequest);

            final CMessage message = createMessage(body);

            final String decision = resultRequest.getData() != null ? resultRequest.getData().getDecision() : "";

            final EmploymentDecisionType decisionType = EmploymentDecisionType.getEducationDecisionType(
                    decision);

            final CResultResponse resultResponse = flushOsds(
                    orderService.getIDLong(),
                    requestId,
                    body,
                    message.getID().toString(),
                    decision);

            try {
                closeOrderService(orderService.getIDLong(), decisionType.dataFound, decisionType.discrepancy);
            } catch (COrderServiceActionException e) {
                throw new RuntimeException(e);
            }

            return resultResponse;
        }
        return CResultResponse.accepted(requestId);
    }
}
