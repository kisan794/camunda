package hireright.applications.fulfillment_task_api.rest.recombointegration.circuitbreaker;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Circuit Breaker implementation for protecting against cascading failures
 * when calling external systems.
 * 
 * States:
 * - CLOSED: Normal operation, requests pass through
 * - OPEN: Circuit is open, requests fail fast without calling external system
 * - HALF_OPEN: Testing if external system has recovered
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Service
@ConditionalOnProperty(name = "circuit-breaker.enabled", havingValue = "true", matchIfMissing = true)
public class CircuitBreakerService {

    private static final Logger LOG = LoggerFactory.getLogger(CircuitBreakerService.class);

    public enum State {
        CLOSED,    // Normal operation
        OPEN,      // Circuit is open, fail fast
        HALF_OPEN  // Testing recovery
    }

    private final AtomicReference<State> state = new AtomicReference<>(State.CLOSED);
    private final AtomicInteger failureCount = new AtomicInteger(0);
    private final AtomicInteger successCount = new AtomicInteger(0);
    private final AtomicLong lastFailureTime = new AtomicLong(0);
    private final CircularBuffer<Boolean> slidingWindow;

    @Value("${circuit-breaker.failure-threshold:5}")
    private int failureThreshold;

    @Value("${circuit-breaker.success-threshold:2}")
    private int successThreshold;

    @Value("${circuit-breaker.timeout-duration:60000}")
    private long timeoutDuration;

    @Value("${circuit-breaker.sliding-window-size:10}")
    private int slidingWindowSize;

    public CircuitBreakerService() {
        this.slidingWindow = new CircularBuffer<>(10); // Will be resized in init
    }

    /**
     * Check if a request can proceed through the circuit breaker.
     *
     * @return true if request can proceed, false if circuit is open
     */
    public boolean allowRequest() {
        State currentState = state.get();

        switch (currentState) {
            case CLOSED:
                return true;

            case OPEN:
                // Check if timeout has elapsed to transition to HALF_OPEN
                if (shouldAttemptReset()) {
                    LOG.info("Circuit breaker transitioning from OPEN to HALF_OPEN");
                    state.set(State.HALF_OPEN);
                    successCount.set(0);
                    return true;
                }
                LOG.warn("Circuit breaker is OPEN - rejecting request");
                return false;

            case HALF_OPEN:
                // Allow limited requests in half-open state
                return true;

            default:
                return true;
        }
    }

    /**
     * Record a successful call to the external system.
     */
    public void recordSuccess() {
        slidingWindow.add(true);
        State currentState = state.get();

        if (currentState == State.HALF_OPEN) {
            int successes = successCount.incrementAndGet();
            LOG.debug("Circuit breaker HALF_OPEN - success count: {}/{}", successes, successThreshold);

            if (successes >= successThreshold) {
                LOG.info("Circuit breaker transitioning from HALF_OPEN to CLOSED - system recovered");
                state.set(State.CLOSED);
                failureCount.set(0);
                successCount.set(0);
            }
        } else if (currentState == State.CLOSED) {
            // Reset failure count on success in closed state
            if (failureCount.get() > 0) {
                failureCount.set(0);
                LOG.debug("Circuit breaker CLOSED - reset failure count after success");
            }
        }
    }

    /**
     * Record a failed call to the external system.
     *
     * @param reason the reason for failure
     */
    public void recordFailure(String reason) {
        slidingWindow.add(false);
        lastFailureTime.set(System.currentTimeMillis());
        State currentState = state.get();

        if (currentState == State.HALF_OPEN) {
            LOG.warn("Circuit breaker HALF_OPEN - failure detected, transitioning back to OPEN. Reason: {}", reason);
            state.set(State.OPEN);
            failureCount.set(0);
            successCount.set(0);
        } else if (currentState == State.CLOSED) {
            int failures = failureCount.incrementAndGet();
            LOG.warn("Circuit breaker CLOSED - failure count: {}/{}. Reason: {}", failures, failureThreshold, reason);

            if (failures >= failureThreshold) {
                LOG.error("Circuit breaker threshold exceeded - transitioning from CLOSED to OPEN");
                state.set(State.OPEN);
                successCount.set(0);
            }
        }
    }

    /**
     * Check if enough time has passed to attempt reset from OPEN to HALF_OPEN.
     *
     * @return true if timeout duration has elapsed
     */
    private boolean shouldAttemptReset() {
        long lastFailure = lastFailureTime.get();
        long currentTime = System.currentTimeMillis();
        return (currentTime - lastFailure) >= timeoutDuration;
    }

    /**
     * Get the current state of the circuit breaker.
     *
     * @return current state
     */
    public State getState() {
        return state.get();
    }

    /**
     * Get the current failure count.
     *
     * @return failure count
     */
    public int getFailureCount() {
        return failureCount.get();
    }

    /**
     * Get the failure rate from the sliding window.
     *
     * @return failure rate as a percentage (0-100)
     */
    public double getFailureRate() {
        return slidingWindow.getFailureRate();
    }

    /**
     * Manually reset the circuit breaker to CLOSED state.
     * This should be used for administrative purposes only.
     */
    public void reset() {
        LOG.info("Circuit breaker manually reset to CLOSED state");
        state.set(State.CLOSED);
        failureCount.set(0);
        successCount.set(0);
        slidingWindow.clear();
    }

    /**
     * Get circuit breaker metrics for monitoring.
     *
     * @return metrics string
     */
    public String getMetrics() {
        return String.format("CircuitBreaker[state=%s, failures=%d, successes=%d, failureRate=%.2f%%]",
                state.get(), failureCount.get(), successCount.get(), getFailureRate());
    }

    /**
     * Circular buffer for tracking success/failure in a sliding window.
     */
    private static class CircularBuffer<T> {
        private final Boolean[] buffer;
        private int index = 0;
        private int size = 0;

        public CircularBuffer(int capacity) {
            this.buffer = new Boolean[capacity];
        }

        public synchronized void add(Boolean value) {
            buffer[index] = value;
            index = (index + 1) % buffer.length;
            if (size < buffer.length) {
                size++;
            }
        }

        public synchronized double getFailureRate() {
            if (size == 0) {
                return 0.0;
            }

            int failures = 0;
            for (int i = 0; i < size; i++) {
                if (buffer[i] != null && !buffer[i]) {
                    failures++;
                }
            }

            return (failures * 100.0) / size;
        }

        public synchronized void clear() {
            for (int i = 0; i < buffer.length; i++) {
                buffer[i] = null;
            }
            index = 0;
            size = 0;
        }
    }
}

