/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.impl;

import hireright.applications.fulfillment_task_api.rest.recombointegration.log.LogOptions;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.lib.logging.log_data_exchange.IDataExchangeLogger;
import hireright.lib.logging.log_data_exchange.model.CLogDataExchange;
import hireright.sdk.util.CProperties;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
class SyncLoggingService implements LoggingService {
    private static final String REQUEST_ID = "requestId";
    private final IDataExchangeLogger dataExchangeLogger;

    public SyncLoggingService(final IDataExchangeLogger dataExchangeLogger) {
        this.dataExchangeLogger = dataExchangeLogger;
    }

    @Override
    public void log(String payload,
            String transactionId,
            RecipientName recipientName,
            Direction direction,
            CProperties properties) {

        final Map<String, String> parameters = new HashMap<>();

        for (String key : properties.keys()) {
            parameters.put(key, properties.getProperty(key));
        }

        final LogOptions logOptions = buildLogOptions(transactionId, properties.getProperty(REQUEST_ID), recipientName, parameters).build();
        final CLogDataExchange logDataExchange = buildDataExchange(
                CLogDataExchange.EDirection.valueOf(direction.name()),
                payload,
                logOptions);
        log(logDataExchange);
    }

    private void log(final CLogDataExchange logDataExchange) {
        this.dataExchangeLogger.log(logDataExchange);
    }

    private LogOptions.LogOptionsBuilder buildLogOptions(final String transactionId,
                                                         final String requestId,
                                                         final RecipientName recipientName,
                                                         final Map<String, String> parameters
            ) {
        return LogOptions.LogOptionsBuilder.cdm2LogOptions(requestId)
                .transactionId(transactionId)
                .recipientName(recipientName)
                .parameters(parameters);
    }

    private CLogDataExchange buildDataExchange(final CLogDataExchange.EDirection direction,
                                               final String payload, final LogOptions options) {
        return new CLogDataExchange.Builder().recipientName(options.recipientName().name())
                .recipientClass(options.recipientClass())
                .transactionID(options.transactionId())
                .recipientID(options.recipientId())
                .parameters(options.parameters())
                .protocol(options.protocol())
                .direction(direction)
                .payload(payload)
                .build();
    }
}
