package hireright.applications.fulfillment_task_api.rest.recombointegration.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AcknowledgeMode;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.support.converter.Jackson2XmlMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ configuration for listener-only setup.
 * Configures queue declarations and listener container factory.
 * Queue creation and bindings are managed externally by the message producer.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Configuration
@ConditionalOnProperty(name = "rabbitmq.enabled", havingValue = "true")
public class RabbitMQConfig {

    private static final Logger LOG = LoggerFactory.getLogger(RabbitMQConfig.class);

    @Value("${rabbitmq.exchange}")
    private String exchange;

    @Value("${rabbitmq.queue.screening-requests}")
    private String screeningRequestsQueue;

    @Value("${rabbitmq.routing.screening-requests}")
    private String screeningRequestsKey;

    @Value("${rabbitmq.queue.screening-dlq}")
    private String screeningDlq;

    @Value("${rabbitmq.routing.screening-dlq}")
    private String screeningKeyDlq;

    @Value("${rabbitmq.listener.concurrency:1}")
    private int concurrency;

    @Value("${rabbitmq.listener.max-concurrency:1}")
    private int maxConcurrency;

    @Value("${rabbitmq.listener.prefetch-count:1}")
    private int prefetchCount;

    @Bean
    public DirectExchange fulfilmentTaskApiDirectExchange() {
        LOG.info("Declaring direct exchange: {}", this.exchange);
        return new DirectExchange(this.exchange);
    }

    /**
     * Declares the main screening requests queue.
     * Messages that fail processing will be sent to DLQ.
     *
     * @return Queue bean for screening requests
     */
    @Bean
    public Queue screeningRequestsQueue()
    {
        LOG.info("Declaring screening requests queue: {}", this.screeningRequestsQueue);
        return QueueBuilder.durable(this.screeningRequestsQueue)
                .withArgument("x-dead-letter-exchange", this.exchange)
                .withArgument("x-dead-letter-routing-key", this.screeningKeyDlq)
                .build();
    }

    // Bind screeningRequestsQueue to the exchange
    @Bean
    public Binding screeningRequestsBinding(Queue screeningRequestsQueue, DirectExchange fulfilmentTaskApiDirectExchange) {
        return BindingBuilder.bind(screeningRequestsQueue)
                .to(fulfilmentTaskApiDirectExchange)
                .with(this.screeningRequestsKey);
    }


    /**
     * Declares the Dead Letter Queue (DLQ) for failed messages.
     *
     * @return Queue bean for DLQ
     */
    @Bean
    public Queue screeningDlq() {
        LOG.info("Declaring screening DLQ: {}", this.screeningDlq);
        return QueueBuilder.durable(this.screeningDlq).build();
    }

    @Bean
    public Binding screeningDlqBinding(Queue screeningDlq, DirectExchange fulfilmentTaskApiDirectExchange) {
        return BindingBuilder.bind(screeningDlq)
                .to(fulfilmentTaskApiDirectExchange)
                .with(this.screeningKeyDlq);
    }

    /**
     * Configures the RabbitMQ listener container factory.
     * Sets concurrency, prefetch count, and message converter.
     *
     * @param connectionFactory RabbitMQ connection factory
     * @return configured listener container factory
     */
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
            ConnectionFactory connectionFactory) {

        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setMessageConverter(jsonMessageConverter());
        factory.setConcurrentConsumers(this.concurrency);
        factory.setMaxConcurrentConsumers(this.maxConcurrency);
        factory.setPrefetchCount(this.prefetchCount);
        factory.setDefaultRequeueRejected(false);
        factory.setAcknowledgeMode(AcknowledgeMode.MANUAL);

        LOG.info("RabbitMQ listener factory configured - Concurrency: {}-{}, Prefetch: {}",
                this.concurrency, this.maxConcurrency, this.prefetchCount);

        return factory;
    }

    /**
     * Configures JSON message converter for RabbitMQ messages.
     *
     * @return Jackson2JsonMessageConverter
     */
    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2XmlMessageConverter();
    }
}

