package hireright.applications.fulfillment_task_api.rest.recombointegration.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AcknowledgeMode;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.support.converter.Jackson2XmlMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ configuration for listener-only setup.
 * Configures queue declarations and listener container factory.
 * Queue creation and bindings are managed externally by the message producer.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Configuration
@ConditionalOnProperty(name = "rabbitmq.enabled", havingValue = "true")
public class RabbitMQConfig {

    private static final Logger LOG = LoggerFactory.getLogger(RabbitMQConfig.class);

    @Value("${rabbitmq.exchange}")
    private String exchange;

    @Value("${rabbitmq.queue.screening-requests}")
    private String screeningRequestsQueue;

    @Value("${rabbitmq.routing.screening-requests}")
    private String screeningRequestsKey;

    @Value("${rabbitmq.queue.screening-dlq}")
    private String screeningDlq;

    @Value("${rabbitmq.routing.screening-dlq}")
    private String screeningKeyDlq;

    @Value("${rabbitmq.queue.retry-1}")
    private String retry1Queue;

    @Value("${rabbitmq.routing.retry-1}")
    private String retry1Key;

    @Value("${rabbitmq.queue.retry-2}")
    private String retry2Queue;

    @Value("${rabbitmq.routing.retry-2}")
    private String retry2Key;

    @Value("${rabbitmq.queue.retry-3}")
    private String retry3Queue;

    @Value("${rabbitmq.routing.retry-3}")
    private String retry3Key;

    @Value("${rabbitmq.listener.concurrency:1}")
    private int concurrency;

    @Value("${rabbitmq.listener.max-concurrency:1}")
    private int maxConcurrency;

    @Value("${rabbitmq.listener.prefetch-count:1}")
    private int prefetchCount;

    @Value("${rabbitmq.retry.delay-r1:30000}")
    private long retryDelay1;

    @Value("${rabbitmq.retry.delay-r2:120000}")
    private long retryDelay2;

    @Value("${rabbitmq.retry.delay-r3:300000}")
    private long retryDelay3;

    @Bean
    public DirectExchange fulfilmentTaskApiDirectExchange() {
        LOG.info("Declaring direct exchange: {}", this.exchange);
        return new DirectExchange(this.exchange);
    }

    /**
     * Declares the main screening requests queue.
     * Messages that fail processing will be sent to DLQ.
     *
     * @return Queue bean for screening requests
     */
    @Bean
    public Queue screeningRequestsQueue()
    {
        LOG.info("Declaring screening requests queue: {}", this.screeningRequestsQueue);
        return QueueBuilder.durable(this.screeningRequestsQueue)
                .withArgument("x-dead-letter-exchange", this.exchange)
                .withArgument("x-dead-letter-routing-key", this.screeningKeyDlq)
                .build();
    }

    // Bind screeningRequestsQueue to the exchange
    @Bean
    public Binding screeningRequestsBinding(Queue screeningRequestsQueue, DirectExchange fulfilmentTaskApiDirectExchange) {
        return BindingBuilder.bind(screeningRequestsQueue)
                .to(fulfilmentTaskApiDirectExchange)
                .with(this.screeningRequestsKey);
    }


    /**
     * Declares the Dead Letter Queue (DLQ) for failed messages.
     *
     * @return Queue bean for DLQ
     */
    @Bean
    public Queue screeningDlq() {
        LOG.info("Declaring screening DLQ: {}", this.screeningDlq);
        return QueueBuilder.durable(this.screeningDlq).build();
    }

    @Bean
    public Binding screeningDlqBinding(Queue screeningDlq, DirectExchange fulfilmentTaskApiDirectExchange) {
        return BindingBuilder.bind(screeningDlq)
                .to(fulfilmentTaskApiDirectExchange)
                .with(this.screeningKeyDlq);
    }

    /**
     * Declares Retry Queue 1 (R1Q) with TTL to return messages to main queue.
     * Messages expire after configured delay and return to main queue for retry.
     *
     * @return Queue bean for R1Q
     */
    @Bean
    public Queue retry1Queue() {
        LOG.info("Declaring Retry Queue 1: {} with TTL: {}ms", this.retry1Queue, this.retryDelay1);
        return QueueBuilder.durable(this.retry1Queue)
                .withArgument("x-message-ttl", this.retryDelay1)
                .withArgument("x-dead-letter-exchange", this.exchange)
                .withArgument("x-dead-letter-routing-key", this.screeningRequestsKey)
                .build();
    }

    @Bean
    public Binding retry1Binding(Queue retry1Queue, DirectExchange fulfilmentTaskApiDirectExchange) {
        return BindingBuilder.bind(retry1Queue)
                .to(fulfilmentTaskApiDirectExchange)
                .with(this.retry1Key);
    }

    /**
     * Declares Retry Queue 2 (R2Q) with TTL to return messages to main queue.
     * Messages expire after configured delay and return to main queue for retry.
     *
     * @return Queue bean for R2Q
     */
    @Bean
    public Queue retry2Queue() {
        LOG.info("Declaring Retry Queue 2: {} with TTL: {}ms", this.retry2Queue, this.retryDelay2);
        return QueueBuilder.durable(this.retry2Queue)
                .withArgument("x-message-ttl", this.retryDelay2)
                .withArgument("x-dead-letter-exchange", this.exchange)
                .withArgument("x-dead-letter-routing-key", this.screeningRequestsKey)
                .build();
    }

    @Bean
    public Binding retry2Binding(Queue retry2Queue, DirectExchange fulfilmentTaskApiDirectExchange) {
        return BindingBuilder.bind(retry2Queue)
                .to(fulfilmentTaskApiDirectExchange)
                .with(this.retry2Key);
    }

    /**
     * Declares Retry Queue 3 (R3Q) with TTL to return messages to main queue.
     * Messages expire after configured delay and return to main queue for retry.
     *
     * @return Queue bean for R3Q
     */
    @Bean
    public Queue retry3Queue() {
        LOG.info("Declaring Retry Queue 3: {} with TTL: {}ms", this.retry3Queue, this.retryDelay3);
        return QueueBuilder.durable(this.retry3Queue)
                .withArgument("x-message-ttl", this.retryDelay3)
                .withArgument("x-dead-letter-exchange", this.exchange)
                .withArgument("x-dead-letter-routing-key", this.screeningRequestsKey)
                .build();
    }

    @Bean
    public Binding retry3Binding(Queue retry3Queue, DirectExchange fulfilmentTaskApiDirectExchange) {
        return BindingBuilder.bind(retry3Queue)
                .to(fulfilmentTaskApiDirectExchange)
                .with(this.retry3Key);
    }

    /**
     * Configures the RabbitMQ listener container factory.
     * Sets concurrency, prefetch count, and message converter.
     *
     * @param connectionFactory RabbitMQ connection factory
     * @return configured listener container factory
     */
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
            ConnectionFactory connectionFactory) {

        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setMessageConverter(jsonMessageConverter());
        factory.setConcurrentConsumers(this.concurrency);
        factory.setMaxConcurrentConsumers(this.maxConcurrency);
        factory.setPrefetchCount(this.prefetchCount);
        factory.setDefaultRequeueRejected(false);
        factory.setAcknowledgeMode(AcknowledgeMode.MANUAL);

        LOG.info("RabbitMQ listener factory configured - Concurrency: {}-{}, Prefetch: {}",
                this.concurrency, this.maxConcurrency, this.prefetchCount);

        return factory;
    }

    /**
     * Configures JSON message converter for RabbitMQ messages.
     *
     * @return Jackson2JsonMessageConverter
     */
    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2XmlMessageConverter();
    }
}

