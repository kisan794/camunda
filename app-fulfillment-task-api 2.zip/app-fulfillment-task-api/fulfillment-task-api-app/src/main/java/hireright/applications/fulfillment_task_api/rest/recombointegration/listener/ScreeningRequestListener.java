package hireright.applications.fulfillment_task_api.rest.recombointegration.listener;

import com.rabbitmq.client.Channel;
import hireright.applications.fulfillment_task_api.model.recombointegration.listener.Event;
import hireright.applications.fulfillment_task_api.rest.recombointegration.circuitbreaker.CircuitBreakerService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.model.MessageMetadata;
import hireright.applications.fulfillment_task_api.rest.recombointegration.retry.RetryMessagePublisher;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.CorrelationIdHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * RabbitMQ listener for screening requests.
 * Listens to the screening queue and processes incoming messages.
 * Integrates with Circuit Breaker and Retry mechanism for resilient external system integration.
 *
 * @author Keshav Ladha
 * @version 1.0
 */

@Component
@ConditionalOnProperty(name = "rabbitmq.enabled", havingValue = "true")
public class ScreeningRequestListener {

    private static final Logger LOG = LoggerFactory.getLogger(ScreeningRequestListener.class);

    private static final String PARAMETER_TASK_ID = "taskID";
    private final FulfillmentService fulfillmentService;
    private final RetryMessagePublisher retryMessagePublisher;
    private final CircuitBreakerService circuitBreakerService;

    public ScreeningRequestListener(
            FulfillmentService fulfillmentService,
            RetryMessagePublisher retryMessagePublisher,
            @Autowired(required = false) CircuitBreakerService circuitBreakerService) {
        this.fulfillmentService = fulfillmentService;
        this.retryMessagePublisher = retryMessagePublisher;
        this.circuitBreakerService = circuitBreakerService;
    }

    /**
     * Listens to screening requests queue and processes messages.
     * Integrates Circuit Breaker pattern to protect against external system failures.
     * Routes failed messages to retry queues or DLQ based on retry count.
     *
     * @param event   the screening request message
     * @param message the RabbitMQ message with headers
     * @param channel the RabbitMQ channel for acknowledgment
     */
    @RabbitListener(queues = "${rabbitmq.queue.screening-requests}")
    public void handleScreeningRequest(@Payload Event event, Message message, Channel channel) {
        String taskId = null;
        try {
            // Set correlation ID from header, or from request body, or generate new one
            CorrelationIdHolder.generate();

            // Extract task ID from event parameters
            taskId = event.parameters().stream()
                    .filter(parameter -> PARAMETER_TASK_ID.equalsIgnoreCase(parameter.getName()))
                    .findFirst()
                    .map(parameter -> parameter.getValue())
                    .orElse(null);

            // Log retry attempt information
            MessageMetadata metadata = extractMetadata(message);
            if (metadata.getRetryCount() > 0) {
                LOG.info("Processing retry attempt {} for screening request - ID: {}, Task ID: {}, CorrelationID: {}",
                        metadata.getRetryCount(), event.id(), taskId, CorrelationIdHolder.get());
            } else {
                LOG.info("Received screening request from queue - ID: {}, Task ID: {}, CorrelationID: {}",
                        event.id(), taskId, CorrelationIdHolder.get());
            }

            // Check circuit breaker before processing
            if (circuitBreakerService != null && !circuitBreakerService.allowRequest()) {
                String reason = "Circuit breaker is OPEN - external system unavailable";
                LOG.warn("{} - Sending to retry queue - Task ID: {}", reason, taskId);
                handleFailure(message, channel, taskId, reason);
                return;
            }

            // Process the request asynchronously
            if (taskId != null) {
                this.fulfillmentService.fulfill(taskId);
            } else {
                LOG.error("Task ID not found in event parameters - ID: {}", event.id());
                channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, false);
                return;
            }

            LOG.info("Successfully processed screening request - ID: {}, Task ID: {}, CorrelationID: {}",
                    event.id(), taskId, CorrelationIdHolder.get());

            // Acknowledge successful processing
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);

            // Record success in circuit breaker
            if (circuitBreakerService != null) {
                circuitBreakerService.recordSuccess();
            }

        } catch (Exception e) {
            LOG.error("Failed to process screening request - ID: {}, Task ID: {}",
                    event.id(), taskId, e);

            handleFailure(message, channel, taskId, e.getMessage());

        } finally {
            // Clean up correlation ID from MDC
            CorrelationIdHolder.clear();
        }
    }

    /**
     * Handle message processing failure by routing to retry queue or DLQ.
     *
     * @param message the failed message
     * @param channel the RabbitMQ channel
     * @param taskId  the task ID
     * @param reason  the failure reason
     */
    private void handleFailure(Message message, Channel channel, String taskId, String reason) {
        try {
            // Record failure in circuit breaker
            if (circuitBreakerService != null) {
                circuitBreakerService.recordFailure(reason);
                LOG.debug("Circuit breaker metrics: {}", circuitBreakerService.getMetrics());
            }

            // Publish to retry queue or DLQ
            retryMessagePublisher.publishForRetry(message, reason, taskId);

            // Acknowledge the message (it's been sent to retry/DLQ)
            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);

        } catch (IOException ex) {
            LOG.error("Failed to handle message failure - Task ID: {}", taskId, ex);
            try {
                // Reject and don't requeue (will go to DLQ via dead-letter-exchange)
                channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, false);
            } catch (IOException nackEx) {
                LOG.error("Failed to NACK message - Task ID: {}", taskId, nackEx);
                throw new RuntimeException("Failed to handle message failure", nackEx);
            }
        }
    }

    /**
     * Extract metadata from message headers.
     *
     * @param message the RabbitMQ message
     * @return MessageMetadata
     */
    private MessageMetadata extractMetadata(Message message) {
        MessageMetadata metadata = new MessageMetadata();
        Object retryCount = message.getMessageProperties().getHeader(MessageMetadata.HEADER_RETRY_COUNT);
        if (retryCount != null) {
            metadata.setRetryCount(((Number) retryCount).intValue());
        }
        return metadata;
    }
}