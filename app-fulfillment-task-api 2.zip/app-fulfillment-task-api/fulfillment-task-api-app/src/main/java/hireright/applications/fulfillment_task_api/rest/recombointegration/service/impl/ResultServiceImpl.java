/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CResultResponse;
import hireright.applications.fulfillment_task_api.rest.recombointegration.db.COrderServiceFactory;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.CIdentifierService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ISourceDetectionService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.adapter.CEducationServiceAdapter;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.adapter.CEmploymentServiceAdapter;
import hireright.objects.is.api.is_message.CPersistenceFacade;
import hireright.objects.order2.COrderService;
import hireright.sdk.db3.DB;
import jakarta.ws.rs.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.EDUCATION;
import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.EMPLOYMENT;

/**
 * Implementation of SubmitService for processing fulfillment task result submissions
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Service
public class ResultServiceImpl implements ResultService {

    private static final Logger LOG = LoggerFactory.getLogger(ResultServiceImpl.class);

    private final ISourceDetectionService sourceDetectionService;
    private final CIdentifierService identifierService;
    private final CEducationServiceAdapter educationServiceAdapter;
    private final CEmploymentServiceAdapter employmentServiceAdapter;


    public ResultServiceImpl(
            ISourceDetectionService sourceDetectionService,
            CIdentifierService identifierService,
            CEducationServiceAdapter educationServiceAdapter,
            CEmploymentServiceAdapter employmentServiceAdapter) {
        this.sourceDetectionService = sourceDetectionService;
        this.identifierService = identifierService;
        this.educationServiceAdapter = educationServiceAdapter;
        this.employmentServiceAdapter = employmentServiceAdapter;
    }

    @Override
    public CResultResponse processSubmission(String requestId, CResultRequest resultRequest) {
        if (resultRequest == null || resultRequest.getId() == null || resultRequest.getId().isEmpty()) {
            throw new BadRequestException();
        }

        LOG.info("Processing fulfillment result - Request Id: {}, Type: {}", requestId, resultRequest.getId());

        return processResultData(resultRequest, requestId);
    }

    private CResultResponse processResultData(CResultRequest resultRequest, String requestId) {
        final String code = this.identifierService.getOrderServiceCode(requestId);
        if (code == null) {
            return null;
        }
        try {
            return DB.execute(() -> {
                COrderService orderService = COrderServiceFactory.getOrderService(code);
                if (orderService == null) {
                    return null;
                }

                String sourceType = this.sourceDetectionService.getSourceType(orderService.getServiceID());
                CResultResponse resultResponse = switch (sourceType) {
                    case EDUCATION -> this.educationServiceAdapter.process(requestId, orderService, resultRequest);
                    case EMPLOYMENT -> this.employmentServiceAdapter.process(requestId, orderService, resultRequest);
                    default -> throw new IllegalStateException("Unexpected value: " + sourceType);
                };

                DB.commit();
                return resultResponse;
            });
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }
        return CResultResponse.accepted(requestId);
    }
}