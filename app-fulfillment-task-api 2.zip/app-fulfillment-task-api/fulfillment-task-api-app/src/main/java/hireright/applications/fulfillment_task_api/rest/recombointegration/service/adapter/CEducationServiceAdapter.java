package hireright.applications.fulfillment_task_api.rest.recombointegration.service.adapter;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-23  Created
 */

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CResultResponse;
import hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic.CEducationResultData;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COrderHistoryService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COsdsService;
import hireright.bdk.order.exception.COrderServiceActionException;
import hireright.objects.is.CMessage;
import hireright.objects.is.api.is_message.CPersistenceFacade;
import hireright.objects.order2.COrderService;
import hireright.objects.order2.service.education.CEducation;
import hireright.sdk.consts.Logical;
import hireright.sdk.db3.DB;
import org.springframework.stereotype.Service;

/**
 * @author mkuznetsov
 */
@Service
public class CEducationServiceAdapter extends CAbstractServiceAdapter {

    private enum EducationDecisionType {
        CANCELED_PER_REQUESTER("U","X"),
        CLOSED_WITHOUT_VERIFICATION_REVIEW_NOTE_DETAILS("U","Y"),
        COMPLETED_WITH_DOCUMENTS("Y","M"),
        COMPLETE_DATA_VERIFIED("Y","N"),
        COMPLETE_SOURCE_FOUND_NO_RECORDS("N","S"),
        COMPLETE_SOURCE_FOUND_NO_RECORDS_REVIEW_NOTE_DETAILS_ON_DOCUMENTS("N","D"),
        REVIEW_NOTE_DETAILS_DOCUMENTS_FLAGGED_BY_SOURCE("Y","F"),
        PRODUCT_NOT_AVAILABLE_DUE_TO_OFAC_REGULATIONS("U","W"),
        COMPLETED_WITH_DOCUMENTS_DISCREPANCY("Y","V"),
        CLOSED_SEARCH_NOT_PERFORMED("N","J"),
        CANCELED_PER_APPLICANT("U","Z"),
        COMPLETE_DISCREPANCY("Y","Y"),
        CLOSED_UNABLE_TO_VERIFY("N","Y"),
        CLOSED_NOT_VERIFIED_PER_GUIDELINES("U","N"),
        COMPLETE_SOURCE_VERIFIED_WITH_DISCREPANCY_REVIEW_NOTE_DETAILS_ON_DOCUMENTS("Y","Q")
        ;

        private final String dataFound;
        private final String discrepancy;

        EducationDecisionType(String dataFound, String discrepancy) {
            this.dataFound = dataFound;
            this.discrepancy = discrepancy;
        }

        static EducationDecisionType getEducationDecisionType(String name) {
            for (EducationDecisionType educationDecisionType : EducationDecisionType.values()) {
                if (educationDecisionType.name().equals(name)) {
                    return educationDecisionType;
                }
            }
            return EducationDecisionType.CLOSED_UNABLE_TO_VERIFY;
        }
    }

    public CEducationServiceAdapter(CPersistenceFacade persistenceFacade,
            COsdsService osdsService,
            LoggingService loggingService,
            COrderHistoryService orderHistoryService,
            ObjectMapper objectMapper) {
        super(persistenceFacade, osdsService, loggingService, orderHistoryService, objectMapper);
    }

    private void mapData(CEducation education, CEducationResultData data){

        if (data == null){
            return;
        }
        education.setRCountry(data.getCountry());
        //education.setRegionId(data.getRegion());
        education.setProvince(data.getCity());

        education.setRDegree(data.getQualifications().getDegree());
        education.setRDegreeDate(parseDate(data.getQualifications().getDegreeDate()));
        education.setGraduated("Inactive".equalsIgnoreCase(data.getQualifications().getEducationStatus()) ? Logical.NO_FULL_UPPER_CASE
                : "Active".equalsIgnoreCase(data.getQualifications().getEducationStatus()) ? Logical.YES_FULL_UPPER_CASE : "");
        education.setReceivedDegreeDate(parseDate(data.getQualifications().getDegreeDate()));
        education.setRStartDate(parseDate(data.getQualifications().getStartDate()));
        education.setRStartDateType(0);
        education.setREndDate(parseDate(data.getQualifications().getEndDate()));
        education.setREndDateType(0);
        education.setSpokeTo(data.getQualifications().getSpokeWith());
    }

    public CResultResponse process(String requestId, COrderService orderService, CResultRequest resultRequest) throws
            JsonProcessingException {
        CEducation education = CEducation.load(orderService.getID().longValue());
        if (education != null) {

            if (resultRequest.getData() != null) {
                mapData(education, (CEducationResultData)resultRequest.getData().getResultData());
                DB.session().update(education);
            }


            String body = getObjectMapper()
                    .writerWithDefaultPrettyPrinter()
                    .writeValueAsString(resultRequest);

            CMessage message = createMessage(body);
            final String decision = resultRequest.getData() != null ? resultRequest.getData().getDecision() : "";

            final EducationDecisionType decisionType = EducationDecisionType.getEducationDecisionType(
                    decision);

            final CResultResponse resultResponse = flushOsds(
                    orderService.getIDLong(),
                    requestId,
                    body,
                    message.getID().toString(),
                    decision);

            try {
                closeOrderService(orderService.getIDLong(), decisionType.dataFound, decisionType.discrepancy);
            } catch (COrderServiceActionException e) {
                throw new RuntimeException(e);
            }

            return resultResponse;
        }
        return CResultResponse.accepted(requestId);

    }
}
