package hireright.applications.fulfillment_task_api.rest.recombointegration.tools;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CGuidelineFactory {

    private static final String SQL =
            "SELECT service_id, customer_id, text FROM user1.customer_guideline"
                    + " WHERE service_id = ? AND customer_id = ? AND active = 'Y'";

    private final Connection m_connection;

    public CGuidelineFactory(Connection connection) {
        m_connection = connection;
    }

    public List<String> get(String sServiceId, String sCustomerId) {
        if (sServiceId == null || sServiceId.isEmpty() || sCustomerId == null || sCustomerId.isBlank()) {
            return null;
        }

        final String guidelines = fromDb(sServiceId, sCustomerId);
        if (guidelines == null) {
            return Collections.emptyList();
        }

        return Arrays.stream(guidelines.split("\\n\\n"))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();

    }

    private String fromDb(String sServiceId, String sCustomerId) {
        try (PreparedStatement stmt = m_connection.prepareStatement(SQL)) {
            int index = 1;
            stmt.setString(index++, sServiceId);
            stmt.setString(index, sCustomerId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("text");
                }
            }
        } catch (SQLException ignored) {
        }

        return null;
    }
}
