package hireright.applications.fulfillment_task_api.rest.recombointegration.processor;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import hireright.applications.fulfillment_task_api.model.recombointegration.common.CNote;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.CDataRequest;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.CIdentifierService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COsdsService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.CXml2JsonSerializer;
import hireright.applications.fulfillment_task_api.rest.recombointegration.tools.CGuidelineFactory;
import hireright.objects.application.CApplication;
import hireright.objects.application.CApplicationOrder;
import hireright.objects.application.CApplicationOrderFactory;
import hireright.objects.billing.CBillingUnitFactory;
import hireright.objects.billing.CBillingUnitItem;
import hireright.objects.objects.CCountries;
import hireright.objects.objects.CCountry;
import hireright.objects.order2.COrderHistory;
import hireright.objects.order2.COrderService;
import hireright.objects.product_catalogue.CD365ProductCode;
import hireright.objects.product_catalogue.CProduct;
import hireright.objects.product_catalogue.CProductIdentification;
import hireright.objects.product_catalogue.factories.CProductIdentificationFactory;
import hireright.objects.service2.CService;
import hireright.objects.users.CCustomerUser;
import hireright.sdk.db3.DB;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public abstract class CAbstractProcessor {

    protected static final int DEFAULT_CUSTOMER = 0;


    private final CXml2JsonSerializer xml2JsonSerializer;
    private final COsdsService osdsService;
    private final CIdentifierService identifierService;

    CAbstractProcessor(
            CXml2JsonSerializer xml2JsonSerializer,
            COsdsService osdsService,
            CIdentifierService identifierService) {
        this.xml2JsonSerializer = xml2JsonSerializer;
        this.osdsService = osdsService;
        this.identifierService = identifierService;
    }

    public abstract <T extends CDataRequest<?>> T process(String sTaskId, COrderService orderService, CService service) throws Exception;

    protected CXml2JsonSerializer getXml2JsonSerializer() {
        return this.xml2JsonSerializer;
    }

    protected COsdsService getOsdsService() {
        return this.osdsService;
    }

    protected CIdentifierService getIdentifierService() {
        return this.identifierService;
    }

    protected CApplication getApplication(Long lOrderID) {
        CApplication application = null;

        CApplicationOrder ao = CApplicationOrderFactory.load(null, lOrderID, CApplication.OBJECT_CLASS);
        if (ao == null) {
            ao = CApplicationOrderFactory.loadByOrderID(lOrderID);
        }
        if (ao != null) {
            application = new CApplication();
            if (!application.load(ao.getApplicationID(), CCustomerUser.OBJECT_CLASS)) {
                application = null;
            }
        }

        return application;
    }

    @SuppressWarnings("unchecked")
    protected CD365ProductCode getProductCode(Integer nServiceID) {
        CProduct product = getProduct(nServiceID);

        Integer nProductID = product != null ? product.getID() : null;

        List<CD365ProductCode> codes = null;

        if (nProductID != null) {
            Criteria d365Query = DB.session().createCriteria(CD365ProductCode.class);
            d365Query.add(Restrictions.eq("productId", nProductID));
            codes = d365Query.list();
        }

        return codes != null && !codes.isEmpty() ? codes.get(0) : null;
    }

    private CProduct getProduct(Integer nServiceID) {
        CProductIdentification identification = CProductIdentificationFactory.getPIDBy(String.valueOf(nServiceID));

        Integer nProductID = identification != null ? identification.getProductID() : null;

        return nProductID != null ? (CProduct) DB.session().get(CProduct.class, nProductID) : null;
    }

    protected CBillingUnitItem getBillingItem(Long lBillingUnitID, COrderService orderService) {
        return lBillingUnitID == null ? null : CBillingUnitFactory.loadBillingUnitItemList(lBillingUnitID,
                        orderService.getObjectClass(), orderService.getObjectID())
                .stream()
                .findFirst()
                .orElse(null);
    }

    protected List<String> getGuideline(String sServiceId, String sCustomerId) throws Exception {
        return DB.execute(() -> {
            try (Connection connection = DB.connection()) {
                CGuidelineFactory guidelineFactory = new CGuidelineFactory(connection);
                return guidelineFactory.get(sServiceId, sCustomerId);
            }
        });
    }

    protected List<CNote> getNotes(Long orderID, Long orderServiceID) {
        List<COrderHistory> orderHistoryList = COrderHistory.loadByOrderAndService(orderID, orderServiceID);
        if (orderHistoryList == null || orderHistoryList.isEmpty()) {
            return new ArrayList<>();
        }

        return orderHistoryList.stream()
                .map(orderHistory -> new CNote.Builder()
                        .date(instantToString(orderHistory.getCreationDate()))
                        .originator(orderHistory.getOperatorName())
                        .note(orderHistory.getHistory())
                        .build())
                .collect(Collectors.toList());
    }

    protected String resolveCountryCode(String countryText, Integer id){
        CCountry country = CCountries.getCountry(id);
        if (country == null){
            Integer countryId = CCountries.findCountry(countryText);
            if (countryId == null){
                countryId = CCountry.USA_COUNTRY_ID;
            }
            country = CCountries.getCountry(countryId);
        }
        return country == null ? "US" : country.getISOA2();
    }

    public static String dateToString(Date date) {
        try {
            return date != null ? date.toString() : null;
        } catch (Throwable e) {
            return "";
        }
    }

    public static String instantToString(Date date) {
        try {
            return date != null ? date.toInstant().toString() : null;
        } catch (Throwable e) {
            return "";
        }
    }
}
