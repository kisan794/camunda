package hireright.applications.fulfillment_task_api.rest.recombointegration.model;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import java.time.Instant;

/**
 * Metadata for tracking message retry attempts and failure information.
 * This information is stored in RabbitMQ message headers.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class MessageMetadata {

    public static final String HEADER_RETRY_COUNT = "x-retry-count";
    public static final String HEADER_FIRST_FAILURE_TIME = "x-first-failure-time";
    public static final String HEADER_LAST_FAILURE_TIME = "x-last-failure-time";
    public static final String HEADER_LAST_FAILURE_REASON = "x-last-failure-reason";
    public static final String HEADER_ORIGINAL_QUEUE = "x-original-queue";
    public static final String HEADER_TASK_ID = "x-task-id";

    private int retryCount;
    private Instant firstFailureTime;
    private Instant lastFailureTime;
    private String lastFailureReason;
    private String originalQueue;
    private String taskId;

    public MessageMetadata() {
        this.retryCount = 0;
    }

    public MessageMetadata(int retryCount, Instant firstFailureTime, Instant lastFailureTime,
                           String lastFailureReason, String originalQueue, String taskId) {
        this.retryCount = retryCount;
        this.firstFailureTime = firstFailureTime;
        this.lastFailureTime = lastFailureTime;
        this.lastFailureReason = lastFailureReason;
        this.originalQueue = originalQueue;
        this.taskId = taskId;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public void incrementRetryCount() {
        this.retryCount++;
    }

    public Instant getFirstFailureTime() {
        return firstFailureTime;
    }

    public void setFirstFailureTime(Instant firstFailureTime) {
        this.firstFailureTime = firstFailureTime;
    }

    public Instant getLastFailureTime() {
        return lastFailureTime;
    }

    public void setLastFailureTime(Instant lastFailureTime) {
        this.lastFailureTime = lastFailureTime;
    }

    public String getLastFailureReason() {
        return lastFailureReason;
    }

    public void setLastFailureReason(String lastFailureReason) {
        this.lastFailureReason = lastFailureReason;
    }

    public String getOriginalQueue() {
        return originalQueue;
    }

    public void setOriginalQueue(String originalQueue) {
        this.originalQueue = originalQueue;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    @Override
    public String toString() {
        return "MessageMetadata{" +
                "retryCount=" + retryCount +
                ", firstFailureTime=" + firstFailureTime +
                ", lastFailureTime=" + lastFailureTime +
                ", lastFailureReason='" + lastFailureReason + '\'' +
                ", originalQueue='" + originalQueue + '\'' +
                ", taskId='" + taskId + '\'' +
                '}';
    }
}

