package hireright.applications.fulfillment_task_api.rest.controller;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import hireright.applications.fulfillment_task_api.api.ITestApi;
import hireright.applications.fulfillment_task_api.api.ITestApiProvider;
import hireright.applications.fulfillment_task_api.api.log.CTestApi;
import hireright.applications.fulfillment_task_api.model.serialization.CDefaultObjectMapper;
import hireright.applications.fulfillment_task_api.rest.log.CTestApiActivityLogger;
import hireright.lib.logging.log_activity.CActivityLogger;
import hireright.lib.logging.log_activity.CObjectActivityLogger;
import hireright.lib.logging.log_activity.IActivityLogger;
import hireright.objects.users.COperator;
import hireright.sdk.db.CMultitenantDB;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.function.Consumer;
import java.util.function.Function;

public abstract class CAbstractController {
    private final ITestApiProvider m_apiProvider;
    private final IActivityLogger m_activityLogger;
    private final Function<Object, String> m_serializer;

    @Autowired
    private HttpServletRequest m_request;

    protected CAbstractController(ITestApiProvider apiProvider, IActivityLogger activityLogger) {
        this.m_apiProvider = apiProvider;
        this.m_activityLogger = activityLogger;
        this.m_serializer = new CDefaultObjectMapper();
    }

    protected CAbstractController(ITestApiProvider apiProvider) {
        this(apiProvider, CActivityLogger.DEFAULT);
    }

    protected void executeNoop(String sTenant, String sOriginator, String sTransactionID,
                               Consumer<ITestApi> execution) {
        execute(sTenant, sOriginator, sTransactionID, api -> {
            execution.accept(api);
            return null;
        });
    }

    protected <T> T execute(String sTenant, String sOriginator, String sTransactionID,
                            Function<ITestApi, T> execution) {
        if (sOriginator == null || sOriginator.trim().isEmpty()) {
            sOriginator = "anonymous";
        }

        ITestApi api = getApi(sOriginator, sTransactionID);

        if (sTenant != null && !sTenant.trim().isEmpty()) {
            try {
                return CMultitenantDB.execute(sTenant, () -> execution.apply(api));
            } catch (RuntimeException e) {
                throw e;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else {
            return execution.apply(api);
        }
    }

    protected ITestApi getApi(String sOriginator, String sTransactionID) {
        String sObjectClass = COperator.OBJECT_CLASS;
        String sObjectID = sOriginator;

        if (sOriginator != null && sOriginator.contains(":")) {
            String[] arrOriginator = sOriginator.split(":");
            if (arrOriginator.length == 2) {
                sObjectClass = arrOriginator[0].trim().toUpperCase();
                sObjectID = arrOriginator[1].trim();
            }
        }

        String sClientIP = this.m_request != null ? this.m_request.getRemoteAddr() : null;

        IActivityLogger logger = this.m_activityLogger;
        logger = new CObjectActivityLogger(logger, sObjectClass, sObjectID, sClientIP);
        logger = new CTestApiActivityLogger(logger, sTransactionID);

        ITestApi api = this.m_apiProvider.getApi();
        api = new CTestApi(api, logger);

        return api;
    }
}
