package hireright.applications.fulfillment_task_api.rest.recombointegration.retry;

import hireright.applications.fulfillment_task_api.rest.recombointegration.model.MessageMetadata;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for RetryMessagePublisher.
 * Tests retry queue routing logic and metadata handling.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class RetryMessagePublisherTest {

    @Mock
    private RabbitTemplate rabbitTemplate;

    private RetryMessagePublisher retryMessagePublisher;

    private static final String EXCHANGE = "test.exchange";
    private static final String RETRY_1_KEY = "retry_1";
    private static final String RETRY_2_KEY = "retry_2";
    private static final String RETRY_3_KEY = "retry_3";
    private static final String DLQ_KEY = "dead_letter";
    private static final int MAX_ATTEMPTS = 3;

    @BeforeEach
    void setUp() {
        retryMessagePublisher = new RetryMessagePublisher(rabbitTemplate);
        
        // Set configuration values
        ReflectionTestUtils.setField(retryMessagePublisher, "exchange", EXCHANGE);
        ReflectionTestUtils.setField(retryMessagePublisher, "retry1RoutingKey", RETRY_1_KEY);
        ReflectionTestUtils.setField(retryMessagePublisher, "retry2RoutingKey", RETRY_2_KEY);
        ReflectionTestUtils.setField(retryMessagePublisher, "retry3RoutingKey", RETRY_3_KEY);
        ReflectionTestUtils.setField(retryMessagePublisher, "dlqRoutingKey", DLQ_KEY);
        ReflectionTestUtils.setField(retryMessagePublisher, "maxRetryAttempts", MAX_ATTEMPTS);
    }

    @Test
    void testFirstFailure_ShouldRouteToRetry1Queue() {
        // Given: A message with no retry count (first failure)
        Message message = createMessage(0);
        String failureReason = "HTTP 503 Service Unavailable";
        String taskId = "TASK-123";

        // When: Publish for retry
        retryMessagePublisher.publishForRetry(message, failureReason, taskId);

        // Then: Should publish to retry-1 queue
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_1_KEY), messageCaptor.capture());

        Message sentMessage = messageCaptor.getValue();
        assertEquals(1, sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_RETRY_COUNT));
        assertEquals(failureReason, sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_LAST_FAILURE_REASON));
        assertEquals(taskId, sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_TASK_ID));
    }

    @Test
    void testSecondFailure_ShouldRouteToRetry2Queue() {
        // Given: A message with retry count = 1
        Message message = createMessage(1);
        String failureReason = "Circuit breaker is OPEN";
        String taskId = "TASK-456";

        // When: Publish for retry
        retryMessagePublisher.publishForRetry(message, failureReason, taskId);

        // Then: Should publish to retry-2 queue
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_2_KEY), messageCaptor.capture());

        Message sentMessage = messageCaptor.getValue();
        assertEquals(2, sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_RETRY_COUNT));
    }

    @Test
    void testThirdFailure_ShouldRouteToRetry3Queue() {
        // Given: A message with retry count = 2
        Message message = createMessage(2);
        String failureReason = "Connection timeout";
        String taskId = "TASK-789";

        // When: Publish for retry
        retryMessagePublisher.publishForRetry(message, failureReason, taskId);

        // Then: Should publish to retry-3 queue
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_3_KEY), messageCaptor.capture());

        Message sentMessage = messageCaptor.getValue();
        assertEquals(3, sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_RETRY_COUNT));
    }

    @Test
    void testMaxRetriesExceeded_ShouldRouteToDLQ() {
        // Given: A message with retry count = 3 (max attempts)
        Message message = createMessage(3);
        String failureReason = "Permanent failure";
        String taskId = "TASK-999";

        // When: Publish for retry
        retryMessagePublisher.publishForRetry(message, failureReason, taskId);

        // Then: Should publish to DLQ
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(DLQ_KEY), messageCaptor.capture());

        Message sentMessage = messageCaptor.getValue();
        assertEquals(3, sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_RETRY_COUNT));
        assertEquals(failureReason, sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_LAST_FAILURE_REASON));
    }

    @Test
    void testMetadataPreservation_FirstFailureTime() {
        // Given: A message with no previous failure time
        Message message = createMessage(0);
        String taskId = "TASK-111";

        // When: Publish for retry
        retryMessagePublisher.publishForRetry(message, "Test failure", taskId);

        // Then: Should set first failure time
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(anyString(), anyString(), messageCaptor.capture());

        Message sentMessage = messageCaptor.getValue();
        assertNotNull(sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_FIRST_FAILURE_TIME));
        assertNotNull(sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_LAST_FAILURE_TIME));
    }

    @Test
    void testMetadataPreservation_SubsequentFailures() {
        // Given: A message with existing first failure time
        Message message = createMessage(1);
        long firstFailureTime = System.currentTimeMillis() - 60000; // 1 minute ago
        message.getMessageProperties().setHeader(MessageMetadata.HEADER_FIRST_FAILURE_TIME, firstFailureTime);
        String taskId = "TASK-222";

        // When: Publish for retry
        retryMessagePublisher.publishForRetry(message, "Test failure", taskId);

        // Then: Should preserve first failure time but update last failure time
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(anyString(), anyString(), messageCaptor.capture());

        Message sentMessage = messageCaptor.getValue();
        assertEquals(firstFailureTime, sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_FIRST_FAILURE_TIME));
        assertNotNull(sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_LAST_FAILURE_TIME));
    }

    @Test
    void testOriginalQueueTracking() {
        // Given: A message from main queue
        Message message = createMessage(0);
        message.getMessageProperties().setHeader(MessageMetadata.HEADER_ORIGINAL_QUEUE, "main.queue");
        String taskId = "TASK-333";

        // When: Publish for retry
        retryMessagePublisher.publishForRetry(message, "Test failure", taskId);

        // Then: Should preserve original queue
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(anyString(), anyString(), messageCaptor.capture());

        Message sentMessage = messageCaptor.getValue();
        assertEquals("main.queue", sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_ORIGINAL_QUEUE));
    }

    @Test
    void testMessageBodyPreservation() {
        // Given: A message with specific body content
        String originalBody = "{\"taskId\":\"TASK-444\",\"type\":\"employment\"}";
        Message message = new Message(originalBody.getBytes(), new MessageProperties());
        String taskId = "TASK-444";

        // When: Publish for retry
        retryMessagePublisher.publishForRetry(message, "Test failure", taskId);

        // Then: Should preserve message body
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(anyString(), anyString(), messageCaptor.capture());

        Message sentMessage = messageCaptor.getValue();
        assertEquals(originalBody, new String(sentMessage.getBody()));
    }

    @Test
    void testNullTaskId_ShouldHandleGracefully() {
        // Given: A message with null task ID
        Message message = createMessage(0);
        String taskId = null;

        // When: Publish for retry
        retryMessagePublisher.publishForRetry(message, "Test failure", taskId);

        // Then: Should still publish message
        verify(rabbitTemplate).send(anyString(), anyString(), any(Message.class));
    }

    @Test
    void testEmptyFailureReason_ShouldHandleGracefully() {
        // Given: A message with empty failure reason
        Message message = createMessage(0);
        String failureReason = "";
        String taskId = "TASK-555";

        // When: Publish for retry
        retryMessagePublisher.publishForRetry(message, failureReason, taskId);

        // Then: Should still publish message
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(anyString(), anyString(), messageCaptor.capture());

        Message sentMessage = messageCaptor.getValue();
        assertEquals("", sentMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_LAST_FAILURE_REASON));
    }

    @Test
    void testRetryCountIncrement_Sequential() {
        // Given: Messages with sequential retry counts
        String taskId = "TASK-666";

        // When: Publish messages with increasing retry counts
        for (int i = 0; i < 4; i++) {
            Message message = createMessage(i);
            retryMessagePublisher.publishForRetry(message, "Failure " + i, taskId);
        }

        // Then: Should route to correct queues
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_1_KEY), any(Message.class));
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_2_KEY), any(Message.class));
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_3_KEY), any(Message.class));
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(DLQ_KEY), any(Message.class));
    }

    @Test
    void testConcurrentPublishing_ThreadSafety() throws InterruptedException {
        // Given: Multiple threads publishing messages
        int threadCount = 10;
        Thread[] threads = new Thread[threadCount];

        // When: Multiple threads publish concurrently
        for (int i = 0; i < threadCount; i++) {
            final int index = i;
            threads[i] = new Thread(() -> {
                Message message = createMessage(0);
                retryMessagePublisher.publishForRetry(message, "Concurrent failure " + index, "TASK-" + index);
            });
            threads[i].start();
        }

        // Wait for all threads to complete
        for (Thread thread : threads) {
            thread.join();
        }

        // Then: All messages should be published
        verify(rabbitTemplate, times(threadCount)).send(anyString(), anyString(), any(Message.class));
    }

    // Helper method to create test messages
    private Message createMessage(int retryCount) {
        MessageProperties properties = new MessageProperties();
        if (retryCount > 0) {
            properties.setHeader(MessageMetadata.HEADER_RETRY_COUNT, retryCount);
        }
        return new Message("{\"test\":\"data\"}".getBytes(), properties);
    }
}

