package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.rest.recombointegration.circuitbreaker.CircuitBreakerService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.db.IDbProcessor;
import hireright.applications.fulfillment_task_api.rest.recombointegration.http.client.Http2ClientService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COrderHistoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.http.HttpResponse;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for FulfillmentServiceImpl.
 * Tests fulfillment service with circuit breaker integration.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class FulfillmentServiceImplTest {

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private IDbProcessor dbProcessor;

    @Mock
    private Http2ClientService http2ClientService;

    @Mock
    private LoggingService loggingService;

    @Mock
    private COrderHistoryService orderHistoryService;

    @Mock
    private CircuitBreakerService circuitBreakerService;

    @Mock
    private HttpResponse<String> httpResponse;

    @Mock
    private IDbProcessor.ITaskDataResult<?> taskDataResult;

    private FulfillmentServiceImpl fulfillmentService;

    private static final String BASE_URL = "https://api.recombo.ai";
    private static final String SUBMIT_ENDPOINT = "/submit/{sourceType}";
    private static final String API_KEY = "test-api-key";

    @BeforeEach
    void setUp() {
        fulfillmentService = new FulfillmentServiceImpl(
                objectMapper,
                dbProcessor,
                http2ClientService,
                loggingService,
                orderHistoryService,
                circuitBreakerService
        );

        ReflectionTestUtils.setField(fulfillmentService, "recomboServiceBaseUrl", BASE_URL);
        ReflectionTestUtils.setField(fulfillmentService, "recomboSubmitEndpoint", SUBMIT_ENDPOINT);
        ReflectionTestUtils.setField(fulfillmentService, "apiKey", API_KEY);
    }

    @Test
    void testFulfill_WithNullTaskData_ShouldReturnEarly() {
        // Given: DB processor returns null
        when(dbProcessor.getTaskData(anyString())).thenReturn(null);

        // When: Fulfill task
        fulfillmentService.fulfill("TASK-123");

        // Then: Should not call external service
        verify(http2ClientService, never()).postAsync(anyString(), anyString(), anyMap());
        verify(circuitBreakerService, never()).recordSuccess();
        verify(circuitBreakerService, never()).recordFailure(anyString());
    }

    @Test
    void testSendAsyncSubmitRequest_Success_ShouldRecordSuccess() throws Exception {
        // Given: Successful HTTP response
        setupSuccessfulScenario();

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-456");

        // Wait a bit for async processing
        Thread.sleep(100);

        // Then: Should record success in circuit breaker
        verify(circuitBreakerService, timeout(1000)).recordSuccess();
        verify(circuitBreakerService, never()).recordFailure(anyString());
    }

    @Test
    void testSendAsyncSubmitRequest_HttpError_ShouldRecordFailure() throws Exception {
        // Given: HTTP error response (503)
        setupErrorScenario(503);

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-789");

        // Wait for async processing
        Thread.sleep(100);

        // Then: Should record failure in circuit breaker
        verify(circuitBreakerService, timeout(1000)).recordFailure(contains("HTTP 503"));
        verify(circuitBreakerService, never()).recordSuccess();
    }

    @Test
    void testSendAsyncSubmitRequest_Exception_ShouldRecordFailure() throws Exception {
        // Given: HTTP client throws exception
        when(dbProcessor.getTaskData(anyString())).thenReturn(taskDataResult);
        when(taskDataResult.getSourceType()).thenReturn("employment");
        when(taskDataResult.getData()).thenReturn(Map.of("test", "data"));
        when(taskDataResult.getOrderServiceID()).thenReturn(123L);
        when(objectMapper.writeValueAsString(any())).thenReturn("{\"test\":\"data\"}");

        CompletableFuture<HttpResponse<String>> failedFuture = new CompletableFuture<>();
        failedFuture.completeExceptionally(new RuntimeException("Connection timeout"));
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap())).thenReturn(failedFuture);

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-999");

        // Wait for async processing
        Thread.sleep(100);

        // Then: Should record failure in circuit breaker
        verify(circuitBreakerService, timeout(1000)).recordFailure(contains("Connection timeout"));
        verify(circuitBreakerService, never()).recordSuccess();
    }

    @Test
    void testSendAsyncSubmitRequest_NullCircuitBreaker_ShouldNotFail() throws Exception {
        // Given: Circuit breaker is null (disabled)
        fulfillmentService = new FulfillmentServiceImpl(
                objectMapper,
                dbProcessor,
                http2ClientService,
                loggingService,
                orderHistoryService,
                null
        );
        ReflectionTestUtils.setField(fulfillmentService, "recomboServiceBaseUrl", BASE_URL);
        ReflectionTestUtils.setField(fulfillmentService, "recomboSubmitEndpoint", SUBMIT_ENDPOINT);
        ReflectionTestUtils.setField(fulfillmentService, "apiKey", API_KEY);

        setupSuccessfulScenario();

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-111");

        // Wait for async processing
        Thread.sleep(100);

        // Then: Should process normally without circuit breaker
        verify(http2ClientService, timeout(1000)).postAsync(anyString(), anyString(), anyMap());
    }

    @Test
    void testSendAsyncSubmitRequest_CorrectUrlConstruction() throws Exception {
        // Given: Task data with specific source type
        setupSuccessfulScenario();
        when(taskDataResult.getSourceType()).thenReturn("education");

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-222");

        // Then: Should construct correct URL
        ArgumentCaptor<String> urlCaptor = ArgumentCaptor.forClass(String.class);
        verify(http2ClientService, timeout(1000)).postAsync(urlCaptor.capture(), anyString(), anyMap());

        String capturedUrl = urlCaptor.getValue();
        assertTrue(capturedUrl.contains("education"));
        assertTrue(capturedUrl.startsWith(BASE_URL));
    }

    @Test
    void testSendAsyncSubmitRequest_CorrectHeaders() throws Exception {
        // Given: Successful scenario
        setupSuccessfulScenario();

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-333");

        // Then: Should include API key in headers
        ArgumentCaptor<Map<String, String>> headersCaptor = ArgumentCaptor.forClass(Map.class);
        verify(http2ClientService, timeout(1000)).postAsync(anyString(), anyString(), headersCaptor.capture());

        Map<String, String> headers = headersCaptor.getValue();
        assertEquals(API_KEY, headers.get("x-api-key"));
    }

    @Test
    void testSendAsyncSubmitRequest_LoggingCalled() throws Exception {
        // Given: Successful scenario
        setupSuccessfulScenario();

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-444");

        // Then: Should log request and response
        verify(loggingService, timeout(1000).atLeast(1)).log(anyString(), anyString(), any(), any(), any());
    }

    @Test
    void testSendAsyncSubmitRequest_OrderHistoryCalled() throws Exception {
        // Given: Successful scenario
        setupSuccessfulScenario();

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-555");

        // Then: Should create order history record
        verify(orderHistoryService, timeout(1000)).createHistoryRecord(anyLong(), anyString());
    }

    @Test
    void testSendAsyncSubmitRequest_MultipleStatusCodes() throws Exception {
        // Test different HTTP status codes
        int[] statusCodes = {200, 201, 400, 404, 500, 503};

        for (int statusCode : statusCodes) {
            reset(circuitBreakerService, http2ClientService);
            setupErrorScenario(statusCode);

            fulfillmentService.fulfill("TASK-" + statusCode);
            Thread.sleep(100);

            if (statusCode >= 200 && statusCode < 300) {
                verify(circuitBreakerService, timeout(1000)).recordSuccess();
            } else {
                verify(circuitBreakerService, timeout(1000)).recordFailure(anyString());
            }
        }
    }

    @Test
    void testSendAsyncSubmitRequest_JsonSerialization() throws Exception {
        // Given: Task data that needs serialization
        setupSuccessfulScenario();
        Map<String, Object> complexData = Map.of(
                "name", "John Doe",
                "ssn", "123-45-6789",
                "type", "employment"
        );
        when(taskDataResult.getData()).thenReturn(complexData);
        when(objectMapper.writeValueAsString(complexData)).thenReturn("{\"name\":\"John Doe\"}");

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-666");

        // Then: Should serialize data correctly
        verify(objectMapper, timeout(1000)).writeValueAsString(complexData);
        ArgumentCaptor<String> bodyCaptor = ArgumentCaptor.forClass(String.class);
        verify(http2ClientService, timeout(1000)).postAsync(anyString(), bodyCaptor.capture(), anyMap());
        assertEquals("{\"name\":\"John Doe\"}", bodyCaptor.getValue());
    }

    @Test
    void testCircuitBreakerMetrics_AfterSuccess() throws Exception {
        // Given: Successful scenario with metrics
        setupSuccessfulScenario();
        when(circuitBreakerService.getMetrics()).thenReturn("CircuitBreaker[state=CLOSED, successes=1]");

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-777");

        // Wait for async processing
        Thread.sleep(100);

        // Then: Should call getMetrics for logging
        verify(circuitBreakerService, timeout(1000)).getMetrics();
    }

    @Test
    void testCircuitBreakerMetrics_AfterFailure() throws Exception {
        // Given: Error scenario with metrics
        setupErrorScenario(500);
        when(circuitBreakerService.getMetrics()).thenReturn("CircuitBreaker[state=CLOSED, failures=1]");

        // When: Send async submit request
        fulfillmentService.fulfill("TASK-888");

        // Wait for async processing
        Thread.sleep(100);

        // Then: Should call getMetrics for logging
        verify(circuitBreakerService, timeout(1000)).getMetrics();
    }

    // Helper methods
    private void setupSuccessfulScenario() throws Exception {
        when(dbProcessor.getTaskData(anyString())).thenReturn(taskDataResult);
        when(taskDataResult.getSourceType()).thenReturn("employment");
        when(taskDataResult.getData()).thenReturn(Map.of("test", "data"));
        when(taskDataResult.getOrderServiceID()).thenReturn(123L);
        when(objectMapper.writeValueAsString(any())).thenReturn("{\"test\":\"data\"}");

        when(httpResponse.statusCode()).thenReturn(200);
        when(httpResponse.body()).thenReturn("{\"status\":\"success\"}");

        CompletableFuture<HttpResponse<String>> future = CompletableFuture.completedFuture(httpResponse);
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap())).thenReturn(future);
    }

    private void setupErrorScenario(int statusCode) throws Exception {
        when(dbProcessor.getTaskData(anyString())).thenReturn(taskDataResult);
        when(taskDataResult.getSourceType()).thenReturn("employment");
        when(taskDataResult.getData()).thenReturn(Map.of("test", "data"));
        when(taskDataResult.getOrderServiceID()).thenReturn(123L);
        when(objectMapper.writeValueAsString(any())).thenReturn("{\"test\":\"data\"}");

        when(httpResponse.statusCode()).thenReturn(statusCode);
        when(httpResponse.body()).thenReturn("{\"error\":\"Service unavailable\"}");

        CompletableFuture<HttpResponse<String>> future = CompletableFuture.completedFuture(httpResponse);
        when(http2ClientService.postAsync(anyString(), anyString(), anyMap())).thenReturn(future);
    }
}

