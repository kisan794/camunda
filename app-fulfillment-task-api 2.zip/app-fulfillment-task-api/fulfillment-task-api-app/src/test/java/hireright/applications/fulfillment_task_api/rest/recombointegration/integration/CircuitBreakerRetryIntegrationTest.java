package hireright.applications.fulfillment_task_api.rest.recombointegration.integration;

import com.rabbitmq.client.Channel;
import hireright.applications.fulfillment_task_api.model.recombointegration.listener.Event;
import hireright.applications.fulfillment_task_api.model.recombointegration.listener.Parameter;
import hireright.applications.fulfillment_task_api.rest.recombointegration.circuitbreaker.CircuitBreakerService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.listener.ScreeningRequestListener;
import hireright.applications.fulfillment_task_api.rest.recombointegration.model.MessageMetadata;
import hireright.applications.fulfillment_task_api.rest.recombointegration.retry.RetryMessagePublisher;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Integration tests for Circuit Breaker and Retry Queue mechanism.
 * Tests the complete flow from listener through circuit breaker to retry queues.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class CircuitBreakerRetryIntegrationTest {

    @Mock
    private FulfillmentService fulfillmentService;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @Mock
    private Channel channel;

    private CircuitBreakerService circuitBreakerService;
    private RetryMessagePublisher retryMessagePublisher;
    private ScreeningRequestListener listener;

    private static final String EXCHANGE = "test.exchange";
    private static final String RETRY_1_KEY = "retry_1";
    private static final String RETRY_2_KEY = "retry_2";
    private static final String RETRY_3_KEY = "retry_3";
    private static final String DLQ_KEY = "dead_letter";

    @BeforeEach
    void setUp() {
        // Initialize circuit breaker
        circuitBreakerService = new CircuitBreakerService();
        ReflectionTestUtils.setField(circuitBreakerService, "failureThreshold", 5);
        ReflectionTestUtils.setField(circuitBreakerService, "successThreshold", 2);
        ReflectionTestUtils.setField(circuitBreakerService, "timeoutDuration", 60000L);
        ReflectionTestUtils.setField(circuitBreakerService, "slidingWindowSize", 10);
        circuitBreakerService.init();

        // Initialize retry publisher
        retryMessagePublisher = new RetryMessagePublisher(rabbitTemplate);
        ReflectionTestUtils.setField(retryMessagePublisher, "exchange", EXCHANGE);
        ReflectionTestUtils.setField(retryMessagePublisher, "retry1RoutingKey", RETRY_1_KEY);
        ReflectionTestUtils.setField(retryMessagePublisher, "retry2RoutingKey", RETRY_2_KEY);
        ReflectionTestUtils.setField(retryMessagePublisher, "retry3RoutingKey", RETRY_3_KEY);
        ReflectionTestUtils.setField(retryMessagePublisher, "dlqRoutingKey", DLQ_KEY);
        ReflectionTestUtils.setField(retryMessagePublisher, "maxRetryAttempts", 3);

        // Initialize listener
        listener = new ScreeningRequestListener(
                fulfillmentService,
                retryMessagePublisher,
                circuitBreakerService
        );
    }

    @Test
    void testEndToEndFlow_SuccessfulProcessing() throws IOException {
        // Given: A valid message and working external system
        Event event = createEvent("EVENT-001", "TASK-001");
        Message message = createMessage(0);
        doNothing().when(fulfillmentService).fulfill(anyString());

        // When: Process message
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should process successfully
        verify(fulfillmentService).fulfill("TASK-001");
        verify(channel).basicAck(anyLong(), eq(false));
        verify(rabbitTemplate, never()).send(anyString(), anyString(), any(Message.class));
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreakerService.getState());
    }

    @Test
    void testEndToEndFlow_SingleFailureWithRetry() throws IOException {
        // Given: First attempt fails, second succeeds
        Event event = createEvent("EVENT-002", "TASK-002");
        Message message = createMessage(0);
        doThrow(new RuntimeException("Temporary error")).when(fulfillmentService).fulfill("TASK-002");

        // When: Process message (first attempt)
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should route to R1Q
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_1_KEY), messageCaptor.capture());
        verify(channel).basicAck(anyLong(), eq(false));

        Message retryMessage = messageCaptor.getValue();
        assertEquals(1, retryMessage.getMessageProperties().getHeader(MessageMetadata.HEADER_RETRY_COUNT));
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreakerService.getState());
    }

    @Test
    void testEndToEndFlow_MultipleRetriesUntilDLQ() throws IOException {
        // Given: Message that fails all retry attempts
        String taskId = "TASK-003";

        // Attempt 1: Initial failure -> R1Q
        Event event1 = createEvent("EVENT-003", taskId);
        Message message1 = createMessage(0);
        doThrow(new RuntimeException("Error 1")).when(fulfillmentService).fulfill(taskId);

        listener.handleScreeningRequest(event1, message1, channel);
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_1_KEY), any(Message.class));

        // Attempt 2: Retry 1 failure -> R2Q
        reset(rabbitTemplate);
        Event event2 = createEvent("EVENT-003", taskId);
        Message message2 = createMessage(1);
        doThrow(new RuntimeException("Error 2")).when(fulfillmentService).fulfill(taskId);

        listener.handleScreeningRequest(event2, message2, channel);
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_2_KEY), any(Message.class));

        // Attempt 3: Retry 2 failure -> R3Q
        reset(rabbitTemplate);
        Event event3 = createEvent("EVENT-003", taskId);
        Message message3 = createMessage(2);
        doThrow(new RuntimeException("Error 3")).when(fulfillmentService).fulfill(taskId);

        listener.handleScreeningRequest(event3, message3, channel);
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_3_KEY), any(Message.class));

        // Attempt 4: Retry 3 failure -> DLQ
        reset(rabbitTemplate);
        Event event4 = createEvent("EVENT-003", taskId);
        Message message4 = createMessage(3);
        doThrow(new RuntimeException("Error 4")).when(fulfillmentService).fulfill(taskId);

        listener.handleScreeningRequest(event4, message4, channel);
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(DLQ_KEY), any(Message.class));
    }

    @Test
    void testEndToEndFlow_CircuitBreakerOpens() throws IOException {
        // Given: Multiple failures to open circuit breaker
        for (int i = 0; i < 5; i++) {
            Event event = createEvent("EVENT-" + i, "TASK-" + i);
            Message message = createMessage(0);
            doThrow(new RuntimeException("Error " + i)).when(fulfillmentService).fulfill("TASK-" + i);

            listener.handleScreeningRequest(event, message, channel);
        }

        // Then: Circuit should be OPEN
        assertEquals(CircuitBreakerService.State.OPEN, circuitBreakerService.getState());

        // When: Try to process another message
        reset(rabbitTemplate);
        Event newEvent = createEvent("EVENT-NEW", "TASK-NEW");
        Message newMessage = createMessage(0);

        listener.handleScreeningRequest(newEvent, newMessage, channel);

        // Then: Should fail fast without calling fulfillment service
        verify(fulfillmentService, never()).fulfill("TASK-NEW");
        verify(rabbitTemplate).send(eq(EXCHANGE), eq(RETRY_1_KEY), any(Message.class));
    }

    @Test
    void testEndToEndFlow_CircuitBreakerRecovery() throws IOException, InterruptedException {
        // Given: Circuit breaker with short timeout
        ReflectionTestUtils.setField(circuitBreakerService, "timeoutDuration", 100L);
        circuitBreakerService.init();

        // Open the circuit
        for (int i = 0; i < 5; i++) {
            Event event = createEvent("EVENT-" + i, "TASK-" + i);
            Message message = createMessage(0);
            doThrow(new RuntimeException("Error")).when(fulfillmentService).fulfill(anyString());
            listener.handleScreeningRequest(event, message, channel);
        }
        assertEquals(CircuitBreakerService.State.OPEN, circuitBreakerService.getState());

        // Wait for timeout
        Thread.sleep(150);

        // When: Process message with working service
        reset(rabbitTemplate, fulfillmentService);
        doNothing().when(fulfillmentService).fulfill(anyString());

        Event event1 = createEvent("EVENT-RECOVERY-1", "TASK-RECOVERY-1");
        Message message1 = createMessage(0);
        listener.handleScreeningRequest(event1, message1, channel);

        // Circuit should be HALF_OPEN
        assertEquals(CircuitBreakerService.State.HALF_OPEN, circuitBreakerService.getState());

        // Process another successful message
        Event event2 = createEvent("EVENT-RECOVERY-2", "TASK-RECOVERY-2");
        Message message2 = createMessage(0);
        listener.handleScreeningRequest(event2, message2, channel);

        // Then: Circuit should be CLOSED
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreakerService.getState());
        verify(fulfillmentService, times(2)).fulfill(anyString());
    }

    @Test
    void testEndToEndFlow_MetadataTracking() throws IOException {
        // Given: Message that fails
        Event event = createEvent("EVENT-META", "TASK-META");
        Message message = createMessage(0);
        doThrow(new RuntimeException("Test error")).when(fulfillmentService).fulfill(anyString());

        long beforeTime = System.currentTimeMillis();

        // When: Process message
        listener.handleScreeningRequest(event, message, channel);

        long afterTime = System.currentTimeMillis();

        // Then: Should track metadata
        ArgumentCaptor<Message> messageCaptor = ArgumentCaptor.forClass(Message.class);
        verify(rabbitTemplate).send(anyString(), anyString(), messageCaptor.capture());

        Message sentMessage = messageCaptor.getValue();
        MessageProperties props = sentMessage.getMessageProperties();

        assertEquals(1, props.getHeader(MessageMetadata.HEADER_RETRY_COUNT));
        assertEquals("Test error", props.getHeader(MessageMetadata.HEADER_LAST_FAILURE_REASON));
        assertEquals("TASK-META", props.getHeader(MessageMetadata.HEADER_TASK_ID));

        Long firstFailureTime = (Long) props.getHeader(MessageMetadata.HEADER_FIRST_FAILURE_TIME);
        assertNotNull(firstFailureTime);
        assertTrue(firstFailureTime >= beforeTime && firstFailureTime <= afterTime);

        Long lastFailureTime = (Long) props.getHeader(MessageMetadata.HEADER_LAST_FAILURE_TIME);
        assertNotNull(lastFailureTime);
        assertTrue(lastFailureTime >= beforeTime && lastFailureTime <= afterTime);
    }

    @Test
    void testEndToEndFlow_ConcurrentMessages() throws IOException, InterruptedException {
        // Given: Multiple messages processed concurrently
        int messageCount = 10;
        Thread[] threads = new Thread[messageCount];

        // When: Process messages concurrently
        for (int i = 0; i < messageCount; i++) {
            final int index = i;
            threads[i] = new Thread(() -> {
                try {
                    Event event = createEvent("EVENT-" + index, "TASK-" + index);
                    Message message = createMessage(0);
                    doNothing().when(fulfillmentService).fulfill("TASK-" + index);
                    listener.handleScreeningRequest(event, message, channel);
                } catch (IOException e) {
                    fail("IOException during concurrent processing");
                }
            });
            threads[i].start();
        }

        // Wait for all threads
        for (Thread thread : threads) {
            thread.join();
        }

        // Then: All messages should be processed
        verify(fulfillmentService, times(messageCount)).fulfill(anyString());
        verify(channel, times(messageCount)).basicAck(anyLong(), eq(false));
    }

    @Test
    void testEndToEndFlow_MixedSuccessAndFailure() throws IOException {
        // Given: Mix of successful and failed messages
        // Success 1
        Event event1 = createEvent("EVENT-1", "TASK-1");
        Message message1 = createMessage(0);
        doNothing().when(fulfillmentService).fulfill("TASK-1");
        listener.handleScreeningRequest(event1, message1, channel);

        // Failure 1
        reset(rabbitTemplate);
        Event event2 = createEvent("EVENT-2", "TASK-2");
        Message message2 = createMessage(0);
        doThrow(new RuntimeException("Error")).when(fulfillmentService).fulfill("TASK-2");
        listener.handleScreeningRequest(event2, message2, channel);

        // Success 2
        reset(rabbitTemplate);
        Event event3 = createEvent("EVENT-3", "TASK-3");
        Message message3 = createMessage(0);
        doNothing().when(fulfillmentService).fulfill("TASK-3");
        listener.handleScreeningRequest(event3, message3, channel);

        // Then: Circuit should still be CLOSED (not enough failures)
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreakerService.getState());
        verify(fulfillmentService, times(3)).fulfill(anyString());
    }

    // Helper methods
    private Event createEvent(String eventId, String taskId) {
        return new Event(eventId, List.of(new Parameter("taskID", taskId)));
    }

    private Message createMessage(int retryCount) {
        MessageProperties properties = new MessageProperties();
        properties.setDeliveryTag(1L);
        if (retryCount > 0) {
            properties.setHeader(MessageMetadata.HEADER_RETRY_COUNT, retryCount);
        }
        return new Message("{\"test\":\"data\"}".getBytes(), properties);
    }
}

