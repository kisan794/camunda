package hireright.applications.fulfillment_task_api.rest.recombointegration.listener;

import com.rabbitmq.client.Channel;
import hireright.applications.fulfillment_task_api.model.recombointegration.listener.Event;
import hireright.applications.fulfillment_task_api.model.recombointegration.listener.Parameter;
import hireright.applications.fulfillment_task_api.rest.recombointegration.circuitbreaker.CircuitBreakerService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.model.MessageMetadata;
import hireright.applications.fulfillment_task_api.rest.recombointegration.retry.RetryMessagePublisher;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;

import java.io.IOException;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ScreeningRequestListener.
 * Tests listener behavior with circuit breaker and retry integration.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
class ScreeningRequestListenerTest {

    @Mock
    private FulfillmentService fulfillmentService;

    @Mock
    private RetryMessagePublisher retryMessagePublisher;

    @Mock
    private CircuitBreakerService circuitBreakerService;

    @Mock
    private Channel channel;

    private ScreeningRequestListener listener;

    @BeforeEach
    void setUp() {
        listener = new ScreeningRequestListener(
                fulfillmentService,
                retryMessagePublisher,
                circuitBreakerService
        );
    }

    @Test
    void testSuccessfulProcessing_ShouldAckMessage() throws IOException {
        // Given: A valid event and circuit breaker is CLOSED
        Event event = createEvent("EVENT-123", "TASK-456");
        Message message = createMessage(0);
        when(circuitBreakerService.allowRequest()).thenReturn(true);
        doNothing().when(fulfillmentService).fulfill(anyString());

        // When: Handle screening request
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should process and ACK message
        verify(fulfillmentService).fulfill("TASK-456");
        verify(channel).basicAck(anyLong(), eq(false));
        verify(circuitBreakerService).recordSuccess();
        verify(retryMessagePublisher, never()).publishForRetry(any(), any(), any());
    }

    @Test
    void testCircuitBreakerOpen_ShouldRouteToRetryQueue() throws IOException {
        // Given: Circuit breaker is OPEN
        Event event = createEvent("EVENT-123", "TASK-456");
        Message message = createMessage(0);
        when(circuitBreakerService.allowRequest()).thenReturn(false);

        // When: Handle screening request
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should route to retry queue without calling fulfillment service
        verify(fulfillmentService, never()).fulfill(anyString());
        verify(retryMessagePublisher).publishForRetry(eq(message), contains("Circuit breaker is OPEN"), eq("TASK-456"));
        verify(channel).basicAck(anyLong(), eq(false));
    }

    @Test
    void testProcessingFailure_ShouldRouteToRetryQueue() throws IOException {
        // Given: Fulfillment service throws exception
        Event event = createEvent("EVENT-123", "TASK-789");
        Message message = createMessage(0);
        when(circuitBreakerService.allowRequest()).thenReturn(true);
        doThrow(new RuntimeException("External system error")).when(fulfillmentService).fulfill(anyString());

        // When: Handle screening request
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should route to retry queue and record failure
        verify(circuitBreakerService).recordFailure(contains("External system error"));
        verify(retryMessagePublisher).publishForRetry(eq(message), contains("External system error"), eq("TASK-789"));
        verify(channel).basicAck(anyLong(), eq(false));
    }

    @Test
    void testRetryAttempt_ShouldLogRetryCount() throws IOException {
        // Given: A message with retry count > 0
        Event event = createEvent("EVENT-123", "TASK-999");
        Message message = createMessage(2);
        when(circuitBreakerService.allowRequest()).thenReturn(true);
        doNothing().when(fulfillmentService).fulfill(anyString());

        // When: Handle screening request
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should process successfully
        verify(fulfillmentService).fulfill("TASK-999");
        verify(channel).basicAck(anyLong(), eq(false));
    }

    @Test
    void testMissingTaskId_ShouldNackMessage() throws IOException {
        // Given: Event without taskID parameter
        Event event = new Event("EVENT-123", List.of());
        Message message = createMessage(0);

        // When: Handle screening request
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should NACK message
        verify(fulfillmentService, never()).fulfill(anyString());
        verify(channel).basicNack(anyLong(), eq(false), eq(false));
        verify(retryMessagePublisher, never()).publishForRetry(any(), any(), any());
    }

    @Test
    void testCircuitBreakerNull_ShouldProcessNormally() throws IOException {
        // Given: Circuit breaker is null (disabled)
        listener = new ScreeningRequestListener(
                fulfillmentService,
                retryMessagePublisher,
                null
        );
        Event event = createEvent("EVENT-123", "TASK-111");
        Message message = createMessage(0);
        doNothing().when(fulfillmentService).fulfill(anyString());

        // When: Handle screening request
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should process normally without circuit breaker
        verify(fulfillmentService).fulfill("TASK-111");
        verify(channel).basicAck(anyLong(), eq(false));
    }

    @Test
    void testRetryPublisherFailure_ShouldNackMessage() throws IOException {
        // Given: Retry publisher throws exception
        Event event = createEvent("EVENT-123", "TASK-222");
        Message message = createMessage(0);
        when(circuitBreakerService.allowRequest()).thenReturn(true);
        doThrow(new RuntimeException("Processing error")).when(fulfillmentService).fulfill(anyString());
        doThrow(new RuntimeException("Retry publisher error")).when(retryMessagePublisher)
                .publishForRetry(any(), any(), any());

        // When: Handle screening request
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should NACK message
        verify(channel).basicNack(anyLong(), eq(false), eq(false));
    }

    @Test
    void testChannelAckFailure_ShouldThrowException() throws IOException {
        // Given: Channel ACK throws IOException
        Event event = createEvent("EVENT-123", "TASK-333");
        Message message = createMessage(0);
        when(circuitBreakerService.allowRequest()).thenReturn(true);
        doNothing().when(fulfillmentService).fulfill(anyString());
        doThrow(new IOException("Channel error")).when(channel).basicAck(anyLong(), anyBoolean());

        // When/Then: Should propagate exception
        try {
            listener.handleScreeningRequest(event, message, channel);
        } catch (Exception e) {
            // Expected
        }

        verify(fulfillmentService).fulfill("TASK-333");
    }

    @Test
    void testMultipleParameters_ShouldExtractTaskId() throws IOException {
        // Given: Event with multiple parameters including taskID
        Event event = new Event("EVENT-123", List.of(
                new Parameter("orderId", "ORDER-999"),
                new Parameter("taskID", "TASK-444"),
                new Parameter("type", "employment")
        ));
        Message message = createMessage(0);
        when(circuitBreakerService.allowRequest()).thenReturn(true);
        doNothing().when(fulfillmentService).fulfill(anyString());

        // When: Handle screening request
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should extract correct taskID
        verify(fulfillmentService).fulfill("TASK-444");
        verify(channel).basicAck(anyLong(), eq(false));
    }

    @Test
    void testCaseInsensitiveTaskIdParameter() throws IOException {
        // Given: Event with lowercase "taskid" parameter
        Event event = new Event("EVENT-123", List.of(
                new Parameter("taskid", "TASK-555")
        ));
        Message message = createMessage(0);
        when(circuitBreakerService.allowRequest()).thenReturn(true);
        doNothing().when(fulfillmentService).fulfill(anyString());

        // When: Handle screening request
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should extract taskID (case-insensitive)
        verify(fulfillmentService).fulfill("TASK-555");
        verify(channel).basicAck(anyLong(), eq(false));
    }

    @Test
    void testCircuitBreakerMetricsLogging() throws IOException {
        // Given: Processing failure with circuit breaker
        Event event = createEvent("EVENT-123", "TASK-666");
        Message message = createMessage(0);
        when(circuitBreakerService.allowRequest()).thenReturn(true);
        when(circuitBreakerService.getMetrics()).thenReturn("CircuitBreaker[state=CLOSED, failures=1]");
        doThrow(new RuntimeException("Test error")).when(fulfillmentService).fulfill(anyString());

        // When: Handle screening request
        listener.handleScreeningRequest(event, message, channel);

        // Then: Should call getMetrics for logging
        verify(circuitBreakerService).getMetrics();
        verify(circuitBreakerService).recordFailure(anyString());
    }

    @Test
    void testFirstFailureVsRetry_DifferentLogging() throws IOException {
        // Test 1: First attempt (retry count = 0)
        Event event1 = createEvent("EVENT-123", "TASK-777");
        Message message1 = createMessage(0);
        when(circuitBreakerService.allowRequest()).thenReturn(true);
        doNothing().when(fulfillmentService).fulfill(anyString());

        listener.handleScreeningRequest(event1, message1, channel);

        verify(fulfillmentService).fulfill("TASK-777");

        // Test 2: Retry attempt (retry count = 1)
        Event event2 = createEvent("EVENT-124", "TASK-888");
        Message message2 = createMessage(1);

        listener.handleScreeningRequest(event2, message2, channel);

        verify(fulfillmentService).fulfill("TASK-888");
    }

    // Helper methods
    private Event createEvent(String eventId, String taskId) {
        return new Event(eventId, List.of(new Parameter("taskID", taskId)));
    }

    private Message createMessage(int retryCount) {
        MessageProperties properties = new MessageProperties();
        properties.setDeliveryTag(1L);
        if (retryCount > 0) {
            properties.setHeader(MessageMetadata.HEADER_RETRY_COUNT, retryCount);
        }
        return new Message("{\"test\":\"data\"}".getBytes(), properties);
    }
}

