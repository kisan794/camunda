package hireright.applications.fulfillment_task_api.rest.recombointegration.circuitbreaker;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for CircuitBreakerService.
 * Tests state transitions, thresholds, and failure/success tracking.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
class CircuitBreakerServiceTest {

    private CircuitBreakerService circuitBreaker;

    @BeforeEach
    void setUp() {
        circuitBreaker = new CircuitBreakerService();
        // Set test configuration values
        ReflectionTestUtils.setField(circuitBreaker, "failureThreshold", 5);
        ReflectionTestUtils.setField(circuitBreaker, "successThreshold", 2);
        ReflectionTestUtils.setField(circuitBreaker, "timeoutDuration", 60000L);
        ReflectionTestUtils.setField(circuitBreaker, "slidingWindowSize", 10);
        circuitBreaker.init();
    }

    @Test
    void testInitialState_ShouldBeClosed() {
        // Given: Fresh circuit breaker
        // When: Check initial state
        CircuitBreakerService.State state = circuitBreaker.getState();

        // Then: Should be CLOSED
        assertEquals(CircuitBreakerService.State.CLOSED, state);
        assertTrue(circuitBreaker.allowRequest());
    }

    @Test
    void testClosedToOpen_WhenFailureThresholdReached() {
        // Given: Circuit breaker in CLOSED state
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreaker.getState());

        // When: Record failures up to threshold (5)
        for (int i = 0; i < 5; i++) {
            circuitBreaker.recordFailure("Test failure " + i);
        }

        // Then: Circuit should be OPEN
        assertEquals(CircuitBreakerService.State.OPEN, circuitBreaker.getState());
        assertFalse(circuitBreaker.allowRequest(), "Circuit should reject requests when OPEN");
    }

    @Test
    void testClosedState_AllowsRequests() {
        // Given: Circuit breaker in CLOSED state
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreaker.getState());

        // When: Check if requests are allowed
        boolean allowed = circuitBreaker.allowRequest();

        // Then: Requests should be allowed
        assertTrue(allowed);
    }

    @Test
    void testOpenState_RejectsRequests() {
        // Given: Circuit breaker in OPEN state
        for (int i = 0; i < 5; i++) {
            circuitBreaker.recordFailure("Test failure");
        }
        assertEquals(CircuitBreakerService.State.OPEN, circuitBreaker.getState());

        // When: Try to make a request
        boolean allowed = circuitBreaker.allowRequest();

        // Then: Request should be rejected
        assertFalse(allowed);
    }

    @Test
    void testOpenToHalfOpen_AfterTimeout() throws InterruptedException {
        // Given: Circuit breaker in OPEN state
        ReflectionTestUtils.setField(circuitBreaker, "timeoutDuration", 100L); // 100ms for testing
        circuitBreaker.init();
        
        for (int i = 0; i < 5; i++) {
            circuitBreaker.recordFailure("Test failure");
        }
        assertEquals(CircuitBreakerService.State.OPEN, circuitBreaker.getState());

        // When: Wait for timeout
        Thread.sleep(150);

        // Then: Circuit should transition to HALF_OPEN
        boolean allowed = circuitBreaker.allowRequest();
        assertTrue(allowed, "Circuit should allow request after timeout");
        assertEquals(CircuitBreakerService.State.HALF_OPEN, circuitBreaker.getState());
    }

    @Test
    void testHalfOpenToClosed_WhenSuccessThresholdReached() throws InterruptedException {
        // Given: Circuit breaker in HALF_OPEN state
        ReflectionTestUtils.setField(circuitBreaker, "timeoutDuration", 100L);
        circuitBreaker.init();
        
        // Open the circuit
        for (int i = 0; i < 5; i++) {
            circuitBreaker.recordFailure("Test failure");
        }
        
        // Wait for timeout to transition to HALF_OPEN
        Thread.sleep(150);
        circuitBreaker.allowRequest(); // Trigger transition to HALF_OPEN
        assertEquals(CircuitBreakerService.State.HALF_OPEN, circuitBreaker.getState());

        // When: Record successes up to threshold (2)
        circuitBreaker.recordSuccess();
        circuitBreaker.recordSuccess();

        // Then: Circuit should be CLOSED
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreaker.getState());
        assertTrue(circuitBreaker.allowRequest());
    }

    @Test
    void testHalfOpenToOpen_OnFailure() throws InterruptedException {
        // Given: Circuit breaker in HALF_OPEN state
        ReflectionTestUtils.setField(circuitBreaker, "timeoutDuration", 100L);
        circuitBreaker.init();
        
        // Open the circuit
        for (int i = 0; i < 5; i++) {
            circuitBreaker.recordFailure("Test failure");
        }
        
        // Wait for timeout to transition to HALF_OPEN
        Thread.sleep(150);
        circuitBreaker.allowRequest(); // Trigger transition to HALF_OPEN
        assertEquals(CircuitBreakerService.State.HALF_OPEN, circuitBreaker.getState());

        // When: Record a failure
        circuitBreaker.recordFailure("Test failure in half-open");

        // Then: Circuit should be OPEN again
        assertEquals(CircuitBreakerService.State.OPEN, circuitBreaker.getState());
        assertFalse(circuitBreaker.allowRequest());
    }

    @Test
    void testSuccessInClosedState_ResetsFailureCount() {
        // Given: Circuit breaker with some failures
        circuitBreaker.recordFailure("Failure 1");
        circuitBreaker.recordFailure("Failure 2");
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreaker.getState());

        // When: Record a success
        circuitBreaker.recordSuccess();

        // Then: Should still be CLOSED and allow more failures before opening
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreaker.getState());
        
        // Should take 5 more failures to open (not 3)
        circuitBreaker.recordFailure("Failure 3");
        circuitBreaker.recordFailure("Failure 4");
        circuitBreaker.recordFailure("Failure 5");
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreaker.getState());
        
        circuitBreaker.recordFailure("Failure 6");
        circuitBreaker.recordFailure("Failure 7");
        assertEquals(CircuitBreakerService.State.OPEN, circuitBreaker.getState());
    }

    @Test
    void testGetMetrics_ReturnsCorrectInformation() {
        // Given: Circuit breaker with some activity
        circuitBreaker.recordSuccess();
        circuitBreaker.recordSuccess();
        circuitBreaker.recordFailure("Test failure");

        // When: Get metrics
        String metrics = circuitBreaker.getMetrics();

        // Then: Metrics should contain state and counts
        assertNotNull(metrics);
        assertTrue(metrics.contains("state=CLOSED"));
        assertTrue(metrics.contains("failures="));
        assertTrue(metrics.contains("successes="));
    }

    @Test
    void testConcurrentAccess_ThreadSafety() throws InterruptedException {
        // Given: Multiple threads accessing circuit breaker
        int threadCount = 10;
        Thread[] threads = new Thread[threadCount];

        // When: Multiple threads record failures concurrently
        for (int i = 0; i < threadCount; i++) {
            threads[i] = new Thread(() -> {
                for (int j = 0; j < 10; j++) {
                    circuitBreaker.recordFailure("Concurrent failure");
                    try {
                        Thread.sleep(1);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
            });
            threads[i].start();
        }

        // Wait for all threads to complete
        for (Thread thread : threads) {
            thread.join();
        }

        // Then: Circuit should be OPEN (thread-safe state management)
        assertEquals(CircuitBreakerService.State.OPEN, circuitBreaker.getState());
    }

    @Test
    void testReset_ResetsToClosedState() {
        // Given: Circuit breaker in OPEN state
        for (int i = 0; i < 5; i++) {
            circuitBreaker.recordFailure("Test failure");
        }
        assertEquals(CircuitBreakerService.State.OPEN, circuitBreaker.getState());

        // When: Reset the circuit breaker
        circuitBreaker.reset();

        // Then: Should be CLOSED and allow requests
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreaker.getState());
        assertTrue(circuitBreaker.allowRequest());
    }

    @Test
    void testFailureRateCalculation_InSlidingWindow() {
        // Given: Circuit breaker with sliding window
        // When: Record mix of successes and failures
        circuitBreaker.recordSuccess();
        circuitBreaker.recordSuccess();
        circuitBreaker.recordFailure("Failure 1");
        circuitBreaker.recordSuccess();
        circuitBreaker.recordFailure("Failure 2");

        // Then: Metrics should reflect the failure rate
        String metrics = circuitBreaker.getMetrics();
        assertTrue(metrics.contains("failureRate="));
    }

    @Test
    void testMultipleStateTransitions() throws InterruptedException {
        // Given: Circuit breaker with short timeout
        ReflectionTestUtils.setField(circuitBreaker, "timeoutDuration", 100L);
        circuitBreaker.init();

        // Scenario: CLOSED -> OPEN -> HALF_OPEN -> CLOSED
        
        // 1. Start in CLOSED
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreaker.getState());
        
        // 2. Transition to OPEN
        for (int i = 0; i < 5; i++) {
            circuitBreaker.recordFailure("Failure " + i);
        }
        assertEquals(CircuitBreakerService.State.OPEN, circuitBreaker.getState());
        
        // 3. Wait and transition to HALF_OPEN
        Thread.sleep(150);
        circuitBreaker.allowRequest();
        assertEquals(CircuitBreakerService.State.HALF_OPEN, circuitBreaker.getState());
        
        // 4. Transition back to CLOSED
        circuitBreaker.recordSuccess();
        circuitBreaker.recordSuccess();
        assertEquals(CircuitBreakerService.State.CLOSED, circuitBreaker.getState());
    }
}

