# Circuit Breaker & Retry Queue Architecture

## Overview

This document describes the resilient system architecture implemented for integrating with external third-party systems (Recombo AI) using asynchronous messaging with RabbitMQ. The architecture protects the internal system from cascading failures caused by external system instability.

## Problem Statement

The system integrates with an external HTTP-based system that is outside our operational control. External system failures may include:

- Temporary unavailability or downtime
- Slow response times or timeouts
- Throttling or rate limiting
- Transient failures (HTTP 503 Service Unavailable)

## Architecture Components

### 1. Circuit Breaker Pattern

**Location**: `CircuitBreakerService.java`

The Circuit Breaker protects the system from cascading failures by monitoring external system health and preventing requests when the system is known to be unavailable.

#### States

- **CLOSED**: Normal operation, all requests pass through
- **OPEN**: Circuit is open, requests fail fast without calling external system
- **HALF_OPEN**: Testing if external system has recovered

#### Configuration

```yaml
circuit-breaker:
  enabled: true
  failure-threshold: 5        # Failures before opening circuit
  success-threshold: 2        # Successes to close circuit
  timeout-duration: 60000     # Time to wait before attempting half-open (ms)
  sliding-window-size: 10     # Number of calls to track
```

#### State Transitions

1. **CLOSED → OPEN**: When failure count reaches threshold (5 failures)
2. **OPEN → HALF_OPEN**: After timeout duration elapses (60 seconds)
3. **HALF_OPEN → CLOSED**: After success threshold is met (2 successes)
4. **HALF_OPEN → OPEN**: On any failure

### 2. Retry Queue Mechanism

**Location**: `RetryMessagePublisher.java`, `RabbitMQConfig.java`

Messages that fail processing are routed through a series of retry queues with progressive delays:

- **R1Q (Retry Queue 1)**: 30 seconds delay
- **R2Q (Retry Queue 2)**: 2 minutes delay
- **R3Q (Retry Queue 3)**: 5 minutes delay
- **DLQ (Dead Letter Queue)**: Final destination after max retries

#### How It Works

1. Message fails processing in Main Queue
2. Message is published to R1Q with retry count = 1
3. After TTL expires (30s), message returns to Main Queue
4. If it fails again, goes to R2Q with retry count = 2
5. Process continues through R3Q
6. After max retries (3), message goes to DLQ

### 3. Message Metadata Tracking

**Location**: `MessageMetadata.java`

Each message carries metadata in RabbitMQ headers:

- `x-retry-count`: Current retry attempt number
- `x-first-failure-time`: Timestamp of first failure
- `x-last-failure-time`: Timestamp of most recent failure
- `x-last-failure-reason`: Reason for last failure
- `x-original-queue`: Original queue name
- `x-task-id`: Task ID for tracking

## Message Flow

### Successful Processing

```
Producer → Exchange → Main Queue → Listener → Circuit Breaker (CLOSED) 
→ Fulfillment Service → External System (200 OK) → ACK → Success
```

### Failed Processing with Retry

```
Producer → Exchange → Main Queue → Listener → Circuit Breaker (CLOSED)
→ Fulfillment Service → External System (503) → Retry Publisher → R1Q
→ [30s delay] → Main Queue → Listener → ... → R2Q
→ [2min delay] → Main Queue → Listener → ... → R3Q
→ [5min delay] → Main Queue → Listener → ... → DLQ
```

### Circuit Breaker Open

```
Producer → Exchange → Main Queue → Listener → Circuit Breaker (OPEN)
→ Retry Publisher → R1Q (fail fast, no external call)
```

## Configuration

### RabbitMQ Queues

```yaml
rabbitmq:
  enabled: true
  exchange: fulfilment_task_api.direct
  queue:
    screening-requests: fulfillment_task_api.screening_request.queue
    screening-dlq: fulfillment_task_api.screening_request.dlq.queue
    retry-1: fulfillment_task_api.screening_request.retry1.queue
    retry-2: fulfillment_task_api.screening_request.retry2.queue
    retry-3: fulfillment_task_api.screening_request.retry3.queue
  routing:
    screening-requests: screening_request
    screening-dlq: dead_letter
    retry-1: retry_1
    retry-2: retry_2
    retry-3: retry_3
  retry:
    max-attempts: 3
    delay-r1: 30000   # 30 seconds
    delay-r2: 120000  # 2 minutes
    delay-r3: 300000  # 5 minutes
```

## Key Features

### 1. Fault Tolerance

- **No Message Loss**: Messages are persisted in RabbitMQ queues
- **Automatic Retry**: Failed messages automatically retry with progressive delays
- **Circuit Protection**: Circuit breaker prevents overwhelming failed external systems

### 2. Operational Visibility

- **Detailed Logging**: All failures logged with correlation IDs
- **Metadata Tracking**: Complete failure history in message headers
- **Circuit Metrics**: Real-time circuit breaker state and metrics

### 3. Manual Intervention

- **DLQ for Failed Messages**: Messages that exceed max retries go to DLQ
- **Manual Reprocessing**: DLQ messages can be manually inspected and reprocessed
- **Circuit Reset**: Circuit breaker can be manually reset if needed

## Implementation Details

### Modified Components

1. **ScreeningRequestListener**
   - Integrated circuit breaker checks
   - Added retry logic with metadata tracking
   - Improved error handling and logging

2. **FulfillmentServiceImpl**
   - Added circuit breaker integration
   - Records success/failure in circuit breaker
   - Enhanced async response handling

3. **RabbitMQConfig**
   - Added retry queue declarations (R1Q, R2Q, R3Q)
   - Configured TTL and dead-letter routing
   - Set up bindings for retry flow

### New Components

1. **CircuitBreakerService**
   - Implements circuit breaker pattern
   - Tracks failure/success rates
   - Manages state transitions

2. **RetryMessagePublisher**
   - Routes failed messages to appropriate retry queues
   - Manages retry count and metadata
   - Publishes to DLQ after max retries

3. **MessageMetadata**
   - Model for message retry metadata
   - Header constants for RabbitMQ
   - Tracking failure history

## Monitoring and Metrics

### Circuit Breaker Metrics

```java
circuitBreakerService.getMetrics()
// Returns: "CircuitBreaker[state=CLOSED, failures=2, successes=8, failureRate=20.00%]"
```

### Log Messages

- Circuit state transitions
- Retry attempts with counts
- Failure reasons and timestamps
- DLQ routing events

## Testing Scenarios

### Scenario 1: Temporary External System Failure

1. External system returns 503
2. Message goes to R1Q (30s delay)
3. External system recovers
4. Message successfully processes on retry

### Scenario 2: Prolonged Outage

1. External system down for 10 minutes
2. Circuit breaker opens after 5 failures
3. Subsequent messages fail fast (no external calls)
4. Messages retry through R1Q → R2Q → R3Q
5. After timeout, circuit attempts HALF_OPEN
6. If system recovered, circuit closes

### Scenario 3: Permanent Failure

1. Message fails all retry attempts
2. Goes through R1Q → R2Q → R3Q
3. After 3 retries, sent to DLQ
4. Operations team investigates DLQ
5. Manual intervention or reprocessing

## Benefits

1. **System Resilience**: Protects internal system from external failures
2. **No Message Loss**: All messages preserved through retry mechanism
3. **Automatic Recovery**: System automatically recovers when external system is available
4. **Operational Control**: DLQ provides manual intervention point
5. **Performance**: Circuit breaker prevents wasted resources on failed systems
6. **Visibility**: Comprehensive logging and metrics for monitoring

## Future Enhancements

1. **Metrics Dashboard**: Grafana dashboard for circuit breaker metrics
2. **Alerting**: Alerts when circuit opens or DLQ threshold exceeded
3. **Dynamic Configuration**: Runtime adjustment of thresholds and delays
4. **DLQ Reprocessing**: Automated DLQ reprocessing tool
5. **Rate Limiting**: Additional rate limiting for external system protection

