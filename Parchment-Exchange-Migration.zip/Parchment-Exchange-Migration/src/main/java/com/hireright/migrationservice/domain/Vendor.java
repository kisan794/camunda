package com.hireright.migrationservice.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "vendor")
public class Vendor {
    
    @Id
    private String id;
    
    private Integer providerId;
    private String vendor;
    private String website;
    private Boolean cevApproved;
    private Boolean isBranchCodeEligible;
    private String location;
    private String organizationType;
}

