package com.hireright.migrationservice.controller;

import com.hireright.migrationservice.dto.InstitutionRecord;
import com.hireright.migrationservice.service.ExcelParserService;
import com.hireright.migrationservice.service.MigrationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/migration")
@RequiredArgsConstructor
public class MigrationController {
    
    private final ExcelParserService excelParserService;
    private final MigrationService migrationService;

    @PostMapping("/upload")
    public ResponseEntity<Map<String, Object>> uploadExcelFile(@RequestParam("file") MultipartFile file) {
        log.info("Received file upload request: {}", file.getOriginalFilename());

        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest()
                    .body(createErrorResponse("File is empty"));
            }

            String filename = file.getOriginalFilename();
            if (filename == null || (!filename.endsWith(".xlsx") && !filename.endsWith(".xls"))) {
                return ResponseEntity.badRequest()
                    .body(createErrorResponse("Invalid file format. Please upload an Excel file (.xlsx or .xls)"));
            }

            log.info("Parsing Excel file: {}", filename);
            List<InstitutionRecord> records = excelParserService.parseExcelFile(file);

            if (records.isEmpty()) {
                return ResponseEntity.badRequest()
                    .body(createErrorResponse("No records found in the Excel file"));
            }

            log.info("Found {} records in Excel file", records.size());

            Map<String, Object> result = migrationService.processInstitutionRecords(records);

            result.put("status", "success");
            result.put("message", "File processed successfully");
            result.put("filename", filename);

            log.info("Processing completed successfully");
            return ResponseEntity.ok(result);

        } catch (Exception e) {
            log.error("Error processing file", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(createErrorResponse("Error processing file: " + e.getMessage()));
        }
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "Parchment Exchange Migration Service");
        return ResponseEntity.ok(response);
    }

    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "error");
        response.put("message", message);
        return response;
    }
}

