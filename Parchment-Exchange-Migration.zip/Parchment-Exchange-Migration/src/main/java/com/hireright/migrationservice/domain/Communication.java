package com.hireright.migrationservice.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Communication {
    private String name;
    private List<CommunicationInfo> communicationInfo;
    private String providerID;
    private Integer priority;
    private String isPrimary;
    private String recipient;
}

