package com.hireright.migrationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@EnableMongoRepositories(basePackages = "com.hireright.migrationservice.repository")
public class MigrationServiceApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(MigrationServiceApplication.class, args);
    }
}

