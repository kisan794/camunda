package com.hireright.migrationservice.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Payload {
    private String departmentName;
    private String website;
    private List<Object> address;
    private String notes;
    private String contactPersonTitle;
    private List<String> infoRequestIDs;
    private List<Object> addionalInfo;
    private String contactPersonName;
    private Boolean dotRegulated;
    private String lastValidatedDateTime;
    private Boolean documentationRequired;
    private Boolean unAccreditedSource;
    private String lastUsedDateTime;
    private List<Contact> contacts;
    private Integer usedCount;
}

