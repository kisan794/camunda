package com.hireright.migrationservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InstitutionRecord {
    private String institutionName;
    private String country;
    private String city;
    private String stateCountyRegion;
    private String serviceProvider;
    private String surchargeAmount;
    private String paymentMethod;
    private String code;
    private String turnaroundTime;
    private String followUpAllowed;
}

