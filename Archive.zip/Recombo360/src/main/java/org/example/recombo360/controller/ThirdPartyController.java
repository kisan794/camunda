/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package org.example.recombo360.controller;

import org.example.recombo360.dto.ThirdPartySubmitRequest;
import org.example.recombo360.service.ThirdPartyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/recombo-third-part/api")
public class ThirdPartyController {

    private static final Logger logger = LoggerFactory.getLogger(ThirdPartyController.class);

    private final ThirdPartyService thirdPartyService;

    public ThirdPartyController(ThirdPartyService thirdPartyService) {
        this.thirdPartyService = thirdPartyService;
    }

    @PostMapping("/submit")
    public ResponseEntity<Map<String, Object>> submit(@RequestBody ThirdPartySubmitRequest request) {
        logger.info("Received submit request with ID: {}", request.getId());

        // Determine request type
        String requestType = thirdPartyService.determineRequestType(request);
        logger.info("Request type: {}", requestType);

        // Submit asynchronously (will execute in a different thread with 5-second delay)
        CompletableFuture<Map<String, Object>> futureResponse = thirdPartyService.submitRequestAsync(request);

        // Immediately return acceptance response
        Map<String, Object> response = new HashMap<>();
        response.put("id", request.getId());
        response.put("status", "ACCEPTED");
        response.put("message", "Request accepted and will be processed asynchronously");
        response.put("type", requestType);

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
    }
}

