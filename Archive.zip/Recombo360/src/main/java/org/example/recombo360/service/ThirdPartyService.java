/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package org.example.recombo360.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.recombo360.dto.ThirdPartySubmitRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class ThirdPartyService {

    private static final Logger logger = LoggerFactory.getLogger(ThirdPartyService.class);

    private final WebClient webClient;
    private final ObjectMapper objectMapper;

    @Value("${fulfillment.submit.api.url:http://localhost:8080/api/submit}")
    private String fulfillmentSubmitUrl;

    public ThirdPartyService(WebClient.Builder webClientBuilder, ObjectMapper objectMapper) {
        this.webClient = webClientBuilder.build();
        this.objectMapper = objectMapper;
    }

    /**
     * Determines if the request is for education or employment based on the refid field
     */
    public String determineRequestType(ThirdPartySubmitRequest request) {
        String refid = request.getRefid();
        if (refid != null) {
            if (refid.contains("-ED-")) {
                return "education";
            } else if (refid.contains("-EM-")) {
                return "employment";
            }
        }
        
        // Fallback: check dataSource type in request
        if (request.getRequest() != null) {
            Map<String, Object> requestMap = request.getRequest();
            if (requestMap.containsKey("dataSource")) {
                @SuppressWarnings("unchecked")
                Map<String, Object> dataSource = (Map<String, Object>) requestMap.get("dataSource");
                if (dataSource != null && dataSource.containsKey("type")) {
                    return (String) dataSource.get("type");
                }
            }
        }
        
        return "unknown";
    }

    /**
     * Submits the request asynchronously with a 5-second delay
     */
    @Async
    public CompletableFuture<Map<String, Object>> submitRequestAsync(ThirdPartySubmitRequest request) {
        logger.info("Starting async submission for request ID: {}", request.getId());

        try {
            // 5-second delay
            Thread.sleep(5000);

            String requestType = determineRequestType(request);
            logger.info("Request type determined: {}", requestType);

            // Get mocked response based on type
            Map<String, Object> mockedResponse = getMockedResponse(requestType, request.getId());

            // Call fulfillment API with mocked response as request body
            callFulfillmentApi(mockedResponse);

            logger.info("Async submission completed for request ID: {}", request.getId());
            return CompletableFuture.completedFuture(mockedResponse);

        } catch (InterruptedException e) {
            logger.error("Thread interrupted during async submission", e);
            Thread.currentThread().interrupt();
            return CompletableFuture.completedFuture(Map.of(
                "id", request.getId(),
                "status", "FAILED",
                "message", "Request interrupted"
            ));
        } catch (Exception e) {
            logger.error("Error during async submission", e);
            return CompletableFuture.completedFuture(Map.of(
                "id", request.getId(),
                "status", "FAILED",
                "message", e.getMessage()
            ));
        }
    }

    /**
     * Calls the fulfillment API with mocked response as request body
     */
    private void callFulfillmentApi(Map<String, Object> mockedResponse) {
        logger.info("Calling fulfillment API at: {} with mocked response", fulfillmentSubmitUrl);

        try {
            webClient.post()
                .uri(fulfillmentSubmitUrl)
                .bodyValue(mockedResponse)
                .retrieve()
                .toBodilessEntity()
                .block();

            logger.info("Fulfillment API call successful with mocked response: {}", mockedResponse);
        } catch (Exception e) {
            logger.error("Failed to call fulfillment API", e);
            // Continue even if API call fails
        }
    }

    /**
     * Loads and returns the mocked response based on request type and ID
     * For employment: searches through SUBMIT-RESPONSE-001 to 005 files to find matching ID
     * For education: uses EDUCATION-SUBMIT-RESPONSE.json
     */
    private Map<String, Object> getMockedResponse(String requestType, String requestId) {
        logger.info("Getting mocked response for type: {} and ID: {}", requestType, requestId);

        if ("employment".equalsIgnoreCase(requestType)) {
            // Search through all 5 SUBMIT-RESPONSE files to find matching ID
            for (int i = 1; i <= 5; i++) {
                String mockFile = String.format("mock/SUBMIT-RESPONSE-%03d.json", i);
                try {
                    ClassPathResource resource = new ClassPathResource(mockFile);
                    @SuppressWarnings("unchecked")
                    Map<String, Object> response = objectMapper.readValue(resource.getInputStream(), Map.class);

                    // Check if this response matches the request ID
                    if (matchesRequestId(response, requestId)) {
                        logger.info("Found matching mock response in file: {}", mockFile);
                        return response;
                    }
                } catch (IOException e) {
                    logger.warn("Failed to load mock response from {}: {}", mockFile, e.getMessage());
                }
            }

            // If no match found, return the first one as default
            logger.warn("No matching mock response found for ID: {}, using default", requestId);
            return loadDefaultEmploymentResponse();

        } else if ("education".equalsIgnoreCase(requestType)) {
            // For education, use the dedicated file
            try {
                ClassPathResource resource = new ClassPathResource("mock/EDUCATION-SUBMIT-RESPONSE.json");
                @SuppressWarnings("unchecked")
                Map<String, Object> response = objectMapper.readValue(resource.getInputStream(), Map.class);
                logger.info("Loaded education mock response");
                return response;
            } catch (IOException e) {
                logger.error("Failed to load education mock response", e);
                return createErrorResponse("Failed to load education mock response: " + e.getMessage());
            }
        } else {
            // Unknown type
            return createErrorResponse("Unknown request type: " + requestType);
        }
    }

    /**
     * Checks if the mock response matches the request ID
     * Compares the subject field in the response with the request ID
     */
    private boolean matchesRequestId(Map<String, Object> response, String requestId) {
        try {
            @SuppressWarnings("unchecked")
            Map<String, Object> responseObj = (Map<String, Object>) response.get("response");
            if (responseObj != null) {
                String subject = (String) responseObj.get("subject");
                if (subject != null) {
                    // Check if the subject contains the request ID or vice versa
                    return subject.contains(requestId) || requestId.contains(subject);
                }
            }
        } catch (Exception e) {
            logger.warn("Error checking ID match: {}", e.getMessage());
        }
        return false;
    }

    /**
     * Loads the default employment response (SUBMIT-RESPONSE-001.json)
     */
    private Map<String, Object> loadDefaultEmploymentResponse() {
        try {
            ClassPathResource resource = new ClassPathResource("mock/SUBMIT-RESPONSE-001.json");
            @SuppressWarnings("unchecked")
            Map<String, Object> response = objectMapper.readValue(resource.getInputStream(), Map.class);
            logger.info("Loaded default employment mock response");
            return response;
        } catch (IOException e) {
            logger.error("Failed to load default employment mock response", e);
            return createErrorResponse("Failed to load default employment mock response: " + e.getMessage());
        }
    }

    /**
     * Creates an error response
     */
    private Map<String, Object> createErrorResponse(String errorMessage) {
        return Map.of(
            "response", Map.of(
                "subject", "hrg:hre:task:ERROR",
                "dataschema", "tasks/ErrorFulfilmentTaskResult",
                "datacontenttype", "application/json",
                "data", Map.of(
                    "decision", "ERROR",
                    "decisionDescription", errorMessage
                )
            )
        );
    }
}

