/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package org.example.recombo360.dto;

public class Data {
	private String decision;
	private String decisionDescription;
	private ResultData resultData;

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public String getDecisionDescription() {
		return decisionDescription;
	}

	public void setDecisionDescription(String decisionDescription) {
		this.decisionDescription = decisionDescription;
	}

	public ResultData getResultData() {
		return resultData;
	}

	public void setResultData(ResultData resultData) {
		this.resultData = resultData;
	}
}
