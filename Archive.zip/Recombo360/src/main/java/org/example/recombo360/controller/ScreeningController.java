package org.example.recombo360.controller;

import org.example.recombo360.dto.ScreeningRequest;
import org.example.recombo360.dto.VerificationRequest;
import org.example.recombo360.service.ScreeningService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/recombo/api")
public class ScreeningController {

    private final ScreeningService screeningService;

    public ScreeningController(ScreeningService screeningService) {
        this.screeningService = screeningService;
    }

    @PostMapping("/screening")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<Map<String, Object>> submitScreening(@RequestBody ScreeningRequest request) {
        Map<String, Object> externalResponse = screeningService.callExternalService(request);
        Map<String, Object> response = new HashMap<>();
        response.put("status", "SUCCESS");
        response.put("data", externalResponse);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/verification")
    public ResponseEntity<Map<String, String>> submitVerification(@RequestBody VerificationRequest request) {
        HttpStatus status = screeningService.callVerificationService(request);
        Map<String, String> response = new HashMap<>();
        response.put("status", status.is2xxSuccessful() ? "SUCCESS" : "FAILED");
        return ResponseEntity.status(status).body(response);
    }
}

