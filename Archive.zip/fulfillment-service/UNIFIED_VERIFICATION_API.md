# Unified Verification API

## Overview
This is a unified REST API that handles both **Education** and **Employment** verification requests using a single endpoint with intelligent routing based on ID prefix. The API uses caching for performance and integrates with Recombo service for status checks and async data submission.

## Key Features

✅ **Single Endpoint** - One API endpoint handles both education and employment verification  
✅ **Intelligent Routing** - Automatically determines verification type based on ID prefix (EDU-* or EMP-*)  
✅ **Caching** - Mock data loaded once at startup and cached in memory  
✅ **Recombo Integration** - Calls Recombo service for status and submits data asynchronously  
✅ **Async Processing** - Non-blocking async POST to third-party endpoint  
✅ **Error Handling** - Comprehensive error handling with appropriate HTTP status codes  

## Architecture Flow

```
1. Client sends POST request with ID
   ↓
2. API determines type (EDU or EMP) from ID prefix
   ↓
3. Fetch verification data from cache
   ↓
4. Call Recombo service GET /status (synchronous)
   ↓
5. Send async POST to /submit endpoint (non-blocking)
   ↓
6. Return verification data + status to client
```

## Endpoint

### POST `/recombo-integration/api/verification`

Single unified endpoint for all verification requests.

## Request Format

```json
{
  "id": "EDU-001"
}
```

or

```json
{
  "id": "EMP-VF-001"
}
```

### Request Parameters
- `id` (String, required): The verification ID
  - **Education**: Must start with `EDU-` (e.g., EDU-001, EDU-002, etc.)
  - **Employment**: Must start with `EMP-` (e.g., EMP-VF-001, EMP-VF-002, etc.)

## Response Format

### Success Response (200 OK)

#### Education Verification Response

```json
{
  "status": "SUCCESS",
  "type": "EDUCATION",
  "message": "EDUCATION verification request processed successfully",
  "recomboStatus": "{\"status\":\"COMPLETED\",\"id\":\"EDU-001\"}",
  "data": {
    "id": "hrg:hre:data-request:111111111",
    "refid": "hrg:hre:order-item:HE-010101-AAAA11-ED-001",
    "request": {
      "hrgSource": {
        "product": {
          "sku": "VF-ED-IEDU-CORE-USA",
          "name": "Education Verification Report"
        },
        "institution": {
          "name": "New York University",
          "location": {
            "city": "New York",
            "region": "NY",
            "country": "US",
            "postalCode": "10003"
          }
        }
      }
    }
  }
}
```

#### Employment Verification Response

```json
{
  "status": "SUCCESS",
  "type": "EMPLOYMENT",
  "message": "EMPLOYMENT verification request processed successfully",
  "recomboStatus": "{\"status\":\"COMPLETED\",\"id\":\"EMP-VF-001\"}",
  "data": {
    "id": "hrg:hre:data-request:100001001",
    "refid": "hrg:hre:order-item:HE-030101-ABCD12-EM-001",
    "request": {
      "hrgSource": {
        "product": {
          "sku": "VF-EM-IEMP-CORE-USA",
          "name": "Employment Verification Report"
        },
        "organization": {
          "name": "Amazon Web Services",
          "location": {
            "city": "Seattle",
            "region": "WA",
            "country": "US"
          }
        }
      }
    }
  }
}
```

### Error Responses

#### 400 Bad Request - Invalid ID Format

```json
{
  "status": "FAILED",
  "message": "Verification failed: Invalid verification ID format. ID must start with 'EDU-' or 'EMP-'. Received: XYZ-001",
  "error": "IllegalArgumentException"
}
```

#### 400 Bad Request - Data Not Found

```json
{
  "status": "FAILED",
  "message": "Verification failed: Education verification data not found for ID: EDU-999",
  "error": "IllegalArgumentException"
}
```

#### 500 Internal Server Error

```json
{
  "status": "FAILED",
  "message": "Processing failed: <error message>",
  "error": "<error type>"
}
```

## Available Mock Data

### Education Verification IDs

| ID | Institution | Degree | Location |
|----|-------------|--------|----------|
| EDU-001 | New York University | BA Psychology | New York, NY |
| EDU-002 | University of Michigan | BBA Business | Ann Arbor, MI |
| EDU-003 | Georgia Tech | MS Data Science | Atlanta, GA |
| EDU-004 | Phoenix Community College | AAS IT | Phoenix, AZ |
| EDU-005 | University of Toronto | BEng/MEng Engineering | Toronto, ON, Canada |

### Employment Verification IDs

| ID | Organization | Position | Location |
|----|--------------|----------|----------|
| EMP-VF-001 | Amazon Web Services | SDE I/II | Seattle, WA |
| EMP-VF-002 | JPMorgan Chase | Financial Analyst | New York, NY |
| EMP-VF-003 | Mayo Clinic | RN/Manager | Rochester, MN |
| EMP-VF-004 | Tesla Inc. | Manufacturing | Fremont, CA |
| EMP-VF-005 | Shopify Inc. | Product Designer | Ottawa, ON, Canada |

## Recombo Service Integration

### 1. Status Check (Synchronous GET)

The API calls the Recombo service to get the current status:

**Endpoint**: `GET {recombo.service.base-url}/recombo-service/api/status?id={verificationId}`

**Response**: Status information (returned in the main response as `recomboStatus`)

### 2. Async Submit (Asynchronous POST)

The API sends verification data to a third-party endpoint asynchronously:

**Endpoint**: `POST {recombo.service.base-url}/recombo-third-part/api/submit`

**Payload**:
```json
{
  "id": "EDU-001",
  "type": "EDUCATION",
  "data": { /* full verification data */ },
  "timestamp": 1700000000000
}
```

**Behavior**: 
- Non-blocking - doesn't affect main response
- Logged on success/failure
- Errors don't propagate to client

## Configuration

### Application Properties

```properties
# Recombo Service Configuration
recombo.service.base-url=${RECOMBO_SERVICE_BASE_URL:http://localhost:8081}
recombo.service.status-endpoint=/recombo-service/api/status
recombo.third-party.submit-endpoint=/recombo-third-part/api/submit
```

### Environment Variables

- `RECOMBO_SERVICE_BASE_URL`: Base URL for Recombo service (default: http://localhost:8081)

## cURL Examples

### Example 1: Education Verification (NYU)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EDU-001"}'
```

### Example 2: Employment Verification (AWS)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EMP-VF-001"}'
```

### Example 3: Invalid ID Format

```bash
curl -X POST http://localhost:8080/recombo-integration/api/verification \
  -H "Content-Type: application/json" \
  -d '{"id": "XYZ-001"}'
```

### Example 4: Data Not Found

```bash
curl -X POST http://localhost:8080/recombo-integration/api/verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EDU-999"}'
```

## Implementation Details

### Controller
- **Class**: `VerificationController`
- **Package**: `com.hireright.recombointegration.controller`
- **Endpoint**: `/recombo-integration/api/verification`
- **Method**: POST

### Caching Strategy
- **Initialization**: `@PostConstruct` method loads all mock data at startup
- **Education Cache**: `Map<String, EducationDataRequest>`
- **Employment Cache**: `Map<String, EmploymentDataRequest>`
- **Performance**: O(1) lookup time

### HTTP Client
- **Service**: `Http2ClientService`
- **Features**: 
  - HTTP/2 support
  - Retry logic with exponential backoff
  - JWT authentication
  - Async request support
  - MDC context propagation

### Dependencies
- Spring Boot 3.2.4
- Java 21
- Jackson for JSON processing
- Lombok for boilerplate reduction
- Custom HTTP/2 client with retry support

## Logging

The API provides comprehensive logging:

```
INFO  - Processing verification request - ID: EDU-001
DEBUG - Fetching education verification data from cache for ID: EDU-001
DEBUG - Calling Recombo service for status - URL: http://localhost:8081/recombo-service/api/status?id=EDU-001
INFO  - Successfully retrieved status from Recombo service for ID: EDU-001
DEBUG - Sending async POST to submit endpoint - URL: http://localhost:8081/recombo-third-part/api/submit
INFO  - Async submit request initiated for ID: EDU-001
INFO  - EDUCATION verification completed - ID: EDU-001
INFO  - Successfully submitted verification data to third-party - ID: EDU-001, Status: 200
```

## Error Handling

### Recombo Service Failures

If the Recombo service status call fails:
- Returns `"ERROR"` or `"UNKNOWN"` as status
- Logs the error
- **Does NOT** fail the main request

If the async submit fails:
- Logs the error
- **Does NOT** affect the response to client
- Handled asynchronously

### Cache Initialization Failures

If cache initialization fails at startup:
- Logs the error
- Initializes empty caches
- Application continues to run
- Requests will fail with "data not found" errors

## Performance Considerations

1. **Caching**: All mock data loaded once at startup - no file I/O on each request
2. **Async Submit**: Non-blocking - doesn't slow down response time
3. **HTTP/2**: Multiplexing and header compression for better performance
4. **Connection Pooling**: Reuses HTTP connections

## Testing

### Unit Testing
Test individual components:
- Cache initialization
- ID prefix detection
- Error handling

### Integration Testing
Test the full flow:
- Mock Recombo service endpoints
- Verify async POST is sent
- Check response format

### Load Testing
- Cache handles concurrent requests efficiently
- Async operations don't block main thread

## Migration from Separate Endpoints

If you were using the old separate endpoints:

**Old**:
- `/recombo-integration/api/education-verification`
- `/recombo-integration/api/employment-verification`

**New**:
- `/recombo-integration/api/verification` (handles both)

Simply change the endpoint URL - the request/response format remains the same.

## Future Enhancements

- [ ] Add cache refresh endpoint
- [ ] Add metrics for Recombo service calls
- [ ] Add circuit breaker for Recombo service
- [ ] Add webhook support for async results
- [ ] Add database persistence option

