# Submit API Refactoring Documentation

## Overview
The Submit API has been refactored following SOLID principles and clean code practices to improve maintainability, testability, and extensibility.

## Refactoring Principles Applied

### 1. Single Responsibility Principle (SRP)

**Before:**
- Controller handled HTTP requests, business logic, validation, serialization, and logging

**After:**
- **Controller**: Only handles HTTP concerns (request/response mapping, status codes)
- **Service**: Handles business logic (validation, processing, logging orchestration)
- **DTOs**: Handle data transfer and response building

### 2. Dependency Inversion Principle (DIP)

**Before:**
```java
public SubmitController(LoggingService loggingService, ObjectMapper objectMapper)
```

**After:**
```java
public SubmitController(SubmitService submitService)
```

- Controller now depends on `SubmitService` interface (abstraction)
- Service implementation can be swapped without changing controller
- Better for testing (easy to mock)

### 3. Open/Closed Principle (OCP)

- Service interface allows new implementations without modifying existing code
- Response builders use static factory methods for extensibility
- Exception hierarchy allows specific error handling

### 4. Clean Code Practices

#### Extracted Constants
- Moved magic strings to static factory methods
- Centralized response building logic

#### Improved Error Handling
- Custom exception with transaction ID tracking
- Specific exception types for different failure scenarios
- Proper HTTP status codes (400 for validation, 500 for server errors)

#### Better Naming
- `submitResponse()` → clear method name
- `processSubmission()` → describes what service does
- `SubmitProcessingException` → specific exception type

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     SubmitController                         │
│  Responsibilities:                                           │
│  - Handle HTTP requests/responses                            │
│  - Map exceptions to HTTP status codes                       │
│  - Delegate to service layer                                 │
└────────────────────────┬────────────────────────────────────┘
                         │ depends on
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                  SubmitService (Interface)                   │
│  + processSubmission(SubmitRequest)                          │
└────────────────────────┬────────────────────────────────────┘
                         │ implemented by
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    SubmitServiceImpl                         │
│  Responsibilities:                                           │
│  - Validate requests                                         │
│  - Serialize to JSON                                         │
│  - Log submissions                                           │
│  - Handle business errors                                    │
└────────────────────────┬────────────────────────────────────┘
                         │ uses
                         ▼
┌─────────────────────────────────────────────────────────────┐
│              LoggingService & ObjectMapper                   │
└─────────────────────────────────────────────────────────────┘
```

## File Structure

### New Files Created

```
src/main/java/com/hireright/recombointegration/
├── controller/
│   └── SubmitController.java (REFACTORED)
├── service/
│   ├── SubmitService.java (NEW - Interface)
│   ├── SubmitProcessingException.java (NEW - Custom Exception)
│   └── impl/
│       └── SubmitServiceImpl.java (NEW - Implementation)
└── dto/
    ├── SubmitRequest.java (EXISTING)
    └── SubmitResponse.java (NEW - Response DTO)
```

## Code Comparison

### Before (Controller doing everything)

```java
@PostMapping("/submit")
public ResponseEntity<Map<String, Object>> submitResponse(@RequestBody SubmitRequest submitRequest) {
    Map<String, Object> response = new HashMap<>();
    try {
        // Validation (implicit)
        log.info("Received submit request - Subject: {}", submitRequest.getResponse().getSubject());
        
        // Serialization
        String jsonPayload = objectMapper.writeValueAsString(submitRequest);
        
        // Business logic
        String transactionId = submitRequest.getResponse().getSubject();
        
        // Logging
        loggingService.log(jsonPayload, transactionId, RecipientName.RECOMBO_RESPONSE, Direction.IN);
        
        // Response building
        response.put("status", "SUCCESS");
        return ResponseEntity.ok(response);
        
    } catch (Exception e) {
        // Generic error handling
        response.put("status", "FAILED");
        response.put("message", "Failed to process submit request: " + e.getMessage());
        return ResponseEntity.status(500).body(response);
    }
}
```

### After (Separation of Concerns)

**Controller (HTTP Layer)**
```java
@PostMapping("/submit")
public ResponseEntity<SubmitResponse> submitResponse(@RequestBody SubmitRequest submitRequest) {
    try {
        log.info("Received submit request - Subject: {}", extractSubjectSafely(submitRequest));
        
        submitService.processSubmission(submitRequest);
        
        SubmitResponse response = SubmitResponse.success(
            submitRequest.getResponse().getSubject(),
            submitRequest.getResponse().getData().getDecision()
        );
        
        return ResponseEntity.ok(response);
        
    } catch (SubmitProcessingException e) {
        log.error("Submit processing failed - Subject: {}", e.getTransactionId(), e);
        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .body(SubmitResponse.error(e.getMessage(), e.getClass().getSimpleName()));
    }
}
```

**Service (Business Logic Layer)**
```java
@Override
public void processSubmission(SubmitRequest submitRequest) throws SubmitProcessingException {
    validateRequest(submitRequest);
    String transactionId = extractTransactionId(submitRequest);
    
    try {
        String jsonPayload = serializeRequest(submitRequest);
        logSubmission(jsonPayload, transactionId);
        log.info("Successfully processed - Subject: {}, Decision: {}", 
            transactionId, submitRequest.getResponse().getData().getDecision());
    } catch (JsonProcessingException e) {
        throw new SubmitProcessingException("Failed to serialize request", transactionId, e);
    }
}
```

## Benefits of Refactoring

### 1. Testability
- **Before**: Hard to test - controller mixed HTTP and business logic
- **After**: Easy to unit test service independently of HTTP layer

```java
// Easy to test service
@Test
void testProcessSubmission_Success() {
    SubmitRequest request = createValidRequest();
    submitService.processSubmission(request);
    verify(loggingService).log(any(), eq("subject"), any(), any());
}
```

### 2. Maintainability
- Clear separation of concerns
- Each class has one reason to change
- Easy to locate and fix bugs

### 3. Extensibility
- Can add new submission types by implementing `SubmitService`
- Can add validation rules without touching controller
- Can change logging strategy without affecting controller

### 4. Error Handling
- **Before**: Generic 500 errors for all failures
- **After**: 
  - 400 for validation errors (`SubmitProcessingException`)
  - 500 for unexpected errors
  - Transaction ID tracked in exceptions

### 5. Type Safety
- **Before**: `Map<String, Object>` - no compile-time safety
- **After**: `SubmitResponse` - type-safe, IDE autocomplete

## Validation Improvements

### Explicit Validation
```java
private void validateRequest(SubmitRequest submitRequest) throws SubmitProcessingException {
    if (Objects.isNull(submitRequest)) {
        throw new SubmitProcessingException("Submit request cannot be null", "UNKNOWN");
    }
    if (Objects.isNull(submitRequest.getResponse())) {
        throw new SubmitProcessingException("Response cannot be null", "UNKNOWN");
    }
    if (Objects.isNull(submitRequest.getResponse().getSubject()) || 
        submitRequest.getResponse().getSubject().isBlank()) {
        throw new SubmitProcessingException("Subject cannot be null or empty", "UNKNOWN");
    }
    if (Objects.isNull(submitRequest.getResponse().getData())) {
        throw new SubmitProcessingException("Response data cannot be null", 
            submitRequest.getResponse().getSubject());
    }
}
```

## Response DTO with Factory Methods

```java
@Data
@Builder
public class SubmitResponse {
    private String status;
    private String message;
    private String subject;
    private String decision;
    private Long timestamp;
    private String error;
    
    public static SubmitResponse success(String subject, String decision) {
        return SubmitResponse.builder()
            .status("SUCCESS")
            .message("Submit response received and logged successfully")
            .subject(subject)
            .decision(decision)
            .timestamp(System.currentTimeMillis())
            .build();
    }
    
    public static SubmitResponse error(String message, String error) {
        return SubmitResponse.builder()
            .status("FAILED")
            .message(message)
            .error(error)
            .timestamp(System.currentTimeMillis())
            .build();
    }
}
```

## API Response Examples

### Success Response
```json
{
  "status": "SUCCESS",
  "message": "Submit response received and logged successfully",
  "subject": "hrg:hre:task:HE-030101-ABCD12-EM-001-CLASSIFICATION",
  "decision": "VERIFIED",
  "timestamp": 1700000000000
}
```

### Validation Error (400)
```json
{
  "status": "FAILED",
  "message": "Subject cannot be null or empty",
  "error": "SubmitProcessingException",
  "timestamp": 1700000000000
}
```

### Server Error (500)
```json
{
  "status": "FAILED",
  "message": "An unexpected error occurred: Connection timeout",
  "error": "TimeoutException",
  "timestamp": 1700000000000
}
```

## Testing Strategy

### Unit Tests for Service
```java
@ExtendWith(MockitoExtension.class)
class SubmitServiceImplTest {
    @Mock private LoggingService loggingService;
    @Mock private ObjectMapper objectMapper;
    @InjectMocks private SubmitServiceImpl submitService;
    
    @Test
    void processSubmission_ValidRequest_Success() {
        // Test business logic in isolation
    }
    
    @Test
    void processSubmission_NullRequest_ThrowsException() {
        // Test validation
    }
}
```

### Integration Tests for Controller
```java
@WebMvcTest(SubmitController.class)
class SubmitControllerTest {
    @Autowired private MockMvc mockMvc;
    @MockBean private SubmitService submitService;
    
    @Test
    void submitResponse_ValidRequest_Returns200() {
        // Test HTTP layer
    }
}
```

## Migration Guide

### For Developers
1. **No API changes** - endpoint and request/response format remain the same
2. **Dependency injection** - Spring automatically wires `SubmitService`
3. **Error handling** - More specific HTTP status codes returned

### For Clients
- **No changes required** - API contract unchanged
- **Better error messages** - More descriptive validation errors
- **Consistent response format** - Always returns `SubmitResponse` structure

## Future Enhancements

With this architecture, we can easily add:

1. **Async Processing**
   ```java
   @Async
   public CompletableFuture<Void> processSubmissionAsync(SubmitRequest request)
   ```

2. **Retry Logic**
   ```java
   @Retryable(value = SubmitProcessingException.class, maxAttempts = 3)
   public void processSubmission(SubmitRequest request)
   ```

3. **Metrics/Monitoring**
   ```java
   @Timed("submit.processing")
   public void processSubmission(SubmitRequest request)
   ```

4. **Different Submission Handlers**
   ```java
   public class EducationSubmitService implements SubmitService { }
   public class EmploymentSubmitService implements SubmitService { }
   ```

## Summary

The refactoring transforms a monolithic controller into a well-structured, maintainable codebase following industry best practices:

✅ **Single Responsibility** - Each class has one job  
✅ **Dependency Inversion** - Depend on abstractions  
✅ **Open/Closed** - Open for extension, closed for modification  
✅ **Type Safety** - Compile-time checking with DTOs  
✅ **Testability** - Easy to unit test each layer  
✅ **Error Handling** - Specific exceptions with context  
✅ **Clean Code** - Self-documenting, readable code  

