/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.recombointegration.dto.ScreeningRequest;
import com.hireright.recombointegration.dto.education.EducationDataRequest;
import com.hireright.recombointegration.dto.employment.EmploymentDataRequest;
import com.hireright.recombointegration.helper.ReadEducationMockResponse;
import com.hireright.recombointegration.helper.ReadEmploymentMockResponse;
import com.hireright.recombointegration.http.client.Http2ClientService;
import com.hireright.recombointegration.log.LoggingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.annotation.PostConstruct;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

import static com.hireright.recombointegration.util.Constant.BASE_SOURCE_INTELLIGENCE_SERVICE_API_PATH;

/**
 * Unified REST Controller for Verification API
 * Handles both education and employment verification requests using cached data
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
@RestController
@RequestMapping(BASE_SOURCE_INTELLIGENCE_SERVICE_API_PATH)
@Slf4j
public class VerificationController {

    private final LoggingService loggingService;
    private final Http2ClientService http2ClientService;
    private final ObjectMapper objectMapper;

    // Cache for education verification data
    private Map<String, EducationDataRequest> educationCache;

    // Cache for employment verification data
    private Map<String, EmploymentDataRequest> employmentCache;

    // Recombo service configuration
    @Value("${recombo.service.base-url:http://localhost:8081}")
    private String recomboServiceBaseUrl;

    @Value("${recombo.third-party.submit-endpoint:/recombo-third-part/api/submit}")
    private String recomboSubmitEndpoint;

    public VerificationController(LoggingService loggingService,
                                   Http2ClientService http2ClientService,
                                   ObjectMapper objectMapper) {
        this.loggingService = loggingService;
        this.http2ClientService = http2ClientService;
        this.objectMapper = objectMapper;
    }
    
    /**
     * Initialize caches on application startup
     */
    @PostConstruct
    public void initializeCaches() {
        try {
            log.info("Initializing verification data caches...");
            
            // Load education verification data into cache
            educationCache = ReadEducationMockResponse.readAllEducationMockResponses();
            log.info("Education verification cache initialized with {} records", educationCache.size());
            
            // Load employment verification data into cache
            employmentCache = ReadEmploymentMockResponse.readAllEmploymentMockResponses();
            log.info("Employment verification cache initialized with {} records", employmentCache.size());
            
            log.info("All verification caches initialized successfully");
            
        } catch (Exception e) {
            log.error("Failed to initialize verification caches", e);
            // Initialize empty caches to prevent null pointer exceptions
            educationCache = new HashMap<>();
            employmentCache = new HashMap<>();
        }
    }
    
    /**
     * Unified POST endpoint for verification (education and employment)
     * Determines verification type based on ID prefix:
     * - EDU-* for education verification
     * - EMP-* for employment verification
     *
     * Flow:
     * 1. Get verification data from cache
     * 2. Call Recombo service to get status
     * 3. Send async POST to third-party submit endpoint
     * 4. Return verification data
     *
     * @param request Screening request containing the verification ID
     * @return ResponseEntity with verification data
     */
    @PostMapping("/verification")
    public ResponseEntity<Map<String, Object>> getVerification(
            @RequestBody ScreeningRequest request) {

        Map<String, Object> response = new HashMap<>();

        try {
            String id = request.getSubjectId();
            log.info("Processing verification request - ID: {}", id);

            // Step 1: Get verification data from cache
            Object verificationData;
            String verificationType;

            if (id.startsWith("EDU-")) {
                verificationType = "EDUCATION";
                verificationData = educationCache.get(id);
                if (Objects.isNull(verificationData)) {
                    throw new IllegalArgumentException("Education verification data not found for ID: " + id);
                }
            } else if (id.startsWith("EMP-")) {
                verificationType = "EMPLOYMENT";
                verificationData = employmentCache.get(id);
                if (Objects.isNull(verificationData)) {
                    throw new IllegalArgumentException("Employment verification data not found for ID: " + id);
                }
            } else {
                throw new IllegalArgumentException(
                    "Invalid verification ID format. ID must start with 'EDU-' or 'EMP-'. Received: " + id
                );
            }

            // Step 3: Send async POST to third-party submit endpoint
            sendAsyncSubmitRequest(id, verificationData, verificationType);

            // Step 4: Build and return response
            response.put("status", "SUCCESS");


            log.info("{} verification completed - ID: {}", verificationType, id);

            return ResponseEntity.ok(response);

        } catch (IllegalArgumentException e) {
            log.error("Verification request validation failed - ID: {}", request.getSubjectId(), e);

            response.put("status", "FAILED");
            response.put("message", "Verification failed: " + e.getMessage());
            response.put("error", e.getClass().getSimpleName());

            return ResponseEntity.status(400).body(response);

        } catch (Exception e) {
            log.error("Verification processing failed - ID: {}", request.getSubjectId(), e);

            response.put("status", "FAILED");
            response.put("message", "Processing failed: " + e.getMessage());
            response.put("error", e.getClass().getSimpleName());

            return ResponseEntity.status(500).body(response);
        }
    }

    /**
     * Send async POST request to third-party submit endpoint
     *
     * @param id Verification ID
     * @param verificationData Verification data to submit
     * @param verificationType Type of verification (EDUCATION or EMPLOYMENT)
     */
    private void sendAsyncSubmitRequest(String id, Object verificationData, String verificationType) {
        try {
            String submitUrl = recomboServiceBaseUrl + recomboSubmitEndpoint;
            log.debug("Sending async POST to submit endpoint - URL: {}", submitUrl);

            String jsonPayload = objectMapper.writeValueAsString(verificationData);

            // Send async POST request
            CompletableFuture<HttpResponse<String>> futureResponse =
                http2ClientService.postAsync(submitUrl, jsonPayload, new HashMap<>());

            // Handle async response (non-blocking)
            futureResponse.thenAccept(response -> {
                if (response.statusCode() >= 200 && response.statusCode() < 300) {
                    log.info("Successfully submitted verification data to third-party - ID: {}, Status: {}",
                        id, response.statusCode());
                } else {
                    log.warn("Third-party submit returned non-success status: {} for ID: {}",
                        response.statusCode(), id);
                }
            }).exceptionally(ex -> {
                log.error("Failed to submit verification data to third-party - ID: {}", id, ex);
                return null;
            });

            log.info("Async submit request initiated for ID: {}", id);

        } catch (Exception e) {
            log.error("Failed to send async submit request - ID: {}", id, e);
            // Don't throw exception - this is async and shouldn't block the main response
        }
    }
}

