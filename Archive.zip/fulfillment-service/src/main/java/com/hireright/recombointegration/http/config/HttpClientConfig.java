/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.http.config;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.http.HttpClient;
import java.time.Duration;

/**
 * Spring-managed configuration for HTTP/2 client.
 * Contains settings for connection timeouts, SSL, and HTTP version.
 * Properties are loaded from application.properties.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Getter
@Component
public class HttpClientConfig {

    @Value("${http.client.connect-timeout:10}")
    private int connectTimeoutSeconds;

    @Value("${http.client.request-timeout:30}")
    private int requestTimeoutSeconds;

    @Value("${http.client.http-version:HTTP_2}")
    private String httpVersionString;

    @Value("${http.client.redirect-policy:NORMAL}")
    private String redirectPolicyString;

    @Value("${http.client.enable-compression:true}")
    private boolean enableCompression;

    /**
     * Validates the configuration after properties are injected.
     */
    @PostConstruct
    public void init() {
        // Validate
        if (connectTimeoutSeconds <= 0) {
            throw new IllegalStateException("Connect timeout must be positive");
        }
        if (requestTimeoutSeconds <= 0) {
            throw new IllegalStateException("Request timeout must be positive");
        }

        log.info("HttpClientConfig initialized - connectTimeout: {}s, requestTimeout: {}s, httpVersion: {}, compression: {}",
                connectTimeoutSeconds, requestTimeoutSeconds, httpVersionString, enableCompression);
    }

    /**
     * Gets the connect timeout as a Duration.
     *
     * @return connect timeout duration
     */
    public Duration getConnectTimeout() {
        return Duration.ofSeconds(connectTimeoutSeconds);
    }

    /**
     * Gets the request timeout as a Duration.
     *
     * @return request timeout duration
     */
    public Duration getRequestTimeout() {
        return Duration.ofSeconds(requestTimeoutSeconds);
    }

    /**
     * Gets the HTTP version.
     *
     * @return HTTP version
     */
    public HttpClient.Version getHttpVersion() {
        try {
            return HttpClient.Version.valueOf(httpVersionString);
        } catch (IllegalArgumentException e) {
            log.warn("Invalid HTTP version '{}', defaulting to HTTP_2", httpVersionString);
            return HttpClient.Version.HTTP_2;
        }
    }

    /**
     * Gets the redirect policy.
     *
     * @return redirect policy
     */
    public HttpClient.Redirect getRedirectPolicy() {
        try {
            return HttpClient.Redirect.valueOf(redirectPolicyString);
        } catch (IllegalArgumentException e) {
            log.warn("Invalid redirect policy '{}', defaulting to NORMAL", redirectPolicyString);
            return HttpClient.Redirect.NORMAL;
        }
    }

}

