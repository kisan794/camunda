/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.controller;

import com.hireright.recombointegration.dto.SubmitRequest;
import com.hireright.recombointegration.dto.SubmitResponse;
import com.hireright.recombointegration.service.SubmitProcessingException;
import com.hireright.recombointegration.service.SubmitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.hireright.recombointegration.util.Constant.BASE_SOURCE_INTELLIGENCE_SERVICE_API_PATH;

/**
 * REST Controller for receiving and processing fulfillment task result submissions
 *
 * Responsibilities:
 * - Handle HTTP requests/responses
 * - Delegate business logic to service layer
 * - Map exceptions to appropriate HTTP responses
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@RestController
@RequestMapping(BASE_SOURCE_INTELLIGENCE_SERVICE_API_PATH)
@Slf4j
public class SubmitController {

    private final SubmitService submitService;

    /**
     * Constructor injection for better testability and immutability
     *
     * @param submitService Service for processing submissions
     */
    public SubmitController(SubmitService submitService) {
        this.submitService = submitService;
    }

    /**
     * POST endpoint to receive and log fulfillment task results
     *
     * @param submitRequest Submit request containing the response payload
     * @return ResponseEntity with acknowledgment
     */
    @PostMapping("/submit")
    public ResponseEntity<SubmitResponse> submitResponse(@RequestBody SubmitRequest submitRequest) {

        try {
            log.info("Received submit request - Subject: {}",
                extractSubjectSafely(submitRequest));

            submitService.processSubmission(submitRequest);

            SubmitResponse response = SubmitResponse.success(
                submitRequest.getResponse().getSubject(),
                submitRequest.getResponse().getData().getDecision()
            );

            return ResponseEntity.ok(response);

        } catch (SubmitProcessingException e) {
            log.error("Submit processing failed - Subject: {}", e.getTransactionId(), e);

            SubmitResponse response = SubmitResponse.error(
                e.getMessage(),
                e.getClass().getSimpleName()
            );

            return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);

        } catch (Exception e) {
            log.error("Unexpected error processing submit request", e);

            SubmitResponse response = SubmitResponse.error(
                "An unexpected error occurred: " + e.getMessage(),
                e.getClass().getSimpleName()
            );

            return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(response);
        }
    }

    /**
     * Safely extract subject from request to avoid NPE in logging
     *
     * @param submitRequest The submit request
     * @return Subject or "UNKNOWN" if not available
     */
    private String extractSubjectSafely(SubmitRequest submitRequest) {
        try {
            return submitRequest.getResponse().getSubject();
        } catch (NullPointerException e) {
            return "UNKNOWN";
        }
    }
}

