# Employment Verification API

## Overview
This API provides employment verification services using mock data for testing purposes.

## Endpoint

### POST `/recombo-integration/api/employment-verification`

Retrieves employment verification data for a given screening ID.

## Request Format

```json
{
  "id": "EMP-VF-001"
}
```

### Request Parameters
- `id` (String, required): The employment verification screening ID (e.g., EMP-VF-001, EMP-VF-002, etc.)

## Response Format

### Success Response (200 OK)

```json
{
  "status": "SUCCESS",
  "message": "Employment verification request processed successfully",
  "data": {
    "id": "hrg:hre:data-request:100001001",
    "refid": "hrg:hre:order-item:HE-030101-ABCD12-EM-001",
    "request": {
      "hrgSource": {
        "product": {
          "sku": "VF-EM-IEMP-CORE-USA",
          "name": "Employment Verification Report"
        },
        "organization": {
          "name": "Amazon Web Services",
          "location": {
            "city": "Seattle",
            "region": "WA",
            "country": "US",
            "postalCode": "98109"
          },
          "tenure": {
            "start": "2018-06",
            "end": "2024-03",
            "current": false
          },
          "positionHistory": [
            {
              "verify": true,
              "title": "Software Development Engineer I",
              "tenure": {
                "start": "2018-06",
                "end": "2020-08",
                "current": false
              }
            }
          ]
        },
        "guidelines": [
          "Verify employment dates and job titles with HR department",
          "Confirm reason for leaving if applicable"
        ],
        "referenceObjects": [
          {
            "type": "order-item",
            "id": "hrg:hre:order-item:HE-030101-ABCD12-BG-001",
            "name": "background check"
          }
        ],
        "notes": [
          {
            "date": "2024-11-15",
            "originator": "Employment Verification Specialist",
            "note": "Candidate left for career advancement opportunity"
          }
        ]
      },
      "dataSource": {
        "name": "TALX/TWN",
        "type": "employment",
        "screenings": [
          {
            "orderServiceNo": "OR-111524-AWS001-EM-001",
            "employerOrgName": "Amazon Web Services",
            "city": "Seattle",
            "region": "WA",
            "country": "US",
            "positionHistory": {
              "title": "Software Development Engineer I",
              "startDate": "2018-06-15",
              "endDate": "2020-08-01",
              "mostRecentHireDate": "2018-06-15",
              "employeeStatusCode": "8",
              "employeeStatus": "Inactive",
              "compensationInfo": {
                "currency": "USD",
                "rateOfPay": "95000",
                "averageHoursPerPayPeriod": "80",
                "dateOfPayIncreaseLast": "2019-06-15",
                "amountOfPayIncreaseLast": "8000",
                "dateOfPayIncreaseNext": "notKnown",
                "amountOfPayIncreaseNext": ""
              }
            }
          }
        ]
      }
    }
  }
}
```

### Error Response (404 Not Found)

```json
{
  "status": "FAILED",
  "message": "Employment verification failed: Employment verification data not found for ID: EMP-VF-999",
  "error": "IllegalArgumentException"
}
```

### Error Response (500 Internal Server Error)

```json
{
  "status": "FAILED",
  "message": "Processing failed: <error message>",
  "error": "<error type>"
}
```

## Available Mock Data

The following employment verification IDs are available:

| ID | Organization | Position(s) | Location | Status | Notes |
|----|--------------|-------------|----------|--------|-------|
| EMP-VF-001 | Amazon Web Services | SDE I → SDE II | Seattle, WA | Former Employee | Career progression, left 2024 |
| EMP-VF-002 | JPMorgan Chase & Co. | Financial Analyst → Senior | New York, NY | Current Employee | Active, salary disclosed |
| EMP-VF-003 | Mayo Clinic | RN → Charge Nurse → Manager | Rochester, MN | Former Employee | 3 positions, relocated |
| EMP-VF-004 | Tesla Inc. | Manufacturing Associate | Fremont, CA | Former Employee | Short tenure, layoff |
| EMP-VF-005 | Shopify Inc. | Designer → Senior → Lead | Ottawa, ON, Canada | Current Employee | International, CAD currency |

## cURL Examples

### Example 1: Verify AWS Employment (EMP-VF-001)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/employment-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EMP-VF-001"}'
```

**Expected Result**: Former AWS employee with 2 positions (SDE I → SDE II), left in March 2024

### Example 2: Verify JPMorgan Employment (EMP-VF-002)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/employment-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EMP-VF-002"}'
```

**Expected Result**: Current JPMorgan employee, Financial Analyst → Senior Financial Analyst, salary information included

### Example 3: Verify Mayo Clinic Employment (EMP-VF-003)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/employment-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EMP-VF-003"}'
```

**Expected Result**: Former Mayo Clinic employee with 3 nursing positions, left in good standing

### Example 4: Verify Tesla Employment (EMP-VF-004)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/employment-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EMP-VF-004"}'
```

**Expected Result**: Former Tesla employee, single position, short tenure due to layoff

### Example 5: Verify Shopify Employment (EMP-VF-005)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/employment-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EMP-VF-005"}'
```

**Expected Result**: Current Shopify employee (Canada), 3 design positions, salary in CAD

### Example 6: Test Error Handling (Invalid ID)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/employment-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EMP-VF-999"}'
```

**Expected Result**: 404 error with appropriate error message

## Data Structure Details

### EmploymentDataRequest
The main DTO containing:
- `id`: Unique data request identifier
- `refid`: Reference to the order item
- `request`: Contains hrgSource and dataSource

### EmploymentHrgSource
Contains verification requirements:
- `product`: Product SKU and name
- `organization`: Organization details and position history
- `guidelines`: Verification guidelines
- `referenceObjects`: Related order items
- `notes`: Verification notes

### Organization
Contains employer information:
- `name`: Organization name
- `location`: City, region, country, postal code
- `tenure`: Overall employment period
- `positionHistory`: Array of positions held

### PositionHistory
Contains job position details:
- `verify`: Whether to verify this position
- `title`: Job title
- `tenure`: Position start/end dates
- `startDate`: Exact start date (in screenings)
- `endDate`: Exact end date (in screenings)
- `employeeStatusCode`: Status code (1=Active, 8=Inactive)
- `employeeStatus`: Status description
- `compensationInfo`: Salary and pay details

### CompensationInfo
Contains salary information:
- `currency`: Currency code (USD, CAD, etc.)
- `rateOfPay`: Annual salary or hourly rate
- `averageHoursPerPayPeriod`: Hours worked per pay period
- `dateOfPayIncreaseLast`: Last raise date
- `amountOfPayIncreaseLast`: Last raise amount
- `dateOfPayIncreaseNext`: Next scheduled raise date
- `amountOfPayIncreaseNext`: Next scheduled raise amount

### EmploymentDataSource
Contains screening data:
- `name`: Data source name (TALX/TWN, CRA/Equifax, etc.)
- `type`: Type of verification (employment)
- `screenings`: Array of screening records

## Implementation Details

### Controller
- **Class**: `EmploymentVerificationController`
- **Package**: `com.hireright.recombointegration.controller`
- **Endpoint**: `/recombo-integration/api/employment-verification`
- **Method**: POST

### DTOs
All DTOs are located in `com.hireright.recombointegration.dto.employment`:
- EmploymentDataRequest
- EmploymentRequest
- EmploymentHrgSource
- EmploymentProduct
- Organization
- EmploymentLocation
- EmploymentTenure
- PositionHistory
- CompensationInfo
- EmploymentReferenceObject
- EmploymentNote
- EmploymentDataSource
- EmploymentScreening

### Helper
- **Class**: `ReadEmploymentMockResponse`
- **Package**: `com.hireright.recombointegration.helper`
- **Purpose**: Reads mock JSON files from `/mock/EMP-VF-*.json`

### Mock Data Files
Located in `src/main/resources/mock/`:
- EMP-VF-001.json - Amazon Web Services (Former, Tech)
- EMP-VF-002.json - JPMorgan Chase (Current, Finance)
- EMP-VF-003.json - Mayo Clinic (Former, Healthcare)
- EMP-VF-004.json - Tesla (Former, Manufacturing)
- EMP-VF-005.json - Shopify (Current, International/Canada)

## Testing

To test the API:

1. Start the application:
   ```bash
   ./gradlew bootRun
   ```

2. Use the cURL examples above or use a tool like Postman

3. Access Swagger UI (if enabled):
   ```
   http://localhost:8080/swagger-ui.html
   ```

## Key Features

- **Multiple Position History**: Supports employees with multiple positions at the same organization
- **Current vs Former Employees**: Distinguishes between active and inactive employees
- **Compensation Details**: Includes salary, pay increases, and currency information
- **International Support**: Handles international employment (Canada example with CAD currency)
- **Data Source Integration**: Simulates integration with TALX/TWN and CRA/Equifax
- **Comprehensive Guidelines**: Includes verification guidelines and notes
- **Error Handling**: Proper 404 and 500 error responses

## Notes

- This API uses mock data for testing purposes
- The logging service integration is included for production use
- All responses follow the standard response wrapper format
- Employee status codes: 1 = Active, 8 = Inactive
- Compensation can be annual salary or hourly rate depending on position type
- International verifications may include currency conversion notes in guidelines

