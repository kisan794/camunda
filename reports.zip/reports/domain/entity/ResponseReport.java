package com.hireright.sourceintelligence.reports.domain.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ResponseReport {

    private String organizationName;
    private String hon;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant createdDate;
    private String address;
    private String verificationValidationDate;
    private String organizationType;
    private String origin;
    private String approvalStatus;
    private String approvedBy;
    private int usedCount;
    private int autoMatch;
    //private boolean isAutoMatch;

    private String operatorName;
    private int added;
    private int changed;
    private int archived;
    private int rejected;
    private int approve;
    private int inProgress;
    private int onHold;
    private String reason;
}
