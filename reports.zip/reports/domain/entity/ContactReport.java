package com.hireright.sourceintelligence.reports.domain.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class ContactReport {

    private String organizationName;
    private String hon;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant usedDate;
    private String address;
    private String verificationValidationDate;
    private String organizationType;
    private String origin;
    private String approvalStatus;
    private String approvedBy;
    private int usedCount;
    private boolean isAutoMatch;
}
