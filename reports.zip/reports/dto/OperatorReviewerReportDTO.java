package com.hireright.sourceintelligence.reports.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OperatorReviewerReportDTO {

    @JsonProperty("Researcher_Name")
    private String researcherName;

    @JsonProperty("Hon")
    private String hon;

    @JsonProperty("Added")
    private int added;

    @JsonProperty("Changed")
    private int changed;

    @JsonProperty("Archived")
    private int archived;

    @JsonProperty("Deleted")
    private int deleted;

    @JsonProperty("New")
    private int newCount;

    @JsonProperty("In_Progress")
    private int inProgress;

    @JsonProperty("On_Hold")
    private int onHold;

    @JsonProperty("Cancelled")
    private int cancelled;

    @JsonProperty("Completed")
    private int completed;

    @JsonProperty("Total")
    private int total;
}