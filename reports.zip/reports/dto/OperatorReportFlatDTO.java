package com.hireright.sourceintelligence.reports.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OperatorReportFlatDTO {

    @JsonProperty("operatorName")
    private String operatorName;

    @JsonProperty("addedNew")
    private int addedNew;

    @JsonProperty("addedInProgress")
    private int addedInProgress;

    @JsonProperty("addedOnHold")
    private int addedOnHold;

    @JsonProperty("addedCancelled")
    private int addedCancelled;

    @JsonProperty("addedCompleted")
    private int addedCompleted;

    @JsonProperty("changedNew")
    private int changedNew;

    @JsonProperty("changedInProgress")
    private int changedInProgress;

    @JsonProperty("changedOnHold")
    private int changedOnHold;

    @JsonProperty("changedCancelled")
    private int changedCancelled;

    @JsonProperty("changedCompleted")
    private int changedCompleted;

    @JsonProperty("archivedNew")
    private int archivedNew;

    @JsonProperty("archivedInProgress")
    private int archivedInProgress;

    @JsonProperty("archivedOnHold")
    private int archivedOnHold;

    @JsonProperty("archivedCancelled")
    private int archivedCancelled;

    @JsonProperty("archivedCompleted")
    private int archivedCompleted;

    @JsonProperty("deletedNew")
    private int deletedNew;

    @JsonProperty("deletedInProgress")
    private int deletedInProgress;

    @JsonProperty("deletedOnHold")
    private int deletedOnHold;

    @JsonProperty("deletedCancelled")
    private int deletedCancelled;

    @JsonProperty("deletedCompleted")
    private int deletedCompleted;
}