package com.hireright.sourceintelligence.reports.dto;

import com.hireright.sourceintelligence.api.dto.DateRange;
import lombok.Data;

@Data
public class ReportsRequestDTO {
    private String reportType;
    private String operatorName;
    private String operatorRole;
    private String organizationName;
    private DateRange dateRange;
    private String region;
    private int startPage;
    private int batchSize;
    private String sort;
    private String order;
}
