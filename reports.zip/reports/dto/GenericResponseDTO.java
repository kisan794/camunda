package com.hireright.sourceintelligence.reports.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class GenericResponseDTO {

    @JsonProperty("Organization_Name")
    private String organizationName;

    @JsonProperty("Hon")
    private String hon;

    @JsonProperty("Used_Date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant usedDate;

    @JsonProperty("Address")
    private String address;

    @JsonProperty("Verification_Validation_Date")
    private String verificationValidationDate;

    @JsonProperty("Organization_Type")
    private String organizationType;

    @JsonProperty("Origin")
    private String origin;

    @JsonProperty("Approval_Status")
    private String approvalStatus;

    @JsonProperty("Approved_By")
    private String approvedBy;

    @JsonProperty("Used_Count")
    private int usedCount;

    @JsonProperty("Is_Auto_Match")
    private String isAutoMatch;

    @JsonProperty("Operator_Name")
    private String operatorName;

    @JsonProperty("Researcher_Name")
    private String researcherName;

    @JsonProperty("Added")
    @JsonInclude
    private int added;

    @JsonProperty("added")
    private ActionStatusCountDTO addedNested;

    @JsonProperty("changed")
    private ActionStatusCountDTO changedNested;

    @JsonProperty("archived")
    private ActionStatusCountDTO archivedNested;

    @JsonProperty("deleted")
    private ActionStatusCountDTO deletedNested;

    @JsonProperty("Changed")
    @JsonInclude
    private int changed;

    @JsonProperty("Archived")
    @JsonInclude
    private int archived;

    @JsonProperty("Deleted")
    @JsonInclude
    private int deleted;

    @JsonProperty("New")
    @JsonInclude
    private int newCount;

    @JsonProperty("On_Hold")
    @JsonInclude
    private int onHold;

    @JsonProperty("In_Progress")
    @JsonInclude
    private int inProgress;

    @JsonProperty("Cancelled")
    @JsonInclude
    private int cancelled;

    @JsonProperty("Completed")
    @JsonInclude
    private int completed;

    @JsonProperty("Reason")
    private String reason;

    @JsonProperty("Total")
    @JsonInclude
    private int total;

}
