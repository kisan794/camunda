package com.hireright.sourceintelligence.reports.dto;

import lombok.Data;

@Data
public class AutoMatchDTO {
    private String organizationName;
    private String location;
    private int usedCount;
    private Boolean isAutoMatched;
}
