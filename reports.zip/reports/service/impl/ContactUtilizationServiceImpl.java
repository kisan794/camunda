package com.hireright.sourceintelligence.reports.service.impl;
import com.hireright.sourceintelligence.service.impl.helperservices.CountryRegionMappingUtils;


import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.GenericResponseDTO;
import com.hireright.sourceintelligence.reports.dto.MetaDTO;
import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import com.hireright.sourceintelligence.reports.service.ContactUtilizationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.REPORTS_COLLECTION;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.ReportTypes.*;
import static com.hireright.sourceintelligence.reports.service.impl.ReportUtils.getMetaDataByReport;

@Slf4j
@RequiredArgsConstructor
@Service
public class ContactUtilizationServiceImpl implements ContactUtilizationService {

    private final ReportMapper reportMapper;

    private final CustomSourceRepository<Reports> customSourceRepository;
    private final CountryRegionMappingUtils countryRegionMappingUtils;


    @Override
    public ReportResponseDTO getContactUtilization(ReportsRequestDTO reportsRequestDTO) {
        List<String> countryList = null;
        if (reportsRequestDTO.getRegion() != null && !reportsRequestDTO.getRegion().isEmpty()) {
            countryList = countryRegionMappingUtils
                    .findDistinctCountriesByRegion(reportsRequestDTO.getRegion());
        }

        Criteria criteria = ReportsQueryBuilder.queryBuilder(reportsRequestDTO, countryList);

        MatchOperation matchOperation = ReportsQueryBuilder.matchOperation(criteria);
        GroupOperation groupOperation = ReportsQueryBuilder.contactUtilizationGroupOperation();
        FacetOperation facetOperation = ReportsQueryBuilder.facetOperation(reportsRequestDTO.getStartPage(), reportsRequestDTO.getBatchSize());
        ProjectionOperation finalProject = ReportsQueryBuilder.finalProjectionWithTotalCountInPipeline();

        AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder()
                .allowDiskUse(true).build();
        Aggregation aggregation;
        aggregation = Aggregation.newAggregation(matchOperation,groupOperation, facetOperation, finalProject).withOptions(aggregationOptionsToAllowDiskUse);
        var response = customSourceRepository.reportCustomAggregate(aggregation,REPORTS_COLLECTION, ReportSearchResult.class);
        log.info("Response: {}", response);
        List<GenericResponseDTO> responseDTOS = new ArrayList<>();
        if(!response.getResponseReportList().isEmpty()){
            responseDTOS = reportMapper.toDTOList(response.getResponseReportList());
        }
        List<MetaDTO> metaDTOList = getMetaDataByReport(CONTACT_UTILIZATION);
        return ReportResponseDTO.builder().
        meta(metaDTOList).response(responseDTOS).total(response.getTotal()).reportType(CONTACT_UTILIZATION).build();
    }

}
