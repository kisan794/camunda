package com.hireright.sourceintelligence.reports.api;

import com.hireright.sourceintelligence.reports.dto.*;
import com.hireright.sourceintelligence.reports.service.ContactUtilizationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Validated
@Slf4j
@CrossOrigin
public class ContactUtilizationApiController implements ContactUtilizationApi {

    private final ContactUtilizationService contactUtilizationService;

    @Override
    public ResponseEntity<ReportResponseDTO> getContactUtilization(@RequestBody ReportsRequestDTO reportsRequestDTO) {
        var response = contactUtilizationService.getContactUtilization(reportsRequestDTO);
        var responseHeaders = new HttpHeaders();
        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }

}
