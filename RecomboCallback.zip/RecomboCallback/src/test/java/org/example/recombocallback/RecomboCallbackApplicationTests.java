package org.example.recombocallback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecomboCallbackApplicationTests {

    @Test
    void contextLoads() {
    }

}
