package org.example.recombocallback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecomboCallbackApplication {

    public static void main(String[] args) {
        SpringApplication.run(RecomboCallbackApplication.class, args);
    }

}
