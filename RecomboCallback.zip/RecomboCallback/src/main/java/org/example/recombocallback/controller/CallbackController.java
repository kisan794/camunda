package org.example.recombocallback.controller;

import org.example.recombocallback.dto.CallbackRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class CallbackController {

    @PostMapping("/callback")
    public ResponseEntity<Map<String, Object>> handleCallback(@RequestBody CallbackRequest request) {
        // Log the received callback
        System.out.println("Received callback: " + request);

        // Process the callback (add your business logic here)
        Map<String, Object> response = new HashMap<>();
        response.put("received", true);
        response.put("id", request.getId());
        response.put("status", request.getStatus());
        response.put("metaData", request.getMetadata());

        System.out.println("Response: " + response);

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}

