package org.example.vendorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendorServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
