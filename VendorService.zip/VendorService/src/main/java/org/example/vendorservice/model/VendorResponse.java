package org.example.vendorservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

/**
 * Response model for vendor screening data.
 */
public class VendorResponse {

    /**
     * HRG request data as JSON object.
     */
    @JsonProperty("hrgRequest")
    private Map<String, Object> hrgRequest;

    /**
     * Attachment information.
     */
    @JsonProperty("attachment")
    private String attachment;

    /**
     * Request type (e.g., "application/xml").
     */
    @JsonProperty("requestType")
    private String requestType;

    /**
     * Base64 encoded XML data.
     */
    @JsonProperty("encode")
    private String encode;

    public VendorResponse() {
    }

    public VendorResponse(Map<String, Object> hrgRequest, String attachment, String requestType, String encode) {
        this.hrgRequest = hrgRequest;
        this.attachment = attachment;
        this.requestType = requestType;
        this.encode = encode;
    }

    public Map<String, Object> getHrgRequest() {
        return hrgRequest;
    }

    public void setHrgRequest(Map<String, Object> hrgRequest) {
        this.hrgRequest = hrgRequest;
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getEncode() {
        return encode;
    }

    public void setEncode(String encode) {
        this.encode = encode;
    }
}

