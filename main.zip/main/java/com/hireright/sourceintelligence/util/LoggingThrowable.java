package com.hireright.sourceintelligence.util;

import com.hireright.sourceintelligence.constants.ErrorConstants;
import com.hireright.sourceintelligence.exception.AccessDeniedException;
import com.hireright.sourceintelligence.exception.InvalidRequestException;
import com.hireright.sourceintelligence.exception.ResourceNotFoundException;
import com.hireright.sourceintelligence.exception.ServiceException;
import com.hireright.sourceintelligence.exception.UnauthorizedException;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;


// Utility class to log errors and throw exeptions.
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class LoggingThrowable {

    public static void logAndThrowRestClientException(ErrorConstants errorConstant, Exception ex) {
        String logErrorMessage = logErrorMessage(errorConstant, ex);
        throw new ServiceException(logErrorMessage);
    }

    public static void logAndThrowServiceException(ErrorConstants errorConstant, Exception ex, Object... args) {
        String logErrorMessage = logErrorMessage(errorConstant, ex, args);
        throw new ServiceException(logErrorMessage);
    }

    public static void logAndThrowInternalServiceException(ErrorConstants errorConstant, Exception ex, Object... args) {
        logErrorMessage(errorConstant, ex, args);
        throw new ServiceException(INTERNAL_SERVER_ERROR);
    }

    public static void logAndThrowAlreadyExistsException(ErrorConstants errorConstant, Exception ex, Object... args)  {
        String logErrorMessage = logErrorMessage(errorConstant, ex, args);
        throw new InvalidRequestException(logErrorMessage);
    }

    public static void logAndThrowUnauthorizedException(ErrorConstants errorConstant, Exception ex, Object... args) {
        String logErrorMessage = logErrorMessage(errorConstant, ex, args);
        throw new UnauthorizedException(logErrorMessage);
    }

    public static void logAndThrowInvalidRequest(ErrorConstants errorConstant, Exception ex, Object... args) {
        String localErrorMessage = logErrorMessage(errorConstant, ex, args);
        throw new InvalidRequestException(localErrorMessage);
    }

    public static void logAndThrowResourceNotFound(ErrorConstants errorConstant, Exception ex, Object... args) {
        String localErrorMessage = logErrorMessage(errorConstant, ex, args);
        throw new ResourceNotFoundException(localErrorMessage);
    }

    public static void logAndThrowInternalResourceNotFound(ErrorConstants errorConstant, Exception ex, Object... args) {
        logErrorMessage(errorConstant, ex, args);
        throw new ResourceNotFoundException(INTERNAL_SERVER_ERROR);
    }

    public static void logAndThrowPermissionsDenied(ErrorConstants errorConstant, Exception ex, Object... args) {
        String localErrorMessage = logErrorMessage(errorConstant, ex, args);
        throw new AccessDeniedException(localErrorMessage);
    }

    protected static String logErrorMessage(ErrorConstants errorConstant, Exception ex, Object... args) {
        String errorMessage;
        if (args != null && args.length > 0) {
            errorMessage = String.format(errorConstant.getMessage(), args);
        } else {
            errorMessage = errorConstant.getMessage();
        }

        if (ex != null) {
            log.error(String.format(ERROR_MESSAGE_FORMAT, errorConstant.getCode(), errorConstant.getSeverity(), errorMessage), ex);
        } else {
            log.error(String.format(ERROR_MESSAGE_FORMAT, errorConstant.getCode(), errorConstant.getSeverity(), errorMessage));
        }
        return errorMessage;
    }
}
