package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.mapper.ReportMapper;
import com.hireright.sourceintelligence.reports.dto.ReportsDTO;
import com.hireright.sourceintelligence.reports.service.ReportDataService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.REPORTS_COLLECTION;

@Slf4j
@RequiredArgsConstructor
@Service
public class ReportDataServiceImpl implements ReportDataService {

    private final CustomSourceRepository<Reports> customSourceRepository;

    private final ReportMapper reportMapper;

    @Override
    public void createData(ReportsDTO reportsDTO) {
        Reports reports = reportMapper.dtoToEntity(reportsDTO);
        reports.setCreatedDate(Instant.now());
        customSourceRepository.create(reports, Reports.class,REPORTS_COLLECTION);
    }
}
