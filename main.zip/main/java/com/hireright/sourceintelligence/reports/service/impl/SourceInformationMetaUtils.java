package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.reports.dto.MetaDTO;
import com.hireright.sourceintelligence.reports.dto.NestedMetaDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for generating metadata for Source Information reports
 */
public class SourceInformationMetaUtils {

    private SourceInformationMetaUtils() {
        // Private constructor to prevent instantiation
    }

    /**
     * Generate nested metadata structure for Operator role
     * @return List of NestedMetaDTO representing the table structure
     */
    public static List<NestedMetaDTO> getOperatorMetadata() {
        List<NestedMetaDTO> metaList = new ArrayList<>();

        // Operator Name column
        metaList.add(NestedMetaDTO.builder()
                .header("Operator Name")
                .accessorKey("operatorName")
                .build());

        // Added column with nested status columns
        List<NestedMetaDTO> addedColumns = new ArrayList<>();
        addedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("added.newCount").build());
        addedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("added.inProgress").build());
        addedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("added.onHold").build());
        addedColumns.add(NestedMetaDTO.builder().header("Cancelled").accessorKey("added.cancelled").build());
        addedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("added.completed").build());
        addedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("added.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Added")
                .accessorKey("added")
                .columns(addedColumns)
                .build());

        // Changed column with nested status columns
        List<NestedMetaDTO> changedColumns = new ArrayList<>();
        changedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("changed.newCount").build());
        changedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("changed.inProgress").build());
        changedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("changed.onHold").build());
        changedColumns.add(NestedMetaDTO.builder().header("Cancelled").accessorKey("changed.cancelled").build());
        changedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("changed.completed").build());
        changedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("changed.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Changed")
                .accessorKey("changed")
                .columns(changedColumns)
                .build());

        // Archived column with nested status columns
        List<NestedMetaDTO> archivedColumns = new ArrayList<>();
        archivedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("archived.newCount").build());
        archivedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("archived.inProgress").build());
        archivedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("archived.onHold").build());
        archivedColumns.add(NestedMetaDTO.builder().header("Cancelled").accessorKey("archived.cancelled").build());
        archivedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("archived.completed").build());
        archivedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("archived.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Archived")
                .accessorKey("archived")
                .columns(archivedColumns)
                .build());

        // Deleted column with nested status columns
        List<NestedMetaDTO> deletedColumns = new ArrayList<>();
        deletedColumns.add(NestedMetaDTO.builder().header("New").accessorKey("deleted.newCount").build());
        deletedColumns.add(NestedMetaDTO.builder().header("In Progress").accessorKey("deleted.inProgress").build());
        deletedColumns.add(NestedMetaDTO.builder().header("On Hold").accessorKey("deleted.onHold").build());
        deletedColumns.add(NestedMetaDTO.builder().header("Cancelled").accessorKey("deleted.cancelled").build());
        deletedColumns.add(NestedMetaDTO.builder().header("Completed").accessorKey("deleted.completed").build());
        deletedColumns.add(NestedMetaDTO.builder().header("Total").accessorKey("deleted.total").build());

        metaList.add(NestedMetaDTO.builder()
                .header("Deleted")
                .accessorKey("deleted")
                .columns(deletedColumns)
                .build());

        // Total column
        metaList.add(NestedMetaDTO.builder()
                .header("Total")
                .accessorKey("total")
                .build());

        return metaList;
    }

    /**
     * Generate flat metadata structure for Reviewer role
     * @return List of MetaDTO representing the table structure
     */
    public static List<MetaDTO> getReviewerMetadata() {
        List<MetaDTO> metaList = new ArrayList<>();

        metaList.add(MetaDTO.builder().header("Researcher Name").accessorKey("Researcher_Name").build());
        metaList.add(MetaDTO.builder().header("Hon").accessorKey("Hon").build());
        metaList.add(MetaDTO.builder().header("Added").accessorKey("Added").build());
        metaList.add(MetaDTO.builder().header("Changed").accessorKey("Changed").build());
        metaList.add(MetaDTO.builder().header("Archived").accessorKey("Archived").build());
        metaList.add(MetaDTO.builder().header("Deleted").accessorKey("Deleted").build());
        metaList.add(MetaDTO.builder().header("In Progress").accessorKey("In_Progress").build());
        metaList.add(MetaDTO.builder().header("On Hold").accessorKey("On_Hold").build());
        metaList.add(MetaDTO.builder().header("Cancelled").accessorKey("Cancelled").build());
        metaList.add(MetaDTO.builder().header("Completed").accessorKey("Completed").build());
        metaList.add(MetaDTO.builder().header("Total").accessorKey("Total").build());

        return metaList;
    }

    /**
     * Generate flat metadata structure for Operator & Reviewer combined role
     * @return List of MetaDTO representing the table structure
     */
    public static List<MetaDTO> getOperatorAndReviewerMetadata() {
        List<MetaDTO> metaList = new ArrayList<>();

        metaList.add(MetaDTO.builder().header("Researcher Name").accessorKey("Researcher_Name").build());
        metaList.add(MetaDTO.builder().header("Hon").accessorKey("Hon").build());
        metaList.add(MetaDTO.builder().header("Added").accessorKey("Added").build());
        metaList.add(MetaDTO.builder().header("Changed").accessorKey("Changed").build());
        metaList.add(MetaDTO.builder().header("Archived").accessorKey("Archived").build());
        metaList.add(MetaDTO.builder().header("Deleted").accessorKey("Deleted").build());
        metaList.add(MetaDTO.builder().header("New").accessorKey("New").build());
        metaList.add(MetaDTO.builder().header("In Progress").accessorKey("In_Progress").build());
        metaList.add(MetaDTO.builder().header("On Hold").accessorKey("On_Hold").build());
        metaList.add(MetaDTO.builder().header("Cancelled").accessorKey("Cancelled").build());
        metaList.add(MetaDTO.builder().header("Completed").accessorKey("Completed").build());
        metaList.add(MetaDTO.builder().header("Total").accessorKey("Total").build());

        return metaList;
    }
}

