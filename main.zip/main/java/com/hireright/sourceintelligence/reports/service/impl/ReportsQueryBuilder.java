package com.hireright.sourceintelligence.reports.service.impl;

import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SortOrder;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;

import java.util.Date;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.INVALID_SORT;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.ADDRESS;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.APPROVAL_STATUS;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.APPROVED_BY;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.AUTO_MATCH;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.CREATE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.CREATED_BY;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.CREATED_DATE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.DELETE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.HON;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.ORGANIZATION_NAME;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.ORGANIZATION_TYPE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.ORIGIN;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.REASON;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.UPDATE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.VERIFICATION_VALIDATION_DATE;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.MongoRegex.*;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.AggregateFields.*;
import static com.hireright.sourceintelligence.reports.service.impl.ReportConstants.SortFields.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

public class ReportsQueryBuilder {

    private ReportsQueryBuilder() {
        throw new IllegalStateException("Utility class");
    }
    /* Contact Utilization & Auto Match */
    public static Criteria queryBuilder(ReportsRequestDTO reportsRequestDTO){
        Criteria criteria = new Criteria();
        criteria.and(ACTION).is(ACTION_USED_COUNT);
        if(!StringUtils.isEmpty(reportsRequestDTO.getOrganizationName())){
            criteria.and(ORGANIZATION_NAME).is(reportsRequestDTO.getOrganizationName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            criteria.and(CREATED_BY).is(reportsRequestDTO.getOperatorName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorRole())){
            criteria.and(OPERATOR_ROLE).is(reportsRequestDTO.getOperatorRole());
        }
        var dateRange = reportsRequestDTO.getDateRange();

        if (dateRange != null
                && dateRange.getStartDate() != null
                && dateRange.getEndDate() != null) {

            criteria.and(CREATED_DATE)
                    .gte(Date.from(dateRange.getStartDate()))
                    .lte(Date.from(dateRange.getEndDate()));
        }
        return criteria;
    }

    /* Contact Utilization & Auto Match with region */

    public static Criteria queryBuilder(ReportsRequestDTO reportsRequestDTO, List<String> countryList){
        Criteria criteria = new Criteria();
        criteria.and(ACTION).is(ACTION_USED_COUNT);

        if(countryList != null && !countryList.isEmpty()){
            Document expr = new Document(IN, List.of(
                    new Document(ARRAY_ELEM_AT, List.of(
                            new Document(SPLIT, List.of(DOLLAR + ADDRESS, ",")),
                            0
                    )),
                    countryList
            ));
            criteria.and(EXPR).is(expr);
        }

        if(!StringUtils.isEmpty(reportsRequestDTO.getOrganizationName())){
            criteria.and(ORGANIZATION_NAME).is(reportsRequestDTO.getOrganizationName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            criteria.and(CREATED_BY).is(reportsRequestDTO.getOperatorName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorRole())){
            criteria.and(OPERATOR_ROLE).is(reportsRequestDTO.getOperatorRole());
        }

        var dateRange = reportsRequestDTO.getDateRange();
        if (dateRange != null && dateRange.getStartDate() != null && dateRange.getEndDate() != null) {
            criteria.and(CREATED_DATE)
                    .gte(Date.from(dateRange.getStartDate()))
                    .lte(Date.from(dateRange.getEndDate()));
        }
        return criteria;
    }

    /* Source Information & Approval Average TAT */
    public static Criteria queryBuilderForSourceInformationAndTat(ReportsRequestDTO reportsRequestDTO){
        Criteria criteria = new Criteria();
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            criteria.and(CREATED_BY).is(reportsRequestDTO.getOperatorName());
        }
        var dateRange = reportsRequestDTO.getDateRange();
        if (dateRange != null
                && dateRange.getStartDate() != null
                && dateRange.getEndDate() != null) {

            criteria.and(CREATED_DATE)
                    .gte(Date.from(dateRange.getStartDate()))
                    .lte(Date.from(dateRange.getEndDate()));
        }
        return criteria;
    }

    /* Query builder for Reviewer role - uses approvedBy instead of createdBy */
    public static Criteria queryBuilderForReviewerRole(ReportsRequestDTO reportsRequestDTO){
        Criteria criteria = new Criteria();
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            criteria.and(APPROVED_BY).is(reportsRequestDTO.getOperatorName());
        }
        var dateRange = reportsRequestDTO.getDateRange();
        if (dateRange != null
                && dateRange.getStartDate() != null
                && dateRange.getEndDate() != null) {

            criteria.and(CREATED_DATE)
                    .gte(Date.from(dateRange.getStartDate()))
                    .lte(Date.from(dateRange.getEndDate()));
        }
        return criteria;
    }


    public static MatchOperation matchOperation(Criteria criteria){
        return match(criteria);
    }

    public static SkipOperation skipOperation(int startPage, int pageSize) {
        return skip((long) (startPage - 1) * pageSize);
    }

    public static LimitOperation limitOperation(int pageSize) {
        return limit(pageSize);
    }

    public static CountOperation countOperation() {
        return count().as(COUNT);
    }
    public static FacetOperation facetOperation(int startPage, int pageSize) {
        return facet().and(countOperation()).as(TOTAL)
                .and(skipOperation(startPage, pageSize), limitOperation(pageSize)).as(DATA);
    }

    public static FacetOperation facetOperationWithGroup(SortOperation sortOperation,int startPage, int pageSize, GroupOperation groupOperation) {
        return facet().and(countOperation()).as(TOTAL)
                .and(groupOperation, sortOperation, skipOperation(startPage, pageSize), limitOperation(pageSize)).as(DATA);
    }

    public static ProjectionOperation finalProjectionWithTotalCountInPipeline() {
        return project()
                .and(ArrayOperators.ArrayElemAt.arrayOf(TOTAL_COUNT).elementAt(0)).as(TOTAL)
                .and(DATA).as(RESPONSE_REPORT_LIST);
    }

    public static ProjectionOperation operatorRoleFinalProjection() {
        return project()
                .and(ArrayOperators.ArrayElemAt.arrayOf(TOTAL_COUNT).elementAt(0)).as(TOTAL)
                .and(DATA).as("operatorReportList");
    }

    public static ProjectionOperation reviewerRoleFinalProjection() {
        return project()
                .and(ArrayOperators.ArrayElemAt.arrayOf(TOTAL_COUNT).elementAt(0)).as(TOTAL)
                .and(DATA).as("reviewerReportList");
    }

    public static ProjectionOperation operatorAndReviewerRoleFinalProjection() {
        return project()
                .and(ArrayOperators.ArrayElemAt.arrayOf(TOTAL_COUNT).elementAt(0)).as(TOTAL)
                .and(DATA).as("operatorReviewerReportList");
    }

    public static GroupOperation contactUtilizationGroupOperation() {
        return Aggregation.group(ORGANIZATION_NAME)
                .count().as(USED_COUNT)
                .first(ORGANIZATION_NAME).as(ORGANIZATION_NAME)
                .last(CREATED_DATE).as(CREATED_DATE)
                .last(VERIFICATION_VALIDATION_DATE).as(VERIFICATION_VALIDATION_DATE)
                .last(ADDRESS).as(ADDRESS)
                .last(APPROVAL_STATUS).as(APPROVAL_STATUS)
                .last(APPROVED_BY).as(APPROVED_BY)
                .last(ORGANIZATION_TYPE).as(ORGANIZATION_TYPE)
                .last(ORIGIN).as(ORIGIN)
                .last(HON).as(HON);
    }

    public static GroupOperation autoMatchGroupOperation() {
        return Aggregation.group(ORGANIZATION_NAME)
                .count().as(USED_COUNT)
                .first(ORGANIZATION_NAME).as(ORGANIZATION_NAME)
                .last(ADDRESS).as(ADDRESS)
                .last(ORGANIZATION_TYPE).as(ORGANIZATION_TYPE)
                .last(AUTO_MATCH).as(AUTO_MATCH)
                .last(HON).as(HON);
    }

    public static GroupOperation sourceInformationGroupOperation() {
        return Aggregation.group(CREATED_BY)
                .first(CREATED_BY).as(CREATED_BY)
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(CREATE).andOperator(Criteria.where(ORIGIN).is(SIDB_CURD)))
                        .then(1).otherwise(0)).as(ADDED)
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(UPDATE).andOperator(Criteria.where(ORIGIN).is(SIDB_CURD)))
                        .then(1).otherwise(0)).as(CHANGED)
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(ARCHIVED).andOperator(Criteria.where(ORIGIN).is(SIDB_CURD)))
                        .then(1).otherwise(0)).as(ARCHIVED)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus()).andOperator(Criteria.where(ORIGIN).is(SIDB_APPROVAL_FLOW)))
                        .then(1).otherwise(0)).as(ReportConstants.AggregateFields.PROGRESS)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus()).andOperator(Criteria.where(ORIGIN).is(SIDB_APPROVAL_FLOW)))
                        .then(1).otherwise(0)).as(COMPLETED)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus()).andOperator(Criteria.where(ORIGIN).is(SIDB_APPROVAL_FLOW)))
                        .then(1).otherwise(0)).as(CANCELLED)
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus()).and(ORIGIN).is(SIDB_APPROVAL_FLOW))
                        .then(1).otherwise(0)).as(ON_HOLD);
    }

    /**
     * Group operation for Operator role - groups by createdBy (operator name)
     * Counts actions (create, update, archive, delete) and their approval statuses
     */
    public static GroupOperation operatorRoleGroupOperation() {
        return Aggregation.group(CREATED_BY)
                .first(CREATED_BY).as("operatorName")
                .last(HON).as(HON)
                // Added - Create action counts by status
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(CREATE)
                        .and(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus()))
                        .then(1).otherwise(0)).as("addedNew")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(CREATE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus()))
                        .then(1).otherwise(0)).as("addedInProgress")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(CREATE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus()))
                        .then(1).otherwise(0)).as("addedOnHold")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(CREATE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus()))
                        .then(1).otherwise(0)).as("addedCancelled")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(CREATE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus()))
                        .then(1).otherwise(0)).as("addedCompleted")
                // Changed - Update action counts by status
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(UPDATE)
                        .and(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus()))
                        .then(1).otherwise(0)).as("changedNew")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(UPDATE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus()))
                        .then(1).otherwise(0)).as("changedInProgress")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(UPDATE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus()))
                        .then(1).otherwise(0)).as("changedOnHold")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(UPDATE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus()))
                        .then(1).otherwise(0)).as("changedCancelled")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(UPDATE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus()))
                        .then(1).otherwise(0)).as("changedCompleted")
                // Archived - Archive action counts by status
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION)
                        .and(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus()))
                        .then(1).otherwise(0)).as("archivedNew")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus()))
                        .then(1).otherwise(0)).as("archivedInProgress")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus()))
                        .then(1).otherwise(0)).as("archivedOnHold")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus()))
                        .then(1).otherwise(0)).as("archivedCancelled")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus()))
                        .then(1).otherwise(0)).as("archivedCompleted")
                // Deleted - Delete action counts by status
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(DELETE)
                        .and(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus()))
                        .then(1).otherwise(0)).as("deletedNew")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(DELETE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus()))
                        .then(1).otherwise(0)).as("deletedInProgress")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(DELETE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus()))
                        .then(1).otherwise(0)).as("deletedOnHold")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(DELETE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus()))
                        .then(1).otherwise(0)).as("deletedCancelled")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(DELETE)
                        .and(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus()))
                        .then(1).otherwise(0)).as("deletedCompleted");
    }

    /**
     * Group operation for Reviewer role - groups by approvedBy (reviewer name)
     * Counts actions and approval statuses
     */
    public static GroupOperation reviewerRoleGroupOperation() {
        return Aggregation.group(APPROVED_BY)
                .first(APPROVED_BY).as("researcherName")
                .last(HON).as(HON)
                // Count by action type
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(CREATE))
                        .then(1).otherwise(0)).as("added")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(UPDATE))
                        .then(1).otherwise(0)).as("changed")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION))
                        .then(1).otherwise(0)).as("archived")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(DELETE))
                        .then(1).otherwise(0)).as("deleted")
                // Count by approval status
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus()))
                        .then(1).otherwise(0)).as("inProgress")
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus()))
                        .then(1).otherwise(0)).as("onHold")
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus()))
                        .then(1).otherwise(0)).as("cancelled")
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus()))
                        .then(1).otherwise(0)).as("completed");
    }

    /**
     * Group operation for Operator & Reviewer combined role - Action counts
     * Groups by createdBy and counts actions (Create, Update, Archive, Delete)
     */
    public static GroupOperation operatorAndReviewerActionGroupOperation() {
        return Aggregation.group(CREATED_BY)
                .first(CREATED_BY).as("researcherName")
                .last(HON).as("hon")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(CREATE))
                        .then(1).otherwise(0)).as("added")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(UPDATE))
                        .then(1).otherwise(0)).as("changed")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(ReportConstants.AggregateFields.ARCHIVED_ACTION))
                        .then(1).otherwise(0)).as("archived")
                .sum(ConditionalOperators.Cond.when(Criteria.where(ACTION).is(DELETE))
                        .then(1).otherwise(0)).as("deleted");
    }

    /**
     * Group operation for Operator & Reviewer combined role - Status counts
     * Groups by approvedBy and counts approval statuses
     */
    public static GroupOperation operatorAndReviewerStatusGroupOperation() {
        return Aggregation.group(APPROVED_BY)
                .first(APPROVED_BY).as("researcherName")
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).in(ApprovalStatus.PENDING_APPROVAL.getStatus(), ApprovalStatus.SAVE_PENDING_APPROVAL.getStatus()))
                        .then(1).otherwise(0)).as("newCount")
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus()))
                        .then(1).otherwise(0)).as("inProgress")
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus()))
                        .then(1).otherwise(0)).as("onHold")
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.REJECTED.getStatus()))
                        .then(1).otherwise(0)).as("cancelled")
                .sum(ConditionalOperators.Cond.when(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus()))
                        .then(1).otherwise(0)).as("completed");
    }


    public static GroupOperation approvalTATGroupOperation() {
        return Aggregation.group(ORGANIZATION_NAME)
                .count().as(USED_COUNT)
                .first(ORGANIZATION_NAME).as(ORGANIZATION_NAME)
                .last(ADDRESS).as(ADDRESS)
                .last(ORGANIZATION_TYPE).as(ORGANIZATION_TYPE)
                .last(AUTO_MATCH).as(AUTO_MATCH)
                .last(HON).as(HON);
    }

    public static Criteria queryBuilderForDelete(ReportsRequestDTO reportsRequestDTO, List<String> countryList){
        Criteria criteria = new Criteria();
        criteria.and(ACTION).is(DELETE);

        if(countryList != null && !countryList.isEmpty()){
            Document expr = new Document(IN, List.of(
                    new Document(ARRAY_ELEM_AT, List.of(
                            new Document(SPLIT, List.of(DOLLAR+ADDRESS, ",")),
                            0
                    )),
                    countryList
            ));

            criteria.and(EXPR).is(expr);
        }

        if(!StringUtils.isEmpty(reportsRequestDTO.getOrganizationName())){
            criteria.and(ORGANIZATION_NAME).is(reportsRequestDTO.getOrganizationName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorName())){
            criteria.and(CREATED_BY).is(reportsRequestDTO.getOperatorName());
        }
        if(!StringUtils.isEmpty(reportsRequestDTO.getOperatorRole())){
            criteria.and(OPERATOR_ROLE).is(reportsRequestDTO.getOperatorRole());
        }
        if(reportsRequestDTO.getDateRange() != null && reportsRequestDTO.getDateRange().getStartDate() != null && reportsRequestDTO.getDateRange().getEndDate() != null){
            criteria.and(CREATED_DATE).gte(Date.from(reportsRequestDTO.getDateRange().getStartDate()))
                    .lte(Date.from(reportsRequestDTO.getDateRange().getEndDate()));
        }

        return criteria;
    }

    public static GroupOperation deleteGroupOperation() {
        return Aggregation.group(ORGANIZATION_NAME)
                .first(ORGANIZATION_NAME).as(ORGANIZATION_NAME)
                .last(CREATED_DATE).as(CREATED_DATE)
                .last(VERIFICATION_VALIDATION_DATE).as(VERIFICATION_VALIDATION_DATE)
                .last(ADDRESS).as(ADDRESS)
                .last(APPROVED_BY).as(APPROVED_BY)
                .last(ORGANIZATION_TYPE).as(ORGANIZATION_TYPE)
                .last(REASON).as(REASON)
                .last(HON).as(HON);
    }

    public static String getSortPropertyMapped(String sort) {
        String sortOnField;
        switch (sort) {
            case ReportConstants.SortFields.HON -> sortOnField = HON;
            case ReportConstants.SortFields.ORGANIZATION_NAME -> sortOnField = ORGANIZATION_NAME;
            case ReportConstants.SortFields.ADDRESS -> sortOnField = ADDRESS;
            case VERIFICATION_DATE -> sortOnField = VERIFICATION_VALIDATION_DATE;
            case ReportConstants.SortFields.ORGANIZATION_TYPE -> sortOnField = ORGANIZATION_TYPE;
            case ReportConstants.SortFields.APPROVAL_STATUS -> sortOnField = APPROVAL_STATUS;
            case ReportConstants.SortFields.APPROVED_BY -> sortOnField = APPROVED_BY;
            case ReportConstants.SortFields.CREATED_BY -> sortOnField = CREATED_BY;
            case ReportConstants.SortFields.AUTO_MATCH, IS_AUTO_MATCH -> sortOnField = AUTO_MATCH;
            case ReportConstants.SortFields.REASON -> sortOnField = REASON;
            default -> sortOnField = CREATED_DATE;
        }
        return sortOnField;
    }

    public static SortOperation buildSortOperation(String sort, String order) {
        SortOperation sortOperation;
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            String sortOnField = getSortPropertyMapped(sort);
            if (sortOnField == null) {
                logAndThrowInvalidRequest(INVALID_SORT, null, sort);
            }
            sortOperation = new SortOperation(
                    Sort.by(getSortOrderDirection(order), sortOnField));
        } else {
            sortOperation = new SortOperation(Sort.by(Sort.Direction.DESC, CREATED_DATE));
        }
        return sortOperation;
    }

    public static Sort.Direction getSortOrderDirection(String order) {
        if (order.equalsIgnoreCase(SortOrder.ASC.getType())) {
            return Sort.Direction.ASC;
        } else {
            return Sort.Direction.DESC;
        }
    }

}