package com.hireright.sourceintelligence.reports.service;

import com.hireright.sourceintelligence.reports.dto.ReportResponseDTO;
import com.hireright.sourceintelligence.reports.dto.ReportsRequestDTO;

public interface ContactUtilizationService {
        ReportResponseDTO getContactUtilization(ReportsRequestDTO reportsRequestDTO);
}
