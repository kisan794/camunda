package com.hireright.sourceintelligence.reports.dto;

import lombok.Data;

@Data
public class SourceInformationDTO {
    private String operatorName;
    private int addNewOrgsAsOriginator;
    private int changedOrgsAsOriginator;
    private int deActivatedOrgsAsOriginator;
    private int hasOrgsInStatusNewAsReviewer;
    private int hasOrgsInStatusInProgessAsReviewer;
    private int hasOrgsInStatusOnHoldAsReviewer;
    private int hasOrgsInStatusCancelledAsReviewer;
    private int hasOrgsInStatusCompletedAsReviewer;
    private int total;

}

