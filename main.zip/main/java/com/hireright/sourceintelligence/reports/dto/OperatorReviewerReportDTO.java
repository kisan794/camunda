package com.hireright.sourceintelligence.reports.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for Operator & Reviewer combined report
 * Combines action counts (grouped by createdBy) and status counts (grouped by approvedBy)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OperatorReviewerReportDTO {

    @JsonProperty("Researcher_Name")
    private String researcherName;

    @JsonProperty("Hon")
    private String hon;

    // Action counts - grouped by createdBy
    @JsonProperty("Added")
    private int added;

    @JsonProperty("Changed")
    private int changed;

    @JsonProperty("Archived")
    private int archived;

    @JsonProperty("Deleted")
    private int deleted;

    // Status counts - grouped by approvedBy
    @JsonProperty("New")
    private int newCount;

    @JsonProperty("In_Progress")
    private int inProgress;

    @JsonProperty("On_Hold")
    private int onHold;

    @JsonProperty("Cancelled")
    private int cancelled;

    @JsonProperty("Completed")
    private int completed;

    @JsonProperty("Total")
    private int total;
}

