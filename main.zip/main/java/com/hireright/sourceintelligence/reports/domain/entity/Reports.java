package com.hireright.sourceintelligence.reports.domain.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.time.Instant;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class Reports {

    @Id
    private String id;
    private String hon;
    private String organizationName;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    //private Instant usedDate; //Created_date
    private Instant createdDate;
    private String address;
    private String verificationValidationDate;
    private String organizationType;
    private String origin;
    private String approvalStatus; //Pending_approval, in_Progress
    private String approvedBy; //field used for deleted by too
    private String approvedId;
   // private boolean isAutoMatch; //not needed
    private int autoMatch;
    private String action; //(update, archive, create, usedCount)
    private String createdBy;
    private String reason;

}
