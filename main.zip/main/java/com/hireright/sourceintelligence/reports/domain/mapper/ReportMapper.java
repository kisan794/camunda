package com.hireright.sourceintelligence.reports.domain.mapper;

import com.hireright.sourceintelligence.reports.domain.entity.Reports;
import com.hireright.sourceintelligence.reports.domain.entity.ResponseReport;
import com.hireright.sourceintelligence.reports.dto.ReportsDTO;
import com.hireright.sourceintelligence.reports.dto.GenericResponseDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;

import java.util.List;

import static org.mapstruct.ReportingPolicy.IGNORE;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
        unmappedTargetPolicy = IGNORE)
public interface ReportMapper {

    default String mapAutoMatch(ResponseReport responseReport) {
        if (responseReport.getAutoMatch() == 1) {
            return "Yes";
        }
        return "No";
    }

    Reports dtoToEntity(ReportsDTO dto);

    ReportsDTO entityToDTO(Reports entity);

    List<ReportsDTO> entityToContactUtilizationDTOList(List<Reports> entityList);

    @Mapping(target="usedDate", source="createdDate")
    @Mapping(target = "isAutoMatch", expression = "java(mapAutoMatch(responseReport))")
    GenericResponseDTO reportToGenericResponseDTO(ResponseReport responseReport);

    List<GenericResponseDTO> toDTOList(List<ResponseReport> dtoList);
}
