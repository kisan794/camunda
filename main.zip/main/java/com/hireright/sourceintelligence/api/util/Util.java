package com.hireright.sourceintelligence.api.util;

public class Util {

}
