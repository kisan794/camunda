package com.hireright.sourceintelligence.api.v2.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hireright.sourceintelligence.api.dto.ApproverDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PermissionsDTO {

    private String userName;
    private String userEmail;
    private String status;
    private String scope;
    private String trustScore;
    private List<String> permissions;
    private List<ApproverDTO> approvalGroupList;
}
