package com.hireright.sourceintelligence.api.v2.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsonorg.JSONObjectDeserializer;
import com.fasterxml.jackson.datatype.jsonorg.JSONObjectSerializer;
import com.hireright.sourceintelligence.api.dto.FieldErrorsDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.JSONObject;

import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class SourceDTO {
    private String sourceId;
    private String hon;
    private String name;
    private SourceOrganizationStatus status;
    private double version;
    private OrganizationType type;
    private ApprovalStatus approvalStatus;

    @NotNull
    @JsonSerialize(using = JSONObjectSerializer.class)
    @JsonDeserialize(using = JSONObjectDeserializer.class)
    private JSONObject payload;

    private String reviewRequired;
    private String postalCode;
    private String location;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private String createdDate;

    private String lastModifiedBy;
    private String lastModifierId;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastModifiedDate;

    private String comments;
    private List<FieldErrorsDTO> generalErrors;
    private List<FieldErrorsDTO> fieldErrors;

}
