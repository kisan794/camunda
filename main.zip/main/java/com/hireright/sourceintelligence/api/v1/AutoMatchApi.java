package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.AUTO_MATCH;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH;


@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH)
@Tag(name = "SourceOrganization", description = "Endpoints for source auto match")
public interface AutoMatchApi {

    @ResponseStatus(HttpStatus.OK)
    @PostMapping(value = AUTO_MATCH,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<AutoMatchResponseDTO> autoMatch(@RequestBody AutoMatchDTO inputData);
}
