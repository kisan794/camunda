package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.*;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.*;
import static com.hireright.sourceintelligence.api.ApiConstants.SearchParams.*;
import static com.hireright.sourceintelligence.api.ApiDescriptions.*;
import com.hireright.sourceintelligence.api.ApiConstants;
import com.hireright.sourceintelligence.api.ApiConstants.ApiPath;
import com.hireright.sourceintelligence.api.dto.AutocompleteSearchDTO;
import com.hireright.sourceintelligence.api.dto.SearchResponseDTO;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogFilters;
import com.hireright.sourceintelligence.api.dto.history.SearchHistoryFilter;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import jakarta.validation.constraints.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;


@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH)
@Tag(name = "Search Source Organization History", description = "Endpoints for managing Source Organizations")
public interface SearchHistoryApi {

  @Operation(summary = "Search for change logs by filters",
      description = SEARCH_CHANGE_LOG_DATA_BY_FILTER_DESCRIPTION ,
      responses = {
          @ApiResponse(description = "OrganizationName  Found", responseCode = "200",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = SearchResponseDTO.class))),
          @ApiResponse(description = "OrganizationName  Not found", responseCode = "404",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = ApiError.class))),
          @ApiResponse(description = "Internal error", responseCode = "500",
              content = @Content(mediaType = "application/json",
                  schema = @Schema(implementation = ApiError.class)))})
  @PostMapping(value = APPROVAL_WORKFLOW + SOURCE_ORGANIZATION + CHANGE_LOG, produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  ResponseEntity<SearchResponseDTO> changeLogsByFilters(@RequestBody ChangeLogFilters changeLogFilters);
}
