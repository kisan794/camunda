package com.hireright.sourceintelligence.api.v1;

import static com.hireright.sourceintelligence.api.ApiConstants.*;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogResponse;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.service.*;
import java.util.List;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.http.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * Controller to trigger CRUD operations on SourceOrganization Document
 */

@RestController
@RequiredArgsConstructor
@Validated
@Slf4j
@CrossOrigin
public class SourceHistoryApiController implements SourceHistoryApi {

	private final SourceHistoryService sourceHistoryService;

	@Override
	public ResponseEntity<SourceOrganizationDTO> getSourceOrganizationHistoryByHonAndVersion(
			@PathVariable(value = HON) @NotNull final String hon, @PathVariable(value = VERSION) @NotNull final Double version) {
		return new ResponseEntity<>(sourceHistoryService.getSourceByHonAndVersion(hon, version),
				HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ChangeLogResponse> getSourcesByHonAndApprovalStatus(@NotNull String hon, Double version, @NotNull ApprovalStatus approvalStatus) {
		return new ResponseEntity<>(sourceHistoryService.getChangeLogByHon(hon,approvalStatus), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<SourceOrganizationDTO>> getSourceOrganizationsForDiff(String hon, Double version, String sourceType) {
		return new ResponseEntity<>(sourceHistoryService.getSourcesForDiff(hon,version, sourceType), HttpStatus.OK);
	}

}
