package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.rds.VendorResponseDTO;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.*;

@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH)
@Tag(name = "SourceOrganization", description = "Endpoints for rds services")
public interface RDSApi {

    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = VENDORS,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<VendorResponseDTO> getVendorsList();

}
