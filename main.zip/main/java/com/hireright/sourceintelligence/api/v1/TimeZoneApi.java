package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.timezone.TimeZoneResponseDTO;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.*;

@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH)
@Tag(name = "SourceOrganization", description = "Endpoints for time zones")
public interface TimeZoneApi {
    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = TIME_ZONE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<TimeZoneResponseDTO> getTimeZones();

}
