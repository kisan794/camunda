package com.hireright.sourceintelligence.api.v1;

import com.hireright.sourceintelligence.api.dto.UserLoginDetailsDTO;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.NotNull;
import java.nio.file.AccessDeniedException;

import static com.hireright.sourceintelligence.api.ApiConstants.*;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH;
import static com.hireright.sourceintelligence.api.ApiConstants.SearchParams.*;

@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH)
@Tag(name = "SourceOrganization", description = "Endpoints for invoking external API")
public interface ExternalApi {

    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = ENTRY_POINT,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<String> getExternalApiResponse(
            @RequestParam(name = OP_TOOL_KEY) String ot_key,
            @RequestParam(name = ENTRY) String entry,
            @RequestParam(name = API_HOST) String apiHost);

    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = CACHED_TOKEN,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<UserLoginDetailsDTO> getCachedToken(
            @RequestParam(name = KEY) String key,
            @RequestParam(name = API_HOST) String apiHost);

    @ResponseStatus(HttpStatus.OK)
    @GetMapping(value = PERMISSIONS,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<UserLoginDetailsDTO> getHRGPermissions(
            @RequestParam(name = SUBJECT) String subject,
            @RequestParam(name = USER_NAME) String userName);

    @ResponseStatus(HttpStatus.OK)
    @PostMapping(value = UPLOAD_ATTACHMENT, produces = MediaType.MULTIPART_FORM_DATA_VALUE)
    ResponseEntity<String> uploadAttachment(
                                            @RequestParam(FILE) MultipartFile file,
                                            @RequestParam(DOCUMENT_META) String documentMeta);

    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    @GetMapping(value = GET_ATTACHMENT, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<InputStreamResource> getAttachment(@RequestParam(value = DOCUMENT_ID) @NotNull String documentId);

    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    @GetMapping(value = DELETE_ATTACHMENT, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<String> deleteAttachment(@RequestParam(value = DOCUMENT_ID) String documentId);

}
