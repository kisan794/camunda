package com.hireright.sourceintelligence.api.v1;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogResponse;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;

import com.hireright.sourceintelligence.exception.ApiError;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.constraints.*;
import static com.hireright.sourceintelligence.api.ApiConstants.ApiPath.*;

import java.util.List;

import static com.hireright.sourceintelligence.api.ApiConstants.*;

@RequestMapping(value = BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH)
@Tag(name = "SourceOrganizationHistory", description = "Endpoints for managing Source Organizations")
public interface SourceHistoryApi {

	@Operation(summary = "Find a source in history using hon and version", responses = {
			@ApiResponse(description = "Source Organization Found", responseCode = "200", content = @Content(mediaType = "application/json", schema = @Schema(implementation = SourceOrganizationDTO.class))),
			@ApiResponse(description = "Source Organization Not found", responseCode = "404", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiError.class))),
			@ApiResponse(description = "Internal error", responseCode = "500", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiError.class))) })
	@ResponseStatus(HttpStatus.OK)
	@GetMapping(value = APPROVAL_WORKFLOW + SOURCE_ORGANIZATION + HON_PATH_VAR + FORWARD_SLASH + VERSION + VERSION_PATH_VAR, produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<SourceOrganizationDTO> getSourceOrganizationHistoryByHonAndVersion(
			@PathVariable(value = HON) @NotNull final String hon,
			@PathVariable(value = VERSION) @NotNull final Double version);


	@Operation(summary = "Get all approved versions lesser than specified for a HON from history ordered by version", tags = {
			"SourceOrganizationHistory" }, responses = {
					@ApiResponse(description = "Source Organization Found", responseCode = "200", content = @Content(mediaType = "application/json",
							array = @ArraySchema(schema = @Schema(implementation = SourceOrganizationDTO.class)))),
					@ApiResponse(description = "Source Organization Not found", responseCode = "404", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiError.class))),
					@ApiResponse(description = "Internal error", responseCode = "500", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiError.class))) })
	@ResponseStatus(HttpStatus.OK)
	@GetMapping(value = APPROVAL_WORKFLOW + SOURCE_ORGANIZATION + HON_PATH_VAR + ALL_VERSIONS,
			produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<ChangeLogResponse> getSourcesByHonAndApprovalStatus(
			@PathVariable(value = HON) @NotNull final String hon,
			@RequestParam(value = VERSION , required = false) final Double version,
			@RequestParam(value = APPROVAL_STATUS) @NotNull final ApprovalStatus approvalStatus);

	@Operation(summary = "Gets the two versions of a source organizations to differentiate the changes", tags = {
			"SourceOrganizationHistory" }, responses = {
			@ApiResponse(description = "source organizations found", responseCode = "200",
					content = @Content(mediaType = "application/json",
							array = @ArraySchema(schema = @Schema(implementation = SourceOrganizationDTO.class)))),
			@ApiResponse(description = "No source organization found", responseCode = "404", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiError.class))),
			@ApiResponse(description = "Internal error", responseCode = "500", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ApiError.class))) })
	@ResponseStatus(HttpStatus.OK)
	@GetMapping(value = APPROVAL_WORKFLOW + SOURCE_ORGANIZATION + HON_PATH_VAR +FORWARD_SLASH+ VERSION + VERSION_PATH_VAR + DIFF , produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<List<SourceOrganizationDTO>> getSourceOrganizationsForDiff(@PathVariable(value = HON) @NotNull final String hon,
			@PathVariable(value = VERSION) @NotNull final Double version, @NotNull final String sourceType);


}
