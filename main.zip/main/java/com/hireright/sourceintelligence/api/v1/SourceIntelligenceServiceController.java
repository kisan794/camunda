package com.hireright.sourceintelligence.api.v1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hireright.sourceintelligence.api.constants.APIConstants;

/**
 * This CommunicationServiceController Function: 1. Calling the Service for
 * Sending the Mail using SendGrid
 */

@RestController
@RequestMapping(APIConstants.SOURCEINTELLIGENCE_SERVICE + APIConstants.V1)
public class SourceIntelligenceServiceController {
	private static final Logger logger = LoggerFactory.getLogger(SourceIntelligenceServiceController.class);

	 
	/**
	 * health check API
	 * 
	 * @return String
	 */
	@GetMapping(APIConstants.HEALTH)
	public String test() {

		logger.info(APIConstants.LOG_HEALTH_CHECK_BEGIN);
		logger.info(APIConstants.LOG_HEALTH_CHECK_END);
		return APIConstants.HEALTH_CHECK;
	}

	
}
