package com.hireright.sourceintelligence.api.dto.timezone;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DropDownDTO {
    @JsonProperty("label")
    private String label;
    @JsonProperty("value")
    private String value;
}
