package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SortOrder;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import lombok.Builder;
import lombok.Data;

import jakarta.validation.constraints.NotNull;

import java.util.List;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SearchDTO {

    private String searchText;
    private String hon;
    private OrganizationType organizationType;
    private String state;
    private String city;
    private String country;
    private String organizationAlias;
    private SourceOrganizationStatus sourceOrganizationStatus;
    private List<String> honIds;

    @NotNull
    private int startIndex;

    @NotNull
    private int batchSize;

    @NotNull
    private SortOrder sort;

}
