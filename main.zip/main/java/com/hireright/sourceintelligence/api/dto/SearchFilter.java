package com.hireright.sourceintelligence.api.dto;

import com.hireright.sourceintelligence.api.dto.timezone.DropDownDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SearchFilter {

  private String searchKey;

  private String searchField;

  //Search history filter
  private List<OrganizationType> verificationTypes;

  private String organizationType;

  private List<ApprovalStatus> statuses;

  private List<ApproverDTO> assignees;

  private DateRange dateRange;

  private List<DropDownDTO> region;
  private String regionValue;


  private String sort;
  private String order;
  private int pageSize;
  private int startPage;

}
