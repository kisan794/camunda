package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class ContactDetails {
    private Boolean followUpAllowed;
    private String surChargeAmount;
    private String paymentMethod;
    private String turnAroundTimeUnit;
    private String surChargeCurrency;
    private String type;
    private Object priority;
    private List<Object> communication;
    private String turnAroundTime;
}
