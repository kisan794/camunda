package com.hireright.sourceintelligence.api.dto;public class ProviderDTO {
}
