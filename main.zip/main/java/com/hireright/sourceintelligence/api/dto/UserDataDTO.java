package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserDataDTO {

    private String trustScore;
    private String subject;
    private String userName;
    private String status;
    private String scope;
    private List<String> permissions;
    private List<ApproverDTO> approvalGroupList;
    private SearchRequestDTO searchRequest;
    private String userEmail;
    private String optoolInstanceName;
    private int optoolWebserverPort;
    private String hon;
    private String fromViewEdit;
    private String organizationType;
}
