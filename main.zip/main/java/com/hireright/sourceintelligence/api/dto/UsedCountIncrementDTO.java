package com.hireright.sourceintelligence.api.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UsedCountIncrementDTO {
    private boolean isAutoMatch;
    @NotNull
    private String hon;
}
