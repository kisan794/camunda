package com.hireright.sourceintelligence.api.dto.optool;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MailAddressDTO {
    private String address;
    private String country;
    private String city;
    private String region;
    private String postalCode;

    @JsonIgnore
    public boolean isEmpty() {
        return isBlank(address) &&
                isBlank(country) &&
                isBlank(city) &&
                isBlank(region) &&
                isBlank(postalCode);
    }

    private boolean isBlank(String str) {
        return str == null || str.isBlank();
    }
}
