package com.hireright.sourceintelligence.api.dto.timezone;

import lombok.Data;

import java.util.List;

@Data
public class TimeZoneResponseDTO {
    private TimeZoneMetaData metadata;
    private List<DropDownDTO> data;
}
