package com.hireright.sourceintelligence.api.dto.optool;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ContactDTO {
    private List<PhoneFaxDTO> numbers; //phone & fax
    private List<String> emails; //email
    private List<MailAddressDTO> addresses; //mail
    private List<String> websites; //websites

    //Automated Service
    private int provider;
    private String providerLink;
    private String[] codes;
    private String name;
    private String[] branches;

    //common for all contacts
    private String contact;
    private String turnAroundTime;
    private String turnAroundTimeUnit;
    private String paymentMethod;
    private String surchargeAmount;
    private String surchargeCurrency;
    private String followUpAllowedAfter;
    private String followUpAllowedAfterUnit;
    private String isFollowUpAllowed;
    private int priority;

    @JsonIgnore
    public boolean isEmptyForAS() {
        return priority == 0 &&
                provider == 999 &&
                isEmptyArray(codes) &&
                isBlank(name) &&
                isEmptyArray(branches) &&
                isBlank(surchargeAmount) &&
                isBlank(surchargeCurrency) &&
                isBlank(paymentMethod) &&
                isBlank(followUpAllowedAfter) &&
                isBlank(followUpAllowedAfterUnit) &&
                isBlank(isFollowUpAllowed) &&
                isBlank(turnAroundTime) &&
                isBlank(turnAroundTimeUnit);
    }

    private boolean isBlank(String str) {
        return str == null || str.isBlank();
    }

    private boolean isEmptyArray(Object[] arr) {
        return arr == null || arr.length == 0;
    }
}
