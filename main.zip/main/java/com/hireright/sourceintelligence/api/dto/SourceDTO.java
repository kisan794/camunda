package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import lombok.Data;

import java.time.Instant;
import java.util.List;

@JsonPropertyOrder({"Organization_Type","Organization_Name", "Organization_Alias", "Department_Name","Department_Aliases", "Address"})
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Data
public class SourceDTO {

    @JsonProperty("Hon")
    private String hon;
    @JsonProperty("Organization_Type")
    private OrganizationType organizationType;
    @JsonProperty(value = "Organization_Name")
    private String organizationName;
    @JsonProperty("Organization_Alias")
    private String organizationAlias;
    @JsonProperty("Country")
    private String country;
    @JsonProperty("State")
    private String state;
    @JsonProperty("City")
    private String city;
    @JsonProperty("Postal_Code")
    private String postalCode;
    @JsonProperty("Department_Name")
    private String departmentName;


    @JsonProperty("Address")
    private String address;

    @JsonProperty("Status")
    private String status;
    @JsonProperty("Approval_Status")
    private String approvalStatus;

    @JsonProperty("Region")
    private String region;

    @JsonProperty("Notes")
    private String notes;

    @JsonProperty("Used_Count")
    private int usedCount;

    @JsonProperty("Verification_Validation_Process")
    private String verificationValidationProcess;

    @JsonProperty("Do_Not_Contact")
    private String doNotContact;

    @JsonProperty("Contact_Details")
    private List<ContactDetailsDTO> contactDetails;

    @JsonProperty("Assigned_To")
    private String assignedTo;

    @JsonProperty("Assigned_Id")
    private String assignedId;

    @JsonProperty("Last_Approved_Date")
    private String lastApprovedDateTime;

    @JsonProperty("Last_Modified_Date")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant lastModifiedDate;

    @JsonProperty("Last_Used_Date")
    private String lastUsedDate;

    @JsonProperty("Last_CleanUp_Date")
    private String lastCleanUpDate;

    @JsonProperty("Release_Type")
    private String releaseType;

    @JsonProperty("OutOfBusiness")
    private Boolean outOfBusiness;

    @JsonProperty("Created_By")
    private String createdBy;

    @JsonProperty("Last_Modified_By")
    private String lastModifiedBy;

    @JsonProperty("Approved_By")
    private String approvedBy;

    @JsonProperty("Flag_Priority")
    private Boolean flagPriority;

    @JsonProperty("Action")
    private String action;

    @JsonProperty("Version")
    private double version;

    @JsonProperty("Temp_Version")
    private double tempVersion;

}
