package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class ApprovalRequestDTO {
    private String approverName;
    private String approverEmail;
    private String orgnaizationType;
    //private ApprovalStatus approvalStatus;
    private List<AssignSourceDTO> sourceDetails;
}
