package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AutoMatchDTO {

    @NotBlank(message = "sourceName is required")
    private String sourceName;
    @NotBlank(message = "sourceType is required")
    private String sourceType;
    @NotBlank(message = "country is required")
    private String country;
    private String state;
    @NotBlank(message = "city is required")
    private String city;
    private String requestId;
    private String region;
}
