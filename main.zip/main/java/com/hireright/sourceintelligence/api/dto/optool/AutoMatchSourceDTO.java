package com.hireright.sourceintelligence.api.dto.optool;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.JSONArray;

import java.util.List;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AutoMatchSourceDTO {
    private String platform = "sidb2";
    private String type;
    private String hon;
    private String name;
    private List<String> aliases;
    private String department;
    private String website;
    private String country;
    private String region;
    private String city;
    private String postalCode;
    private String address;
    private String comment;
    private String verificationValidationProcess;
    private String relationshipType;
    private String parentCompany;
    private String parentCountry;
    private String parentInstitution;
    private String parentID;
    private int childCount;
    private String sic;
    private String taxID;
    @JsonProperty("isUnaccredited")
    private boolean isUnaccredited;
    private boolean dotRegulated;
    private JSONArray infoRequestIDs;
    private String releaseType;
    private String language;
    private String contactPersonName;
    private String contactPersonTitle;
    private String contactTimeFrom;
    private String contactTimeTo;
    private String contactTimeZone;
    private String status;
    private String lastApproverName;
    private String lastModifierName;
    private String lastModified;
    private String lastApproved;
    private String created;
    private String lastUsed;

    private Boolean doNotContact;
    private List<Map<String, Object>> contactAutomatedServices;
    private ContactDTO contactPhones;
    private ContactDTO contactFaxes;
    private ContactDTO contactEmails;
    private ContactDTO contactWebsites;
    private ContactDTO contactMails;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public ContactDTO getContactMails() {
        if (contactMails != null
                && contactMails.getProvider() == 0
                && contactMails.getPriority() == 0) {
            return null;  // ignored in JSON
        }
        return contactMails;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public ContactDTO getContactEmails() {
        if (contactEmails != null
                && contactEmails.getProvider() == 0
                && contactEmails.getPriority() == 0) {
            return null;  // ignored in JSON
        }
        return contactEmails;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public ContactDTO getContactPhones() {
        if (contactPhones != null
                && contactPhones.getProvider() == 0
                && contactPhones.getPriority() == 0) {
            return null;  // ignored in JSON
        }
        return contactPhones;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public ContactDTO getContactFaxes() {
        if (contactFaxes != null
                && contactFaxes.getProvider() == 0
                && contactFaxes.getPriority() == 0) {
            return null;  // ignored in JSON
        }
        return contactFaxes;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public ContactDTO getContactWebsites() {
        if (contactWebsites != null
                && contactWebsites.getProvider() == 0
                && contactWebsites.getPriority() == 0) {
            return null;  // ignored in JSON
        }
        return contactWebsites;
    }

}
