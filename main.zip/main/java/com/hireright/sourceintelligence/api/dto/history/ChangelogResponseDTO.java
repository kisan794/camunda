package com.hireright.sourceintelligence.api.dto.history;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import lombok.Data;

import java.util.List;

@Data
public class ChangelogResponseDTO {

    private SourceOrganizationDTO sourceDTO;
    private List<SourceOrganizationDTO> versions;

}
