package com.hireright.sourceintelligence.api.dto;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsonorg.JSONObjectDeserializer;
import com.fasterxml.jackson.datatype.jsonorg.JSONObjectSerializer;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.JSONObject;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchPayload {

  private String addressLine;

  private List<ContactDetails> contactDetails;

  private String website;
  private String notes;
  private List<AdditionalInfo> additionalInfo;

  private String lastCleanUpDate;
  private SourceOrganizationStatus status;
  private String lastUsed;
  private String lastApprovedDateTime;


  //this is to parse if usedCount value is like {"$numberInt"="59"}
  public Integer getUsedCount() {
    String usedCountString = String.valueOf(usedCount);
    if(usedCount == null){
      return 0;
    }
    if(usedCountString != null && usedCountString.contains("$numberInt")){
      String [] arrStr = usedCountString.replaceAll("[{}]","").split("=");
      if(arrStr.length>0 && arrStr[1] != null){
        return Integer.valueOf(arrStr[1].trim());
      }else{
        return 0;
      }
    }else {
      return Integer.valueOf(usedCount.toString());
    }
  }

  private Object usedCount;

  private String primaryContact;

  private String departmentName;

  private Alias[] departmentAliases;

  private String doNotContact;

  private List<RelationshipsDTO> relationships;

  @JsonSerialize(using = JSONObjectSerializer.class)
  @JsonDeserialize(using = JSONObjectDeserializer.class)
  private JSONObject payload;
}
