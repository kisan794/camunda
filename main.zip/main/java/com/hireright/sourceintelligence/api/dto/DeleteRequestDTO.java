package com.hireright.sourceintelligence.api.dto;

import lombok.Data;

@Data
public class DeleteRequestDTO {
    private String reason;
    private UIActionsDTO uiAction;
}
