package com.hireright.sourceintelligence.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
public class AdditionalInfo {

    private String releaseType;
    private String doNotContact;
    private String sourceLanguage;
    private String version;
    private String contactPersonName;
    private String contactPersonTitle;
    private String releaseSubType;
    private String releaseWebAddress;
    private String requestApplicatDocument;
    private String linkExpiration;
    private String linkExpirationUnit;
    private String contactTimeFrom;
    private String contactTimeTo;
    private String contactTimeZone;
    private String verificationValidationProcess;
}
