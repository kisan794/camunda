package com.hireright.sourceintelligence.api.dto.timezone;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class TimeZoneMetaData {
    @JsonProperty("BatchSize")
    private int batchSize;
    @JsonProperty("StartIndex")
    private int startIndex;
    @JsonProperty("TotalSize")
    private int totalSize;
}
