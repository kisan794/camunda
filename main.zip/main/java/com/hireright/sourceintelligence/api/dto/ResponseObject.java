package com.hireright.sourceintelligence.api.dto;
import java.sql.Timestamp;
import java.util.ArrayList;

import lombok.Builder;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Component
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ResponseObject {

	private Timestamp timestamp = new Timestamp(System.currentTimeMillis());
	private String status = "SUCCESS";
	private String message = "";
	private Integer statusCode = 0;
	private ArrayList<String> errors = new ArrayList<>();
	private Object response = null;

	public static ResponseObjectBuilder baseBuilder(String status, String message, Integer statusCode) {
		return ResponseObject.builder().status(status)
				.message(message)
				.statusCode(statusCode);
	}
}
