package com.hireright.sourceintelligence.api.dto.optool;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PhoneFaxDTO {
    private String countryCode;
    private String areaCode;
    private String number;
    private String extension;
    private String contact;
    private String phoneCountryCode;

    @JsonIgnore
    public boolean isEmpty() {
        return (isBlank(countryCode) &&
                isBlank(areaCode) &&
                isBlank(number) &&
                isBlank(extension));
    }

    private boolean isBlank(String str) {
        return str == null || str.isBlank();
    }
}
