package com.hireright.sourceintelligence.api.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.hireright.sourceintelligence.api.constants.APIConstants;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * This is the response to be returned in invalid scenarios.
 */
@NoArgsConstructor
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@Component
@Scope(APIConstants.SCOPE_PROTOTYPE)
public class Error {

	private String errorCode;
	
	private Object field;
	
	private String message;
}
