package com.hireright.sourceintelligence.api.constants;

public class APIConstants {
	private APIConstants() {

	}

	// endpoint related constants
	public static final String SOURCEINTELLIGENCE_SERVICE = "/sourceintelligence-service";
	public static final String V1 = "/1.0";
	public static final String HEALTH = "/health";
	
	// message related constants
	public static final String HEALTH_CHECK = "Up and running!";

	// framework related constants
	public static final String SCOPE_PROTOTYPE = "prototype";
	
	// logging related constants
	public static final String LOG_HEALTH_CHECK_BEGIN = "Beginning operation to invoke health check API";
	public static final String LOG_HEALTH_CHECK_END = "Ending operation to invoke health check API";

}
