package com.hireright.sourceintelligence.exception;

public class ExperianInvalidRequestException extends RuntimeException {
    public ExperianInvalidRequestException() {
        super();
    }
    public ExperianInvalidRequestException(String message) {
        super(message);
    }
    public ExperianInvalidRequestException(String message, Throwable cause) {
        super(message, cause);
    }
}

