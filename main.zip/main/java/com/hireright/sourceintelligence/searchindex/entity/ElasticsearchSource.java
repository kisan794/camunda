package com.hireright.sourceintelligence.searchindex.entity;

import lombok.Data;

import java.util.List;

@Data
public class ElasticsearchSource {
    private String hon;
    private String organizationName;
    private List<String> organizationAlias;
    private String country;
    private String state;
    private String city;
    private String postalCode;
    private String addressLine;
    private String department;
    private String website;
    private List<String> automatedService;
    private List<String> code;
    private List<String> phoneNumber;
    private List<String> faxNumber;
    private List<String> email;
    private String status;
    private String approvalStatus;
    private int usedCount;
}
