package com.hireright.sourceintelligence.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.hireright.sourceintelligence.api.dto.ExternalResponse;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.web.client.RestClientException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface ExternalService {

    @Retryable(value = {RestClientException.class},
            maxAttempts = 3,
            backoff = @Backoff(delay = 1000, multiplier = 2))
    ExternalResponse getExternalApiResponse(String key);

    @Retryable(value = {RestClientException.class},
            maxAttempts = 3,
            backoff = @Backoff(delay = 1000, multiplier = 2))
    JsonNode getHRGPermissions(String hrg1PermissionApiUrl);

    @Retryable(value = {RestClientException.class},
            maxAttempts = 3,
            backoff = @Backoff(delay = 1000, multiplier = 2))
    JsonNode getApproversList(String hrg1ApproversApiUrl);

    @Retryable(value = {RestClientException.class},
            maxAttempts = 3,
            backoff = @Backoff(delay = 1000, multiplier = 2))
    String retryUploadService(MultipartFile file, String documentMeta);

    ResponseEntity<InputStreamResource> getAttachmentByUrl(String documentId);

    String deleteAttachment(String documentId) throws InterruptedException, IOException;

    String getHtmlResponseByHon(String hon);

}
