package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;

import java.util.*;

public interface SourceService {

    SourceOrganizationDTO createSource(SourceOrganizationDTO sourceIntelligence, UIActionsDTO uiActionsDTO);

    SourceOrganizationDTO getSourceByHon(String hon);

    ResponseObject archiveSource(String hon, UIActionsDTO uiActionsDTO);

    SourceOrganizationDTO updateSource(SourceOrganizationDTO sourceIntelligence, UIActionsDTO uiActionsDTO);

    AutoMatchResponseDTO incrementUsedCount(String hon, ApprovalStatus approvalStatus);

    List<SourceOrganizationDTO> getSourcesByHonIds(List<String> hons);

    ResponseObject assignApproveManagerToSource(ApprovalRequestDTO approvalRequestDTO);

    boolean updateFlagForPriority(String hon, Double version);

    boolean updateUsedCount(String hon, boolean isAutoMatch);

    ResponseObject deleteSource(String hon, DeleteRequestDTO deleteRequestDTO);

    ResponseObject lockSource(String hon, UIActionsDTO uiActionsDTO);

    ResponseObject unlockSource(String hon, UIActionsDTO uiActionsDTO);

    SourceOrganizationDTO getSourceByHonAndApprovalStatus(String hon, ApprovalStatus approvalStatus);

    SourceOrganizationDTO getSourceByHonForOpTool(String hon);

    SourceOrganizationDTO getSourceForEditByHon(String hon, String action);

    boolean updateSourceStatus(String hon, String version,String tempVersion, ApprovalStatus approvalStatus);



}
