package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.AutocompleteSearchDTO;
import com.hireright.sourceintelligence.api.dto.HighlightDTO;
import com.hireright.sourceintelligence.api.dto.KeyMatchDTO;
import com.hireright.sourceintelligence.api.dto.UserInfo;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import com.hireright.sourceintelligence.domain.entity.FieldValueInfo;
import jakarta.servlet.http.HttpServletRequest;

public interface CommonUtilService {

  <T> T convertJsonToPOJO(String source, Class<T> target);

  String getDateAsString(Date date, String pattern);

  String base64decoder(String encodedString);

  <V> void setIfNotNullAndEmpty(V value, Consumer<V> setter);

  <T> T convertBytesToPOJO(byte[] source, Class<T> target);

  UserInfo getUserInfo(HttpServletRequest httpServletRequest);

  boolean isResearchAnalyst(List<String> roles);

  Map<String,List<KeyMatchDTO>> categorizeMatchedValuesFromHighlightedObject(String category, FieldValueInfo info ,
                                                                             Map<String,List<KeyMatchDTO>> mapOfCategorySearch, HighlightDTO highlightDTO);

  Map<String,List<KeyMatchDTO>> categorizeMatchedValues(String category, FieldValueInfo info ,
                                                        Map<String,List<KeyMatchDTO>> mapOfCategorySearch);

  List<AutocompleteSearchDTO> getTopFiveCategorySearches(Map<String,List<KeyMatchDTO>> mapOfCategorySearch);

  boolean isQualityAnalystOnly(List<String> roles);

}
