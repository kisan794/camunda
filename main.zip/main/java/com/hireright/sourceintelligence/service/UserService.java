package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.Users;

public interface UserService {

  Users getUserAccountServiceUsers(String username);
}
