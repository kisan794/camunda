package com.hireright.sourceintelligence.service.impl;

import static com.hireright.sourceintelligence.api.ApiConstants.FAILURE;
import static com.hireright.sourceintelligence.api.ApiConstants.SUCCESS;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.*;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.APPROVED;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.IN_PROGRESS;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ErrorMessages.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ReportActions.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.StatusCode.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.*;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchSourceDTO;
import com.hireright.sourceintelligence.constants.ApplicationConstants;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.AutoMatchMapper;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.*;
import com.hireright.sourceintelligence.service.*;
import com.hireright.sourceintelligence.service.impl.helperservices.CreateSourceService;
import com.hireright.sourceintelligence.service.impl.helperservices.ArchiveSourceService;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import com.hireright.sourceintelligence.service.impl.helperservices.UpdateSourceService;
import com.hireright.sourceintelligence.util.Helper;

import java.time.Instant;
import java.util.*;

import com.mongodb.client.MongoClient;
import jakarta.validation.constraints.NotNull;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;


@Primary
@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
public class SourceServiceImpl implements SourceService {

    private static final String SOURCE_ORGANIZATION_WITH_HON = "SourceOrganization with HON: ";

    private final CustomSourceRepository<Source> customSourceRepository;
    private final SourceMapper sourceMapper;
    private final ReportDataUtils reportDataUtils;
    private final AutoMatchMapper autoMatchMapper;

    private final CreateSourceService createSourceService;
    private final UpdateSourceService updateSourceService;
    private final ArchiveSourceService archiveSourceService;
    private final MongoSourceService mongoSourceService;

    @Transactional
    @Override
    public SourceOrganizationDTO createSource(@NotNull SourceOrganizationDTO sourceOrganizationDTO, UIActionsDTO uiActionsDTO) {
        try {
            return createSourceService.createSource(sourceOrganizationDTO, uiActionsDTO);
        } catch (Exception e) {
            logAndThrowServiceException(CREATE_SOURCE_ERROR, e, sourceOrganizationDTO.getOrganizationName(), e.getMessage());
        }
        return null;
    }

    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
    @Override
    public SourceOrganizationDTO updateSource(SourceOrganizationDTO sourceDTO, UIActionsDTO uiActionsDTO) {
        try {
            return updateSourceService.updateSource(sourceDTO, uiActionsDTO);
        } catch (Exception e) {
            logAndThrowServiceException(UPDATE_SOURCE_ERROR, e, sourceDTO.getHon(), e.getMessage());
        }
        return null;
    }

    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
    @Override
    public ResponseObject archiveSource(String hon, UIActionsDTO uiActionsDTO) {
        ResponseObject responseObject = null;
        try {
            boolean response = archiveSourceService.archiveSource(hon, uiActionsDTO);
            if(response){
                responseObject = ResponseObject.baseBuilder(SUCCESS,ARCHIVE_SUCCESS,SUCCESS_CODE).build();
            }else{
                responseObject = ResponseObject.baseBuilder(FAILURE,ARCHIVE_FAILURE,FAILURE_CODE).build();
            }
        } catch (Exception e) {
            logAndThrowServiceException(DELETE_SOURCE_ERROR, e, hon, e.getMessage());
        }
        return responseObject;
    }

    @Override
    @Transactional
    public AutoMatchResponseDTO incrementUsedCount(String hon, ApprovalStatus approvalStatus) {
        log.info("Manual select source request: {}", hon);
        Instant requestTime = Instant.now();
        var entityFromDb = mongoSourceService.findSourceByHonAndApprovalStatus(hon, approvalStatus);
        if (entityFromDb == null) {
            logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, hon);
        }
        if (entityFromDb != null && entityFromDb.getPayload() == null) {
            logAndThrowInvalidRequest(SEARCH_TEXT_MISSING, null);
        }
        log.info("current system date: {}", requestTime);
        AutoMatchSourceDTO response = autoMatchMapper.toAutoMatchDTO(entityFromDb);

        assert entityFromDb != null;
        log.info("Manual select source response: {}", response);
        log.info("Source organization with hon: {} was last verified on {}", hon, requestTime);
        return AutoMatchResponseDTO.baseBuilder("", requestTime).source(response).build();
    }

    @Override
    public List<SourceOrganizationDTO> getSourcesByHonIds(List<String> honIds) {
        List<Source> sourceList = customSourceRepository.findByHonIn(honIds, Source.class, Helper.getCollectionName(honIds.get(0), SOURCE_COLLECTION_SUFFIX));
        if (!ObjectUtils.isEmpty(sourceList)) {
            return sourceMapper.toSourceDTOList(sourceList);
        }
        return Collections.emptyList();
    }

    @Override
    public SourceOrganizationDTO getSourceByHon(@NotNull String hon) {
        Source source = mongoSourceService.findSourceByHon(hon);
        if (source == null) {
            logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, hon);
        }
        return sourceMapper.entitySourceToDTO(source);
    }

    @Override
    public ResponseObject assignApproveManagerToSource(ApprovalRequestDTO approvalRequestDTO) {
        List<String> hons = new ArrayList<>();
        Query query = new Query();
        List<String> approvalStatuses = new ArrayList<>(){};
        approvalStatuses.add(IN_PROGRESS.toString());
        approvalStatuses.add(ONHOLD.toString());
        if (!approvalRequestDTO.getSourceDetails().isEmpty()) {
            for (AssignSourceDTO assignSourceDTO : approvalRequestDTO.getSourceDetails()) {
                Source source = mongoSourceService.findSourceByHonAndApprovalStatus(assignSourceDTO.getHon(),assignSourceDTO.getApprovalStatus());
                if (source != null) {
                    if (source.getApprovalStatus().equals(PENDING_APPROVAL) || source.getApprovalStatus().equals(SAVE_PENDING_APPROVAL) || source.getApprovalStatus().equals(ONHOLD)) {
                        Source existingSource = mongoSourceService.findSourceByHonAndApprovalStatuses(assignSourceDTO.getHon(),approvalStatuses);
                        if(existingSource == null){
                            hons.add(assignSourceDTO.getHon());
                            query.addCriteria(Criteria.where(HON).is(assignSourceDTO.getHon()));
                            query.addCriteria(Criteria.where(APPROVAL_STATUS).is(assignSourceDTO.getApprovalStatus()));
                        }else{
                            return ResponseObject.baseBuilder(FAILURE,ASSIGN_FAILURE_2,FAILURE_CODE).build();
                        }
                    }else{
                        return ResponseObject.baseBuilder(FAILURE,ASSIGN_FAILURE,FAILURE_CODE).build();
                    }
                }
            }
        }
        if (!hons.isEmpty()) {
            customSourceRepository.assignApproverToSource(query, approvalRequestDTO.getApproverName(), approvalRequestDTO.getApproverEmail(), Helper.getCollectionName(approvalRequestDTO.getOrgnaizationType(), SOURCE_COLLECTION_SUFFIX));
            reportDataUtils.createReportData(approvalRequestDTO, hons);
            return ResponseObject.baseBuilder(SUCCESS,ASSIGN_SUCCESS,SUCCESS_CODE).build();
        }
        return ResponseObject.baseBuilder(FAILURE,ASSIGN_FAILURE,FAILURE2_CODE).build();
    }

    @Override
    @Transactional
    public boolean updateFlagForPriority(String hon, Double version) {
        var entityFromDb = findSourceByHonAndVersion(hon, version);
        if (entityFromDb == null) {
            logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, hon);
            return false;
        }
        Boolean flag = entityFromDb.getFlagPriority() == null ? Boolean.TRUE : !entityFromDb.getFlagPriority();
        String collectionName = Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
        Update update = new Update().set(FLAG_PRIORITY, flag);
        update.set(LAST_ACTION_DATE, Instant.now());
        Query query = new Query().addCriteria(Criteria.where(HON).is(hon));
        updateByIdWithCustomFields(query, update, collectionName);
        log.info("Organization with hon:{} flagged {} for priority", hon, entityFromDb.getFlagPriority());
        return flag;
    }

    @Override
    public ResponseObject deleteSource(String hon, DeleteRequestDTO deleteRequestDTO) {
        try {
            long count = mongoSourceService.hardDeleteSource(hon, deleteRequestDTO);
            if(count == 0){
                return ResponseObject.baseBuilder(FAILURE,DELETE_FAILURE,FAILURE2_CODE).build();
            }
            return ResponseObject.baseBuilder(SUCCESS,DELETE_SUCCESS,SUCCESS_CODE).build();
        }catch (Exception e) {
            return ResponseObject.baseBuilder(FAILURE,INTERNAL_FAILURE,INTERNAL_ERROR_CODE).build();
        }
    }

    @Override
    public ResponseObject lockSource(String hon, UIActionsDTO uiActionsDTO) {
        Source source = mongoSourceService.findSourceByHon(hon);
        if(source != null){
            if(Boolean.FALSE.equals(source.getIsLockEnabled())){
                String collectionName = Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
                Update update = new Update().set(IS_LOCK_ENABLED, true)
                        .set(LAST_LOCKED_BY,uiActionsDTO.getUserName())
                        .set(LAST_LOCKED_ID,uiActionsDTO.getUserEmail())
                        .set(LAST_LOCKED_DATE,Instant.now())
                        .set(LOG_FLAG,SearchConstants.LogFlagConstants.LOCKED);
                Query query = new Query().addCriteria(Criteria.where(HON).is(hon));
                updateByIdWithCustomFields(query, update, collectionName);
                Source sourceHistory = updateLockAndUnlockFields(source, uiActionsDTO);
                mongoSourceService.insertSourceHistory(sourceHistory);
                reportDataUtils.reportData(source, LOCK, SIDB_ORIGIN,0,null);
                return ResponseObject.baseBuilder(SUCCESS,LOCK_SUCCESS,SUCCESS_CODE).build();
            }else{
                return ResponseObject.baseBuilder(FAILURE,LOCK_FAILURE,FAILURE_CODE).build();
            }
        }
        return ResponseObject.baseBuilder(FAILURE,LOCK_FAILURE_2,FAILURE2_CODE).build();
    }

    @Override
    public ResponseObject unlockSource(String hon, UIActionsDTO uiActionsDTO) {
        Source source = mongoSourceService.findSourceByHon(hon);
        if(source != null){
            if(Boolean.TRUE.equals(source.getIsLockEnabled())){
              String collectionName = Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
                Update update = new Update().set(IS_LOCK_ENABLED, false)
                        .set(LAST_LOCKED_BY,uiActionsDTO.getUserName())
                        .set(LAST_LOCKED_ID,uiActionsDTO.getUserEmail())
                        .set(LAST_LOCKED_DATE,Instant.now())
                        .set(LOG_FLAG,source.getAction().equalsIgnoreCase(ApplicationConstants.CREATE) ? SearchConstants.LogFlagConstants.NEW_RECORD : SearchConstants.LogFlagConstants.DETAILS_CHANGED);
                Query query = new Query().addCriteria(Criteria.where(HON).is(hon));
                updateByIdWithCustomFields(query, update, collectionName);
                Source sourceHistory = updateLockAndUnlockFields(source, uiActionsDTO);
                mongoSourceService.insertSourceHistory(sourceHistory);
                reportDataUtils.reportData(source, UNLOCK, SIDB_ORIGIN,0,null);
                return ResponseObject.baseBuilder(SUCCESS,UNLOCK_SUCCESS,SUCCESS_CODE).build();
            }else{
                return ResponseObject.baseBuilder(FAILURE,UNLOCK_FAILURE,FAILURE_CODE).build();
            }
        }
        return ResponseObject.baseBuilder(FAILURE,UNLOCK_FAILURE2,FAILURE2_CODE).build();
    }

    @Override
    public boolean updateUsedCount(String hon, boolean isAutoMatch) {
        log.info("Update used count source request: {}", hon);
        var entityFromDb = findSourceByHonAndStatusAndApprovalStatus(hon, SourceOrganizationStatus.ACTIVE.getStatus(), APPROVED.getStatus());
        if (entityFromDb == null) {
            logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, hon);
        }
        if (entityFromDb != null && entityFromDb.getPayload() == null) {
            logAndThrowInvalidRequest(SEARCH_TEXT_MISSING, null);
        }
        log.info("current system date: {}", Instant.now().toString());
        Source source = customSourceRepository.UpdateDateOnIncrementByHon(hon, Instant.now().toString(), Source.class, Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX));
        if (source != null) {
            /* Report Data Starts */
            int autoMatch = isAutoMatch ? 1 : 0;
            reportDataUtils.reportData(entityFromDb, SearchConstants.ReportActions.USED_COUNT, ORIGIN, autoMatch, null);
            /* Report Data Ends */
            return true;
        }
        return false;
    }

    @Transactional
    @Override
    public SourceOrganizationDTO getSourceByHonAndApprovalStatus(@NotNull String hon, ApprovalStatus approvalStatus) {
        Source source = mongoSourceService.findSourceByHonAndApprovalStatus(hon, approvalStatus);
        if (source == null) {
            return null;
        }
        if(source.getApprovalStatus().equals(approvalStatus)){
            return sourceMapper.entitySourceToDTO(source);
        }else{
            //Temparory fix
            log.info("temp fix");
            source = mongoSourceService.findSourceByHonAndApprovalStatus(hon, approvalStatus);
            if (source == null) {
                return null;
            }
            if(source.getApprovalStatus().equals(approvalStatus)){
                return sourceMapper.entitySourceToDTO(source);
            }
            return null;
        }
    }

    @Override
    public SourceOrganizationDTO getSourceByHonForOpTool(@NotNull String hon) {
        Source source = mongoSourceService.findSourceByHonOrderByLastModifiedBy(hon);
        if (source == null) {
            return null;
            //logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, hon);
        }
        return sourceMapper.entitySourceToDTO(source);
    }

    @Override
    public SourceOrganizationDTO getSourceForEditByHon(@NotNull String hon, String action) {
        Source source = mongoSourceService.findSourceByHonOrderByLastModifiedBy(hon);
        if (source == null && action.equalsIgnoreCase(action)) {
            Source source2 = mongoSourceService.findSourceByHon(hon);
            if (source2 == null) {
                return null;
            }
            log.info("id: {}", source2.getId());
            source2.setApprovalStatus(PENDING_APPROVAL);
            source2.setAssignedTo(UNASSIGNED);
            source2.setAssignedId(UNASSIGNED);
            source2.setGeneralErrors(new ArrayList<>());
            source2.setFieldErrors(new ArrayList<>());
            source2.setComments("");
            return sourceMapper.entitySourceToDTO(source2);
        }
        if (source != null) {
            log.info("id: {}", source.getId());
            return sourceMapper.entitySourceToDTO(source);
        }
        return null;
    }


    @Transactional
    @Override
    public boolean updateSourceStatus(String hon, String version, String tempVersion, ApprovalStatus approvalStatus) {
        Query query = new Query();
        query.addCriteria(Criteria.where(HON).is(hon));
        query.addCriteria(Criteria.where(APPROVAL_STATUS).in(IN_PROGRESS, ONHOLD));
        String collectionName = Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
        var entityFromDb = findSourceByQuery(query, collectionName);
        if (entityFromDb == null || (entityFromDb != null && entityFromDb.getVersion() == Double.parseDouble(version) && entityFromDb.getTempVersion() == Double.parseDouble(tempVersion))) {
            Query query1 = new Query();
            query1.addCriteria(Criteria.where(HON).is(hon));
            query1.addCriteria(Criteria.where(SearchConstants.SearchFields.VERSION).is(Double.parseDouble(version)));
            query1.addCriteria(Criteria.where(TEMP_VERSION).is(Double.parseDouble(tempVersion)));
            query1.addCriteria(Criteria.where(APPROVAL_STATUS).in(PENDING_APPROVAL, SAVE_PENDING_APPROVAL, ONHOLD));
            var currentSource = findSourceByQuery(query1, collectionName);
            if (currentSource == null) {
                logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, hon);
            }
            currentSource.setApprovalStatus(approvalStatus);
            currentSource.setApprovalStartDate(Instant.now());
            Update update = new Update().set(APPROVAL_STATUS, approvalStatus).set("approvalStartDate",Instant.now());
            Query query2 = new Query().addCriteria(Criteria.where("_id").is(currentSource.getId()));
            var response = updateByIdWithCustomFields(query2, update, collectionName);
            log.info("Organization with hon: {} approvedStatus: {}", hon, currentSource.getApprovalStatus());
            reportDataUtils.reportData(currentSource, SearchConstants.ReportActions.IN_PROGRESS, SIDB_CURD, 0, null);
            return response;
        }else{
            logAndThrowResourceNotFound(SOURCE_ALREADY_IN_PROGRESS, null, hon);
        }
        return false;
    }

    private Source findSourceByHon(@NotNull String hon) {
        try {
            return customSourceRepository.findOneByHon(hon, Source.class, Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX));
        } catch (Exception ex) {
            logAndThrowInternalServiceException(NO_SEARCH_RESULT_FOUND, ex);
        }
        return null;
    }

    private Source findSourceByHonAndStatusAndApprovalStatus(@NotNull String hon, String status, String approvalStatus) {
        try {
            List<Source> sources = customSourceRepository.findByHonAndStatusAndApprovalStatus(hon, status, approvalStatus, Source.class, Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX));
            if (!sources.isEmpty()) {
                return sources.get(0);
            }
        } catch (Exception ex) {
            logAndThrowInternalServiceException(NO_SEARCH_RESULT_FOUND, ex);
        }
        return null;
    }

    private Boolean updateByQuery(Query query, @NotNull Source entityToPersist, String collectionName) {
        //entityToPersist.setId(null);
        return customSourceRepository.updateByQuery(query, entityToPersist, Source.class, collectionName);
    }


    private Source findSourceByHonAndVersion(@NotNull String hon, Double version) {
        try {
            Query query = new Query();
            query.addCriteria(Criteria.where(HON).is(hon));
            query.addCriteria(Criteria.where(SearchConstants.SearchFields.VERSION).is(version));
            //query.addCriteria(Criteria.where(APPROVAL_STATUS).in(PENDING_APPROVAL, SAVE_PENDING_APPROVAL,IN_PROGRESS));
            List<Source> result = customSourceRepository.findByQuery(query, Source.class, Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX));
            log.info("FindByHonAndVersion: Result: {}", result);
            if (!result.isEmpty()) {
                return result.get(0);
            }
        } catch (Exception ex) {
            logAndThrowInternalServiceException(NO_SEARCH_RESULT_FOUND, ex);
        }
        return null;
    }

    private Source findSourceByQuery(Query query, String collectionName) {
        try {
            List<Source> result = customSourceRepository.findByQuery(query, Source.class, collectionName);
            log.info("FindByHonAndVersion: Result: {}", result);
            if (!result.isEmpty()) {
                return result.get(0);
            }
        } catch (Exception ex) {
            logAndThrowInternalServiceException(NO_SEARCH_RESULT_FOUND, ex);
        }
        return null;
    }

    private Boolean update(String queryField, String queryValue, @NotNull Source entityToPersist, String collectionName) {
        entityToPersist.setId(null);
        return customSourceRepository.update(queryField, queryValue, entityToPersist, Source.class, collectionName);
    }

    private Boolean updateByIdWithCustomFields(Query query, Update update, String collectionName) {
        return customSourceRepository.updateFieldsByQuery(query, update, Source.class, collectionName);
    }

    private Source updateLockAndUnlockFields(Source source, UIActionsDTO uiActionsDTO){
        source.setLastActionDate(Instant.now());
        if(uiActionsDTO.getUserAction().equalsIgnoreCase(LOCK)){
            source.setIsLockEnabled(true);
            source.setLastLockedBy(uiActionsDTO.getUserName());
            source.setLastLockedId(uiActionsDTO.getUserEmail());
            source.setLastLockedDate(Instant.now());
            source.setLogFlag(SearchConstants.LogFlagConstants.LOCKED);
        }else{
            source.setIsLockEnabled(false);
            source.setLastUnLockedBy(uiActionsDTO.getUserName());
            source.setLastUnLockedId(uiActionsDTO.getUserEmail());
            source.setLastUnLockedDate(Instant.now());
            source.setLogFlag(source.getAction().equalsIgnoreCase(ApplicationConstants.CREATE) ? SearchConstants.LogFlagConstants.NEW_RECORD : SearchConstants.LogFlagConstants.DETAILS_CHANGED);
        }
        return source;
    }

}
