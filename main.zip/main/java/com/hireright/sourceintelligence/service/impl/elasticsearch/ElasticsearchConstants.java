package com.hireright.sourceintelligence.service.impl.elasticsearch;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

public class ElasticsearchConstants {

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    public static class SearchFields {
        public static final String HON = "hon";
        public static final String ORG_NAME = "organizationName";
        public static final String ORG_ALIAS = "organizationAlias";
        public static final String ADDRESS_LINE = "addressLine";
        public static final String DEPARTMENT = "department";
        public static final String WEBSITE = "website";
        public static final String COUNTRY = "country";
        public static final String STATE = "state";
        public static final String CITY = "city";
        public static final String POSTAL_CODE = "postalCode";
        public static final String AUTOMATED_SERVICE = "automatedService";
        public static final String CODE = "code";
        public static final String EMAIL = "email";
        public static final String PHONE_NUMBER = "phoneNumber";
        public static final String FAX_NUMBER = "faxNumber";
        public static final String STATUS = "status";
        public static final String APPROVAL_STATUS = "approvalStatus";


        public static final String DEPARTMENT_NAME = "departmentName";

    }
    public static final int US_LIMIT = 5;

    public static class Regions {
        public static final String US = "US";
        public static final String NON_US = "EMEA";
    }
    public static class EsFields {
        public static final String ORG_NAME_EXACT = "organizationName.exact";
        public static final String ORG_ALIAS_EXACT = "organizationAlias.exact";

        public static final String ORG_NAME_FUZZY = "organizationName.fuzzy";
        public static final String ORG_ALIAS_FUZZY = "organizationAlias.fuzzy";

        public static final String ORG_NAME_AUTOCOMPLETE = "organizationName.autocomplete";
        public static final String ORG_ALIAS_AUTOCOMPLETE = "organizationAlias.autocomplete";

    }
}

