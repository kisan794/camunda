package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogFilters;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SortOrder;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.json.*;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.ADDRESS;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.*;
import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.VALUE;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ADDRESS_LINE;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.AggregationPipelineStages.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.DEPARTMENT_NAME;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.PayloadFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.Regex.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.CITY;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.HON;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.POSTAL_CODE;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.VERSION;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchProjectionFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SortFields.SORTASSIGNEDTO;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SortFields.SORTLASTMODIFIEDBY;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

public class QueryBuilder {

    public static Criteria buildCriteriaForLikeStartsWith(String fieldName, String fieldValue) {
        return Criteria.where(fieldName).regex(PIPE + fieldValue);
    }

    public static MatchOperation buildMatch(Criteria criteria) {
        return match(criteria);
    }

    public static Criteria buildMustClauseDocumentWithFilters(Map<String, Set<String>> searchFilters) {
        Criteria criteria = new Criteria();
        for (Map.Entry<String, Set<String>> searchFilter : searchFilters.entrySet()) {
            String searchField = searchFilter.getKey();
            String searchValue = searchFilter.getValue().iterator().next();
            List<String> listSearchValue = new ArrayList<>();
            if (searchField.equals(LOG_FLAG) || searchField.equals(APPROVAL_STATUS) || searchField.equals(ASSIGNED_TO)) {
                listSearchValue = searchFilter.getValue().stream().toList();
            }
            switch (searchField) {
                case ORGANIZATION_NAME -> criteria.and(SEARCH_ORG).regex(searchValue.toLowerCase());
                case ORGANIZATION_ALIAS -> criteria.and(ORGANIZATION_ALIAS).regex(searchValue);
                case HON -> criteria.and(HON).is(searchFilter.getValue());
                case ASSIGNED_TO -> criteria.and(ASSIGNED_TO).in(listSearchValue);
                case COUNTRY -> criteria.and(COUNTRY).is(searchFilter.getValue());
                case STATE -> criteria.and(STATE).is(searchFilter.getValue());
                case CITY -> criteria.and(CITY).is(searchValue);
                case POSTAL_CODE -> criteria.and(POSTAL_CODE).is(searchValue);
                case STATUS -> criteria.and(STATUS).is(searchValue);
                case LOG_FLAG -> criteria.and(LOG_FLAG).in(listSearchValue);
                case APPROVAL_STATUS -> criteria.and(APPROVAL_STATUS).in(listSearchValue);
                default -> logAndThrowInvalidRequest(SEARCH_NOT_SUPPORTED, null, searchField);
            }
        }
        return criteria;
    }

    public static Document buildAutocompleteProjectionDocument() {
        return new Document(PROJECT,
                new Document(ORGANIZATION_NAME, 1L)
                        .append(HON, 1L)
                        .append(OUT_OF_BUSINESS, 1L)
                        .append(CITY, 1L)
                        .append(STATE, 1L)
                        .append(COUNTRY, 1L)
                // .append(POSTAL_CODE, 1L)
        );
    }

    public static MatchOperation buildAutocompleteSearchDocument(String keyword, boolean isRAM) {
        Criteria criteria = new Criteria();
        criteria.and(SEARCH_ORG).regex(PIPE + keyword.toLowerCase());
        if (!isRAM) {
            criteria.and(APPROVAL_STATUS).is(ApprovalStatus.APPROVED);
        }

        return QueryBuilder.buildMatch(criteria);
    }

    public static Criteria buildDuplicateSearchDocument(String keyword) {
        return Criteria.where(SEARCH_ORG).regex(PIPE + keyword.toLowerCase().trim())
                .and(APPROVAL_STATUS).ne(ApprovalStatus.REJECTED)
                .norOperator(Criteria.where(STATUS).is(SourceOrganizationStatus.INACTIVE.getStatus()).and(APPROVAL_STATUS).is(ApprovalStatus.APPROVED));
    }

    /* For Autocomplete detailed search
     */
    public static Criteria buildAutocompleteSearchDocument(String keyword, String country, SourceOrganizationStatus status) {
        Criteria criteria = new Criteria();
        List<Criteria> orOperator = new ArrayList<>();
        orOperator.add(Criteria.where(SEARCH_ORG).regex(keyword.toLowerCase().trim()));
        orOperator.add(Criteria.where(ORGANIZATION_ALIAS).regex(keyword.trim()));
        criteria.and(STATUS).is(status == null ? SourceOrganizationStatus.ACTIVE.getStatus() : status.getStatus());
        if (StringUtils.isNoneEmpty(country)) {
            criteria.and(COUNTRY).is(country);
        }
        criteria.orOperator(orOperator);
        return criteria;
    }

    public static Criteria buildDocumentByFilter(Map<String, Set<String>> mapFilters) {
        return buildMustClauseDocumentWithFilters(mapFilters);
    }

    public static Criteria buildDocumentForChangeLog(ChangeLogFilters changeLogFilters) {
        Criteria criteria = new Criteria();
        if (!StringUtils.isEmpty(changeLogFilters.getOrganizationName())) {
            criteria.and(SEARCH_ORG).is(changeLogFilters.getOrganizationName().toLowerCase());
        }
        if (!StringUtils.isEmpty(changeLogFilters.getHon())) {
            criteria.and(HON).is(changeLogFilters.getHon());
        }
        if (!ObjectUtils.isEmpty(changeLogFilters.getActivities())) {
            criteria.and(LOG_FLAG).in(changeLogFilters.getActivities());
        }
        if (!ObjectUtils.isEmpty(changeLogFilters.getDateRange())) {
            criteria.and(LAST_MODIFIED_DATE).gte(Date.from(changeLogFilters.getDateRange().getStartDate()))
                    .lte(Date.from(changeLogFilters.getDateRange().getEndDate()));
        }
        return criteria;
    }

    public static Criteria buildDocumentForApprovalManager(SearchFilter searchFilter) {
        Criteria criteria = new Criteria();

        applyAssigneeFilter(criteria, searchFilter);
        applyStatusFilter(criteria, searchFilter);
        applyDateRangeFilter(criteria, searchFilter);
        applySearchKeyFilter(criteria, searchFilter);
        applyDefaultFallback(criteria, searchFilter);

        return criteria;
    }

    private static void applyAssigneeFilter(Criteria criteria, SearchFilter searchFilter) {
        if (searchFilter.getAssignees() == null || searchFilter.getAssignees().isEmpty()) {
            return;
        }

        List<String> assigneeToList = searchFilter.getAssignees().stream()
                .map(ApproverDTO::getApproverName)
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.toList());

        if (!assigneeToList.isEmpty()) {
            criteria.and(ASSIGNED_TO).in(assigneeToList);
        }
    }

    private static void applyStatusFilter(Criteria criteria, SearchFilter searchFilter) {
        List<ApprovalStatus> statuses = searchFilter.getStatuses();
        if (statuses == null || statuses.isEmpty()) return;

        ApprovalStatus firstStatus = statuses.get(0);
        if (statuses.size() == 1 && firstStatus.equals(ApprovalStatus.APPROVED)) {
            criteria.and(APPROVAL_STATUS).is(firstStatus);
            criteria.norOperator(
                    Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus())
                            .and(STATUS).is(SourceOrganizationStatus.ACTIVE.getStatus())
                            .and(ACTION).is(DELETE)
            );
        } else if (statuses.size() == 1 && firstStatus.equals(ApprovalStatus.REJECTED)) {
            criteria.orOperator(
                    Criteria.where(APPROVAL_STATUS).is(firstStatus),
                    Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus())
                            .and(STATUS).is(SourceOrganizationStatus.ACTIVE.getStatus())
                            .and(ACTION).is(DELETE)
            );
        } else {
            criteria.and(APPROVAL_STATUS).in(statuses);
        }
    }

    private static void applyDateRangeFilter(Criteria criteria, SearchFilter searchFilter) {
        if (searchFilter.getDateRange() == null
                || searchFilter.getDateRange().getStartDate() == null
                || searchFilter.getDateRange().getEndDate() == null) {
            return;
        }

        criteria.and(LAST_MODIFIED_DATE)
                .gte(Date.from(searchFilter.getDateRange().getStartDate()))
                .lte(Date.from(searchFilter.getDateRange().getEndDate()));
    }

    private static void applySearchKeyFilter(Criteria criteria, SearchFilter searchFilter) {
        if (StringUtils.isNotEmpty(searchFilter.getSearchKey()) &&
                StringUtils.isNotEmpty(searchFilter.getSearchField())) {
            criteria.and(searchFilter.getSearchField()).is(searchFilter.getSearchKey());
        }
    }

    private static void applyDefaultFallback(Criteria criteria, SearchFilter searchFilter) {
        boolean isEmpty = StringUtils.isEmpty(searchFilter.getSearchKey()) &&
                ObjectUtils.isEmpty(searchFilter.getDateRange()) &&
                CollectionUtils.isEmpty(searchFilter.getAssignees()) &&
                CollectionUtils.isEmpty(searchFilter.getStatuses());

        if (!isEmpty) return;

        criteria.and(APPROVAL_STATUS).in(
                ApprovalStatus.PENDING_APPROVAL.toString(),
                ApprovalStatus.SAVE_PENDING_APPROVAL.toString(),
                ApprovalStatus.IN_PROGRESS.toString()
        );

        Instant endDate = Instant.now();
        Instant startDate = LocalDateTime.ofInstant(endDate, ZoneOffset.UTC)
                .minusMonths(3)
                .toInstant(ZoneOffset.UTC);

        criteria.and(LAST_MODIFIED_DATE)
                .gte(Date.from(startDate))
                .lte(Date.from(endDate));
    }


    public static Aggregation aggregateWithMatch(MatchOperation matchOperation, FacetOperation facetOperation, ProjectionOperation projectionOperation) {
        AggregationOptions options = AggregationOptions.builder().allowDiskUse(true).build();
        return newAggregation(
                matchOperation, facetOperation, projectionOperation).withOptions(options);
    }

    public static Query searchQuery(SearchDTO searchDTO) {
        Query query = new Query();
        if (searchDTO.getHon() != null) {
            query.addCriteria(Criteria.where(HON).is(searchDTO.getHon()));
        }
        if (!ObjectUtils.isEmpty(searchDTO.getSearchText())) {
            Criteria regex = Criteria.where(SEARCH_ORG)
                    .regex(PIPE + searchDTO.getSearchText());
            query.addCriteria(regex);
        }
        if (searchDTO.getOrganizationType() != null) {
            query.addCriteria(Criteria.where(ORGANIZATION_TYPE).is(searchDTO.getOrganizationType().getType()));
        }
        if (null == searchDTO.getSourceOrganizationStatus()) {
            query.addCriteria(Criteria.where(STATUS).is(SourceOrganizationStatus.ACTIVE));
        } else {
            query.addCriteria(Criteria.where(STATUS).is(searchDTO.getSourceOrganizationStatus().getStatus()));
        }
        if (searchDTO.getCountry() != null) {
            query.addCriteria(Criteria.where(COUNTRY).is(searchDTO.getCountry()));
        }
        if (searchDTO.getState() != null) {
            query.addCriteria(Criteria.where(STATE).is(searchDTO.getState()));
        }
        if (searchDTO.getCity() != null) {
            query.addCriteria(Criteria.where(CITY).is(searchDTO.getCity()));
        }
        return query;
    }

    public static int getTotalPages(int totalItem, int pageSize) {
        return (totalItem % pageSize) == 0 ? (totalItem / pageSize) : (totalItem / pageSize) + 1;
    }

    public static SkipOperation skipOperation(int startPage, int pageSize) {
        //db index starts from 0 ,so subtracting 1 from start page
        return skip((long) (startPage - 1) * pageSize);
    }

    public static LimitOperation limitOperation(int pageSize) {
        return limit(pageSize);
    }

    public static CountOperation countOperation() {
        return count().as(COUNT);
    }

    public static FacetOperation facetOperation(int startPage, int pageSize) {
        return facet().and(countOperation()).as(TOTAL)
                .and(skipOperation(startPage, pageSize), limitOperation(pageSize)).as(DATA);
    }

    public static ProjectionOperation finalProjectionWithTotalCountInPipeline() {
        return project()
                .and(ArrayOperators.ArrayElemAt.arrayOf(TOTAL_COUNT).elementAt(0)).as(TOTAL)
                .and(DATA).as(ORGANIZATION_LIST);
    }

    public static ProjectionOperation autoCompleteHitsProjection() {
        return project(HON, ORGANIZATION_NAME, ORGANIZATION_ALIAS,
                ORGANIZATION_TYPE, STATUS, CITY, STATE, COUNTRY, OUT_OF_BUSINESS, REVIEW_REQUIRED)
                .and(ArrayOperators.ArrayElemAt.arrayOf(REFERENCE_DOLLAR_OPERATOR + PAYLOAD_ADDRESS_LINE)
                        .elementAt(0)).as(SEARCH_PAYLOAD_ADDRESS_LINE)
                .andExpression(PAYLOAD_LAST_CLEAN_UP_DATE).as(SEARCH_PAYLOAD_LAST_CLEAN_UP_DATE)
                .andExpression(PAYLOAD_USED_COUNT).as(SEARCH_PAYLOAD_USED_COUNT)
                .andExpression(PAYLOAD_DEPARTMENT_NAME).as(SEARCH_PAYLOAD_DEPARTMENT_NAME)
                .andExpression(PAYLOAD_DEPARTMENT_ALIASES).as(SEARCH_PAYLOAD_DEPARTMENT_ALIASES);
    }

    public static ProjectionOperation possibleDuplicateProjection() {
        return project(HON, ORGANIZATION_NAME, COUNTRY, STATE, CITY,
                ORGANIZATION_TYPE, STATUS, APPROVAL_STATUS, ACTION, IS_LOCK_ENABLED);
    }

    public static ProjectionOperation smartSearchProjection() {
        return project(HON, ORGANIZATION_NAME, CITY,COUNTRY, STATE, POSTAL_CODE,LAST_MODIFIED_DATE, SEARCH_LAST_APPROVED_DATE).andExclude(ID)
                .andExpression(PAYLOAD_USED_COUNT).as(SEARCH_PAYLOAD_USED_COUNT)
                .andExpression(PAYLOAD_LAST_USED_DATETIME).as(SEARCH_PAYLOAD_LAST_USED_DATE_TIME)
                .andExpression(PAYLOAD_DEPARTMENT_NAME).as(SEARCH_PAYLOAD_DEPARTMENT_NAME);
    }

    public static ProjectionOperation sourceByFiltersProjection() {

        return project(HON, ORGANIZATION_NAME, VERSION, REQUESTED_BY, REQUESTER_ID, APPROVAL_STATUS,STATUS, TEMP_VERSION,
                FLAG_PRIORITY,ASSIGNED_TO, ASSIGNED_ID, ORGANIZATION_TYPE, COUNTRY, CREATED_BY,LAST_MODIFIED_BY, ACTION,LAST_MODIFIED_DATE);
    }

    public static Direction getSortOrderDirection(String order) {
        if (order.equalsIgnoreCase(SortOrder.ASC.getType())) {
            return Direction.ASC;
        } else {
            return Direction.DESC;
        }
    }

    public static String getSortPropertyMapped(String sort) {
        String sortOnField;
        switch (sort) {
            case ORGANIZATION_NAME,SortFields.ORGANIZATION_NAME -> sortOnField = ORGANIZATION_NAME;
            case VALIDATED,SortFields.TOTAL_COUNT -> sortOnField = SEARCH_PAYLOAD_USED_COUNT;
            case LAST_ACTIVE, LAST_MODIFIED_DATE,SortFields.LAST_MODIFIED_DATE -> sortOnField = LAST_MODIFIED_DATE;
            case SortFields.SORT_LAST_MODIFIED_BY -> sortOnField = SORTLASTMODIFIEDBY;
            case SortFields.SORTASSIGNEDTO -> sortOnField = SORTASSIGNEDTO;
            case LAST_APPROVED_DATE,SortFields.LAST_APPROVED_DATE -> sortOnField = SEARCH_LAST_APPROVED_DATE;
            case LOCATION -> sortOnField = SEARCH_PAYLOAD_ADDRESS_LINE;
            case PRIMARY_CONTACT -> sortOnField = SEARCH_PAYLOAD_PRIMARY_CONTACT;
            case ORGANIZATION_TYPE -> sortOnField = ORGANIZATION_TYPE;
            case CITY,SortFields.CITY -> sortOnField = CITY;
            case STATE,SortFields.REGION -> sortOnField = STATE;
            case POSTAL_CODE,SortFields.POSTAL_CODE -> sortOnField = POSTAL_CODE;
            case COUNTRY,SortFields.COUNTRY -> sortOnField = COUNTRY;
            case DEPARTMENT_NAME,SortFields.DEPARTMENT_NAME -> sortOnField = PAYLOAD_DEPARTMENT_NAME;
            case STATUS -> sortOnField = STATUS;
            case LAST_USED,SortFields.LAST_USED_DATE -> sortOnField = PAYLOAD_LAST_USED_DATETIME;
            case FLAG_PRIORITY -> sortOnField = FLAG_PRIORITY;
            case SortFields.LASTMODIFIEDBY,SortFields.LAST_MODIFIED_BY  -> sortOnField = SortFields.LASTMODIFIEDBY;
            case SortFields.ASSIGNED_TO -> sortOnField = SortFields.ASSIGNEDTO;
            case SortFields.APPROVAL_STATUS -> sortOnField = SortFields.APPROVALSTATUS;
            case CREATED_BY, SortFields.CREATED_BY -> sortOnField = CREATED_BY;
            case LOG_FLAG -> sortOnField = LOG_FLAG;
            case SEARCH_ORG -> sortOnField = SEARCH_ORG;
            default -> sortOnField = LAST_MODIFIED_DATE;
        }
        return sortOnField;
    }

    public static SortOperation buildSortOperation(String sort, String order) {
        SortOperation sortOperation;
        if (!StringUtils.isEmpty(sort) && !StringUtils.isEmpty(order)) {
            String sortOnField = QueryBuilder.getSortPropertyMapped(sort);
            if (sortOnField == null) {
                logAndThrowInvalidRequest(INVALID_SORT, null, sort);
            }
            if(sort.equals(FLAG_PRIORITY)){
                sortOperation = new SortOperation(
                        Sort.by(QueryBuilder.getSortOrderDirection(order), sortOnField))
                        .and(Sort.by(QueryBuilder.getSortOrderDirection(order), LAST_MODIFIED_DATE));
            }else{
                sortOperation = new SortOperation(
                        Sort.by(QueryBuilder.getSortOrderDirection(order), sortOnField));
            }

        } else {
            sortOperation = new SortOperation(Sort.by(Direction.DESC, LAST_MODIFIED_DATE));
        }
        return sortOperation;
    }

    public static ProjectionOperation changeLogProjection() {
        return project(HON, ORGANIZATION_NAME, LAST_MODIFIED_DATE,
                REQUESTED_BY, REQUESTER_ID, ASSIGNED_TO, ASSIGNED_ID,
                APPROVAL_STATUS, VERSION, CREATED_DATE, CREATED_BY,
                LOG_FLAG, ORGANIZATION_TYPE, LAST_MODIFIED_BY, SEARCH_ORG);
    }

    public static Criteria changeLogDateMatchDocument(DateRange dateRange) {
        Criteria criteria = new Criteria();
        criteria.and(LAST_MODIFIED_DATE).gte(Date.from(dateRange.getStartDate()))
                .lte(Date.from(dateRange.getEndDate()));
        return criteria;

    }

    public static List<Criteria> queryCriteriaForNonArrayFields(SourceOrganizationDTO sourceOrganizationDTO) {

        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(Criteria.where(SEARCH_ORG).is(sourceOrganizationDTO.getOrganizationName().toLowerCase()));

        criteriaList.add(Criteria.where(COUNTRY).is(sourceOrganizationDTO.getCountry() != null ? sourceOrganizationDTO.getCountry() : EMPTY_STRING));
        if (sourceOrganizationDTO.getState() != null) {
            criteriaList.add(Criteria.where(STATE).is(sourceOrganizationDTO.getState()));
        } else {
            criteriaList.add(Criteria.where(EMPTY_STRING).orOperator(Criteria.where(STATE).is(EMPTY_STRING), Criteria.where(STATE).exists(false)));
        }
        if (sourceOrganizationDTO.getCity() != null) {
            criteriaList.add(Criteria.where(CITY).is(sourceOrganizationDTO.getCity()));
        } else {
            criteriaList.add(Criteria.where(EMPTY_STRING).orOperator(Criteria.where(CITY).is(EMPTY_STRING), Criteria.where(CITY).exists(false)));
        }

        if (sourceOrganizationDTO.getPostalCode() != null) {
            criteriaList.add(Criteria.where(POSTAL_CODE).is(sourceOrganizationDTO.getPostalCode()));
        } else {
            criteriaList.add(Criteria.where(EMPTY_STRING).orOperator(Criteria.where(POSTAL_CODE).is(EMPTY_STRING), Criteria.where(POSTAL_CODE).exists(false)));
        }
        if (sourceOrganizationDTO.getPayload()
                .has(DEPARTMENT_NAME) && !ObjectUtils.isEmpty(sourceOrganizationDTO.getPayload().get(DEPARTMENT_NAME))) {
            String departmentName = (String) sourceOrganizationDTO.getPayload().get(DEPARTMENT_NAME);
            criteriaList.add(Criteria.where(PAYLOAD_DEPARTMENT_NAME).is(departmentName));
        } else {
            criteriaList.add(Criteria.where(EMPTY_STRING).orOperator(Criteria.where(PAYLOAD_DEPARTMENT_NAME).is(EMPTY_STRING), Criteria.where(PAYLOAD_DEPARTMENT_NAME).exists(false)));
        }
        JSONArray addressArray = sourceOrganizationDTO.getPayload().has(ADDRESS) ? (JSONArray) sourceOrganizationDTO.getPayload().get(ADDRESS) : new JSONArray();
        JSONObject addressObj = !addressArray.isEmpty() ? (JSONObject) addressArray.get(0) : new JSONObject();

        if (addressObj.has(ADDRESS_LINE) && !ObjectUtils.isEmpty(addressObj.get(ADDRESS_LINE))) {
            String address = (String) addressObj.get(ADDRESS_LINE);
            criteriaList.add(Criteria.where(PAYLOAD_ADDRESS_LINE).is(address));
        } else {
            criteriaList.add(Criteria.where(EMPTY_STRING).orOperator(Criteria.where(PAYLOAD_ADDRESS_LINE).is(EMPTY_STRING), Criteria.where(PAYLOAD_ADDRESS_LINE).exists(false)));
        }

        criteriaList.add(Criteria.where(APPROVAL_STATUS).ne(ApprovalStatus.REJECTED.toString()));
        return criteriaList;
    }

    public static void queryCriteriaForArrayFields(SourceOrganizationDTO sourceOrganizationDTO, List<Criteria> criteriaList) {
        List<Pattern> regexOrgAliasList = new ArrayList<>();
        List<String> aliasNames = new ArrayList<>();
        if (sourceOrganizationDTO.getOrganizationAlias() != null && sourceOrganizationDTO.getOrganizationAlias().length > 0) {
            aliasNames = Arrays.stream(sourceOrganizationDTO.getOrganizationAlias())
                    .map(Alias::getName).filter(alias -> alias != null && !alias.isBlank()).toList();
        }
        for (String name : aliasNames) {
            regexOrgAliasList.add(Pattern.compile(Pattern.quote(name), Pattern.CASE_INSENSITIVE));
        }

        if (aliasNames.isEmpty()) {
            criteriaList.add(Criteria.where(EMPTY_STRING).orOperator(Criteria.where(ORGANIZATION_ALIAS_NAME).in(List.of(EMPTY_STRING)), Criteria.where(ORGANIZATION_ALIAS).is(List.of()), Criteria.where(ORGANIZATION_ALIAS).exists(false)));
        } else {
            criteriaList.add(Criteria.where(ORGANIZATION_ALIAS_NAME).in(regexOrgAliasList));
        }
    }

    public static Criteria buildCriteriaForSmartSearchSuggestions(Map<String, String> searchFilter) {
        Criteria criteria = new Criteria();
        if(searchFilter.get(COUNTRY) != null){
            criteria.and(COUNTRY).is(searchFilter.get(COUNTRY));
        }
        if(searchFilter.get(STATE) != null){
            criteria.and(STATE).is(searchFilter.get(STATE));
        }
        if(searchFilter.get(CITY) != null){
            criteria.and(CITY).regex(searchFilter.get(CITY),"i");
        }
        if(searchFilter.get(POSTAL_CODE) != null){
            criteria.and(POSTAL_CODE).is(searchFilter.get(POSTAL_CODE));
        }
        if(searchFilter.get(PAYLOAD_WEBSITE) != null){
            criteria.and(PAYLOAD_WEBSITE).is(searchFilter.get(PAYLOAD_WEBSITE));
        }
        criteria.and(APPROVAL_STATUS).is(ApprovalStatus.APPROVED.getStatus());
        if(searchFilter.get(STATUS) != null){
            criteria.and(STATUS).is(searchFilter.get(STATUS));
        }
        return criteria;
    }

    public static Criteria smartSearchCriteria(Set<String> honIds, Map<String,String> smartSearchFields){
        Criteria criteria = new Criteria();
        criteria.and(HON).in(honIds);
        if(smartSearchFields.get(STATUS) != null){
            criteria.and(STATUS).is(smartSearchFields.get(STATUS));
        }
        if(smartSearchFields.get(APPROVAL_STATUS) != null) {
            criteria.and(APPROVAL_STATUS).is(smartSearchFields.get(APPROVAL_STATUS));
        }
        if(smartSearchFields.get(PAYLOAD_CONTACTS_ONLINE_PROVIDER) != null && smartSearchFields.get(PAYLOAD_CONTACTS_COMMUNICATION_VALUE) != null){
            buildCriteriaForOnlineProviderForSmartSearch(smartSearchFields.get(PAYLOAD_CONTACTS_ONLINE_PROVIDER), smartSearchFields.get(PAYLOAD_CONTACTS_COMMUNICATION_VALUE), criteria);
        }
        return criteria;
    }

    public static void buildCriteriaForOnlineProviderForSmartSearch(String provider, String code, Criteria criteria) {
        Criteria innerCommInfo = Criteria.where(CONTACTS_TYPE).is(CODES);
        if (code != null && !code.isEmpty()) {
            innerCommInfo = innerCommInfo.and(VALUE).regex(code);
        }
        Criteria communicationCriteria = Criteria.where(NAME).is(provider)
                .and(COMMUNICATION_INFO).elemMatch(innerCommInfo);

        Criteria contactDetailCriteria = Criteria.where(CONTACTS_TYPE).is(CONTACT_AUTOMATED_SERVICES)
                .and(COMMUNICATION).elemMatch(communicationCriteria);
        criteria.and(PAYLOAD_CONTACT_DETAILS).elemMatch(contactDetailCriteria);

    }

    public static Criteria dropdownCriteria(String keyword) {
        Criteria criteria = new Criteria();
        if (!StringUtils.isEmpty(keyword)) {
            criteria.and(SEARCH_ORG).regex(PIPE+keyword.trim().toLowerCase());
        }
        return criteria;
    }

    public static Aggregation buildQueryForDropdown(String keyword) {
        Aggregation aggregation;
        Criteria criteria = dropdownCriteria(keyword);
        MatchOperation matchOperation = buildMatch(criteria);
        GroupOperation group = Aggregation.group().addToSet(ORGANIZATION_NAME).as(ORG_NAMES);
        AggregationOptions options = AggregationOptions.builder().allowDiskUse(true).build();
        aggregation = Aggregation.newAggregation(
                matchOperation, group).withOptions(options);
        return aggregation;
    }

    public static AddFieldsOperation addLastModifiedBy(){

        Document lastModifiedByUpdate = new Document("$cond", new Document("if",
                new Document("$not", Arrays.asList("$lastModifiedBy")
                ))
                .append("then", "$createdBy")
                .append("else", "$lastModifiedBy")
        );

        Document sortLastModifiedByUpdate = new Document("$toLower", lastModifiedByUpdate);
        Document sortAssignedToByUpdate = new Document("$toLower", "$assignedTo");

        return AddFieldsOperation.builder()
                .addField(LAST_MODIFIED_BY)
                .withValue(lastModifiedByUpdate)
                .addField(SORTLASTMODIFIEDBY).withValue(sortLastModifiedByUpdate)
                .addField(SORTASSIGNEDTO).withValue(sortAssignedToByUpdate)
                .build();

    }

}