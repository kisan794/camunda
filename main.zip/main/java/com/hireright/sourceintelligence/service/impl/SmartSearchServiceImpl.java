package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.*;
import com.hireright.sourceintelligence.constants.ErrorConstants;
import com.hireright.sourceintelligence.domain.entity.FieldValueInfo;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceDTOMapper;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.SmartSearchService;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.util.Helper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.SOURCE_COLLECTION_SUFFIX;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.ContactTypes.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.PayloadFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchScore.SEARCH_LIMIT;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchScore.SMART_SEARCH_LIMIT;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SortFields.TOTAL_COUNT;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInternalServiceException;
import static java.util.Comparator.nullsLast;
import static java.util.Comparator.reverseOrder;

@Slf4j
@AllArgsConstructor
@Service
public class SmartSearchServiceImpl implements SmartSearchService {

    private final ElasticsearchService elasticsearchService;
    private final DistanceAlgorithm distanceAlgorithm;
    private ElasticsearchService searchIndexService;
    private final SourceDTOMapper sourceDTOMapper;
    private final MongoSearchService mongoSearchService;

    @Override
    public SearchResponseDTO getSourceListBySearch(SmartSearchDTO smartSearchDTO) {
        log.info("Smart Search Service request: {}", smartSearchDTO);
        try{
        List<SourceDTO> finalList = new ArrayList<>();
        int totalRecords = 0;
        if (StringUtils.isEmpty(smartSearchDTO.getOrder()) && StringUtils.isEmpty(smartSearchDTO.getSort())) {
            smartSearchDTO.setOrder("desc");
            smartSearchDTO.setSort(TOTAL_COUNT);
        }
        ElasticsearchDTO elasticsearchDTO = new ElasticsearchDTO();
        Map<String, String> smartSearchFieldMapping = new LinkedHashMap<>();
        smartSearchFieldMapping(smartSearchDTO, elasticsearchDTO, smartSearchFieldMapping);
        String collectionName = Helper.getCollectionName(smartSearchDTO.getOrganizationType(), SOURCE_COLLECTION_SUFFIX);
        if (!elasticsearchDTO.isEmpty()) {
            log.info("Index search:startTime: {}", Instant.now());
            //filter - hon
            Set<String> honIds = searchIndexService.smartSearch(elasticsearchDTO, Helper.getIndexName(smartSearchDTO.getOrganizationType()), smartSearchDTO.getIsDropDownSelected());
            log.info("Index search:endTime: {}, size: {}", Instant.now(), honIds.size());
            if (honIds != null && !honIds.isEmpty()) {
                log.info("Mongo search Starts:$in {}", Instant.now());
                finalList = mongoSearchService.getSmartSearchResponseByHonIds(smartSearchFieldMapping, collectionName, honIds);
                log.info("Mongo search ends :$in {},{}", finalList.size(), Instant.now());
                totalRecords = finalList.size();
            }
        } else {
            log.info("smart search without ES starts: {}", Instant.now());
            Criteria criteria = QueryBuilder.buildCriteriaForSmartSearchSuggestions(smartSearchFieldMapping);
            List<Source> searchResult = mongoSearchService.smartSearchExecution(criteria, smartSearchDTO);
            log.info("smart search without ES mongo response ends: {}, size:{}", Instant.now(), searchResult.size());
            if (searchResult != null && !ObjectUtils.isEmpty(searchResult.isEmpty())) {
                log.info("search results format starts: {}", Instant.now());
                List<SourceDTO> outputList;
                if(searchResult.size() > 10){
                    log.info("mongo parallel search results format starts: {}", Instant.now());
                    outputList = Collections.synchronizedList(new ArrayList<>());
                    searchResult.parallelStream().forEach(source -> {
                        outputList.add(sourceDTOMapper.toSourceDTO(source));
                    });
                    log.info("mongo parallel search results format ends: {}", Instant.now());
                }else{
                    outputList = sourceDTOMapper.entityToSourceList(searchResult);
                }
                finalList = outputList.stream().sorted(Comparator
                                .comparing(SourceDTO::getUsedCount, nullsLast(reverseOrder())))
                        .collect(Collectors.toCollection(LinkedList::new));
                totalRecords = finalList.size();
                log.info("search results format ends: {}", Instant.now());
            }
            log.info("smart search without ES ends: {}", Instant.now());
        }
        log.info("smart search ends: {}", Instant.now());
        var resp = SearchResponseDTO.builder().searchList(finalList)
                .status("SUCCESS")
                .currentPage(smartSearchDTO.getStartPage())
                .totalItems(totalRecords)
                .totalPages(QueryBuilder.getTotalPages(totalRecords, SMART_SEARCH_LIMIT))
                .build();
        log.info("Smart Search Service response: {}", resp);
        return resp;
        }catch (Exception e){
            logAndThrowInternalServiceException(ErrorConstants.INTERNAL_SERVER_ERROR, e);
        }
        return null;
    }


    @Override
    public List<AutocompleteSearchDTO> getDropDownList(String keyword, OrganizationType orgType, Boolean isRAM, Map<String, String> searchFilters) {
        log.info("drop down list starts: {}", Instant.now());
        ElasticsearchDTO elasticsearchDTO = new ElasticsearchDTO();
        elasticsearchDTO.setOrganizationName(keyword);
        String indexName = Helper.getIndexName(orgType.getType());
        log.info("Dropdown es starts: {}", Instant.now());
        List<ElasticsearchSource> esResult = elasticsearchService.dropDownSearch(elasticsearchDTO, indexName);
        log.info("Dropdown es size:{}", esResult.size());
        log.info("Dropdown es ends: {}", Instant.now());
        if (esResult.isEmpty()) {
            return Collections.emptyList();
        }
        Set<String> finalOrgs = distanceAlgorithm.jaroWinklerAlgorithmForDropDown(keyword.toLowerCase(), esResult);
        AutocompleteSearchDTO autocompleteSearchDTO = new AutocompleteSearchDTO();
        autocompleteSearchDTO.setCategory(ORGANIZATION_NAME);
        List<FieldValueInfo> fvList = new ArrayList<>();
        for (String source : finalOrgs) {
            FieldValueInfo fv = new FieldValueInfo();
            fv.setValue(source);
            fvList.add(fv);
        }
        autocompleteSearchDTO.setMatches(fvList);
        log.info("drop down list ends: {}", Instant.now());
        return List.of(autocompleteSearchDTO);
    }

    @Override
    public List<AutocompleteSearchDTO> getDropDownListForRAM(String keyword, OrganizationType organizationType, Boolean isRAM, Map<String, String> searchFilters) {
        List<AutocompleteSearchDTO> dropdownList = new ArrayList<>();
        try{
            List<FieldValueInfo> list = new ArrayList<>();
            List<String> uniqueOrgList = mongoSearchService.getDropDownListForRAM(keyword, organizationType);
            if(uniqueOrgList != null && !uniqueOrgList.isEmpty()){
                Set<String> sortedList = distanceAlgorithm.jaroWinklerAlgorithmForDropDownRAM(keyword, uniqueOrgList);
                if(sortedList != null && !sortedList.isEmpty()){
                    for(String source : sortedList){
                        FieldValueInfo fieldValueInfo = new FieldValueInfo();
                        fieldValueInfo.setValue(source);
                        list.add(fieldValueInfo);
                        if(list.size() == SEARCH_LIMIT){
                            break;
                        }
                    }
                }
            }
            AutocompleteSearchDTO searchDTO = new AutocompleteSearchDTO();
            searchDTO.setMatches(list);
            searchDTO.setCategory(ORGANIZATION_NAME);
            dropdownList.add(searchDTO);
        }catch (Exception e){
            AutocompleteSearchDTO searchDTO = new AutocompleteSearchDTO();
            searchDTO.setCategory(ORGANIZATION_NAME);
            dropdownList.add(searchDTO);
            return dropdownList;
        }
        return dropdownList;
    }

    private void smartSearchFieldMapping(SmartSearchDTO smartSearchDTO, ElasticsearchDTO elasticsearchDTO, Map<String, String> smartSearchFieldMapping) {
        if (smartSearchDTO.getStartPage() == 0) {
            smartSearchDTO.setStartPage(1);
        }
        smartSearchSourceMapping(smartSearchDTO, elasticsearchDTO, smartSearchFieldMapping);
        smartSearchAddressMapping(smartSearchDTO, elasticsearchDTO, smartSearchFieldMapping);
        smartSearchContactsMapping(smartSearchDTO, elasticsearchDTO, smartSearchFieldMapping);

        if (Boolean.TRUE.equals(smartSearchDTO.getIsArchive())) {
            smartSearchFieldMapping.put(APPROVAL_STATUS, ApprovalStatus.APPROVED.getStatus());
            if (!elasticsearchDTO.isEmpty()) {
                elasticsearchDTO.setApprovalStatus(ApprovalStatus.APPROVED.getStatus());
            }
        } else {
            smartSearchFieldMapping.put(STATUS, SourceOrganizationStatus.ACTIVE.getStatus());
            smartSearchFieldMapping.put(APPROVAL_STATUS, ApprovalStatus.APPROVED.getStatus());
            if (!elasticsearchDTO.isEmpty()) {
                elasticsearchDTO.setStatus(SourceOrganizationStatus.ACTIVE.getStatus());
            }
        }
    }

    private void smartSearchAddressMapping(SmartSearchDTO smartSearchDTO, ElasticsearchDTO elasticsearchDTO, Map<String, String> smartSearchFieldMapping) {
        if (!StringUtils.isEmpty(smartSearchDTO.getAddress())) {
            elasticsearchDTO.setAddressLine(smartSearchDTO.getAddress());
            smartSearchFieldMapping.put(PAYLOAD_ADDRESS, smartSearchDTO.getAddress());
        }
        if (!StringUtils.isEmpty(smartSearchDTO.getCountry())) {
            smartSearchFieldMapping.put(COUNTRY, smartSearchDTO.getCountry());
            if (!elasticsearchDTO.isEmpty()) {
                elasticsearchDTO.setCountry(smartSearchDTO.getCountry());
            }
        }
        if (!StringUtils.isEmpty(smartSearchDTO.getState())) {
            if (!elasticsearchDTO.isEmpty()) {
                elasticsearchDTO.setState(smartSearchDTO.getState());
            }
            smartSearchFieldMapping.put(STATE, smartSearchDTO.getState());
        }
        if (!StringUtils.isEmpty(smartSearchDTO.getCity())) {
            smartSearchFieldMapping.put(CITY, smartSearchDTO.getCity());
            if (!elasticsearchDTO.isEmpty()) {
                elasticsearchDTO.setCity(smartSearchDTO.getCity().toLowerCase());
            }
        }
        if (!StringUtils.isEmpty(smartSearchDTO.getPostalCode())) {
            smartSearchFieldMapping.put(POSTAL_CODE, smartSearchDTO.getPostalCode());
            if (!elasticsearchDTO.isEmpty()) {
                elasticsearchDTO.setPostalCode(smartSearchDTO.getPostalCode().toLowerCase());
            }
        }
    }

    private void smartSearchContactsMapping(SmartSearchDTO smartSearchDTO, ElasticsearchDTO elasticsearchDTO, Map<String, String> smartSearchFieldMapping) {
        if (!StringUtils.isEmpty(smartSearchDTO.getEmail())) {
            elasticsearchDTO.setEmail(smartSearchDTO.getEmail().trim().toLowerCase());
        }
        if (!StringUtils.isEmpty(smartSearchDTO.getOnlineProvider())) {
            elasticsearchDTO.setAutomatedService(smartSearchDTO.getOnlineProvider());
            if (!StringUtils.isEmpty(smartSearchDTO.getCode())) {
                elasticsearchDTO.setCode(smartSearchDTO.getCode().toLowerCase());
                smartSearchFieldMapping.put(PAYLOAD_CONTACTS_COMMUNICATION_VALUE, smartSearchDTO.getCode());
                smartSearchFieldMapping.put(PAYLOAD_CONTACTS_COMMUNICATION_TYPE, AUTOMATED_CODES);
            }
            smartSearchFieldMapping.put(PAYLOAD_CONTACTS_TYPE, AUTOMATED_ONLINE_PROVIDER);
            smartSearchFieldMapping.put(PAYLOAD_CONTACTS_ONLINE_PROVIDER, smartSearchDTO.getOnlineProvider());
        }
        smartSearchPhoneMapping(smartSearchDTO, elasticsearchDTO);
        smartSearchFaxMapping(smartSearchDTO, elasticsearchDTO);
    }

    private void smartSearchPhoneMapping(SmartSearchDTO smartSearchDTO, ElasticsearchDTO elasticsearchDTO) {
        if (!StringUtils.isEmpty(smartSearchDTO.getPhoneNumber())) {
            StringBuilder phoneNumber = new StringBuilder();
            if (!StringUtils.isEmpty(smartSearchDTO.getPhoneCountryCode())) {
                if (smartSearchDTO.getPhoneCountryCode().contains("+")) {
                    phoneNumber.append(smartSearchDTO.getPhoneCountryCode());
                } else {
                    phoneNumber.append("+").append(smartSearchDTO.getPhoneCountryCode());
                }
            }
            if (!StringUtils.isEmpty(smartSearchDTO.getPhoneAreaCode())) {
                phoneNumber.append(smartSearchDTO.getPhoneAreaCode());
            }
            phoneNumber.append(smartSearchDTO.getPhoneNumber());
            if (!StringUtils.isEmpty(smartSearchDTO.getPhoneExtension())) {
                phoneNumber.append(":").append(smartSearchDTO.getPhoneExtension());
            }
            elasticsearchDTO.setPhoneNumber(phoneNumber.toString());
        }
    }

    private void smartSearchFaxMapping(SmartSearchDTO smartSearchDTO, ElasticsearchDTO elasticsearchDTO) {
        if (!StringUtils.isEmpty(smartSearchDTO.getFaxNumber())) {
            StringBuilder faxNumber = new StringBuilder();
            if (!StringUtils.isEmpty(smartSearchDTO.getFaxCountryCode())) {
                if (smartSearchDTO.getFaxCountryCode().contains("+")) {
                    faxNumber.append(smartSearchDTO.getFaxCountryCode());
                } else {
                    faxNumber.append("+").append(smartSearchDTO.getFaxCountryCode());
                }
            }
            if (!StringUtils.isEmpty(smartSearchDTO.getFaxAreaCode())) {
                faxNumber.append(smartSearchDTO.getFaxAreaCode());
            }
            faxNumber.append(smartSearchDTO.getFaxNumber());
            elasticsearchDTO.setFaxNumber(smartSearchDTO.getFaxNumber());
            if (!StringUtils.isEmpty(smartSearchDTO.getFaxExtension())) {
                faxNumber.append(":").append(smartSearchDTO.getFaxExtension());
            }
            elasticsearchDTO.setFaxNumber(faxNumber.toString());
        }
    }

    private void smartSearchSourceMapping(SmartSearchDTO smartSearchDTO, ElasticsearchDTO elasticsearchDTO, Map<String, String> smartSearchFieldMapping) {
        if (!StringUtils.isEmpty(smartSearchDTO.getName())) {
            elasticsearchDTO.setOrganizationName(smartSearchDTO.getName());
            elasticsearchDTO.setOrganizationAlias(smartSearchDTO.getName());
            smartSearchFieldMapping.put(SEARCH_ORG, smartSearchDTO.getName().toLowerCase());
            smartSearchFieldMapping.put(ORGANIZATION_ALIAS, smartSearchDTO.getName());
        }
        if (!StringUtils.isEmpty(smartSearchDTO.getDepartment())) {
            elasticsearchDTO.setDepartment(smartSearchDTO.getDepartment());
            smartSearchFieldMapping.put(PAYLOAD_DEPARTMENT_NAME, smartSearchDTO.getDepartment());
        }
        if (!StringUtils.isEmpty(smartSearchDTO.getWebAddress())) {
            if(!elasticsearchDTO.isEmpty()){
                elasticsearchDTO.setWebsite(smartSearchDTO.getWebAddress().toLowerCase().trim());
            }
            smartSearchFieldMapping.put(PAYLOAD_WEBSITE, smartSearchDTO.getWebAddress().toLowerCase().trim());
        }
    }
}
