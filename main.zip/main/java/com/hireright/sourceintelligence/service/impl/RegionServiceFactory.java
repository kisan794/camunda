package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.service.AutoMatchRegionService;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;


@Component
public class RegionServiceFactory {

    private final ObjectProvider<USRegionAutoMatchServiceImpl> usRegionServiceProvider;
    private final ObjectProvider<NonUSRegionAutoMatchServiceImpl> nonUsRegionServiceProvider;

    public RegionServiceFactory(ObjectProvider<USRegionAutoMatchServiceImpl> usRegionServiceProvider,
                                ObjectProvider<NonUSRegionAutoMatchServiceImpl> nonUsRegionServiceProvider) {
        this.usRegionServiceProvider = usRegionServiceProvider;
        this.nonUsRegionServiceProvider = nonUsRegionServiceProvider;
    }

    public AutoMatchRegionService getService(String region) {
        return switch (region.toLowerCase()) {
            case "us", "latam", "canada" -> usRegionServiceProvider.getIfAvailable();
            default -> nonUsRegionServiceProvider.getIfAvailable();
        };
    }
}