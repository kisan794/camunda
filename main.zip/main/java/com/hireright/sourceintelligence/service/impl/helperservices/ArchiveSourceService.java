package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.api.dto.UIActionsDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.service.impl.*;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.util.Helper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.validation.constraints.NotNull;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.LOG_FLAG;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowResourceNotFound;

@Primary
@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
public class ArchiveSourceService {

    private final MongoSourceService mongoSourceService;
    private final ReportDataUtils reportDataUtils;
    private final ElasticsearchService elasticsearchService;

    public boolean archiveSource(@NotNull String hon, UIActionsDTO uiActionsDTO) throws Exception {
        var entityFromDb = mongoSourceService.findSourceByHonAndApprovalStatus(hon,APPROVED);
        if (entityFromDb == null) {
            logAndThrowResourceNotFound(SOURCE_NOT_FOUND, null, hon);
        }
        assert entityFromDb != null;
        List<String> approvalStatus = new ArrayList<>();
        approvalStatus.add(ONHOLD.toString());
        approvalStatus.add(SAVE_PENDING_APPROVAL.toString());
        approvalStatus.add(PENDING_APPROVAL.toString());
        approvalStatus.add(IN_PROGRESS.toString());
        approvalStatus.add(REJECTED.toString());
        String collectionName = Helper.getCollectionName(entityFromDb.getHon(), SOURCE_COLLECTION_SUFFIX);
        List<Source> sourceList = mongoSourceService.getSourceListByHonAndApprovalStatuses(hon, approvalStatus);
        if(sourceList != null && !sourceList.isEmpty()){
            for (Source source : sourceList) {
                mongoSourceService.delete(source,collectionName);
            }
        }
        Update update = new Update().set(STATUS, SourceOrganizationStatus.INACTIVE.getStatus())
                .set(APPROVAL_STATUS, APPROVED)
                .set(ACTION,DELETE)
                .set(LAST_ACTION_DATE,Instant.now())
                .set(LAST_MODIFIED_DATE, Instant.now())
                .set(LAST_MODIFIED_BY, uiActionsDTO.getUserName())
                .set(LOG_FLAG,SearchConstants.LogFlagConstants.ARCHIVED);
        Query query = new Query().addCriteria(Criteria.where(HON).is(hon));
        var updatedCount = mongoSourceService.updateByIdWithCustomFields(query, update, collectionName);

        entityFromDb.setApprovalStatus(APPROVED);
        entityFromDb.setStatus(SourceOrganizationStatus.INACTIVE);
        entityFromDb.setAction(DELETE);
        entityFromDb.setLastActionDate(Instant.now());
        entityFromDb.setLastModifiedDate(Instant.now());
        entityFromDb.setLastModifierId(uiActionsDTO.getUserEmail());
        entityFromDb.setLastModifiedBy(uiActionsDTO.getUserName());
        entityFromDb.setLogFlag(SearchConstants.LogFlagConstants.ARCHIVED);
        mongoSourceService.insertSourceHistory(entityFromDb);

        elasticsearchService.updateStatusForSourceIndex(entityFromDb, SourceOrganizationStatus.INACTIVE.getStatus(), ApprovalStatus.APPROVED.getStatus());

        /* Report Data Starts */
        reportDataUtils.reportData(entityFromDb, SearchConstants.ReportActions.ARCHIVED, SIDB_ORIGIN, 0, null);
        /* Report Data Ends */
        log.info("{} Archive - updated successfully for {}", updatedCount, entityFromDb.getHon());
        return updatedCount;
    }

}
