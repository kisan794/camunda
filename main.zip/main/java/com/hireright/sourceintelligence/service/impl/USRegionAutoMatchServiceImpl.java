package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.AutoMatchDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchResponseDTO;
import com.hireright.sourceintelligence.api.dto.optool.AutoMatchSourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.AutoMatchMapper;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.service.AutoMatchRegionService;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.service.impl.helperservices.ReportDataUtils;
import com.hireright.sourceintelligence.util.Helper;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOptions;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.*;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.JaroFields.ORG_ALIAS;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.JaroFields.ORG_NAME;

@Getter
@Primary
@Slf4j
@RequiredArgsConstructor
@Service
@Lazy
public class USRegionAutoMatchServiceImpl implements AutoMatchRegionService {


    private final ElasticsearchService elasticsearchService;
    private final CustomSourceRepository<Source> customSourceRepository;
    private final SourceMapper sourceMapper;
    private final AutoMatchMapper autoMatchMapper;
    private final DistanceAlgorithm distanceAlgorithm;
    private final ReportDataUtils reportDataUtils;

    @Override
    public AutoMatchResponseDTO autoMatch(AutoMatchDTO inputData) {
        log.info("[{}] Automatch service US request: {}", inputData.getRequestId(), inputData);
        Instant requestTime = Instant.now();
        try {
            String collectionName = Helper.getCollectionName(inputData.getSourceType(), SOURCE_COLLECTION_SUFFIX);
            String indexName = Helper.getIndexName(inputData.getSourceType());
            log.info("[{}] Elasticsearch starts:", inputData.getRequestId());
            List<ElasticsearchSource> searchList = elasticsearchService.autoMatchSearch(inputData, indexName);
            if (searchList == null || searchList.isEmpty()) {
                return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).error(NO_AUTO_MATCH_ES).build();
            }log.info("[{}] Elasticsearch ends:", inputData.getRequestId());
            log.info("[{}] Jaro Starts", inputData.getRequestId());
            Map<String, String> searchSources = distanceAlgorithm.jaroWinklerAlgorithm(inputData.getSourceName(), searchList);
            log.info("[{}] Jaro Ends", inputData.getRequestId());
            if (searchSources == null) {
                return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).error(NO_AUTO_MATCH_JARO).build();
            }
            Aggregation aggregation = generateQuery(searchSources, inputData);
            if(aggregation == null){
                return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).error(NO_AUTO_MATCH_JARO).build();
            }
            List<Source> searchResult = customSourceRepository.aggregate(aggregation, collectionName, Source.class);
            log.info("[{}] Aggregate Document Result Time: {}, mongo result size: {}", inputData.getRequestId(), LocalDateTime.now(), searchResult.size());
            if (searchResult.isEmpty()) {
                return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).error(NO_AUTO_MATCH_MS).build();
            }
            AutoMatchSourceDTO autoMatchSourceDTO = autoMatchMapper.toAutoMatchDTO(searchResult.getFirst());
            log.info("[{}] auto match source result: {}", inputData.getRequestId(), autoMatchSourceDTO.getHon());
            return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).source(autoMatchSourceDTO).build();
        }catch (Exception e){
            return AutoMatchResponseDTO.baseBuilder(inputData.getRequestId(), requestTime).serverError(INTERNAL_SERVER_ERROR).build();
        }
    }

    private Aggregation generateQuery(Map<String, String> searchSources,AutoMatchDTO inputData){
        Aggregation aggregation;
        AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder()
                .allowDiskUse(true).build();
        String collectionName = Helper.getCollectionName(inputData.getSourceType(), SOURCE_COLLECTION_SUFFIX);
        if(inputData.getSourceType().equals(OrganizationType.EDUCATION.getType())){
            inputData.setCity(Helper.convertToTitleCase(inputData.getCity()));
        }
        if (searchSources.containsKey(ORG_NAME) && searchSources.containsKey(ORG_ALIAS)) {
            String organizationName = searchSources.get(ORG_NAME);
            inputData.setSourceName(organizationName);
            aggregation = AutoMatchQueryBuilder.autoMatchUSRegion(inputData, collectionName);
            aggregation.withOptions(aggregationOptionsToAllowDiskUse);
        } else if (searchSources.containsKey(ORG_NAME)) {
            String organizationName = searchSources.get(ORG_NAME);
            inputData.setSourceName(organizationName);
            aggregation = AutoMatchQueryBuilder.autoMatchUSRegionForOrg(inputData);
            aggregation.withOptions(aggregationOptionsToAllowDiskUse);
        } else if (searchSources.containsKey(ORG_ALIAS)) {
            String organizationName = searchSources.get(ORG_ALIAS);
            inputData.setSourceName(organizationName);
            aggregation = AutoMatchQueryBuilder.autoMatchUSRegionForOrgAlias(inputData);
            aggregation.withOptions(aggregationOptionsToAllowDiskUse);
        }else{
            return null;
        }
        return aggregation;
    }
}
