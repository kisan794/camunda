package com.hireright.sourceintelligence.service.impl.elasticsearch;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.searchindex.entity.ElasticsearchSource;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.util.Helper;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.hireright.sourceintelligence.domain.constants.Constants.SmartSearchKeys.*;
import static com.hireright.sourceintelligence.domain.mapper.SourceMapper.mapToJSONObject;

@AllArgsConstructor
@Component
public class ElasticsearchMapper {

    public ElasticsearchSource sourceToSearchSourceMapping(Source source) {
        ElasticsearchSource searchSource = new ElasticsearchSource();
        if (source.getApprovalStatus().equals(ApprovalStatus.APPROVED)) {
            mapSourceDetails(source, searchSource);
            mapAddress(source, searchSource);
            JSONObject payload = mapToJSONObject(source.getPayload());
            if (payload.has(CONTACTS) && payload.get(CONTACTS) != null) {
                var contacts = (JSONArray) payload.get(CONTACTS);
                if (!contacts.isEmpty()) {
                    var contactDetails = ((JSONObject) contacts.get(0)).has(CONTACT_DETAILS) ? (JSONArray) ((JSONObject) contacts.get(0)).get(CONTACT_DETAILS) : new JSONArray();
                    if (contactDetails != null && !contactDetails.isEmpty()) {
                        for (Object contactDetail : contactDetails) {
                            JSONObject contactDetailJson = (JSONObject) contactDetail;
                            if (contactDetailJson.has(TYPE) && !contactDetailJson.isNull(TYPE)) {
                                String key = (String) contactDetailJson.get(TYPE);
                                if (contactDetailJson.has(COMMUNICATION) && contactDetailJson.get(COMMUNICATION) != null) {
                                    var communication = (JSONArray) contactDetailJson.get(COMMUNICATION);
                                    if (!communication.isEmpty()){
                                        List<String> automatedService = new ArrayList<>();
                                        List<String> codes = new ArrayList<>();
                                        List<String> phoneNumbers = new ArrayList<>();
                                        List<String> faxNumbers = new ArrayList<>();
                                        List<String> emailList = new ArrayList<>();
                                        for (Object communicationList : communication) {
                                            JSONObject communicationObj = (JSONObject) communicationList;
                                            if (communicationObj.has(COMMUNICATION_INFO)) {
                                                if (key.equals(CONTACT_AUTOMATED_SERVICES) && communicationObj.has(NAME)) {
                                                    automatedService.add(((String) communicationObj.get(NAME)).trim());
                                                }
                                                JSONArray communicationInfoDetails = (JSONArray) communicationObj.get(COMMUNICATION_INFO);
                                                String number = "";
                                                String countryCode = "";
                                                String areaCode = "";
                                                String extension = "";
                                                if (communicationInfoDetails != null && !communicationInfoDetails.isEmpty()) {
                                                    for (Object communicationInfo : communicationInfoDetails) {
                                                        if (communicationInfo instanceof JSONObject communicationInfoJson) {
                                                            if (communicationInfoJson.has(TYPE)) {
                                                                String type = (String) communicationInfoJson.get(TYPE);
                                                                var value = !communicationInfoJson.isNull(VALUE) ? communicationInfoJson.get(VALUE) : "";
                                                                if (key.equals(CONTACT_PHONES)) {
                                                                    if (type.equals(AREA_CODE)) {
                                                                        areaCode = ((String) value).trim();
                                                                    }
                                                                    if (type.equals(PHONE_COUNTRY_CODE)) {
                                                                        countryCode = ((String) value).trim();
                                                                    }
                                                                    if (type.equals(PHONE_NUMBER)) {
                                                                        number = ((String) value).trim();
                                                                    }
                                                                    if (type.equals(EXTENSION)) {
                                                                        extension = ((String) value).trim();
                                                                    }
                                                                }
                                                                if (key.equals(CONTACT_FAXES)) {
                                                                    if (type.equals(AREA_CODE)) {
                                                                        areaCode = ((String) value).trim();
                                                                    }
                                                                    if (type.equals(PHONE_COUNTRY_CODE)) {
                                                                        countryCode = ((String) value).trim();
                                                                    }
                                                                    if (type.equals(PHONE_NUMBER)) {
                                                                        number = ((String) value).trim();
                                                                    }
                                                                    if (type.equals(EXTENSION)) {
                                                                        extension = ((String) value).trim();
                                                                    }
                                                                }
                                                                if (key.equals(CONTACT_EMAILS) && type.equals(ADDRESS)) {
                                                                    emailList.add(((String) value).trim().toLowerCase());
                                                                }

                                                                if (key.equals(CONTACT_AUTOMATED_SERVICES) && type.equals(CODES)) {
                                                                    String code = ((String) value).trim().toLowerCase();
                                                                    String[] list = code.split(";");
                                                                    Collections.addAll(codes, list);
                                                                }
                                                            }
                                                        }
                                                    }
                                                    if (key.equals(CONTACT_PHONES)) {
                                                        if(!countryCode.contains("+")){
                                                            countryCode = "+"+countryCode;
                                                        }
                                                        String phoneNumber = countryCode+areaCode+number;
                                                        if (!StringUtils.isEmpty(phoneNumber) && !StringUtils.isEmpty(extension)) {
                                                            phoneNumbers.add(phoneNumber);
                                                            phoneNumbers.add(phoneNumber + ":" + extension);
                                                        } else if (!StringUtils.isEmpty(phoneNumber) && StringUtils.isEmpty(extension)) {
                                                            phoneNumbers.add(phoneNumber);
                                                        }
                                                    }
                                                    if(key.equals(CONTACT_FAXES)){
                                                        if(!countryCode.contains("+")){
                                                            countryCode = "+"+countryCode;
                                                        }
                                                        String faxNumber = countryCode+areaCode+number;
                                                        if (!StringUtils.isEmpty(faxNumber) && !StringUtils.isEmpty(extension)) {
                                                            faxNumbers.add(faxNumber);
                                                            faxNumbers.add(faxNumber + ":" + extension);
                                                        } else if (!StringUtils.isEmpty(faxNumber) && StringUtils.isEmpty(extension)) {
                                                            faxNumbers.add(faxNumber);
                                                        }else{
                                                            faxNumbers.add(faxNumber);
                                                        }
                                                    }
                                                }
                                            }
                                            if (!phoneNumbers.isEmpty()) {
                                                searchSource.setPhoneNumber(phoneNumbers);
                                            }
                                            if (!faxNumbers.isEmpty()) {
                                                searchSource.setFaxNumber(faxNumbers);
                                            }
                                            if (!emailList.isEmpty()) {
                                                searchSource.setEmail(emailList);
                                            }
                                            if (!automatedService.isEmpty()) {
                                                searchSource.setAutomatedService(automatedService);
                                            }
                                            if (!codes.isEmpty()) {
                                                searchSource.setCode(codes);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return searchSource;
    }

    private void mapSourceDetails(Source source, ElasticsearchSource searchSource){
        searchSource.setHon(source.getHon());
        searchSource.setOrganizationName(source.getOrganizationName().trim());
        if(!ObjectUtils.isEmpty(source.getOrganizationAlias())){
            Alias[] aliases = source.getOrganizationAlias();
            List<String> aliasList = new ArrayList<>();
            for (Alias alias : aliases) {
                if (!StringUtils.isEmpty(alias.getName()) && !alias.getName().isBlank()) {
                    aliasList.add(alias.getName().trim());
                }
            }
            searchSource.setOrganizationAlias(aliasList);
        }
        searchSource.setStatus(source.getStatus().getStatus());
        if(source.getApprovalStatus().equals(ApprovalStatus.APPROVED) || source.getApprovalStatus().equals(ApprovalStatus.REJECTED)){
            searchSource.setApprovalStatus(source.getApprovalStatus().getStatus());
        }else{
            searchSource.setApprovalStatus(ApprovalStatus.PENDING_APPROVAL.getStatus());
        }
        JSONObject payload = mapToJSONObject(source.getPayload());
        if (payload.has(DEPARTMENT_NAME) && !StringUtils.isEmpty((String) payload.get(DEPARTMENT_NAME))) {
            searchSource.setDepartment(((String) payload.get(DEPARTMENT_NAME)).trim());
        }
        if (payload.has(WEBSITE) && !StringUtils.isEmpty((String) payload.get(WEBSITE))) {
            searchSource.setWebsite(((String) payload.get(WEBSITE)).trim().toLowerCase());
        }
    }

    private void mapAddress(Source source, ElasticsearchSource searchSource){
        searchSource.setCountry(source.getCountry().trim());
        if(StringUtils.isNotEmpty(source.getState())){
            searchSource.setState(source.getState().trim());
        }
        if(StringUtils.isNotEmpty(source.getCity())){
            searchSource.setCity(Helper.removeExtraSpaces(source.getCity().trim().toLowerCase()));
        }
        if(StringUtils.isNotEmpty(source.getPostalCode())){
            searchSource.setPostalCode(source.getPostalCode().trim().toLowerCase());
        }
        JSONObject payload = mapToJSONObject(source.getPayload());
        if (payload.has(ADDRESS)) {
            JSONArray address = payload.getJSONArray(ADDRESS);
            if(!address.isEmpty()){
                JSONObject addr = (JSONObject) address.get(0);
                if(addr.get(LINE) != null && addr.get(LINE) != ""){
                    searchSource.setAddressLine(((String) addr.get(LINE)).trim());
                }
            }
        }
    }

}
