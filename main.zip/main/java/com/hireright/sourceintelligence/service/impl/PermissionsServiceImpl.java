package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.v2.dto.PermissionsDTO;
import com.hireright.sourceintelligence.domain.entity.Permissions;
import com.hireright.sourceintelligence.domain.repository.PermissionsRepositary;
import com.hireright.sourceintelligence.service.PermissionsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowPermissionsDenied;

@Primary
@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
public class PermissionsServiceImpl implements PermissionsService {

    private final PermissionsRepositary permissionsRepositary;

    @Override
    public PermissionsDTO getPermissionByNameAndStatus(String userName, String status) {
        Permissions permissions = permissionsRepositary.findByUserNameAndStatus(userName,status);
        if (permissions == null) {
            logAndThrowPermissionsDenied(ACCESS_DENIED_ERROR, null, userName);
            return null;
        }
        PermissionsDTO permissionsDTO = new PermissionsDTO();
        permissionsDTO.setScope(permissions.getScope());
        permissionsDTO.setTrustScore(permissions.getTrustScore());
        permissionsDTO.setPermissions(permissions.getPermissions());
        permissionsDTO.setApprovalGroupList(permissions.getApprovalGroupList());
        permissionsDTO.setUserName(permissions.getUserName());
        permissionsDTO.setUserEmail(permissions.getUserEmail());
        permissionsDTO.setStatus(permissions.getStatus());
        return permissionsDTO;
    }
}
