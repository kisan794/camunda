package com.hireright.sourceintelligence.service.impl.helperservices;

import com.hireright.sourceintelligence.api.dto.Alias;
import com.hireright.sourceintelligence.api.dto.CycleResult;
import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.UIActionsDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.SourceOrganizationStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.UserCycleRepository;
import com.hireright.sourceintelligence.exception.Location;
import com.hireright.sourceintelligence.service.impl.*;
import com.hireright.sourceintelligence.service.impl.elasticsearch.ElasticsearchService;
import com.hireright.sourceintelligence.util.Helper;
import com.hireright.sourceintelligence.util.HonGenerator;
import com.mongodb.DBObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import jakarta.validation.constraints.NotNull;
import java.time.Instant;
import java.util.Arrays;
import java.util.Optional;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.*;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.USED_COUNT;
import static com.hireright.sourceintelligence.util.LoggingThrowable.*;

@Primary
@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
public class CreateSourceService {

    private static final String SOURCE_ORGANIZATION_WITH_HON = "SourceOrganization with HON: ";

    private final SourceMapper sourceMapper;

    private final MongoSourceService mongoSourceService;
    private final ReportDataUtils reportDataUtils;
    private final CountryRegionMappingUtils countryRegionMappingUtils;
    private final ElasticsearchService elasticsearchService;
    private final SourceUtils sourceUtils;
    private final UserCycleRepository userCycleRepository;

    @Value("${shard.location}")
    private String shardLocation;

    public SourceOrganizationDTO createSource(@NotNull SourceOrganizationDTO sourceOrganizationDTO, UIActionsDTO uiActionsDTO) throws Exception {
        Source orgEntity = sourceMapper.dtoToEntitySource(sourceOrganizationDTO);
        String hon = HonGenerator.createHon(sourceOrganizationDTO.getOrganizationType());
        if (ObjectUtils.isEmpty(hon)) {
            logAndThrowInternalServiceException(FAILED_TO_CREATE_HON, null);
        }
        String collectionName = Helper.getCollectionName(orgEntity.getOrganizationType().getType(), SOURCE_COLLECTION_SUFFIX);
        orgEntity.setHon(hon);
        if (mongoSourceService.isHonExists(orgEntity.getHon())) {
            logAndThrowAlreadyExistsException(HON_ALREADY_EXISTS, null, orgEntity.getHon());
        }
        String saveHon = SOURCE_ORGANIZATION_WITH_HON + orgEntity.getHon();
        SourceOrganizationDTO duplicateResult = mongoSourceService.getPossibleDuplicateSources(sourceOrganizationDTO);
        if (duplicateResult != null && !duplicateResult.getHon().equals(orgEntity.getHon())) {
            logAndThrowAlreadyExistsException(SOURCE_ALREADY_EXISTS, null,
                    duplicateResult.getHon());
        }
        commonFields(orgEntity, uiActionsDTO);
        String region = countryRegionMappingUtils.getRegionByCountry(sourceOrganizationDTO.getCountry());
        CycleResult cycleResult = sourceUtils.checkForAutoApproval(uiActionsDTO.getUserTrustScore(), region, uiActionsDTO.getUserEmail());
        if(sourceOrganizationDTO.getOrganizationAlias().length == 1){
            Optional<Alias> alias = Arrays.stream(sourceOrganizationDTO.getOrganizationAlias()).findFirst();
            if(alias.get().getName().isEmpty()){
                sourceOrganizationDTO.setOrganizationAlias(new Alias[]{});
            }
        }
        if (AUTO_APPOVED.equals(cycleResult.getStatus()) && sourceOrganizationDTO.getOrganizationAlias().length == 0) {
            updateFieldsForApproved(orgEntity, uiActionsDTO);
        }
        if(orgEntity.getApprovalStatus().equals(PENDING_APPROVAL) || orgEntity.getApprovalStatus().equals(SAVE_PENDING_APPROVAL)){
            orgEntity.setTempVersion(1);
            orgEntity.setVersion(0);
        }
        orgEntity.setLastActionDate(Instant.now());
        var sourceCreated = mongoSourceService.insert(orgEntity, collectionName);
        log.info("{} created successfully", saveHon);
        mongoSourceService.insertSourceHistory(orgEntity);

        // Updating user cycle object with new cycle values
        if(sourceCreated != null && cycleResult.getCycle() != null && sourceOrganizationDTO.getOrganizationAlias().length == 0) {
            userCycleRepository.save(cycleResult.getCycle());
            log.info("updated user cycle successfully for user id {} and region {}", uiActionsDTO.getUserEmail(), region);
        }
        if (sourceCreated != null && APPROVED.equals(sourceCreated.getApprovalStatus())) {
            elasticsearchService.createSource(orgEntity);
        }

        /* Report Data Starts */
        reportDataUtils.reportData(orgEntity, SearchConstants.ReportActions.CREATE, SIDB_CURD, 0, null);

        /* Report Data Ends */
        return sourceMapper.entitySourceToDTO(sourceCreated);
    }

    private void commonFields(Source orgEntity, UIActionsDTO uiActionsDTO){
        orgEntity.setLocation(Location.getLocationValueForSharding(shardLocation));
        Instant date = Instant.now();
        orgEntity.setCreatedDate(date);
        orgEntity.setCreatedBy(uiActionsDTO.getUserName());
        orgEntity.setCreatorId(uiActionsDTO.getUserEmail());
        orgEntity.setLastModifiedDate(date);
        orgEntity.setSearchOrg(orgEntity.getOrganizationName().toLowerCase());
        orgEntity.setAssignedTo(UNASSIGNED);
        orgEntity.setAssignedId(UNASSIGNED);
        orgEntity.setLogFlag(SearchConstants.LogFlagConstants.NEW_RECORD);
        orgEntity.setFlagPriority(Boolean.FALSE);
        orgEntity.setAction(CREATE);
        DBObject obj = orgEntity.getPayload();
        obj.put(USED_COUNT, 0);
        orgEntity.setPayload(obj);

        orgEntity.setApprovalStatus(Helper.fromAction(uiActionsDTO.getUserAction()));
        orgEntity.setStatus(SourceOrganizationStatus.INACTIVE);
    }

    private void updateFieldsForApproved(Source orgEntity, UIActionsDTO uiActionsDTO){
        orgEntity.setApprovalStatus(APPROVED);
        orgEntity.setLastApprovedDate(Instant.now());
        orgEntity.setApproverId(uiActionsDTO.getUserEmail());
        orgEntity.setApprovedBy(uiActionsDTO.getUserName());
        orgEntity.setAssignedTo(uiActionsDTO.getUserName());
        orgEntity.setAssignedId(uiActionsDTO.getUserEmail());
        orgEntity.setStatus(SourceOrganizationStatus.ACTIVE);
        orgEntity.setTempVersion(0);
        orgEntity.setVersion(1);
    }

}