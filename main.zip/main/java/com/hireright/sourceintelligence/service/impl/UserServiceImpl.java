package com.hireright.sourceintelligence.service.impl;

import static com.hireright.sourceintelligence.constants.ErrorConstants.UNABLE_TO_GET_USER_DETAILS;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInternalServiceException;

import com.hireright.sourceintelligence.api.dto.Users;
import java.io.IOException;
import java.util.Objects;

import com.hireright.sourceintelligence.service.CommonUtilService;
import com.hireright.sourceintelligence.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Call;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
public class UserServiceImpl implements UserService {

  @Value("${uas.users.url}")
  private String uasUsersURL;

  private final CommonUtilService commonUtilService;

  @Override
  public Users getUserAccountServiceUsers(String username) {

    log.info("Calling User account service Api to get user by username");
    HttpUrl.Builder urlBuilder
        = Objects.requireNonNull(HttpUrl.parse(uasUsersURL)).newBuilder();
    urlBuilder.addQueryParameter("username", username);
    urlBuilder.addQueryParameter("order", "asc");
    urlBuilder.addQueryParameter("sort", "username");
    urlBuilder.addQueryParameter("batchSize", "10");
    urlBuilder.addQueryParameter("startIndex", "1");
    String url = urlBuilder.build().toString();
    Request request = new Request.Builder().url(url).build();

    try {
      OkHttpClient client = new OkHttpClient.Builder().build();
      Call call = client.newCall(request);
      Response response = call.execute();
      return commonUtilService.convertBytesToPOJO(Objects.requireNonNull(response.body()).bytes(), Users.class);
    } catch (IOException ioException) {
      logAndThrowInternalServiceException(UNABLE_TO_GET_USER_DETAILS,ioException,username);
    }
    return null;
  }
}
