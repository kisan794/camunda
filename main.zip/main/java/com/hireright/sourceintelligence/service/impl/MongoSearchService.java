package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.SmartSearchDTO;
import com.hireright.sourceintelligence.api.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.enums.OrganizationType;
import com.hireright.sourceintelligence.domain.mapper.SourceDTOMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.util.Helper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.SOURCE_COLLECTION_SUFFIX;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchScore.SMART_SEARCH_LIMIT;
import static java.util.Comparator.nullsLast;
import static java.util.Comparator.reverseOrder;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;


@Slf4j
@AllArgsConstructor
@Service
public class MongoSearchService {

    private final SourceDTOMapper sourceDTOMapper;
    private final CustomSourceRepository<Source> customSourceRepository;


    protected List<Source> smartSearchExecution(Criteria criteria, SmartSearchDTO smartSearchDTO){
        MatchOperation matchOperation = QueryBuilder.buildMatch(criteria);
        log.info("matchOperation: {}", matchOperation);
        SortOperation sortOperation = QueryBuilder.buildSortOperation(SearchConstants.SortFields.TOTAL_COUNT, "desc");
        LimitOperation limitOperation = new LimitOperation(SMART_SEARCH_LIMIT);
        AggregationOptions aggregationOptionsToAllowDiskUse = AggregationOptions.builder()
                .allowDiskUse(true).build();

        Aggregation aggregation = Aggregation.newAggregation(matchOperation, limitOperation, sortOperation).withOptions(aggregationOptionsToAllowDiskUse);
        log.info("Aggregate Start Time: {}, aggregation: {}", LocalDateTime.now(), aggregation);
        String collectionName = Helper.getCollectionName(smartSearchDTO.getOrganizationType(), SOURCE_COLLECTION_SUFFIX);
        List<Source> searchResult = customSourceRepository.aggregate(aggregation, collectionName, Source.class);
        log.info("Aggregate Document Result Time: {}", LocalDateTime.now());
        return searchResult;
    }

    protected List<SourceDTO> getSmartSearchResponseByHonIds(Map<String,String> smartSearchFields, String collectionName, Set<String> honIds) {
        log.info("getSmartSearchResponseByHonIds:1: {}", Instant.now());
        List<Source> result = new ArrayList<>();
        Criteria criteria = QueryBuilder.smartSearchCriteria(honIds, smartSearchFields);
        if(smartSearchFields.containsKey(PAYLOAD_RELATIONSHIPS_RELATIONSHIP)){
            criteria.and(PAYLOAD_RELATIONSHIPS_RELATIONSHIP).in(SearchConstants.ParentChildTypes.PARENT_TYPE);
        }
        MatchOperation matchOperation = QueryBuilder.buildMatch(criteria);
        SortOperation sortOperation = QueryBuilder.buildSortOperation(SearchConstants.SortFields.TOTAL_COUNT, "desc");
        Aggregation aggregation = newAggregation(matchOperation, sortOperation,limit(SMART_SEARCH_LIMIT));
        log.info("aggregate query: {}", aggregation);
        result = customSourceRepository.aggregate(aggregation, collectionName, Source.class);
        if(!result.isEmpty()){
            log.info("getSmartSearchResponseByHonIds:2: {}", Instant.now());
            //parallism
            List<SourceDTO> outputList;
            if(result.size() > 10){
                log.info("parallel search results format starts: {}", Instant.now());
                outputList = Collections.synchronizedList(new ArrayList<>());
                result.parallelStream().forEach(source ->
                    outputList.add(sourceDTOMapper.toSourceDTO(source))
                );
                log.info("parallel search results format ends: {}", Instant.now());
            }else{
                outputList = sourceDTOMapper.entityToSourceList(result);
            }
            log.info("getSmartSearchResponseByHonIds:3: {}", Instant.now());
            return outputList.stream().sorted(Comparator
                            .comparing(SourceDTO::getUsedCount, nullsLast(reverseOrder())))
                    .collect(Collectors.toCollection(LinkedList::new));
        }
        return new ArrayList<>();
    }

    protected List<String> getDropDownListForRAM(String keyword, OrganizationType organizationType){
        String collectionName = Helper.getCollectionName(organizationType.getType(), SOURCE_COLLECTION_SUFFIX);
        Aggregation aggregation = QueryBuilder.buildQueryForDropdown(keyword);
        log.info("dropdown aggregation: {}", aggregation);
        Document result = customSourceRepository.aggregateDocument(aggregation, collectionName);
        if(!result.isEmpty()){
            List<Document> rs = (ArrayList) result.get(RESULTS);
            if(!rs.isEmpty()){
                List<String> orgList = (ArrayList)rs.get(0).get(ORG_NAMES);
                if(orgList != null && !orgList.isEmpty()){
                    return orgList;
                }
            }
        }
        return null;
    }

    //Scheduler Related methods
    public List<Source> findAllSourcesWithInProgress(String collectionName){
        log.info("findAllSourcesWithInProgress");
        List<Source> result = new ArrayList<>();

        Date now = new Date();
        Date thirtyMinutesAgo = new Date(now.getTime() - 30 * 60 * 1000);

        Query query = new Query();
        query.addCriteria(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.IN_PROGRESS.getStatus()));
        query.addCriteria(Criteria.where(APPROVAL_START_DATE).lte(thirtyMinutesAgo));
        result = customSourceRepository.findByQuery(query, Source.class,collectionName);

        return result;
    }

    public List<Source> findAllSourcesWithOnHold(String collectionName){
        log.info("findAllSourcesWithOnHold");
        List<Source> result = new ArrayList<>();

        Date now = new Date();
        Date oneDayAgo = new Date(now.getTime() - 24L * 60 * 60 * 1000);

        Query query = new Query();
        query.addCriteria(Criteria.where(APPROVAL_STATUS).is(ApprovalStatus.ONHOLD.getStatus()));
        query.addCriteria(Criteria.where(APPROVAL_START_DATE).lte(oneDayAgo));
        result = customSourceRepository.findByQuery(query, Source.class,collectionName);

        return result;
    }

}
