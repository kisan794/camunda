package com.hireright.sourceintelligence.service.impl;

import com.hireright.sourceintelligence.api.dto.SourceOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.history.ChangeLogResponse;
import com.hireright.sourceintelligence.api.dto.history.ChangelogResponseDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import com.hireright.sourceintelligence.domain.enums.ApprovalStatus;
import com.hireright.sourceintelligence.domain.mapper.SourceMapper;
import com.hireright.sourceintelligence.domain.repository.CustomSourceRepository;
import com.hireright.sourceintelligence.service.SourceHistoryService;
import com.hireright.sourceintelligence.util.Helper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import jakarta.validation.constraints.NotNull;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.*;
import static com.hireright.sourceintelligence.constants.ErrorConstants.SOURCE_VERSION_NOT_FOUND;
import static com.hireright.sourceintelligence.domain.enums.ApprovalStatus.APPROVED;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowResourceNotFound;

@Primary
@Slf4j
@RequiredArgsConstructor
@Transactional
@Service
public class SourceHistoryServiceImpl implements SourceHistoryService {

    private final SourceMapper sourceMapper;
    private final CustomSourceRepository<Source> customSourceRepository;

    @Override
    public List<SourceOrganizationDTO> getSourcesByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc(String hon, ApprovalStatus approvalStatus, Double version) {
        String collectionName = Helper.getCollectionName(hon, SOURCE_HISTORY_COLLECTION_SUFFIX);
        List<Source> sourceOrganizationHistories = customSourceRepository
                .findByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc(hon, approvalStatus, version, Source.class, collectionName);
        return sourceMapper.toSourceDTOList(sourceOrganizationHistories);
    }

    //TODO - revalidate when approval flow starts[Dont touch for now]
    @Override
    public List<SourceOrganizationDTO> getSourcesByHonAndApprovalStatusOrderByVersionDesc(String hon, ApprovalStatus approvalStatus) {
        List<Source> result = new LinkedList<>();
        String collectionName = Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
        List<Source> source = customSourceRepository.findByHon(hon, Source.class, collectionName);

        String historyCollectionName = Helper.getCollectionName(hon, SOURCE_HISTORY_COLLECTION_SUFFIX);

        List<Source> sourceOrganizationHistories = customSourceRepository.findByHonAndApprovalStatusOrderByVersionDesc(hon,
                approvalStatus, Source.class, historyCollectionName);
        if(!source.isEmpty()){
            result.addFirst(source.getFirst());
        }
        if(!sourceOrganizationHistories.isEmpty()){
            result.addAll(1, sourceOrganizationHistories);
        }
        return sourceMapper.toSourceDTOList(result);
    }

    @Override
    public ChangeLogResponse getChangeLogByHon(String hon, ApprovalStatus approvalStatus) {
        ChangeLogResponse result = new ChangeLogResponse();
        double latestActiveVersion = getLatestActiveVersion(hon);
        List<ChangelogResponseDTO> activeSources = new ArrayList<>();
        String historyCollectionName = Helper.getCollectionName(hon, SOURCE_HISTORY_COLLECTION_SUFFIX);
        int  version = (int) Math.round(latestActiveVersion);
        for (int i = version; i > 0; i--) {
            ChangelogResponseDTO changeLogResponse = new ChangelogResponseDTO();
            List<Source> activeSource = getActiveSources(hon,version,i,historyCollectionName);
            double subVersion = (i - 1);
            if (activeSource != null && !activeSource.isEmpty()) {
                for (int j = 0; j < activeSource.size(); j++) {
                    ChangelogResponseDTO changeLogResponseDTO = new ChangelogResponseDTO();
                    changeLogResponseDTO.setSourceDTO(sourceMapper.entitySourceToDTO(activeSource.get(j)));
                    if(j == activeSource.size()-1){
                        getSubVersions(hon, subVersion, changeLogResponseDTO, historyCollectionName);
                    }
                    activeSources.add(changeLogResponseDTO);
                }
            }else{
                getSubVersions(hon, subVersion, changeLogResponse, historyCollectionName);
                activeSources.add(changeLogResponse);
            }
            if(changeLogResponse.getSourceDTO() == null && (changeLogResponse.getVersions() == null || changeLogResponse.getVersions().isEmpty())){
                break;
            }
        }
        result.setActiveSources(activeSources);
        return result;
    }

    @Override
    public SourceOrganizationDTO getSourceByHonAndVersion(@NotNull String hon, @NotNull Double version) {
        var response = findSourceOrganizationHistoryByHonAndVersion(hon, version);
        if (response == null) {
            String collectionName = Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
            response = findSourceByHonAndVersion(hon, version,collectionName);
            if(response == null){
                logAndThrowResourceNotFound(SOURCE_VERSION_NOT_FOUND, null, hon, version);
            }
            }
        return sourceMapper.entitySourceToDTO(response);
    }

    //TODO - Async implementation pending
    @Override
    public List<SourceOrganizationDTO> getSourcesForDiff(String hon, Double version, String sourceType) {
        log.info("getSourcesForDiff Starts");
        //current - source and source history
        List<SourceOrganizationDTO> sourceOrganizationHistories = new LinkedList<>();
        String collectionName = Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
        String historyCollectionName = Helper.getCollectionName(hon, SOURCE_HISTORY_COLLECTION_SUFFIX);

        if(Objects.equals(sourceType, CURRENT)){
            Source currentSourceOrganization = customSourceRepository.findOneByHonAndVersion(hon, version, Source.class, collectionName);
            Source lastSourceOrganization = customSourceRepository.findOneByHonAndVersion(hon, version-1, Source.class, historyCollectionName);
            sourceOrganizationHistories.add(!ObjectUtils.isEmpty(currentSourceOrganization) ? sourceMapper.entitySourceToDTO(currentSourceOrganization) : null);
            sourceOrganizationHistories.add(!ObjectUtils.isEmpty(lastSourceOrganization) ? sourceMapper.entitySourceToDTO(lastSourceOrganization) : null);

        }else {
            //PREVIOUS
            Double[] versions = new Double[]{version,version-1};
            List<Source> approvedSourceOrganizations = customSourceRepository
                    .findByHonAndVersionInOrderByVersionDesc(hon, versions, Source.class, historyCollectionName);
            if(!approvedSourceOrganizations.isEmpty()){
                sourceOrganizationHistories = sourceMapper.toSourceDTOList(approvedSourceOrganizations);
            }
        }
        log.info("getSourcesForDiff Ends");
        return sourceOrganizationHistories;
    }

    private Source findSourceOrganizationHistoryByHonAndVersion(@NotNull String hon, @NotNull Double version) {
        String collectionName = Helper.getCollectionName(hon, SOURCE_HISTORY_COLLECTION_SUFFIX);
        return customSourceRepository.findOneByHonAndVersion(hon, version, Source.class, collectionName);
    }

    private Source findSourceByHonAndVersion(@NotNull String hon, @NotNull Double version, String collectionName) {
        return customSourceRepository.findOneByHonAndVersion(hon, version, Source.class, collectionName);
    }

    private double getLatestActiveVersion(String hon){
        double latestActiveVersion = 0.0;
        String collectionName = Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
        List<Source> sourceList = customSourceRepository.findByHonOrderByLastModifiedDateDesc(hon, Source.class, collectionName);
        if(!sourceList.isEmpty()){
            Source source = sourceList.getFirst();
            latestActiveVersion = source.getVersion();
            if(source.getApprovalStatus() != null && !source.getApprovalStatus().equals(APPROVED)){
                latestActiveVersion = latestActiveVersion + 1;
            }
        }
        return latestActiveVersion;
    }

    private void getSubVersions(String hon,double version, ChangelogResponseDTO changeLogResponse, String historyCollectionName){
        List<Source> sourceOrganizationHistories = customSourceRepository.getHistoryByHonAndVersion(hon, version, Source.class, historyCollectionName);
        if(!sourceOrganizationHistories.isEmpty()){
            changeLogResponse.setVersions(sourceMapper.toSourceDTOList(sourceOrganizationHistories));
        }
    }

    private List<Source> getActiveSources(String hon, double version,int i, String historyCollectionName){
        List<Source> activeSource = customSourceRepository.findByHonAndVersionAndApprovalStatus(hon, i, Source.class, historyCollectionName);
        if(version == i && (activeSource == null || activeSource.isEmpty())){
            String collectionName = Helper.getCollectionName(hon, SOURCE_COLLECTION_SUFFIX);
            activeSource = customSourceRepository.findByHonAndVersionAndApprovalStatus(hon, i, Source.class, collectionName);
        }
        return activeSource;
    }

}
