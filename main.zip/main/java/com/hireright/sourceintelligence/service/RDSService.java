package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.dto.rds.VendorResponseDTO;

public interface RDSService {

    VendorResponseDTO getVendorList();

}
