package com.hireright.sourceintelligence.service;

import com.hireright.sourceintelligence.api.v2.dto.PermissionsDTO;

public interface PermissionsService {

    PermissionsDTO getPermissionByNameAndStatus(String userName, String status);
}
