package com.hireright.sourceintelligence.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("https://api-int-azdev.data.hireright.com","http://localhost:3000","https://sources-azdev.hireright.com/", "https://sources-aztest.hireright.com/","https://sources-dev.hireright.com/","https://sources-test.hireright.com/", "https://sources-azdev.data.hireright.com/", "https://si-test.data.hireright.com/", "https://si-stg.data.hireright.com/","https://si.data.hireright.com/") // React app URL
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowCredentials(true); // Allow cookies
    }
}
