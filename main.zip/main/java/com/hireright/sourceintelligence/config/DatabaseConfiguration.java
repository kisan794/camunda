package com.hireright.sourceintelligence.config;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ReadPreference;
import com.mongodb.WriteConcern;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.PRODUCTION;
import static com.hireright.sourceintelligence.constants.ApplicationConstants.STAGE;

@Configuration
@EnableMongoRepositories(basePackages = "com.hireright.sourceintelligence.domain",
		considerNestedRepositories = true
)
public class DatabaseConfiguration extends AbstractMongoClientConfiguration {
	
	@Value("${spring.data.mongodb.database}")
	private String primaryDatabaseName;
	
	@Value("${spring.data.mongodb.uri}")
	private String dbConnectionString;

	@Value("${elasticsearchEnvType}")
	private String elasticsearchEnvType;

	@Bean
	MongoTransactionManager transactionManager(MongoDatabaseFactory dbFactory) {
		return new MongoTransactionManager(dbFactory);
	}

	@Override
	protected String getDatabaseName() {
		return primaryDatabaseName;
	}

    @NotNull
	@Override
    public MongoClient mongoClient() {
		final ConnectionString connectionString = new ConnectionString(dbConnectionString);
		MongoClientSettings.Builder builder = MongoClientSettings.builder()
				.applyConnectionString(connectionString);
		if(elasticsearchEnvType.equals(STAGE) || elasticsearchEnvType.equals(PRODUCTION)){
			builder.retryWrites(true)
					.readPreference(ReadPreference.primary())
					.writeConcern(WriteConcern.MAJORITY);
		}
		final MongoClientSettings mongoClientSettings = builder.build();
        return MongoClients.create(mongoClientSettings);
    }
}
