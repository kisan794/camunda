package com.hireright.sourceintelligence.config;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import java.time.Duration;

public class RequestInProgressCache {

    public static final Cache<String, Boolean> inProgressCache =
            Caffeine.newBuilder()
                    .expireAfterWrite(Duration.ofSeconds(30)) // window
                    .maximumSize(5000)
                    .build();
}
