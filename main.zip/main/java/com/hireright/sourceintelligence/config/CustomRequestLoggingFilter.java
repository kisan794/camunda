package com.hireright.sourceintelligence.config;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

public class CustomRequestLoggingFilter extends CommonsRequestLoggingFilter {

    @Override
    protected boolean shouldLog(HttpServletRequest request) {
        String uri = request.getRequestURI();
        if (uri.contains("/actuator/health") || uri.contains("/actuator/health/liveness") || uri.contains("/timezones") || uri.contains("/swagger-ui")) {
            return false;
        }
        return true;
    }
}
