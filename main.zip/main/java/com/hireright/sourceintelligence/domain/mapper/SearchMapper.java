package com.hireright.sourceintelligence.domain.mapper;
import static com.hireright.sourceintelligence.constants.ErrorConstants.PARSE_FAILED;
import static com.hireright.sourceintelligence.exception.SetIfNotNull.setIfNotNull;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowServiceException;
import static org.mapstruct.ReportingPolicy.IGNORE;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.sourceintelligence.api.dto.SearchOrganizationDTO;
import com.hireright.sourceintelligence.api.dto.SearchPayload;
import com.hireright.sourceintelligence.api.dto.SmartSearchResultDTO;
import com.hireright.sourceintelligence.api.dto.SourceDTO;
import com.hireright.sourceintelligence.domain.entity.Source;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.mapstruct.*;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS,
    unmappedTargetPolicy = IGNORE)
public interface SearchMapper {

  @Slf4j
  final class LogHolder
  {}

   default <T> T convertJsonToPOJO(String source, Class<T> target) {
    LogHolder.log.info("Source string to be converted : " +source);
    ObjectMapper objectMapper = new ObjectMapper();
    T t = null;
    try {
      t = objectMapper.readValue(source, target);
        LogHolder.log.info("After Source string to be converted : " +t);
    } catch (JsonProcessingException jsonProcessingException) {
      logAndThrowServiceException(PARSE_FAILED, jsonProcessingException,source);
    }
    return t;
  }


    @AfterMapping
    default void mapPayloadFields(Source entity, @MappingTarget SearchOrganizationDTO dto) {

        LogHolder.log.info("Parsing source organization with hon "+entity.getHon());
        if(entity.getPayload() == null) {
            return;
        }
        SearchPayload searchPayload = convertJsonToPOJO(entity.getPayload().toString(), SearchPayload.class);
        if(searchPayload == null){
            return;
        }
        setIfNotNull(searchPayload.getContactDetails(),dto::setContactDetails);
        setIfNotNull(searchPayload.getWebsite(),dto::setWebsite);
        setIfNotNull(searchPayload.getNotes(),dto::setNotes);
        setIfNotNull(searchPayload.getAdditionalInfo(),dto::setAdditionalInfo);
        setIfNotNull(searchPayload.getAddressLine(),dto::setAddressLine);
        setIfNotNull(searchPayload.getLastCleanUpDate(),dto::setLastCleanUpDate);
        setIfNotNull(searchPayload.getUsedCount(), dto::setUsedCount);
        setIfNotNull(searchPayload.getPrimaryContact(),dto::setPrimaryContact);
        setIfNotNull(searchPayload.getDepartmentName(),dto::setDepartmentName);
        setIfNotNull(searchPayload.getDepartmentAliases(),dto::setDepartmentAliases);
        setIfNotNull(searchPayload.getDoNotContact(),dto::setDoNotContact);
        setIfNotNull(entity.getApprovalStatus(),dto::setApprovalStatus);
        setIfNotNull(entity.getAssignedTo(),dto::setAssignedTo);
        setIfNotNull(entity.getStatus(),dto::setStatus);
        setIfNotNull(searchPayload.getRelationships(),dto::setRelationships);
        setIfNotNull(searchPayload.getLastApprovedDateTime(),dto::setLastApprovedDateTime);
        setIfNotNull(searchPayload.getLastUsed(),dto::setLastUsedDate);
    }

    @Mapping(target = "contactDetails", ignore = true)
    @Mapping(target = "website", ignore = true)
    @Mapping(target = "notes", ignore = true)
    @Mapping(target = "additionalInfo", ignore = true)
    @Mapping(target = "primaryContact", ignore = true)
    @Mapping(target = "addressLine", ignore = true)
    @Mapping(target = "lastCleanUpDate", ignore = true)
    //@Mapping(target = "usedCount", ignore = true)
    @Mapping(target = "departmentName", ignore = true)
    @Mapping(target = "departmentAliases", ignore = true)
    @Mapping(target = "doNotContact", ignore = true)
    @Mapping(target = "approvalStatus", ignore = true)
    @Mapping(target = "status", ignore = true)
  SearchOrganizationDTO entitySourceToDTO(Source entity);

  List<SearchOrganizationDTO> toDTOList(List<Source> entityList);

    List<SmartSearchResultDTO> toSmartSourceDTOList(List<Source> entityList);

}
