package com.hireright.sourceintelligence.domain.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum SortOrder {
    ASC("asc"), DESC("desc");

    private final String type;

    SortOrder(String type) {
        this.type = type;
    }

    @JsonCreator
    public static SortOrder fromString(String type) {
        return type == null ? null : SortOrder.valueOf(type.toUpperCase());
    }

    @Override
    public String toString() {
        return type;
    }

    @JsonValue
    public String getType() {
        return this.type.toUpperCase();
    }
}
