package com.hireright.sourceintelligence.domain.enums;

public enum ChangeLogActivity {

  NEW_RECORD("New record"),
  DETAILS_CHANGED("Details changed"),
  ARCHIVED("Archived");

  private String activity;

  ChangeLogActivity(String changeLogActivity) {
    this.activity = changeLogActivity;
  }

  public String getChangeLogActivity() {
    return activity;
  }
}
