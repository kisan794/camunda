package com.hireright.sourceintelligence.domain.enums;

public enum SearchType {
    HON("hon"),
    HONANDVERSION("honAndVersion"),
    AUTOMATCH("autoMatch"),
    SUGGESTIONS("suggestions"),
    COUNTRY_STATE_CITY("country_state_city"),
    COUNTRY_STATE("country_state"),
    COUNTRY_CITY("country_city"),
    COUNTRY("country");

    private final String type;

    SearchType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public static SearchType fromString(String search) {
        for (SearchType searchType : SearchType.values()) {
            if (searchType.getType().equalsIgnoreCase(search)) {
                return searchType;
            }
        }
        return null;
    }
}
