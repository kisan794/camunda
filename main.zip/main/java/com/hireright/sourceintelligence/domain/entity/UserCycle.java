package com.hireright.sourceintelligence.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "user_cycle_evaluation")
public class UserCycle {

    @Id
    private String id;

    private String userId;
    private String region;

    private int autoQuota;
    private int manualQuota;
    private int cycleSize = 10;
    private int effectiveThreshold;
    private int trustScore;
    private int regionThreshold;

    @CreatedDate
    private LocalDateTime cycleStartDate;

    private LocalDateTime lastModifiedDate;
}
