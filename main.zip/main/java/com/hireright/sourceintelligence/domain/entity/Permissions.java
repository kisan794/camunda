package com.hireright.sourceintelligence.domain.entity;

import com.hireright.sourceintelligence.api.dto.ApproverDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document(collection = "permissions")
public class Permissions {

    @Id
    private String id;
    private String userName;
    private String userEmail;
    private String status;
    private String scope;
    private String trustScore;
    private List<String> permissions;
    private List<ApproverDTO> approvalGroupList;
}
