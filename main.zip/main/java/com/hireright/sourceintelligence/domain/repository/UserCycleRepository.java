package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.UserCycle;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface UserCycleRepository extends MongoRepository<UserCycle, String> {

    Optional<UserCycle> findByUserIdAndRegion(String userId, String region);
}
