package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.Vendors;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VendorsRepository extends MongoRepository<Vendors, String> {

    List<Vendors> findByOrganizationType(String organizationType);


    List<Vendors> findByOrganizationTypeOrderByVendorAsc(String organizationType);


    //case insensitive sorting on vendor field
    @Aggregation(pipeline = {
            "{ $match: { organizationType: ?0 } }",
            "{ $addFields: { vendorLower: { $toLower: \"$vendor\" } } }",
            "{ $sort: { vendorLower: 1 } }"
    })
    List<Vendors> findByOrganizationTypeOrderByVendorCaseInsensitive(String organizationType);

}
