package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.MongoSearchResult;
import com.hireright.sourceintelligence.domain.enums.*;
import com.hireright.sourceintelligence.reports.domain.entity.ReportSearchResult;
import com.mongodb.client.result.UpdateResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.*;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.Collections;
import java.util.List;

import static com.hireright.sourceintelligence.constants.ApplicationConstants.UNIQUE_ORG_INDEX;
import static com.hireright.sourceintelligence.constants.ErrorConstants.INVALID_INPUT;
import static com.hireright.sourceintelligence.domain.constants.Constants.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.PayloadFields.*;
import static com.hireright.sourceintelligence.service.impl.SearchConstants.SearchFields.*;
import static com.hireright.sourceintelligence.util.LoggingThrowable.logAndThrowInvalidRequest;

@Slf4j
@RequiredArgsConstructor
@Repository
public class CustomSourceRepositoryImpl<T> implements CustomSourceRepository<T> {

    private final MongoTemplate mongoTemplate;
    private Query query;

    @Override
    public T findOneByHon(String hon, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        return mongoTemplate.findOne(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByHon(String hon, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    public T findLatestByHon(String hon, Class<T> entityClass, String collectionName) {
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        query.with(Sort.by(Sort.Direction.DESC, "last_modified_date")); // Replace "createdAt" with your timestamp field
        query.limit(1);
        return mongoTemplate.findOne(query, entityClass, collectionName);
    }

    @Override
    public Boolean isHonExists(String hon, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        var source = mongoTemplate.findOne(query, entityClass, collectionName);
        return source != null;
    }

    @Override
    public List<T> findByHonAndStatus(String hon, String status, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        query.addCriteria(Criteria.where(FIELD_STATUS).is(status));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByHonAndStatusAndApprovalStatus(String hon, String status, String approvalStatus, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        query.addCriteria(Criteria.where(FIELD_STATUS).is(status));
        query.addCriteria(Criteria.where(FIELD_APPROVAL_STATUS).is(approvalStatus));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public Page<T> findDistinctByOrganizationName(String searchText, Pageable pageable, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_NAME).regex(searchText, "i")); // case-insensitive search
        query.with(pageable);

        // Get the distinct organization names
        List<T> organizations = mongoTemplate.findDistinct(query, FIELD_NAME, collectionName, // specify your collection name here
                entityClass, entityClass);

        // Get the total count of distinct organization names
        long total = mongoTemplate.count(query, entityClass, collectionName);

        return new PageImpl<>(organizations, pageable, total);
    }

    @Override
    public List<T> findByFieldDistinct(Query query, String fieldName, Class<T> entityClass, String collectionName) {
        return mongoTemplate.findDistinct(query, fieldName, collectionName, entityClass);
    }

    @Override
    public List<String> findByFieldDistinct(Query query, String fieldName, String collectionName) {
        return mongoTemplate.findDistinct(query, fieldName, collectionName, String.class);
    }

    @Override
    public List<T> findByHonIn(List<String> honIds, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).in(honIds));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByHonIdsWithProjection(List<String> honIds, String[] projectionOperation, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).in(honIds));
        query.fields().include(projectionOperation);
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByStatusAndOrganizationNameAndCountryAndStateAndCity(String organizationName, String organizationType, String status, String country, String state, String city, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_STATUS).is(status)
                .and(FIELD_NAME).is(organizationName)
                .and(FIELD_COUNTRY).is(country)
                .and(FIELD_STATE).is(state)
                .and(FIELD_CITY).is(city));

        // Specify the fields to be returned
        query.fields().include(FIELD_HON).include(FIELD_NAME).include(FIELD_ALIAS).include(FIELD_TYPE).include(FIELD_USED_COUNT).include(FIELD_ADDESS_LINE).include(FIELD_OUT_OF_BUSINESS).include(FIELD_REVIEW_REQUIRED).include(FIELD_STATUS).include(FIELD_CITY).include(FIELD_STATE).include(FIELD_COUNTRY).include(FIELD_LAST_CLEAN_UP_DATE).include(FIELD_DEPT_NAME).include(FIELD_DEPT_ALIAS);

        // Set the collation to en_US with strength 2 for case-insensitive and accent-insensitive search
        Collation collation = Collation.of(COLLATION_LANG).strength(Collation.ComparisonLevel.secondary());
        query.collation(collation).withHint(UNIQUE_ORG_INDEX);
        // Execute the query
        return mongoTemplate.find(query, entityClass, collectionName);

    }

    @Override
    public List<T> findByHonOrderByVersionDesc(String hon, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        query.with(Sort.by(Sort.Direction.DESC, FIELD_VERSION));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByHonAndApprovalStatusOrderByVersionDesc(String hon, ApprovalStatus approvalStatus, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon)
                .and(FIELD_APPROVAL_STATUS).is(approvalStatus));
        query.with(Sort.by(Sort.Direction.DESC, FIELD_VERSION));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByRequesterIdAndLastModifiedDateBetween(String requestedBy, Instant startTime, Instant endTime, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_REQUESTED_BY).is(requestedBy)
                .and(FIELD_LAST_MODIFIED_DATE).gte(startTime).lte(endTime));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByHonAndApprovalStatusAndVersionLessThanOrderByVersionDesc(String hon, ApprovalStatus approvalStatus, Double version, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon)
                // .and(FIELD_APPROVAL_STATUS).is(approvalStatus)
                .and(FIELD_VERSION).lt(version));
        query.with(Sort.by(Sort.Direction.DESC, FIELD_VERSION));

        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByHonAndApprovalStatusAndVersionInOrderByVersionDesc(String hon, ApprovalStatus approvalStatus, Double[] versions, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon)
                .and(FIELD_VERSION).in(versions)
                .and(FIELD_APPROVAL_STATUS).is(approvalStatus));
        query.with(Sort.by(Sort.Direction.DESC, FIELD_VERSION));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByHonAndVersionInOrderByVersionDesc(String hon, Double[] versions, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon)
                .and(FIELD_VERSION).in(versions));
        query.with(Sort.by(Sort.Direction.DESC, FIELD_VERSION));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByHonAndVersion(String hon, Double version, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon)
                .and(FIELD_VERSION).is(version));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public T findOneByHonAndVersion(String hon, Double version, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon)
                .and(FIELD_VERSION).is(version));
        return mongoTemplate.findOne(query, entityClass, collectionName);
    }

    @Override
    public T UpdateDateOnIncrementByHon(String hon, String lastUsedDate, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(HON).is(hon).and(STATUS).is(SourceOrganizationStatus.ACTIVE.getStatus()));
        Update update = new Update().set(PAYLOAD_LAST_USED_DATE, lastUsedDate).inc(PAYLOAD_USED_COUNT, 1);
        return mongoTemplate.findAndModify(query, update, entityClass, collectionName);
    }

    @Override
    public long getSourceCountByStatuses(List<ApprovalStatus> statuses, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_APPROVAL_STATUS).in(statuses));
        return mongoTemplate.count(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByStatuses(List<ApprovalStatus> statuses, int page, int size, Class<T> entityClass, String collectionName) {
        query = new Query();
        Pageable pageable = new OffsetBasedPageRequest(page - 1, size);
        query.with(pageable);
        query.addCriteria(Criteria.where(FIELD_APPROVAL_STATUS).in(statuses));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByQuery(Query query, Class<T> entityClass, String collectionName) {
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByHonAndVersionOrderByLastModifiedDateDesc(String hon,  Double version, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        query.addCriteria(Criteria.where(FIELD_VERSION).is(version));
        query.with(Sort.by(Sort.Direction.DESC, FIELD_LAST_ACTION_DATE));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> getHistoryByHonAndVersion(String hon,  Double version, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        query.addCriteria(Criteria.where(FIELD_VERSION).is(version));
        query.addCriteria(Criteria.where(APPROVAL_STATUS).ne(ApprovalStatus.APPROVED.getStatus()));
        query.addCriteria(Criteria.where(STATUS).is(SourceOrganizationStatus.INACTIVE.getStatus()));
        query.with(Sort.by(Sort.Direction.DESC, FIELD_LAST_ACTION_DATE));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByHonOrderByLastModifiedDateDesc(String hon, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        query.with(Sort.by(Sort.Direction.DESC, FIELD_LAST_ACTION_DATE));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public T create(T entityObj, Class<T> entityClass, String collectionName) {
        T res = mongoTemplate.save(entityObj, collectionName);
        log.info("Inserted successfully {}", collectionName);
        return res;
    }

    @Override
    public Boolean update(String queryField, String fieldValue, T entityObj, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(queryField).is(fieldValue));
        Object result = mongoTemplate.findAndReplace(query, entityObj, collectionName);
        return result != null;
    }

    @Override
    public Boolean patch(String queryField, String fieldValue, Update update, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(queryField).is(fieldValue));
        UpdateResult res = mongoTemplate.upsert(query, update, collectionName);
        log.info("patch successfully {} in collection:{}", res.getModifiedCount(), collectionName);
        return res.getMatchedCount() > 0;
    }

    @Override
    public T findById(Object id, Class<T> entityClass, String collectionName) {
        return mongoTemplate.findById(id, entityClass, collectionName);
    }

    @Override
    public T findByOne(String queryField, String fieldValue, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(queryField).is(fieldValue));
        return mongoTemplate.findOne(query, entityClass, collectionName);
    }

    @Override
    public List<T> findByField(String fieldName, String fieldValue, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(fieldName).is(fieldValue));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public List<T> aggregate(Aggregation aggregation, String collectionName, Class<T> responseClass) {
        try {
            AggregationResults<T> results = mongoTemplate.aggregate(aggregation, collectionName, responseClass);
            return results.getMappedResults();
        } catch (Exception e) {
            logAndThrowInvalidRequest(INVALID_INPUT, e);
        }
        return Collections.emptyList();
    }

    @Override
    public long queryCount(Query query, String collectionName, Class<T> responseClass) {
        try {
            return mongoTemplate.count(query, responseClass, collectionName);
        } catch (Exception e) {
            logAndThrowInvalidRequest(INVALID_INPUT, e);
        }
        return 0;
    }

    @Override
    public T findOneByHonAndApprovalStatus(String hon, String approvalStatus, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon).and(FIELD_APPROVAL_STATUS).is(approvalStatus));
        return mongoTemplate.findOne(query, entityClass, collectionName);
    }

    @Override
    public T findOneByHonAndApprovalStatuses(String hon, List<String> approvalStatus, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        query.addCriteria(Criteria.where(FIELD_APPROVAL_STATUS).in(approvalStatus));
        var result = mongoTemplate.find(query, entityClass, collectionName);
        return result.getFirst();
    }

    @Override
    public List<T> findByHonAndApprovalStatuses(String hon, List<String> approvalStatus, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        query.addCriteria(Criteria.where(FIELD_APPROVAL_STATUS).in(approvalStatus));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public T findSourceByHonOrderByLastModifiedBy(String hon, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon));
        query.addCriteria(Criteria.where(FIELD_APPROVAL_STATUS).in(ApprovalStatus.APPROVED, ApprovalStatus.SAVE_PENDING_APPROVAL, ApprovalStatus.PENDING_APPROVAL));
        query.with(Sort.by(Sort.Direction.DESC, FIELD_LAST_MODIFIED_DATE));
        var result = mongoTemplate.find(query, entityClass, collectionName);
        if(result.isEmpty()){
            return null;
        }
        return result.getFirst();
    }

    @Override
    public Boolean updateByQuery(Query query, T entityObj, Class<T> entityClass, String collectionName) {
        Object result = mongoTemplate.findAndReplace(query, entityObj, collectionName);
        return result != null;
    }

    @Override
    public Boolean updateFieldsByQuery(Query query, Update update, Class<T> entityClass, String collectionName) {
        var result = mongoTemplate.updateMulti(query, update, entityClass, collectionName);
        return result.getModifiedCount() > 0;
    }

    @Override
    public long deleteByQuery(Query query, Class<T> entityClass, String collectionName) {
        var res = mongoTemplate.remove(query, collectionName);
        return res.getDeletedCount();
    }

    @Override
    public long deleteById(ObjectId id, Class<T> entityClass, String collectionName) {
        Query deleteQuery = new Query().addCriteria(Criteria.where("_id").is(id));
        var source = mongoTemplate.find(deleteQuery, entityClass, collectionName);
        log.info("source:{}", source);
        var res = mongoTemplate.remove(deleteQuery, collectionName);
        log.info("Deleted successfully: {},id: {},count: {}", collectionName, id, res.getDeletedCount());
        return res.getDeletedCount();

    }

    @Override
    public long delete(T entityObj, Class<T> entityClass, String collectionName) {
        var res = mongoTemplate.remove(entityObj, collectionName);
        log.info("Deleted successfully: {}", collectionName);
        return res.getDeletedCount();
    }

    @Override
    public MongoSearchResult customAggregate(Aggregation aggregation, String collectionName, Class<MongoSearchResult> mongoSearchResultClass) {
        try {
            AggregationResults<MongoSearchResult> results = mongoTemplate.aggregate(aggregation, collectionName, mongoSearchResultClass);
            return results.getMappedResults().getFirst();
        } catch (Exception e) {
            logAndThrowInvalidRequest(INVALID_INPUT, e);
        }
        return null;
    }

    @Override
    public ReportSearchResult reportCustomAggregate(Aggregation aggregation, String collectionName, Class<ReportSearchResult> reportSearchResultClass) {
        try {
            AggregationResults<ReportSearchResult> results = mongoTemplate.aggregate(aggregation, collectionName, reportSearchResultClass);
            return results.getMappedResults().getFirst();
        } catch (Exception e) {
            logAndThrowInvalidRequest(INVALID_INPUT, e);
        }
        return null;
    }

    @Override
    public List<T> findByHonAndVersionAndApprovalStatus(String hon, double version, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where(FIELD_HON).is(hon)
                .and(FIELD_VERSION).is(version)
                .and(APPROVAL_STATUS).is(ApprovalStatus.APPROVED));
        query.with(Sort.by(Sort.Direction.DESC, FIELD_LAST_ACTION_DATE));
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public Document aggregateDocument(Aggregation aggregation, String collectionName) {
        AggregationResults<Document> results = mongoTemplate.aggregate(aggregation, collectionName, Document.class);
        return results.getRawResults();
    }

    @Override
    public long findCountByQuery(Query query, Class<T> entityClass, String collectionName) {
        return mongoTemplate.count(query, entityClass, collectionName);
    }

    @Override
    public List<String> getHonIdsByQuery(Query query, String collectionName) {
        return mongoTemplate.findDistinct(query, "hon", collectionName, String.class);
    }

    @Override
    public List<T> getChildSourcesByHon(List<String> honIds, SourceOrganizationStatus status, Class<T> entityClass, String collectionName) {
        query = new Query();
        query.addCriteria(Criteria.where("payload.relationships.HON").in(honIds));
        query.addCriteria(Criteria.where("payload.relationships.relationship").in("CHILD"));
        query.addCriteria(Criteria.where(STATUS).in(status.getStatus()));

        query.fields().include(FIELD_HON).include(FIELD_NAME).include(FIELD_TYPE).include(FIELD_ALIAS).include(FIELD_USED_COUNT).include(FIELD_ADDESS_LINE).include(FIELD_DEPT_NAME).include(FIELD_DEPT_ALIAS).include(FIELD_STATUS).include(FIELD_CITY).include(FIELD_STATE).include(FIELD_COUNTRY);
        return mongoTemplate.find(query, entityClass, collectionName);
    }

    @Override
    public void assignApproverToSource(Query query, String approverName, String approverEmail, String collectionName) {

        Update update = new Update();
        if (approverName != null && !approverName.isEmpty()) {
            update.set("assignedTo", approverName);
        }
        if (approverEmail != null && !approverEmail.isEmpty()) {
            update.set("assignedId", approverEmail);
        }

        mongoTemplate.updateMulti(query, update, collectionName);
    }

}
