package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.Permissions;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PermissionsRepositary extends MongoRepository<Permissions, String> {

    Permissions findByUserNameAndStatus(String userName, String status);
}
