package com.hireright.sourceintelligence.domain.repository;

import com.hireright.sourceintelligence.domain.entity.RegionThreshold;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RegionThresholdRepository extends MongoRepository<RegionThreshold, String> {

    RegionThreshold findByThresholdType(String thresholdType);
}
