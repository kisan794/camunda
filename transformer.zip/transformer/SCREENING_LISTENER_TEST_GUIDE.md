# Screening Request Listener Test Guide

This guide explains how to test the `ScreeningRequestListener` without requiring RabbitMQ to be running.

## Overview

The `ScreeningTestController` provides REST endpoints that directly call the `handleScreeningRequest()` method, simulating RabbitMQ message processing.

---

## Test Endpoints

### 1. Health Check
```bash
GET http://localhost:8080/api/test/screening/health
```

**Response:**
```json
{
  "status": "UP",
  "service": "ScreeningTestController",
  "message": "Test controller is ready"
}
```

---

### 2. Simple Test (Path Parameter)
```bash
POST http://localhost:8080/api/test/screening/process/{screeningId}?correlationId={correlationId}
```

**Example:**
```bash
curl -X POST "http://localhost:8080/api/test/screening/process/NSCH123456?correlationId=test-123"
```

**Response:**
```json
{
  "screeningId": "NSCH123456",
  "correlationId": "test-123",
  "status": "SUCCESS",
  "message": "Screening request processed successfully"
}
```

---

### 3. Full JSON Payload Test
```bash
POST http://localhost:8080/api/test/screening/process
Content-Type: application/json
X-Correlation-ID: {correlationId}  (optional header)

{
  "id": "TALK789012"
}
```

**Example:**
```bash
curl -X POST "http://localhost:8080/api/test/screening/process" \
  -H "Content-Type: application/json" \
  -H "X-Correlation-ID: header-correlation-123" \
  -d '{"id": "TALK789012"}'
```

**Response:**
```json
{
  "screeningId": "TALK789012",
  "correlationId": "header-correlation-123",
  "status": "SUCCESS",
  "message": "Screening request processed successfully"
}
```

---

## Automated Test Script

Run all tests automatically:

```bash
./test-screening-listener.sh
```

This script will:
1. ✅ Check server health
2. ✅ Test simple request without correlation ID
3. ✅ Test request with correlation ID
4. ✅ Test full JSON payload with correlation ID in body
5. ✅ Test full JSON payload with correlation ID in header
6. ✅ Test expected failure scenario

---

## Correlation ID Priority

The listener extracts correlation ID in this order:

1. **Message Header** (`@Header("correlationId")`) - Highest priority
2. **Request Body** (`request.getCorrelationId()`) - Fallback
3. **Generated** - If neither exists, generates new UUID

---

## Testing Scenarios

### Scenario 1: Test with Correlation ID from Header
```bash
curl -X POST "http://localhost:8080/api/test/screening/process/NSCH123456?correlationId=my-correlation-id"
```

**Expected:**
- Correlation ID `my-correlation-id` is used
- Logs show: `Using correlation ID from message header: my-correlation-id`

---

### Scenario 2: Test without Correlation ID
```bash
curl -X POST "http://localhost:8080/api/test/screening/process/NSCH123456"
```

**Expected:**
- New correlation ID is generated (UUID format)
- Logs show: `Generated new correlation ID: <uuid>`

---

### Scenario 3: Test Full Flow with Debugging

1. **Set breakpoint** in `ScreeningRequestListener.handleScreeningRequest()` at line 40
2. **Start application in debug mode**
3. **Call endpoint:**
   ```bash
   curl -X POST "http://localhost:8080/api/test/screening/process/NSCH123456?correlationId=debug-test-123"
   ```
4. **Observe:**
   - Breakpoint hits
   - `correlationId` parameter = `"debug-test-123"`
   - `CorrelationIdHolder.get()` returns `"debug-test-123"`
   - MDC contains correlation ID for logging

---

## Viewing Logs

Check the application logs to see correlation ID tracking:

```bash
tail -f logs/recombo-integration.log | grep "debug-test-123"
```

**Expected log entries:**
```
2025-11-12 12:00:00.123 [http-nio-8080-exec-1] [debug-test-123] INFO  o.e.r.l.ScreeningRequestListener - Received screening request from queue - ID: NSCH123456, CorrelationID: debug-test-123
2025-11-12 12:00:00.456 [http-nio-8080-exec-1] [debug-test-123] INFO  o.e.r.s.ScreeningProcessorService - Processing screening request - ID: NSCH123456
2025-11-12 12:00:01.789 [http-nio-8080-exec-1] [debug-test-123] INFO  o.e.r.l.ScreeningRequestListener - Successfully processed screening request - ID: NSCH123456, CorrelationID: debug-test-123
```

---

## What Gets Tested

When you call the test endpoint, it simulates the full RabbitMQ flow:

1. ✅ **Correlation ID extraction** from header
2. ✅ **MDC setup** with correlation ID
3. ✅ **Listener method** (`handleScreeningRequest`)
4. ✅ **Service call** (`ScreeningProcessorService.processScreeningRequest`)
5. ✅ **Vendor API call** (HTTP GET to vendor API)
6. ✅ **Response processing** (transform HRG + XML)
7. ✅ **Third-party API call** (HTTP POST to Recombo 360)
8. ✅ **MDC cleanup** in finally block

---

## Expected Failures

The test will fail if:
- ❌ Vendor API is not accessible
- ❌ Vendor API returns non-200 status
- ❌ Response parsing fails
- ❌ Transformation fails
- ❌ Recombo 360 API call fails

**Example failure response:**
```json
{
  "screeningId": "INVALID_ID",
  "correlationId": "test-123",
  "status": "FAILED",
  "message": "Processing failed: Failed to fetch vendor data: HTTP 404",
  "error": "HttpClientException"
}
```

---

## Swagger UI

Access interactive API documentation:

```
http://localhost:8080/swagger-ui.html
```

Navigate to **"Screening Test"** section to test endpoints interactively.

---

## Comparison: RabbitMQ vs REST Test

| Aspect | RabbitMQ Flow | REST Test Flow |
|--------|---------------|----------------|
| **Trigger** | Message published to queue | HTTP POST to test endpoint |
| **Correlation ID** | From message header | From query param or header |
| **Listener Method** | `@RabbitListener` invoked | Direct method call |
| **Processing** | Same | Same |
| **Error Handling** | Message sent to DLQ | HTTP 500 response |
| **Requires RabbitMQ** | ✅ Yes | ❌ No |

---

## Quick Commands

```bash
# Health check
curl http://localhost:8080/api/test/screening/health

# Simple test
curl -X POST "http://localhost:8080/api/test/screening/process/NSCH123456?correlationId=test-123"

# Full test with JSON
curl -X POST "http://localhost:8080/api/test/screening/process" \
  -H "Content-Type: application/json" \
  -H "X-Correlation-ID: my-correlation-id" \
  -d '{"id": "TALK789012"}'

# Run automated tests
./test-screening-listener.sh

# Watch logs
tail -f logs/recombo-integration.log
```

---

## Troubleshooting

### Issue: "Connection refused" in logs
**Cause:** Vendor API or Recombo 360 API is not accessible  
**Solution:** This is expected in test environment. Check logs for correlation ID tracking.

### Issue: "Failed to fetch vendor data"
**Cause:** Vendor API returned non-200 status  
**Solution:** Verify vendor API URL in `application.properties`

### Issue: Correlation ID not in logs
**Cause:** MDC not properly configured  
**Solution:** Check `CorrelationIdHolder` is setting MDC correctly

---

## Summary

✅ **Created:** `ScreeningTestController` - REST endpoints for testing  
✅ **Created:** `test-screening-listener.sh` - Automated test script  
✅ **Feature:** Test listener without RabbitMQ  
✅ **Feature:** Correlation ID tracking verification  
✅ **Feature:** Full flow simulation  

**Next Steps:**
1. Start the application
2. Run `./test-screening-listener.sh`
3. Check logs for correlation ID tracking
4. Use Swagger UI for interactive testing

