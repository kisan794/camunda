#!/bin/bash

# Test script for ScreeningRequestListener via REST API
# This script tests the screening request processing without requiring RabbitMQ

BASE_URL="http://localhost:8080/api/test/screening"

echo "=========================================="
echo "Screening Request Listener Test Script"
echo "=========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print test header
print_test() {
    echo ""
    echo -e "${YELLOW}TEST $1: $2${NC}"
    echo "----------------------------------------"
}

# Function to print success
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

# Function to print error
print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Check if server is running
print_test "0" "Health Check"
response=$(curl -s -w "\n%{http_code}" "$BASE_URL/health")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | sed '$d')

if [ "$http_code" -eq 200 ]; then
    print_success "Server is running"
    echo "$body" | jq '.'
else
    print_error "Server is not running or not accessible"
    echo "HTTP Status: $http_code"
    exit 1
fi

# Test 1: Simple screening request with path parameter (no correlation ID)
print_test "1" "Simple Request - No Correlation ID"
echo "Request: POST $BASE_URL/process/NSCH123456"
response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/process/NSCH123456")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | sed '$d')

echo "HTTP Status: $http_code"
echo "$body" | jq '.'

if [ "$http_code" -eq 200 ]; then
    print_success "Request processed successfully"
else
    print_error "Request failed"
fi

# Test 2: Screening request with correlation ID
print_test "2" "Request with Correlation ID"
correlation_id="test-correlation-$(date +%s)"
echo "Request: POST $BASE_URL/process/TALK789012?correlationId=$correlation_id"
response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/process/TALK789012?correlationId=$correlation_id")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | sed '$d')

echo "HTTP Status: $http_code"
echo "$body" | jq '.'

if [ "$http_code" -eq 200 ]; then
    print_success "Request with correlation ID processed successfully"
else
    print_error "Request failed"
fi

# Test 3: Full JSON payload with correlation ID in body
print_test "3" "Full JSON Payload - Correlation ID in Body"
json_payload='{
  "id": "NSCH999888",
  "timestamp": '$(date +%s000)',
  "correlationId": "json-body-correlation-'$(date +%s)'"
}'

echo "Request: POST $BASE_URL/process"
echo "Payload: $json_payload" | jq '.'
response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/process" \
    -H "Content-Type: application/json" \
    -d "$json_payload")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | sed '$d')

echo "HTTP Status: $http_code"
echo "$body" | jq '.'

if [ "$http_code" -eq 200 ]; then
    print_success "JSON payload request processed successfully"
else
    print_error "Request failed"
fi

# Test 4: Full JSON payload with correlation ID in header
print_test "4" "Full JSON Payload - Correlation ID in Header"
header_correlation_id="header-correlation-$(date +%s)"
json_payload='{
  "id": "TALK555444",
  "timestamp": '$(date +%s000)'
}'

echo "Request: POST $BASE_URL/process"
echo "Header: X-Correlation-ID: $header_correlation_id"
echo "Payload: $json_payload" | jq '.'
response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/process" \
    -H "Content-Type: application/json" \
    -H "X-Correlation-ID: $header_correlation_id" \
    -d "$json_payload")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | sed '$d')

echo "HTTP Status: $http_code"
echo "$body" | jq '.'

if [ "$http_code" -eq 200 ]; then
    print_success "Header correlation ID request processed successfully"
else
    print_error "Request failed"
fi

# Test 5: Request that will fail (invalid vendor URL)
print_test "5" "Expected Failure Test - Invalid Screening ID"
echo "Request: POST $BASE_URL/process/INVALID_ID_12345"
echo "Note: This should fail when calling vendor API"
response=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/process/INVALID_ID_12345?correlationId=fail-test-$(date +%s)")
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | sed '$d')

echo "HTTP Status: $http_code"
echo "$body" | jq '.'

if [ "$http_code" -eq 500 ]; then
    print_success "Expected failure occurred (vendor API call failed)"
else
    print_error "Unexpected response"
fi

echo ""
echo "=========================================="
echo "Test Summary"
echo "=========================================="
echo "All tests completed!"
echo ""
echo "To view logs, check:"
echo "  - Application logs: logs/recombo-integration.log"
echo "  - Look for correlation IDs in the logs"
echo ""
echo "To test manually:"
echo "  curl -X POST \"$BASE_URL/process/NSCH123456?correlationId=my-test-id\""
echo ""

