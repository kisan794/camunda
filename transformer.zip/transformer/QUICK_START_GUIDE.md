# HTTP/2 Client - Quick Start Guide

## 🚀 5-Minute Quick Start

### Option 1: Spring Application (Easiest)

**Step 1:** Add configuration to `application.properties`
```properties
http.client.jwt.enabled=true
http.client.jwt.secret-key=your-secret-key-here
http.client.retry.enabled=true
```

**Step 2:** Inject and use
```java
@Service
public class MyService {
    @Autowired
    private Http2ClientService httpClient;
    
    public void callApi() {
        HttpResponse<String> response = httpClient.get("https://api.example.com/data");
        System.out.println(response.body());
    }
}
```

### Option 2: Standalone Application

```java
// Create client
Http2Client client = Http2Client.builder()
    .jwtConfig(new JwtConfig().setSecretKey("your-secret-key"))
    .retryConfig(new RetryConfig().setMaxAttempts(3))
    .build();

// Use it
HttpResponse<String> response = client.get("https://api.example.com/data");
```

## 📋 Common Operations

### GET Request
```java
// Simple GET
HttpResponse<String> response = client.get("https://api.example.com/users");

// GET with headers
Map<String, String> headers = Map.of("X-API-Key", "key123");
HttpResponse<String> response = client.get("https://api.example.com/users", headers);
```

### POST Request
```java
String jsonBody = "{\"name\":\"John\",\"email\":\"john@example.com\"}";
HttpResponse<String> response = client.post("https://api.example.com/users", jsonBody);
```

### PUT Request
```java
String jsonBody = "{\"name\":\"John Updated\"}";
HttpResponse<String> response = client.put("https://api.example.com/users/123", jsonBody);
```

### DELETE Request
```java
HttpResponse<String> response = client.delete("https://api.example.com/users/123");
```

### Async Request
```java
client.getAsync("https://api.example.com/users")
    .thenAccept(response -> System.out.println(response.body()))
    .exceptionally(error -> {
        System.err.println("Error: " + error.getMessage());
        return null;
    });
```

## ⚙️ Configuration Options

### Basic Configuration
```java
Http2Client client = Http2Client.builder()
    .connectTimeout(Duration.ofSeconds(10))
    .requestTimeout(Duration.ofSeconds(30))
    .build();
```

### With JWT Authentication
```java
JwtConfig jwtConfig = new JwtConfig()
    .setSecretKey("your-256-bit-secret-key")
    .setIssuer("my-service")
    .setExpirationTime(Duration.ofHours(1));

Http2Client client = Http2Client.builder()
    .jwtConfig(jwtConfig)
    .build();
```

### With Retry Logic
```java
RetryConfig retryConfig = new RetryConfig()
    .setMaxAttempts(5)
    .setInitialDelay(Duration.ofMillis(500))
    .setBackoffMultiplier(2.0);

Http2Client client = Http2Client.builder()
    .retryConfig(retryConfig)
    .build();
```

### Full Configuration
```java
Http2Client client = Http2Client.builder()
    .connectTimeout(Duration.ofSeconds(10))
    .requestTimeout(Duration.ofSeconds(30))
    .jwtConfig(new JwtConfig()
        .setSecretKey("your-secret-key")
        .setIssuer("my-service"))
    .retryConfig(new RetryConfig()
        .setMaxAttempts(3))
    .build();
```

## 🔐 JWT Authentication

### Enable JWT in Spring
```properties
http.client.jwt.enabled=true
http.client.jwt.secret-key=your-256-bit-secret-key-must-be-at-least-32-characters
http.client.jwt.issuer=my-microservice
http.client.jwt.subject=api-client
http.client.jwt.expiration-hours=1
```

### Enable JWT Programmatically
```java
JwtConfig jwtConfig = new JwtConfig()
    .setSecretKey("your-secret-key")
    .setIssuer("my-service")
    .setSubject("api-client")
    .setExpirationTime(Duration.ofHours(1));

Http2Client client = Http2Client.builder()
    .jwtConfig(jwtConfig)
    .build();

// All requests will automatically include: Authorization: Bearer <jwt-token>
```

## 🔄 Retry Configuration

### Default Retry Behavior
- Max attempts: 3
- Initial delay: 500ms
- Backoff multiplier: 2.0
- Retryable status codes: 408, 429, 500, 502, 503, 504

### Custom Retry Configuration
```java
RetryConfig retryConfig = new RetryConfig()
    .setMaxAttempts(5)                          // Try up to 5 times
    .setInitialDelay(Duration.ofMillis(500))    // Start with 500ms
    .setMaxDelay(Duration.ofSeconds(10))        // Cap at 10 seconds
    .setBackoffMultiplier(2.0)                  // Double each time
    .setRetryableStatusCodes(Set.of(408, 429, 500, 502, 503, 504));
```

### Retry Timeline Example
```
Attempt 1: Immediate
Attempt 2: After 500ms
Attempt 3: After 1000ms (1s)
Attempt 4: After 2000ms (2s)
Attempt 5: After 4000ms (4s)
```

## 🎯 Async Operations

### Single Async Request
```java
CompletableFuture<HttpResponse<String>> future = 
    client.getAsync("https://api.example.com/users");

future.thenAccept(response -> {
    System.out.println("Status: " + response.statusCode());
    System.out.println("Body: " + response.body());
});
```

### Multiple Parallel Requests
```java
CompletableFuture<HttpResponse<String>> req1 = client.getAsync("https://api.example.com/users/1");
CompletableFuture<HttpResponse<String>> req2 = client.getAsync("https://api.example.com/users/2");
CompletableFuture<HttpResponse<String>> req3 = client.getAsync("https://api.example.com/users/3");

CompletableFuture.allOf(req1, req2, req3)
    .thenRun(() -> System.out.println("All requests completed"));
```

### Chaining Requests
```java
client.getAsync("https://api.example.com/users/1")
    .thenCompose(userResponse -> {
        String userId = extractUserId(userResponse.body());
        return client.getAsync("https://api.example.com/orders?userId=" + userId);
    })
    .thenAccept(ordersResponse -> {
        System.out.println("Orders: " + ordersResponse.body());
    });
```

## ⚠️ Error Handling

### Basic Error Handling
```java
try {
    HttpResponse<String> response = client.get("https://api.example.com/data");
    
    if (response.statusCode() == 200) {
        System.out.println("Success: " + response.body());
    } else {
        System.err.println("Error status: " + response.statusCode());
    }
    
} catch (HttpClientException e) {
    System.err.println("Request failed: " + e.getMessage());
}
```

### Comprehensive Error Handling
```java
try {
    HttpResponse<String> response = client.get("https://api.example.com/data");
    // Process response
    
} catch (HttpRetryExhaustedException e) {
    System.err.println("All retry attempts failed");
    System.err.println("Attempts: " + e.getAttemptsMade());
    
} catch (JwtAuthenticationException e) {
    System.err.println("JWT auth failed: " + e.getMessage());
    
} catch (HttpClientException e) {
    System.err.println("HTTP error: " + e.getMessage());
    System.err.println("Error code: " + e.getErrorCode());
}
```

### Async Error Handling
```java
client.getAsync("https://api.example.com/data")
    .thenAccept(response -> {
        // Success
        System.out.println(response.body());
    })
    .exceptionally(throwable -> {
        // Error
        System.err.println("Request failed: " + throwable.getMessage());
        return null;
    });
```

## 📊 Response Handling

### Check Status Code
```java
HttpResponse<String> response = client.get("https://api.example.com/users");

if (response.statusCode() == 200) {
    System.out.println("Success");
} else if (response.statusCode() == 404) {
    System.out.println("Not found");
} else if (response.statusCode() >= 500) {
    System.out.println("Server error");
}
```

### Access Headers
```java
HttpResponse<String> response = client.get("https://api.example.com/users");

response.headers().map().forEach((key, values) -> {
    System.out.println(key + ": " + values);
});

String contentType = response.headers().firstValue("Content-Type").orElse("unknown");
```

### Get Response Body
```java
HttpResponse<String> response = client.get("https://api.example.com/users");
String body = response.body();

// Parse JSON (using Jackson or similar)
ObjectMapper mapper = new ObjectMapper();
User user = mapper.readValue(body, User.class);
```

## 🎓 Best Practices

1. **Reuse Client Instances**
   ```java
   // Good: Create once, reuse many times
   private final Http2Client client = Http2Client.builder().build();
   
   // Bad: Creating new client for each request
   Http2Client client = Http2Client.builder().build(); // Don't do this repeatedly
   ```

2. **Use Async for I/O-Bound Operations**
   ```java
   // Good for multiple requests
   CompletableFuture.allOf(
       client.getAsync(url1),
       client.getAsync(url2),
       client.getAsync(url3)
   ).join();
   ```

3. **Set Appropriate Timeouts**
   ```java
   Http2Client client = Http2Client.builder()
       .connectTimeout(Duration.ofSeconds(10))
       .requestTimeout(Duration.ofSeconds(30))
       .build();
   ```

4. **Secure JWT Keys**
   ```properties
   # Use environment variables
   http.client.jwt.secret-key=${JWT_SECRET_KEY}
   ```

5. **Handle Errors Gracefully**
   ```java
   try {
       HttpResponse<String> response = client.get(url);
       // Always check status code
       if (response.statusCode() >= 400) {
           // Handle error
       }
   } catch (HttpClientException e) {
       // Handle exception
   }
   ```

## 📚 Additional Resources

- Full Documentation: `src/main/java/org/example/recombointegration/http/README.md`
- Examples: `src/main/java/org/example/recombointegration/http/example/Http2ClientExample.java`
- Summary: `HTTP2_CLIENT_SUMMARY.md`

## 🆘 Common Issues

### Issue: JWT Secret Key Too Short
```
Error: JWT secret key must be at least 256 bits (32 characters)
Solution: Use a longer secret key (at least 32 characters)
```

### Issue: Connection Timeout
```
Solution: Increase connect timeout
client.builder().connectTimeout(Duration.ofSeconds(30))
```

### Issue: Request Timeout
```
Solution: Increase request timeout
client.builder().requestTimeout(Duration.ofSeconds(60))
```

---

**Ready to use!** Start with the Spring Service approach for the easiest integration.

