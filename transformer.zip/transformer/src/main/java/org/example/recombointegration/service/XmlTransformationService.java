package org.example.recombointegration.service;

import org.example.recombointegration.exception.XmlTransformationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Service for orchestrating XML transformation operations.
 * Coordinates validation and conversion of XML to JSON.
 *
 * @author Keshav Ladha
 */
@Service
public class XmlTransformationService {

    private static final Logger logger = LoggerFactory.getLogger(XmlTransformationService.class);

    private final XmlValidator xmlValidator;
    private final XmlConverterFactory converterFactory;

    /**
     * Constructor with dependency injection.
     *
     * @param xmlValidator     the XML validator
     * @param converterFactory the converter factory
     */
    public XmlTransformationService(XmlValidator xmlValidator, XmlConverterFactory converterFactory) {
        this.xmlValidator = xmlValidator;
        this.converterFactory = converterFactory;
        logger.info("XmlTransformationService initialized with validator: {} and factory with {} converter types",
                xmlValidator.getClass().getSimpleName(),
                converterFactory.getSupportedTypes().length);
    }

    /**
     * Transforms XML to JSON with validation using specified type.
     *
     * @param xml  the XML content to transform
     * @param type the screening type (education, employment, etc.)
     * @return the JSON representation
     * @throws XmlTransformationException if transformation fails
     */
    public String transformXmlToJson(String xml, String type) {
        logger.debug("Starting XML to JSON transformation for type: {}", type);

        try {

            // Validate XML
            xmlValidator.validateOrThrow(xml);

            logger.debug("XML validation successful, proceeding with conversion");

            // Get the appropriate converter based on type
            XmlToJsonConverter converter = converterFactory.getConverter(type);

            logger.debug("Using converter: {}", converter.getClass().getSimpleName());

            // Convert to JSON
            String json = converter.convert(xml);

            logger.info("XML to JSON transformation completed successfully (type: {}, output length: {} characters)",
                    type, json != null ? json.length() : 0);

            return json;

        } catch (XmlTransformationException e) {
            throw e;
        } catch (Exception e) {
            throw new XmlTransformationException(
                    "TRANSFORMATION_FAILED",
                    "Failed to transform XML to JSON: " + e.getMessage(),
                    e);
        }
    }
}