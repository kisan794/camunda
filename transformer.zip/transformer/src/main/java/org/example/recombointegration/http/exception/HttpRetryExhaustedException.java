package org.example.recombointegration.http.exception;

import lombok.Getter;
import org.example.recombointegration.util.Constant;

/**
 * Exception thrown when all retry attempts have been exhausted.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Getter
public class HttpRetryExhaustedException extends HttpClientException {

    private final int attemptsMade;

    /**
     * Constructor with message and attempts made.
     *
     * @param message      the error message
     * @param attemptsMade the number of attempts made
     */
    public HttpRetryExhaustedException(String message, int attemptsMade) {
        super(Constant.ERROR_CODE_RETRY_EXHAUSTED, message, null);
        this.attemptsMade = attemptsMade;
    }

    /**
     * Constructor with message, attempts made, and cause.
     *
     * @param message      the error message
     * @param attemptsMade the number of attempts made
     * @param cause        the cause of the exception
     */
    public HttpRetryExhaustedException(String message, int attemptsMade, Throwable cause) {
        super(Constant.ERROR_CODE_RETRY_EXHAUSTED, message, cause);
        this.attemptsMade = attemptsMade;
    }
}

