package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO for XML transformation.
 * Contains the XML content to be transformed and the type of screening.
 * <p>
 * Supported types:
 * - "education" - Education screening transformation
 * - "employment" - Employment screening transformation
 *
 * @author Keshav Ladha
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request object for XML to JSON transformation")
public class TransformRequest {

    @Schema(
            description = "XML content to be transformed",
            example = "<EducationScreeningList><EducationScreening>...</EducationScreening></EducationScreeningList>"
    )
    @JsonProperty("content")
    private String content;

    @Schema(
            description = "Type of screening (education or employment). Defaults to 'education' if not specified.",
            example = "education"
    )
    @JsonProperty("type")
    private String type;

    @Override
    public String toString() {
        return "TransformRequest{" +
                "type='" + type + "', " +
                "content='" + (content != null ? content.substring(0, Math.min(100, content.length())) + "..." : "null") +
                "'}";
    }
}