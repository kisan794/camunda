package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.io.Serializable;

/**
 * Request DTO for XML transformation.
 * Contains the XML content to be transformed and the type of screening.
 * <p>
 * Supported types:
 * - "education" - Education screening transformation
 * - "employment" - Employment screening transformation
 *
 * @author Keshav Ladha
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransformRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("content")
    private String content;

    @JsonProperty("type")
    private String type;

    @Override
    public String toString() {
        return "TransformRequest{" +
                "type='" + type + "', " +
                "content='" + (content != null ? content.substring(0, Math.min(100, content.length())) + "..." : "null") +
                "'}";
    }
}