package org.example.recombointegration.service;

import org.example.recombointegration.exception.XmlValidationException;

/**
 * Interface for XML validation.
 * Defines contract for validating XML content.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public interface XmlValidator {

    /**
     * Gets the validation error message for the given XML.
     *
     * @param xml the XML content to validate
     * @return the validation error message, or null if valid
     */
    String getValidationError(String xml);

    /**
     * Validates the given XML content and throws exception if invalid.
     *
     * @param xml the XML content to validate
     * @throws XmlValidationException if validation fails
     */
    void validateOrThrow(String xml);
}

