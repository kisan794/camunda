package org.example.recombointegration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot Application for Recombo Integration.
 * Provides XML to JSON transformation services for Screening data.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@SpringBootApplication
public class RecomboIntegrationApplication {

    private static final Logger logger = LoggerFactory.getLogger(RecomboIntegrationApplication.class);

    /**
     * Main method to start the Spring Boot application.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        logger.info("Starting Recombo Integration Application...");

        try {
            SpringApplication.run(RecomboIntegrationApplication.class, args);
            logger.info("Recombo Integration Application started successfully");
        } catch (Exception e) {
            logger.error("Failed to start Recombo Integration Application", e);
            System.exit(1);
        }
    }
}