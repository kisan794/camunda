package org.example.recombointegration.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.dto.VendorResponse;
import org.example.recombointegration.service.ScreeningProcessorService;
import org.example.recombointegration.util.CorrelationIdHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * REST controller for processing screening vendor responses.
 * Accepts VendorResponse directly via REST API and processes it.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@RestController
@RequestMapping("/api/screening")
@RequiredArgsConstructor
public class ScreeningController {

    private final ScreeningProcessorService screeningProcessorService;

    /**
     * Process vendor response endpoint.
     * Accepts VendorResponse containing hrgRequest and encoded XML,
     * transforms the data, and posts to Recombo 360 API.
     * <p>
     * Request Body Example:
     * {
     * "hrgRequest": {
     * "field1": "value1",
     * "field2": "value2"
     * },
     * "attachment": "attachment_info",
     * "requestType": "application/xml",
     * "encode": "PD94bWwgdmVyc2lvbj0iMS4wIj8+..." (base64 encoded XML)
     * }
     *
     * @param screeningId    the screening ID (path variable)
     * @param vendorResponse the vendor response data
     * @return ResponseEntity with processing status
     */
    @PostMapping("/process/{screeningId}")
    public CompletableFuture<ResponseEntity<Map<String, Object>>> processVendorResponse(
            @PathVariable String screeningId,
            @RequestBody VendorResponse vendorResponse) {

        String correlationId = CorrelationIdHolder.getOrGenerate();

        log.info("Received vendor response for processing - ScreeningID: {}, CorrelationID: {}",
                screeningId, correlationId);

        return screeningProcessorService.processVendorResponse(vendorResponse, screeningId)
                .thenApply(v -> {
                    Map<String, Object> response = new HashMap<>();
                    response.put("status", "success");
                    response.put("message", "Vendor response processed successfully");
                    response.put("screeningId", screeningId);
                    response.put("correlationId", correlationId);

                    log.info("Successfully processed vendor response - ScreeningID: {}, CorrelationID: {}",
                            screeningId, correlationId);

                    return ResponseEntity.ok(response);
                })
                .exceptionally(throwable -> {
                    Map<String, Object> errorResponse = new HashMap<>();
                    errorResponse.put("status", "error");
                    errorResponse.put("message", "Failed to process vendor response: " + throwable.getMessage());
                    errorResponse.put("screeningId", screeningId);
                    errorResponse.put("correlationId", correlationId);

                    log.error("Failed to process vendor response - ScreeningID: {}, CorrelationID: {}",
                            screeningId, correlationId, throwable);

                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
                });
    }

}

