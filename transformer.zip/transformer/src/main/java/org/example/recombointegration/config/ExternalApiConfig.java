package org.example.recombointegration.config;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Configuration for vendor API and third-party (Recombo 360) API endpoints.
 * Vendor API: Source system that provides screening data
 * Recombo 360 API: Third-party destination system for processed data
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Getter
@Component
public class ExternalApiConfig {

    // Vendor API (Source)
    @Value("${vendor.api.base-url}")
    private String vendorBaseUrl;

    @Value("${vendor.api.get-endpoint}")
    private String vendorGetEndpoint;

    // Recombo 360 API (Third-party Destination)
    @Value("${recombo360.api.base-url}")
    private String recombo360BaseUrl;

    @Value("${recombo360.api.post-endpoint}")
    private String recombo360PostEndpoint;

    /**
     * Gets the full URL for vendor API GET endpoint.
     *
     * @param screeningId the screening ID to fetch
     * @return full vendor API URL with screening ID
     */
    public String getVendorUrl(String screeningId) {
        return vendorBaseUrl + vendorGetEndpoint.replace("{id}", screeningId);
    }

    /**
     * Gets the full URL for Recombo 360 POST endpoint.
     *
     * @return full Recombo 360 API URL
     */
    public String getRecombo360PostUrl() {
        return recombo360BaseUrl + recombo360PostEndpoint;
    }
}

