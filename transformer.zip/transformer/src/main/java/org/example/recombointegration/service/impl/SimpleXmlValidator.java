package org.example.recombointegration.service.impl;

import org.example.recombointegration.exception.XmlValidationException;
import org.example.recombointegration.service.XmlValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * Simple XML validator implementation.
 * Validates XML content using DOM parser.
 *
 * @author Keshav Ladha
 */
@Service
public class SimpleXmlValidator implements XmlValidator {

    private static final Logger logger = LoggerFactory.getLogger(SimpleXmlValidator.class);

    private final DocumentBuilderFactory documentBuilderFactory;

    /**
     * Constructor initializes DocumentBuilderFactory.
     */
    public SimpleXmlValidator() {
        this.documentBuilderFactory = DocumentBuilderFactory.newInstance();
        this.documentBuilderFactory.setNamespaceAware(true);

        // Security settings to prevent XXE attacks
        try {
            this.documentBuilderFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            this.documentBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            this.documentBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            this.documentBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            this.documentBuilderFactory.setXIncludeAware(false);
            this.documentBuilderFactory.setExpandEntityReferences(false);

            logger.info("SimpleXmlValidator initialized with secure XML parsing settings");
        } catch (ParserConfigurationException e) {
            logger.warn("Could not set all security features for XML parser", e);
        }
    }


    @Override
    public String getValidationError(String xml) {
        logger.debug("Getting validation error for XML");

        if (xml == null || xml.trim().isEmpty()) {
            return "XML content cannot be null or empty";
        }

        try {
            DocumentBuilder builder = documentBuilderFactory.newDocumentBuilder();
            builder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));

            logger.debug("XML is valid, no errors");
            return null;

        } catch (ParserConfigurationException e) {
            String error = "XML parser configuration error: " + e.getMessage();
            logger.debug(error);
            return error;

        } catch (SAXException e) {
            String error = "Invalid XML: " + e.getMessage();
            logger.debug(error);
            return error;

        } catch (IOException e) {
            String error = "Error reading XML: " + e.getMessage();
            logger.debug(error);
            return error;
        }
    }

    @Override
    public void validateOrThrow(String xml) {
        logger.debug("Validating XML and throwing exception if invalid");

        String error = getValidationError(xml);

        if (error != null) {
            logger.error("XML validation failed: {}", error);
            throw new XmlValidationException("XML_INVALID", error, null);
        }

        logger.debug("XML validation successful");
    }
}

