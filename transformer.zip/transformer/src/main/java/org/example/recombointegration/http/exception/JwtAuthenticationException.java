package org.example.recombointegration.http.exception;

/**
 * Exception thrown when JWT authentication fails.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class JwtAuthenticationException extends HttpClientException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructor with message.
     *
     * @param message the error message
     */
    public JwtAuthenticationException(String message) {
        super("JWT_AUTH_ERROR", message, null);
    }

    /**
     * Constructor with message and cause.
     *
     * @param message the error message
     * @param cause   the cause of the exception
     */
    public JwtAuthenticationException(String message, Throwable cause) {
        super("JWT_AUTH_ERROR", message, cause);
    }
}

