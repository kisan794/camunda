package org.example.recombointegration.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * DTO for screening request messages from RabbitMQ.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScreeningRequest  {

    /**
     * Unique screening identifier (e.g., NSCH123456, TALK789012)
     */
    private String id;

}
