package org.example.recombointegration.http.retry;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.http.config.RetryConfig;
import org.example.recombointegration.http.exception.HttpClientException;
import org.example.recombointegration.http.exception.HttpRetryExhaustedException;

import java.io.IOException;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

/**
 * Handler for retry logic with exponential backoff.
 * Retries failed HTTP requests based on configured retry policy.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Getter
@Slf4j
public class RetryHandler {

    /**
     * -- GETTER --
     *  Gets the retry configuration.
     *
     */
    private final RetryConfig config;

    /**
     * Constructor with retry configuration.
     *
     * @param config the retry configuration
     */
    public RetryHandler(RetryConfig config) {
        this.config = config;
        log.info("RetryHandler initialized with max attempts: {}, initial delay: {}ms",
                config.getMaxAttempts(), config.getInitialDelay().toMillis());
    }

    /**
     * Executes a synchronous operation with retry logic.
     *
     * @param operation the operation to execute
     * @param <T>       the response type
     * @return the response
     * @throws HttpRetryExhaustedException if all retry attempts are exhausted
     * @throws HttpClientException         if a non-retryable error occurs
     */
    public <T> HttpResponse<T> executeWithRetry(Supplier<HttpResponse<T>> operation) {
        int attempt = 0;
        Throwable lastException = null;

        while (attempt < config.getMaxAttempts()) {
            attempt++;

            try {
                log.debug("Executing request attempt {}/{}", attempt, config.getMaxAttempts());

                HttpResponse<T> response = operation.get();

                // Check if response status code is retryable
                if (config.isRetryable(response.statusCode())) {
                    log.warn("Received retryable status code {} on attempt {}/{}",
                            response.statusCode(), attempt, config.getMaxAttempts());

                    if (attempt < config.getMaxAttempts()) {
                        waitBeforeRetry(attempt);
                        continue;
                    } else {
                        throw new HttpRetryExhaustedException(
                                "Max retry attempts reached. Last status code: " + response.statusCode(),
                                attempt
                        );
                    }
                }

                // Success - return response
                if (attempt > 1) {
                    log.info("Request succeeded on attempt {}/{}", attempt, config.getMaxAttempts());
                }
                return response;

            } catch (HttpClientException e) {
                lastException = e;
                log.error("HTTP client error on attempt {}/{}: {}",
                        attempt, config.getMaxAttempts(), e.getMessage());

                if (attempt < config.getMaxAttempts() && isRetryableException(e)) {
                    waitBeforeRetry(attempt);
                } else {
                    throw e;
                }

            } catch (Exception e) {
                lastException = e;
                log.error("Unexpected error on attempt {}/{}: {}",
                        attempt, config.getMaxAttempts(), e.getMessage());

                if (attempt < config.getMaxAttempts() && isRetryableException(e)) {
                    waitBeforeRetry(attempt);
                } else {
                    throw new HttpClientException("Request failed: " + e.getMessage(), e);
                }
            }
        }

        // All retries exhausted
        throw new HttpRetryExhaustedException(
                "Max retry attempts reached: " + (lastException != null ? lastException.getMessage() : "Unknown error"),
                attempt,
                lastException
        );
    }

    /**
     * Executes an asynchronous operation with retry logic.
     *
     * @param operation the operation to execute
     * @param <T>       the response type
     * @return a CompletableFuture containing the response
     */
    public <T> CompletableFuture<HttpResponse<T>> executeWithRetryAsync(
            Supplier<CompletableFuture<HttpResponse<T>>> operation) {

        return executeAsyncAttempt(operation, 1);
    }

    /**
     * Executes an asynchronous attempt with retry logic.
     *
     * @param operation the operation to execute
     * @param attempt   the current attempt number
     * @param <T>       the response type
     * @return a CompletableFuture containing the response
     */
    private <T> CompletableFuture<HttpResponse<T>> executeAsyncAttempt(
            Supplier<CompletableFuture<HttpResponse<T>>> operation, int attempt) {

        log.debug("Executing async request attempt {}/{}", attempt, config.getMaxAttempts());

        return operation.get()
                .thenApply(response -> {
                    // Check if response status code is retryable
                    if (config.isRetryable(response.statusCode())) {
                        log.warn("Received retryable status code {} on async attempt {}/{}",
                                response.statusCode(), attempt, config.getMaxAttempts());

                        if (attempt < config.getMaxAttempts()) {
                            throw new RetryableException("Retryable status code: " + response.statusCode());
                        } else {
                            throw new HttpRetryExhaustedException(
                                    "Max retry attempts reached. Last status code: " + response.statusCode(),
                                    attempt
                            );
                        }
                    }

                    if (attempt > 1) {
                        log.info("Async request succeeded on attempt {}/{}", attempt, config.getMaxAttempts());
                    }
                    return response;
                })
                .exceptionallyCompose(throwable -> {
                    Throwable cause = throwable.getCause() != null ? throwable.getCause() : throwable;

                    if (cause instanceof HttpRetryExhaustedException) {
                        return CompletableFuture.failedFuture(cause);
                    }

                    if (attempt < config.getMaxAttempts() && isRetryableException(cause)) {
                        log.warn("Async request failed on attempt {}/{}, retrying: {}",
                                attempt, config.getMaxAttempts(), cause.getMessage());

                        Duration delay = calculateDelay(attempt);
                        return CompletableFuture
                                .supplyAsync(() -> null,
                                        CompletableFuture.delayedExecutor(delay.toMillis(),
                                                java.util.concurrent.TimeUnit.MILLISECONDS))
                                .thenCompose(v -> executeAsyncAttempt(operation, attempt + 1));
                    }

                    log.error("Async request failed on attempt {}/{}: {}",
                            attempt, config.getMaxAttempts(), cause.getMessage());

                    if (cause instanceof HttpClientException) {
                        return CompletableFuture.failedFuture(cause);
                    }

                    return CompletableFuture.failedFuture(
                            new HttpRetryExhaustedException(
                                    "Max retry attempts reached: " + cause.getMessage(),
                                    attempt,
                                    cause
                            )
                    );
                });
    }

    /**
     * Waits before retrying based on exponential backoff.
     *
     * @param attempt the current attempt number
     */
    private void waitBeforeRetry(int attempt) {
        Duration delay = calculateDelay(attempt);
        log.debug("Waiting {}ms before retry attempt {}", delay.toMillis(), attempt + 1);

        try {
            Thread.sleep(delay.toMillis());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new HttpClientException("Retry interrupted", e);
        }
    }

    /**
     * Calculates the delay before the next retry using exponential backoff.
     *
     * @param attempt the current attempt number
     * @return the delay duration
     */
    private Duration calculateDelay(int attempt) {
        long delayMillis = (long) (config.getInitialDelay().toMillis() *
                Math.pow(config.getBackoffMultiplier(), attempt - 1));

        long maxDelayMillis = config.getMaxDelay().toMillis();
        delayMillis = Math.min(delayMillis, maxDelayMillis);

        return Duration.ofMillis(delayMillis);
    }

    /**
     * Checks if an exception is retryable.
     *
     * @param throwable the exception to check
     * @return true if the exception is retryable, false otherwise
     */
    private boolean isRetryableException(Throwable throwable) {
        if (throwable instanceof RetryableException) {
            return true;
        }
        return throwable instanceof IOException;
    }

    /**
     * Internal exception to signal a retryable condition.
     */
    private static class RetryableException extends RuntimeException {
        public RetryableException(String message) {
            super(message);
        }
    }
}

