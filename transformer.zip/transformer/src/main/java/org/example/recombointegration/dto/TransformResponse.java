package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRawValue;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response DTO for XML transformation.
 * Contains the transformation result, status, and any error information.
 * <p>
 * Version 1.0:
 *
 * @author Keshav Ladha
 */
@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Response object for XML to JSON transformation")
public class TransformResponse {

    @Schema(
            description = "Indicates if the transformation was successful",
            example = "true"
    )
    @JsonProperty("success")
    private Boolean success;

    @Schema(
            description = "Transformed JSON result (only present on success)",
            example = "{\"name\":\"Education Screening\",\"type\":\"education\",\"screeningData\":[...]}"
    )
    @JsonProperty("result")
    @JsonRawValue
    private String result;

    @Schema(
            description = "Error code (only present on failure)",
            example = "XML_VALIDATION_ERROR"
    )
    @JsonProperty("errorCode")
    private String errorCode;

    @Schema(
            description = "Error message (only present on failure)",
            example = "Invalid XML format"
    )
    @JsonProperty("errorMessage")
    private String errorMessage;

    /**
     * Constructor for success response.
     *
     * @param result the transformation result (JSON string)
     */
    public TransformResponse(String result) {
        this.success = true;
        this.result = result;
    }

    /**
     * Constructor for error response.
     *
     * @param errorCode    the error code
     * @param errorMessage the error message
     */
    public TransformResponse(String errorCode, String errorMessage) {
        this.success = false;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    /**
     * Creates a success response.
     *
     * @param result the transformation result
     * @return success response
     */
    public static TransformResponse success(String result) {
        return new TransformResponse(result);
    }

    /**
     * Creates an error response.
     *
     * @param errorCode the error code
     * @param error     the error message
     * @return error response
     */
    public static TransformResponse error(String errorCode, String error) {
        return new TransformResponse(errorCode, error);
    }

    @Override
    public String toString() {
        return "TransformResponse{" +
                "success=" + success +
                ", errorCode='" + errorCode + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }
}

