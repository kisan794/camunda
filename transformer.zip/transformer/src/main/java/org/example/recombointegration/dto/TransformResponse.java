package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRawValue;

import java.io.Serializable;

/**
 * Response DTO for XML transformation.
 * Contains the transformation result, status, and any error information.
 * <p>
 * Version 2.0:
 *
 * @author Keshav Ladha
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransformResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("success")
    private Boolean success;

    @JsonProperty("result")
    @JsonRawValue
    private String result;

    @JsonProperty("errorCode")
    private String errorCode;

    @JsonProperty("errorMessage")
    private String errorMessage;

    /**
     * Constructor for success response.
     *
     * @param result the transformation result (JSON string)
     */
    public TransformResponse(String result) {
        this.success = true;
        this.result = result;
    }

    /**
     * Constructor for error response.
     *
     * @param errorCode    the error code
     * @param errorMessage the error message
     */
    public TransformResponse(String errorCode, String errorMessage) {
        this.success = false;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    /**
     * Creates a success response.
     *
     * @param result the transformation result
     * @return success response
     */
    public static TransformResponse success(String result) {
        return new TransformResponse(result);
    }

    /**
     * Creates an error response.
     *
     * @param errorCode the error code
     * @param error     the error message
     * @return error response
     */
    public static TransformResponse error(String errorCode, String error) {
        return new TransformResponse(errorCode, error);
    }

    // Getters and Setters

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "TransformResponse{" +
                "success=" + success +
                ", errorCode='" + errorCode + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }
}

