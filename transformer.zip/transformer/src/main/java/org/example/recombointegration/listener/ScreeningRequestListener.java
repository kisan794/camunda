package org.example.recombointegration.listener;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.dto.ScreeningRequest;
import org.example.recombointegration.service.ScreeningProcessorService;
import org.example.recombointegration.util.CorrelationIdHolder;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * RabbitMQ listener for screening requests.
 * Listens to the screening queue and processes incoming messages.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ScreeningRequestListener {

    private final ScreeningProcessorService screeningProcessorService;

    /**
     * Listens to screening requests queue and processes messages.
     * Extracts correlation ID from message header for tracking.
     *
     * @param request the screening request message
     * @param correlationId correlation ID from message header (optional)
     */
    @RabbitListener(queues = "${rabbitmq.queue.screening-requests}")
    public void handleScreeningRequest(
            @Payload ScreeningRequest request,
            @Header(value = "correlationId", required = false) String correlationId) {

        try {
            // Set correlation ID from header, or from request body, or generate new one
            if (correlationId != null && !correlationId.isEmpty()) {
                CorrelationIdHolder.set(correlationId);
                log.debug("Using correlation ID from message header: {}", correlationId);
            } else {
                CorrelationIdHolder.generate();
                log.debug("Generated new correlation ID: {}", CorrelationIdHolder.get());
            }

            log.info("Received screening request from queue - ID: {}, CorrelationID: {}",
                    request.getId(), CorrelationIdHolder.get());

            // Process the request asynchronously
            screeningProcessorService.processScreeningRequest(request)
                    .join(); // Wait for completion (blocking in listener context)

            log.info("Successfully processed screening request - ID: {}, CorrelationID: {}",
                    request.getId(), CorrelationIdHolder.get());

        } catch (Exception e) {
            log.error("Failed to process screening request - ID: {}, CorrelationID: {}",
                    request.getId(), CorrelationIdHolder.get(), e);
            // Exception will cause message to be sent to DLQ
            throw new UnsupportedOperationException("Failed to process screening request: " + e.getMessage(), e);
        } finally {
            // Clean up correlation ID from MDC
            CorrelationIdHolder.clear();
        }
    }
}

