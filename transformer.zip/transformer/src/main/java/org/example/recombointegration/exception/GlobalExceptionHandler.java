package org.example.recombointegration.exception;

import org.example.recombointegration.util.Constant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Global exception handler for the application.
 * Handles all exceptions and returns appropriate HTTP responses.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handles XmlValidationException.
     *
     * @param ex      the exception
     * @param request the web request
     * @return error response
     */
    @ExceptionHandler(XmlValidationException.class)
    public ResponseEntity<Map<String, Object>> handleXmlValidationException(
            XmlValidationException ex, WebRequest request) {

        logger.error("XML Validation Error: {} - Error Code: {}",
                ex.getMessage(), ex.getErrorCode(), ex);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put(Constant.FIELD_TIMESTAMP, LocalDateTime.now());
        body.put(Constant.FIELD_STATUS, HttpStatus.BAD_REQUEST.value());
        body.put(Constant.FIELD_ERROR, "Bad Request");
        body.put(Constant.FIELD_ERROR_CODE, ex.getErrorCode());
        body.put(Constant.FIELD_MESSAGE, ex.getMessage());
        body.put(Constant.FIELD_PATH, request.getDescription(false).replace("uri=", ""));

        if (ex.getValidationErrors() != null) {
            body.put("validationErrors", ex.getValidationErrors());
        }

        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

    /**
     * Handles XmlTransformationException.
     *
     * @param ex      the exception
     * @param request the web request
     * @return error response
     */
    @ExceptionHandler(XmlTransformationException.class)
    public ResponseEntity<Map<String, Object>> handleXmlTransformationException(
            XmlTransformationException ex, WebRequest request) {

        logger.error("XML Transformation Error: {} - Error Code: {}",
                ex.getMessage(), ex.getErrorCode(), ex);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put(Constant.FIELD_TIMESTAMP, LocalDateTime.now());
        body.put(Constant.FIELD_STATUS, HttpStatus.INTERNAL_SERVER_ERROR.value());
        body.put(Constant.FIELD_ERROR, "Internal Server Error");
        body.put(Constant.FIELD_ERROR_CODE, ex.getErrorCode());
        body.put(Constant.FIELD_MESSAGE, ex.getMessage());
        body.put(Constant.FIELD_PATH, request.getDescription(false).replace("uri=", ""));

        if (ex.getDetails() != null) {
            body.put("details", ex.getDetails());
        }

        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handles IllegalArgumentException.
     *
     * @param ex      the exception
     * @param request the web request
     * @return error response
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleIllegalArgumentException(
            IllegalArgumentException ex, WebRequest request) {

        logger.error("Illegal Argument Error: {}", ex.getMessage(), ex);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put(Constant.FIELD_TIMESTAMP, LocalDateTime.now());
        body.put(Constant.FIELD_STATUS, HttpStatus.BAD_REQUEST.value());
        body.put(Constant.FIELD_ERROR, "Bad Request");
        body.put(Constant.FIELD_ERROR_CODE, "INVALID_ARGUMENT");
        body.put(Constant.FIELD_MESSAGE, ex.getMessage());
        body.put(Constant.FIELD_PATH, request.getDescription(false).replace("uri=", ""));

        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

    /**
     * Handles all other exceptions.
     *
     * @param ex      the exception
     * @param request the web request
     * @return error response
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGlobalException(
            Exception ex, WebRequest request) {

        logger.error("Unexpected Error: {}", ex.getMessage(), ex);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put(Constant.FIELD_TIMESTAMP, LocalDateTime.now());
        body.put(Constant.FIELD_STATUS, HttpStatus.INTERNAL_SERVER_ERROR.value());
        body.put(Constant.FIELD_ERROR, "Internal Server Error");
        body.put(Constant.FIELD_ERROR_CODE, "INTERNAL_ERROR");
        body.put(Constant.FIELD_MESSAGE, "An unexpected error occurred. Please contact support.");
        body.put(Constant.FIELD_PATH, request.getDescription(false).replace("uri=", ""));

        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

