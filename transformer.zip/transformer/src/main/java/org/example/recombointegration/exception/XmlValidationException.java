package org.example.recombointegration.exception;

/**
 * Custom exception for XML validation errors.
 * Thrown when XML validation fails.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class XmlValidationException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final String errorCode;
    private final transient Object validationErrors;

    /**
     * Constructs a new XmlValidationException with the specified detail message.
     *
     * @param message the detail message
     */
    public XmlValidationException(String message) {
        super(message);
        this.errorCode = "XML_VALIDATION_ERROR";
        this.validationErrors = null;
    }

    /**
     * Constructs a new XmlValidationException with the specified detail message and cause.
     *
     * @param message the detail message
     * @param cause   the cause
     */
    public XmlValidationException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = "XML_VALIDATION_ERROR";
        this.validationErrors = null;
    }

    /**
     * Constructs a new XmlValidationException with error code, message and validation errors.
     *
     * @param errorCode        the error code
     * @param message          the detail message
     * @param validationErrors the validation errors
     */
    public XmlValidationException(String errorCode, String message, Object validationErrors) {
        super(message);
        this.errorCode = errorCode;
        this.validationErrors = validationErrors;
    }

    /**
     * Gets the error code.
     *
     * @return the error code
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Gets the validation errors.
     *
     * @return the validation errors
     */
    public Object getValidationErrors() {
        return validationErrors;
    }
}

