package org.example.recombointegration.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.example.recombointegration.exception.XmlTransformationException;
import org.example.recombointegration.service.ScreeningType;
import org.example.recombointegration.service.XmlToJsonConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Maps HireRight Education Screening XML structure to custom JSON schema.
 *
 * @author Keshav Ladha
 */
@Service
public class EducationScreeningXmlToJsonConverter implements XmlToJsonConverter {

    private static final Logger logger = LoggerFactory.getLogger(EducationScreeningXmlToJsonConverter.class);

    private static final String DEFAULT_NAME = "NSCH";
    private static final String DEFAULT_TYPE = "education";
    private static final String ERROR_CODE_CONVERSION_FAILED = "JSON_CONVERSION_FAILED";

    private final XmlMapper xmlMapper;
    private final ObjectMapper jsonMapper;

    /**
     * Constructor initializes XML and JSON mappers.
     */
    public EducationScreeningXmlToJsonConverter() {
        this.xmlMapper = new XmlMapper();
        this.jsonMapper = new ObjectMapper();
        logger.info("EducationScreeningXmlToJsonConverter initialized");
    }

    @Override
    public ScreeningType getType() {
        return ScreeningType.EDUCATION;
    }

    @Override
    public String convert(String xml) {
        logger.debug("Starting Education Screening XML to JSON conversion");

        if (xml == null || xml.trim().isEmpty()) {
            logger.error("XML content is null or empty");
            throw new XmlTransformationException(
                    "XML_EMPTY",
                    "XML content cannot be null or empty",
                    null);
        }

        try {
            logger.debug("Parsing XML content (length: {} characters)", xml.length());

            // Parse XML to JsonNode
            JsonNode xmlNode = xmlMapper.readTree(xml);

            logger.debug("XML parsed successfully, transforming to custom JSON structure");

            // Transform to custom JSON structure
            ObjectNode result = buildJsonStructure(xmlNode);

            // Convert to pretty-printed JSON string
            String jsonOutput = jsonMapper.writerWithDefaultPrettyPrinter().writeValueAsString(result);

            logger.debug("Conversion output preview: {}", jsonOutput);

            return jsonOutput;

        } catch (Exception e) {
            logger.error("Failed to convert Education Screening XML to JSON", e);
            throw new XmlTransformationException(
                    ERROR_CODE_CONVERSION_FAILED,
                    "Failed to convert XML to JSON: " + e.getMessage(),
                    e);
        }
    }

    /**
     * Builds the JSON structure from XML node.
     *
     * @param xmlNode the XML node
     * @return the JSON object node
     */
    private ObjectNode buildJsonStructure(JsonNode xmlNode) {
        logger.debug("Building JSON structure from XML node");

        ObjectNode result = jsonMapper.createObjectNode();

        // Extract root element
        JsonNode educationScreeningList = xmlNode.path("EducationScreeningList");
        if (educationScreeningList.isMissingNode()) {
            educationScreeningList = xmlNode;
            logger.debug("Using root node as EducationScreeningList");
        }

        // Set name and type
        result.put("name", DEFAULT_NAME);

        JsonNode firstScreening = educationScreeningList.path("EducationScreening");
        if (!firstScreening.isMissingNode()) {
            JsonNode screening = firstScreening.path("Screening");
            String type = screening.path("type").asText(DEFAULT_TYPE);
            result.put("type", type);
            logger.debug("Screening type: {}", type);
        } else {
            result.put("type", DEFAULT_TYPE);
            logger.debug("Using default screening type: {}", DEFAULT_TYPE);
        }

        // Create screening array
        ArrayNode screeningArray = jsonMapper.createArrayNode();

        // Process EducationScreening elements
        JsonNode educationScreenings = educationScreeningList.path("EducationScreening");

        if (educationScreenings.isArray()) {
            logger.debug("Processing {} education screening elements", educationScreenings.size());
            for (JsonNode eduScreening : educationScreenings) {
                ObjectNode screeningItem = processEducationScreening(eduScreening);
                screeningArray.add(screeningItem);
            }
        } else if (!educationScreenings.isMissingNode()) {
            logger.debug("Processing single education screening element");
            ObjectNode screeningItem = processEducationScreening(educationScreenings);
            screeningArray.add(screeningItem);
        } else {
            logger.warn("No EducationScreening elements found in XML");
        }

        result.set("screening", screeningArray);

        logger.debug("JSON structure built successfully with {} screening items", screeningArray.size());

        return result;
    }

    /**
     * Processes a single EducationScreening element.
     *
     * @param eduScreening the education screening node
     * @return the screening item object node
     */
    private ObjectNode processEducationScreening(JsonNode eduScreening) {
        logger.debug("Processing EducationScreening element");

        ObjectNode screeningItem = jsonMapper.createObjectNode();

        JsonNode screening = eduScreening.path("Screening");
        JsonNode producerRefId = screening.path("ProducerReferenceId");

        // Extract IdValues
        extractIdValues(producerRefId, screeningItem);

        // Process
        JsonNode verificationReport = screening.path("EducationVerificationReport");

        // Process Contact
        ObjectNode contact = processContact(verificationReport);
        screeningItem.set("contact", contact);

        // Process Institution
        ObjectNode institution = processInstitution(verificationReport);
        screeningItem.set("institution", institution);

        logger.debug("EducationScreening element processed successfully");

        return screeningItem;
    }

    /**
     * Extracts IdValue elements from ProducerReferenceId.
     *
     * @param producerRefId the producer reference ID node
     * @param screeningItem the screening item to populate
     */
    private void extractIdValues(JsonNode producerRefId, ObjectNode screeningItem) {
        logger.debug("Extracting IdValues from ProducerReferenceId");

        JsonNode idValues = producerRefId.path("IdValue");

        if (idValues.isArray()) {
            logger.debug("Processing {} IdValue elements", idValues.size());

            for (JsonNode idValue : idValues) {
                String name = idValue.path("name").asText("");
                String value = extractIdValue(idValue);

                processIdValue(name, value, screeningItem);
            }
        } else if (!idValues.isMissingNode()) {
            logger.debug("Processing single IdValue element");

            String name = idValues.path("name").asText("");
            String value = extractIdValue(idValues);

            processIdValue(name, value, screeningItem);
        }

        logger.debug("IdValues extracted successfully");
    }

    /**
     * Extracts the value from an IdValue node.
     *
     * @param idValue the IdValue node
     * @return the extracted value
     */
    private String extractIdValue(JsonNode idValue) {
        String value = null;

        if (idValue.isTextual()) {
            value = idValue.asText();
        } else if (idValue.isObject()) {
            value = idValue.path("").asText("");
        }

        return value;
    }

    /**
     * Processes a single IdValue and adds it to the screening item.
     *
     * @param name          the IdValue name
     * @param value         the IdValue value
     * @param screeningItem the screening item to populate
     */
    private void processIdValue(String name, String value, ObjectNode screeningItem) {
        switch (name) {
            case "OrderServiceNo":
                screeningItem.put("orderServiceNo", value != null ? value : "");
                logger.debug("OrderServiceNo: {}", value);
                break;
            case "ServiceId":
                screeningItem.put("serviceId", value != null ? value : "");
                logger.debug("ServiceId: {}", value);
                break;
            case "HRSchoolId":
                screeningItem.set("hrSchoolId", (value == null || value.isEmpty()) ?
                        jsonMapper.nullNode() : jsonMapper.valueToTree(value));
                logger.debug("HRSchoolId: {}", value);
                break;
            case "NSCHSchoolId":
                screeningItem.put("nschSchoolId", value != null ? value : "");
                logger.debug("NSCHSchoolId: {}", value);
                break;
            default:
                logger.debug("Unknown IdValue name: {}", name);
                break;
        }
    }

    /**
     * Processes contact information from EducationVerificationReport.
     * Supports both EducationResult (ContactInformation) and EducationInput (Contact) formats.
     *
     * @param verificationReport the verification report node
     * @return the contact object node
     */
    private ObjectNode processContact(JsonNode verificationReport) {
        logger.debug("Processing contact information");

        ObjectNode contact = jsonMapper.createObjectNode();

        JsonNode educationData = verificationReport.path("EducationResult");

        JsonNode contactInfo = educationData.path("ContactInformation");
        // Person Name
        JsonNode personName = contactInfo.path("PersonName");

        // Try FormattedName first
        String fullName = personName.path("FormattedName").asText("");

        if (fullName.isEmpty()) {
            contact.set("personName", jsonMapper.nullNode());
            logger.debug("Contact person name: null");
        } else {
            contact.put("personName", fullName);
            logger.debug("Contact person name: {}", fullName);
        }

        // Title
        String title = contactInfo.path("Title").asText(null);
        contact.set("title", title == null || title.isEmpty() ?
                jsonMapper.nullNode() : jsonMapper.valueToTree(title));
        logger.debug("Contact title: {}", title);

        logger.debug("Contact information processed successfully");

        return contact;
    }

    /**
     * Processes institution information from EducationVerificationReport.
     * Supports both EducationResult and EducationInput formats.
     *
     * @param verificationReport the verification report node
     * @return the institution object node
     */
    private ObjectNode processInstitution(JsonNode verificationReport) {
        logger.debug("Processing institution information");

        ObjectNode institution = jsonMapper.createObjectNode();

        JsonNode educationData = verificationReport.path("EducationResult");

        JsonNode schoolOrInstitution = educationData.path("SchoolOrInstitution");

        // School Name
        String schoolName = schoolOrInstitution.path("SchoolName").asText("");
        institution.put("name", schoolName);
        logger.debug("Institution name: {}", schoolName);

        // Programs array
        ArrayNode programs = jsonMapper.createArrayNode();

        // New format: data is in SchoolOrInstitution with Degree and DatesOfAttendance
        logger.debug("Processing SchoolOrInstitution format (Degree and DatesOfAttendance)");
        ObjectNode program = processSchoolOrInstitution(schoolOrInstitution);
        if (program != null) {
            programs.add(program);
        }

        institution.set("programs", programs);

        logger.debug("Institution information processed successfully with {} programs", programs.size());

        return institution;
    }

    /**
     * Processes SchoolOrInstitution element (new format with Degree and DatesOfAttendance).
     *
     * @param schoolOrInstitution the school or institution node
     * @return the program object node, or null if no degree data
     */
    private ObjectNode processSchoolOrInstitution(JsonNode schoolOrInstitution) {
        logger.debug("Processing SchoolOrInstitution element");

        // Check if there's actual degree data
        JsonNode degree = schoolOrInstitution.path("Degree");
        if (degree.isMissingNode() || degree.path("DegreeName").asText("").isEmpty()) {
            logger.debug("No degree data found in SchoolOrInstitution");
            return null;
        }

        ObjectNode program = jsonMapper.createObjectNode();

        // Verification Required - check if degree was received
        String received = degree.path("Received").asText("");
        boolean verificationRequired = "Yes".equalsIgnoreCase(received);
        program.put("verificationRequired", verificationRequired);
        logger.debug("Verification required (based on Received={}): {}", received, verificationRequired);

        // Degree Name
        String degreeName = degree.path("DegreeName").asText("");
        program.put("degree", degreeName);
        logger.debug("Degree: {}", degreeName);

        // Major
        String major = schoolOrInstitution.path("Major").asText("");
        program.put("major", major);
        logger.debug("Major: {}", major);

        // Tenure
        ObjectNode tenure = jsonMapper.createObjectNode();

        JsonNode datesOfAttendance = schoolOrInstitution.path("DatesOfAttendance");
        String startDate = datesOfAttendance.path("StartDate").path("AnyDate").asText("");
        String endDate = datesOfAttendance.path("EndDate").path("AnyDate").asText("");

        // Check if currently attending (if endDate is empty or in the future)
        boolean current = endDate.isEmpty();

        tenure.put("startDate", startDate);
        tenure.put("endDate", endDate);
        tenure.put("current", current);

        logger.debug("Tenure: {} to {}, current: {}", startDate, endDate, current);

        program.set("tenure", tenure);

        logger.debug("SchoolOrInstitution element processed successfully");

        return program;
    }
}

