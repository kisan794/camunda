package org.example.recombointegration.service;

import org.example.recombointegration.exception.XmlTransformationException;

/**
 * Interface for XML to JSON conversion.
 * Defines contract for converting XML content to JSON format.
 *
 * @author Keshav Ladha
 */
public interface XmlToJsonConverter {

    /**
     * Converts the given XML content to JSON format.
     *
     * @param xml the XML content to convert
     * @return the JSON representation
     * @throws XmlTransformationException if conversion fails
     */
    String convert(String xml);

    /**
     * Gets the screening type that this converter handles.
     * Used by the factory to automatically register converters.
     *
     * @return the screening type
     */
    ScreeningType getType();
}

