package org.example.recombointegration.http.client;

import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.http.config.HttpClientConfig;
import org.example.recombointegration.http.config.JwtConfig;
import org.example.recombointegration.http.config.RetryConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.net.http.HttpResponse;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

/**
 * Spring service wrapper for Http2Client.
 * Provides a Spring-managed HTTP/2 client with configuration from Spring-managed config beans.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Service
public class Http2ClientService {

    private final HttpClientConfig httpClientConfig;
    private final Optional<RetryConfig> retryConfig;
    private final Optional<JwtConfig> jwtConfig;

    private Http2Client client;

    /**
     * Constructor with dependency injection.
     * RetryConfig and JwtConfig are optional based on their conditional properties.
     *
     * @param httpClientConfig the HTTP client configuration (required)
     * @param retryConfig      the retry configuration (optional, based on http.client.retry.enabled)
     * @param jwtConfig        the JWT configuration (optional, based on http.client.jwt.enabled)
     */
    @Autowired
    public Http2ClientService(
            HttpClientConfig httpClientConfig,
            @Autowired(required = false) RetryConfig retryConfig,
            @Autowired(required = false) JwtConfig jwtConfig) {
        this.httpClientConfig = httpClientConfig;
        this.retryConfig = Optional.ofNullable(retryConfig);
        this.jwtConfig = Optional.ofNullable(jwtConfig);
    }

    /**
     * Initializes the HTTP/2 client after dependencies are injected.
     */
    @PostConstruct
    public void init() {
        log.info("Initializing Http2ClientService with configuration from Spring beans");

        Http2Client.Builder builder = Http2Client.builder()
                .clientConfig(httpClientConfig);

        // Configure retry if enabled
        retryConfig.ifPresent(config -> {
            builder.retryConfig(config);
            log.info("Retry enabled with max attempts: {}", config.getMaxAttempts());
        });

        // Configure JWT if enabled
        jwtConfig.ifPresent(config -> {
            builder.jwtConfig(config);
            log.info("JWT authentication enabled with issuer: {}", config.getIssuer());
        });

        this.client = builder.build();
        log.info("Http2ClientService initialized successfully");
    }

    /**
     * Executes a synchronous GET request with custom headers.
     *
     * @param uri     the request URI
     * @param headers custom headers to include
     * @return the HTTP response
     */
    public HttpResponse<String> get(String uri, Map<String, String> headers) {
        return client.get(uri, headers);
    }

    /**
     * Executes a synchronous POST request with custom headers.
     *
     * @param uri     the request URI
     * @param body    the request body
     * @param headers custom headers to include
     * @return the HTTP response
     */
    public HttpResponse<String> post(String uri, String body, Map<String, String> headers) {
        return client.post(uri, body, headers);
    }

    /**
     * Executes an asynchronous GET request with custom headers.
     *
     * @param uri     the request URI
     * @param headers custom headers to include
     * @return a CompletableFuture containing the HTTP response
     */
    public CompletableFuture<HttpResponse<String>> getAsync(String uri, Map<String, String> headers) {
        return client.getAsync(uri, headers);
    }

    /**
     * Executes an asynchronous POST request with custom headers.
     *
     * @param uri     the request URI
     * @param body    the request body
     * @param headers custom headers to include
     * @return a CompletableFuture containing the HTTP response
     */
    public CompletableFuture<HttpResponse<String>> postAsync(String uri, String body, Map<String, String> headers) {
        return client.postAsync(uri, body, headers);
    }

}