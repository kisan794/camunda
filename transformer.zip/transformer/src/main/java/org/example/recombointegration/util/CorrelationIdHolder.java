package org.example.recombointegration.util;

import org.slf4j.MDC;

import java.util.UUID;

/**
 * Utility class for managing correlation IDs using SLF4J's MDC (Mapped Diagnostic Context).
 * Correlation IDs are used to track requests across multiple services and components.
 * <p>
 * This class provides thread-safe correlation ID management by leveraging MDC,
 * which maintains a per-thread context map.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class CorrelationIdHolder {

    /**
     * MDC key for storing correlation ID.
     */
    public static final String CORRELATION_ID_KEY = "correlationId";

    /**
     * HTTP header name for correlation ID.
     */
    public static final String CORRELATION_ID_HEADER = "X-Correlation-ID";

    /**
     * RabbitMQ message header name for correlation ID.
     */
    public static final String RABBITMQ_CORRELATION_ID_HEADER = "correlationId";

    private CorrelationIdHolder() {
        // Private constructor to prevent instantiation
    }

    /**
     * Generates a new correlation ID and sets it in MDC.
     *
     * @return the generated correlation ID
     */
    public static String generate() {
        String correlationId = UUID.randomUUID().toString();
        set(correlationId);
        return correlationId;
    }

    /**
     * Sets the correlation ID in MDC.
     *
     * @param correlationId the correlation ID to set
     */
    public static void set(String correlationId) {
        if (correlationId != null && !correlationId.isEmpty()) {
            MDC.put(CORRELATION_ID_KEY, correlationId);
        }
    }

    /**
     * Gets the current correlation ID from MDC.
     *
     * @return the correlation ID, or null if not set
     */
    public static String get() {
        return MDC.get(CORRELATION_ID_KEY);
    }

    /**
     * Gets the current correlation ID from MDC, or generates a new one if not set.
     *
     * @return the correlation ID
     */
    public static String getOrGenerate() {
        String correlationId = get();
        if (correlationId == null || correlationId.isEmpty()) {
            correlationId = generate();
        }
        return correlationId;
    }

    /**
     * Removes the correlation ID from MDC.
     */
    public static void clear() {
        MDC.remove(CORRELATION_ID_KEY);
    }

    /**
     * Clears all MDC context.
     * Use this when you want to ensure a clean MDC state.
     */
    public static void clearAll() {
        MDC.clear();
    }
}

