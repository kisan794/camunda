package org.example.recombointegration.util;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@UtilityClass
public class Recombo360RequestTransformerUtil {

    /**
     * Maps data sources and converts to JSON string.
     *
     * @param hrgRequestData   transformed HRG request data
     * @param xmlConvertedData JSON data converted from XML
     * @return unified datasource as JSON string
     * @throws Exception if conversion fails
     */
    public Map<String, Object> transform(
            Map<String, Object> hrgRequestData,
            Map<String, Object> xmlConvertedData) throws Exception {


        log.debug("Mapping data sources - HRG data size: {}, XML data size: {}",
                hrgRequestData != null ? hrgRequestData.size() : 0,
                xmlConvertedData != null ? xmlConvertedData.size() : 0);

        Map<String, Object> datasource = new HashMap<>();

        // Add HRG request data
        if (hrgRequestData != null && !hrgRequestData.isEmpty()) {
            datasource.put("hrgData", hrgRequestData);
        }

        // Add XML converted data
        if (xmlConvertedData != null && !xmlConvertedData.isEmpty()) {
            datasource.put("screeningData", xmlConvertedData);
        }

        log.info("Data sources mapped successfully - total fields: {}", datasource.size());

        return datasource;
    }
}
