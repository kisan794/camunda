package org.example.recombointegration.util;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@UtilityClass
public class Recombo360RequestTransformerUtil {

    /**
     * Maps data sources and converts to JSON string.
     *
     * @param hrgRequestData   transformed HRG request data
     * @param xmlConvertedData JSON data converted from XML
     * @return unified datasource as JSON string
     * @throws Exception if conversion fails
     */
    public Map<String, Object> transform(
            Map<String, Object> hrgRequestData,
            Map<String, Object> xmlConvertedData) throws Exception {


        log.debug("Mapping data sources - HRG data size: {}, XML data size: {}",
                hrgRequestData != null ? hrgRequestData.size() : 0,
                xmlConvertedData != null ? xmlConvertedData.size() : 0);

        Map<String, Object> reCombo360Payload = new HashMap<>();
        Map<String, Object> request = new HashMap<>();

        // Add HRG request data
        if (hrgRequestData != null && !hrgRequestData.isEmpty()) {
            request.put("hrgSource", hrgRequestData);
        }

        // Add XML converted data
        if (xmlConvertedData != null && !xmlConvertedData.isEmpty()) {
            request.put("dataSource", xmlConvertedData);
        }
        reCombo360Payload.put("id", "hrg:hre:data-request:985702987"); // @TODO
        reCombo360Payload.put("refid", "hrg:hre:order-item:HE-020202-98765R-EM-002"); // @TODO
        reCombo360Payload.put("request", request);

        log.info("Data sources mapped successfully - total fields: {}", reCombo360Payload.size());

        return reCombo360Payload;
    }
}
