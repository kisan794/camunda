package org.example.recombointegration.exception;

/**
 * Custom exception for XML transformation errors.
 * Thrown when XML to JSON transformation fails.
 *
 * @author Keshav Ladha
 */
public class XmlTransformationException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final String errorCode;
    private final transient Object details;

    /**
     * Constructs a new XmlTransformationException with the specified detail message.
     *
     * @param message the detail message
     */
    public XmlTransformationException(String message) {
        super(message);
        this.errorCode = "XML_TRANSFORMATION_ERROR";
        this.details = null;
    }

    /**
     * Constructs a new XmlTransformationException with the specified detail message and cause.
     *
     * @param message the detail message
     * @param cause   the cause
     */
    public XmlTransformationException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = "XML_TRANSFORMATION_ERROR";
        this.details = null;
    }

    /**
     * Constructs a new XmlTransformationException with error code, message and cause.
     *
     * @param errorCode the error code
     * @param message   the detail message
     * @param cause     the cause
     */
    public XmlTransformationException(String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.details = null;
    }

    /**
     * Constructs a new XmlTransformationException with error code, message, cause and details.
     *
     * @param errorCode the error code
     * @param message   the detail message
     * @param cause     the cause
     * @param details   additional error details
     */
    public XmlTransformationException(String errorCode, String message, Throwable cause, Object details) {
        super(message, cause);
        this.errorCode = errorCode;
        this.details = details;
    }

    /**
     * Gets the error code.
     *
     * @return the error code
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Gets the error details.
     *
     * @return the error details
     */
    public Object getDetails() {
        return details;
    }
}

