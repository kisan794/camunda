package org.example.recombointegration.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.example.recombointegration.exception.XmlTransformationException;
import org.example.recombointegration.service.ScreeningType;
import org.example.recombointegration.service.XmlToJsonConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Maps HireRight Employment Screening XML structure to custom JSON schema.
 * Handles TALX/XYZ employment verification data with position history and compensation information.
 * <p>
 * Features:
 * - Handles single or multiple EmploymentScreening elements
 * - Extracts employer organization details
 * - Processes position history with dates and status
 * - Includes compensation information
 *
 * @author Keshav Ladha
 */
@Service
public class EmploymentScreeningXmlToJsonConverter implements XmlToJsonConverter {

    private static final Logger logger = LoggerFactory.getLogger(EmploymentScreeningXmlToJsonConverter.class);

    private static final String DEFAULT_NAME = "TALX/XYZ";
    private static final String DEFAULT_TYPE = "employment";
    private static final String ERROR_CODE_CONVERSION_FAILED = "JSON_CONVERSION_FAILED";

    private final XmlMapper xmlMapper;
    private final ObjectMapper jsonMapper;

    /**
     * Constructor initializes XML and JSON mappers.
     */
    public EmploymentScreeningXmlToJsonConverter() {
        this.xmlMapper = new XmlMapper();
        this.jsonMapper = new ObjectMapper();
        logger.info("EmploymentScreeningXmlToJsonConverter initialized");
    }

    @Override
    public ScreeningType getType() {
        return ScreeningType.EMPLOYMENT;
    }

    @Override
    public String convert(String xml) {
        logger.debug("Starting Employment Screening XML to JSON conversion");

        if (xml == null || xml.trim().isEmpty()) {
            logger.error("XML content is null or empty");
            throw new XmlTransformationException(
                    "XML_EMPTY",
                    "XML content cannot be null or empty",
                    null);
        }

        try {
            logger.debug("Parsing XML content (length: {} characters)", xml.length());

            // Parse XML to JsonNode
            JsonNode xmlNode = xmlMapper.readTree(xml);

            logger.debug("XML parsed successfully, transforming to custom JSON structure");

            // Transform to custom JSON structure
            ObjectNode result = buildJsonStructure(xmlNode);

            // Convert to pretty-printed JSON string
            String jsonOutput = jsonMapper.writerWithDefaultPrettyPrinter().writeValueAsString(result);

            logger.debug("Conversion output preview: {}", jsonOutput);

            return jsonOutput;

        } catch (Exception e) {
            logger.error("Failed to convert Employment Screening XML to JSON", e);
            throw new XmlTransformationException(
                    ERROR_CODE_CONVERSION_FAILED,
                    "Failed to convert XML to JSON: " + e.getMessage(),
                    e);
        }
    }

    /**
     * Builds the JSON structure from XML node.
     *
     * @param xmlNode the XML node
     * @return the JSON object node
     */
    private ObjectNode buildJsonStructure(JsonNode xmlNode) {
        logger.debug("Building JSON structure from XML node");

        ObjectNode result = jsonMapper.createObjectNode();

        // Extract root element
        JsonNode employmentScreeningList = xmlNode.path("EmploymentScreeningList");
        if (employmentScreeningList.isMissingNode()) {
            employmentScreeningList = xmlNode;
            logger.debug("Using root node as EmploymentScreeningList");
        }

        // Set name and type
        result.put("name", DEFAULT_NAME);

        JsonNode firstScreening = employmentScreeningList.path("EmploymentScreening");
        if (!firstScreening.isMissingNode()) {
            JsonNode screening = firstScreening.path("Screening");
            String type = screening.path("type").asText(DEFAULT_TYPE);
            result.put("type", type);
            logger.debug("Screening type: {}", type);
        } else {
            result.put("type", DEFAULT_TYPE);
            logger.debug("Using default screening type: {}", DEFAULT_TYPE);
        }

        // Create screenings array
        ArrayNode screeningsArray = jsonMapper.createArrayNode();

        // Process EmploymentScreening elements
        JsonNode employmentScreenings = employmentScreeningList.path("EmploymentScreening");

        if (employmentScreenings.isArray()) {
            logger.debug("Processing {} employment screening elements", employmentScreenings.size());
            for (JsonNode empScreening : employmentScreenings) {
                ObjectNode screeningItem = processEmploymentScreening(empScreening);
                screeningsArray.add(screeningItem);
            }
        } else if (!employmentScreenings.isMissingNode()) {
            logger.debug("Processing single employment screening element");
            ObjectNode screeningItem = processEmploymentScreening(employmentScreenings);
            screeningsArray.add(screeningItem);
        } else {
            logger.warn("No EmploymentScreening elements found in XML");
        }

        result.set("screenings", screeningsArray);

        logger.debug("JSON structure built successfully with {} screening items", screeningsArray.size());

        return result;
    }

    /**
     * Processes a single EmploymentScreening element.
     *
     * @param empScreening the employment screening node
     * @return the screening item object node
     */
    private ObjectNode processEmploymentScreening(JsonNode empScreening) {
        logger.debug("Processing EmploymentScreening element");

        ObjectNode screeningItem = jsonMapper.createObjectNode();

        JsonNode screening = empScreening.path("Screening");
        JsonNode producerRefId = screening.path("ProducerReferenceId");

        // Extract IdValues (OrderServiceNo, ServiceId, TALXEmployerCode)
        extractIdValues(producerRefId, screeningItem);

        // Process Employment Verification Report
        JsonNode verificationReport = screening.path("EmploymentVerificationReport");
        JsonNode employmentResult = verificationReport.path("EmploymentResult");
        JsonNode employmentHistory = employmentResult.path("EmploymentHistory");
        JsonNode employerOrg = employmentHistory.path("EmployerOrg");

        // Extract employer organization details
        extractEmployerOrgDetails(employerOrg, screeningItem);

        // Process Position History
        ObjectNode positionHistory = processPositionHistory(employerOrg.path("PositionHistory"));
        screeningItem.set("positionHistory", positionHistory);

        logger.debug("EmploymentScreening element processed successfully");

        return screeningItem;
    }

    /**
     * Extracts IdValue elements from ProducerReferenceId.
     *
     * @param producerRefId the producer reference ID node
     * @param screeningItem the screening item to populate
     */
    private void extractIdValues(JsonNode producerRefId, ObjectNode screeningItem) {
        logger.debug("Extracting IdValues from ProducerReferenceId");

        JsonNode idValues = producerRefId.path("IdValue");

        if (idValues.isArray()) {
            logger.debug("Processing {} IdValue elements", idValues.size());

            for (JsonNode idValue : idValues) {
                String name = idValue.path("name").asText("");
                String value = extractIdValue(idValue);

                processIdValue(name, value, screeningItem);
            }
        } else if (!idValues.isMissingNode()) {
            logger.debug("Processing single IdValue element");

            String name = idValues.path("name").asText("");
            String value = extractIdValue(idValues);

            processIdValue(name, value, screeningItem);
        }

        logger.debug("IdValues extracted successfully");
    }

    /**
     * Extracts the value from an IdValue node.
     *
     * @param idValue the IdValue node
     * @return the extracted value
     */
    private String extractIdValue(JsonNode idValue) {
        String value = null;

        if (idValue.isTextual()) {
            value = idValue.asText();
        } else if (idValue.isObject()) {
            value = idValue.path("").asText("");
        }

        return value;
    }

    /**
     * Processes a single IdValue and adds it to the screening item.
     *
     * @param name          the IdValue name
     * @param value         the IdValue value
     * @param screeningItem the screening item to populate
     */
    private void processIdValue(String name, String value, ObjectNode screeningItem) {
        switch (name) {
            case "OrderServiceNo":
                screeningItem.put("orderServiceNo", value != null ? value : "");
                logger.debug("OrderServiceNo: {}", value);
                break;
            case "ServiceId":
                screeningItem.put("serviceId", value != null ? value : "");
                logger.debug("ServiceId: {}", value);
                break;
            case "TALXEmployerCode":
                screeningItem.put("talxEmployerCode", value != null ? value : "");
                logger.debug("TALXEmployerCode: {}", value);
                break;
            default:
                logger.debug("Unknown IdValue name: {}, skipping", name);
                break;
        }
    }

    /**
     * Extracts employer organization details.
     *
     * @param employerOrg   the employer organization node
     * @param screeningItem the screening item to populate
     */
    private void extractEmployerOrgDetails(JsonNode employerOrg, ObjectNode screeningItem) {
        logger.debug("Extracting employer organization details");

        // Employer Organization Name
        String employerOrgName = employerOrg.path("EmployerOrgName").asText("");
        screeningItem.put("employerOrgName", employerOrgName);
        logger.debug("EmployerOrgName: {}", employerOrgName);

        // Location details
        JsonNode employerContactInfo = employerOrg.path("EmployerContactInfo");
        JsonNode locationSummary = employerContactInfo.path("LocationSummary");

        String city = locationSummary.path("Municipality").asText("");
        String region = locationSummary.path("Region").asText("");
        String country = locationSummary.path("CountryCode").asText("");

        screeningItem.put("city", city);
        screeningItem.put("region", region);
        screeningItem.put("country", country);

        logger.debug("Location: city={}, region={}, country={}", city, region, country);
    }

    /**
     * Processes position history information.
     *
     * @param positionHistoryNode the position history node
     * @return the position history object node
     */
    private ObjectNode processPositionHistory(JsonNode positionHistoryNode) {
        logger.debug("Processing position history");

        ObjectNode positionHistory = jsonMapper.createObjectNode();

        // Title
        String title = positionHistoryNode.path("Title").asText("");
        positionHistory.put("title", title);
        logger.debug("Title: {}", title);

        // Start Date
        String startDate = positionHistoryNode.path("StartDate").path("AnyDate").asText("");
        positionHistory.put("startDate", startDate);
        logger.debug("StartDate: {}", startDate);

        // End Date
        String endDate = positionHistoryNode.path("EndDate").path("AnyDate").asText("");
        positionHistory.put("endDate", endDate);
        logger.debug("EndDate: {}", endDate);

        // Most Recent Hire Date
        String mostRecentHireDate = positionHistoryNode.path("MostRecentHireDate").path("AnyDate").asText("");
        positionHistory.put("mostRecentHireDate", mostRecentHireDate);
        logger.debug("MostRecentHireDate: {}", mostRecentHireDate);

        // Employee Status
        JsonNode employeeStatusNode = positionHistoryNode.path("EmployeeStatus");
        String employeeStatusCode = employeeStatusNode.path("code").asText("");
        // Get the text content of the EmployeeStatus element
        String employeeStatus = employeeStatusNode.path("").asText("");

        positionHistory.put("employeeStatusCode", employeeStatusCode);
        positionHistory.put("employeeStatus", employeeStatus);
        logger.debug("EmployeeStatus: code={}, status={}", employeeStatusCode, employeeStatus);

        // Compensation Info
        ObjectNode compensationInfo = processCompensationInfo(positionHistoryNode.path("CompensationInfo"));
        positionHistory.set("compensationInfo", compensationInfo);

        logger.debug("Position history processed successfully");

        return positionHistory;
    }

    /**
     * Processes compensation information.
     *
     * @param compensationInfoNode the compensation info node
     * @return the compensation info object node
     */
    private ObjectNode processCompensationInfo(JsonNode compensationInfoNode) {
        logger.debug("Processing compensation information");

        ObjectNode compensationInfo = jsonMapper.createObjectNode();

        // Currency
        String currency = compensationInfoNode.path("currency").asText("");
        compensationInfo.put("currency", currency);
        logger.debug("Currency: {}", currency);

        // Rate of Pay
        String rateOfPay = compensationInfoNode.path("RateOfPay").asText("");
        compensationInfo.put("rateOfPay", rateOfPay);

        // Average Hours Per Pay Period
        String avgHours = compensationInfoNode.path("AverageHoursPerPayPeriod").asText("");
        compensationInfo.put("averageHoursPerPayPeriod", avgHours);

        // Date of Pay Increase Last
        String dateOfPayIncreaseLast = compensationInfoNode.path("DateOfPayIncreaseLast").path("AnyDate").asText("");
        compensationInfo.put("dateOfPayIncreaseLast", dateOfPayIncreaseLast);

        // Amount of Pay Increase Last
        String amountOfPayIncreaseLast = compensationInfoNode.path("AmountOfPayIncreaseLast").asText("");
        compensationInfo.put("amountOfPayIncreaseLast", amountOfPayIncreaseLast);

        // Date of Pay Increase Next
        String dateOfPayIncreaseNext = compensationInfoNode.path("DateOfPayIncreaseNext").path("AnyDate").asText("");
        compensationInfo.put("dateOfPayIncreaseNext", dateOfPayIncreaseNext);

        // Amount of Pay Increase Next
        String amountOfPayIncreaseNext = compensationInfoNode.path("AmountOfPayIncreaseNext").asText("");
        compensationInfo.put("amountOfPayIncreaseNext", amountOfPayIncreaseNext);

        logger.debug("Compensation information processed successfully");

        return compensationInfo;
    }
}

