package org.example.recombointegration.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.dto.ScreeningRequest;
import org.example.recombointegration.listener.ScreeningRequestListener;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Test controller for manually testing the ScreeningRequestListener.
 * Simulates RabbitMQ message processing without requiring RabbitMQ to be running.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@RestController
@RequestMapping("/api/test/screening")
@RequiredArgsConstructor
@Tag(name = "Screening Test", description = "Test endpoints for screening request processing")
public class ScreeningTestController {

    private final ScreeningRequestListener screeningRequestListener;


    /**
     * Test endpoint with full request body.
     * Allows testing with custom ScreeningRequest payload.
     *
     * @param request the screening request
     * @param correlationId optional correlation ID from header
     * @return response with processing status
     */
    @PostMapping("/process")
    @Operation(
            summary = "Test screening request with custom payload",
            description = "Allows testing with a full ScreeningRequest JSON payload. " +
                    "Correlation ID can be provided in header or request body."
    )
    public ResponseEntity<Map<String, Object>> testScreeningRequestWithBody(
            @RequestBody ScreeningRequest request,
            
            @Parameter(description = "Optional correlation ID from header")
            @RequestHeader(value = "X-Correlation-ID", required = false) String correlationId) {

        log.info("Test endpoint called with body - ScreeningID: {}, CorrelationID: {}",
                request.getId(), correlationId);

        Map<String, Object> response = new HashMap<>();
        response.put("screeningId", request.getId());
        response.put("correlationId", correlationId);

        try {
            // Call the listener method directly (simulating RabbitMQ message)
            screeningRequestListener.handleScreeningRequest(request, correlationId);

            response.put("status", "SUCCESS");
            response.put("message", "Screening request processed successfully");

            log.info("Test processing completed successfully - ScreeningID: {}", request.getId());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("Test processing failed - ScreeningID: {}", request.getId(), e);

            response.put("status", "FAILED");
            response.put("message", "Processing failed: " + e.getMessage());
            response.put("error", e.getClass().getSimpleName());

            return ResponseEntity.status(500).body(response);
        }
    }

}

