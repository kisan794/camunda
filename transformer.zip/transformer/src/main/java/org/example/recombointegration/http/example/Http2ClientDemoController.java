package org.example.recombointegration.http.example;

import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.http.client.Http2ClientService;
import org.example.recombointegration.http.exception.HttpClientException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * Spring Boot REST Controller demonstrating HTTP/2 client usage.
 * This controller shows how to use Http2ClientService in a Spring Boot application.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@RestController
@RequestMapping("/api/http-client-demo")
public class Http2ClientDemoController {

    private final Http2ClientService httpClient;

    @Autowired
    public Http2ClientDemoController(Http2ClientService httpClient) {
        this.httpClient = httpClient;
        log.info("Http2ClientDemoController initialized with Http2ClientService");
    }

    /**
     * Example 3: POST request with custom headers.
     * POST /api/http-client-demo/post-with-headers
     */
    @PostMapping("/post-with-headers")
    public ResponseEntity<Map<String, Object>> postWithHeaders(@RequestBody Map<String, Object> requestBody) {
        log.info("Executing POST request with custom headers");
        
        try {
            String jsonBody = convertToJson(requestBody);
            
            // Add custom headers
            Map<String, String> headers = new HashMap<>();
            headers.put("X-Custom-Header", "custom-value");
            headers.put("X-Request-ID", java.util.UUID.randomUUID().toString());
            
            HttpResponse<String> response = httpClient.post(
                    "https://jsonplaceholder.typicode.com/posts",
                    jsonBody,
                    headers
            );
            
            Map<String, Object> result = new HashMap<>();
            result.put("status", "success");
            result.put("statusCode", response.statusCode());
            result.put("body", response.body());
            result.put("customHeaders", headers);
            
            return ResponseEntity.ok(result);
            
        } catch (HttpClientException e) {
            log.error("POST with headers failed: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("status", "error", "message", e.getMessage()));
        }
    }

    /**
     * Helper method to convert Map to JSON string.
     */
    private String convertToJson(Map<String, Object> map) {
        try {
            // Simple JSON conversion (in production, use Jackson ObjectMapper)
            StringBuilder json = new StringBuilder("{");
            map.forEach((key, value) -> {
                json.append("\"").append(key).append("\":");
                if (value instanceof String) {
                    json.append("\"").append(value).append("\"");
                } else {
                    json.append(value);
                }
                json.append(",");
            });
            if (json.length() > 1) {
                json.setLength(json.length() - 1); // Remove last comma
            }
            json.append("}");
            return json.toString();
        } catch (Exception e) {
            throw new RuntimeException("Failed to convert to JSON", e);
        }
    }
}

