package org.example.recombointegration.http.config;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.time.Duration;

/**
 * Spring-managed configuration for JWT authentication.
 * Contains settings for JWT token generation and validation.
 * Properties are loaded from application.properties.
 * Only active when http.client.jwt.enabled=true.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Getter
@Component
@ConditionalOnProperty(name = "http.client.jwt.enabled", havingValue = "true")
public class JwtConfig {

    @Value("${http.client.jwt.secret-key}")
    private String secretKey;

    @Value("${http.client.jwt.issuer:}")
    private String issuer;

    @Value("${http.client.jwt.subject:}")
    private String subject;

    @Value("${http.client.jwt.expiration-hours:1}")
    private int expirationHours;

    /**
     * Validates the configuration after properties are injected.
     */
    @PostConstruct
    public void init() {
        // Validate
        if (secretKey == null || secretKey.isBlank()) {
            throw new IllegalStateException("JWT secret key must not be null or blank when JWT is enabled");
        }
        if (expirationHours <= 0) {
            throw new IllegalStateException("JWT expiration hours must be positive");
        }

        log.info("JwtConfig initialized - issuer: {}, subject: {}, expirationHours: {}",
                issuer, subject, expirationHours);
    }

    /**
     * Gets the JWT expiration time as a Duration.
     *
     * @return expiration time duration
     */
    public Duration getExpirationTime() {
        return Duration.ofHours(expirationHours);
    }
}

