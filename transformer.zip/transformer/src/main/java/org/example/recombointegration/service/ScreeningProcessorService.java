package org.example.recombointegration.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.recombointegration.config.ExternalApiConfig;
import org.example.recombointegration.dto.VendorResponse;
import org.example.recombointegration.http.client.Http2ClientService;
import org.example.recombointegration.http.exception.HttpClientException;
import org.example.recombointegration.util.Constant;
import org.example.recombointegration.util.CorrelationIdHolder;
import org.example.recombointegration.util.HrgRequestTransformerUtil;
import org.example.recombointegration.util.Recombo360RequestTransformerUtil;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Service for processing vendor responses.
 * Transforms vendor data and posts to Recombo 360 API.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ScreeningProcessorService {

    private final Http2ClientService httpClient;
    private final ExternalApiConfig externalApiConfig;
    private final XmlTransformationService xmlTransformationService;
    private final ObjectMapper objectMapper;

    /**
     * Processes vendor response containing hrgRequest and encoded XML.
     * This is the main entry point for processing vendor data.
     * <p>
     * Steps:
     * 1. Transform hrgRequest JSON to target format
     * 2. Decode base64 encoded XML
     * 3. Transform XML to JSON
     * 4. Map/merge both JSONs as datasource
     * 5. POST to third-party API
     *
     * @param vendorResponse the vendor API response
     * @param screeningId    the screening ID
     * @return CompletableFuture that completes when processing is done
     */
    public CompletableFuture<Void> processVendorResponse(VendorResponse vendorResponse, String screeningId) {
        // Capture MDC context for async operations
        Map<String, String> mdcContext = MDC.getCopyOfContextMap();

        log.info("Processing vendor response for ID: {}, CorrelationID: {}",
                screeningId, CorrelationIdHolder.get());

        try {
            // Step 1: Transform hrgRequest to target JSON format
            Map<String, Object> transformedHrgData = HrgRequestTransformerUtil.transform(vendorResponse.getHrgRequest());
            log.debug("Transformed HRG request for ID: {}, CorrelationID: {}",
                    screeningId, CorrelationIdHolder.get());

            // Step 2: Decode base64 encoded XML
            String encodedXml = vendorResponse.getEncode();
            if (encodedXml == null || encodedXml.isEmpty()) {
                log.error("Encoded XML is null or empty for ID: {}, CorrelationID: {}",
                        screeningId, CorrelationIdHolder.get());
                return CompletableFuture.failedFuture(
                        new IllegalArgumentException("Encoded XML is missing")
                );
            }

            byte[] decodedBytes = Base64.getDecoder().decode(encodedXml);
            String xmlData = new String(decodedBytes, StandardCharsets.UTF_8);
            log.debug("Decoded XML data for ID: {}, CorrelationID: {} - length: {}",
                    screeningId, CorrelationIdHolder.get(), xmlData.length());

            // Step 3: Transform XML to JSON
            String xmlJsonString = xmlTransformationService.transformXmlToJson(xmlData, Constant.SCREENING_TYPE_EDUCATION);
            @SuppressWarnings("unchecked")
            Map<String, Object> xmlConvertedData = objectMapper.readValue(xmlJsonString, Map.class);
            log.info("Transformed XML to JSON for ID: {}, CorrelationID: {}",
                    screeningId, CorrelationIdHolder.get());

            // Step 4: Map/merge both JSONs as datasource
            String datasourceJson = objectMapper.writeValueAsString(Recombo360RequestTransformerUtil.transform(transformedHrgData, xmlConvertedData));

            log.info("Mapped data sources for ID: {}, CorrelationID: {}",
                    screeningId, CorrelationIdHolder.get());

            // Step 5: POST to third-party API
            return postToThirdParty(datasourceJson, screeningId)
                    .thenAccept(v -> {
                        // Restore MDC context in async callback
                        if (mdcContext != null) {
                            MDC.setContextMap(mdcContext);
                        }
                        log.info("Successfully processed vendor response for ID: {}, CorrelationID: {}",
                                screeningId, CorrelationIdHolder.get());
                    });

        } catch (Exception e) {
            log.error("Failed to process vendor response for ID: {}, CorrelationID: {}",
                    screeningId, CorrelationIdHolder.get(), e);
            return CompletableFuture.failedFuture(e);
        }
    }


    /**
     * Posts JSON data to Recombo 360 API (third-party) asynchronously.
     *
     * @param jsonData the JSON payload
     * @param id       the screening ID (for logging)
     * @return CompletableFuture that completes when POST is successful
     */
    private CompletableFuture<Void> postToThirdParty(String jsonData, String id) {
        log.info("Posting data to Recombo 360 API for ID: {}", id);

        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");

        String recombo360Url = externalApiConfig.getRecombo360PostUrl();

        return httpClient.postAsync(recombo360Url, jsonData, headers)
                .thenAccept(response -> {
                    if (response.statusCode() >= 200 && response.statusCode() < 300) {
                        log.info("Successfully posted to Recombo 360 API - Status: {}, ID: {}",
                                response.statusCode(), id);
                    } else {
                        log.error("Recombo 360 API returned error - Status: {}, ID: {}",
                                response.statusCode(), id);
                        throw new HttpClientException("Recombo 360 API error: HTTP " + response.statusCode());
                    }
                });
    }
}

