package org.example.recombointegration.controller;

import org.example.recombointegration.dto.TransformRequest;
import org.example.recombointegration.dto.TransformResponse;
import org.example.recombointegration.exception.XmlTransformationException;
import org.example.recombointegration.exception.XmlValidationException;
import org.example.recombointegration.service.XmlTransformationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST Controller for XML to JSON transformation operations.
 * Provides endpoints for transforming Screening XML to JSON.
 * <p>
 * - Type-based transformation (education, employment)
 * <p>
 * Endpoints:
 * - POST /api/transform/xml-to-json - Transform XML to JSON
 * Request body: { "content": "<xml>", "type": "education|employment" }
 * If type is not specified, defaults to "education"
 *
 * @author Keshav Ladha
 */
@RestController
@RequestMapping("/api/transform")
public class TransformerController {

    private static final Logger logger = LoggerFactory.getLogger(TransformerController.class);

    private final XmlTransformationService xmlTransformationService;

    /**
     * Constructor with dependency injection.
     *
     * @param xmlTransformationService the XML transformation service
     */
    public TransformerController(XmlTransformationService xmlTransformationService) {
        this.xmlTransformationService = xmlTransformationService;
        logger.info("TransformerController initialized");
    }

    /**
     * Transforms XML to JSON (POST method).
     * Supports type-based transformation.
     *
     * @param request the transform request containing XML content and optional type
     * @return the transform response with JSON result
     */
    @PostMapping("/xml-to-json")
    public ResponseEntity<TransformResponse> transformXmlToJson(@RequestBody TransformRequest request) {
        logger.info("Received POST request to transform XML to JSON (type: {})", request.getType());
        logger.debug("Request: {}", request);

        try {
            logger.debug("Processing XML content (length: {} characters, type: {})",
                    request.getContent().length(), request.getType());
            String jsonResult = xmlTransformationService.transformXmlToJson(
                    request.getContent(),
                    request.getType()
            );

            logger.info("XML to JSON transformation completed successfully (type: {})", request.getType());

            return ResponseEntity.ok(TransformResponse.success(jsonResult));

        } catch (XmlValidationException e) {
            logger.error("XML validation failed: {}", e.getMessage());
            return ResponseEntity
                    .badRequest()
                    .body(TransformResponse.error(e.getErrorCode(), e.getMessage()));

        } catch (XmlTransformationException e) {
            logger.error("XML transformation failed: {}", e.getMessage());
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(TransformResponse.error(e.getErrorCode(), e.getMessage()));

        } catch (Exception e) {
            logger.error("Unexpected error during transformation", e);
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(TransformResponse.error("INTERNAL_ERROR", "An unexpected error occurred"));
        }
    }

}