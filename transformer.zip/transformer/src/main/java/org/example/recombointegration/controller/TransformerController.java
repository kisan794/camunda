package org.example.recombointegration.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.example.recombointegration.dto.TransformRequest;
import org.example.recombointegration.dto.TransformResponse;
import org.example.recombointegration.exception.XmlTransformationException;
import org.example.recombointegration.exception.XmlValidationException;
import org.example.recombointegration.service.XmlTransformationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.example.recombointegration.util.Constant.BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH;

/**
 * REST Controller for XML to JSON transformation operations.
 * Provides endpoints for transforming Screening XML to JSON.
 * <p>
 * - Type-based transformation (education, employment)
 * <p>
 * Endpoints:
 * - POST /api/transform/xml-to-json - Transform XML to JSON
 * Request body: { "content": "<xml>", "type": "education|employment" }
 * If type is not specified, defaults to "education"
 *
 * @author Keshav Ladha
 */
@Tag(name = "XML Transformation", description = "APIs for transforming XML screening data to JSON format")
@RestController
@RequestMapping(BASE_SOURCE_INTELLIGENCE_SERVICE_V1_API_PATH)
public class TransformerController {

    private static final Logger logger = LoggerFactory.getLogger(TransformerController.class);

    private final XmlTransformationService xmlTransformationService;

    /**
     * Constructor with dependency injection.
     *
     * @param xmlTransformationService the XML transformation service
     */
    public TransformerController(XmlTransformationService xmlTransformationService) {
        this.xmlTransformationService = xmlTransformationService;
        logger.info("TransformerController initialized");
    }

    /**
     * Transforms XML to JSON (POST method).
     * Supports type-based transformation.
     *
     * @param request the transform request containing XML content and optional type
     * @return the transform response with JSON result
     */
    @Operation(
            summary = "Transform XML to JSON",
            description = """
                    Transforms screening XML data to JSON format.
                    
                    Supports two screening types:
                    - **education**: Education verification screening
                    - **employment**: Employment verification screening
                    
                    If type is not specified, defaults to 'education'.
                    
                    The XML content should be a valid screening XML document.
                    """
    )
    @PostMapping(value = "/transform/xml-to-json", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TransformResponse> transformXmlToJson(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Transform request with XML content and screening type",
                    required = true,
                    content = @Content(
                            mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = TransformRequest.class),
                            examples = {
                                    @ExampleObject(
                                            name = "Education Screening",
                                            value = """
                                                    {
                                                      "content": "<EducationScreeningList>...</EducationScreeningList>",
                                                      "type": "education"
                                                    }
                                                    """
                                    ),
                                    @ExampleObject(
                                            name = "Employment Screening",
                                            value = """
                                                    {
                                                      "content": "<EmploymentScreeningList>...</EmploymentScreeningList>",
                                                      "type": "employment"
                                                    }
                                                    """
                                    )
                            }
                    )
            )
            @RequestBody TransformRequest request) {
        logger.info("Received POST request to transform XML to JSON (type: {})", request.getType());
        logger.debug("Request: {}", request);

        try {
            logger.debug("Processing XML content (length: {} characters, type: {})",
                    request.getContent().length(), request.getType());
            String jsonResult = xmlTransformationService.transformXmlToJson(
                    request.getContent(),
                    request.getType()
            );

            logger.info("XML to JSON transformation completed successfully (type: {})", request.getType());

            return ResponseEntity.ok(TransformResponse.success(jsonResult));

        } catch (XmlValidationException e) {
            logger.error("XML validation failed: {}", e.getMessage());
            return ResponseEntity
                    .badRequest()
                    .body(TransformResponse.error(e.getErrorCode(), e.getMessage()));

        } catch (XmlTransformationException e) {
            logger.error("XML transformation failed: {}", e.getMessage());
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(TransformResponse.error(e.getErrorCode(), e.getMessage()));

        } catch (Exception e) {
            logger.error("Unexpected error during transformation", e);
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(TransformResponse.error("INTERNAL_ERROR", "An unexpected error occurred"));
        }
    }

}