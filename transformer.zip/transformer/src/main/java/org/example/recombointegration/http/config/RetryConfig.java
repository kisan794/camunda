package org.example.recombointegration.http.config;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Spring-managed configuration for HTTP retry logic.
 * Defines retry behavior for transient errors.
 * Properties are loaded from application.properties.
 * Only active when http.client.retry.enabled=true.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Getter
@Component
@ConditionalOnProperty(name = "http.client.retry.enabled", havingValue = "true", matchIfMissing = true)
public class RetryConfig {

    @Value("${http.client.retry.max-attempts:3}")
    private int maxAttempts;

    @Value("${http.client.retry.initial-delay-ms:500}")
    private long initialDelayMs;

    @Value("${http.client.retry.max-delay-seconds:10}")
    private long maxDelaySeconds;

    @Value("${http.client.retry.backoff-multiplier:2.0}")
    private double backoffMultiplier;

    @Value("${http.client.retry.retryable-status-codes:408,429,500,502,503,504}")
    private String retryableStatusCodesString;

    /**
     * Validates the configuration after properties are injected.
     */
    @PostConstruct
    public void init() {
        // Validate
        if (maxAttempts < 1) {
            throw new IllegalStateException("Max attempts must be at least 1");
        }
        if (initialDelayMs < 0) {
            throw new IllegalStateException("Initial delay must be non-negative");
        }
        if (maxDelaySeconds < 0) {
            throw new IllegalStateException("Max delay must be non-negative");
        }
        if (backoffMultiplier < 1.0) {
            throw new IllegalStateException("Backoff multiplier must be at least 1.0");
        }

        log.info("RetryConfig initialized - maxAttempts: {}, initialDelay: {}ms, maxDelay: {}s, backoffMultiplier: {}, retryableStatusCodes: {}",
                maxAttempts, initialDelayMs, maxDelaySeconds, backoffMultiplier, retryableStatusCodesString);
    }

    /**
     * Gets the initial delay before the first retry.
     *
     * @return initial delay duration
     */
    public Duration getInitialDelay() {
        return Duration.ofMillis(initialDelayMs);
    }

    /**
     * Gets the maximum delay between retries.
     *
     * @return max delay duration
     */
    public Duration getMaxDelay() {
        return Duration.ofSeconds(maxDelaySeconds);
    }

    /**
     * Gets the set of retryable HTTP status codes.
     *
     * @return set of retryable status codes
     */
    public Set<Integer> getRetryableStatusCodes() {
        return Arrays.stream(retryableStatusCodesString.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(Integer::parseInt)
                .collect(Collectors.toSet());
    }

    /**
     * Checks if a status code is retryable.
     *
     * @param statusCode the HTTP status code
     * @return true if the status code is retryable, false otherwise
     */
    public boolean isRetryable(int statusCode) {
        return getRetryableStatusCodes().contains(statusCode);
    }
}

