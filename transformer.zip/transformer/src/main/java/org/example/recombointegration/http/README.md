# HTTP/2 Client for Spring Boot

A production-ready HTTP/2 client for Spring Boot applications using Java 21 and the standard `java.net.http.HttpClient` API.

## Features

- ✅ **HTTP/2 Protocol Support** - Uses HTTP/2 by default with automatic fallback
- ✅ **Spring Boot Integration** - Fully integrated as a Spring-managed service
- ✅ **Property-Based Configuration** - Configure via `application.properties`
- ✅ **JWT Authentication (HMAC)** - Built-in JWT token generation and management
- ✅ **Automatic Retry Logic** - Exponential backoff for transient errors
- ✅ **Sync & Async Execution** - Both synchronous and asynchronous request modes
- ✅ **Dependency Injection Ready** - Just `@Autowire` and use

## Architecture

```
http/
├── auth/
│   └── JwtAuthenticationProvider.java    # JWT token generation
├── client/
│   ├── Http2Client.java                  # Core HTTP/2 client
│   └── Http2ClientService.java           # Spring service wrapper
├── config/
│   ├── HttpClientConfig.java             # HTTP client settings
│   ├── JwtConfig.java                    # JWT configuration
│   └── RetryConfig.java                  # Retry policy settings
├── exception/
│   ├── HttpClientException.java          # Base exception
│   ├── HttpRetryExhaustedException.java  # Retry exhausted exception
│   └── JwtAuthenticationException.java   # JWT auth exception
└── retry/
    └── RetryHandler.java                 # Retry logic with exponential backoff
```

## Quick Start

### Step 1: Inject the HTTP Client Service

Simply autowire `Http2ClientService` in any Spring component:

```java
@Service
public class MyService {

    @Autowired
    private Http2ClientService httpClient;

    public void callExternalApi() {
        // Synchronous GET request
        HttpResponse<String> response = httpClient.get("https://api.example.com/data");
        System.out.println("Response: " + response.body());

        // Asynchronous POST request
        httpClient.postAsync("https://api.example.com/data", "{\"key\":\"value\"}")
            .thenAccept(resp -> System.out.println("Async response: " + resp.body()));
    }
}
```

### Step 2: Configure via application.properties

```properties
# Connection timeouts
http.client.connect-timeout=10
http.client.request-timeout=30

# Enable retry on failures
http.client.retry.enabled=true
http.client.retry.max-attempts=3

# Optional: Enable JWT authentication
http.client.jwt.enabled=true
http.client.jwt.secret-key=your-secret-key-here
```

That's it! The HTTP client is automatically configured and ready to use.

## Configuration

All configuration is done via `application.properties` - no code changes needed!

### Available Properties

```properties
# Connection Timeouts (in seconds)
http.client.connect-timeout=10
http.client.request-timeout=30

# Retry Configuration
http.client.retry.enabled=true
http.client.retry.max-attempts=3

# JWT Authentication (optional)
http.client.jwt.enabled=false
http.client.jwt.secret-key=your-256-bit-secret-key-must-be-at-least-32-characters-long
http.client.jwt.issuer=recombo-integration
http.client.jwt.subject=microservice
http.client.jwt.expiration-hours=1
```

### Environment-Specific Configuration

Use Spring profiles for different environments:

**application-dev.properties**
```properties
http.client.connect-timeout=5
http.client.retry.max-attempts=2
http.client.jwt.enabled=false
```

**application-prod.properties**
```properties
http.client.connect-timeout=15
http.client.retry.max-attempts=5
http.client.jwt.enabled=true
http.client.jwt.secret-key=${JWT_SECRET_KEY}
```

## Usage Examples

All examples use the Spring-managed `Http2ClientService` injected via `@Autowired`.

### Synchronous Requests

```java
@Service
public class ApiService {

    @Autowired
    private Http2ClientService httpClient;

    public void makeRequests() {
        // GET request
        HttpResponse<String> response = httpClient.get("https://api.example.com/users");

        // GET with custom headers
        Map<String, String> headers = Map.of("X-Custom-Header", "value");
        HttpResponse<String> response = httpClient.get("https://api.example.com/users", headers);

        // POST request
        String jsonBody = "{\"name\":\"John\",\"email\":\"john@example.com\"}";
        HttpResponse<String> response = httpClient.post("https://api.example.com/users", jsonBody);

        // PUT request
        HttpResponse<String> response = httpClient.put("https://api.example.com/users/123", jsonBody);

        // DELETE request
        HttpResponse<String> response = httpClient.delete("https://api.example.com/users/123");
    }
}
```

### Asynchronous Requests

```java
@Service
public class AsyncApiService {

    @Autowired
    private Http2ClientService httpClient;

    public CompletableFuture<String> fetchDataAsync() {
        // Async GET request
        return httpClient.getAsync("https://api.example.com/users")
            .thenApply(response -> {
                log.info("Status: {}", response.statusCode());
                return response.body();
            })
            .exceptionally(throwable -> {
                log.error("Request failed: {}", throwable.getMessage());
                return null;
            });
    }

    public void chainRequests() {
        // Chaining multiple async requests
        httpClient.getAsync("https://api.example.com/users/123")
            .thenCompose(response -> {
                String userId = parseUserId(response.body());
                return httpClient.getAsync("https://api.example.com/orders?userId=" + userId);
            })
            .thenAccept(orders -> log.info("Orders: {}", orders.body()));
    }
}
```

### With Custom Headers

```java
@Service
public class SecureApiService {

    @Autowired
    private Http2ClientService httpClient;

    public void callSecureApi() {
        Map<String, String> headers = new HashMap<>();
        headers.put("X-API-Key", "your-api-key");
        headers.put("X-Request-ID", UUID.randomUUID().toString());

        HttpResponse<String> response = httpClient.get("https://api.example.com/data", headers);
    }
}
```

## Retry Logic

The retry handler automatically retries requests for:

- **Retryable HTTP Status Codes**: 408, 429, 500, 502, 503, 504
- **Network Errors**: IOException, HttpTimeoutException, HttpConnectTimeoutException
- **Exponential Backoff**: Delay increases exponentially between retries

```java
RetryConfig retryConfig = new RetryConfig()
    .setMaxAttempts(5)                              // Max 5 attempts
    .setInitialDelay(Duration.ofMillis(500))        // Start with 500ms delay
    .setMaxDelay(Duration.ofSeconds(10))            // Cap at 10 seconds
    .setBackoffMultiplier(2.0);                     // Double delay each time

// Retry delays: 500ms, 1s, 2s, 4s, 8s (capped at 10s)
```

## JWT Authentication

The client automatically adds JWT tokens to requests when configured:

```java
JwtConfig jwtConfig = new JwtConfig()
    .setSecretKey("your-256-bit-secret-key")
    .setIssuer("my-microservice")
    .setSubject("api-client")
    .setExpirationTime(Duration.ofHours(1));

Http2Client client = Http2Client.builder()
    .jwtConfig(jwtConfig)
    .build();

// All requests will include: Authorization: Bearer <jwt-token>
HttpResponse<String> response = client.get("https://api.example.com/protected");
```

### Custom JWT Claims

```java
JwtAuthenticationProvider jwtProvider = new JwtAuthenticationProvider(jwtConfig);

Map<String, Object> customClaims = new HashMap<>();
customClaims.put("userId", "12345");
customClaims.put("role", "admin");

String token = jwtProvider.generateToken(customClaims);
```

## Error Handling

```java
try {
    HttpResponse<String> response = client.get("https://api.example.com/data");
    
    if (response.statusCode() == 200) {
        System.out.println("Success: " + response.body());
    } else {
        System.err.println("Error: " + response.statusCode());
    }
    
} catch (HttpRetryExhaustedException e) {
    System.err.println("All retry attempts failed: " + e.getMessage());
    System.err.println("Attempts made: " + e.getAttemptsMade());
    
} catch (JwtAuthenticationException e) {
    System.err.println("JWT authentication failed: " + e.getMessage());
    
} catch (HttpClientException e) {
    System.err.println("HTTP client error: " + e.getMessage());
    System.err.println("Error code: " + e.getErrorCode());
}
```

## Best Practices

1. **Reuse Client Instances**: Create one client instance and reuse it across requests
2. **Configure Timeouts**: Set appropriate timeouts based on your use case
3. **Use Async for I/O-Bound Operations**: Prefer async methods for better resource utilization
4. **Handle Errors Gracefully**: Always handle exceptions and check status codes
5. **Secure JWT Keys**: Store JWT secret keys in secure configuration (e.g., environment variables)
6. **Monitor Retry Metrics**: Log retry attempts to identify problematic endpoints

## Dependencies

The HTTP/2 client requires the following dependencies (already added to `build.gradle`):

```gradle
// JWT dependencies for HMAC authentication
implementation 'io.jsonwebtoken:jjwt-api:0.12.6'
runtimeOnly 'io.jsonwebtoken:jjwt-impl:0.12.6'
runtimeOnly 'io.jsonwebtoken:jjwt-jackson:0.12.6'
```

## License

This HTTP/2 client utility is part of the Recombo Integration project.

## Author

Keshav Ladha - Version 1.0

