package org.example.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * DTO for vendor API response containing HRG request and encoded XML data.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VendorResponse {

    /**
     * HRG request data as JSON object.
     */
    @JsonProperty("hrgRequest")
    private Map<String, Object> hrgRequest;

    /**
     * Attachment information.
     */
    @JsonProperty("attachment")
    private String attachment;

    /**
     * Request type (e.g., "application/xml").
     */
    @JsonProperty("requestType")
    private String requestType;

    /**
     * Base64 encoded XML data.
     */
    @JsonProperty("encode")
    private String encode;
}

