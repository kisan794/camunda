package org.example.recombointegration.service;

import org.example.recombointegration.exception.XmlTransformationException;
import org.example.recombointegration.service.impl.EducationScreeningXmlToJsonConverter;
import org.example.recombointegration.service.impl.EmploymentScreeningXmlToJsonConverter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for XmlConverterFactory.
 * Tests automatic converter registration and type-based selection.
 */
class XmlConverterFactoryTest {

    private XmlConverterFactory factory;
    private EducationScreeningXmlToJsonConverter educationConverter;
    private EmploymentScreeningXmlToJsonConverter employmentConverter;

    @BeforeEach
    void setUp() {
        educationConverter = new EducationScreeningXmlToJsonConverter();
        employmentConverter = new EmploymentScreeningXmlToJsonConverter();
        
        List<XmlToJsonConverter> converters = Arrays.asList(
                educationConverter,
                employmentConverter
        );
        
        factory = new XmlConverterFactory(converters);
    }

    @Test
    void testAutoRegistration_ShouldRegisterAllConverters() {
        // When
        ScreeningType[] supportedTypes = factory.getSupportedTypes();

        // Then
        assertEquals(2, supportedTypes.length);
        assertTrue(Arrays.asList(supportedTypes).contains(ScreeningType.EDUCATION));
        assertTrue(Arrays.asList(supportedTypes).contains(ScreeningType.EMPLOYMENT));
    }

    @Test
    void testGetConverter_WithEducationType_ShouldReturnEducationConverter() {
        // When
        XmlToJsonConverter converter = factory.getConverter("education");

        // Then
        assertNotNull(converter);
        assertEquals(ScreeningType.EDUCATION, converter.getType());
        assertInstanceOf(EducationScreeningXmlToJsonConverter.class, converter);
    }

    @Test
    void testGetConverter_WithEmploymentType_ShouldReturnEmploymentConverter() {
        // When
        XmlToJsonConverter converter = factory.getConverter("employment");

        // Then
        assertNotNull(converter);
        assertEquals(ScreeningType.EMPLOYMENT, converter.getType());
        assertInstanceOf(EmploymentScreeningXmlToJsonConverter.class, converter);
    }

    @Test
    void testGetConverter_WithUpperCase_ShouldWork() {
        // When
        XmlToJsonConverter converter = factory.getConverter("EDUCATION");

        // Then
        assertNotNull(converter);
        assertEquals(ScreeningType.EDUCATION, converter.getType());
    }

    @Test
    void testGetConverter_WithMixedCase_ShouldWork() {
        // When
        XmlToJsonConverter converter = factory.getConverter("EmPlOyMeNt");

        // Then
        assertNotNull(converter);
        assertEquals(ScreeningType.EMPLOYMENT, converter.getType());
    }

    @Test
    void testGetConverter_WithWhitespace_ShouldWork() {
        // When
        XmlToJsonConverter converter = factory.getConverter("  education  ");

        // Then
        assertNotNull(converter);
        assertEquals(ScreeningType.EDUCATION, converter.getType());
    }

    @Test
    void testGetConverter_WithNullType_ShouldReturnDefaultEducation() {
        // When
        XmlToJsonConverter converter = factory.getConverter((String) null);

        // Then
        assertNotNull(converter);
        assertEquals(ScreeningType.EDUCATION, converter.getType());
    }

    @Test
    void testGetConverter_WithEmptyType_ShouldReturnDefaultEducation() {
        // When
        XmlToJsonConverter converter = factory.getConverter("");

        // Then
        assertNotNull(converter);
        assertEquals(ScreeningType.EDUCATION, converter.getType());
    }

    @Test
    void testGetConverter_WithInvalidType_ShouldThrowException() {
        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> factory.getConverter("invalid_type")
        );

        assertEquals("UNSUPPORTED_TYPE", exception.getErrorCode());
        assertTrue(exception.getMessage().contains("invalid_type"));
        assertTrue(exception.getMessage().contains("education"));
        assertTrue(exception.getMessage().contains("employment"));
    }

    @Test
    void testGetConverter_WithScreeningTypeEnum_ShouldWork() {
        // When
        XmlToJsonConverter converter = factory.getConverter(ScreeningType.EDUCATION);

        // Then
        assertNotNull(converter);
        assertEquals(ScreeningType.EDUCATION, converter.getType());
    }

    @Test
    void testIsTypeSupported_WithValidType_ShouldReturnTrue() {
        // When & Then
        assertTrue(factory.isTypeSupported("education"));
        assertTrue(factory.isTypeSupported("employment"));
        assertTrue(factory.isTypeSupported("EDUCATION"));
        assertTrue(factory.isTypeSupported("  employment  "));
    }

    @Test
    void testIsTypeSupported_WithInvalidType_ShouldReturnFalse() {
        // When & Then
        assertFalse(factory.isTypeSupported("invalid"));
        assertFalse(factory.isTypeSupported("criminal"));
        assertFalse(factory.isTypeSupported("xyz"));
    }

    @Test
    void testGetSupportedTypesString_ShouldReturnAllTypes() {
        // When
        String supportedTypes = factory.getSupportedTypesString();

        // Then
        assertNotNull(supportedTypes);
        assertTrue(supportedTypes.contains("education"));
        assertTrue(supportedTypes.contains("employment"));
    }

    @Test
    void testConverterSelfIdentification_EducationConverter() {
        // When
        ScreeningType type = educationConverter.getType();

        // Then
        assertEquals(ScreeningType.EDUCATION, type);
    }

    @Test
    void testConverterSelfIdentification_EmploymentConverter() {
        // When
        ScreeningType type = employmentConverter.getType();

        // Then
        assertEquals(ScreeningType.EMPLOYMENT, type);
    }

    @Test
    void testFactoryWithSingleConverter_ShouldWork() {
        // Given
        List<XmlToJsonConverter> singleConverter = Arrays.asList(educationConverter);
        XmlConverterFactory singleFactory = new XmlConverterFactory(singleConverter);

        // When
        ScreeningType[] types = singleFactory.getSupportedTypes();

        // Then
        assertEquals(1, types.length);
        assertEquals(ScreeningType.EDUCATION, types[0]);
    }

    @Test
    void testFactoryWithEmptyList_ShouldHandleGracefully() {
        // Given
        List<XmlToJsonConverter> emptyList = Arrays.asList();
        XmlConverterFactory emptyFactory = new XmlConverterFactory(emptyList);

        // When
        ScreeningType[] types = emptyFactory.getSupportedTypes();

        // Then
        assertEquals(0, types.length);
    }
}

