package org.example.recombointegration.service.impl;

import org.example.recombointegration.exception.XmlValidationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for SimpleXmlValidator.
 * Tests XML validation logic and security features.
 */
class SimpleXmlValidatorTest {

    private SimpleXmlValidator validator;

    @BeforeEach
    void setUp() {
        validator = new SimpleXmlValidator();
    }

    @Test
    void testGetValidationError_WithValidXml_ShouldReturnNull() {
        // Given
        String validXml = "<root><child>value</child></root>";

        // When
        String error = validator.getValidationError(validXml);

        // Then
        assertNull(error);
    }

    @Test
    void testGetValidationError_WithValidComplexXml_ShouldReturnNull() {
        // Given
        String validXml = "<EducationScreeningList>\n" +
                "    <EducationScreening>\n" +
                "        <Screening type=\"education\">\n" +
                "            <EducationVerificationReport>\n" +
                "                <EducationResult>\n" +
                "                    <School>\n" +
                "                        <SchoolName>Test University</SchoolName>\n" +
                "                    </School>\n" +
                "                </EducationResult>\n" +
                "            </EducationVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EducationScreening>\n" +
                "</EducationScreeningList>";

        // When
        String error = validator.getValidationError(validXml);

        // Then
        assertNull(error);
    }

    @Test
    void testGetValidationError_WithNullXml_ShouldReturnError() {
        // When
        String error = validator.getValidationError(null);

        // Then
        assertNotNull(error);
        assertTrue(error.contains("cannot be null or empty"));
    }

    @Test
    void testGetValidationError_WithEmptyXml_ShouldReturnError() {
        // When
        String error = validator.getValidationError("");

        // Then
        assertNotNull(error);
        assertTrue(error.contains("cannot be null or empty"));
    }

    @Test
    void testGetValidationError_WithWhitespaceOnlyXml_ShouldReturnError() {
        // When
        String error = validator.getValidationError("   \n\t  ");

        // Then
        assertNotNull(error);
        assertTrue(error.contains("cannot be null or empty"));
    }

    @Test
    void testGetValidationError_WithMalformedXml_ShouldReturnError() {
        // Given
        String malformedXml = "<root><unclosed>";

        // When
        String error = validator.getValidationError(malformedXml);

        // Then
        assertNotNull(error);
    }

    @Test
    void testGetValidationError_WithValidEscapedCharacters_ShouldReturnNull() {
        // Given
        String validXml = "<root>Valid &amp; &lt; &gt; &quot; &apos; characters</root>";

        // When
        String error = validator.getValidationError(validXml);

        // Then
        assertNull(error);
    }

    @Test
    void testGetValidationError_WithXmlDeclaration_ShouldReturnNull() {
        // Given
        String xmlWithDeclaration = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<root><child>value</child></root>";

        // When
        String error = validator.getValidationError(xmlWithDeclaration);

        // Then
        assertNull(error);
    }

    @Test
    void testGetValidationError_WithNamespaces_ShouldReturnNull() {
        // Given
        String xmlWithNamespace = "<root xmlns=\"http://example.com/ns\">\n" +
                "    <child>value</child>\n" +
                "</root>";

        // When
        String error = validator.getValidationError(xmlWithNamespace);

        // Then
        assertNull(error);
    }

    @Test
    void testGetValidationError_WithAttributes_ShouldReturnNull() {
        // Given
        String xmlWithAttributes = "<root attr1=\"value1\" attr2=\"value2\">\n" +
                "    <child id=\"123\">value</child>\n" +
                "</root>";

        // When
        String error = validator.getValidationError(xmlWithAttributes);

        // Then
        assertNull(error);
    }

    @Test
    void testGetValidationError_WithCDATA_ShouldReturnNull() {
        // Given
        String xmlWithCDATA = "<root><![CDATA[Some <special> content]]></root>";

        // When
        String error = validator.getValidationError(xmlWithCDATA);

        // Then
        assertNull(error);
    }

    @Test
    void testGetValidationError_WithComments_ShouldReturnNull() {
        // Given
        String xmlWithComments = "<root><!-- This is a comment --><child>value</child></root>";

        // When
        String error = validator.getValidationError(xmlWithComments);

        // Then
        assertNull(error);
    }

    @Test
    void testValidateOrThrow_WithValidXml_ShouldNotThrow() {
        // Given
        String validXml = "<root><child>value</child></root>";

        // When & Then
        assertDoesNotThrow(() -> validator.validateOrThrow(validXml));
    }

    @Test
    void testValidateOrThrow_WithNullXml_ShouldThrowException() {
        // When & Then
        assertThrows(XmlValidationException.class, () -> validator.validateOrThrow(null));
    }

    @Test
    void testValidateOrThrow_WithEmptyXml_ShouldThrowException() {
        // When & Then
        assertThrows(XmlValidationException.class, () -> validator.validateOrThrow(""));
    }

    @Test
    void testValidateOrThrow_WithMalformedXml_ShouldThrowException() {
        // Given
        String malformedXml = "<root><unclosed>";

        // When & Then
        assertThrows(XmlValidationException.class, () -> validator.validateOrThrow(malformedXml));
    }

    @Test
    void testValidateOrThrow_WithNestedElements_ShouldNotThrow() {
        // Given
        String nestedXml = "<root>\n" +
                "    <level1>\n" +
                "        <level2>\n" +
                "            <level3>value</level3>\n" +
                "        </level2>\n" +
                "    </level1>\n" +
                "</root>";

        // When & Then
        assertDoesNotThrow(() -> validator.validateOrThrow(nestedXml));
    }

    @Test
    void testValidateOrThrow_WithEmptyElements_ShouldNotThrow() {
        // Given
        String emptyElements = "<root><empty/><another></another></root>";

        // When & Then
        assertDoesNotThrow(() -> validator.validateOrThrow(emptyElements));
    }

    @Test
    void testValidateOrThrow_WithLargeXml_ShouldWork() {
        // Given
        StringBuilder largeXml = new StringBuilder("<root>");
        for (int i = 0; i < 1000; i++) {
            largeXml.append("<item id=\"").append(i).append("\">value</item>");
        }
        largeXml.append("</root>");

        // When & Then
        assertDoesNotThrow(() -> validator.validateOrThrow(largeXml.toString()));
    }

    @Test
    void testValidateOrThrow_WithSpecialCharactersInContent_ShouldNotThrow() {
        // Given
        String xmlWithSpecialChars = "<root>Special chars: &lt; &gt; &amp; &quot; &apos;</root>";

        // When & Then
        assertDoesNotThrow(() -> validator.validateOrThrow(xmlWithSpecialChars));
    }

    @Test
    void testValidateOrThrow_WithUnicodeCharacters_ShouldNotThrow() {
        // Given
        String xmlWithUnicode = "<root>Unicode: 你好 مرحبا Привет</root>";

        // When & Then
        assertDoesNotThrow(() -> validator.validateOrThrow(xmlWithUnicode));
    }

    @Test
    void testGetValidationError_WithProcessingInstructions_ShouldReturnNull() {
        // Given
        String xmlWithPI = "<?xml version=\"1.0\"?>\n" +
                "<?xml-stylesheet type=\"text/xsl\" href=\"style.xsl\"?>\n" +
                "<root><child>value</child></root>";

        // When
        String error = validator.getValidationError(xmlWithPI);

        // Then
        assertNull(error);
    }
}

