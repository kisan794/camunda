package org.example.recombointegration.exception;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for XmlValidationException.
 * Tests all constructors and methods of the custom exception.
 */
class XmlValidationExceptionTest {

    @Test
    void testConstructor_WithMessage_ShouldSetDefaultErrorCode() {
        // Given
        String message = "XML validation failed";

        // When
        XmlValidationException exception = new XmlValidationException(message);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals("XML_VALIDATION_ERROR", exception.getErrorCode());
        assertNull(exception.getValidationErrors());
        assertNull(exception.getCause());
    }

    @Test
    void testConstructor_WithMessageAndCause_ShouldSetDefaultErrorCode() {
        // Given
        String message = "XML validation failed";
        Throwable cause = new IllegalArgumentException("Invalid XML");

        // When
        XmlValidationException exception = new XmlValidationException(message, cause);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals("XML_VALIDATION_ERROR", exception.getErrorCode());
        assertNull(exception.getValidationErrors());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testConstructor_WithErrorCodeMessageAndValidationErrors_ShouldSetAllFields() {
        // Given
        String errorCode = "CUSTOM_VALIDATION_ERROR";
        String message = "Custom validation failed";
        Map<String, String> validationErrors = new HashMap<>();
        validationErrors.put("field1", "error1");
        validationErrors.put("field2", "error2");

        // When
        XmlValidationException exception = new XmlValidationException(errorCode, message, validationErrors);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals(errorCode, exception.getErrorCode());
        assertEquals(validationErrors, exception.getValidationErrors());
        assertNull(exception.getCause());
    }

    @Test
    void testConstructor_WithNullValidationErrors_ShouldHandleGracefully() {
        // Given
        String errorCode = "NULL_VALIDATION_ERROR";
        String message = "Validation failed with null errors";

        // When
        XmlValidationException exception = new XmlValidationException(errorCode, message, null);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals(errorCode, exception.getErrorCode());
        assertNull(exception.getValidationErrors());
    }

    @Test
    void testGetErrorCode_ShouldReturnCorrectCode() {
        // Given
        XmlValidationException exception = new XmlValidationException("CUSTOM_CODE", "Test message", null);

        // When
        String errorCode = exception.getErrorCode();

        // Then
        assertEquals("CUSTOM_CODE", errorCode);
    }

    @Test
    void testGetValidationErrors_ShouldReturnCorrectErrors() {
        // Given
        Map<String, String> errors = new HashMap<>();
        errors.put("name", "Name is required");
        errors.put("age", "Age must be positive");
        XmlValidationException exception = new XmlValidationException("VALIDATION_ERROR", "Validation failed", errors);

        // When
        Object validationErrors = exception.getValidationErrors();

        // Then
        assertNotNull(validationErrors);
        assertEquals(errors, validationErrors);
    }

    @Test
    void testException_IsRuntimeException() {
        // Given
        XmlValidationException exception = new XmlValidationException("Test message");

        // Then
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testException_CanBeThrown() {
        // When & Then
        assertThrows(XmlValidationException.class, () -> {
            throw new XmlValidationException("Test exception");
        });
    }

    @Test
    void testException_WithComplexValidationErrors() {
        // Given
        Map<String, Object> complexErrors = new HashMap<>();
        complexErrors.put("field1", "Simple error");
        complexErrors.put("field2", Map.of("nested", "Nested error"));
        complexErrors.put("field3", java.util.Arrays.asList("error1", "error2", "error3"));

        // When
        XmlValidationException exception = new XmlValidationException(
                "COMPLEX_VALIDATION_ERROR",
                "Complex validation failed",
                complexErrors
        );

        // Then
        assertEquals("COMPLEX_VALIDATION_ERROR", exception.getErrorCode());
        assertEquals(complexErrors, exception.getValidationErrors());
        assertTrue(((Map<?, ?>) exception.getValidationErrors()).containsKey("field1"));
        assertTrue(((Map<?, ?>) exception.getValidationErrors()).containsKey("field2"));
        assertTrue(((Map<?, ?>) exception.getValidationErrors()).containsKey("field3"));
    }

    @Test
    void testException_WithEmptyMessage() {
        // Given
        String emptyMessage = "";

        // When
        XmlValidationException exception = new XmlValidationException(emptyMessage);

        // Then
        assertEquals(emptyMessage, exception.getMessage());
        assertEquals("XML_VALIDATION_ERROR", exception.getErrorCode());
    }

    @Test
    void testException_WithNullMessage() {
        // Given & When
        XmlValidationException exception = new XmlValidationException(null);

        // Then
        assertNull(exception.getMessage());
        assertEquals("XML_VALIDATION_ERROR", exception.getErrorCode());
    }

    @Test
    void testException_SerializableFields() {
        // Given
        XmlValidationException exception = new XmlValidationException(
                "TEST_CODE",
                "Test message",
                Map.of("key", "value")
        );

        // Then - Verify serialVersionUID exists (implicitly tested by compilation)
        assertNotNull(exception.getErrorCode());
        assertNotNull(exception.getValidationErrors());
    }

    @Test
    void testException_WithCauseChain() {
        // Given
        Throwable rootCause = new IllegalArgumentException("Root cause");
        Throwable intermediateCause = new RuntimeException("Intermediate cause", rootCause);
        String message = "XML validation failed";

        // When
        XmlValidationException exception = new XmlValidationException(message, intermediateCause);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals(intermediateCause, exception.getCause());
        assertEquals(rootCause, exception.getCause().getCause());
    }

    @Test
    void testException_MessageFormatting() {
        // Given
        String errorCode = "VALIDATION_001";
        String message = "Field 'username' is required and must be at least 3 characters";
        Map<String, String> errors = Map.of("username", "Too short");

        // When
        XmlValidationException exception = new XmlValidationException(errorCode, message, errors);

        // Then
        assertTrue(exception.getMessage().contains("username"));
        assertTrue(exception.getMessage().contains("required"));
        assertEquals(errorCode, exception.getErrorCode());
    }
}

