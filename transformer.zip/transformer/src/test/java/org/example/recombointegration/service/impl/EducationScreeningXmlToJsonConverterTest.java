package org.example.recombointegration.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.recombointegration.exception.XmlTransformationException;
import org.example.recombointegration.service.ScreeningType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for EducationScreeningXmlToJsonConverter.
 * Tests the conversion of Education Screening XML to JSON format.
 */
class EducationScreeningXmlToJsonConverterTest {

    private EducationScreeningXmlToJsonConverter converter;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        converter = new EducationScreeningXmlToJsonConverter();
        objectMapper = new ObjectMapper();
    }

    @Test
    void testGetType_ShouldReturnEducation() {
        // When
        ScreeningType type = converter.getType();

        // Then
        assertEquals(ScreeningType.EDUCATION, type);
    }

    @Test
    void testConvert_WithValidXml_ShouldReturnJson() throws Exception {
        // Given
        String xml = "<EducationScreeningList>\n" +
                "    <EducationScreening>\n" +
                "        <Screening type=\"education\" version=\"1\">\n" +
                "            <ProducerReferenceId idOwner=\"urn:hivp.hireright.com\">\n" +
                "                <IdValue name=\"OrderServiceNo\">OR-122024-CZ896-ED-001</IdValue>\n" +
                "                <IdValue name=\"ServiceId\">5</IdValue>\n" +
                "                <IdValue name=\"HRSchoolId\">12345</IdValue>\n" +
                "                <IdValue name=\"NSCHSchoolId\">67890</IdValue>\n" +
                "            </ProducerReferenceId>\n" +
                "            <EducationVerificationReport>\n" +
                "                <EducationResult>\n" +
                "                    <ContactInformation>\n" +
                "                        <PersonName>\n" +
                "                            <FormattedName>John Doe</FormattedName>\n" +
                "                        </PersonName>\n" +
                "                        <Title>Registrar</Title>\n" +
                "                    </ContactInformation>\n" +
                "                    <SchoolOrInstitution>\n" +
                "                        <SchoolName>Harvard University</SchoolName>\n" +
                "                        <Degree>\n" +
                "                            <DegreeName>Bachelor of Science</DegreeName>\n" +
                "                            <Received>Yes</Received>\n" +
                "                        </Degree>\n" +
                "                        <Major>Computer Science</Major>\n" +
                "                        <DatesOfAttendance>\n" +
                "                            <StartDate>\n" +
                "                                <AnyDate>2018-09-01</AnyDate>\n" +
                "                            </StartDate>\n" +
                "                            <EndDate>\n" +
                "                                <AnyDate>2022-06-15</AnyDate>\n" +
                "                            </EndDate>\n" +
                "                        </DatesOfAttendance>\n" +
                "                    </SchoolOrInstitution>\n" +
                "                </EducationResult>\n" +
                "            </EducationVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EducationScreening>\n" +
                "</EducationScreeningList>";

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        JsonNode jsonNode = objectMapper.readTree(json);

        // Verify root structure
        assertEquals("NSCH", jsonNode.get("name").asText());
        assertEquals("education", jsonNode.get("type").asText());
        assertTrue(jsonNode.has("screening"));

        // Verify screening array
        JsonNode screening = jsonNode.get("screening");
        assertTrue(screening.isArray());
        assertEquals(1, screening.size());

        // Verify first screening
        JsonNode firstScreening = screening.get(0);
        assertEquals("OR-122024-CZ896-ED-001", firstScreening.get("orderServiceNo").asText());
        assertEquals("5", firstScreening.get("serviceId").asText());
        assertEquals("12345", firstScreening.get("hrSchoolId").asText());
        assertEquals("67890", firstScreening.get("nschSchoolId").asText());

        // Verify contact
        JsonNode contact = firstScreening.get("contact");
        assertNotNull(contact);
        assertEquals("John Doe", contact.get("personName").asText());
        assertEquals("Registrar", contact.get("title").asText());

        // Verify institution
        JsonNode institution = firstScreening.get("institution");
        assertNotNull(institution);
        assertEquals("Harvard University", institution.get("name").asText());

        // Verify programs
        JsonNode programs = institution.get("programs");
        assertTrue(programs.isArray());
        assertEquals(1, programs.size());

        JsonNode program = programs.get(0);
        assertTrue(program.get("verificationRequired").asBoolean());
        assertEquals("Bachelor of Science", program.get("degree").asText());
        assertEquals("Computer Science", program.get("major").asText());

        // Verify tenure
        JsonNode tenure = program.get("tenure");
        assertNotNull(tenure);
        assertEquals("2018-09-01", tenure.get("startDate").asText());
        assertEquals("2022-06-15", tenure.get("endDate").asText());
        assertFalse(tenure.get("current").asBoolean());
    }

    @Test
    void testConvert_WithMultipleScreenings_ShouldReturnAllScreenings() throws Exception {
        // Given
        String xml = "<EducationScreeningList>\n" +
                "    <EducationScreening>\n" +
                "        <Screening type=\"education\" version=\"1\">\n" +
                "            <ProducerReferenceId idOwner=\"urn:hivp.hireright.com\">\n" +
                "                <IdValue name=\"OrderServiceNo\">OR-001</IdValue>\n" +
                "                <IdValue name=\"ServiceId\">1</IdValue>\n" +
                "                <IdValue name=\"HRSchoolId\">111</IdValue>\n" +
                "                <IdValue name=\"NSCHSchoolId\">222</IdValue>\n" +
                "            </ProducerReferenceId>\n" +
                "            <EducationVerificationReport>\n" +
                "                <EducationResult>\n" +
                "                    <ContactInformation>\n" +
                "                        <PersonName>\n" +
                "                            <FormattedName>Jane Smith</FormattedName>\n" +
                "                        </PersonName>\n" +
                "                        <Title>Dean</Title>\n" +
                "                    </ContactInformation>\n" +
                "                    <SchoolOrInstitution>\n" +
                "                        <SchoolName>MIT</SchoolName>\n" +
                "                        <Degree>\n" +
                "                            <DegreeName>Master of Science</DegreeName>\n" +
                "                            <Received>Yes</Received>\n" +
                "                        </Degree>\n" +
                "                        <Major>Engineering</Major>\n" +
                "                        <DatesOfAttendance>\n" +
                "                            <StartDate>\n" +
                "                                <AnyDate>2020-01-01</AnyDate>\n" +
                "                            </StartDate>\n" +
                "                            <EndDate>\n" +
                "                                <AnyDate>2022-12-31</AnyDate>\n" +
                "                            </EndDate>\n" +
                "                        </DatesOfAttendance>\n" +
                "                    </SchoolOrInstitution>\n" +
                "                </EducationResult>\n" +
                "            </EducationVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EducationScreening>\n" +
                "    <EducationScreening>\n" +
                "        <Screening type=\"education\" version=\"1\">\n" +
                "            <ProducerReferenceId idOwner=\"urn:hivp.hireright.com\">\n" +
                "                <IdValue name=\"OrderServiceNo\">OR-002</IdValue>\n" +
                "                <IdValue name=\"ServiceId\">2</IdValue>\n" +
                "                <IdValue name=\"HRSchoolId\">333</IdValue>\n" +
                "                <IdValue name=\"NSCHSchoolId\">444</IdValue>\n" +
                "            </ProducerReferenceId>\n" +
                "            <EducationVerificationReport>\n" +
                "                <EducationResult>\n" +
                "                    <ContactInformation>\n" +
                "                        <PersonName>\n" +
                "                            <FormattedName>Bob Johnson</FormattedName>\n" +
                "                        </PersonName>\n" +
                "                        <Title>Administrator</Title>\n" +
                "                    </ContactInformation>\n" +
                "                    <SchoolOrInstitution>\n" +
                "                        <SchoolName>Stanford University</SchoolName>\n" +
                "                        <Degree>\n" +
                "                            <DegreeName>PhD</DegreeName>\n" +
                "                            <Received>No</Received>\n" +
                "                        </Degree>\n" +
                "                        <Major>Physics</Major>\n" +
                "                        <DatesOfAttendance>\n" +
                "                            <StartDate>\n" +
                "                                <AnyDate>2015-09-01</AnyDate>\n" +
                "                            </StartDate>\n" +
                "                            <EndDate>\n" +
                "                                <AnyDate></AnyDate>\n" +
                "                            </EndDate>\n" +
                "                        </DatesOfAttendance>\n" +
                "                    </SchoolOrInstitution>\n" +
                "                </EducationResult>\n" +
                "            </EducationVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EducationScreening>\n" +
                "</EducationScreeningList>";

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        JsonNode jsonNode = objectMapper.readTree(json);

        JsonNode screening = jsonNode.get("screening");
        assertEquals(2, screening.size());

        // Verify first screening
        assertEquals("OR-001", screening.get(0).get("orderServiceNo").asText());
        assertEquals("MIT", screening.get(0).get("institution").get("name").asText());
        assertTrue(screening.get(0).get("institution").get("programs").get(0).get("verificationRequired").asBoolean());

        // Verify second screening
        assertEquals("OR-002", screening.get(1).get("orderServiceNo").asText());
        assertEquals("Stanford University", screening.get(1).get("institution").get("name").asText());
        assertFalse(screening.get(1).get("institution").get("programs").get(0).get("verificationRequired").asBoolean());
        
        // Verify current student (empty end date)
        assertTrue(screening.get(1).get("institution").get("programs").get(0).get("tenure").get("current").asBoolean());
    }

    @Test
    void testConvert_WithNullXml_ShouldThrowException() {
        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert(null)
        );

        assertEquals("XML_EMPTY", exception.getErrorCode());
        assertTrue(exception.getMessage().contains("XML content cannot be null or empty"));
    }

    @Test
    void testConvert_WithEmptyXml_ShouldThrowException() {
        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert("")
        );

        assertEquals("XML_EMPTY", exception.getErrorCode());
        assertTrue(exception.getMessage().contains("XML content cannot be null or empty"));
    }

    @Test
    void testConvert_WithWhitespaceXml_ShouldThrowException() {
        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert("   \n\t  ")
        );

        assertEquals("XML_EMPTY", exception.getErrorCode());
    }

    @Test
    void testConvert_WithInvalidXml_ShouldThrowException() {
        // Given
        String invalidXml = "<InvalidXml>";

        // When & Then
        XmlTransformationException exception = assertThrows(
                XmlTransformationException.class,
                () -> converter.convert(invalidXml)
        );

        assertEquals("JSON_CONVERSION_FAILED", exception.getErrorCode());
        assertTrue(exception.getMessage().contains("Failed to convert XML to JSON"));
    }

    @Test
    void testConvert_WithNullContactName_ShouldHandleGracefully() throws Exception {
        // Given
        String xml = "<EducationScreeningList>\n" +
                "    <EducationScreening>\n" +
                "        <Screening type=\"education\" version=\"1\">\n" +
                "            <ProducerReferenceId idOwner=\"urn:hivp.hireright.com\">\n" +
                "                <IdValue name=\"OrderServiceNo\">OR-003</IdValue>\n" +
                "                <IdValue name=\"ServiceId\">3</IdValue>\n" +
                "            </ProducerReferenceId>\n" +
                "            <EducationVerificationReport>\n" +
                "                <EducationResult>\n" +
                "                    <ContactInformation>\n" +
                "                        <PersonName>\n" +
                "                            <FormattedName></FormattedName>\n" +
                "                        </PersonName>\n" +
                "                        <Title></Title>\n" +
                "                    </ContactInformation>\n" +
                "                    <SchoolOrInstitution>\n" +
                "                        <SchoolName>Test University</SchoolName>\n" +
                "                        <Degree>\n" +
                "                            <DegreeName>BA</DegreeName>\n" +
                "                            <Received>Yes</Received>\n" +
                "                        </Degree>\n" +
                "                        <Major>History</Major>\n" +
                "                        <DatesOfAttendance>\n" +
                "                            <StartDate><AnyDate>2010-01-01</AnyDate></StartDate>\n" +
                "                            <EndDate><AnyDate>2014-12-31</AnyDate></EndDate>\n" +
                "                        </DatesOfAttendance>\n" +
                "                    </SchoolOrInstitution>\n" +
                "                </EducationResult>\n" +
                "            </EducationVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EducationScreening>\n" +
                "</EducationScreeningList>";

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        JsonNode jsonNode = objectMapper.readTree(json);
        JsonNode contact = jsonNode.get("screening").get(0).get("contact");

        assertTrue(contact.get("personName").isNull());
        assertTrue(contact.get("title").isNull());
    }

    @Test
    void testConvert_WithEmptyHRSchoolId_ShouldSetToNull() throws Exception {
        // Given
        String xml = "<EducationScreeningList>\n" +
                "    <EducationScreening>\n" +
                "        <Screening type=\"education\" version=\"1\">\n" +
                "            <ProducerReferenceId idOwner=\"urn:hivp.hireright.com\">\n" +
                "                <IdValue name=\"OrderServiceNo\">OR-004</IdValue>\n" +
                "                <IdValue name=\"ServiceId\">4</IdValue>\n" +
                "                <IdValue name=\"HRSchoolId\"></IdValue>\n" +
                "                <IdValue name=\"NSCHSchoolId\">999</IdValue>\n" +
                "            </ProducerReferenceId>\n" +
                "            <EducationVerificationReport>\n" +
                "                <EducationResult>\n" +
                "                    <ContactInformation>\n" +
                "                        <PersonName><FormattedName>Test Person</FormattedName></PersonName>\n" +
                "                        <Title>Test Title</Title>\n" +
                "                    </ContactInformation>\n" +
                "                    <SchoolOrInstitution>\n" +
                "                        <SchoolName>Test School</SchoolName>\n" +
                "                        <Degree>\n" +
                "                            <DegreeName>BS</DegreeName>\n" +
                "                            <Received>Yes</Received>\n" +
                "                        </Degree>\n" +
                "                        <Major>Math</Major>\n" +
                "                        <DatesOfAttendance>\n" +
                "                            <StartDate><AnyDate>2015-01-01</AnyDate></StartDate>\n" +
                "                            <EndDate><AnyDate>2019-12-31</AnyDate></EndDate>\n" +
                "                        </DatesOfAttendance>\n" +
                "                    </SchoolOrInstitution>\n" +
                "                </EducationResult>\n" +
                "            </EducationVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EducationScreening>\n" +
                "</EducationScreeningList>";

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        JsonNode jsonNode = objectMapper.readTree(json);
        JsonNode screening = jsonNode.get("screening").get(0);

        assertTrue(screening.get("hrSchoolId").isNull());
        assertEquals("999", screening.get("nschSchoolId").asText());
    }

    @Test
    void testConvert_WithNoDegreeData_ShouldHandleGracefully() throws Exception {
        // Given
        String xml = "<EducationScreeningList>\n" +
                "    <EducationScreening>\n" +
                "        <Screening type=\"education\" version=\"1\">\n" +
                "            <ProducerReferenceId idOwner=\"urn:hivp.hireright.com\">\n" +
                "                <IdValue name=\"OrderServiceNo\">OR-005</IdValue>\n" +
                "                <IdValue name=\"ServiceId\">5</IdValue>\n" +
                "            </ProducerReferenceId>\n" +
                "            <EducationVerificationReport>\n" +
                "                <EducationResult>\n" +
                "                    <ContactInformation>\n" +
                "                        <PersonName><FormattedName>Test Person</FormattedName></PersonName>\n" +
                "                        <Title>Test Title</Title>\n" +
                "                    </ContactInformation>\n" +
                "                    <SchoolOrInstitution>\n" +
                "                        <SchoolName>Test School</SchoolName>\n" +
                "                    </SchoolOrInstitution>\n" +
                "                </EducationResult>\n" +
                "            </EducationVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EducationScreening>\n" +
                "</EducationScreeningList>";

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        JsonNode jsonNode = objectMapper.readTree(json);
        JsonNode programs = jsonNode.get("screening").get(0).get("institution").get("programs");

        assertTrue(programs.isArray());
        assertEquals(0, programs.size());
    }

    @Test
    void testConvert_WithSingleIdValue_ShouldProcess() throws Exception {
        // Given
        String xml = "<EducationScreeningList>\n" +
                "    <EducationScreening>\n" +
                "        <Screening type=\"education\" version=\"1\">\n" +
                "            <ProducerReferenceId idOwner=\"urn:hivp.hireright.com\">\n" +
                "                <IdValue name=\"OrderServiceNo\">OR-006</IdValue>\n" +
                "            </ProducerReferenceId>\n" +
                "            <EducationVerificationReport>\n" +
                "                <EducationResult>\n" +
                "                    <ContactInformation>\n" +
                "                        <PersonName><FormattedName>Test</FormattedName></PersonName>\n" +
                "                        <Title>Title</Title>\n" +
                "                    </ContactInformation>\n" +
                "                    <SchoolOrInstitution>\n" +
                "                        <SchoolName>School</SchoolName>\n" +
                "                        <Degree>\n" +
                "                            <DegreeName>BA</DegreeName>\n" +
                "                            <Received>Yes</Received>\n" +
                "                        </Degree>\n" +
                "                        <Major>Art</Major>\n" +
                "                        <DatesOfAttendance>\n" +
                "                            <StartDate><AnyDate>2010-01-01</AnyDate></StartDate>\n" +
                "                            <EndDate><AnyDate>2014-12-31</AnyDate></EndDate>\n" +
                "                        </DatesOfAttendance>\n" +
                "                    </SchoolOrInstitution>\n" +
                "                </EducationResult>\n" +
                "            </EducationVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EducationScreening>\n" +
                "</EducationScreeningList>";

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        JsonNode jsonNode = objectMapper.readTree(json);
        JsonNode screening = jsonNode.get("screening").get(0);

        assertEquals("OR-006", screening.get("orderServiceNo").asText());
    }
}
