package org.example.recombointegration.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ScreeningType enum.
 * Tests type conversion, validation, and default behavior.
 */
class ScreeningTypeTest {

    @Test
    void testFromValue_WithEducation_ShouldReturnEducationType() {
        // When
        ScreeningType type = ScreeningType.fromValue("education");

        // Then
        assertEquals(ScreeningType.EDUCATION, type);
    }

    @Test
    void testFromValue_WithEmployment_ShouldReturnEmploymentType() {
        // When
        ScreeningType type = ScreeningType.fromValue("employment");

        // Then
        assertEquals(ScreeningType.EMPLOYMENT, type);
    }

    @Test
    void testFromValue_WithUpperCase_ShouldWork() {
        // When
        ScreeningType educationType = ScreeningType.fromValue("EDUCATION");
        ScreeningType employmentType = ScreeningType.fromValue("EMPLOYMENT");

        // Then
        assertEquals(ScreeningType.EDUCATION, educationType);
        assertEquals(ScreeningType.EMPLOYMENT, employmentType);
    }

    @Test
    void testFromValue_WithMixedCase_ShouldWork() {
        // When
        ScreeningType educationType = ScreeningType.fromValue("EdUcAtIoN");
        ScreeningType employmentType = ScreeningType.fromValue("EmPlOyMeNt");

        // Then
        assertEquals(ScreeningType.EDUCATION, educationType);
        assertEquals(ScreeningType.EMPLOYMENT, employmentType);
    }

    @Test
    void testFromValue_WithWhitespace_ShouldWork() {
        // When
        ScreeningType educationType = ScreeningType.fromValue("  education  ");
        ScreeningType employmentType = ScreeningType.fromValue("  employment  ");

        // Then
        assertEquals(ScreeningType.EDUCATION, educationType);
        assertEquals(ScreeningType.EMPLOYMENT, employmentType);
    }

    @Test
    void testFromValue_WithNull_ShouldReturnDefaultEducation() {
        // When
        ScreeningType type = ScreeningType.fromValue(null);

        // Then
        assertEquals(ScreeningType.EDUCATION, type);
    }

    @Test
    void testFromValue_WithEmptyString_ShouldReturnDefaultEducation() {
        // When
        ScreeningType type = ScreeningType.fromValue("");

        // Then
        assertEquals(ScreeningType.EDUCATION, type);
    }

    @Test
    void testFromValue_WithWhitespaceOnly_ShouldReturnDefaultEducation() {
        // When
        ScreeningType type = ScreeningType.fromValue("   ");

        // Then
        assertEquals(ScreeningType.EDUCATION, type);
    }

    @Test
    void testFromValue_WithInvalidValue_ShouldThrowException() {
        // When & Then
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> ScreeningType.fromValue("invalid")
        );

        assertTrue(exception.getMessage().contains("invalid"));
        assertTrue(exception.getMessage().contains("education"));
        assertTrue(exception.getMessage().contains("employment"));
    }

    @Test
    void testGetValue_Education_ShouldReturnCorrectString() {
        // When
        String value = ScreeningType.EDUCATION.getValue();

        // Then
        assertEquals("education", value);
    }

    @Test
    void testGetValue_Employment_ShouldReturnCorrectString() {
        // When
        String value = ScreeningType.EMPLOYMENT.getValue();

        // Then
        assertEquals("employment", value);
    }

    @Test
    void testToString_Education_ShouldReturnValue() {
        // When
        String value = ScreeningType.EDUCATION.toString();

        // Then
        assertEquals("education", value);
    }

    @Test
    void testToString_Employment_ShouldReturnValue() {
        // When
        String value = ScreeningType.EMPLOYMENT.toString();

        // Then
        assertEquals("employment", value);
    }

    @Test
    void testGetSupportedTypes_ShouldReturnAllTypes() {
        // When
        String supportedTypes = ScreeningType.getSupportedTypes();

        // Then
        assertNotNull(supportedTypes);
        assertTrue(supportedTypes.contains("education"));
        assertTrue(supportedTypes.contains("employment"));
    }

    @Test
    void testValues_ShouldReturnAllEnumValues() {
        // When
        ScreeningType[] values = ScreeningType.values();

        // Then
        assertEquals(2, values.length);
        assertTrue(containsType(values, ScreeningType.EDUCATION));
        assertTrue(containsType(values, ScreeningType.EMPLOYMENT));
    }

    @Test
    void testValueOf_WithEducation_ShouldWork() {
        // When
        ScreeningType type = ScreeningType.valueOf("EDUCATION");

        // Then
        assertEquals(ScreeningType.EDUCATION, type);
    }

    @Test
    void testValueOf_WithEmployment_ShouldWork() {
        // When
        ScreeningType type = ScreeningType.valueOf("EMPLOYMENT");

        // Then
        assertEquals(ScreeningType.EMPLOYMENT, type);
    }

    @Test
    void testEnumEquality() {
        // When & Then
        assertEquals(ScreeningType.EDUCATION, ScreeningType.EDUCATION);
        assertEquals(ScreeningType.EMPLOYMENT, ScreeningType.EMPLOYMENT);
        assertNotEquals(ScreeningType.EDUCATION, ScreeningType.EMPLOYMENT);
    }

    @Test
    void testEnumSwitch() {
        // Given
        ScreeningType type = ScreeningType.EDUCATION;
        String result;

        // When
        switch (type) {
            case EDUCATION:
                result = "education screening";
                break;
            case EMPLOYMENT:
                result = "employment screening";
                break;
            default:
                result = "unknown";
        }

        // Then
        assertEquals("education screening", result);
    }

    private boolean containsType(ScreeningType[] types, ScreeningType target) {
        for (ScreeningType type : types) {
            if (type == target) {
                return true;
            }
        }
        return false;
    }
}

