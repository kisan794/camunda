package org.example.recombointegration.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.recombointegration.exception.XmlTransformationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for EmploymentScreeningXmlToJsonConverter.
 * Tests the conversion of Employment Screening XML to JSON format.
 */
class EmploymentScreeningXmlToJsonConverterTest {

    private EmploymentScreeningXmlToJsonConverter converter;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        converter = new EmploymentScreeningXmlToJsonConverter();
        objectMapper = new ObjectMapper();
    }

    @Test
    void testConvert_WithValidXml_ShouldReturnJson() throws Exception {
        // Given
        String xml = "<EmploymentScreeningList>\n" +
                "    <EmploymentScreening xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                "        <Screening type=\"employment\" version=\"1\">\n" +
                "            <ProducerReferenceId idOwner=\"urn:hivp.hireright.com\">\n" +
                "                <IdValue name=\"OrderServiceNo\">OR-122024-CZ896-EM-002</IdValue>\n" +
                "                <IdValue name=\"ServiceId\">4</IdValue>\n" +
                "                <IdValue name=\"TALXEmployerCode\">27473129</IdValue>\n" +
                "            </ProducerReferenceId>\n" +
                "            <EmploymentVerificationReport>\n" +
                "                <EmploymentResult>\n" +
                "                    <EmploymentHistory>\n" +
                "                        <EmployerOrg>\n" +
                "                            <EmployerOrgName>WARWICK HEALTH CENTRE INC</EmployerOrgName>\n" +
                "                            <EmployerContactInfo>\n" +
                "                                <LocationSummary>\n" +
                "                                    <Municipality>WARWICK</Municipality>\n" +
                "                                    <Region>RI</Region>\n" +
                "                                    <CountryCode/>\n" +
                "                                </LocationSummary>\n" +
                "                            </EmployerContactInfo>\n" +
                "                            <PositionHistory>\n" +
                "                                <Title>RN</Title>\n" +
                "                                <StartDate>\n" +
                "                                    <AnyDate>2023-05-18</AnyDate>\n" +
                "                                </StartDate>\n" +
                "                                <EndDate>\n" +
                "                                    <AnyDate>2023-05-22</AnyDate>\n" +
                "                                </EndDate>\n" +
                "                                <MostRecentHireDate>\n" +
                "                                    <AnyDate>2023-05-18</AnyDate>\n" +
                "                                </MostRecentHireDate>\n" +
                "                                <EmployeeStatus code=\"8\">Inactive</EmployeeStatus>\n" +
                "                                <CompensationInfo currency=\"USD\">\n" +
                "                                    <RateOfPay/>\n" +
                "                                    <AverageHoursPerPayPeriod/>\n" +
                "                                    <DateOfPayIncreaseLast>\n" +
                "                                        <AnyDate>notKnown</AnyDate>\n" +
                "                                    </DateOfPayIncreaseLast>\n" +
                "                                    <AmountOfPayIncreaseLast/>\n" +
                "                                    <DateOfPayIncreaseNext>\n" +
                "                                        <AnyDate>notKnown</AnyDate>\n" +
                "                                    </DateOfPayIncreaseNext>\n" +
                "                                    <AmountOfPayIncreaseNext/>\n" +
                "                                </CompensationInfo>\n" +
                "                            </PositionHistory>\n" +
                "                        </EmployerOrg>\n" +
                "                    </EmploymentHistory>\n" +
                "                </EmploymentResult>\n" +
                "            </EmploymentVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EmploymentScreening>\n" +
                "</EmploymentScreeningList>";

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        JsonNode jsonNode = objectMapper.readTree(json);

        // Verify root structure
        assertEquals("TALX/XYZ", jsonNode.get("name").asText());
        assertEquals("employment", jsonNode.get("type").asText());
        assertTrue(jsonNode.has("screenings"));

        // Verify screenings array
        JsonNode screenings = jsonNode.get("screenings");
        assertTrue(screenings.isArray());
        assertEquals(1, screenings.size());

        // Verify first screening
        JsonNode screening = screenings.get(0);
        assertEquals("OR-122024-CZ896-EM-002", screening.get("orderServiceNo").asText());
        assertEquals("4", screening.get("serviceId").asText());
        assertEquals("27473129", screening.get("talxEmployerCode").asText());
        assertEquals("WARWICK HEALTH CENTRE INC", screening.get("employerOrgName").asText());
        assertEquals("WARWICK", screening.get("city").asText());
        assertEquals("RI", screening.get("region").asText());
        
        // Verify position history
        JsonNode positionHistory = screening.get("positionHistory");
        assertNotNull(positionHistory);
        assertEquals("RN", positionHistory.get("title").asText());
        assertEquals("2023-05-18", positionHistory.get("startDate").asText());
        assertEquals("2023-05-22", positionHistory.get("endDate").asText());
        assertEquals("2023-05-18", positionHistory.get("mostRecentHireDate").asText());
        assertEquals("8", positionHistory.get("employeeStatusCode").asText());
        assertEquals("Inactive", positionHistory.get("employeeStatus").asText());
        
        // Verify compensation info
        JsonNode compensationInfo = positionHistory.get("compensationInfo");
        assertNotNull(compensationInfo);
        assertEquals("USD", compensationInfo.get("currency").asText());
        assertEquals("notKnown", compensationInfo.get("dateOfPayIncreaseLast").asText());
        assertEquals("notKnown", compensationInfo.get("dateOfPayIncreaseNext").asText());
    }

    @Test
    void testConvert_WithMultipleScreenings_ShouldReturnAllScreenings() throws Exception {
        // Given
        String xml = "<EmploymentScreeningList>\n" +
                "    <EmploymentScreening>\n" +
                "        <Screening type=\"employment\" version=\"1\">\n" +
                "            <ProducerReferenceId idOwner=\"urn:hivp.hireright.com\">\n" +
                "                <IdValue name=\"OrderServiceNo\">OR-001</IdValue>\n" +
                "                <IdValue name=\"ServiceId\">1</IdValue>\n" +
                "                <IdValue name=\"TALXEmployerCode\">111</IdValue>\n" +
                "            </ProducerReferenceId>\n" +
                "            <EmploymentVerificationReport>\n" +
                "                <EmploymentResult>\n" +
                "                    <EmploymentHistory>\n" +
                "                        <EmployerOrg>\n" +
                "                            <EmployerOrgName>Company A</EmployerOrgName>\n" +
                "                            <EmployerContactInfo>\n" +
                "                                <LocationSummary>\n" +
                "                                    <Municipality>City A</Municipality>\n" +
                "                                    <Region>CA</Region>\n" +
                "                                    <CountryCode>US</CountryCode>\n" +
                "                                </LocationSummary>\n" +
                "                            </EmployerContactInfo>\n" +
                "                            <PositionHistory>\n" +
                "                                <Title>Engineer</Title>\n" +
                "                                <StartDate><AnyDate>2020-01-01</AnyDate></StartDate>\n" +
                "                                <EndDate><AnyDate>2021-01-01</AnyDate></EndDate>\n" +
                "                                <MostRecentHireDate><AnyDate>2020-01-01</AnyDate></MostRecentHireDate>\n" +
                "                                <EmployeeStatus code=\"8\">Inactive</EmployeeStatus>\n" +
                "                                <CompensationInfo currency=\"USD\">\n" +
                "                                    <RateOfPay/>\n" +
                "                                    <AverageHoursPerPayPeriod/>\n" +
                "                                    <DateOfPayIncreaseLast><AnyDate>notKnown</AnyDate></DateOfPayIncreaseLast>\n" +
                "                                    <AmountOfPayIncreaseLast/>\n" +
                "                                    <DateOfPayIncreaseNext><AnyDate>notKnown</AnyDate></DateOfPayIncreaseNext>\n" +
                "                                    <AmountOfPayIncreaseNext/>\n" +
                "                                </CompensationInfo>\n" +
                "                            </PositionHistory>\n" +
                "                        </EmployerOrg>\n" +
                "                    </EmploymentHistory>\n" +
                "                </EmploymentResult>\n" +
                "            </EmploymentVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EmploymentScreening>\n" +
                "    <EmploymentScreening>\n" +
                "        <Screening type=\"employment\" version=\"1\">\n" +
                "            <ProducerReferenceId idOwner=\"urn:hivp.hireright.com\">\n" +
                "                <IdValue name=\"OrderServiceNo\">OR-002</IdValue>\n" +
                "                <IdValue name=\"ServiceId\">2</IdValue>\n" +
                "                <IdValue name=\"TALXEmployerCode\">222</IdValue>\n" +
                "            </ProducerReferenceId>\n" +
                "            <EmploymentVerificationReport>\n" +
                "                <EmploymentResult>\n" +
                "                    <EmploymentHistory>\n" +
                "                        <EmployerOrg>\n" +
                "                            <EmployerOrgName>Company B</EmployerOrgName>\n" +
                "                            <EmployerContactInfo>\n" +
                "                                <LocationSummary>\n" +
                "                                    <Municipality>City B</Municipality>\n" +
                "                                    <Region>NY</Region>\n" +
                "                                    <CountryCode>US</CountryCode>\n" +
                "                                </LocationSummary>\n" +
                "                            </EmployerContactInfo>\n" +
                "                            <PositionHistory>\n" +
                "                                <Title>Manager</Title>\n" +
                "                                <StartDate><AnyDate>2021-01-01</AnyDate></StartDate>\n" +
                "                                <EndDate><AnyDate>2022-01-01</AnyDate></EndDate>\n" +
                "                                <MostRecentHireDate><AnyDate>2021-01-01</AnyDate></MostRecentHireDate>\n" +
                "                                <EmployeeStatus code=\"1\">Active</EmployeeStatus>\n" +
                "                                <CompensationInfo currency=\"USD\">\n" +
                "                                    <RateOfPay/>\n" +
                "                                    <AverageHoursPerPayPeriod/>\n" +
                "                                    <DateOfPayIncreaseLast><AnyDate>notKnown</AnyDate></DateOfPayIncreaseLast>\n" +
                "                                    <AmountOfPayIncreaseLast/>\n" +
                "                                    <DateOfPayIncreaseNext><AnyDate>notKnown</AnyDate></DateOfPayIncreaseNext>\n" +
                "                                    <AmountOfPayIncreaseNext/>\n" +
                "                                </CompensationInfo>\n" +
                "                            </PositionHistory>\n" +
                "                        </EmployerOrg>\n" +
                "                    </EmploymentHistory>\n" +
                "                </EmploymentResult>\n" +
                "            </EmploymentVerificationReport>\n" +
                "        </Screening>\n" +
                "    </EmploymentScreening>\n" +
                "</EmploymentScreeningList>";

        // When
        String json = converter.convert(xml);

        // Then
        assertNotNull(json);
        JsonNode jsonNode = objectMapper.readTree(json);
        
        JsonNode screenings = jsonNode.get("screenings");
        assertEquals(2, screenings.size());
        
        // Verify first screening
        assertEquals("OR-001", screenings.get(0).get("orderServiceNo").asText());
        assertEquals("Company A", screenings.get(0).get("employerOrgName").asText());
        
        // Verify second screening
        assertEquals("OR-002", screenings.get(1).get("orderServiceNo").asText());
        assertEquals("Company B", screenings.get(1).get("employerOrgName").asText());
    }

    @Test
    void testConvert_WithNullXml_ShouldThrowException() {
        // When & Then
        assertThrows(XmlTransformationException.class, () -> converter.convert(null));
    }

    @Test
    void testConvert_WithEmptyXml_ShouldThrowException() {
        // When & Then
        assertThrows(XmlTransformationException.class, () -> converter.convert(""));
    }

    @Test
    void testConvert_WithInvalidXml_ShouldThrowException() {
        // Given
        String invalidXml = "<InvalidXml>";

        // When & Then
        assertThrows(XmlTransformationException.class, () -> converter.convert(invalidXml));
    }
}

