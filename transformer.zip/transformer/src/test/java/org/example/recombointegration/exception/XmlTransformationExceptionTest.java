package org.example.recombointegration.exception;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for XmlTransformationException.
 * Tests all constructors and methods of the custom exception.
 */
class XmlTransformationExceptionTest {

    @Test
    void testConstructor_WithMessage_ShouldSetDefaultErrorCode() {
        // Given
        String message = "XML transformation failed";

        // When
        XmlTransformationException exception = new XmlTransformationException(message);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals("XML_TRANSFORMATION_ERROR", exception.getErrorCode());
        assertNull(exception.getDetails());
        assertNull(exception.getCause());
    }

    @Test
    void testConstructor_WithMessageAndCause_ShouldSetDefaultErrorCode() {
        // Given
        String message = "XML transformation failed";
        Throwable cause = new IllegalArgumentException("Invalid XML format");

        // When
        XmlTransformationException exception = new XmlTransformationException(message, cause);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals("XML_TRANSFORMATION_ERROR", exception.getErrorCode());
        assertNull(exception.getDetails());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testConstructor_WithErrorCodeMessageAndCause_ShouldSetAllFields() {
        // Given
        String errorCode = "CUSTOM_TRANSFORMATION_ERROR";
        String message = "Custom transformation failed";
        Throwable cause = new RuntimeException("Parsing error");

        // When
        XmlTransformationException exception = new XmlTransformationException(errorCode, message, cause);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals(errorCode, exception.getErrorCode());
        assertNull(exception.getDetails());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testConstructor_WithErrorCodeMessageCauseAndDetails_ShouldSetAllFields() {
        // Given
        String errorCode = "DETAILED_TRANSFORMATION_ERROR";
        String message = "Transformation failed with details";
        Throwable cause = new RuntimeException("Root cause");
        Map<String, Object> details = new HashMap<>();
        details.put("line", 42);
        details.put("column", 15);
        details.put("element", "EducationScreening");

        // When
        XmlTransformationException exception = new XmlTransformationException(errorCode, message, cause, details);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals(errorCode, exception.getErrorCode());
        assertEquals(details, exception.getDetails());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testConstructor_WithNullDetails_ShouldHandleGracefully() {
        // Given
        String errorCode = "NULL_DETAILS_ERROR";
        String message = "Transformation failed with null details";
        Throwable cause = new RuntimeException("Test cause");

        // When
        XmlTransformationException exception = new XmlTransformationException(errorCode, message, cause, null);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals(errorCode, exception.getErrorCode());
        assertNull(exception.getDetails());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testGetErrorCode_ShouldReturnCorrectCode() {
        // Given
        XmlTransformationException exception = new XmlTransformationException("CUSTOM_CODE", "Test message", null);

        // When
        String errorCode = exception.getErrorCode();

        // Then
        assertEquals("CUSTOM_CODE", errorCode);
    }

    @Test
    void testGetDetails_ShouldReturnCorrectDetails() {
        // Given
        Map<String, Object> details = new HashMap<>();
        details.put("xmlLength", 1024);
        details.put("processingTime", 150L);
        XmlTransformationException exception = new XmlTransformationException(
                "TRANSFORMATION_ERROR",
                "Transformation failed",
                null,
                details
        );

        // When
        Object retrievedDetails = exception.getDetails();

        // Then
        assertNotNull(retrievedDetails);
        assertEquals(details, retrievedDetails);
    }

    @Test
    void testException_IsRuntimeException() {
        // Given
        XmlTransformationException exception = new XmlTransformationException("Test message");

        // Then
        assertTrue(exception instanceof RuntimeException);
    }

    @Test
    void testException_CanBeThrown() {
        // When & Then
        assertThrows(XmlTransformationException.class, () -> {
            throw new XmlTransformationException("Test exception");
        });
    }

    @Test
    void testException_WithComplexDetails() {
        // Given
        Map<String, Object> complexDetails = new HashMap<>();
        complexDetails.put("simpleField", "Simple value");
        complexDetails.put("nestedMap", Map.of("key1", "value1", "key2", "value2"));
        complexDetails.put("list", java.util.Arrays.asList("item1", "item2", "item3"));
        complexDetails.put("number", 42);
        complexDetails.put("boolean", true);

        // When
        XmlTransformationException exception = new XmlTransformationException(
                "COMPLEX_DETAILS_ERROR",
                "Complex transformation failed",
                null,
                complexDetails
        );

        // Then
        assertEquals("COMPLEX_DETAILS_ERROR", exception.getErrorCode());
        assertEquals(complexDetails, exception.getDetails());
        assertTrue(((Map<?, ?>) exception.getDetails()).containsKey("simpleField"));
        assertTrue(((Map<?, ?>) exception.getDetails()).containsKey("nestedMap"));
        assertTrue(((Map<?, ?>) exception.getDetails()).containsKey("list"));
    }

    @Test
    void testException_WithEmptyMessage() {
        // Given
        String emptyMessage = "";

        // When
        XmlTransformationException exception = new XmlTransformationException(emptyMessage);

        // Then
        assertEquals(emptyMessage, exception.getMessage());
        assertEquals("XML_TRANSFORMATION_ERROR", exception.getErrorCode());
    }

    @Test
    void testException_WithNullMessage() {
        // Given & When
        XmlTransformationException exception = new XmlTransformationException(null);

        // Then
        assertNull(exception.getMessage());
        assertEquals("XML_TRANSFORMATION_ERROR", exception.getErrorCode());
    }

    @Test
    void testException_SerializableFields() {
        // Given
        XmlTransformationException exception = new XmlTransformationException(
                "TEST_CODE",
                "Test message",
                null,
                Map.of("key", "value")
        );

        // Then - Verify serialVersionUID exists (implicitly tested by compilation)
        assertNotNull(exception.getErrorCode());
        assertNotNull(exception.getDetails());
    }

    @Test
    void testException_WithCauseChain() {
        // Given
        Throwable rootCause = new IllegalArgumentException("Root cause");
        Throwable intermediateCause = new RuntimeException("Intermediate cause", rootCause);
        String message = "XML transformation failed";

        // When
        XmlTransformationException exception = new XmlTransformationException(message, intermediateCause);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals(intermediateCause, exception.getCause());
        assertEquals(rootCause, exception.getCause().getCause());
    }

    @Test
    void testException_MessageFormatting() {
        // Given
        String errorCode = "JSON_CONVERSION_FAILED";
        String message = "Failed to convert XML to JSON: Unexpected character '<' at position 10";
        Throwable cause = new RuntimeException("Parse error");

        // When
        XmlTransformationException exception = new XmlTransformationException(errorCode, message, cause);

        // Then
        assertTrue(exception.getMessage().contains("Failed to convert"));
        assertTrue(exception.getMessage().contains("JSON"));
        assertEquals(errorCode, exception.getErrorCode());
    }

    @Test
    void testException_WithNullCause() {
        // Given
        String errorCode = "NULL_CAUSE_ERROR";
        String message = "Transformation failed without cause";

        // When
        XmlTransformationException exception = new XmlTransformationException(errorCode, message, null);

        // Then
        assertEquals(message, exception.getMessage());
        assertEquals(errorCode, exception.getErrorCode());
        assertNull(exception.getCause());
    }

    @Test
    void testException_CompareWithValidationException() {
        // Given
        XmlTransformationException transformationException = new XmlTransformationException("Transform failed");
        XmlValidationException validationException = new XmlValidationException("Validation failed");

        // Then
        assertNotEquals(transformationException.getClass(), validationException.getClass());
        assertEquals("XML_TRANSFORMATION_ERROR", transformationException.getErrorCode());
        assertEquals("XML_VALIDATION_ERROR", validationException.getErrorCode());
    }

    @Test
    void testException_WithStringDetails() {
        // Given
        String errorCode = "STRING_DETAILS_ERROR";
        String message = "Transformation failed";
        String details = "Additional error information as string";

        // When
        XmlTransformationException exception = new XmlTransformationException(errorCode, message, null, details);

        // Then
        assertEquals(details, exception.getDetails());
        assertTrue(exception.getDetails() instanceof String);
    }

    @Test
    void testException_WithNumericDetails() {
        // Given
        String errorCode = "NUMERIC_DETAILS_ERROR";
        String message = "Transformation failed at position";
        Integer position = 42;

        // When
        XmlTransformationException exception = new XmlTransformationException(errorCode, message, null, position);

        // Then
        assertEquals(position, exception.getDetails());
        assertTrue(exception.getDetails() instanceof Integer);
    }
}

