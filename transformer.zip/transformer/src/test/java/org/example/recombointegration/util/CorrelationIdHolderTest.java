package org.example.recombointegration.util;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for CorrelationIdHolder.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
class CorrelationIdHolderTest {

    @BeforeEach
    void setUp() {
        // Clear MDC before each test
        MDC.clear();
    }

    @AfterEach
    void tearDown() {
        // Clean up MDC after each test
        MDC.clear();
    }

    @Test
    void testGenerate_shouldCreateNewCorrelationId() {
        // When
        String correlationId = CorrelationIdHolder.generate();

        // Then
        assertNotNull(correlationId, "Correlation ID should not be null");
        assertFalse(correlationId.isEmpty(), "Correlation ID should not be empty");
        assertEquals(36, correlationId.length(), "UUID should be 36 characters long");
    }

    @Test
    void testGenerate_shouldSetInMDC() {
        // When
        String correlationId = CorrelationIdHolder.generate();

        // Then
        assertEquals(correlationId, MDC.get(CorrelationIdHolder.CORRELATION_ID_KEY),
                "Correlation ID should be set in MDC");
    }

    @Test
    void testSet_shouldStoreCorrelationIdInMDC() {
        // Given
        String testCorrelationId = "test-correlation-id-12345";

        // When
        CorrelationIdHolder.set(testCorrelationId);

        // Then
        assertEquals(testCorrelationId, MDC.get(CorrelationIdHolder.CORRELATION_ID_KEY),
                "Correlation ID should be stored in MDC");
    }

    @Test
    void testSet_withNullValue_shouldNotSetInMDC() {
        // When
        CorrelationIdHolder.set(null);

        // Then
        assertNull(MDC.get(CorrelationIdHolder.CORRELATION_ID_KEY),
                "Null correlation ID should not be set in MDC");
    }

    @Test
    void testSet_withEmptyString_shouldNotSetInMDC() {
        // When
        CorrelationIdHolder.set("");

        // Then
        assertNull(MDC.get(CorrelationIdHolder.CORRELATION_ID_KEY),
                "Empty correlation ID should not be set in MDC");
    }

    @Test
    void testGet_shouldReturnCorrelationIdFromMDC() {
        // Given
        String testCorrelationId = "test-correlation-id-67890";
        MDC.put(CorrelationIdHolder.CORRELATION_ID_KEY, testCorrelationId);

        // When
        String result = CorrelationIdHolder.get();

        // Then
        assertEquals(testCorrelationId, result, "Should return correlation ID from MDC");
    }

    @Test
    void testGet_whenNotSet_shouldReturnNull() {
        // When
        String result = CorrelationIdHolder.get();

        // Then
        assertNull(result, "Should return null when correlation ID is not set");
    }

    @Test
    void testGetOrGenerate_whenSet_shouldReturnExisting() {
        // Given
        String existingCorrelationId = "existing-correlation-id";
        CorrelationIdHolder.set(existingCorrelationId);

        // When
        String result = CorrelationIdHolder.getOrGenerate();

        // Then
        assertEquals(existingCorrelationId, result,
                "Should return existing correlation ID");
    }

    @Test
    void testGetOrGenerate_whenNotSet_shouldGenerateNew() {
        // When
        String result = CorrelationIdHolder.getOrGenerate();

        // Then
        assertNotNull(result, "Should generate new correlation ID");
        assertFalse(result.isEmpty(), "Generated correlation ID should not be empty");
        assertEquals(result, MDC.get(CorrelationIdHolder.CORRELATION_ID_KEY),
                "Generated correlation ID should be set in MDC");
    }

    @Test
    void testClear_shouldRemoveCorrelationIdFromMDC() {
        // Given
        CorrelationIdHolder.set("test-correlation-id");

        // When
        CorrelationIdHolder.clear();

        // Then
        assertNull(MDC.get(CorrelationIdHolder.CORRELATION_ID_KEY),
                "Correlation ID should be removed from MDC");
    }

    @Test
    void testClearAll_shouldClearEntireMDC() {
        // Given
        CorrelationIdHolder.set("test-correlation-id");
        MDC.put("otherKey", "otherValue");

        // When
        CorrelationIdHolder.clearAll();

        // Then
        assertNull(MDC.get(CorrelationIdHolder.CORRELATION_ID_KEY),
                "Correlation ID should be cleared");
        assertNull(MDC.get("otherKey"), "All MDC entries should be cleared");
    }

    @Test
    void testConstants() {
        // Verify constant values
        assertEquals("correlationId", CorrelationIdHolder.CORRELATION_ID_KEY,
                "CORRELATION_ID_KEY should be 'correlationId'");
        assertEquals("X-Correlation-ID", CorrelationIdHolder.CORRELATION_ID_HEADER,
                "CORRELATION_ID_HEADER should be 'X-Correlation-ID'");
        assertEquals("correlationId", CorrelationIdHolder.RABBITMQ_CORRELATION_ID_HEADER,
                "RABBITMQ_CORRELATION_ID_HEADER should be 'correlationId'");
    }

    @Test
    void testThreadSafety_multipleCalls() {
        // Generate multiple correlation IDs
        String id1 = CorrelationIdHolder.generate();
        String id2 = CorrelationIdHolder.generate();
        String id3 = CorrelationIdHolder.generate();

        // Each should be unique
        assertNotEquals(id1, id2, "Each generated ID should be unique");
        assertNotEquals(id2, id3, "Each generated ID should be unique");
        assertNotEquals(id1, id3, "Each generated ID should be unique");

        // Last one should be in MDC
        assertEquals(id3, CorrelationIdHolder.get(),
                "Last generated ID should be in MDC");
    }

    @Test
    void testSetAndGet_workflow() {
        // Workflow: Set -> Get -> Clear -> Get
        String testId = "workflow-test-id";

        // Set
        CorrelationIdHolder.set(testId);
        assertEquals(testId, CorrelationIdHolder.get(), "Should get the set value");

        // Clear
        CorrelationIdHolder.clear();
        assertNull(CorrelationIdHolder.get(), "Should be null after clear");

        // GetOrGenerate
        String newId = CorrelationIdHolder.getOrGenerate();
        assertNotNull(newId, "Should generate new ID");
        assertEquals(newId, CorrelationIdHolder.get(), "Should get the generated value");
    }
}

