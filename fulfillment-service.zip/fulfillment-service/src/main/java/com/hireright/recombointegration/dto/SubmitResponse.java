/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Submit Response DTO for API responses
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SubmitResponse {
    
    @JsonProperty("status")
    private String status;
    
    @JsonProperty("message")
    private String message;
    
    @JsonProperty("subject")
    private String subject;
    
    @JsonProperty("decision")
    private String decision;
    
    @JsonProperty("timestamp")
    private Long timestamp;
    
    @JsonProperty("error")
    private String error;
    
    /**
     * Create a success response
     * 
     * @param subject The transaction subject
     * @param decision The decision made
     * @return Success response
     */
    public static SubmitResponse success(String subject, String decision) {
        return SubmitResponse.builder()
            .status("SUCCESS")
            .message("Submit response received and logged successfully")
            .subject(subject)
            .decision(decision)
            .timestamp(System.currentTimeMillis())
            .build();
    }
    
    /**
     * Create an error response
     * 
     * @param message Error message
     * @param error Error type
     * @return Error response
     */
    public static SubmitResponse error(String message, String error) {
        return SubmitResponse.builder()
            .status("FAILED")
            .message(message)
            .error(error)
            .timestamp(System.currentTimeMillis())
            .build();
    }
}

