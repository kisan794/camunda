/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.log;

import java.util.Map;

public interface LoggingService
{

	void log(final String payload, final String transactionId, final RecipientName recipientName, final Direction direction);

	void logWithParameters(final String payload, final String transactionId, final RecipientName recipientName, final Map<String, String> parameters);

}
