/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.log;

public enum RecipientName {
	CASES_AFTER_DOB_POLICIES_DETAILS,
	CASES_REFUSED,
	CASES_ACCEPTED,
	CASE_CHARGES_AFTER_CHARGE_POLICY_DETAILS,
	ITKS_CALLS,
	KNOCKOUT_REQUEST,
	KNOCKOUT_RESPONSE,
	KNOCKOUT_ERROR,
	CDS_REQUEST,
	CDS_RESPONSE,
	ENTRY_REQUEST,
	ENTRY_RESPONSE
}
