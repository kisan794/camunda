/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.log;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.hireright.recombointegration.log.ValidationUtil.requireNonNullOrBlank;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.slf4j.LoggerFactory.getLogger;

@Component
class LoggingTemplateMapper {
    private final static Logger LOGGER = getLogger(LoggingTemplateMapper.class);


   /* <T> String listToJson(final List<T> listToJson) {
        try {
            return mapper.writeValueAsString(listToJson);
        } catch(final JsonProcessingException ex) {
            LOGGER.error("Failed to convert cases to JSON", ex);
        }

        return EMPTY;
    }*/
}
