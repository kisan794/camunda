/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.dto.employment;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Employment HRG Source DTO containing product, organization, and verification details
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmploymentHrgSource {
    
    @JsonProperty("product")
    private EmploymentProduct product;
    
    @JsonProperty("organization")
    private Organization organization;
    
    @JsonProperty("guidelines")
    private List<String> guidelines;
    
    @JsonProperty("referenceObjects")
    private List<EmploymentReferenceObject> referenceObjects;
    
    @JsonProperty("notes")
    private List<EmploymentNote> notes;
}

