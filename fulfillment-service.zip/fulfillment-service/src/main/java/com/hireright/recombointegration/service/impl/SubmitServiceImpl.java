/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.recombointegration.dto.SubmitRequest;
import com.hireright.recombointegration.log.enums.Direction;
import com.hireright.recombointegration.log.enums.RecipientName;
import com.hireright.recombointegration.log.service.LoggingService;
import com.hireright.recombointegration.service.SubmitProcessingException;
import com.hireright.recombointegration.service.SubmitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Objects;

/**
 * Implementation of SubmitService for processing fulfillment task result submissions
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
@Service
@Slf4j
public class SubmitServiceImpl implements SubmitService {
    
    private final LoggingService loggingService;
    private final ObjectMapper objectMapper;
    
    public SubmitServiceImpl(LoggingService loggingService, ObjectMapper objectMapper) {
        this.loggingService = loggingService;
        this.objectMapper = objectMapper;
    }
    
    @Override
    public void processSubmission(SubmitRequest submitRequest) throws SubmitProcessingException {
        validateRequest(submitRequest);
        
        String transactionId = extractTransactionId(submitRequest);
        
        try {
            log.info("Processing submit request - Subject: {}", transactionId);
            
            String jsonPayload = serializeRequest(submitRequest);
            logSubmission(jsonPayload, transactionId);
            
            log.info("Successfully processed submit response - Subject: {}, Decision: {}", 
                transactionId,
                submitRequest.getResponse().getData().getDecision());
                
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize submit request - Subject: {}", transactionId, e);
            throw new SubmitProcessingException(
                "Failed to serialize request payload", 
                transactionId, 
                e
            );
        } catch (Exception e) {
            log.error("Failed to process submit request - Subject: {}", transactionId, e);
            throw new SubmitProcessingException(
                "Failed to process submission", 
                transactionId, 
                e
            );
        }
    }
    
    /**
     * Validate the submit request
     * 
     * @param submitRequest The request to validate
     * @throws SubmitProcessingException if validation fails
     */
    private void validateRequest(SubmitRequest submitRequest) throws SubmitProcessingException {
        if (Objects.isNull(submitRequest)) {
            throw new SubmitProcessingException("Submit request cannot be null", "UNKNOWN");
        }
        
        if (Objects.isNull(submitRequest.getResponse())) {
            throw new SubmitProcessingException("Response cannot be null", "UNKNOWN");
        }
        
        if (Objects.isNull(submitRequest.getResponse().getSubject()) || 
            submitRequest.getResponse().getSubject().isBlank()) {
            throw new SubmitProcessingException("Subject cannot be null or empty", "UNKNOWN");
        }
        
        if (Objects.isNull(submitRequest.getResponse().getData())) {
            throw new SubmitProcessingException(
                "Response data cannot be null", 
                submitRequest.getResponse().getSubject()
            );
        }
    }
    
    /**
     * Extract transaction ID from submit request
     * 
     * @param submitRequest The submit request
     * @return The transaction ID (subject)
     */
    private String extractTransactionId(SubmitRequest submitRequest) {
        return submitRequest.getResponse().getSubject();
    }
    
    /**
     * Serialize the submit request to JSON
     * 
     * @param submitRequest The request to serialize
     * @return JSON string representation
     * @throws JsonProcessingException if serialization fails
     */
    private String serializeRequest(SubmitRequest submitRequest) throws JsonProcessingException {
        return objectMapper.writeValueAsString(submitRequest);
    }
    
    /**
     * Log the submission using the logging service
     * 
     * @param jsonPayload The JSON payload to log
     * @param transactionId The transaction ID
     */
    private void logSubmission(String jsonPayload, String transactionId) {
        loggingService.log(
            jsonPayload,
            transactionId,
            RecipientName.RECOMBO_RESPONSE,
            Direction.IN
        );
    }
}

