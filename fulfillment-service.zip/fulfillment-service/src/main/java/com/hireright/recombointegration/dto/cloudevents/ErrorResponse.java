/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.dto.cloudevents;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hireright.recombointegration.util.CloudEventsConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * CloudEvents format error response following CloudEvents v1.0 specification.
 * This class represents error responses for authentication and validation failures.
 *
 * @see <a href="https://github.com/cloudevents/spec/blob/v1.0/spec.md">CloudEvents Specification v1.0</a>
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Slf4j
public class ErrorResponse {

    @JsonProperty("specversion")
    private String specversion;

    @JsonProperty("id")
    private String id;

    @JsonProperty("source")
    private String source;

    @JsonProperty("type")
    private String type;

    @JsonProperty("datacontenttype")
    private String datacontenttype;

    @JsonProperty("time")
    private String time;

    @JsonProperty("data")
    private ErrorData data;

    /**
     * Create authentication error response (HTTP 401).
     *
     * @param requestId The request ID for correlation (can be null, will generate UUID)
     * @param message Custom error message (can be null, will use default)
     * @param reason Error reason code (can be null, will use default)
     * @return ErrorResponse configured for authentication error
     */
    public static ErrorResponse authenticationError(String requestId, String message, String reason) {
        String effectiveRequestId = Objects.requireNonNullElseGet(requestId, () -> UUID.randomUUID().toString());
        String effectiveMessage = Objects.requireNonNullElse(message, CloudEventsConstants.ERROR_MSG_AUTH_DEFAULT);
        String effectiveReason = Objects.requireNonNullElse(reason, CloudEventsConstants.REASON_INVALID_OR_EXPIRED_TOKEN);

        log.debug("Creating authentication error response - RequestId: {}, Reason: {}", effectiveRequestId, effectiveReason);

        ErrorData errorData = ErrorData.builder()
            .status(401)
            .error(CloudEventsConstants.HTTP_STATUS_UNAUTHORIZED)
            .message(effectiveMessage)
            .errorCode(CloudEventsConstants.ERROR_CODE_AUTH)
            .reason(effectiveReason)
            .build();

        return ErrorResponse.builder()
            .specversion(CloudEventsConstants.CLOUDEVENTS_VERSION)
            .id(effectiveRequestId)
            .source(CloudEventsConstants.SOURCE_FULFILLMENT)
            .type(CloudEventsConstants.TYPE_ERROR_AUTHENTICATION)
            .datacontenttype(CloudEventsConstants.CONTENT_TYPE_JSON)
            .time(Instant.now().toString())
            .data(errorData)
            .build();
    }

    /**
     * Create validation error response (HTTP 400).
     *
     * @param requestId The request ID for correlation (can be null, will generate UUID)
     * @param message Custom error message (can be null, will use default)
     * @param details List of validation error details (can be null)
     * @return ErrorResponse configured for validation error
     */
    public static ErrorResponse validationError(String requestId, String message, List<ValidationDetail> details) {
        String effectiveRequestId = Objects.requireNonNullElseGet(requestId, () -> UUID.randomUUID().toString());
        String effectiveMessage = Objects.requireNonNullElse(message, CloudEventsConstants.ERROR_MSG_VALIDATION_DEFAULT);

        log.debug("Creating validation error response - RequestId: {}, Details count: {}",
            effectiveRequestId, details != null ? details.size() : 0);

        ErrorData errorData = ErrorData.builder()
            .status(400)
            .error(CloudEventsConstants.HTTP_STATUS_BAD_REQUEST)
            .errorCode(CloudEventsConstants.ERROR_CODE_VALIDATION)
            .message(effectiveMessage)
            .details(details)
            .build();

        return ErrorResponse.builder()
            .specversion(CloudEventsConstants.CLOUDEVENTS_VERSION)
            .id(effectiveRequestId)
            .source(CloudEventsConstants.SOURCE_TASK)
            .type(CloudEventsConstants.TYPE_ERROR_VALIDATION)
            .datacontenttype(CloudEventsConstants.CONTENT_TYPE_JSON)
            .time(Instant.now().toString())
            .data(errorData)
            .build();
    }
}

