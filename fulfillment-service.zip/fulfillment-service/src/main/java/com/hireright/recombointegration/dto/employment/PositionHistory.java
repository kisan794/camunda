/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.dto.employment;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Position History DTO for job position information
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PositionHistory {
    
    @JsonProperty("verify")
    private Boolean verify;
    
    @JsonProperty("title")
    private String title;
    
    @JsonProperty("tenure")
    private EmploymentTenure tenure;
    
    @JsonProperty("startDate")
    private String startDate;
    
    @JsonProperty("endDate")
    private String endDate;
    
    @JsonProperty("mostRecentHireDate")
    private String mostRecentHireDate;
    
    @JsonProperty("employeeStatusCode")
    private String employeeStatusCode;
    
    @JsonProperty("employeeStatus")
    private String employeeStatus;
    
    @JsonProperty("compensationInfo")
    private CompensationInfo compensationInfo;
}

