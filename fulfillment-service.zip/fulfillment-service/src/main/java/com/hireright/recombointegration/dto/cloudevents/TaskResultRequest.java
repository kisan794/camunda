/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.dto.cloudevents;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CloudEvents format request for task results
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaskResultRequest {
    
    @JsonProperty("specversion")
    private String specversion;
    
    @JsonProperty("id")
    private String id;
    
    @JsonProperty("source")
    private String source;
    
    @JsonProperty("type")
    private String type;
    
    @JsonProperty("datacontenttype")
    private String datacontenttype;
    
    @JsonProperty("dataschema")
    private String dataschema;
    
    @JsonProperty("data")
    private TaskResultData data;
}

