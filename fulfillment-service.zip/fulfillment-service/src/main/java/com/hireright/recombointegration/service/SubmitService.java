/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.service;

import com.hireright.recombointegration.dto.SubmitRequest;

/**
 * Service interface for processing fulfillment task result submissions
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
public interface SubmitService {
    
    /**
     * Process and log a fulfillment task result submission
     * 
     * @param submitRequest The submit request containing task result data
     * @throws SubmitProcessingException if processing fails
     */
    void processSubmission(SubmitRequest submitRequest) throws SubmitProcessingException;
}

