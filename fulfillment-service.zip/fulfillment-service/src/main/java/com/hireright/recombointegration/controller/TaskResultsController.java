/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.recombointegration.dto.cloudevents.*;
import com.hireright.recombointegration.log.LoggingService;
import com.hireright.recombointegration.log.RecipientName;
import com.hireright.recombointegration.log.Direction;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Task Results Controller for receiving fulfillment task results.
 * Implements CloudEvents v1.0 specification for task result submissions.
 *
 * <p>This controller handles:
 * <ul>
 *   <li>Task result validation</li>
 *   <li>CloudEvents format compliance</li>
 *   <li>Request logging and auditing</li>
 *   <li>Error handling with proper HTTP status codes</li>
 * </ul>
 *
 * @author Keshav Ladha
 * @version 1.0
 * @see TaskResultRequest
 * @see TaskResultResponse
 */
@RestController
@RequestMapping("/v1/fulfillment")
@Slf4j
public class TaskResultsController {

    private static final String LOG_RECEIVED = "Received task result - ID: {}, Type: {}";
    private static final String LOG_VALIDATION_FAILED = "Validation failed for task result - ID: {}, Errors: {}";
    private static final String LOG_SUCCESS = "Task result logged successfully - ID: {}, Decision: {}";
    private static final String LOG_ERROR = "Failed to process task result - ID: {}";
    private static final String ERROR_MESSAGE_PROCESSING = "Failed to process task result";

    private final LoggingService loggingService;
    private final ObjectMapper objectMapper;

    /**
     * Constructor with dependency injection.
     *
     * @param loggingService Service for logging data exchanges
     * @param objectMapper Jackson ObjectMapper for JSON serialization
     */
    public TaskResultsController(LoggingService loggingService, ObjectMapper objectMapper) {
        this.loggingService = loggingService;
        this.objectMapper = objectMapper;
    }

    /**
     * POST endpoint to receive task results in CloudEvents format.
     *
     * <p>This endpoint:
     * <ul>
     *   <li>Validates the CloudEvents format request</li>
     *   <li>Logs the request for auditing</li>
     *   <li>Returns CloudEvents format response</li>
     * </ul>
     *
     * @param request Task result request in CloudEvents format (must not be null)
     * @return ResponseEntity with CloudEvents format response or error
     *         <ul>
     *           <li>200 OK - Task accepted successfully</li>
     *           <li>400 Bad Request - Validation failed</li>
     *           <li>500 Internal Server Error - Processing failed</li>
     *         </ul>
     */
    @PostMapping("/tasks/results")
    public ResponseEntity<?> submitTaskResults(@RequestBody TaskResultRequest request) {
        String requestId = extractRequestId(request);

        try {
            log.info(LOG_RECEIVED, requestId, extractType(request));

            // Validate request
            List<ValidationDetail> validationErrors = validateRequest(request);
            if (!validationErrors.isEmpty()) {
                return handleValidationErrors(requestId, validationErrors);
            }

            // Log the request for auditing
            logRequest(request, requestId);

            log.info(LOG_SUCCESS, requestId, extractDecision(request));

            // Create and return success response
            return ResponseEntity.ok(TaskResultResponse.accepted(requestId, requestId));

        } catch (Exception e) {
            return handleProcessingError(requestId, e);
        }
    }

    /**
     * Handle validation errors and create appropriate response.
     */
    private ResponseEntity<?> handleValidationErrors(String requestId, List<ValidationDetail> validationErrors) {
        log.warn(LOG_VALIDATION_FAILED, requestId, validationErrors.size());

        ErrorResponse errorResponse = ErrorResponse.validationError(
            requestId,
            "Input validation failed",
            validationErrors
        );

        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .body(errorResponse);
    }

    /**
     * Log the request using the logging service.
     */
    private void logRequest(TaskResultRequest request, String requestId) {
        try {
            String jsonPayload = objectMapper.writeValueAsString(request);
            loggingService.log(
                jsonPayload,
                requestId,
                RecipientName.CDS_RESPONSE,
                Direction.IN
            );
        } catch (Exception e) {
            log.error("Failed to log request - ID: {}", requestId, e);
            // Don't fail the request if logging fails
        }
    }

    /**
     * Handle processing errors and create appropriate response.
     */
    private ResponseEntity<?> handleProcessingError(String requestId, Exception e) {
        log.error(LOG_ERROR, requestId, e);

        ErrorResponse errorResponse = ErrorResponse.validationError(
            requestId,
            ERROR_MESSAGE_PROCESSING + ": " + e.getMessage(),
            null
        );

        return ResponseEntity
            .status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(errorResponse);
    }

    /**
     * Extract request ID safely from request.
     */
    private String extractRequestId(TaskResultRequest request) {
        return request != null ? request.getId() : "unknown";
    }

    /**
     * Extract type safely from request.
     */
    private String extractType(TaskResultRequest request) {
        return request != null ? request.getType() : "unknown";
    }

    /**
     * Extract decision safely from request.
     */
    private String extractDecision(TaskResultRequest request) {
        if (request != null && request.getData() != null) {
            return request.getData().getDecision();
        }
        return "N/A";
    }
    
    /**
     * Validate task result request according to CloudEvents specification.
     *
     * <p>Validates:
     * <ul>
     *   <li>Request is not null</li>
     *   <li>Required CloudEvents fields (specversion, id, source, type)</li>
     *   <li>Data field and its required sub-fields (decision, resultData)</li>
     * </ul>
     *
     * @param request Task result request to validate
     * @return List of validation errors (empty if valid)
     */
    private List<ValidationDetail> validateRequest(TaskResultRequest request) {
        List<ValidationDetail> errors = new ArrayList<>();

        if (request == null) {
            errors.add(createValidationDetail("request", "Request body is required"));
            return errors;
        }

        // Validate required CloudEvents fields
        validateRequiredField(errors, request.getSpecversion(), "specversion", "Specversion is required");
        validateRequiredField(errors, request.getId(), "id", "ID is required");
        validateRequiredField(errors, request.getSource(), "source", "Source is required");
        validateRequiredField(errors, request.getType(), "type", "Type is required");

        // Validate data field
        if (request.getData() == null) {
            errors.add(createValidationDetail("data", "Data is required"));
        } else {
            validateDataFields(errors, request.getData());
        }

        return errors;
    }

    /**
     * Validate data fields within the request.
     */
    private void validateDataFields(List<ValidationDetail> errors, TaskResultData data) {
        validateRequiredField(errors, data.getDecision(), "decision", "Decision is required");

        if (data.getResultData() == null) {
            errors.add(createValidationDetail("resultData", "Result data is required"));
        }
    }

    /**
     * Validate a required field and add error if invalid.
     */
    private void validateRequiredField(List<ValidationDetail> errors, String value, String fieldName, String message) {
        if (value == null || value.trim().isEmpty()) {
            errors.add(createValidationDetail(fieldName, message));
        }
    }

    /**
     * Create a validation detail object.
     */
    private ValidationDetail createValidationDetail(String field, String message) {
        return ValidationDetail.builder()
            .field(field)
            .message(message)
            .build();
    }
}

