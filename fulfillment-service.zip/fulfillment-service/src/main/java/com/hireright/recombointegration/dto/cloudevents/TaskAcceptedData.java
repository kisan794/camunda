/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.dto.cloudevents;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Task accepted data for successful response
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaskAcceptedData {
    
    @JsonProperty("taskId")
    private String taskId;
    
    @JsonProperty("status")
    private String status;
    
    @JsonProperty("submittedAt")
    private String submittedAt;
    
    @JsonProperty("expectedCompletion")
    private String expectedCompletion;
    
    @JsonProperty("message")
    private String message;
}

