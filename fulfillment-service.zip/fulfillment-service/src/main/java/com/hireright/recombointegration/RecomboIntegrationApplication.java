/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration;

import hireright.lib.logging.log_data_exchange.CDataExchangeLogger;
import hireright.lib.logging.log_data_exchange.IDataExchangeLogger;
import hireright.lib.logging.log_trace.CTraceLogger;
import hireright.lib.logging.log_trace.ITraceLogger;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;

import static java.lang.System.setProperty;

@SpringBootApplication
@EnableAsync
public class RecomboIntegrationApplication
{
	private final static String HRG_WEBAPP_LOGGING_INITIAL_GLX_POSTING_URL = "logging.InitialGlxPostingUrl";

	@Value("${logging.InitialGlxPostingUrl:http://us11iass.data.hireright.com:6808/log_receiver/postGlx}")
	private String loggingInitialGlxPostingUrl;


	public static void main(String[] args)
	{
		SpringApplication.run(RecomboIntegrationApplication.class, args);
	}

	@Bean
	IDataExchangeLogger dataExchangeLogger() {
		return CDataExchangeLogger.DEFAULT;
	}

	@PostConstruct
	void setLoggerEndpoint() {
		setProperty(HRG_WEBAPP_LOGGING_INITIAL_GLX_POSTING_URL, loggingInitialGlxPostingUrl);
	}

	@Bean
	ITraceLogger dataTraceLogger() {
		return CTraceLogger.DEFAULT;
	}


}
