/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hireright.recombointegration.dto.ResponseWrapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class ReadMockResponse
{
	private static final ObjectMapper mapper = new ObjectMapper();

	private ReadMockResponse () {

	}
	public static Map<String, ResponseWrapper> readAllMockResponses() throws IOException
	{
		Map<String, ResponseWrapper> responseMap = new HashMap<>();

		String[] files = {
			"/mock/EMP-001.json",
			"/mock/EMP-002.json",
			"/mock/EMP-003.json",
			"/mock/EMP-004.json",
			"/mock/EMP-005.json"
		};

		for (int i = 0; i < files.length; i++) {
			String key = "EMP-00" + (i + 1);

			try (InputStream is = ReadMockResponse.class.getResourceAsStream(files[i])) {
				if (is == null) {
					throw new IOException("File not found: " + files[i]);
				}
				// Convert JSON into Response object
				ResponseWrapper response = mapper.readValue(is, ResponseWrapper.class);
				responseMap.put(key, response);
			}
		}
		return responseMap;
	}

}
