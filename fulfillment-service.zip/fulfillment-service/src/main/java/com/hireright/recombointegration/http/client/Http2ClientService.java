/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.http.client;

import com.hireright.recombointegration.http.config.HttpClientConfig;
import com.hireright.recombointegration.http.config.JwtConfig;
import com.hireright.recombointegration.http.exception.HttpClientException;
import com.hireright.recombointegration.http.exception.RetryableHttpException;
import com.hireright.recombointegration.util.CorrelationIdHolder;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Spring service wrapper for Http2Client with retry support.
 * Provides a Spring-managed HTTP/2 client with @Retryable annotation for automatic retries.
 * Retry logic is configured via spring.retry.* properties.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Service
public class Http2ClientService {

    private final HttpClientConfig httpClientConfig;
    private final Optional<JwtConfig> jwtConfig;
    private final Set<Integer> retryableStatusCodes;

    private Http2Client client;

    /**
     * Constructor with dependency injection.
     * JwtConfig is optional based on conditional properties.
     *
     * @param httpClientConfig           the HTTP client configuration (required)
     * @param jwtConfig                  the JWT configuration (optional, based on http.client.jwt.enabled)
     * @param retryableStatusCodesString comma-separated list of retryable HTTP status codes
     */
    @Autowired
    public Http2ClientService(
            HttpClientConfig httpClientConfig,
            @Autowired(required = false) JwtConfig jwtConfig,
            @Value("${spring.retry.retryable-status-codes:408,429,500,502,503,504}") String retryableStatusCodesString) {
        this.httpClientConfig = httpClientConfig;
        this.jwtConfig = Optional.ofNullable(jwtConfig);
        this.retryableStatusCodes = Arrays.stream(retryableStatusCodesString.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(Integer::parseInt)
                .collect(Collectors.toSet());
    }

    /**
     * Initializes the HTTP/2 client after dependencies are injected.
     */
    @PostConstruct
    public void init() {
        log.info("Initializing Http2ClientService with configuration from Spring beans");

        Http2Client.Builder builder = Http2Client.builder()
                .clientConfig(httpClientConfig);

        // Configure JWT if enabled
        jwtConfig.ifPresent(config -> {
            builder.jwtConfig(config);
            log.info("JWT authentication enabled with issuer: {}", config.getIssuer());
        });

        this.client = builder.build();
        log.info("Http2ClientService initialized successfully with retryable status codes: {}", retryableStatusCodes);
    }

    /**
     * Executes a synchronous GET request with retry support.
     * Retries on configured HTTP status codes and exceptions.
     *
     * @param uri     the request URI
     * @param headers custom headers to include
     * @return the HTTP response
     * @throws RetryableHttpException if response has retryable status code
     * @throws HttpClientException    if request fails after all retries
     */
    @Retryable(
            retryFor = {RetryableHttpException.class, HttpClientException.class},
            maxAttemptsExpression = "${spring.retry.max-attempts:3}",
            backoff = @Backoff(
                    delayExpression = "${spring.retry.initial-interval:1000}",
                    maxDelayExpression = "${spring.retry.max-interval:10000}",
                    multiplierExpression = "${spring.retry.multiplier:2.0}"
            )
    )
    public HttpResponse<String> get(String uri, Map<String, String> headers) {
        log.debug("Executing GET request with retry support - URI: {}, CorrelationID: {}",
                uri, CorrelationIdHolder.get());

        HttpResponse<String> response = client.get(uri, headers);
        checkAndThrowIfRetryable(response, "GET", uri);
        return response;
    }

    /**
     * Executes a synchronous POST request with retry support.
     * Retries on configured HTTP status codes and exceptions.
     *
     * @param uri     the request URI
     * @param body    the request body
     * @param headers custom headers to include
     * @return the HTTP response
     * @throws RetryableHttpException if response has retryable status code
     * @throws HttpClientException    if request fails after all retries
     */
    @Retryable(
            retryFor = { RetryableHttpException.class, HttpClientException.class},
            maxAttemptsExpression = "${spring.retry.max-attempts:3}",
            backoff = @Backoff(
                    delayExpression = "${spring.retry.initial-interval:1000}",
                    maxDelayExpression = "${spring.retry.max-interval:10000}",
                    multiplierExpression = "${spring.retry.multiplier:2.0}"
            )
    )
    public HttpResponse<String> post(String uri, String body, Map<String, String> headers) {
        log.debug("Executing POST request with retry support - URI: {}, CorrelationID: {}",
                uri, CorrelationIdHolder.get());

        HttpResponse<String> response = client.post(uri, body, headers);
        checkAndThrowIfRetryable(response, "POST", uri);
        return response;
    }

    /**
     * Executes an asynchronous GET request with retry support.
     * Retries on configured HTTP status codes and exceptions.
     *
     * @param uri     the request URI
     * @param headers custom headers to include
     * @return a CompletableFuture containing the HTTP response
     */
    @Retryable(
            retryFor = {RetryableHttpException.class, HttpClientException.class},
            maxAttemptsExpression = "${spring.retry.max-attempts:3}",
            backoff = @Backoff(
                    delayExpression = "${spring.retry.initial-interval:1000}",
                    maxDelayExpression = "${spring.retry.max-interval:10000}",
                    multiplierExpression = "${spring.retry.multiplier:2.0}"
            )
    )
    public CompletableFuture<HttpResponse<String>> getAsync(String uri, Map<String, String> headers) {
        // Capture MDC context for async operations
        Map<String, String> mdcContext = MDC.getCopyOfContextMap();

        log.debug("Executing async GET request with retry support - URI: {}, CorrelationID: {}",
                uri, CorrelationIdHolder.get());

        return client.getAsync(uri, headers)
                .thenApply(response -> {
                    // Restore MDC context
                    if (mdcContext != null) {
                        MDC.setContextMap(mdcContext);
                    }
                    checkAndThrowIfRetryable(response, "GET", uri);
                    return response;
                });
    }

    /**
     * Executes an asynchronous POST request with retry support.
     * Retries on configured HTTP status codes and exceptions.
     *
     * @param uri     the request URI
     * @param body    the request body
     * @param headers custom headers to include
     * @return a CompletableFuture containing the HTTP response
     */
    @Retryable(
            retryFor = {RetryableHttpException.class, HttpClientException.class},
            maxAttemptsExpression = "${spring.retry.max-attempts:3}",
            backoff = @Backoff(
                    delayExpression = "${spring.retry.initial-interval:1000}",
                    maxDelayExpression = "${spring.retry.max-interval:10000}",
                    multiplierExpression = "${spring.retry.multiplier:2.0}"
            )
    )
    public CompletableFuture<HttpResponse<String>> postAsync(String uri, String body, Map<String, String> headers) {
        // Capture MDC context for async operations
        Map<String, String> mdcContext = MDC.getCopyOfContextMap();

        log.debug("Executing async POST request with retry support - URI: {}, CorrelationID: {}",
                uri, CorrelationIdHolder.get());

        return client.postAsync(uri, body, headers)
                .thenApply(response -> {
                    // Restore MDC context
                    if (mdcContext != null) {
                        MDC.setContextMap(mdcContext);
                    }
                    checkAndThrowIfRetryable(response, "POST", uri);
                    return response;
                });
    }

    /**
     * Checks if the response has a retryable status code and throws exception if so.
     *
     * @param response the HTTP response
     * @param method   the HTTP method
     * @param uri      the request URI
     * @throws RetryableHttpException if the status code is retryable
     */
    private void checkAndThrowIfRetryable(HttpResponse<String> response, String method, String uri) {
        if (retryableStatusCodes.contains(response.statusCode())) {
            log.warn("Received retryable status code {} for {} request to: {}, CorrelationID: {}",
                    response.statusCode(), method, uri, CorrelationIdHolder.get());
            throw new RetryableHttpException(response.statusCode(), response.body());
        }
    }
}