/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package com.hireright.recombointegration.dto.cloudevents;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hireright.recombointegration.util.CloudEventsConstants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * API Version Error Response for unsupported API versions
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiVersionErrorResponse {
    
    @JsonProperty("errorCode")
    private String errorCode;
    
    @JsonProperty("message")
    private String message;
    
    /**
     * Create unsupported API version error response
     * 
     * @param version The unsupported version
     * @param supportedVersion The supported version
     * @return API version error response
     */
    public static ApiVersionErrorResponse unsupportedVersion(String version, String supportedVersion) {
        return ApiVersionErrorResponse.builder()
            .errorCode(CloudEventsConstants.ERROR_CODE_UNSUPPORTED_VERSION)
            .message(String.format("API version %s is no longer supported. Please use %s.", version, supportedVersion))
            .build();
    }
}

