package com.hireright.recombointegration.controller;

import com.hireright.recombointegration.dto.ResponseWrapper;
import com.hireright.recombointegration.dto.ScreeningRequest;
import com.hireright.recombointegration.helper.ReadMockResponse;
import com.hireright.recombointegration.log.Direction;
import com.hireright.recombointegration.log.LoggingService;
import com.hireright.recombointegration.log.RecipientName;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.hireright.recombointegration.util.Constant.BASE_SOURCE_INTELLIGENCE_SERVICE_API_PATH;

/**
 * @author Keshav Ladha
 * @version 1.0
 */

@RestController
@RequestMapping(BASE_SOURCE_INTELLIGENCE_SERVICE_API_PATH)
@Slf4j
public class ScreeningController {

    private final LoggingService loggingService;

	public ScreeningController(LoggingService loggingService)
	{
		this.loggingService = loggingService;
	}

	@PostMapping("/screening")
    public ResponseEntity<Map<String, Object>> getScreeningResponse(
        @RequestBody ScreeningRequest request) {

        Map<String, Object> response = new HashMap<>();

        try {
            loggingService.log("mike testing", "123", RecipientName.CDS_RESPONSE, Direction.IN);
            ResponseWrapper responseWrapper = ReadMockResponse.readAllMockResponses().get(request.getId());
            if (Objects.isNull(responseWrapper)) throw new IllegalArgumentException("screening data not exist");
            response.put("status", "SUCCESS");
            response.put("message", "Screening request processed successfully");
            response.put("data", responseWrapper);

            log.info("Screening processing completed successfully - ScreeningID: {}", request.getId());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("Screening processing failed - ScreeningID: {}", request.getId(), e);

            response.put("status", "FAILED");
            response.put("message", "Processing failed: " + e.getMessage());
            response.put("error", e.getClass().getSimpleName());

            return ResponseEntity.status(500).body(response);
        }
    }
}


