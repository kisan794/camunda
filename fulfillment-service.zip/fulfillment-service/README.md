# Recombo Integration Service

## Overview
Enterprise-grade fulfillment service for education and employment verification integration. Built with Spring Boot 3.2.4 and Java 21, following CloudEvents v1.0 specification.

## 🚀 Quick Start

### Prerequisites
- **Java 21** (JDK 21)
- **Maven 3.8+** (or use included Maven Wrapper)
- **Docker** (optional, for containerization)

### Build & Run
```bash
# Build the project
./mvnw clean install

# Run the application
./mvnw spring-boot:run

# Access the application
http://localhost:8080
```

## 📋 Features

### Core Functionality
- ✅ **Education Verification** - Process education verification requests
- ✅ **Employment Verification** - Process employment verification requests
- ✅ **Task Management** - Async task initiation and result processing
- ✅ **CloudEvents Compliance** - Full CloudEvents v1.0 specification support

### Security
- ✅ **JWT Authentication** - Token-based authentication for all endpoints
- ✅ **API Version Validation** - Configurable API version support
- ✅ **Input Validation** - Comprehensive request validation with detailed errors

### Observability
- ✅ **OpenTelemetry Integration** - Distributed tracing support
- ✅ **Prometheus Metrics** - Application metrics export
- ✅ **Health Checks** - Spring Boot Actuator endpoints
- ✅ **Structured Logging** - Correlation ID tracking

## 🔑 API Endpoints

### Task Initiation
```http
POST /v1/fulfillment/tasks/{taskid}/initiate
Authorization: Bearer <jwt-token>
```

**Response (202 Accepted):**
```json
{
  "status": "Accepted",
  "message": "Sub-request triggered successfully."
}
```

### Task Results Submission
```http
POST /v1/fulfillment/tasks/results
Authorization: Bearer <jwt-token>
Content-Type: application/json
```

**Request Body:**
```json
{
  "specversion": "1.0",
  "id": "HE-010101-XXXXX-EM-001",
  "source": "hrg:hre:task",
  "type": "EmploymentFulfillmentResult",
  "datacontenttype": "application/json",
  "data": {
    "decision": "VERIFIED",
    "confidenceScore": 0.95,
    "decisionDescription": "Verification completed successfully",
    "resultData": {
      "employerOrgName": "Tech Innovations Inc.",
      "city": "Berkeley",
      "region": "CA",
      "country": "US"
    }
  }
}
```

**Response (200 OK):**
```json
{
  "specversion": "1.0",
  "id": "7a8f3c9e-2b44-4c11-b9e3-2f9a6d1a89d2",
  "source": "hrg:hre:fulfillment-api",
  "type": "Task.Accepted",
  "datacontenttype": "application/json",
  "time": "2025-11-20T10:15:30Z",
  "data": {
    "taskId": "HE-010101-XXXXX-EM-001",
    "status": "PENDING",
    "submittedAt": "2025-11-20T10:15:30Z",
    "expectedCompletion": "2025-11-20T10:17:30Z",
    "message": "Task request accepted for processing"
  }
}
```

## 🔐 Authentication

All API endpoints require JWT authentication:

```bash
curl -X POST http://localhost:8080/v1/fulfillment/tasks/results \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  -H "Content-Type: application/json" \
  -d @request.json
```

### Configuration
```properties
# application.properties
jwt.secret=${JWT_SECRET:your-256-bit-secret-key}
```

## 🎯 API Versioning

The service supports configurable API versioning:

```properties
# application.properties
api.supported-versions=${API_SUPPORTED_VERSIONS:v1}
api.latest-version=${API_LATEST_VERSION:v1}
```

**Unsupported Version Response (400 Bad Request):**
```json
{
  "errorCode": "UNSUPPORTED_API_VERSION",
  "message": "API version v1 is no longer supported. Please use v2."
}
```

## 🛠️ Development

### Build Commands
```bash
# Clean build
./mvnw clean install

# Build without tests
./mvnw clean package -DskipTests

# Run tests
./mvnw test

# Run with coverage
./mvnw clean test jacoco:report

# View coverage report
open target/site/jacoco/index.html
```

### Run Application
```bash
# Default profile
./mvnw spring-boot:run

# With specific profile
./mvnw spring-boot:run -Dspring-boot.run.profiles=dev

# With debug logging
./mvnw spring-boot:run -Dlogging.level.com.hireright=DEBUG
```

## 🐳 Docker

### Build Docker Image
```bash
# Build JAR
./mvnw clean package -DskipTests

# Build Docker image
docker build -t recombo-integration:1.0.0 .

# Run container
docker run -p 8080:8080 \
  -e JWT_SECRET=your-secret-key \
  -e API_SUPPORTED_VERSIONS=v1 \
  recombo-integration:1.0.0
```

## 📊 Monitoring

### Health Check
```bash
curl http://localhost:8080/actuator/health
```

### Metrics
```bash
curl http://localhost:8080/actuator/metrics
```

### Swagger UI
```bash
open http://localhost:8080/recombo-integration/swagger-ui.html
```

## 🧪 Testing

### Unit Tests
```bash
./mvnw test
```

### Integration Tests
```bash
./mvnw verify
```

### Code Coverage
```bash
./mvnw clean test jacoco:report
open target/site/jacoco/index.html
```

### SonarQube Analysis
```bash
./mvnw clean verify sonar:sonar \
  -Dsonar.projectKey=com.hireright:recombo-integration \
  -Dsonar.host.url=http://your-sonarqube:9000 \
  -Dsonar.login=your-token
```

## 📁 Project Structure

```
recombo-integration/
├── src/main/java/com/hireright/recombointegration/
│   ├── controller/              # REST API controllers
│   │   ├── FulfillmentTaskController.java
│   │   └── TaskResultsController.java
│   ├── service/                 # Business logic services
│   │   ├── SubmitService.java
│   │   └── impl/
│   ├── dto/                     # Data Transfer Objects
│   │   ├── cloudevents/        # CloudEvents DTOs
│   │   ├── education/          # Education verification DTOs
│   │   └── employment/         # Employment verification DTOs
│   ├── security/               # Security filters & validators
│   │   ├── JwtAuthenticationFilter.java
│   │   ├── JwtTokenValidator.java
│   │   ├── ApiVersionValidationFilter.java
│   │   └── SecurityConfig.java
│   ├── config/                 # Configuration classes
│   ├── http/                   # HTTP client configuration
│   ├── log/                    # Logging services
│   └── util/                   # Utilities & constants
│       ├── CloudEventsConstants.java
│       └── Constant.java
├── src/main/resources/
│   ├── application.properties  # Application configuration
│   └── mock/                   # Mock JSON responses
│       ├── education/
│       └── employment/
├── pom.xml                     # Maven configuration
├── Dockerfile                  # Docker configuration
└── README.md                   # This file
```

## ⚙️ Configuration

### Environment Variables
```bash
# JWT Configuration
export JWT_SECRET=your-256-bit-secret-key

# API Version Configuration
export API_SUPPORTED_VERSIONS=v1,v2
export API_LATEST_VERSION=v2

# Recombo Service Configuration
export RECOMBO_SERVICE_BASE_URL=http://localhost:8082

# Logging Configuration
export HRG_WEBAPP_LOGGING_INITIAL_GLX_POSTING_URL=http://logging-service:8087/log_receiver/postGlx
```

### Application Profiles
- **dev** - Development environment
- **test** - Test environment
- **prod** - Production environment

## 📚 Documentation

- **[Quick Start Guide](QUICK_START.md)** - Get started quickly
- **[Maven Build Guide](MAVEN_BUILD.md)** - Complete Maven documentation
- **[API Version Validation](API_VERSION_VALIDATION.md)** - API versioning guide
- **[Refactoring Summary](REFACTORING_SUMMARY.md)** - Code quality improvements
- **[Swagger UI](http://localhost:8080/recombo-integration/swagger-ui.html)** - Interactive API documentation

## 🔧 Troubleshooting

### Build Issues
```bash
# Clear Maven cache
rm -rf ~/.m2/repository

# Force update dependencies
./mvnw clean install -U

# Verbose output
./mvnw clean install -X
```

### Runtime Issues
```bash
# Check application logs
tail -f logs/application.log

# Run with debug logging
./mvnw spring-boot:run -Dlogging.level.root=DEBUG
```

### Port Already in Use
```bash
# Find process using port 8080
lsof -i :8080

# Kill the process
kill -9 <PID>

# Or use different port
./mvnw spring-boot:run -Dserver.port=8081
```

## 🏗️ Technology Stack

- **Java 21** - Programming language
- **Spring Boot 3.2.4** - Application framework
- **Spring Security** - Authentication & authorization
- **Maven** - Build tool
- **Jackson** - JSON/XML processing
- **JWT (jjwt)** - Token authentication
- **OpenTelemetry** - Distributed tracing
- **Prometheus** - Metrics
- **JaCoCo** - Code coverage
- **Lombok** - Boilerplate reduction
- **SpringDoc OpenAPI** - API documentation

## 📄 License

Copyright 2001-2025 by HireRight, Inc. All rights reserved.

## 👥 Support

For issues or questions:
1. Check the documentation in this repository
2. Review application logs
3. Contact the development team

---

**Built with ❤️ by HireRight Engineering Team**

