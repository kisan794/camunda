# Education Verification API

## Overview
This API provides education verification services using mock data for testing purposes.

## Endpoint

### POST `/recombo-integration/api/education-verification`

Retrieves education verification data for a given screening ID.

## Request Format

```json
{
  "id": "EDU-001"
}
```

### Request Parameters
- `id` (String, required): The education verification screening ID (e.g., EDU-001, EDU-002, etc.)

## Response Format

### Success Response (200 OK)

```json
{
  "status": "SUCCESS",
  "message": "Education verification request processed successfully",
  "data": {
    "id": "hrg:hre:data-request:111111111",
    "refid": "hrg:hre:order-item:HE-010101-AAAA11-ED-001",
    "request": {
      "hrgSource": {
        "product": {
          "sku": "VF-ED-IEDU-CORE-USA",
          "name": "Education Verification Report"
        },
        "institution": {
          "name": "New York University",
          "location": {
            "city": "New York",
            "region": "NY",
            "country": "US",
            "postalCode": "10003"
          },
          "tenure": {
            "start": "2015-09",
            "end": "2019-05",
            "current": false
          },
          "qualifications": [
            {
              "verify": true,
              "degree": "Bachelor of Arts",
              "major": "Psychology",
              "minor": "Sociology",
              "tenure": {
                "start": "2015-09",
                "end": "2019-05",
                "current": false
              }
            }
          ]
        },
        "guidelines": [
          "Verify degree, major, and graduation date with registrar",
          "Confirm dates of attendance",
          "Verify honors designation"
        ],
        "referenceObjects": [
          {
            "type": "order-item",
            "id": "hrg:hre:order-item:HE-010101-AAAA11-ED-001-REF",
            "name": "primary education verification"
          }
        ],
        "notes": [
          {
            "date": "2024-11-15",
            "originator": "Verification Specialist",
            "note": "Candidate claims Cum Laude honors - verify with registrar"
          }
        ]
      },
      "dataSource": {
        "name": "NSCH",
        "type": "education",
        "screening": [
          {
            "orderServiceNo": "NY-111524-NYU01-ED-001",
            "serviceId": "5",
            "hrSchoolId": "NYU-001",
            "nschSchoolId": "002785",
            "contact": {
              "personName": "Sarah Johnson",
              "title": "Registrar Assistant"
            },
            "institution": {
              "name": "New York University",
              "programs": [
                {
                  "verify": true,
                  "degree": "Bachelor of Arts",
                  "major": "Psychology",
                  "minor": "Sociology",
                  "tenure": {
                    "startDate": "2015-09-01",
                    "endDate": "2019-05-15",
                    "current": false
                  }
                }
              ]
            }
          }
        ]
      }
    }
  }
}
```

### Error Response (404 Not Found)

```json
{
  "status": "FAILED",
  "message": "Education verification failed: Education verification data not found for ID: EDU-999",
  "error": "IllegalArgumentException"
}
```

### Error Response (500 Internal Server Error)

```json
{
  "status": "FAILED",
  "message": "Processing failed: <error message>",
  "error": "<error type>"
}
```

## Available Mock Data

The following education verification IDs are available:

| ID | Institution | Degree Type | Location | Notes |
|----|-------------|-------------|----------|-------|
| EDU-001 | New York University | Bachelor of Arts in Psychology | New York, NY | Single degree with honors |
| EDU-002 | University of Michigan | BBA in Business Administration | Ann Arbor, MI | Major name discrepancy |
| EDU-003 | Georgia Institute of Technology | Master of Science in Data Science | Atlanta, GA | Withdrawn student |
| EDU-004 | Phoenix Community College | Associate of Applied Science | Phoenix, AZ | Closed institution |
| EDU-005 | University of Toronto | BEng & MEng in Engineering | Toronto, ON, Canada | International multi-degree |

## cURL Examples

### Example 1: Verify NYU Education (EDU-001)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/education-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EDU-001"}'
```

### Example 2: Verify University of Michigan (EDU-002)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/education-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EDU-002"}'
```

### Example 3: Verify Georgia Tech (EDU-003)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/education-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EDU-003"}'
```

### Example 4: Verify Phoenix Community College (EDU-004)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/education-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EDU-004"}'
```

### Example 5: Verify University of Toronto (EDU-005)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/education-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EDU-005"}'
```

### Example 6: Test Error Handling (Invalid ID)

```bash
curl -X POST http://localhost:8080/recombo-integration/api/education-verification \
  -H "Content-Type: application/json" \
  -d '{"id": "EDU-999"}'
```

## Data Structure

### EducationDataRequest
The main DTO containing:
- `id`: Unique data request identifier
- `refid`: Reference to the order item
- `request`: Contains hrgSource and dataSource

### HrgSource
Contains verification requirements:
- `product`: Product SKU and name
- `institution`: Institution details and qualifications
- `guidelines`: Verification guidelines
- `referenceObjects`: Related order items
- `notes`: Verification notes

### DataSource
Contains screening data:
- `name`: Data source name (NSCH, WES, etc.)
- `type`: Type of verification (education)
- `screening`: Array of screening records

## Implementation Details

### Controller
- **Class**: `EducationVerificationController`
- **Package**: `com.hireright.recombointegration.controller`
- **Endpoint**: `/recombo-integration/api/education-verification`
- **Method**: POST

### DTOs
All DTOs are located in `com.hireright.recombointegration.dto.education`:
- EducationDataRequest
- Request
- HrgSource
- Product
- Institution
- Location
- Tenure
- Qualification
- ReferenceObject
- Note
- DataSource
- Screening
- Contact
- ScreeningInstitution
- Program

### Helper
- **Class**: `ReadEducationMockResponse`
- **Package**: `com.hireright.recombointegration.helper`
- **Purpose**: Reads mock JSON files from `/mock/EDU-*.json`

### Mock Data Files
Located in `src/main/resources/mock/`:
- EDU-001.json
- EDU-002.json
- EDU-003.json
- EDU-004.json
- EDU-005.json

## Testing

To test the API:

1. Start the application:
   ```bash
   ./gradlew bootRun
   ```

2. Use the cURL examples above or use a tool like Postman

3. Access Swagger UI (if enabled):
   ```
   http://localhost:8080/swagger-ui.html
   ```

## Notes

- This API uses mock data for testing purposes
- The logging service integration is included for production use
- All responses follow the standard response wrapper format
- Error handling includes both 404 (not found) and 500 (server error) responses

