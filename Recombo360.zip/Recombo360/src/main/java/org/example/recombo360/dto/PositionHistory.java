/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package org.example.recombo360.dto;

public class PositionHistory {
	private String title;
	private String startDate;
	private String endDate;
	private String mostRecentHireDate;
	private String employeeStatusCode;
	private String employeeStatus;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getMostRecentHireDate() {
		return mostRecentHireDate;
	}

	public void setMostRecentHireDate(String mostRecentHireDate) {
		this.mostRecentHireDate = mostRecentHireDate;
	}

	public String getEmployeeStatusCode() {
		return employeeStatusCode;
	}

	public void setEmployeeStatusCode(String employeeStatusCode) {
		this.employeeStatusCode = employeeStatusCode;
	}

	public String getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}
}
