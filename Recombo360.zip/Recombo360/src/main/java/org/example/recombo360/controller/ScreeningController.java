package org.example.recombo360.controller;

import org.example.recombo360.service.ScreeningService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/screening")
public class ScreeningController {

    private final ScreeningService screeningService;

    public ScreeningController(ScreeningService screeningService) {
        this.screeningService = screeningService;
    }

    @PostMapping("/submit")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void submitScreening(@RequestBody Map<String, Object> requestData) {
        screeningService.processScreeningAsync(requestData);
    }
}

