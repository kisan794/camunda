package org.example.recombo360.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
public class ScreeningService {

    private static final Logger logger = LoggerFactory.getLogger(ScreeningService.class);

    private final WebClient webClient;

    @Value("${screening.external.api.url:http://localhost:8081/api/external/screening}")
    private String externalApiUrl;

    public ScreeningService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    public void processScreeningAsync(Map<String, Object> requestData) {
        logger.info("Received screening request {}, will process in 4 seconds", requestData);

        // Create a new thread to handle the delay and external service call
        new Thread(() -> {
            try {
                // Wait for 4 seconds before calling external service
                TimeUnit.SECONDS.sleep(4);

                // Call external service API
                callExternalService(createCallBackRequest(String.valueOf(requestData.get("id"))));

            } catch (InterruptedException e) {
                logger.error("Thread was interrupted while waiting", e);
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                logger.error("Error processing screening request", e);
            }
        }).start();
    }

    private void callExternalService(Map<String, Object> requestData) {
        logger.info("Calling external service at: {}", externalApiUrl);

        try {
            webClient.post()
                    .uri(externalApiUrl)
                    .bodyValue(requestData)
                    .retrieve()
                    .bodyToMono(String.class)
                    .doOnSuccess(response -> logger.info("External service call successful: {}", response))
                    .doOnError(error -> logger.error("External service call failed", error))
                    .subscribe();

        } catch (Exception e) {
            logger.error("Failed to call external service", e);
        }
    }

    private Map<String, Object> createCallBackRequest(String id) {
        Map<String, Object> map = new HashMap<>();
        map.put("status", "SUCCESS");
        map.put("id", id);
        map.put("message", "Screening completed successfully");
        return map;
    }
}

