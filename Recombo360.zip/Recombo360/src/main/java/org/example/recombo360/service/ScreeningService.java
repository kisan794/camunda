package org.example.recombo360.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.recombo360.dto.Response;
import org.example.recombo360.dto.ScreeningRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

@Service
public class ScreeningService {

    private static final Logger logger = LoggerFactory.getLogger(ScreeningService.class);

    private final WebClient webClient;

    @Value("${screening.external.api.url:http://localhost:8081/api/external/screening}")
    private String externalApiUrl;

    public ScreeningService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }


    public Map<String, Object> callExternalService(ScreeningRequest requestData) {
        logger.info("Calling external service at: {}", externalApiUrl);

        try {
            String response = webClient.post()
                .uri(externalApiUrl)
                .bodyValue(requestData)
                .retrieve()
                .bodyToMono(String.class)
                .block(); // synchronous for simplicity

            // Parse JSON string into Map
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> responseMap = mapper.readValue(response, Map.class);

            logger.info("External service call successful: {}", responseMap);
            return responseMap;

        } catch (Exception e) {
            logger.error("Failed to call external service", e);
            return Map.of("error", e.getMessage());
        }
    }

}

