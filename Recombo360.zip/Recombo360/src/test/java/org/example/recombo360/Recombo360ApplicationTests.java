package org.example.recombo360;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Recombo360ApplicationTests {

    @Test
    void contextLoads() {
    }

}
