package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-04-11  ATS-1264 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class CRequestConfiguration {
    @JsonProperty("tenant")
    private String m_sTenant;

    @JsonProperty("originator")
    private String m_sOriginator;

    @JsonProperty("transactionId")
    private String m_sTransactionID;

    private CRequestConfiguration() {
    }

    public CRequestConfiguration(String sTenant, String sOriginator, String sTransactionID) {
        this.m_sTenant = sTenant;
        this.m_sOriginator = sOriginator;
        this.m_sTransactionID = sTransactionID;
    }

    public CRequestConfiguration(String sTenant, IObjectReference originator, String sTransactionID) {
        this.m_sTenant = sTenant;
        this.m_sOriginator = originator != null ? originator.serialize() : null;
        this.m_sTransactionID = sTransactionID;
    }

    private CRequestConfiguration(Builder builder) {
        this.m_sTenant = builder.m_sTenant;
        this.m_sOriginator = builder.m_sOriginator;
        this.m_sTransactionID = builder.m_sTransactionID;
    }

    public String getTenant() {
        return this.m_sTenant;
    }

    public String getOriginator() {
        return this.m_sOriginator;
    }

    public String getTransactionID() {
        return this.m_sTransactionID;
    }

    @Override
    public String toString() {
        return "CRequestConfiguration{" + "m_sTenant='" + this.m_sTenant + '\'' + ", m_sOriginator='" + this.m_sOriginator +
                '\'' + ", m_sTransactionID='" + this.m_sTransactionID + '\'' + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CRequestConfiguration that = (CRequestConfiguration) o;

        if (!Objects.equals(this.m_sTenant, that.m_sTenant)) {
            return false;
        }
        if (!Objects.equals(this.m_sOriginator, that.m_sOriginator)) {
            return false;
        }
        return Objects.equals(this.m_sTransactionID, that.m_sTransactionID);
    }

    @Override
    public int hashCode() {
        int result = this.m_sTenant != null ? this.m_sTenant.hashCode() : 0;
        result = 31 * result + (this.m_sOriginator != null ? this.m_sOriginator.hashCode() : 0);
        result = 31 * result + (this.m_sTransactionID != null ? this.m_sTransactionID.hashCode() : 0);
        return result;
    }

    public static final class Builder {
        private String m_sTenant;
        private String m_sOriginator;
        private String m_sTransactionID;

        public Builder() {
        }

        public Builder(CRequestConfiguration copy) {
            if (copy == null) {
                return;
            }

            this.m_sTenant = copy.getTenant();
            this.m_sOriginator = copy.getOriginator();
            this.m_sTransactionID = copy.getTransactionID();
        }

        public Builder tenant(String sTenant) {
            this.m_sTenant = sTenant;
            return this;
        }

        public Builder operator(String sOperator) {
            this.m_sOriginator =
                    sOperator != null && !sOperator.trim().isEmpty() ? "OPERATOR:" + sOperator.trim() : null;
            return this;
        }

        public Builder originator(String sOriginator) {
            this.m_sOriginator = sOriginator;
            return this;
        }

        public Builder originator(IObjectReference originator) {
            if (originator != null) {
                this.m_sOriginator = originator.serialize();
            }
            return this;
        }

        public Builder transactionID(String sTransactionID) {
            this.m_sTransactionID = sTransactionID;
            return this;
        }

        public CRequestConfiguration build() {
            return new CRequestConfiguration(this);
        }
    }
}
