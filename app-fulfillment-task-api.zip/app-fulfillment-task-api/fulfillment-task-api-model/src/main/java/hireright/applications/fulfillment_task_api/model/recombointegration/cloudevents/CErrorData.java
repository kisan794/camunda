package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

/**
 * Error data payload for CloudEvents error responses.
 *
 * @author Keshav Ladha
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"status", "error", "errorCode", "message", "reason", "details"})
public class CErrorData {

    @JsonProperty("status")
    private Integer m_nStatus;

    @JsonProperty("error")
    private String m_sError;

    @JsonProperty("errorCode")
    private String m_sErrorCode;

    @JsonProperty("message")
    private String m_sMessage;

    @JsonProperty("reason")
    private String m_sReason;

    @JsonProperty("details")
    private List<CValidationDetail> m_details;

    private CErrorData() {
    }

    public CErrorData(Builder builder) {
        this.m_nStatus = builder.m_nStatus;
        this.m_sError = builder.m_sError;
        this.m_sErrorCode = builder.m_sErrorCode;
        this.m_sMessage = builder.m_sMessage;
        this.m_sReason = builder.m_sReason;
        this.m_details = builder.m_details;
    }

    public Integer getStatus() {
        return m_nStatus;
    }

    public String getError() {
        return m_sError;
    }

    public String getErrorCode() {
        return m_sErrorCode;
    }

    public String getMessage() {
        return m_sMessage;
    }

    public String getReason() {
        return m_sReason;
    }

    public List<CValidationDetail> getDetails() {
        return m_details;
    }

    public static final class Builder {

        private Integer m_nStatus;
        private String m_sError;
        private String m_sErrorCode;
        private String m_sMessage;
        private String m_sReason;
        private List<CValidationDetail> m_details;

        public Builder() {
        }

        public Builder status(Integer nStatus) {
            m_nStatus = nStatus;
            return this;
        }

        public Builder error(String sError) {
            m_sError = sError;
            return this;
        }

        public Builder errorCode(String sErrorCode) {
            m_sErrorCode = sErrorCode;
            return this;
        }

        public Builder message(String sMessage) {
            m_sMessage = sMessage;
            return this;
        }

        public Builder reason(String sReason) {
            m_sReason = sReason;
            return this;
        }

        public Builder details(List<CValidationDetail> details) {
            m_details = details;
            return this;
        }

        public CErrorData build() {
            return new CErrorData(this);
        }
    }
}
