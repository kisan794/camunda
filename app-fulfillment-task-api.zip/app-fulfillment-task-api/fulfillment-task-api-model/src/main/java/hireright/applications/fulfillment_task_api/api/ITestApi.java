package hireright.applications.fulfillment_task_api.api;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 * M.Naumov   2025-05-19  HRG-337113 adding getOrderFormInstructionManager
 */

import hireright.applications.fulfillment_task_api.api.management.IServiceHealthManager;
import hireright.applications.fulfillment_task_api.api.management.ITestManager;

public interface ITestApi {

    ITestManager getTestManager();
    IServiceHealthManager getServiceHealthManager();
}
