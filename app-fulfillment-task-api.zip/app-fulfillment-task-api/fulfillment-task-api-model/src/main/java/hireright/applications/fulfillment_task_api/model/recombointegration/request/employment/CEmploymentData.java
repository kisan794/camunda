package hireright.applications.fulfillment_task_api.model.recombointegration.request.employment;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Employment Request DTO containing HRG source and data source information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"providedSource", "dataSource"})
public class CEmploymentData {

    @JsonProperty("providedSource")
    private CProvidedSource m_providedSource;

    @JsonProperty("dataSource")
    private CDataSource m_dataSource;

    private CEmploymentData() {
    }

    private CEmploymentData(Builder builder) {
        m_providedSource = builder.m_providedSource;
        m_dataSource = builder.m_dataSource;
    }

    public CProvidedSource getProvidedSource() {
        return m_providedSource;
    }

    public CDataSource getDataSource() {
        return m_dataSource;
    }

    public static final class Builder {

        private CProvidedSource m_providedSource;
        private CDataSource m_dataSource;

        public Builder() {
        }

        public Builder providedSource(CProvidedSource providedSource) {
            m_providedSource = providedSource;
            return this;
        }

        public Builder dataSource(CDataSource dataSource) {
            m_dataSource = dataSource;
            return this;
        }

        public CEmploymentData build() {
            return new CEmploymentData(this);
        }
    }
}
