package hireright.applications.fulfillment_task_api.model.serialization;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CLocalDateTimeDeserializer extends StdDeserializer<LocalDateTime> {
    protected CLocalDateTimeDeserializer() {
        super(LocalDateTime.class);
    }

    @Override
    public LocalDateTime deserialize(JsonParser parser, DeserializationContext context) throws IOException {
        String sValue = parser.readValueAs(String.class);

        if (sValue == null || sValue.trim().isEmpty()) {
            return null;
        }

        if (sValue.endsWith("Z")) {
            sValue = sValue.substring(0, sValue.length() - 1);
        }

        try {
            return LocalDateTime.parse(sValue, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        } catch (Exception ignored) {
            return LocalDateTime.parse(sValue);
        }
    }
}
