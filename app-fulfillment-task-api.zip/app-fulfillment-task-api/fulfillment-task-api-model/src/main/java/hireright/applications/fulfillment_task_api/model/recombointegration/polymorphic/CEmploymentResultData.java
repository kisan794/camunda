package hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * Employment-specific result data for employment verification results.
 * Contains employer organization information and position history.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonTypeName("EMPLOYMENT")
@JsonPropertyOrder({"city", "region", "country", "employerOrgName", "positionHistory"})
public class CEmploymentResultData extends CBaseResultData {

    /**
     * Employment-specific fields
     */
    @JsonProperty("employerOrgName")
    private String m_sEmployerOrgName;

    @JsonProperty("positionHistory")
    private CPositionHistory m_positionHistory;

    private CEmploymentResultData(Builder builder) {
        m_sCity = builder.m_sCity;
        m_sRegion = builder.m_sRegion;
        m_sCountry = builder.m_sCountry;
        m_sEmployerOrgName = builder.m_sEmployerOrgName;
        m_positionHistory = builder.m_positionHistory;
    }

    public String getEmployerOrgName() {
        return m_sEmployerOrgName;
    }

    public CPositionHistory getPositionHistory() {
        return m_positionHistory;
    }

    public void setPositionHistory(CPositionHistory m_positionHistory) {
        this.m_positionHistory = m_positionHistory;
    }

    public static class Builder {

        private String m_sCity;
        private String m_sRegion;
        private String m_sCountry;
        private String m_sEmployerOrgName;
        private CPositionHistory m_positionHistory;

        public Builder() {
        }

        public Builder city(String sCity) {
            this.m_sCity = sCity;
            return this;
        }

        public Builder region(String sRegion) {
            this.m_sRegion = sRegion;
            return this;
        }

        public Builder country(String sCountry) {
            this.m_sCountry = sCountry;
            return this;
        }

        public Builder employerOrgName(String sEmployerOrgName) {
            m_sEmployerOrgName = sEmployerOrgName;
            return this;
        }

        public Builder positionHistory(CPositionHistory positionHistory) {
            m_positionHistory = positionHistory;
            return this;
        }

        public CEmploymentResultData build() {
            return new CEmploymentResultData(this);
        }
    }
}

