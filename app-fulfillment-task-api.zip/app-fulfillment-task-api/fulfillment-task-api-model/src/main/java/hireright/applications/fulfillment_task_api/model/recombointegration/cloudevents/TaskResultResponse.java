/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.util.UUID;

/**
 * CloudEvents format response for task results following CloudEvents v1.0 specification.
 * This class represents successful acceptance of task result submissions.
 *
 * @see <a href="https://github.com/cloudevents/spec/blob/v1.0/spec.md">CloudEvents Specification v1.0</a>
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class TaskResultResponse {

    private String specversion;

    private String id;

    private String source;

    private String type;

    private String datacontenttype;

    private String time;

    private TaskAcceptedData data;

    /**
     * Create a success response for accepted task result.
     *
     * @param taskId The task identifier
     * @param requestId The original request identifier (currently unused, reserved for future use)
     * @return TaskResultResponse configured for successful acceptance
     * @throws IllegalArgumentException if taskId is null or empty
     */
    public static TaskResultResponse accepted(String taskId, String requestId) {
        if (taskId == null || taskId.trim().isEmpty()) {
            log.error("Task ID cannot be null or empty");
            throw new IllegalArgumentException("Task ID cannot be null or empty");
        }

        Instant now = Instant.now();
        String responseId = UUID.randomUUID().toString();
        Instant expectedCompletion = now.plusSeconds(CloudEventsConstants.EXPECTED_COMPLETION_SECONDS);

        log.debug("Creating task accepted response - TaskId: {}, ResponseId: {}", taskId, responseId);

        TaskAcceptedData acceptedData = TaskAcceptedData.builder()
            .taskId(taskId)
            .status(CloudEventsConstants.STATUS_PENDING)
            .submittedAt(now.toString())
            .expectedCompletion(expectedCompletion.toString())
            .message(CloudEventsConstants.MSG_TASK_ACCEPTED)
            .build();

        return TaskResultResponse.builder()
            .specversion(CloudEventsConstants.CLOUDEVENTS_VERSION)
            .id(responseId)
            .source(CloudEventsConstants.SOURCE_FULFILLMENT_API)
            .type(CloudEventsConstants.TYPE_TASK_ACCEPTED)
            .datacontenttype(CloudEventsConstants.CONTENT_TYPE_JSON)
            .time(now.toString())
            .data(acceptedData)
            .build();
    }
}

