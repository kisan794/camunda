package hireright.applications.fulfillment_task_api.model.recombointegration.request.education;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.CDataRequest;

/**
 * Root DTO for Education Verification Data Request
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"specversion", "id", "source", "type", "datacontenttype", "time", "dataschema", "data"})
public class CEducationDataRequest extends CDataRequest<CEducationData> {

    private CEducationDataRequest() {
    }

    public CEducationDataRequest(Builder builder) {
        m_sSpecVersion = builder.m_sSpecVersion;
        m_sId = builder.m_sId;
        m_sSource = builder.m_sSource;
        m_sType = builder.m_sType;
        m_sDataContentType = builder.m_sDataContentType;
        m_sTime = builder.m_sTime;
        m_sDataSchema = builder.m_sDataSchema;
        m_data = builder.m_data;
    }

    public CEducationData getData() {
        return m_data;
    }

    public static final class Builder {

        private String m_sSpecVersion;
        private String m_sId;
        private String m_sSource;
        private String m_sType;
        private String m_sDataContentType;
        private String m_sTime;
        private String m_sDataSchema;
        private CEducationData m_data;

        public Builder() {
        }

        public Builder specVersion(String specVersion) {
            m_sSpecVersion = specVersion;
            return this;
        }

        public Builder id(String id) {
            m_sId = id;
            return this;
        }

        public Builder source(String source) {
            m_sSource = source;
            return this;
        }

        public Builder type(String type) {
            m_sType = type;
            return this;
        }

        public Builder dataContentType(String dataContentType) {
            m_sDataContentType = dataContentType;
            return this;
        }

        public Builder time(String time) {
            m_sTime = time;
            return this;
        }

        public Builder dataSchema(String dataSchema) {
            m_sDataSchema = dataSchema;
            return this;
        }

        public Builder data(CEducationData data) {
            m_data = data;
            return this;
        }

        public CEducationDataRequest build() {
            return new CEducationDataRequest(this);
        }
    }
}

