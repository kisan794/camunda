package hireright.applications.fulfillment_task_api.api;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import java.util.function.Supplier;

public interface ITestApiProvider extends Supplier<ITestApi> {
    ITestApi getApi();

    @Override
    default ITestApi get() {
        return getApi();
    }
}
