package hireright.applications.fulfillment_task_api.model.recombointegration.request.employment;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CTenure;

@JsonPropertyOrder({"title", "tenure", "spokeWith", "reasonForLeaving", "eligibleForRehire"})
public class CPosition {

    @JsonProperty("title")
    private String m_sTitle;

    @JsonProperty("tenure")
    private CTenure m_tenure;

    @JsonProperty("spokeWith")
    private String m_sSpokeWith;

    @JsonProperty("reasonForLeaving")
    private String m_sReasonForLeaving;

    @JsonProperty("eligibleForRehire")
    private String m_sEligibleForRehire;

    private CPosition() {
    }

    private CPosition(Builder builder) {
        m_sTitle = builder.m_sTitle;
        m_tenure = builder.m_tenure;
        m_sSpokeWith = builder.m_sSpokeWith;
        m_sReasonForLeaving = builder.m_sReasonForLeaving;
        m_sEligibleForRehire = builder.m_sEligibleForRehire;
    }

    public String getTitle() {
        return m_sTitle;
    }

    public CTenure getTenure() {
        return m_tenure;
    }

    public String getSpokeWith() {
        return m_sSpokeWith;
    }

    public String getReasonForLeaving() {
        return m_sReasonForLeaving;
    }

    public String getEligibleForRehire() {
        return m_sEligibleForRehire;
    }

    public static final class Builder {

        private String m_sTitle;
        private CTenure m_tenure;
        private String m_sSpokeWith;
        private String m_sReasonForLeaving;
        private String m_sEligibleForRehire;

        public Builder() {
        }

        public Builder title(String sTitle) {
            m_sTitle = sTitle;
            return this;
        }

        public Builder tenure(CTenure tenure) {
            m_tenure = tenure;
            return this;
        }

        public Builder spokeWith(String spokeWith) {
            m_sSpokeWith = spokeWith;
            return this;
        }

        public Builder reasonForLeaving(String sReasonForLeaving) {
            m_sReasonForLeaving = sReasonForLeaving;
            return this;
        }

        public Builder eligibleForRehire(String sEligibleForRehire) {
            m_sEligibleForRehire = sEligibleForRehire;
            return this;
        }

        public CPosition build() {
            return new CPosition(this);
        }
    }
}
