/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.employment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Compensation Info DTO for salary and pay information
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompensationInfo {
    
    private String currency;
    
    private String rateOfPay;
    
    private String averageHoursPerPayPeriod;
    
    private String dateOfPayIncreaseLast;
    
    private String amountOfPayIncreaseLast;
    
    private String dateOfPayIncreaseNext;
    
    private String amountOfPayIncreaseNext;
}

