/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.util;

/**
 * Constants for CloudEvents specification compliance.
 * 
 * <p>This class contains all CloudEvents-related constants used throughout the application
 * to ensure consistency and compliance with CloudEvents v1.0 specification.
 * 
 * @see <a href="https://github.com/cloudevents/spec/blob/v1.0/spec.md">CloudEvents Specification v1.0</a>
 * @author Keshav Ladha
 * @version 1.0
 */
public final class CloudEventsConstants
{
    
    // CloudEvents Specification
    public static final String CLOUDEVENTS_VERSION = "1.0";
    public static final String CONTENT_TYPE_JSON = "application/json";
    
    // Sources
    public static final String SOURCE_FULFILLMENT = "hrg:hre:fulfillment";
    public static final String SOURCE_FULFILLMENT_API = "hrg:hre:fulfillment-api";
    public static final String SOURCE_TASK = "hrg:hre:task";
    
    // Event Types
    public static final String TYPE_TASK_ACCEPTED = "Task.Accepted";
    public static final String TYPE_ERROR_AUTHENTICATION = "Error.Authentication";
    public static final String TYPE_ERROR_VALIDATION = "Error.Validation";
    public static final String TYPE_EMPLOYMENT_FULFILLMENT_RESULT = "EmploymentFulfillmentResult";
    public static final String TYPE_EDUCATION_FULFILLMENT_RESULT = "EducationFulfillmentResult";
    
    // Task Status
    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_PROCESSING = "PROCESSING";
    public static final String STATUS_COMPLETED = "COMPLETED";
    public static final String STATUS_FAILED = "FAILED";
    
    // Error Codes
    public static final String ERROR_CODE_AUTH = "AUTH001";
    public static final String ERROR_CODE_VALIDATION = "REQ001";
    public static final String ERROR_CODE_UNSUPPORTED_VERSION = "UNSUPPORTED_API_VERSION";
    
    // Error Messages
    public static final String ERROR_MSG_AUTH_DEFAULT = "Authentication token is missing or invalid";
    public static final String ERROR_MSG_VALIDATION_DEFAULT = "Input validation failed";
    public static final String ERROR_MSG_PROCESSING_FAILED = "Failed to process task result";
    
    // Error Reasons
    public static final String REASON_INVALID_TOKEN = "INVALID_TOKEN";
    public static final String REASON_EXPIRED_TOKEN = "EXPIRED_TOKEN";
    public static final String REASON_MISSING_TOKEN = "MISSING_TOKEN";
    public static final String REASON_INVALID_OR_EXPIRED_TOKEN = "INVALID_OR_EXPIRED_TOKEN";
    
    // HTTP Status Messages
    public static final String HTTP_STATUS_UNAUTHORIZED = "Unauthorized";
    public static final String HTTP_STATUS_BAD_REQUEST = "Bad Request";
    
    // Task Messages
    public static final String MSG_TASK_ACCEPTED = "Task request accepted for processing";
    
    // Time Constants
    public static final long EXPECTED_COMPLETION_SECONDS = 120L;
    
    /**
     * Private constructor to prevent instantiation.
     * This is a utility class with only static constants.
     */
    private CloudEventsConstants() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

