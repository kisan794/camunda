package hireright.applications.fulfillment_task_api.model.recombointegration.request.education;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CTenure;

/**
 * Qualification DTO for degree and major information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"degree", "major", "tenure", "grade", "degreeReceived", "degreeDate",
        "futureDegreeApproachDate", "plansToGraduateWithinLimit"})
public class CQualification {

    @JsonProperty("degree")
    private String m_sDegree;

    @JsonProperty("major")
    private String m_sMajor;

    @JsonProperty("tenure")
    private CTenure m_tenure;

    @JsonProperty("grade")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String m_sGrade;

    @JsonProperty("degreeReceived")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private boolean m_degreeReceived;

    @JsonProperty("degreeDate")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String m_sDegreeDate;

    @JsonProperty("futureDegreeApproachDate")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String m_sFutureDegreeApproachDate;

    @JsonProperty("plansToGraduateWithinLimit")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private boolean m_plansToGraduateWithinLimit;

    private CQualification() {
    }

    public CQualification(Builder builder) {
        m_sDegree = builder.m_sDegree;
        m_sMajor = builder.m_sMajor;
        m_tenure = builder.m_tenure;
        m_sGrade = builder.m_sGrade;
        m_degreeReceived = builder.m_degreeReceived;
        m_sDegreeDate = builder.m_sDegreeDate;
        m_sFutureDegreeApproachDate = builder.m_sFutureDegreeApproachDate;
        m_plansToGraduateWithinLimit = builder.m_plansToGraduateWithinLimit;
    }

    public String getDegree() {
        return m_sDegree;
    }

    public String getMajor() {
        return m_sMajor;
    }

    public CTenure getTenure() {
        return m_tenure;
    }

    public String getGrade() {
        return m_sGrade;
    }

    public boolean isDegreeReceived() {
        return m_degreeReceived;
    }

    public String getDegreeDate() {
        return m_sDegreeDate;
    }

    public String getFutureDegreeApproachDate() {
        return m_sFutureDegreeApproachDate;
    }

    public boolean isPlansToGraduateWithinLimit() {
        return m_plansToGraduateWithinLimit;
    }

    public static final class Builder {

        private String m_sDegree;
        private String m_sMajor;
        private CTenure m_tenure;
        private String m_sGrade;
        private boolean m_degreeReceived;
        private String m_sDegreeDate;
        private String m_sFutureDegreeApproachDate;
        private boolean m_plansToGraduateWithinLimit;

        public Builder() {
        }

        public Builder degree(String degree) {
            m_sDegree = degree;
            return this;
        }

        public Builder major(String major) {
            m_sMajor = major;
            return this;
        }

        public Builder tenure(CTenure tenure) {
            m_tenure = tenure;
            return this;
        }

        public Builder grade(String grade) {
            m_sGrade = grade;
            return this;
        }

        public Builder degreeReceived(boolean degreeReceived) {
            m_degreeReceived = degreeReceived;
            return this;
        }

        public Builder degreeDate(String degreeDate) {
            m_sDegreeDate = degreeDate;
            return this;
        }

        public Builder futureDegreeApproachDate(String futureDegreeApproachDate) {
            m_sFutureDegreeApproachDate = futureDegreeApproachDate;
            return this;
        }

        public Builder plansToGraduateWithinLimit(boolean plansToGraduateWithinLimit) {
            m_plansToGraduateWithinLimit = plansToGraduateWithinLimit;
            return this;
        }

        public CQualification build() {
            return new CQualification(this);
        }
    }
}