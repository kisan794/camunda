/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Error data payload for CloudEvents error responses.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorData {

	/**
	 * HTTP status code
	 */
	@JsonProperty("status")
	private Integer status;

	/**
	 * Error type/category
	 */
	@JsonProperty("error")
	private String error;

	/**
	 * Application-specific error code
	 */
	@JsonProperty("errorCode")
	private String errorCode;

	/**
	 * Human-readable error message
	 */
	@JsonProperty("message")
	private String message;

	/**
	 * Reason for the error (optional, used for authentication errors)
	 */
	@JsonProperty("reason")
	private String reason;

	/**
	 * Validation error details (optional, used for validation errors)
	 */
	@JsonProperty("details")
	private List<ValidationDetail> details;
}
