package hireright.applications.fulfillment_task_api.model.recombointegration.request.employment;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"companyName", "accountName", "companyCode"})
public class CClient {

    @JsonProperty("companyName")
    private String m_sCompanyName;

    @JsonProperty("accountName")
    private String m_sAccountName;

    @JsonProperty("companyCode")
    private String m_sCompanyCode;

    private CClient() {
    }

    public CClient(Builder builder) {
        m_sCompanyName = builder.m_sCompanyName;
        m_sAccountName = builder.m_sAccountName;
        m_sCompanyCode = builder.m_sCompanyCode;
    }

    public String getCompanyName() {
        return m_sCompanyName;
    }

    public String getAccountName() {
        return m_sAccountName;
    }

    public String getCompanyCode() {
        return m_sCompanyCode;
    }

    public static final class Builder {

        private String m_sCompanyName;
        private String m_sAccountName;
        private String m_sCompanyCode;

        public Builder() {
        }

        public Builder companyName(String companyName) {
            m_sCompanyName = companyName;
            return this;
        }

        public Builder accountName(String accountName) {
            m_sAccountName = accountName;
            return this;
        }

        public Builder companyCode(String companyCode) {
            m_sCompanyCode = companyCode;
            return this;
        }

        public CClient build() {
            return new CClient(this);
        }
    }
}
