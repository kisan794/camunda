/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Abstract base class for result data supporting polymorphic deserialization.
 * This enables type-safe handling of both Employment and Education verification results.
 *
 * The type is determined automatically by the presence of specific fields in the JSON:
 * - If "employerOrgName" is present → EmploymentResultData
 * - If "institutionName" is present → EducationResultData
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@SuperBuilder
@NoArgsConstructor
@JsonDeserialize(using = ResultDataDeserializer.class)
public abstract class BaseResultData {

    /**
     * Common fields for both employment and education results
     */
    private String city;

    private String region;

    private String country;

}

