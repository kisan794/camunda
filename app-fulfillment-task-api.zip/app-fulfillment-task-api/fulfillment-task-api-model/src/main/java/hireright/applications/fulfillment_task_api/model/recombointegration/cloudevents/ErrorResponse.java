/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * CloudEvents v1.0 compliant error response.
 * Used for returning structured error information following CloudEvents specification.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorResponse {

	/**
	 * CloudEvents version (always "1.0")
	 */
	@Builder.Default
	@JsonProperty("specversion")
	private String specversion = "1.0";

	/**
	 * Unique identifier for this error event (typically the request ID)
	 */
	@JsonProperty("id")
	private String id;

	/**
	 * Source of the error event
	 */
	@Builder.Default
	@JsonProperty("source")
	private String source = "hrg:hre:fulfillment";

	/**
	 * Type of error (e.g., "Error.Authentication", "Error.Validation")
	 */
	@JsonProperty("type")
	private String type;

	/**
	 * Content type of the data field
	 */
	@Builder.Default
	@JsonProperty("datacontenttype")
	private String datacontenttype = "application/json";

	/**
	 * Timestamp when the error occurred
	 */
	@Builder.Default
	@JsonProperty("time")
	private String time = Instant.now().toString();

	/**
	 * Error data payload
	 */
	@JsonProperty("data")
	private ErrorData data;

	/**
	 * Create an authentication error response
	 */
	public static ErrorResponse authenticationError(String requestId, String message, String reason) {
		return ErrorResponse.builder()
			.id(requestId)
			.type("Error.Authentication")
			.data(ErrorData.builder()
				.status(401)
				.error("Unauthorized")
				.message(message)
				.errorCode("AUTH001")
				.reason(reason)
				.build())
			.build();
	}

	/**
	 * Create a validation error response
	 */
	public static ErrorResponse validationError(String requestId, String message, java.util.List<ValidationDetail> details) {
		return ErrorResponse.builder()
			.id(requestId)
			.type("Error.Validation")
			.source("hrg:hre:task")
			.data(ErrorData.builder()
				.status(400)
				.error("Bad Request")
				.errorCode("REQ001")
				.message(message)
				.details(details)
				.build())
			.build();
	}

	/**
	 * Create a generic error response
	 */
	public static ErrorResponse genericError(String requestId, String type, int status, String error, String errorCode, String message) {
		return ErrorResponse.builder()
			.id(requestId)
			.type(type)
			.data(ErrorData.builder()
				.status(status)
				.error(error)
				.errorCode(errorCode)
				.message(message)
				.build())
			.build();
	}
}
