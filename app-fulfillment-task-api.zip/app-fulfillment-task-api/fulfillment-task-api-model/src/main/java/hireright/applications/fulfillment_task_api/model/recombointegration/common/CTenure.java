package hireright.applications.fulfillment_task_api.model.recombointegration.common;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Employment Tenure DTO for date range information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"start", "end", "current"})
public class CTenure {

    @JsonProperty("start")
    private String m_sStart;

    @JsonProperty("end")
    private String m_sEnd;

    @JsonProperty("current")
    private boolean m_current;

    private CTenure() {
    }

    private CTenure(Builder builder) {
        m_sStart = builder.m_sStart;
        m_sEnd = builder.m_sEnd;
        m_current = builder.m_current;
    }

    public String getStart() {
        return m_sStart;
    }

    public String getEnd() {
        return m_sEnd;
    }

    public boolean isCurrent() {
        return m_current;
    }

    public static final class Builder {

        private String m_sStart;
        private String m_sEnd;
        private boolean m_current;

        public Builder() {
        }

        public Builder start(String sStart) {
            m_sStart = sStart;
            return this;
        }

        public Builder end(String sEnd) {
            m_sEnd = sEnd;
            return this;
        }

        public Builder current(boolean current) {
            m_current = current;
            return this;
        }

        public CTenure build() {
            return new CTenure(this);
        }
    }
}

