package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Validation error detail for field-level validation errors.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"field", "message"})
public class CValidationDetail {

    /**
     * The field name that failed validation
     */
    @JsonProperty("field")
    private String m_sField;

    /**
     * The validation error message for this field
     */
    @JsonProperty("message")
    private String m_sMessage;

    private CValidationDetail() {
    }

    public CValidationDetail(Builder builder) {
        this.m_sField = builder.m_sField;
        this.m_sMessage = builder.m_sMessage;
    }

    public static final class Builder {

        private String m_sField;
        private String m_sMessage;

        public Builder() {
        }

        public Builder field(String sField) {
            m_sField = sField;
            return this;
        }

        public Builder message(String sMessage) {
            m_sMessage = sMessage;
            return this;
        }

        public CValidationDetail build() {
            return new CValidationDetail(this);
        }
    }
}