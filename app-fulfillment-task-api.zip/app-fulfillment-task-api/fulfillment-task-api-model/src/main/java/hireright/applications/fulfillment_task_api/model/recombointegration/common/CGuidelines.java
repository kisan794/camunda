package hireright.applications.fulfillment_task_api.model.recombointegration.common;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonPropertyOrder({"product", "client", "generic"})
public class CGuidelines {

    @JsonProperty("product")
    private List<String> m_product;

    @JsonProperty("client")
    private List<String> m_client;

    @JsonProperty("generic")
    private List<String> m_generic;

    private CGuidelines() {
    }

    private CGuidelines(Builder builder) {
        m_product = builder.m_product;
        m_client = builder.m_client;
        m_generic = builder.m_generic;
    }

    public List<String> getProduct() {
        return m_product;
    }

    public List<String> getClient() {
        return m_client;
    }

    public List<String> getGeneric() {
        return m_generic;
    }

    public static final class Builder {

        private List<String> m_product;
        private List<String> m_client;
        private List<String> m_generic;

        public Builder() {
        }

        public Builder product(List<String> product) {
            m_product = product;
            return this;
        }

        public Builder client(List<String> client) {
            m_client = client;
            return this;
        }

        public Builder generic(List<String> generic) {
            m_generic = generic;
            return this;
        }

        public CGuidelines build() {
            return new CGuidelines(this);
        }
    }
}
