package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Objects;

@XmlAccessorType (XmlAccessType.NONE)
@XmlRootElement (name = "Collection")
public class CCollection<T> implements Iterable<T>, Serializable {
    @XmlElement (name = "items")
    @JsonProperty ("items")
    private Collection<T> items = new ArrayList<>();

    @XmlAttribute (name = "offset")
    @JsonProperty ("offset")
    private Long m_lOffset;

    @XmlAttribute (name = "limit")
    @JsonProperty ("limit")
    private Integer m_nLimit;

    @XmlAttribute (name = "total")
    @JsonProperty ("total")
    private Long m_lTotal;

    private CCollection() {
    }

    private CCollection(Builder<T> builder) {
        this.items.addAll(builder.m_items);
        this.m_lOffset = builder.m_lOffset;
        this.m_nLimit = builder.m_nLimit;
        this.m_lTotal = builder.m_lTotal;
    }

    public Collection<T> getItems() {
        return this.items != null ? Collections.unmodifiableCollection(this.items) : Collections.emptyList();
    }

    public Long getOffset() {
        return this.m_lOffset;
    }

    public Integer getLimit() {
        return this.m_nLimit;
    }

    public Long getTotal() {
        return this.m_lTotal;
    }

    public T getFirst() {
        return this.items != null && !this.items.isEmpty() ? this.items.iterator().next() : null;
    }

    public boolean isEmpty() {
        return this.items == null || this.items.isEmpty();
    }

    @Override
    public Iterator<T> iterator() {
        return getItems().iterator();
    }

    @Override
    public String toString() {
        return "CCollection{" + "m_items=" + this.items + ", m_lOffset=" + this.m_lOffset + ", m_nLimit=" + this.m_nLimit +
                ", m_lTotal=" + this.m_lTotal + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CCollection<?> that = (CCollection<?>) o;

        if (!Objects.equals(this.items, that.items)) {
            return false;
        }
        if (!Objects.equals(this.m_lOffset, that.m_lOffset)) {
            return false;
        }
        if (!Objects.equals(this.m_nLimit, that.m_nLimit)) {
            return false;
        }
        return Objects.equals(this.m_lTotal, that.m_lTotal);
    }

    @Override
    public int hashCode() {
        int result = this.items != null ? this.items.hashCode() : 0;
        result = 31 * result + (this.m_lOffset != null ? this.m_lOffset.hashCode() : 0);
        result = 31 * result + (this.m_nLimit != null ? this.m_nLimit.hashCode() : 0);
        result = 31 * result + (this.m_lTotal != null ? this.m_lTotal.hashCode() : 0);
        return result;
    }

    public static final class Builder<T> {
        private final Collection<T> m_items = new ArrayList<>();
        private Long m_lOffset;
        private Integer m_nLimit;
        private Long m_lTotal;

        public Builder() {
        }

        public Builder(CCollection<T> copy) {
            if (copy == null) {
                return;
            }

            this.m_items.addAll(copy.getItems());
            this.m_lOffset = copy.getOffset();
            this.m_nLimit = copy.getLimit();
            this.m_lTotal = copy.getTotal();
        }

        public Builder<T> item(T item) {
            this.m_items.add(item);
            return this;
        }

        public Builder<T> items(Collection<T> items) {
            this.m_items.clear();
            if (items != null) {
                this.m_items.addAll(items);
            }
            return this;
        }

        public Builder<T> offset(Long lOffset) {
            this.m_lOffset = lOffset;
            return this;
        }

        public Builder<T> limit(Integer nLimit) {
            this.m_nLimit = nLimit;
            return this;
        }

        public Builder<T> total(Long lTotal) {
            this.m_lTotal = lTotal;
            return this;
        }

        public CCollection<T> build() {
            if (this.m_lTotal == null) {
                this.m_lTotal = 0L;
            }
            if (this.m_lOffset == null) {
                this.m_lOffset = 0L;
            }

            return new CCollection<>(this);
        }

        public static <R> CCollection<R> empty() {
            return new Builder<R>().build();
        }
    }
}
