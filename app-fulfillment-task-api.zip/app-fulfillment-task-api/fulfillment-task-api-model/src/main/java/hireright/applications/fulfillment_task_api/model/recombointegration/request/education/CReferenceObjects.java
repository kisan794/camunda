package hireright.applications.fulfillment_task_api.model.recombointegration.request.education;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Reference Object DTO for related order items
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"type", "id", "institution"})
public class CReferenceObjects {

    @JsonProperty("type")
    private String m_sType;

    @JsonProperty("id")
    private String m_sId;

    @JsonProperty("institution")
    private CInstitution m_institution;

    private CReferenceObjects() {
    }

    public CReferenceObjects(Builder builder) {
        m_sType = builder.m_sType;
        m_sId = builder.m_sId;
        m_institution = builder.m_institution;
    }

    public String getType() {
        return m_sType;
    }

    public String getId() {
        return m_sId;
    }

    public CInstitution getInstitution() {
        return m_institution;
    }

    public static final class Builder {

        private String m_sType;
        private String m_sId;
        private CInstitution m_institution;

        public Builder() {
        }

        public Builder type(String type) {
            m_sType = type;
            return this;
        }

        public Builder id(String id) {
            m_sId = id;
            return this;
        }

        public Builder institution(CInstitution institution) {
            m_institution = institution;
            return this;
        }

        public CReferenceObjects build() {
            return new CReferenceObjects(this);
        }
    }
}

