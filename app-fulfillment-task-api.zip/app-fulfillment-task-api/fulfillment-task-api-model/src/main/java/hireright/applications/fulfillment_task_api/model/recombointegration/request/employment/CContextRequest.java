package hireright.applications.fulfillment_task_api.model.recombointegration.request.employment;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CPropertiesRequest;

@JsonPropertyOrder({"id", "requestDate", "purpose", "properties"})
public class CContextRequest {

    @JsonProperty("id")
    private String m_sId;

    @JsonProperty("requestDate")
    private String m_sRequestDate;

    @JsonProperty("purpose")
    private String m_sPurpose;

    @JsonProperty("properties")
    private CPropertiesRequest m_properties;

    private CContextRequest() {
    }

    private CContextRequest(Builder builder) {
        m_sId = builder.m_sId;
        m_sRequestDate = builder.m_sRequestDate;
        m_sPurpose = builder.m_sPurpose;
        m_properties = builder.m_properties;
    }

    public String getId() {
        return m_sId;
    }

    public String getRequestDate() {
        return m_sRequestDate;
    }

    public String getPurpose() {
        return m_sPurpose;
    }

    public CPropertiesRequest getProperties() {
        return m_properties;
    }

    public static final class Builder {

        private String m_sId;
        private String m_sRequestDate;
        private String m_sPurpose;
        private CPropertiesRequest m_properties;

        public Builder() {
        }

        public Builder id(String sId) {
            m_sId = sId;
            return this;
        }

        public Builder requestDate(String sRequestDate) {
            m_sRequestDate = sRequestDate;
            return this;
        }

        public Builder purpose(String sPurpose) {
            m_sPurpose = sPurpose;
            return this;
        }

        public Builder properties(CPropertiesRequest properties) {
            m_properties = properties;
            return this;
        }

        public CContextRequest build() {
            return new CContextRequest(this);
        }
    }
}
