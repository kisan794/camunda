package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({"id", "status", "submittedAt", "message"})
public class CAcceptedData {

    @JsonProperty("id")
    private String m_sId;

    @JsonProperty("status")
    private String m_sStatus;

    @JsonProperty("submittedAt")
    private String m_sSubmittedAt;

    @JsonProperty("message")
    private String m_sMessage;

    private CAcceptedData() {
    }

    public String getId() {
        return m_sId;
    }

    public String getStatus() {
        return m_sStatus;
    }

    public String getSubmittedAt() {
        return m_sSubmittedAt;
    }

    public String getMessage() {
        return m_sMessage;
    }

    private CAcceptedData(Builder builder) {
        m_sId = builder.m_sId;
        m_sStatus = builder.m_sStatus;
        m_sSubmittedAt = builder.m_sSubmittedAt;
        m_sMessage = builder.m_sMessage;
    }

    public static final class Builder {

        private String m_sId;
        private String m_sStatus;
        private String m_sSubmittedAt;
        private String m_sMessage;

        public Builder() {
        }

        public Builder id(String sId) {
            this.m_sId = sId;
            return this;
        }

        public Builder status(String sStatus) {
            this.m_sStatus = sStatus;
            return this;
        }

        public Builder submittedAt(String sSubmittedAt) {
            this.m_sSubmittedAt = sSubmittedAt;
            return this;
        }

        public Builder message(String sMessage) {
            this.m_sMessage = sMessage;
            return this;
        }

        public CAcceptedData build() {
            return new CAcceptedData(this);
        }
    }
}

