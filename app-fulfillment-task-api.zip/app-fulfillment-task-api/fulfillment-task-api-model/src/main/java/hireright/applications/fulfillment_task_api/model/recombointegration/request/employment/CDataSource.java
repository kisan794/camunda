package hireright.applications.fulfillment_task_api.model.recombointegration.request.employment;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

/**
 * Employment Data Source DTO for screening data source information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"name", "type", "screenings"})
public class CDataSource {

    @JsonProperty("name")
    private String m_sName;

    @JsonProperty("type")
    private String m_sType;

    @JsonProperty("screenings")
    private List<CScreening> m_screenings;

    private CDataSource() {
    }

    private CDataSource(Builder builder) {
        m_sName = builder.m_sName;
        m_sType = builder.m_sType;
        m_screenings = builder.m_screenings;
    }

    public String getName() {
        return m_sName;
    }

    public String getType() {
        return m_sType;
    }

    public List<CScreening> getScreenings() {
        return m_screenings;
    }

    public static final class Builder {

        private String m_sName;
        private String m_sType;
        private List<CScreening> m_screenings;

        public Builder() {
        }

        public Builder name(String sName) {
            m_sName = sName;
            return this;
        }

        public Builder type(String sType) {
            m_sType = sType;
            return this;
        }

        public Builder screenings(List<CScreening> screenings) {
            m_screenings = screenings;
            return this;
        }

        public CDataSource build() {
            return new CDataSource(this);
        }
    }
}

