package hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.time.Instant;
import java.util.UUID;

/**
 * CloudEvents format response for task results following CloudEvents v1.0 specification.
 * This class represents successful acceptance of task result submissions.
 *
 * @author Keshav Ladha
 * @version 1.0
 * @see <a href="https://github.com/cloudevents/spec/blob/v1.0/spec.md">CloudEvents Specification v1.0</a>
 */
@JsonPropertyOrder({"specversion", "id", "source", "type", "datacontenttype", "time", "data"})
public class CResultResponse {

    @JsonProperty("specversion")
    private String m_sSpecVersion;

    @JsonProperty("id")
    private String m_sId;

    @JsonProperty("source")
    private String m_sSource;

    @JsonProperty("type")
    private String m_sType;

    @JsonProperty("datacontenttype")
    private String m_sDataContentType;

    @JsonProperty("time")
    private String m_sTime;

    @JsonProperty("data")
    private CAcceptedData m_data;

    private CResultResponse() {
    }

    public CResultResponse(Builder builder) {
        m_sSpecVersion = builder.m_sSpecVersion;
        m_sId = builder.m_sId;
        m_sSource = builder.m_sSource;
        m_sType = builder.m_sType;
        m_sDataContentType = builder.m_sDataContentType;
        m_sTime = builder.m_sTime;
        m_data = builder.m_data;
    }

    public static final class Builder {

        private String m_sSpecVersion;
        private String m_sId;
        private String m_sSource;
        private String m_sType;
        private String m_sDataContentType;
        private String m_sTime;
        private CAcceptedData m_data;

        public Builder() {
        }

        public Builder specVersion(String sSpecVersion) {
            m_sSpecVersion = sSpecVersion;
            return this;
        }

        public Builder id(String sId) {
            m_sId = sId;
            return this;
        }

        public Builder source(String sSource) {
            m_sSource = sSource;
            return this;
        }

        public Builder type(String sType) {
            m_sType = sType;
            return this;
        }

        public Builder dataContentType(String sDataContentType) {
            m_sDataContentType = sDataContentType;
            return this;
        }

        public Builder time(String sTime) {
            m_sTime = sTime;
            return this;
        }

        public Builder data(CAcceptedData data) {
            m_data = data;
            return this;
        }

        public CResultResponse build() {
            return new CResultResponse(this);
        }
    }

    /**
     * Create a success response for accepted task result.
     *
     * @param requestId The task identifier
     * @param requestId The original request identifier (currently unused, reserved for future use)
     * @return TaskResultResponse configured for successful acceptance
     * @throws IllegalArgumentException if requestId is null or empty
     */
    //TODO move it to ResultApiController
    public static CResultResponse accepted(String requestId) {
        if (requestId == null || requestId.trim().isEmpty()) {
//            LOG.error("Task ID cannot be null or empty");
            throw new IllegalArgumentException("Task ID cannot be null or empty");
        }

        Instant now = Instant.now();
        String responseId = UUID.randomUUID().toString();
        Instant expectedCompletion = now.plusSeconds(CCloudEventsConstants.EXPECTED_COMPLETION_SECONDS);


//        LOG.debug("Creating task accepted response - TaskId: {}, ResponseId: {}", requestId, responseId);

        CAcceptedData acceptedData = new CAcceptedData.Builder()
                .id(requestId)
                .status(CCloudEventsConstants.STATUS_COMPLETED)
                .submittedAt(now.toString())
                .message(CCloudEventsConstants.MSG_RECEIVED)
                .build();

        return new Builder()
                .specVersion(CCloudEventsConstants.CLOUDEVENTS_VERSION)
                .id(responseId)
                .source(CCloudEventsConstants.SOURCE_FULFILLMENT_API)
                .type(CCloudEventsConstants.TYPE_TASK_ACCEPTED)
                .dataContentType(CCloudEventsConstants.CONTENT_TYPE_JSON)
                .time(now.toString())
                .data(acceptedData)
                .build();
    }
}

