package hireright.applications.fulfillment_task_api.model.recombointegration.education.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReferenceObjectsQualification {
    private String degree;

    private String major;

    private Tenure tenure;
}

