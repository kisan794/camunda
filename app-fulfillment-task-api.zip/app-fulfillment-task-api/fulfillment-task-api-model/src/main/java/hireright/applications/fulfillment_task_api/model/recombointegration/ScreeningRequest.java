package hireright.applications.fulfillment_task_api.model.recombointegration;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for screening request messages from RabbitMQ.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ScreeningRequest
{

    private String id;

}
