/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.education;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Location DTO for institution location information
 * 
 * @author Keshav Ladha
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Location {
    
    private String city;
    
    private String region;
    
    private String country;
    
    private String postalCode;
}

