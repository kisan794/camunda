package hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Position History DTO for employment position history information
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"title", "startDate", "endDate", "mostRecentHireDate", "employeeStatusCode", "employeeStatus",
        "spokeWith", "reasonForLeaving", "eligibleForRehire"})
public class CPositionHistory {

    @JsonProperty("title")
    private String m_sTitle;

    @JsonProperty("startDate")
    private String m_sStartDate;

    @JsonProperty("endDate")
    private String m_sEndDate;

    @JsonProperty("mostRecentHireDate")
    private String m_sMostRecentHireDate;

    @JsonProperty("employeeStatusCode")
    private String m_sEmployeeStatusCode;

    @JsonProperty("employeeStatus")
    private String m_sEmployeeStatus;

    @JsonProperty("spokeWith")
    private String m_sSpokeWith;

    @JsonProperty("reasonForLeaving")
    private String m_sReasonForLeaving;

    @JsonProperty("eligibleForRehire")
    private String m_sEligibleForRehire;

    private CPositionHistory() {
    }

    private CPositionHistory(Builder builder) {
        m_sTitle = builder.m_sTitle;
        m_sStartDate = builder.m_sStartDate;
        m_sEndDate = builder.m_sEndDate;
        m_sMostRecentHireDate = builder.m_sMostRecentHireDate;
        m_sEmployeeStatusCode = builder.m_sEmployeeStatusCode;
        m_sEmployeeStatus = builder.m_sEmployeeStatus;
        m_sSpokeWith = builder.m_sSpokeWith;
        m_sReasonForLeaving = builder.m_sReasonForLeaving;
        m_sEligibleForRehire = builder.m_sEligibleForRehire;
    }

    public String getTitle() {
        return m_sTitle;
    }

    public String getStartDate() {
        return m_sStartDate;
    }

    public String getEndDate() {
        return m_sEndDate;
    }

    public String getMostRecentHireDate() {
        return m_sMostRecentHireDate;
    }

    public String getEmployeeStatusCode() {
        return m_sEmployeeStatusCode;
    }

    public String getEmployeeStatus() {
        return m_sEmployeeStatus;
    }

    public String getSpokeWith() {
        return m_sSpokeWith;
    }

    public String getReasonForLeaving() {
        return m_sReasonForLeaving;
    }

    public String getEligibleForRehire() {
        return m_sEligibleForRehire;
    }

    public static final class Builder {

        private String m_sTitle;
        private String m_sStartDate;
        private String m_sEndDate;
        private String m_sMostRecentHireDate;
        private String m_sEmployeeStatusCode;
        private String m_sEmployeeStatus;
        private String m_sSpokeWith;
        private String m_sReasonForLeaving;
        private String m_sEligibleForRehire;

        public Builder() {
        }

        public Builder title(String sTitle) {
            m_sTitle = sTitle;
            return this;
        }

        public Builder startDate(String sStartDate) {
            m_sStartDate = sStartDate;
            return this;
        }

        public Builder endDate(String sEndDate) {
            m_sEndDate = sEndDate;
            return this;
        }

        public Builder mostRecentHireDate(String sMostRecentHireDate) {
            m_sMostRecentHireDate = sMostRecentHireDate;
            return this;
        }

        public Builder employeeStatusCode(String sEmployeeStatusCode) {
            m_sEmployeeStatusCode = sEmployeeStatusCode;
            return this;
        }

        public Builder employeeStatus(String sEmployeeStatus) {
            m_sEmployeeStatus = sEmployeeStatus;
            return this;
        }

        public Builder spokeWith(String sSpokeWith) {
            m_sSpokeWith = sSpokeWith;
            return this;
        }

        public Builder reasonForLeaving(String sReasonForLeaving) {
            m_sReasonForLeaving = sReasonForLeaving;
            return this;
        }

        public Builder eligibleForRehire(String sEligibleForRehire) {
            m_sEligibleForRehire = sEligibleForRehire;
            return this;
        }

        public CPositionHistory build() {
            return new CPositionHistory(this);
        }
    }
}
