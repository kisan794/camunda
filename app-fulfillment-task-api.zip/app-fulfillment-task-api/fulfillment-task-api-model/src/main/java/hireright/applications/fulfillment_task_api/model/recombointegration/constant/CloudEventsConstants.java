/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.constant;

/**
 * Constants for CloudEvents specification compliance.
 *
 * <p>This class contains all CloudEvents-related constants used throughout the application
 * to ensure consistency and compliance with CloudEvents v1.0 specification.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public final class CloudEventsConstants {

    public static final String CLOUDEVENTS_VERSION = "1.0";

    public static final String CONTENT_TYPE_JSON = "application/json";

    public static final String SOURCE_FULFILLMENT_API = "hrg:hre:fulfillment-api";

    public static final String TYPE_TASK_ACCEPTED = "Task.Accepted";

    public static final String STATUS_COMPLETED = "COMPLETED";

    public static final String MSG_RECEIVED = "results recevied";

    /**
     * Private constructor to prevent instantiation.
     * This is a utility class with only static constants.
     */
    private CloudEventsConstants() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

