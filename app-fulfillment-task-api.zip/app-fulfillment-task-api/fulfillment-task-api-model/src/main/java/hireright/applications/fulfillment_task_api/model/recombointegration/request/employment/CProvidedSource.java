package hireright.applications.fulfillment_task_api.model.recombointegration.request.employment;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CContext;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CNote;

import java.util.List;

/**
 * Employment HRG Source DTO containing product, organization, and verification details
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"id", "context", "organization", "referenceObjects", "notes"})
public class CProvidedSource {

    @JsonProperty("id")
    private String m_sId;

    @JsonProperty("context")
    private CContext m_context;

    @JsonProperty("organization")
    private COrganization m_organization;

    @JsonProperty("referenceObjects")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<CReferenceObjects> m_referenceObjects;

    @JsonProperty("notes")
    private List<CNote> m_notes;

    private CProvidedSource() {
    }

    private CProvidedSource(Builder builder) {
        m_sId = builder.m_sId;
        m_context = builder.m_context;
        m_organization = builder.m_organization;
        m_referenceObjects = builder.m_referenceObjects;
        m_notes = builder.m_notes;
    }

    public String getId() {
        return m_sId;
    }

    public CContext getContext() {
        return m_context;
    }

    public COrganization getOrganization() {
        return m_organization;
    }

    public List<CReferenceObjects> getReferenceObjects() {
        return m_referenceObjects;
    }

    public List<CNote> getNotes() {
        return m_notes;
    }

    public static final class Builder {

        private String m_sId;
        private CContext m_context;
        private COrganization m_organization;
        private List<CReferenceObjects> m_referenceObjects;
        private List<CNote> m_notes;

        public Builder() {
        }

        public Builder id(String sId) {
            m_sId = sId;
            return this;
        }

        public Builder context(CContext context) {
            m_context = context;
            return this;
        }

        public Builder organization(COrganization organization) {
            m_organization = organization;
            return this;
        }

        public Builder referenceObjects(List<CReferenceObjects> referenceObjects) {
            m_referenceObjects = referenceObjects;
            return this;
        }

        public Builder notes(List<CNote> notes) {
            m_notes = notes;
            return this;
        }

        public CProvidedSource build() {
            return new CProvidedSource(this);
        }
    }
}

