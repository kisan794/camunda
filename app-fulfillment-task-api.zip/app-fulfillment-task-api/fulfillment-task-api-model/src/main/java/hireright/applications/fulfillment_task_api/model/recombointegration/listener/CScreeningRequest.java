package hireright.applications.fulfillment_task_api.model.recombointegration.listener;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DTO for screening request messages from RabbitMQ.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class CScreeningRequest {

    @JsonProperty("id")
    private String m_sId;

    private CScreeningRequest() {
    }

    private CScreeningRequest(Builder builder) {
        m_sId = builder.m_sId;
    }

    public String getId() {
        return m_sId;
    }

    public static final class Builder {

        private String m_sId;

        public Builder() {
        }

        public Builder id(String sId) {
            m_sId = sId;
            return this;
        }

        public CScreeningRequest build() {
            return new CScreeningRequest(this);
        }
    }
}