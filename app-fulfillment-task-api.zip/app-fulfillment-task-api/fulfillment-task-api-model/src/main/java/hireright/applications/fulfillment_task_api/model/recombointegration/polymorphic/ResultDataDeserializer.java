/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

/**
 * Custom deserializer for BaseResultData that automatically determines the concrete type
 * based on the presence of specific fields in the JSON payload.
 *
 * Detection logic:
 * - If "employerOrgName" field is present → EmploymentResultData
 * - If "institutionName" field is present → EducationResultData
 * - Otherwise → defaults to EmploymentResultData
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class ResultDataDeserializer extends JsonDeserializer<BaseResultData> {

    private static final String EMPLOYER_ORG_NAME_FIELD = "employerOrgName";
    private static final String INSTITUTION_NAME_FIELD = "institutionName";
    private static final String POSITION_HISTORY_FIELD = "positionHistory";
    private static final String QUALIFICATIONS_FIELD = "qualifications";
    private static final String CITY_FIELD = "city";
    private static final String REGION_FIELD = "region";
    private static final String COUNTRY_FIELD = "country";

    @Override
    public BaseResultData deserialize(JsonParser parser, DeserializationContext context)
        throws IOException {

        ObjectMapper mapper = (ObjectMapper) parser.getCodec();
        JsonNode node = mapper.readTree(parser);

        // Extract common fields
        String city = node.has(CITY_FIELD) ? node.get(CITY_FIELD).asText() : null;
        String region = node.has(REGION_FIELD) ? node.get(REGION_FIELD).asText() : null;
        String country = node.has(COUNTRY_FIELD) ? node.get(COUNTRY_FIELD).asText() : null;

        // Determine the type based on the presence of specific fields
        if (node.has(EMPLOYER_ORG_NAME_FIELD) || node.has(POSITION_HISTORY_FIELD)) {
            return getEmploymentResultData(city, region, country, node, mapper);
        } else if (node.has(INSTITUTION_NAME_FIELD) || node.has(QUALIFICATIONS_FIELD)) {
            return getEducationResultData(city, region, country, node, mapper);
        } else {
            // Default to employment if neither field is present
            return EmploymentResultData.builder()
                .city(city)
                .region(region)
                .country(country)
                .build();
        }
    }

    private static EducationResultData getEducationResultData(String city, String region,
        String country, JsonNode node, ObjectMapper mapper) throws JsonProcessingException
    {
        // Education result
        EducationResultData education = EducationResultData.builder()
            .city(city)
            .region(region)
            .country(country)
            .institutionName(node.has(INSTITUTION_NAME_FIELD) ?
                node.get(INSTITUTION_NAME_FIELD).asText() : null)
            .build();

        getQualificationData(node, mapper, education);
        return education;
    }

    private static void getQualificationData(JsonNode node, ObjectMapper mapper, EducationResultData education)
        throws JsonProcessingException
    {
        // Deserialize qualifications if present
        if (node.has(QUALIFICATIONS_FIELD)) {
            EducationQualifications qualifications = mapper.treeToValue(
                node.get(QUALIFICATIONS_FIELD),
                EducationQualifications.class
            );
            education.setQualifications(qualifications);
        }
    }

    private static EmploymentResultData getEmploymentResultData(String city, String region,
        String country, JsonNode node, ObjectMapper mapper) throws JsonProcessingException
    {
        EmploymentResultData employment = EmploymentResultData.builder()
            .city(city)
            .region(region)
            .country(country)
            .employerOrgName(node.has(EMPLOYER_ORG_NAME_FIELD) ?
                node.get(EMPLOYER_ORG_NAME_FIELD).asText() : null)
            .build();

        getPositionHistory(node, mapper, employment);
        return employment;
    }

    private static void getPositionHistory(JsonNode node, ObjectMapper mapper,
        EmploymentResultData employment) throws JsonProcessingException
    {
        // Deserialize position history if present
        if (node.has(POSITION_HISTORY_FIELD)) {
            PositionHistory positionHistory = mapper.treeToValue(
                node.get(POSITION_HISTORY_FIELD),
                PositionHistory.class
            );
            employment.setPositionHistory(positionHistory);
        }
    }
}
