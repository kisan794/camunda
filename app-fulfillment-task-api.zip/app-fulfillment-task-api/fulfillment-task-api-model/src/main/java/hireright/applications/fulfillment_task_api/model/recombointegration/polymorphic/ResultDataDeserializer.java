/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

/**
 * Custom deserializer for BaseResultData that automatically determines the concrete type
 * based on the presence of specific fields in the JSON payload.
 * 
 * Detection logic:
 * - If "employerOrgName" field is present → EmploymentResultData
 * - If "institutionName" field is present → EducationResultData
 * - Otherwise → defaults to EmploymentResultData
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class ResultDataDeserializer extends JsonDeserializer<BaseResultData> {

    private static final String EMPLOYER_ORG_NAME_FIELD = "employerOrgName";
    private static final String INSTITUTION_NAME_FIELD = "institutionName";

    @Override
    public BaseResultData deserialize(JsonParser parser, DeserializationContext context) 
            throws IOException {
        
        ObjectMapper mapper = (ObjectMapper) parser.getCodec();
        JsonNode node = mapper.readTree(parser);
        
        // Determine the type based on the presence of specific fields
        if (node.has(EMPLOYER_ORG_NAME_FIELD)) {
            // Employment result
            return mapper.treeToValue(node, EmploymentResultData.class);
        } else if (node.has(INSTITUTION_NAME_FIELD)) {
            // Education result
            return mapper.treeToValue(node, EducationResultData.class);
        } else {
            // Default to employment if neither field is present
            return mapper.treeToValue(node, EmploymentResultData.class);
        }
    }
}

