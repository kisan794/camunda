package hireright.applications.fulfillment_task_api.model.recombointegration.common;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Employment Note DTO for verification notes
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@JsonPropertyOrder({"date", "originator", "note"})
public class CNote {

    @JsonProperty("date")
    private String m_sDate;

    @JsonProperty("originator")
    private String m_sOriginator;

    @JsonProperty("note")
    private String m_sNote;

    private CNote() {
    }

    private CNote(Builder builder) {
        m_sDate = builder.m_sDate;
        m_sOriginator = builder.m_sOriginator;
        m_sNote = builder.m_sNote;
    }

    public String getDate() {
        return m_sDate;
    }

    public String getOriginator() {
        return m_sOriginator;
    }

    public String getNote() {
        return m_sNote;
    }

    public static final class Builder {

        private String m_sDate;
        private String m_sOriginator;
        private String m_sNote;

        public Builder() {
        }

        public Builder date(String sDate) {
            m_sDate = sDate;
            return this;
        }

        public Builder originator(String sOriginator) {
            m_sOriginator = sOriginator;
            return this;
        }

        public Builder note(String sNote) {
            m_sNote = sNote;
            return this;
        }

        public CNote build() {
            return new CNote(this);
        }
    }
}

