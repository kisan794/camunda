package hireright.applications.fulfillment_task_api.model;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import java.io.Serializable;
import java.util.Objects;

public class CSort<T> implements Serializable {
    private T m_field;
    private EOrder m_order;

    private CSort() {
    }

    public CSort(T field, EOrder order) {
        this.m_field = field;
        this.m_order = order;
    }

    private CSort(Builder<T> builder) {
        this.m_field = builder.m_field;
        this.m_order = builder.m_order;
    }

    public static <T> CSort<T> asc(T field) {
        return new CSort<>(field, EOrder.ASC);
    }

    public static <T> CSort<T> desc(T field) {
        return new CSort<>(field, EOrder.DESC);
    }

    public T getField() {
        return this.m_field;
    }

    public EOrder getOrder() {
        return this.m_order;
    }

    public boolean isEmpty() {
        return this.m_field == null || this.m_field instanceof String && ((String) this.m_field).trim().isEmpty() ||
                this.m_order == null;
    }

    @Override
    public String toString() {
        return "CSort{" + "m_field=" + this.m_field + ", m_order=" + this.m_order + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CSort<?> cSort = (CSort<?>) o;

        if (!Objects.equals(this.m_field, cSort.m_field)) {
            return false;
        }
        return this.m_order == cSort.m_order;
    }

    @Override
    public int hashCode() {
        int result = this.m_field != null ? this.m_field.hashCode() : 0;
        result = 31 * result + (this.m_order != null ? this.m_order.hashCode() : 0);
        return result;
    }

    public enum EOrder {
        ASC,
        DESC;

        public static EOrder fromValue(String text) {
            if (text == null || text.trim().isEmpty()) {
                return null;
            }

            for (EOrder entry : EOrder.values()) {
                if (entry.name().equalsIgnoreCase(text) || text.toLowerCase().startsWith(entry.name().toLowerCase())) {
                    return entry;
                }
            }
            return null;
        }
    }

    public static final class Builder<T> {
        private T m_field;
        private EOrder m_order;

        public Builder() {
        }

        public Builder(CSort<T> copy) {
            if (copy == null) {
                return;
            }

            this.m_field = copy.getField();
            this.m_order = copy.getOrder();
        }

        public Builder<T> field(T field) {
            this.m_field = field;
            return this;
        }

        public Builder<T> order(EOrder order) {
            this.m_order = order;
            return this;
        }

        public CSort<T> build() {
            return new CSort<>(this);
        }
    }
}
