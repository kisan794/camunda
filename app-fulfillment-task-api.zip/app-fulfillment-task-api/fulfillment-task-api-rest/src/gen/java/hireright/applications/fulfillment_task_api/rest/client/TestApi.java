package hireright.applications.fulfillment_task_api.rest.client;

import hireright.applications.fulfillment_task_api.rest.invoker.ApiClient;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaClientCodegen", date = "2025-12-01T11:58:39.966749100+05:30[Asia/Calcutta]")
@Component("hireright.applications.fulfillment_task_api.rest.client.TestApi")
public class TestApi {
    private ApiClient apiClient;

    public TestApi() {
        this(new ApiClient());
    }

    @Autowired
    public TestApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /**
     * 
     * 
     * <p><b>200</b> - Success
     * <p><b>400</b> - Bad request
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Server error
     * <p><b>503</b> - Service Unavailable
     * @param xHRDbTenantCode  (optional)
     * @param xHROriginator  (optional)
     * @param xHRTransactionId  (optional)
     * @return hireright.applications.fulfillment_task_api.model.CEmpty
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public hireright.applications.fulfillment_task_api.model.CEmpty testError(String xHRDbTenantCode, String xHROriginator, String xHRTransactionId) throws RestClientException {
        return testErrorWithHttpInfo(xHRDbTenantCode, xHROriginator, xHRTransactionId).getBody();
    }

    /**
     * 
     * 
     * <p><b>200</b> - Success
     * <p><b>400</b> - Bad request
     * <p><b>404</b> - Not Found
     * <p><b>500</b> - Server error
     * <p><b>503</b> - Service Unavailable
     * @param xHRDbTenantCode  (optional)
     * @param xHROriginator  (optional)
     * @param xHRTransactionId  (optional)
     * @return ResponseEntity&lt;hireright.applications.fulfillment_task_api.model.CEmpty&gt;
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public ResponseEntity<hireright.applications.fulfillment_task_api.model.CEmpty> testErrorWithHttpInfo(String xHRDbTenantCode, String xHROriginator, String xHRTransactionId) throws RestClientException {
        Object postBody = null;
        String path = UriComponentsBuilder.fromPath("/test/error").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();
        if (xHRDbTenantCode != null)
            headerParams.add("X-HR-DbTenantCode", apiClient.parameterToString(xHRDbTenantCode));
        if (xHROriginator != null)
            headerParams.add("X-HR-Originator", apiClient.parameterToString(xHROriginator));
        if (xHRTransactionId != null)
            headerParams.add("X-HR-Transaction-Id", apiClient.parameterToString(xHRTransactionId));

        final String[] accepts = { 
            "application/json; charset&#x3D;utf-8"
         };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = {  };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<hireright.applications.fulfillment_task_api.model.CEmpty> returnType = new ParameterizedTypeReference<hireright.applications.fulfillment_task_api.model.CEmpty>() {};
        return apiClient.invokeAPI(path, HttpMethod.GET, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
    /**
     * 
     * 
     * <p><b>200</b> - Success
     * <p><b>400</b> - Bad request
     * <p><b>500</b> - Server error
     * <p><b>503</b> - Service Unavailable
     * @param xHRDbTenantCode  (optional)
     * @param xHROriginator  (optional)
     * @param xHRTransactionId  (optional)
     * @return hireright.applications.fulfillment_task_api.model.CEmpty
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public hireright.applications.fulfillment_task_api.model.CEmpty testOk(String xHRDbTenantCode, String xHROriginator, String xHRTransactionId) throws RestClientException {
        return testOkWithHttpInfo(xHRDbTenantCode, xHROriginator, xHRTransactionId).getBody();
    }

    /**
     * 
     * 
     * <p><b>200</b> - Success
     * <p><b>400</b> - Bad request
     * <p><b>500</b> - Server error
     * <p><b>503</b> - Service Unavailable
     * @param xHRDbTenantCode  (optional)
     * @param xHROriginator  (optional)
     * @param xHRTransactionId  (optional)
     * @return ResponseEntity&lt;hireright.applications.fulfillment_task_api.model.CEmpty&gt;
     * @throws RestClientException if an error occurs while attempting to invoke the API
     */
    public ResponseEntity<hireright.applications.fulfillment_task_api.model.CEmpty> testOkWithHttpInfo(String xHRDbTenantCode, String xHROriginator, String xHRTransactionId) throws RestClientException {
        Object postBody = null;
        String path = UriComponentsBuilder.fromPath("/test/ok").build().toUriString();
        
        final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();
        final HttpHeaders headerParams = new HttpHeaders();
        final MultiValueMap<String, Object> formParams = new LinkedMultiValueMap<String, Object>();
        if (xHRDbTenantCode != null)
            headerParams.add("X-HR-DbTenantCode", apiClient.parameterToString(xHRDbTenantCode));
        if (xHROriginator != null)
            headerParams.add("X-HR-Originator", apiClient.parameterToString(xHROriginator));
        if (xHRTransactionId != null)
            headerParams.add("X-HR-Transaction-Id", apiClient.parameterToString(xHRTransactionId));

        final String[] accepts = { 
            "application/json; charset&#x3D;utf-8"
         };
        final List<MediaType> accept = apiClient.selectHeaderAccept(accepts);
        final String[] contentTypes = {  };
        final MediaType contentType = apiClient.selectHeaderContentType(contentTypes);

        String[] authNames = new String[] {  };

        ParameterizedTypeReference<hireright.applications.fulfillment_task_api.model.CEmpty> returnType = new ParameterizedTypeReference<hireright.applications.fulfillment_task_api.model.CEmpty>() {};
        return apiClient.invokeAPI(path, HttpMethod.GET, queryParams, postBody, headerParams, formParams, accept, contentType, authNames, returnType);
    }
}
