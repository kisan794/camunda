package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.response.EducationResultData;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.response.EducationResultRequest;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.EducationValidationUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class EducationResultServiceImpl extends ResultService {

    private final LoggingService loggingService;
    private final ObjectMapper objectMapper;

    public EducationResultServiceImpl(LoggingService loggingService, ObjectMapper objectMapper) {
        this.loggingService = loggingService;
        this.objectMapper = objectMapper;
    }

    @Override
    public void processEducationSubmission(String requestId, EducationResultRequest resultRequest) {
        EducationValidationUtil.validateResultRequest(requestId, resultRequest);

        log.info("Processing fulfillment result - Request ID: {}, Type: {}", requestId, resultRequest.getType());

        EducationResultData resultData = resultRequest.getData().getResultData();
        // @TODO need to process internally
        processResultData(resultData, requestId);

        String jsonPayload = serializeRequest(resultRequest);
        loggingService.log(jsonPayload, requestId, RecipientName.FULFILLMENT_RESPONSE, Direction.IN);

        log.info("Successfully processed fulfillment result - Request ID: {}, Decision: {}", requestId, resultRequest.getData().getDecision());

    }

    /**
     * Serialize the submit request to JSON
     *
     * @param resultRequest The request to serialize
     * @return JSON string representation
     */
    private String serializeRequest(EducationResultRequest resultRequest) {
        try {
            return objectMapper.writeValueAsString(resultRequest);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private void processResultData(EducationResultData resultData, String requestId) {
        log.info("Education verification result - Request ID: {}, Institution: {}, Degree: {}", requestId, resultData.getInstitutionName(), resultData.getQualifications() != null ?
                resultData.getQualifications().getDegree() : "N/A");
    }
}
