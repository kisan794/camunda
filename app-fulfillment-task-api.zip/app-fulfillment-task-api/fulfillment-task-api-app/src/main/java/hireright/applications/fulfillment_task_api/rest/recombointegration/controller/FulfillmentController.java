/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.controller;

import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.BASE_RECOMBO_INTEGRATION_SERVICE_API_PATH;

/**
 * Fulfillment Task Controller for initiating task processing
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@RestController
@RequestMapping(BASE_RECOMBO_INTEGRATION_SERVICE_API_PATH)
@Slf4j
public class FulfillmentController
{

	private final FulfillmentService fulfillmentService;

	public FulfillmentController(FulfillmentService fulfillmentService)
	{
		this.fulfillmentService = fulfillmentService;
	}

	/**
	 * POST endpoint to initiate a fulfillment task
	 * Returns immediately with "Accepted" status and processes the task asynchronously
	 *
	 * @param requestId The task ID to initiate
	 * @return ResponseEntity with immediate acceptance response
	 */
	@PostMapping("/{request_id}/initiate")
	public ResponseEntity<Map<String, Object>> initiateTask(
		@PathVariable("request_id") String requestId)
	{

		log.info("Received task initiation request - Task ID: {}", requestId);

		// Trigger async processing
		fulfillmentService.fulfill(requestId);

		// Return immediate response
		Map<String, Object> response = new HashMap<>();
		response.put("status", "Accepted");
		response.put("message", "Sub-request triggered successfully.");

		log.info("Task initiation accepted - Task ID: {}", requestId);

		return ResponseEntity.accepted().body(response);
	}

}

