/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.config.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ErrorResponse;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

/**
 * JWT Authentication Filter for validating JWT tokens
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Component
@Slf4j
public class JwtAuthenticationFilter extends OncePerRequestFilter
{

	private final JwtTokenValidator jwtTokenValidator;
	private final ObjectMapper objectMapper;

	public JwtAuthenticationFilter(JwtTokenValidator jwtTokenValidator, ObjectMapper objectMapper)
	{
		this.jwtTokenValidator = jwtTokenValidator;
		this.objectMapper = objectMapper;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
		FilterChain filterChain) throws ServletException, IOException
	{

		// Skip authentication for health check and actuator endpoints
		String path = request.getRequestURI();
		if(shouldSkipAuthentication(path))
		{
			filterChain.doFilter(request, response);
			return;
		}

		// Extract JWT token from Authorization header
		String authHeader = request.getHeader("Authorization");

		if(authHeader == null || !authHeader.startsWith("Bearer "))
		{
			log.warn("Missing or invalid Authorization header for path: {}", path);
			sendAuthenticationError(response, "MISSING_TOKEN");
			return;
		}

		String token = authHeader.substring(7); // Remove "Bearer " prefix

		// Validate JWT token
		try
		{
			if(!jwtTokenValidator.validateToken(token))
			{
				log.warn("Invalid JWT token for path: {}", path);
				sendAuthenticationError(response, "INVALID_OR_EXPIRED_TOKEN");
				return;
			}

			// Token is valid, continue with the request
			filterChain.doFilter(request, response);

		}
		catch(Exception e)
		{
			log.error("JWT token validation failed for path: {}", path, e);
			sendAuthenticationError(response, "INVALID_OR_EXPIRED_TOKEN");
		}
	}

	/**
	 * Check if authentication should be skipped for this path
	 */
	private boolean shouldSkipAuthentication(String path)
	{
		return path.startsWith("/fulfillment_task_api/actuator") || path.startsWith(
			"/fulfillment_task_api/health") || path.equals("/") || path.startsWith("/swagger")
			|| path.startsWith("/v3/api-docs") || path.startsWith("/fulfillment_task_api/api-docs")
			|| path.startsWith("/fulfillment_task_api/swagger-ui");
	}


	private void sendAuthenticationError(HttpServletResponse response, String reason) throws IOException {
		String requestId = UUID.randomUUID().toString();

		ErrorResponse errorResponse = ErrorResponse.authenticationError(
			requestId,
			"Authentication token is missing or invalid",
			reason
		);

		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.getWriter().write(objectMapper.writeValueAsString(errorResponse));
	}

}

