/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.http.auth;

import hireright.applications.fulfillment_task_api.rest.recombointegration.http.config.JwtConfig;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

/**
 * Provider for JWT authentication using HMAC.
 * Generates JWT tokens for authenticating HTTP requests.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
public class JwtAuthenticationProvider {

    private final JwtConfig config;
    private final SecretKey secretKey;

    /**
     * Constructor with JWT configuration.
     *
     * @param config the JWT configuration
     */
    public JwtAuthenticationProvider(JwtConfig config) {
        this.config = config;
        this.secretKey = Keys.hmacShaKeyFor(config.getSecretKey().getBytes(StandardCharsets.UTF_8));
        log.info("JwtAuthenticationProvider initialized with issuer: {}", config.getIssuer());
    }

    /**
     * Generates a JWT token with custom claims.
     *
     * @param customClaims additional claims to include in the token
     * @return the JWT token
     */
    public String generateToken(Map<String, Object> customClaims) {

        Instant now = Instant.now();
        Instant expiration = now.plus(config.getExpirationTime());

        var builder = Jwts.builder().claims(customClaims).issuedAt(Date.from(now))
                .expiration(Date.from(expiration)).signWith(secretKey);

        if (config.getIssuer() != null) {
            builder.issuer(config.getIssuer());
        }

        if (config.getSubject() != null) {
            builder.subject(config.getSubject());
        }

        String token = builder.compact();

        log.debug("Generated JWT token with expiration: {}", expiration);
        return token;
    }

    /**
     * Generates an Authorization header value with Bearer token and custom claims.
     *
     * @param customClaims additional claims to include in the token
     * @return the Authorization header value
     */
    public String generateAuthorizationHeader(Map<String, Object> customClaims) {
        return "Bearer " + generateToken(customClaims);
    }
}