package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ISourceDetectionService;
import hireright.sdk.db3.DB;
import org.springframework.stereotype.Service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.EDUCATION;
import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.EMPLOYMENT;

@Service
public class CSourceDetectionService implements ISourceDetectionService {

    @Override
    public String getSourceType(Integer nServiceId) throws Exception {
        boolean isEmploymentService = getIsEmploymentService(nServiceId);
        if (isEmploymentService) {
            return EMPLOYMENT;
        }

        boolean isEducationService = getIsEducationService(nServiceId);
        if (isEducationService) {
            return EDUCATION;
        }

        return "";
    }

    private static Boolean getIsEmploymentService(Integer nServiceId) throws Exception {
        return DB.execute(() -> {
            try (Connection connection = DB.connection();
                 CallableStatement callableStatement = connection.prepareCall(
                         "DECLARE "
                                 + "  v_result BOOLEAN;"
                                 + " BEGIN"
                                 + "  v_result := bdk_order_employment.is_employmentservice(?);"
                                 + "  ? := CASE WHEN v_result THEN 1 ELSE 0 END;"
                                 + " END;"
                 )) {
                callableStatement.setInt(1, nServiceId);
                callableStatement.registerOutParameter(2, Types.INTEGER);

                callableStatement.execute();
                return callableStatement.getInt(2) == 1;
            }
        });
    }

    private static Boolean getIsEducationService(Integer nServiceId) throws Exception {
        return DB.execute(() -> {
            try (Connection connection = DB.connection();
                 CallableStatement callableStatement = connection.prepareCall(
                         "{ ? = call bdk_order_education.is_educationService(?) }")
            ) {
                callableStatement.registerOutParameter(1, Types.INTEGER);
                callableStatement.setInt(2, nServiceId);
                callableStatement.execute();
                return callableStatement.getInt(1) == 1;
            }
        });
    }

}
