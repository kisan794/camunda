/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;


import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CValidationDetail;
import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.ValidationException;
import hireright.sdk.util.CStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Service for validating result submission requests.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Service

public class RequestValidationService {

    private static final Logger LOG = LoggerFactory.getLogger(RequestValidationService.class);

    /**
     * Validate a result submission request
     *
     * @param requestId     the request ID from the path
     * @param resultRequest the result request to validate
     * @throws ValidationException if validation fails
     */
    public void validateResultRequest(String requestId, CResultRequest resultRequest) {
        List<CValidationDetail> errors = new ArrayList<>();

        validateRequestId(requestId, resultRequest, errors);

        validateCloudEvents(resultRequest, errors);

        validateDataPayload(resultRequest, errors);

        validateException(requestId, errors);

        LOG.debug("Validation successful for request ID: {}", requestId);
    }

    private static void validateException(String requestId, List<CValidationDetail> errors) {
        if (!errors.isEmpty()) {
            LOG.warn("Validation failed for request ID: {} - {} errors found", requestId,
                    errors.size());
            throw new ValidationException("Input validation failed", requestId, errors);
        }
    }

    private static void validateDataPayload(CResultRequest resultRequest,
                                            List<CValidationDetail> errors) {
        // Validate data payload
        if (resultRequest.getData() == null) {
            errors.add(new CValidationDetail.Builder()
                    .field("data")
                    .message("Data payload is required")
                    .build());
        } else {
            // Validate decision field
            if (CStringUtils.isEmpty(resultRequest.getData().getDecision())) {
                errors.add(new CValidationDetail.Builder()
                        .field("decision")
                        .message("Decision is required")
                        .build());
            }

            // Validate reviewScore field
            if (resultRequest.getData().getReviewScore() == null) {
                errors.add(new CValidationDetail.Builder()
                        .field("reviewScore")
                        .message("ReviewScore is required")
                        .build());
            }

            // Validate decisionDescription field
            if (CStringUtils.isEmpty(resultRequest.getData().getDecisionDescription())) {
                errors.add(new CValidationDetail.Builder()
                        .field("decisionDescription")
                        .message("DecisionDescription is required")
                        .build());
            }

            // Validate audit field
            boolean hasAudit = resultRequest.getData().getProperties() != null
                    && resultRequest.getData().getProperties().getAudit() != null;

            if (!hasAudit) {
                errors.add(new CValidationDetail.Builder()
                        .field("audit")
                        .message("Audit is required")
                        .build());
            }

            // Validate rfmFlag field
            boolean hasRFMFlag = resultRequest.getData().getProperties() != null
                    && resultRequest.getData().getProperties().getRfmFlag() != null;

            if (!hasRFMFlag) {
                errors.add(new CValidationDetail.Builder()
                        .field("rfmFlag")
                        .message("RFMFlag is required")
                        .build());
            }

            // Validate result data
            if (resultRequest.getData().getResultData() == null) {
                errors.add(new CValidationDetail.Builder()
                        .field("resultData")
                        .message("Result data is required")
                        .build());
            }
        }
    }

    private static void validateCloudEvents(CResultRequest resultRequest,
                                            List<CValidationDetail> errors) {
        // Validate CloudEvents required fields
        if (CStringUtils.isEmpty(resultRequest.getSpecVersion())) {
            errors.add(new CValidationDetail.Builder()
                    .field("specversion")
                    .message("CloudEvents spec version is required")
                    .build());
        }

        if (CStringUtils.isEmpty(resultRequest.getSource())) {
            errors.add(new CValidationDetail.Builder()
                    .field("source")
                    .message("CloudEvents source is required")
                    .build());
        }

        if (CStringUtils.isEmpty(resultRequest.getType())) {
            errors.add(new CValidationDetail.Builder()
                    .field("type")
                    .message("CloudEvents type is required")
                    .build());
        }
    }

    private static void validateRequestId(String requestId, CResultRequest resultRequest,
                                          List<CValidationDetail> errors) {
        // Validate request ID match
        if (CStringUtils.isEmpty(resultRequest.getId())) {
            errors.add(new CValidationDetail.Builder()
                    .field("id")
                    .message("Request ID is required").build());
        } else if (!requestId.equals(resultRequest.getId())) {
            errors.add(new CValidationDetail.Builder()
                    .field("id")
                    .message("Request ID in path does not match request ID in body")
                    .build());
        }
    }
}