package hireright.applications.fulfillment_task_api.rest.recombointegration.processor;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import hireright.applications.fulfillment_task_api.model.recombointegration.common.CContext;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CGuidelines;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CLocation;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CNote;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CProduct;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CPropertiesRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CTenure;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CClient;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CContextRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CDataSource;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CEmploymentData;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CEmploymentDataRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.COrganization;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CPosition;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CProvidedSource;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CReferenceObjects;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.CIdentifierService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COsdsService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.CXml2JsonSerializer;
import hireright.objects.applicant.CApplicant;
import hireright.objects.application.CApplication;
import hireright.objects.billing.CBillingUnitItem;
import hireright.objects.order2.COrder;
import hireright.objects.order2.COrderProperties;
import hireright.objects.order2.COrderService;
import hireright.objects.order2.loaders.COrderLoader;
import hireright.objects.order2.service.employment.CEmployment;
import hireright.objects.product_catalogue.CD365ProductCode;
import hireright.objects.service2.CService;
import hireright.objects.users.CCustomer;
import hireright.objects.users.CCustomerFactory;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CProperties;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class CEmploymentProcessor extends CAbstractProcessor {

    public CEmploymentProcessor(CXml2JsonSerializer xml2JsonSerializer,
                                COsdsService osdsService,
                                CIdentifierService identifierService) {
        super(xml2JsonSerializer, osdsService, identifierService);
    }

    private CDataSource getDataSource(long orderServiceID) {
        final String response = getOsdsService().getEmploymentResponse(orderServiceID);
        return response == null
                ? null
                : getXml2JsonSerializer().deserialize(response, CDataSource.class);
    }

    @Override
    public Object process(String taskId, COrderService orderService, CService service) throws Exception {
        final Long orderID = orderService.getOrderID();
        final Long orderServiceID = orderService.getIDLong();

        COrder order = new COrderLoader().loadOrderInfo(orderID);
        Objects.requireNonNull(order);

        CProperties orderProperties = new COrderProperties(orderID).toProperties();
        if (orderProperties == null) {
            orderProperties = CProperties.NO_PROPERTIES;
        }

        CCustomer customer = CCustomerFactory.getCustomer(order.getCustomerId());
        Objects.requireNonNull(customer);

        CApplication application = getApplication(orderID);
        Objects.requireNonNull(application);

        CApplicant applicant = application.getApplicant();
        Objects.requireNonNull(applicant);

        CD365ProductCode productCode = getProductCode(service.getId());
        Long lBillingUnitID = orderProperties.getLong("BILLING_UNIT_ID");
        CBillingUnitItem billingItem = getBillingItem(lBillingUnitID, orderService);
        CProperties productFeatures = billingItem != null ? billingItem.getProductFeatures() : null;


        final CEmployment employment = CEmployment.load(orderServiceID);

        final Long requestId = employment.getId().getRequestId();

        final CContext context = new CContext.Builder()
                .client(new CClient.Builder()
                        .companyName(customer.getCompanyName())
                        .accountName(customer.getAccountName())
                        .companyCode(customer.getCompanyCode())
                        .build())
                .product(new CProduct.Builder()
                        .sku(productCode != null ? productCode.getItemNumber() : null)
                        .name(productCode != null ? productCode.resolveFeatures(productFeatures) : null)
                        .build())
                .request(new CContextRequest.Builder()
                        .id(String.valueOf(requestId))
                        .requestDate(instantToString(orderService.getSubmittedDTTM()))
                        .purpose(service.getName())
                        .properties(new CPropertiesRequest.Builder()
                                .audit(false)
                                .build())
                        .build())
                .guidelines(new CGuidelines.Builder()
                        .product(new ArrayList<>())  //TODO
                        .client(getGuideline(String.valueOf(service.getId()), String.valueOf(customer.getID())))
                        .generic(getGuideline(String.valueOf(service.getId()), String.valueOf(DEFAULT_CUSTOMER)))
                        .build())
                .build();

        final COrganization organization = toOrganization(employment);
        final List<CReferenceObjects> referenceObjects = getReferenceObjects(requestId, orderServiceID);
        final List<CNote> notes = getNotes(orderID, orderServiceID);

        final CProvidedSource providedSource = new CProvidedSource.Builder()
                .id(getIdentifierService().build(orderService))
                .context(context)
                .organization(organization)
                .referenceObjects(referenceObjects)
                .notes(notes)
                .build();

        return new CEmploymentDataRequest.Builder()
                .specVersion("1.0")
                .id(getIdentifierService().build(orderService))
                .source("hrg:hre:data-request")
                .type("EmploymentFulfillment")
                .dataContentType("application/json")
                .time(Instant.now().toString())
                .dataSchema("schemas/emp_compound_fulfillment_v1.0.json")
                .data(new CEmploymentData.Builder()
                        .providedSource(providedSource)
                        .dataSource(getDataSource(orderServiceID))
                        .build())
                .build();
    }

    @SuppressWarnings("unchecked")
    private List<CReferenceObjects> getReferenceObjects(Long requestId, Long orderServiceId) throws SQLException {
        Criteria query = DB.session().createCriteria(CEmployment.class);
        query.add(Restrictions.eq("id.requestId", requestId));
        query.add(Restrictions.ne("orderServiceId", orderServiceId.intValue()));

        List<CEmployment> employmentList = query.list();

        return employmentList.stream()
                .map(employmentItem -> {
                    COrderService orderService = COrderService.load(Long.valueOf(employmentItem.getOrderServiceId()));

                    return new CReferenceObjects.Builder()
                            .type("order-item")
                            .id(getIdentifierService().build(orderService))
                            .organization(toOrganization(employmentItem))
                            .build();
                })
                .collect(Collectors.toList());
    }

    private COrganization toOrganization(CEmployment employmentItem) {
        return new COrganization.Builder()
                .name(employmentItem.getCompanyName())
                .location(new CLocation.Builder()
                        .city(employmentItem.getAddress().getCity())
                        .region(employmentItem.getAddress().getStateID())
                        .country(resolveCountryCode(employmentItem.getCountry(), employmentItem.getCountryId()))
                        .postalCode(employmentItem.getAddress().getZip())
                        .build())
                .position(new CPosition.Builder()
                        .title(employmentItem.getJobTitle())
                        .tenure(new CTenure.Builder()
                                .start(dateToString(employmentItem.getStartDate()))
                                .end(dateToString(employmentItem.getEndDate()))
                                .current(employmentItem.getEndDate() == null)
                                .build())
                        .spokeWith(employmentItem.getSpokeTo())
                        .reasonForLeaving(employmentItem.getRReason())
                        .build())
                .build();
    }

}
