/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.http.client;

import hireright.applications.fulfillment_task_api.rest.recombointegration.http.auth.JwtAuthenticationProvider;
import hireright.applications.fulfillment_task_api.rest.recombointegration.http.config.HttpClientConfig;
import hireright.applications.fulfillment_task_api.rest.recombointegration.http.config.JwtConfig;
import hireright.applications.fulfillment_task_api.rest.recombointegration.http.exception.HttpClientException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.CorrelationIdHolder;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Reusable HTTP/2 client utility for invoking REST endpoints.
 * Supports HTTP/2 protocol, JWT authentication, and both sync/async executions.
 * Retry logic is handled by Spring's @Retryable annotation at the service layer.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
public class Http2Client
{

	private final HttpClient httpClient;
	private final HttpClientConfig clientConfig;
	private final JwtAuthenticationProvider jwtProvider;

	/**
	 * Private constructor for a builder pattern.
	 *
	 * @param builder the builder instance
	 */
	private Http2Client(Builder builder)
	{
		this.clientConfig = builder.clientConfig;
		this.jwtProvider =
			builder.jwtConfig != null ? new JwtAuthenticationProvider(builder.jwtConfig) : null;

		// Build the HttpClient
		this.httpClient = HttpClient.newBuilder()
			.version(clientConfig.getHttpVersion())
			.connectTimeout(clientConfig.getConnectTimeout())
			.followRedirects(clientConfig.getRedirectPolicy())
			.build();

		log.info("Http2Client initialized with HTTP version: {}, connect timeout: {}s",
			clientConfig.getHttpVersion(), clientConfig.getConnectTimeout().getSeconds());
	}

	/**
	 * Creates a new builder for Http2Client.
	 *
	 * @return a new builder instance
	 */
	public static Builder builder()
	{
		return new Builder();
	}

	/**
	 * Executes a synchronous GET request with custom headers.
	 *
	 * @param uri     the request URI
	 * @param headers custom headers to include
	 * @return the HTTP response
	 * @throws HttpClientException if the request fails
	 */
	public HttpResponse<String> get(String uri, Map<String, String> headers)
	{
		HttpRequest request = buildRequest(uri, "GET", null, headers);
		return executeSync(request);
	}

	/**
	 * Executes a synchronous POST request with custom headers.
	 *
	 * @param uri     the request URI
	 * @param body    the request body
	 * @param headers custom headers to include
	 * @return the HTTP response
	 * @throws HttpClientException if the request fails
	 */
	public HttpResponse<String> post(String uri, String body, Map<String, String> headers)
	{
		HttpRequest request = buildRequest(uri, "POST", body, headers);
		return executeSync(request);
	}

	/**
	 * Executes an asynchronous GET request with custom headers.
	 *
	 * @param uri     the request URI
	 * @param headers custom headers to include
	 * @return a CompletableFuture containing the HTTP response
	 */
	public CompletableFuture<HttpResponse<String>> getAsync(String uri, Map<String, String> headers)
	{
		HttpRequest request = buildRequest(uri, "GET", null, headers);
		return executeAsync(request);
	}

	/**
	 * Executes an asynchronous POST request with custom headers.
	 *
	 * @param uri     the request URI
	 * @param body    the request body
	 * @param headers custom headers to include
	 * @return a CompletableFuture containing the HTTP response
	 */
	public CompletableFuture<HttpResponse<String>> postAsync(String uri, String body,
		Map<String, String> headers)
	{
		HttpRequest request = buildRequest(uri, "POST", body, headers);
		return executeAsync(request);
	}

	/**
	 * Builds an HTTP request with the specified parameters.
	 *
	 * @param uri     the request URI
	 * @param method  the HTTP method
	 * @param body    the request body (can be null)
	 * @param headers custom headers to include
	 * @return the built HTTP request
	 */
	private HttpRequest buildRequest(String uri, String method, String body,
		Map<String, String> headers)
	{
		try
		{
			HttpRequest.Builder builder = HttpRequest.newBuilder()
				.uri(URI.create(uri))
				.timeout(clientConfig.getRequestTimeout());

			// Add custom headers
			headers.forEach(builder::header);

			// Add correlation ID header if available in MDC
			String correlationId = CorrelationIdHolder.get();
			if(correlationId != null && !correlationId.isEmpty())
			{
				builder.header(CorrelationIdHolder.CORRELATION_ID_HEADER, correlationId);
				log.debug("Adding correlation ID to request: {}", correlationId);
			}

			// Add JWT authentication if configured
			if(jwtProvider != null)
			{
				builder.header("Authorization",
					jwtProvider.generateAuthorizationHeader(new HashMap<>()));
			}

			// Add a compression header if enabled
			if(clientConfig.isEnableCompression())
			{
				builder.header("Accept-Encoding", "gzip, deflate");
			}

			// Set method and body
			if(body != null)
			{
				builder.method(method, HttpRequest.BodyPublishers.ofString(body));
				builder.header("Content-Type", "application/json");
			}
			else
			{
				builder.method(method, HttpRequest.BodyPublishers.noBody());
			}

			return builder.build();

		}
		catch(Exception e)
		{
			log.error("Failed to build HTTP request for URI: {}", uri, e);
			throw new HttpClientException("Failed to build request: " + e.getMessage(), e);
		}
	}

	/**
	 * Executes a synchronous HTTP request.
	 *
	 * @param request the HTTP request
	 * @return the HTTP response
	 * @throws HttpClientException if the request fails
	 */
	private HttpResponse<String> executeSync(HttpRequest request)
	{
		log.debug("Executing synchronous {} request to: {}", request.method(), request.uri());

		try
		{
			return httpClient.send(request, HttpResponse.BodyHandlers.ofString());

		}
		catch(InterruptedException e)
		{
			Thread.currentThread().interrupt();
			log.error("Synchronous request interrupted for URI: {}", request.uri(), e);
			throw new HttpClientException("Request interrupted: " + e.getMessage(), e);
		}
		catch(IOException e)
		{
			log.error("Synchronous request failed for URI: {}", request.uri(), e);
			throw new HttpClientException("Request failed: " + e.getMessage(), e);
		}
	}

	/**
	 * Executes an asynchronous HTTP request.
	 *
	 * @param request the HTTP request
	 * @return a CompletableFuture containing the HTTP response
	 */
	private CompletableFuture<HttpResponse<String>> executeAsync(HttpRequest request)
	{
		log.debug("Executing asynchronous {} request to: {}", request.method(), request.uri());
		return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString());
	}

	/**
	 * Builder for Http2Client.
	 * Requires Spring-managed configuration beans.
	 */
	public static class Builder
	{
		private HttpClientConfig clientConfig;
		private JwtConfig jwtConfig;

		/**
		 * Sets the HTTP client configuration (required, Spring-managed).
		 *
		 * @param clientConfig the HTTP client configuration
		 * @return this builder instance
		 */
		public Builder clientConfig(HttpClientConfig clientConfig)
		{
			this.clientConfig = clientConfig;
			return this;
		}

		/**
		 * Sets the JWT configuration (optional, Spring-managed).
		 *
		 * @param jwtConfig the JWT configuration
		 * @return this builder instance
		 */
		public Builder jwtConfig(JwtConfig jwtConfig)
		{
			this.jwtConfig = jwtConfig;
			return this;
		}

		/**
		 * Builds the Http2Client instance.
		 *
		 * @return the Http2Client instance
		 * @throws IllegalStateException if clientConfig is not set
		 */
		public Http2Client build()
		{
			if(clientConfig == null)
			{
				throw new IllegalStateException("HttpClientConfig is required.");
			}

			return new Http2Client(this);
		}
	}
}