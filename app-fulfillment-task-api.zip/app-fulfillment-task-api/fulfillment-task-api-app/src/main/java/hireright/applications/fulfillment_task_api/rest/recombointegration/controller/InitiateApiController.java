/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.controller;

import hireright.applications.fulfillment_task_api.model.recombointegration.common.InitiateResponse;
import hireright.applications.fulfillment_task_api.rest.controller.InitiateApi;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * Fulfillment Controller for initiating processing
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@RestController
@EnableRetry
@Validated
@Slf4j
public class InitiateApiController implements InitiateApi {

    private final FulfillmentService fulfillmentService;

    public InitiateApiController(FulfillmentService fulfillmentService) {
        this.fulfillmentService = fulfillmentService;
    }

    /**
     * POST endpoint to initiate a fulfillment
     * Returns immediately with "Accepted" status and processes asynchronously
     *
     * @param requestId to initiate
     * @return ResponseEntity with immediate acceptance response
     */
    @Override
    public ResponseEntity<InitiateResponse> initiate(
            @PathVariable("request_id") @NonNull final String requestId) {
        log.info("Received initiation request - Task ID: {}", requestId);

        fulfillmentService.fulfill(requestId);

        InitiateResponse response = InitiateResponse.builder().status("Accepted")
                .message("Sub-request triggered successfully.").build();

        log.info("initiation accepted - Task ID: {}", requestId);

        return ResponseEntity.accepted().body(response);
    }

}

