package hireright.applications.fulfillment_task_api.rest.recombointegration.service;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-11  Created
 */

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.URIResolver;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * @author mkuznetsov
 */
@Service
public class CXml2JsonSerializer {

    private static final String XSLT = "classpath:/xslt/";
    private static final String XML_2_JSON_XSLT = "xml2json.xslt";
    private final XmlMapper xmlMapper = new XmlMapper();

    private final TransformerFactory factory;
    private final ResourceLoader resourceLoader;

    public CXml2JsonSerializer(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
        this.factory = TransformerFactory.newInstance();
        this.factory.setURIResolver(new ClasspathURIResolver(this.resourceLoader));
    }

    private String transformWithXslt(String xml, String xslt) {
        try {


            InputStream xsltInputStream = this.resourceLoader.getResource(XSLT + xslt).getInputStream();

            Source xsltSource = new StreamSource(xsltInputStream);
            Transformer transformer = this.factory.newTransformer(xsltSource);

            Source xmlSource = new StreamSource(new StringReader(xml));
            StringWriter writer = new StringWriter();
            transformer.transform(xmlSource, new StreamResult(writer));
            return writer.toString();
        } catch (Exception e) {
            throw new RuntimeException("XSLT transformation failed", e);
        }
    }


    private <T> T deserialize(String requestData, String xslt, Class<T> clazz)
    {
        try {
            final String transformed = transformWithXslt(requestData, xslt);
            return this.xmlMapper.readValue(transformed, clazz);
        } catch (Exception e) {
            throw new RuntimeException("Failed to deserialize XML", e);
        }
    }

    public <T> T deserialize(String requestData, Class<T> clazz)
    {
        return deserialize(requestData, XML_2_JSON_XSLT, clazz);
    }

    private static class ClasspathURIResolver implements URIResolver {

        private final ResourceLoader resourceLoader;

        public ClasspathURIResolver(ResourceLoader resourceLoader) {
            this.resourceLoader = resourceLoader;
        }

        @Override
        public Source resolve(String href, String base) throws TransformerException {
            final String resultHref = "classpath:xslt/" + href;
            InputStream xsltInputStream = null;
            try {
                xsltInputStream = this.resourceLoader.getResource(resultHref).getInputStream();
            } catch (IOException e) {
                throw new TransformerException(e);
            }

            return new StreamSource(xsltInputStream);
        }
    }
}
