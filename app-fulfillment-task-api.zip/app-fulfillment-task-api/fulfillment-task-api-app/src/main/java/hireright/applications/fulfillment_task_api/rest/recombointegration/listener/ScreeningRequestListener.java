package hireright.applications.fulfillment_task_api.rest.recombointegration.listener;

import com.rabbitmq.client.Channel;
import hireright.applications.fulfillment_task_api.model.recombointegration.listener.Event;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.CorrelationIdHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * RabbitMQ listener for screening requests.
 * Listens to the screening queue and processes incoming messages.
 *
 * @author Keshav Ladha
 * @version 1.0
 */

@Component
@ConditionalOnProperty(name = "rabbitmq.enabled", havingValue = "true")
public class ScreeningRequestListener {

    private static final Logger LOG = LoggerFactory.getLogger(ScreeningRequestListener.class);

    private static final String PARAMETER_TASK_ID = "taskID";
    private final FulfillmentService fulfillmentService;

    public ScreeningRequestListener(FulfillmentService fulfillmentService) {
        this.fulfillmentService = fulfillmentService;
    }

    /**
     * Listens to screening requests queue and processes messages.
     * Extracts correlation ID from message header for tracking.
     *
	 * @param event the screening request message
     */
    @RabbitListener(queues = "${rabbitmq.queue.screening-requests}")
    public void handleScreeningRequest(@Payload Event event, Message message, Channel channel) {
        try {
            // Set correlation ID from header, or from request body, or generate new one
            CorrelationIdHolder.generate();

            LOG.info("Received screening request from queue - ID: {}, CorrelationID: {}",
                    event.id(), CorrelationIdHolder.get());

            // Process the request asynchronously
            event.parameters().stream().filter(parameter -> PARAMETER_TASK_ID.equalsIgnoreCase(parameter.getName())).findFirst().ifPresent(parameter -> {
                this.fulfillmentService.fulfill(parameter.getValue());
            });

            LOG.info("Successfully processed screening request - ID: {}, CorrelationID: {}",
                    event.id(), CorrelationIdHolder.get());

            channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);

        } catch (Exception e) {
            LOG.error("Failed to process screening request - ID: {}",
                    event.id(), e);

            try {
                channel.basicNack(message.getMessageProperties().getDeliveryTag(), false, false);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }

            throw new UnsupportedOperationException(
                    "Failed to process screening request: " + e.getMessage(), e);
        } finally {
            // Clean up correlation ID from MDC
            CorrelationIdHolder.clear();
        }
    }
}