package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.XmlTransformationException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ScreeningType;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.XmlToJsonConverter;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Maps HireRight Education Screening XML structure to custom JSON schema.
 *
 * @author Keshav Ladha
 */
@Service
@Slf4j
public class EducationXmlToJsonConverter implements XmlToJsonConverter {

    private static final String DEFAULT_NAME = "NSCH";
    private static final String DEFAULT_TYPE = Constant.SCREENING_TYPE_EDUCATION;
    private static final String ERROR_CODE_CONVERSION_FAILED = "JSON_CONVERSION_FAILED";

    private final XmlMapper xmlMapper;
    private final ObjectMapper jsonMapper;

    /**
     * Constructor initializes XML and JSON mappers.
     */
    public EducationXmlToJsonConverter() {
        this.xmlMapper = new XmlMapper();
        this.jsonMapper = new ObjectMapper();
        log.info("EducationScreeningXmlToJsonConverter initialized");
    }

    @Override
    public ScreeningType getType() {
        return ScreeningType.EDUCATION;
    }

    @Override
    public String convert(String xml) {
        log.debug("Starting Education Screening XML to JSON conversion");

        if (xml == null || xml.trim().isEmpty()) {
            log.error("XML content is null or empty");
            throw new XmlTransformationException(
                    "XML_EMPTY",
                    "XML content cannot be null or empty",
                    null);
        }

        try {
            log.debug("Parsing XML content (length: {} characters)", xml.length());

            JsonNode xmlNode = xmlMapper.readTree(xml);

            log.debug("XML parsed successfully, transforming to custom JSON structure");

            ObjectNode result = buildJsonStructure(xmlNode);

            String jsonOutput = jsonMapper.writerWithDefaultPrettyPrinter().writeValueAsString(result);

            log.debug("Conversion output preview: {}", jsonOutput);

            return jsonOutput;

        } catch (Exception e) {
            throw new XmlTransformationException(
                    ERROR_CODE_CONVERSION_FAILED,
                    "Failed to convert XML to JSON: " + e.getMessage(),
                    e);
        }
    }

    /**
     * Builds the JSON structure from XML node.
     *
     * @param xmlNode the XML node
     * @return the JSON object node
     */
    private ObjectNode buildJsonStructure(JsonNode xmlNode) {
        log.debug("Building JSON structure from XML node");

        ObjectNode result = jsonMapper.createObjectNode();

        // Extract root element
        JsonNode educationScreeningList = xmlNode.path("EducationScreeningList");
        if (educationScreeningList.isMissingNode()) {
            educationScreeningList = xmlNode;
            log.debug("Using root node as EducationScreeningList");
        }

        // Set name and type
        result.put(Constant.FIELD_NAME, DEFAULT_NAME);

        JsonNode firstScreening = educationScreeningList.path("EducationScreening");
        if (!firstScreening.isMissingNode()) {
            JsonNode screening = firstScreening.path(Constant.XML_PATH_SCREENING);
            String type = screening.path(Constant.XML_PATH_TYPE).asText(DEFAULT_TYPE);
            result.put(Constant.FIELD_TYPE, type);
            log.debug("Screening type: {}", type);
        } else {
            result.put(Constant.FIELD_TYPE, DEFAULT_TYPE);
            log.debug("Using default screening type: {}", DEFAULT_TYPE);
        }

        // Create screening array
        ArrayNode screeningArray = jsonMapper.createArrayNode();

        // Process EducationScreening elements
        JsonNode educationScreenings = educationScreeningList.path("EducationScreening");

        if (educationScreenings.isArray()) {
            log.debug("Processing {} education screening elements", educationScreenings.size());
            for (JsonNode eduScreening : educationScreenings) {
                ArrayNode screeningItems = processEducationScreeningWithMultipleResults(eduScreening);
                for (JsonNode item : screeningItems) {
                    screeningArray.add(item);
                }
            }
        } else if (!educationScreenings.isMissingNode()) {
            log.debug("Processing single education screening element");
            ArrayNode screeningItems = processEducationScreeningWithMultipleResults(educationScreenings);
            for (JsonNode item : screeningItems) {
                screeningArray.add(item);
            }
        } else {
            log.warn("No EducationScreening elements found in XML");
        }

        result.set("screening", screeningArray);

        log.debug("JSON structure built successfully with {} screening items", screeningArray.size());

        return result;
    }

    /**
     * Processes a single EducationScreening element and returns an array of screening items.
     * Handles multiple EducationResult elements by grouping them by institution.
     * If multiple results have the same institution, they are combined into one screening with multiple programs.
     * If results have different institutions, separate screening objects are created.
     *
     * @param eduScreening the education screening node
     * @return array of screening item object nodes
     */
    private ArrayNode processEducationScreeningWithMultipleResults(JsonNode eduScreening) {
        log.debug("Processing EducationScreening element with potential multiple results");

        ArrayNode screeningItems = jsonMapper.createArrayNode();

        JsonNode screening = eduScreening.path(Constant.XML_PATH_SCREENING);
        JsonNode producerRefId = screening.path(Constant.XML_PATH_PRODUCER_REFERENCE_ID);
        JsonNode verificationReport = screening.path("EducationVerificationReport");

        // Get all EducationResult elements
        JsonNode educationResults = verificationReport.path("EducationResult");

        if (educationResults.isMissingNode()) {
            log.warn("No EducationResult found in EducationVerificationReport");
            screeningItems.add(createEmptyScreeningItem(producerRefId));
            return screeningItems;
        }

        // Handle single EducationResult
        if (!educationResults.isArray()) {
            log.debug("Processing single EducationResult");
            screeningItems.add(createScreeningItem(producerRefId, educationResults));
            return screeningItems;
        }

        // Handle multiple EducationResults - group by institution
        log.debug("Processing {} EducationResult elements", educationResults.size());
        processMultipleEducationResultsGrouped(producerRefId, educationResults, screeningItems);

        return screeningItems;
    }

    /**
     * Processes multiple EducationResult elements and groups them by institution.
     * Creates separate screening items for different institutions.
     * Combines programs for the same institution.
     *
     * @param producerRefId    the producer reference ID node
     * @param educationResults the array of EducationResult nodes
     * @param screeningItems   the array to add screening items to
     */
    private void processMultipleEducationResultsGrouped(JsonNode producerRefId, JsonNode educationResults, ArrayNode screeningItems) {
        log.debug("Processing multiple EducationResults - grouping by institution");

        // Map to group results by institution name
        Map<String, List<JsonNode>> institutionGroups = new LinkedHashMap<>();

        // Group all EducationResults by institution name
        for (JsonNode educationResult : educationResults) {
            String institutionName = educationResult
                    .path("SchoolOrInstitution")
                    .path("SchoolName")
                    .asText("");

            String normalizedName = institutionName.toLowerCase();

            institutionGroups.computeIfAbsent(normalizedName, k -> new ArrayList<>())
                    .add(educationResult);
        }

        log.debug("Found {} unique institutions in EducationResults", institutionGroups.size());

        // Create a screening item for each institution
        for (Map.Entry<String, List<JsonNode>> entry : institutionGroups.entrySet()) {
            String institutionName = entry.getKey();
            List<JsonNode> results = entry.getValue();

            log.debug("Creating screening item for institution '{}' with {} programs", institutionName, results.size());

            // Create screening item from the first result
            ObjectNode screeningItem = createScreeningItem(producerRefId, results.get(0));

            // Add additional programs from remaining results for the same institution
            if (results.size() > 1) {
                ArrayNode programs = (ArrayNode) screeningItem.path("institution").path("programs");

                for (int i = 1; i < results.size(); i++) {
                    JsonNode educationResult = results.get(i);
                    JsonNode schoolOrInstitution = educationResult.path("SchoolOrInstitution");
                    ObjectNode program = processSchoolOrInstitution(schoolOrInstitution);
                    if (program != null) {
                        programs.add(program);
                        log.debug("Added program {} to institution '{}'", i + 1, institutionName);
                    }
                }
            }

            screeningItems.add(screeningItem);
        }
    }

    /**
     * Creates a screening item from producer reference ID and education result.
     *
     * @param producerRefId   the producer reference ID node
     * @param educationResult the education result node
     * @return the screening item object node
     */
    private ObjectNode createScreeningItem(JsonNode producerRefId, JsonNode educationResult) {
        ObjectNode screeningItem = jsonMapper.createObjectNode();

        // Extract IdValues
        extractIdValues(producerRefId, screeningItem);

        // Process Contact
        ObjectNode contact = processContactFromResult(educationResult);
        screeningItem.set("contact", contact);

        // Process Institution
        ObjectNode institution = processInstitutionFromResult(educationResult);
        screeningItem.set("institution", institution);

        return screeningItem;
    }

    /**
     * Creates an empty screening item when no EducationResult is found.
     *
     * @param producerRefId the producer reference ID node
     * @return the empty screening item object node
     */
    private ObjectNode createEmptyScreeningItem(JsonNode producerRefId) {
        ObjectNode screeningItem = jsonMapper.createObjectNode();
        extractIdValues(producerRefId, screeningItem);
        screeningItem.set("contact", jsonMapper.createObjectNode());
        screeningItem.set("institution", jsonMapper.createObjectNode());
        return screeningItem;
    }

    /**
     * Extracts IdValue elements from ProducerReferenceId.
     *
     * @param producerRefId the producer reference ID node
     * @param screeningItem the screening item to populate
     */
    private void extractIdValues(JsonNode producerRefId, ObjectNode screeningItem) {
        log.debug("Extracting IdValues from ProducerReferenceId");

        JsonNode idValues = producerRefId.path(Constant.XML_PATH_ID_VALUE);

        if (idValues.isArray()) {
            log.debug("Processing {} IdValue elements", idValues.size());

            for (JsonNode idValue : idValues) {
                String name = idValue.path(Constant.XML_PATH_NAME).asText("");
                String value = extractIdValue(idValue);

                processIdValue(name, value, screeningItem);
            }
        } else if (!idValues.isMissingNode()) {
            log.debug("Processing single IdValue element");

            String name = idValues.path(Constant.XML_PATH_NAME).asText("");
            String value = extractIdValue(idValues);

            processIdValue(name, value, screeningItem);
        }

        log.debug("IdValues extracted successfully");
    }

    /**
     * Extracts the value from an IdValue node.
     *
     * @param idValue the IdValue node
     * @return the extracted value
     */
    private String extractIdValue(JsonNode idValue) {
        String value = null;

        if (idValue.isTextual()) {
            value = idValue.asText();
        } else if (idValue.isObject()) {
            value = idValue.path("").asText("");
        }

        return value;
    }

    /**
     * Processes a single IdValue and adds it to the screening item.
     *
     * @param name          the IdValue name
     * @param value         the IdValue value
     * @param screeningItem the screening item to populate
     */
    private void processIdValue(String name, String value, ObjectNode screeningItem) {
        switch (name) {
            case "ServiceId":
                screeningItem.put("serviceId", value != null ? value : "");
                log.debug("ServiceId: {}", value);
                break;
            case "HRSchoolId":
                screeningItem.set("hrSchoolId", (value == null || value.isEmpty()) ?
                        jsonMapper.nullNode() : jsonMapper.valueToTree(value));
                log.debug("HRSchoolId: {}", value);
                break;
            case "NSCHSchoolId":
                screeningItem.put("nschSchoolId", value != null ? value : "");
                log.debug("NSCHSchoolId: {}", value);
                break;
            default:
                log.debug("Unknown IdValue name: {}", name);
                break;
        }
    }

    /**
     * Processes contact information from a single EducationResult node.
     *
     * @param educationResult the education result node
     * @return the contact object node
     */
    private ObjectNode processContactFromResult(JsonNode educationResult) {
        log.debug("Processing contact information from EducationResult");

        ObjectNode contact = jsonMapper.createObjectNode();

        JsonNode contactInfo = educationResult.path("ContactInformation");
        // Person Name
        JsonNode personName = contactInfo.path("PersonName");

        // Try FormattedName first
        String fullName = personName.path("FormattedName").asText("");

        if (fullName.isEmpty()) {
            contact.set("personName", jsonMapper.nullNode());
            log.debug("Contact person name: null");
        } else {
            contact.put("personName", fullName);
            log.debug("Contact person name: {}", fullName);
        }

        // Title
        String title = contactInfo.path("Title").asText(null);
        contact.set("title", title == null || title.isEmpty() ?
                jsonMapper.nullNode() : jsonMapper.valueToTree(title));
        log.debug("Contact title: {}", title);

        log.debug("Contact information processed successfully");

        return contact;
    }

    /**
     * Processes institution information from a single EducationResult node.
     *
     * @param educationResult the education result node
     * @return the institution object node
     */
    private ObjectNode processInstitutionFromResult(JsonNode educationResult) {
        log.debug("Processing institution information from EducationResult");

        ObjectNode institution = jsonMapper.createObjectNode();

        JsonNode schoolOrInstitution = educationResult.path("SchoolOrInstitution");

        // School Name
        String schoolName = schoolOrInstitution.path("SchoolName").asText("");
        institution.put(Constant.FIELD_NAME, schoolName);
        log.debug("Institution name: {}", schoolName);

        // Programs array
        ArrayNode programs = jsonMapper.createArrayNode();

        // New format: data is in SchoolOrInstitution with Degree and DatesOfAttendance
        log.debug("Processing SchoolOrInstitution format (Degree and DatesOfAttendance)");
        ObjectNode program = processSchoolOrInstitution(schoolOrInstitution);
        if (program != null) {
            programs.add(program);
        }

        institution.set("programs", programs);

        log.debug("Institution information processed successfully with {} programs", programs.size());

        return institution;
    }

    /**
     * Processes SchoolOrInstitution element (new format with Degree and DatesOfAttendance).
     *
     * @param schoolOrInstitution the school or institution node
     * @return the program object node, or null if no degree data
     */
    private ObjectNode processSchoolOrInstitution(JsonNode schoolOrInstitution) {
        log.debug("Processing SchoolOrInstitution element");

        // Check if there's actual degree data
        JsonNode degree = schoolOrInstitution.path("Degree");
        if (degree.isMissingNode() || degree.path("DegreeName").asText("").isEmpty()) {
            log.debug("No degree data found in SchoolOrInstitution");
            return null;
        }

        ObjectNode program = jsonMapper.createObjectNode();

        // Verification Required - check if degree was received
        String received = degree.path("Received").asText("");
        boolean verify = "Yes".equalsIgnoreCase(received);
        program.put("verify", verify);
        log.debug("verify required (based on Received={}): {}", received, verify);

        // Degree Name
        String degreeName = degree.path("DegreeName").asText("");
        program.put("degree", degreeName);
        log.debug("Degree: {}", degreeName);

        // degreeReceived
        String degreeReceived = degree.path("Received").asText("");
        program.put("degreeReceived", degreeReceived);
        log.debug("degreeReceived: {}", degreeReceived);

        // degreeDate
        String degreeDate = degree.path("DegreeDate").path("AnyDate").asText("");
        program.put("degreeDate", degreeDate);
        log.debug("degreeDate: {}", degreeDate);

        // Major
        String major = schoolOrInstitution.path("Major").asText("");
        program.put("major", major);
        log.debug("Major: {}", major);

        // Tenure
        ObjectNode tenure = jsonMapper.createObjectNode();

        JsonNode datesOfAttendance = schoolOrInstitution.path("DatesOfAttendance");
        String startDate = datesOfAttendance.path("StartDate").path(Constant.XML_PATH_ANY_DATE).asText("");
        String endDate = datesOfAttendance.path("EndDate").path(Constant.XML_PATH_ANY_DATE).asText("");

        // Check if currently attending (if endDate is empty or in the future)
        boolean current = endDate.isEmpty();

        tenure.put("startDate", startDate);
        tenure.put("endDate", endDate);
        tenure.put("current", current);

        log.debug("Tenure: {} to {}, current: {}", startDate, endDate, current);

        program.set("tenure", tenure);

        log.debug("SchoolOrInstitution element processed successfully");

        return program;
    }
}
