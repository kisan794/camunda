package hireright.applications.fulfillment_task_api.rest.boot;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * D.Chuiko			2025-11-18		HRG-347815: Created
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
@EnableCaching
public class CFulfillmentTaskApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(CFulfillmentTaskApiApplication.class, args);
    }

}
