/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic.BaseResultData;
import hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic.EducationResultData;
import hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic.EmploymentResultData;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.RequestValidationService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Implementation of SubmitService for processing fulfillment task result submissions
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Service
@Slf4j
public class ResultServiceImpl implements ResultService
{

	private final LoggingService loggingService;
	private final ObjectMapper objectMapper;
	private RequestValidationService validationService;

	public ResultServiceImpl(LoggingService loggingService, RequestValidationService validationService, ObjectMapper objectMapper)
	{
		this.loggingService = loggingService;
		this.validationService = validationService;
		this.objectMapper = objectMapper;
	}

	@Override
	public void processSubmission(String requestId, ResultRequest resultRequest)
	{
		validationService.validateResultRequest(requestId, resultRequest);

		log.info("Processing fulfillment result - Request ID: {}, Type: {}", requestId, resultRequest.getType());

		// Type-safe handling of polymorphic result data
		BaseResultData resultData = resultRequest.getData().getResultData();
		// @TODO need to process internally
		processResultData(resultData, requestId);

		String jsonPayload = serializeRequest(resultRequest);
		loggingService.log(jsonPayload, requestId, RecipientName.FULFILLMENT_RESPONSE, Direction.IN);

		log.info("Successfully processed fulfillment result - Request ID: {}, Decision: {}", requestId, resultRequest.getData().getDecision());

	}

	/**
	 * Serialize the submit request to JSON
	 *
	 * @param resultRequest The request to serialize
	 * @return JSON string representation
	 * @throws JsonProcessingException if serialization fails
	 */
	private String serializeRequest(ResultRequest resultRequest)
	{
		try
		{
			return objectMapper.writeValueAsString(resultRequest);
		}
		catch(JsonProcessingException e)
		{
			throw new RuntimeException(e);
		}
	}

	/**
	 * Process result data with type-safe polymorphic handling
	 *
	 * @param resultData The polymorphic result data
	 * @param requestId  The request ID for logging
	 */
	private void processResultData(BaseResultData resultData, String requestId)
	{
		switch(resultData)
		{
		case EmploymentResultData employment ->
			log.info("Employment verification result - Request ID: {}, Employer: {}, Position: {}",
				requestId, employment.getEmployerOrgName(),
				employment.getPositionHistory() != null ?
					employment.getPositionHistory().getTitle() :
					"N/A");
		case EducationResultData education ->
			log.info("Education verification result - Request ID: {}, Institution: {}, Degree: {}",
				requestId, education.getInstitutionName(), education.getQualifications() != null ?
					education.getQualifications().getDegree() :
					"N/A");
		case null, default ->
			log.warn("Unknown result data type - Request ID: {}, Type: {}", requestId,
				resultData.getClass().getSimpleName());
		}
	}
}