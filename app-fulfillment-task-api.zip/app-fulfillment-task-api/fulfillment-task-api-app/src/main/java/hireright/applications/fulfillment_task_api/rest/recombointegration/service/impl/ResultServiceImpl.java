/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic.BaseResultData;
import hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic.EducationResultData;
import hireright.applications.fulfillment_task_api.model.recombointegration.polymorphic.EmploymentResultData;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultProcessingException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.RequestTypeUtil;
import hireright.lib.logging.log_trace.CTraceLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Implementation of SubmitService for processing fulfillment task result submissions
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Service
@Slf4j
public class ResultServiceImpl implements ResultService
{

	private final LoggingService loggingService;
	private final ObjectMapper objectMapper;

	public ResultServiceImpl(LoggingService loggingService, ObjectMapper objectMapper)
	{
		this.loggingService = loggingService;
		this.objectMapper = objectMapper;
	}

	@Override
	public void processSubmission(String requestId, ResultRequest resultRequest) throws ResultProcessingException
	{
		try
		{
			if (!requestId.equals(resultRequest.getId())) {
				throw new ResultProcessingException("Request id mismatch",
					requestId);
			}

			// Determine request type based on request ID
			String requestType = RequestTypeUtil.getRequestType(requestId);
			log.info("Processing {} fulfillment result - Request ID: {}, Type: {}",
				requestType, requestId, resultRequest.getType());

			// Type-safe handling of polymorphic result data
			BaseResultData resultData = resultRequest.getData().getResultData();
			processResultData(resultData, requestId);

			String jsonPayload = serializeRequest(resultRequest);
			logSubmission(jsonPayload, requestId);

			log.info("Successfully processed {} fulfillment result - Request ID: {}, Decision: {}",
				requestType, requestId, resultRequest.getData().getDecision());

		}
		catch(JsonProcessingException e)
		{
			log.error("Failed to serialize submit request - Subject: {}", requestId, e);
			throw new ResultProcessingException("Failed to serialize request payload",
				requestId, e);
		}
		catch(Exception e)
		{
			log.error("Failed to process submit request - Subject: {}", requestId, e);
			throw new ResultProcessingException("Failed to process submission", requestId, e);
		}
	}

	/**
	 * Process result data with type-safe polymorphic handling
	 *
	 * @param resultData The polymorphic result data
	 * @param requestId  The request ID for logging
	 */
	private void processResultData(BaseResultData resultData, String requestId)
	{
		if (resultData instanceof EmploymentResultData employment)
		{
			log.info("Employment verification result - Request ID: {}, Employer: {}, Position: {}",
				requestId,
				employment.getEmployerOrgName(),
				employment.getPositionHistory() != null ? employment.getPositionHistory().getTitle() : "N/A");
		}
		else if (resultData instanceof EducationResultData education)
		{
			log.info("Education verification result - Request ID: {}, Institution: {}, Degree: {}",
				requestId,
				education.getInstitutionName(),
				education.getQualifications() != null ? education.getQualifications().getDegree() : "N/A");
		}
		else
		{
			log.warn("Unknown result data type - Request ID: {}, Type: {}",
				requestId, resultData.getClass().getSimpleName());
		}
	}


	/**
	 * Serialize the submit request to JSON
	 *
	 * @param resultRequest The request to serialize
	 * @return JSON string representation
	 * @throws JsonProcessingException if serialization fails
	 */
	private String serializeRequest(ResultRequest resultRequest) throws JsonProcessingException
	{
		return objectMapper.writeValueAsString(resultRequest);
	}

	/**
	 * Log the submission using the logging service
	 *
	 * @param jsonPayload   The JSON payload to log
	 * @param transactionId The transaction ID
	 */
	private void logSubmission(String jsonPayload, String transactionId)
	{
		try
		{
			loggingService.log(jsonPayload, transactionId, RecipientName.RECOMBO_RESPONSE,
				Direction.IN);
		}
		catch(Exception e)
		{
			log.error("Failed to log request - ID: {}", transactionId, e);
			// Don't fail the request if logging fails
			CTraceLogger.error(e, this.getClass().getName(), e.getMessage());
		}

	}
}

