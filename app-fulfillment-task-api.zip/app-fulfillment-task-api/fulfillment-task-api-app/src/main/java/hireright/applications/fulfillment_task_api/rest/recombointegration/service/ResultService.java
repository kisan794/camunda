/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.service;

import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ResultRequest;

/**
 * Service interface for processing fulfillment task result submissions
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public interface ResultService
{

	/**
	 * Process and log a fulfillment task result submission
	 */
	void processSubmission(String requestId, ResultRequest resultRequest) throws ResultProcessingException;
}

