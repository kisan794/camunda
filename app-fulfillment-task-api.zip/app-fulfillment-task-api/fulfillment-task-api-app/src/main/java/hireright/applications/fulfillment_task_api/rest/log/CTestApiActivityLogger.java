package hireright.applications.fulfillment_task_api.rest.log;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-04-14  ATS-1264 initial version
 */

import hireright.lib.logging.log_activity.IActivityLogger;
import hireright.lib.logging.log_activity.model.CLogActivity;

public class CTestApiActivityLogger implements IActivityLogger {
    private static final String WEBAPP_NAME = "fulfillment_task_api";

    private final IActivityLogger m_delegate;
    private final String transactionID;

    public CTestApiActivityLogger(IActivityLogger delegate, String sTransactionID) {
        this.m_delegate = delegate;
        this.transactionID = sTransactionID;
    }

    @Override
    public CLogActivity log(CLogActivity log) {
        if (log != null) {
            CLogActivity.Builder target = new CLogActivity.Builder(log);
            target.parameter("webapp", WEBAPP_NAME);

            if (this.transactionID != null && !this.transactionID.trim().isEmpty()) {
                target.parameter("transactionID", this.transactionID);
            }

            log = target.build();
        }

        return this.m_delegate.log(log);
    }
}
