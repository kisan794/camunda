package hireright.applications.fulfillment_task_api.rest.recombointegration.util;

import hireright.applications.fulfillment_task_api.model.recombointegration.employment.response.EmploymentResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.validation.ValidationDetail;
import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.ValidationException;
import hireright.sdk.util.CStringUtils;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@UtilityClass
@Slf4j
public class EmploymentValidationUtil {
    /**
     * Validate a result submission request
     *
     * @param requestId     the request ID from the path
     * @param resultRequest the result request to validate
     * @throws ValidationException if validation fails
     */
    public void validateResultRequest(String requestId, EmploymentResultRequest resultRequest) {
        List<ValidationDetail> errors = new ArrayList<>();

        validateRequestId(requestId, resultRequest, errors);

        validateCloudEvents(resultRequest, errors);

        validateDataPayload(resultRequest, errors);

        validateException(requestId, errors);

        log.debug("Validation successful for request ID: {}", requestId);
    }

    private static void validateException(String requestId, List<ValidationDetail> errors) {
        if (!errors.isEmpty()) {
            log.warn("Validation failed for request ID: {} - {} errors found", requestId,
                    errors.size());
            throw new ValidationException("Input validation failed", requestId, errors);
        }
    }

    private static void validateDataPayload(EmploymentResultRequest resultRequest,
                                            List<ValidationDetail> errors) {
        // Validate data payload
        if (resultRequest.getData() == null) {
            errors.add(ValidationDetail.builder().field("data").message("Data payload is required")
                    .build());
        } else {
            // Validate decision field
            if (CStringUtils.isEmpty(resultRequest.getData().getDecision())) {
                errors.add(ValidationDetail.builder()
                        .field("decision")
                        .message("Decision is required")
                        .build());
            }

            // Validate reviewScore  field
            if (resultRequest.getData().getReviewScore() == null) {
                errors.add(ValidationDetail.builder()
                        .field("reviewScore ")
                        .message("ReviewScore  is required")
                        .build());
            }

            // Validate decisionDescription field
            if (CStringUtils.isEmpty(resultRequest.getData().getDecisionDescription())) {
                errors.add(ValidationDetail.builder()
                        .field("decisionDescription")
                        .message("DecisionDescription is required")
                        .build());
            }

            validateProperties(resultRequest, errors);

            // Validate result data
            if (resultRequest.getData().getResultData() == null) {
                errors.add(ValidationDetail.builder()
                        .field("resultData")
                        .message("Result data is required")
                        .build());
            }
        }
    }

    private static void validateProperties(EmploymentResultRequest resultRequest, List<ValidationDetail> errors) {
        // Validate audit field
        boolean hasAudit = resultRequest.getData().getProperties() != null
                 && resultRequest.getData().getProperties().getAudit() != null;

        if (!hasAudit) {
            errors.add(ValidationDetail.builder()
                    .field("audit")
                    .message("Audit is required")
                    .build());
        }

        // Validate rfmFlag field
        boolean hasRFMFlag = resultRequest.getData().getProperties() != null
                && resultRequest.getData().getProperties().getRfmFlag() != null;

        if (!hasRFMFlag) {
            errors.add(ValidationDetail.builder()
                    .field("rfmFlag")
                    .message("RFMFlag is required")
                    .build());
        }
    }

    private static void validateCloudEvents(EmploymentResultRequest resultRequest,
                                            List<ValidationDetail> errors) {
        // Validate CloudEvents required fields
        if (CStringUtils.isEmpty(resultRequest.getSpecversion())) {
            errors.add(ValidationDetail.builder()
                    .field("specversion")
                    .message("CloudEvents spec version is required")
                    .build());
        }

        if (CStringUtils.isEmpty(resultRequest.getSource())) {
            errors.add(ValidationDetail.builder()
                    .field("source")
                    .message("CloudEvents source is required")
                    .build());
        }

        if (CStringUtils.isEmpty(resultRequest.getType())) {
            errors.add(ValidationDetail.builder()
                    .field("type")
                    .message("CloudEvents type is required")
                    .build());
        }
    }

    private static void validateRequestId(String requestId, EmploymentResultRequest resultRequest,
                                          List<ValidationDetail> errors) {
        // Validate request ID match
        if (CStringUtils.isEmpty(resultRequest.getId())) {
            errors.add(
                    ValidationDetail.builder().field("id").message("Request ID is required").build());
        } else if (!requestId.equals(resultRequest.getId())) {
            errors.add(ValidationDetail.builder()
                    .field("id")
                    .message("Request ID in path does not match request ID in body")
                    .build());
        }
    }
}
