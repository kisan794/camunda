package hireright.applications.fulfillment_task_api.rest.recombointegration.db;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-16  Created
 */


import hireright.objects.order2.COrderService;
import hireright.sdk.db3.DB;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Service;


/**
 * @author mkuznetsov
 */
@Service
public class COrderServiceFactory {

    public static COrderService getOrderService(String code) {
        Criteria query = DB.session().createCriteria(COrderService.class);
        query.add(Restrictions.eq("Code", code));

        return (COrderService) query.uniqueResult();
    }
}
