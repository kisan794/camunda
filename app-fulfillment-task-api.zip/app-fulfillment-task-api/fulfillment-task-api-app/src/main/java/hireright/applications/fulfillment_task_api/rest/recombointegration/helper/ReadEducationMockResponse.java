/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.Request;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Helper class to read education verification mock JSON responses
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class ReadEducationMockResponse
{

	private static final ObjectMapper mapper = new ObjectMapper();

	private ReadEducationMockResponse()
	{
		// Private constructor to prevent instantiation
	}

	/**
	 * Reads all education verification mock responses from JSON files
	 *
	 * @return Map of education data requests keyed by ID
	 * @throws IOException if file reading fails
	 */
	public static Map<String, Request> readAllEducationMockResponses()
	{
		Map<String, Request> responseMap = new HashMap<>();

		String[] files = {
			"/mock/EDU-001.json",
			"/mock/EDU-002.json"
		};

		for(int i = 0; i < files.length; i++)
		{
			String key = "EDU-00" + (i + 1);

			try(InputStream is = ReadEducationMockResponse.class.getResourceAsStream(files[i]))
			{
				if(is == null)
				{
					throw new IOException("File not found: " + files[i]);
				}
				// Convert JSON into EducationDataRequest object
				Request request = mapper.readValue(is, Request.class);
				responseMap.put(key, request);
			}
			catch(IOException e)
			{
				throw new RuntimeException(e);
			}
		}
		return responseMap;
	}
}

