/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.service;

/**
 * Exception thrown when submit request processing fails
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class ResultProcessingException extends Exception
{

	private final String transactionId;

	public ResultProcessingException(String message, String transactionId)
	{
		super(message);
		this.transactionId = transactionId;
	}

	public ResultProcessingException(String message, String transactionId, Throwable cause)
	{
		super(message, cause);
		this.transactionId = transactionId;
	}

	public String getTransactionId()
	{
		return transactionId;
	}
}

