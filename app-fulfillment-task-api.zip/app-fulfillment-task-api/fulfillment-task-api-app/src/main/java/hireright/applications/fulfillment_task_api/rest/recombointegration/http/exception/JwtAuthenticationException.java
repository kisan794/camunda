/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.http.exception;

import hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant;

/**
 * Exception thrown when JWT authentication fails.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class JwtAuthenticationException extends HttpClientException
{

	/**
	 * Constructor with message.
	 *
	 * @param message the error message
	 */
	public JwtAuthenticationException(String message)
	{
		super(Constant.ERROR_CODE_JWT_AUTH, message, null);
	}

	/**
	 * Constructor with message and cause.
	 *
	 * @param message the error message
	 * @param cause   the cause of the exception
	 */
	public JwtAuthenticationException(String message, Throwable cause)
	{
		super(Constant.ERROR_CODE_JWT_AUTH, message, cause);
	}
}

