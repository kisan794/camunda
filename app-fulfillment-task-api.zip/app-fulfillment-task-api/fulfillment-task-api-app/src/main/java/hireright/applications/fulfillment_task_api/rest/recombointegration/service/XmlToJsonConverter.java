package hireright.applications.fulfillment_task_api.rest.recombointegration.service;


/**
 * Interface for XML to JSON conversion.
 * Defines contract for converting XML content to JSON format.
 *
 * @author Keshav Ladha
 */
public interface XmlToJsonConverter {


    String convert(String xml);

    ScreeningType getType();
}

