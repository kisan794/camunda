/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.controller;

import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.TaskResultResponse;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultProcessingException;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.BASE_FULFILLMENTS_SERVICE_API_PATH;

/**
 * Task Results Controller for receiving fulfillment task results.
 * Implements CloudEvents v1.0 specification for task result submissions.
 *
 * <p>This controller handles:
 * <ul>
 *   <li>Task result validation</li>
 *   <li>CloudEvents format compliance</li>
 *   <li>Request logging and auditing</li>
 *   <li>Error handling with proper HTTP status codes</li>
 * </ul>
 *
 * @author Keshav Ladha
 * @version 1.0
 * @see ResultRequest
 * @see TaskResultResponse
 */
@RestController
@RequestMapping(BASE_FULFILLMENTS_SERVICE_API_PATH)
@Slf4j
public class ResultController
{

	private final ResultService resultService;

	/**
	 * Constructor with dependency injection.
	 */
	public ResultController(ResultService resultService)
	{
		this.resultService = resultService;
	}

	/**
	 * POST endpoint to receive task results in CloudEvents format.
	 */
	@PostMapping("/{request_id}/results")
	public ResponseEntity<?> submitResult(@PathVariable("request_id") String requestId,
		@RequestBody ResultRequest resultRequest) throws ResultProcessingException
	{
		resultService.processSubmission(requestId, resultRequest);
		// Create and return success response
		return ResponseEntity.ok(TaskResultResponse.accepted(requestId, requestId));

	}
}