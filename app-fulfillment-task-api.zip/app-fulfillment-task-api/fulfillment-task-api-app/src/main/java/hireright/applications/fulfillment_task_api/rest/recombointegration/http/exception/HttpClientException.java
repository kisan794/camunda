/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.http.exception;

import hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant;
import lombok.Getter;

/**
 * Base exception for HTTP client operations.
 * Thrown when HTTP requests fail due to various reasons.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Getter
public class HttpClientException extends RuntimeException
{

	private final String errorCode;
	private final Integer statusCode;

	/**
	 * Constructor with message.
	 *
	 * @param message the error message
	 */
	public HttpClientException(String message)
	{
		super(message);
		this.errorCode = Constant.ERROR_CODE_HTTP_CLIENT;
		this.statusCode = null;
	}

	/**
	 * Constructor with message and cause.
	 *
	 * @param message the error message
	 * @param cause   the cause of the exception
	 */
	public HttpClientException(String message, Throwable cause)
	{
		super(message, cause);
		this.errorCode = Constant.ERROR_CODE_HTTP_CLIENT;
		this.statusCode = null;
	}

	/**
	 * Constructor with error code, message, and cause.
	 *
	 * @param errorCode the error code
	 * @param message   the error message
	 * @param cause     the cause of the exception
	 */
	public HttpClientException(String errorCode, String message, Throwable cause)
	{
		super(message, cause);
		this.errorCode = errorCode;
		this.statusCode = null;
	}

	/**
	 * Constructor with error code, message, status code, and cause.
	 *
	 * @param errorCode  the error code
	 * @param message    the error message
	 * @param statusCode the HTTP status code
	 * @param cause      the cause of the exception
	 */
	public HttpClientException(String errorCode, String message, Integer statusCode,
		Throwable cause)
	{
		super(message, cause);
		this.errorCode = errorCode;
		this.statusCode = statusCode;
	}
}

