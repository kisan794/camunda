package hireright.applications.fulfillment_task_api.rest.recombointegration.service.adapter;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-23  Created
 */

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CResultResponse;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COrderHistoryService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COsdsService;
import hireright.bdk.order.COrderServiceActions;
import hireright.bdk.order.exception.COrderServiceActionException;
import hireright.objects.is.CMessage;
import hireright.objects.is.CMessagePayload;
import hireright.objects.is.api.is_message.CPersistenceFacade;
import hireright.objects.order2.COrderService;
import hireright.objects.users.COperator;
import hireright.sdk.db3.DB;
import hireright.sdk.util.Base64Encoder;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import hireright.service_definition.CServiceDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

/**
 * @author mkuznetsov
 */
abstract class CAbstractServiceAdapter {

    private static final Logger LOG = LoggerFactory.getLogger(CAbstractServiceAdapter.class);

    private static final String INCOMING_DOMAIN = "BASE";
    private static final String INCOMING_ADAPTER_ID = "FLMT-IN";
    private static final String OPERATOR_LOGIN = "flmt-in";

    private final CPersistenceFacade persistenceFacade;
    private final COsdsService osdsService;
    private final LoggingService loggingService;
    private final COrderHistoryService orderHistoryService;
    private final ObjectMapper objectMapper;

    CAbstractServiceAdapter(
            CPersistenceFacade persistenceFacade,
            COsdsService osdsService,
            LoggingService loggingService,
            COrderHistoryService orderHistoryService,
            ObjectMapper objectMapper) {
        this.persistenceFacade = persistenceFacade;
        this.osdsService = osdsService;
        this.loggingService = loggingService;
        this.orderHistoryService = orderHistoryService;
        this.objectMapper = objectMapper;
    }

    protected ObjectMapper getObjectMapper() {
        return this.objectMapper;
    }

    protected CMessage createMessage(String body){
        final CMessage message = buildMessage(body);
        this.persistenceFacade.create(message);
        return message;
    }

    protected CMessage buildMessage(String sBody) {
        CMessage message = new CMessage();
        message.setAdapterID(INCOMING_ADAPTER_ID);
        message.setDomainID(INCOMING_DOMAIN);
        message.setAttemptsLeft(CMessage.ATTEMPTS_LEFT_UNDEFINED);
        message.addPayload(CMessagePayload.createTextPayload(null, 0,
                Base64Encoder.encode(sBody.getBytes(StandardCharsets.UTF_8)), CMessagePayload.BODY_TYPE_BASE64,
                null, "utf-8", "base64", null, null, null));

        return message;
    }

    protected CResultResponse flushOsds(long orderServiceID, String requestID, String response, String messageID, String decision)
            throws JsonProcessingException {

        final String transactionId = this.osdsService.getAnyTransactionId(orderServiceID);
        if (transactionId == null) {
            return CResultResponse.accepted(requestID);
        }

        final CProperties props = new CProperties()
                .setProperty("transactionID", transactionId)
                .setProperty("orderServiceID", orderServiceID)
                .setProperty("requestId", requestID)
                .setProperty("messageID", messageID);

        this.loggingService.log(response, transactionId,
                RecipientName.FULFILLMENT_RESPONSE,
                Direction.IN,
                props);

        this.osdsService.createIncomingOSDS(orderServiceID, response, props);

        final CResultResponse accepted = CResultResponse.accepted(requestID);
        this.loggingService.log(
                this.objectMapper.writeValueAsString(accepted),
                transactionId,
                RecipientName.FULFILLMENT_RESPONSE,
                Direction.OUT,
                props);

        this.orderHistoryService.createHistoryRecord(orderServiceID,
                "Data has been received from RecomboAI. Decision: " + decision + ". See transaction: " + transactionId);

        return accepted;
    }

    protected void closeOrderService(long orderServiceId, String dataFound, String discrepancy)
            throws COrderServiceActionException {

        final COrderService orderService = COrderService.load(orderServiceId);
        final COperator manager = COperator.get(OPERATOR_LOGIN); //??

        int nResult = COrderServiceActions.actionLockOrderService(orderServiceId,
                manager.getObjectClass(), manager.getObjectID());
        DB.session().flush();

        if(nResult != COrderServiceActions.RETURN_STATUS_OK)
        {
            this.orderHistoryService.createHistoryRecord(orderServiceId,
                    "Unable to lock order service, it will not be closed automatically.");
            return;
        }
        orderService.setDataFound(dataFound);
        orderService.setDiscrepancy(discrepancy);
        orderService.setOK("Y");

        DB.session().update(orderService);

        nResult = COrderServiceActions.actionCloseOrderService(orderServiceId,
                manager.getObjectClass(), manager.getObjectID());

        if(nResult != COrderServiceActions.RETURN_STATUS_OK)
        {
            this.orderHistoryService.createHistoryRecord(orderServiceId,
                    "Unable to close order service.");
            return;
        }

        this.orderHistoryService.createHistoryRecord(orderServiceId,
                "Order service has been automatically closed.");
    }

    //TODO
    protected static Date parseDate(String date){
        try {
            LocalDate localDate = LocalDate.parse(date);
            return Date.from(localDate.atStartOfDay(java.time.ZoneId.systemDefault()).toInstant());
        } catch (Exception e) {
            LOG.error("Invalid date format: " + date, e);
            return null;
        }
    }
}
