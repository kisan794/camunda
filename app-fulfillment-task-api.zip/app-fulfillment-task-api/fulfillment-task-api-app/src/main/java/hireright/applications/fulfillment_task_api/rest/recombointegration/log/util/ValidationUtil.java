/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.log.util;

import static org.apache.commons.lang3.StringUtils.isBlank;

public class ValidationUtil
{

	public static String requireNonNullOrBlank(final String obj, final String message)
	{
		if(isBlank(obj))
		{
			throw new NullPointerException(message);
		}
		return obj;
	}
}
