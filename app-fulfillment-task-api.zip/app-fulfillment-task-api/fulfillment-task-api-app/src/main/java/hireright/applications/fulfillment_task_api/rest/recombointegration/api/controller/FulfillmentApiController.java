/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.api.controller;

import hireright.applications.fulfillment_task_api.rest.recombointegration.api.FulfillmentApi;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Fulfillment Controller for initiating processing
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@RestController
@EnableRetry
@Validated
@Slf4j
public class FulfillmentApiController implements FulfillmentApi
{

	private final FulfillmentService fulfillmentService;

	public FulfillmentApiController(FulfillmentService fulfillmentService)
	{
		this.fulfillmentService = fulfillmentService;
	}

	/**
	 * POST endpoint to initiate a fulfillment
	 * Returns immediately with "Accepted" status and processes asynchronously
	 *
	 * @param requestId to initiate
	 * @return ResponseEntity with immediate acceptance response
	 */
	@Override
	public ResponseEntity<Map<String, Object>> initiateTask(
		@PathVariable("request_id") @NonNull final String requestId)
	{
		log.info("Received initiation request - Task ID: {}", requestId);

		// Trigger async processing
		fulfillmentService.fulfill(requestId);

		// Return immediate response
		Map<String, Object> response = new HashMap<>();
		response.put("status", "Accepted");
		response.put("message", "Sub-request triggered successfully.");

		log.info("initiation accepted - Task ID: {}", requestId);

		return ResponseEntity.accepted().body(response);
	}

}

