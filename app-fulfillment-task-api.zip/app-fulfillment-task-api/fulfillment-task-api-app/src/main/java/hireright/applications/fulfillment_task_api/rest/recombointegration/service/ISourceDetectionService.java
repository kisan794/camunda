package hireright.applications.fulfillment_task_api.rest.recombointegration.service;

public interface ISourceDetectionService {

    String getSourceType(Integer nServiceId) throws Exception;
}
