package hireright.applications.fulfillment_task_api.rest.recombointegration.service;

import hireright.applications.fulfillment_task_api.rest.recombointegration.exception.XmlTransformationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Service for orchestrating XML transformation operations.
 * Coordinates validation and conversion of XML to JSON.
 *
 * @author Keshav Ladha
 */
@Service
@Slf4j
public class XmlTransformationService {


    private final XmlConverterFactory converterFactory;

    /**
     * Constructor with dependency injection.
     *
     * @param converterFactory the converter factory
     */
    public XmlTransformationService(XmlConverterFactory converterFactory) {
        this.converterFactory = converterFactory;
    }

    /**
     * Transforms XML to JSON with validation using specified type.
     *
     * @param xml  the XML content to transform
     * @param type the screening type (education, employment, etc.)
     * @return the JSON representation
     * @throws XmlTransformationException if transformation fails
     */
    public String transformXmlToJson(String xml, String type) {
        log.debug("Starting XML to JSON transformation for type: {}", type);

        try {


            // Get the appropriate converter based on type
            XmlToJsonConverter converter = converterFactory.getConverter(type);

            log.debug("Using converter: {}", converter.getClass().getSimpleName());

            // Convert to JSON
            String json = converter.convert(xml);

            log.info("XML to JSON transformation completed successfully (type: {}, output length: {} characters)",
                    type, json != null ? json.length() : 0);

            return json;

        } catch (XmlTransformationException e) {
            throw e;
        } catch (Exception e) {
            throw new XmlTransformationException(
                    "TRANSFORMATION_FAILED",
                    "Failed to transform XML to JSON: " + e.getMessage(),
                    e);
        }
    }
}