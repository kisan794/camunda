package hireright.applications.fulfillment_task_api.rest.recombointegration.exception;

import lombok.Getter;

/**
 * Custom exception for XML transformation errors.
 * Thrown when XML to JSON transformation fails.
 *
 * @author Keshav Ladha
 */
@Getter
public class XmlTransformationException extends RuntimeException {

    private final String errorCode;

    private final transient Object details;

    /**
     * Constructs a new XmlTransformationException with error code, message and cause.
     *
     * @param errorCode the error code
     * @param message   the detail message
     * @param cause     the cause
     */
    public XmlTransformationException(String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.details = null;
    }
}

