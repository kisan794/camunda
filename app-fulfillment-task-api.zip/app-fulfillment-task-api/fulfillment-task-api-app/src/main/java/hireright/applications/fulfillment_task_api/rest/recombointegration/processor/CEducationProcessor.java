package hireright.applications.fulfillment_task_api.rest.recombointegration.processor;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import hireright.applications.fulfillment_task_api.model.recombointegration.common.CContext;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CGuidelines;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CLocation;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CNote;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CProduct;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CPropertiesRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CTenure;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.education.CDataSource;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.education.CEducationData;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.education.CEducationDataRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.education.CInstitution;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.education.CProvidedSource;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.education.CQualification;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.education.CReferenceObjects;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CClient;
import hireright.applications.fulfillment_task_api.model.recombointegration.request.employment.CContextRequest;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.CIdentifierService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COsdsService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.CXml2JsonSerializer;
import hireright.objects.applicant.CApplicant;
import hireright.objects.application.CApplication;
import hireright.objects.billing.CBillingUnitItem;
import hireright.objects.order2.COrder;
import hireright.objects.order2.COrderProperties;
import hireright.objects.order2.COrderService;
import hireright.objects.order2.loaders.COrderLoader;
import hireright.objects.order2.service.education.CEducation;
import hireright.objects.product_catalogue.CD365ProductCode;
import hireright.objects.service2.CService;
import hireright.objects.users.CCustomer;
import hireright.objects.users.CCustomerFactory;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class CEducationProcessor extends CAbstractProcessor {


    public CEducationProcessor(CXml2JsonSerializer xml2JsonSerializer,
                               COsdsService osdsService,
                               CIdentifierService identifierService) {
        super(xml2JsonSerializer, osdsService, identifierService);
    }

    private CDataSource getDataSource(long orderServiceID) {
        final String response = getOsdsService().getEducationResponse(orderServiceID);
        return response == null
                ? null
                : getXml2JsonSerializer().deserialize(response, CDataSource.class);
    }

    @Override
    public Object process(String taskId, COrderService orderService, CService service) throws Exception {

        final Long orderID = orderService.getOrderID();
        final Long orderServiceID = orderService.getIDLong();

        COrder order = new COrderLoader().loadOrderInfo(orderID);
        Objects.requireNonNull(order);

        CProperties orderProperties = new COrderProperties(orderID).toProperties();
        if (orderProperties == null) {
            orderProperties = CProperties.NO_PROPERTIES;
        }

        CCustomer customer = CCustomerFactory.getCustomer(order.getCustomerId());
        Objects.requireNonNull(customer);

        CApplication application = getApplication(orderID);
        Objects.requireNonNull(application);

        CApplicant applicant = application.getApplicant();
        Objects.requireNonNull(applicant);

        CD365ProductCode productCode = getProductCode(service.getId());
        Long lBillingUnitID = orderProperties.getLong("BILLING_UNIT_ID");
        CBillingUnitItem billingItem = getBillingItem(lBillingUnitID, orderService);
        CProperties productFeatures = billingItem != null ? billingItem.getProductFeatures() : null;


        final CEducation education = CEducation.load(orderServiceID);

        final Long requestId = education.getId().getRequestId();

        final CContext context = new CContext.Builder()
                .client(new CClient.Builder()
                        .companyName(customer.getCompanyName())
                        .accountName(customer.getAccountName())
                        .companyCode(customer.getCompanyCode())
                        .build())
                .product(new CProduct.Builder()
                        .sku(productCode != null ? productCode.getItemNumber() : null)
                        .name(productCode != null ? productCode.resolveFeatures(productFeatures) : null)
                        .build())
                .request(new CContextRequest.Builder()
                        .id(String.valueOf(requestId))
                        .requestDate(instantToString(orderService.getSubmittedDTTM()))
                        .purpose(service.getName())
                        .properties(new CPropertiesRequest.Builder()
                                .audit(false)
                                .build())
                        .build())
                .guidelines(new CGuidelines.Builder()
                        .product(new ArrayList<>())  //TODO
                        .client(getGuideline(String.valueOf(service.getId()), String.valueOf(customer.getID())))
                        .generic(getGuideline(String.valueOf(service.getId()), String.valueOf(DEFAULT_CUSTOMER)))
                        .build())
                .build();

        final CInstitution institution = toInstitution(education);
        final List<CReferenceObjects> referenceObjects = getReferenceObjects(requestId, orderServiceID);
        final List<CNote> notes = getNotes(orderID, orderServiceID);

        final CProvidedSource providedSource = new CProvidedSource.Builder()
                .id(getIdentifierService().build(orderService))
                .context(context)
                .institution(institution)
                .referenceObjects(referenceObjects)
                .notes(notes)
                .build();

        return new CEducationDataRequest.Builder()
                .specVersion("1.0")
                .id(getIdentifierService().build(orderService))
                .source("hrg:hre:data-request")
                .type("EducationFulfillmentRequest")
                .dataContentType("application/json")
                .time(Instant.now().toString())
                .dataSchema("schemas/EducationFulfillment.json")
                .data(new CEducationData.Builder()
                        .providedSource(providedSource)
                        .dataSource(getDataSource(orderServiceID))
                        .build())
                .build();
    }

    @SuppressWarnings("unchecked")
    private List<CReferenceObjects> getReferenceObjects(Long requestId, Long orderServiceId) {
        Criteria query = DB.session().createCriteria(CEducation.class);
        query.add(Restrictions.eq("id.requestId", requestId));
        query.add(Restrictions.ne("orderServiceId", orderServiceId));

        List<CEducation> educationList = query.list();

        return educationList.stream()
                .map(educationItem -> {
                    COrderService orderService = COrderService.load(educationItem.getOrderServiceId());

                    return new CReferenceObjects.Builder()
                            .type("order-item")
                            .id(getIdentifierService().build(orderService))
                            .institution(toInstitution(educationItem))
                            .build();
                })
                .collect(Collectors.toList());
    }

    private CInstitution toInstitution(CEducation education) {
        return new CInstitution.Builder()
                .name(education.getSchoolName())
                .location(new CLocation.Builder()
                        .city(education.getSchoolCity())
                        .region(education.getProvince())
                        .country(resolveCountryCode(education.getCountry(), education.getCountryId()))
                        .postalCode(null)
                        .build())
                .qualifications(new CQualification.Builder()
                        .degree(education.getDegree())
                        .major(education.getMajor())
                        .tenure(new CTenure.Builder()
                                .start(dateToString(education.getStartDate()))
                                .end(dateToString(education.getEndDate()))
                                .current(education.getEndDate() == null)
                                .build())
                        //.grade()
                        .degreeReceived(education.getReceivedDegree() != null)
                        .degreeDate(instantToString(education.getReceivedDegreeDate()))
                        //.futureDegreeApproachDate()
                        //.plansToGraduateWithinLimit()
                        .build())
                //.permissionToContact()
                .spokeWith(education.getSpokeTo())
                .build();
    }
}
