/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.api;

import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ResultResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;

import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.BASE_FULFILLMENTS_SERVICE_API_PATH;

@RequestMapping(BASE_FULFILLMENTS_SERVICE_API_PATH)

public interface ResultApi
{
	@PostMapping("/{request_id}/results")
	ResponseEntity<ResultResponse> submitResult(@PathVariable("request_id") String requestId, @Valid
	@RequestBody ResultRequest resultRequest);
}
