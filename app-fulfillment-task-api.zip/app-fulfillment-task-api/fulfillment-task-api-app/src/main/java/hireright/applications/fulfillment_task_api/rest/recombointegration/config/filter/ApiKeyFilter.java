package hireright.applications.fulfillment_task_api.rest.recombointegration.config.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.validation.ErrorResponse;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

/**
 * @author Keshav Ladha
 * @version 1.0
 */
@Component
@Slf4j
public class ApiKeyFilter extends OncePerRequestFilter {

    private static final String API_KEY_HEADER = "x-api-key";

    @Value("${api.key}")
    private String apiKey;

    private final ObjectMapper objectMapper;

    public ApiKeyFilter(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String path = request.getRequestURI();
        if (shouldSkipAuthentication(path)) {
            filterChain.doFilter(request, response);
            return;
        }

        String apiKey = request.getHeader(API_KEY_HEADER);

        if (apiKey == null || !apiKey.equals(this.apiKey)) {
            sendAuthenticationError(response, "Invalid or missing API key");
            return;
        }
        filterChain.doFilter(request, response);
    }

    /**
     * Check if Authentication should be skipped for this path
     */
    private boolean shouldSkipAuthentication(String path) {
        return path.startsWith("/fulfillment_task_api/actuator") || path.startsWith(
                "/fulfillment_task_api/health") || path.equals("/") || path.startsWith("/swagger")
                || path.startsWith("/v3/api-docs") || path.startsWith("/fulfillment_task_api/api-docs")
                || path.startsWith("/fulfillment_task_api/swagger-ui");
    }

    private void sendAuthenticationError(HttpServletResponse response, String reason) throws IOException {
        String requestId = UUID.randomUUID().toString();

        ErrorResponse errorResponse = ErrorResponse.authenticationError(
                requestId,
                "API key is missing or invalid",
                reason
        );

        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.getWriter().write(objectMapper.writeValueAsString(errorResponse));
    }
}
