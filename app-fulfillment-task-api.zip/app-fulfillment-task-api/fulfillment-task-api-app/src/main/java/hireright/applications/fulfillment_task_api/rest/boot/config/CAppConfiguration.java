/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.boot.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import hireright.lib.logging.log_data_exchange.CDataExchangeLogger;
import hireright.lib.logging.log_data_exchange.IDataExchangeLogger;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;
import org.springframework.format.support.DefaultFormattingConversionService;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.support.ConfigurableWebBindingInitializer;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

import java.util.ArrayList;
import java.util.List;

import static java.lang.System.setProperty;

@Configuration
@EnableAspectJAutoProxy (exposeProxy = true)
@ImportResource("classpath:rest-api-context.xml")
class CAppConfiguration {

    private static final String HRG_WEBAPP_LOGGING_INITIAL_GLX_POSTING_URL = "logging.InitialGlxPostingUrl";

    @Value ("${logging.InitialGlxPostingUrl:http://us11iass.data.hireright.com:6808/log_receiver/postGlx}")
    private String loggingInitialGlxPostingUrl;

    @Bean
    ObjectMapper objectMapper() {
        return JsonMapper.builder()
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                //.disable(MapperFeature.REQUIRE_HANDLERS_FOR_JAVA8_TIMES)
                .addModule(new Jdk8Module())
                .addModule(new JavaTimeModule())
                .build();
    }

    @Bean
    public RequestMappingHandlerAdapter requestMappingHandlerAdapter()
    {
        RequestMappingHandlerAdapter adapter = new RequestMappingHandlerAdapter();

        // Set up message converters
        List<HttpMessageConverter<?>> converters = new ArrayList<>();
        converters.add(new MappingJackson2HttpMessageConverter(objectMapper()));
        converters.add(new StringHttpMessageConverter());
        converters.add(new ByteArrayHttpMessageConverter());

        adapter.setMessageConverters(converters);

        // Set up web binding initializer
        ConfigurableWebBindingInitializer initializer = new ConfigurableWebBindingInitializer();
        initializer.setConversionService(new DefaultFormattingConversionService());
        adapter.setWebBindingInitializer(initializer);

        return adapter;
    }

    @Bean
    IDataExchangeLogger dataExchangeLogger() {
        return CDataExchangeLogger.DEFAULT;
    }

    @PostConstruct
    void setLoggerEndpoint() {
        setProperty(HRG_WEBAPP_LOGGING_INITIAL_GLX_POSTING_URL, this.loggingInitialGlxPostingUrl);
    }
}
