/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.config.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.validation.ErrorResponse;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * API Version Validation Filter
 * Validates API version in the request path and rejects unsupported versions
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Component
@Slf4j
public class ApiVersionValidationFilter extends OncePerRequestFilter {

    // Pattern to extract version from path like /v1/fulfillment/... or /v2/fulfillment/...
    private static final Pattern VERSION_PATTERN =
            Pattern.compile("^/fulfillment_task_api/(v\\d+)(?:/.*)?$");
    private final ObjectMapper objectMapper;
    @Value("${api.supported-versions:v1}")
    private String supportedVersionsConfig;

    @Value("${api.latest-version:v1}")
    private String latestVersion;

    public ApiVersionValidationFilter(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        String path = request.getRequestURI();

        // Skip validation for non-versioned endpoints
        if (shouldSkipValidation(path)) {
            filterChain.doFilter(request, response);
            return;
        }

        // Extract version from path
        Matcher matcher = VERSION_PATTERN.matcher(path);

        if (matcher.matches()) {
            String version = matcher.group(1);

            // Check if version is supported
            List<String> supportedVersions = Arrays.asList(supportedVersionsConfig.split(","));

            if (!supportedVersions.contains(version)) {
                log.warn("Unsupported API version requested - Version: {}, Path: {}", version,
                        path);
                sendVersionError(response, version);
                return;
            }
        }

        // Version is supported or no version in path, continue
        filterChain.doFilter(request, response);
    }

    /**
     * Check if version validation should be skipped for this path
     */
    private boolean shouldSkipValidation(String path) {
        return path.startsWith("/fulfillment_task_api/actuator") || path.startsWith(
                "/fulfillment_task_api/health") || path.equals("/") || path.startsWith("/swagger")
                || path.startsWith("/v3/api-docs") || path.startsWith("/fulfillment_task_api/api-docs")
                || path.startsWith("/fulfillment_task_api/swagger-ui");
    }

    private void sendVersionError(HttpServletResponse response, String version) throws IOException {
        String requestId = UUID.randomUUID().toString();

        ErrorResponse errorResponse = ErrorResponse.genericError(
                requestId,
                "Error.UnsupportedVersion",
                400,
                "Bad Request",
                "UNSUPPORTED_API_VERSION",
                String.format("API version %s is no longer supported. Please use %s.", version, latestVersion)
        );

        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.getWriter().write(objectMapper.writeValueAsString(errorResponse));
    }
}

