/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.service;



import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.ValidationDetail;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Service for validating result submission requests.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Service
@Slf4j
public class RequestValidationService {

	/**
	 * Validate a result submission request
	 *
	 * @param requestId the request ID from the path
	 * @param resultRequest the result request to validate
	 * @throws ValidationException if validation fails
	 */
	public void validateResultRequest(String requestId, ResultRequest resultRequest) {
		List<ValidationDetail> errors = new ArrayList<>();

		// Validate request ID match
		if (resultRequest.getId() == null || resultRequest.getId().isEmpty()) {
			errors.add(ValidationDetail.builder()
				.field("id")
				.message("Request ID is required")
				.build());
		} else if (!requestId.equals(resultRequest.getId())) {
			errors.add(ValidationDetail.builder()
				.field("id")
				.message("Request ID in path does not match request ID in body")
				.build());
		}

		// Validate CloudEvents required fields
		if (resultRequest.getSpecversion() == null || resultRequest.getSpecversion().isEmpty()) {
			errors.add(ValidationDetail.builder()
				.field("specversion")
				.message("CloudEvents spec version is required")
				.build());
		}

		if (resultRequest.getSource() == null || resultRequest.getSource().isEmpty()) {
			errors.add(ValidationDetail.builder()
				.field("source")
				.message("CloudEvents source is required")
				.build());
		}

		if (resultRequest.getType() == null || resultRequest.getType().isEmpty()) {
			errors.add(ValidationDetail.builder()
				.field("type")
				.message("CloudEvents type is required")
				.build());
		}

		// Validate data payload
		if (resultRequest.getData() == null) {
			errors.add(ValidationDetail.builder()
				.field("data")
				.message("Data payload is required")
				.build());
		} else {
			// Validate decision field
			if (resultRequest.getData().getDecision() == null ||
				resultRequest.getData().getDecision().isEmpty()) {
				errors.add(ValidationDetail.builder()
					.field("decision")
					.message("Decision is required")
					.build());
			}

			// Validate result data
			if (resultRequest.getData().getResultData() == null) {
				errors.add(ValidationDetail.builder()
					.field("resultData")
					.message("Result data is required")
					.build());
			}
		}

		// If there are validation errors, throw ValidationException
		if (!errors.isEmpty()) {
			log.warn("Validation failed for request ID: {} - {} errors found", requestId, errors.size());
			throw new ValidationException("Input validation failed", requestId, errors);
		}

		log.debug("Validation successful for request ID: {}", requestId);
	}
}

