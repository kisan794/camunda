package hireright.applications.fulfillment_task_api.rest.recombointegration.service.factory;

import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ScreeningType;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl.EducationResultServiceImpl;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl.EmploymentResultServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ResultServiceFactory {

    private final Map<String, ResultService> serviceMap = new HashMap<>();

    @Autowired
    public ResultServiceFactory(List<ResultService> services) {
        for (ResultService service : services) {
            if (service instanceof EducationResultServiceImpl) {
                serviceMap.put(ScreeningType.EDUCATION.getValue(), service);
            } else if (service instanceof EmploymentResultServiceImpl) {
                serviceMap.put(ScreeningType.EMPLOYMENT.getValue(), service);
            }
        }
    }

    public ResultService getService(String type) {
        ResultService service = serviceMap.get(type.toLowerCase());
        if (service == null) {
            throw new IllegalArgumentException("Unknown result type: " + type);
        }
        return service;
    }
}
