package hireright.applications.fulfillment_task_api.rest.recombointegration.exception;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CValidationDetail;

import java.util.List;

/**
 * Exception thrown when request validation fails.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class ValidationException extends RuntimeException {

    private final String requestId;
    private final transient List<CValidationDetail> details;

    public ValidationException(String message, String requestId, List<CValidationDetail> details) {
        super(message);
        this.requestId = requestId;
        this.details = details;
    }

    public String getRequestId() {
        return requestId;
    }

    public List<CValidationDetail> getDetails() {
        return details;
    }
}
