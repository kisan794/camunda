package hireright.applications.fulfillment_task_api.rest.recombointegration.db;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import hireright.applications.fulfillment_task_api.rest.recombointegration.processor.CEducationProcessor;
import hireright.applications.fulfillment_task_api.rest.recombointegration.processor.CEmploymentProcessor;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.CIdentifierService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ISourceDetectionService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant;
import hireright.objects.order2.COrderService;
import hireright.objects.service2.CService;
import hireright.objects.service2.CServiceFactory;
import hireright.sdk.db3.DB;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Objects;

import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.EDUCATION;
import static hireright.applications.fulfillment_task_api.rest.recombointegration.util.Constant.EMPLOYMENT;

@Service
public class CDbProcessor implements IDbProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(CDbProcessor.class);

    private final ISourceDetectionService sourceDetectionService;
    private final CEducationProcessor educationProcessor;
    private final CEmploymentProcessor employmentProcessor;
    private final CIdentifierService identifierService;

    public CDbProcessor(ISourceDetectionService sourceDetectionService,
            CEducationProcessor educationProcessor,
            CEmploymentProcessor employmentProcessor,
            CIdentifierService identifierService) {
        this.sourceDetectionService = sourceDetectionService;
        this.educationProcessor = educationProcessor;
        this.employmentProcessor = employmentProcessor;
        this.identifierService = identifierService;
    }

    @Override
    public ITaskDataResult getTaskData(String sTaskId) {
        try {
            return DB.execute(() -> {

                COrderService orderService = loadOrderService(sTaskId);
                Objects.requireNonNull(orderService);

                Long lOrderID = orderService.getOrderID();
                Objects.requireNonNull(lOrderID);

                CService service = CServiceFactory.getById(orderService.getServiceID());
                Objects.requireNonNull(service);

                final String sourceType = this.sourceDetectionService.getSourceType(service.getId());
                return switch (sourceType) {
                    case EDUCATION -> new TaskDataResult(processEduction(sTaskId, orderService, service), EDUCATION, orderService.getIDLong());
                    case EMPLOYMENT -> new TaskDataResult(processEmployment(sTaskId, orderService, service), EMPLOYMENT, orderService.getIDLong());
                    default -> null;
                };
            });
        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }

        return null;
    }

    private Object processEduction(
            String sTaskId, COrderService orderService, CService service) throws Exception {
        return this.educationProcessor.process(sTaskId, orderService, service);
    }

    private Object processEmployment(
            String sTaskId, COrderService orderService, CService service) throws Exception {
        return this.employmentProcessor.process(sTaskId, orderService, service);
    }

    private COrderService loadOrderService(String sRequestId) {

        final String orderServiceCode = this.identifierService.getTaskID(sRequestId);

        return COrderServiceFactory.getOrderService(orderServiceCode);
    }

    private static class TaskDataResult implements ITaskDataResult {

        private final Object data;
        private final String sourceType;
        private final long orderServiceID;

        public TaskDataResult(Object data, String sourceType, long orderServiceID) {
            this.data = data;
            this.sourceType = sourceType;
            this.orderServiceID = orderServiceID;
        }

        @Override
        public long getOrderServiceID() {
            return this.orderServiceID;
        }

        @Override
        public String getSourceType() {
            return this.sourceType;
        }

        @Override
        public Object getData() {
            return  this.data;
        }
    }
}
