package hireright.applications.fulfillment_task_api.rest.recombointegration.service;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-12-16  Created
 */

import hireright.objects.order.COrderServiceDataSource;
import hireright.objects.order.COrderServiceDataSourceFactory;
import hireright.sdk.util.CProperties;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * @author mkuznetsov
 */
@Service
public class COsdsService {

    private static final String STATE_COMPLETED = "COMPLETED";
    private static final String TALX_4_SEARCH = "TALX4-SEARCH";
    private static final String EQFX_EDUCATION = "EQFX-EDUCATION";
    private static final String NSCH_3_SEARCH = "NSCH3-SEARCH";
    private static final String TRANSACTION_ID = "transactionID";
    private static final String RECOMBO = "RECOMBO";

    private Optional<COrderServiceDataSource> getLastOSDS(long orderServiceID, String...arrProviderDataSourceID) {

        for (String providerDataSourceID : arrProviderDataSourceID) {
            final List<COrderServiceDataSource> serviceDataSources = COrderServiceDataSourceFactory.loadByOrderServiceAndState(
                    orderServiceID, providerDataSourceID, STATE_COMPLETED);

            if (serviceDataSources == null || serviceDataSources.isEmpty()) {
                continue;
            }

            return Optional.of(serviceDataSources.stream()
                    .sorted(Comparator.comparing(COrderServiceDataSource::getStateDate))
                    .toList()
                    .getLast());
        }
        return Optional.empty();
    }

    public String getAnyTransactionId(long orderServiceID){
        return getLastOSDS(orderServiceID, TALX_4_SEARCH, EQFX_EDUCATION, NSCH_3_SEARCH)
                .map(COrderServiceDataSource::getProperties)
                .map(props -> props.getProperty(TRANSACTION_ID))
                .orElse(null);
    }

    public String getEmploymentResponse(long orderServiceID) {
        return getLastOSDS(orderServiceID, TALX_4_SEARCH)
                .map(COrderServiceDataSource::getResponse)
                .orElse(null);
    }

    public String getEducationResponse(long orderServiceID) {
        //'TALX4-SEARCH',
        return getLastOSDS(orderServiceID, EQFX_EDUCATION, NSCH_3_SEARCH)
                .map(COrderServiceDataSource::getResponse)
                .orElse(null);
    }

    public void createIncomingOSDS(long orderServiceID, String response, CProperties props) {

        final Optional<COrderServiceDataSource> existingRecombo = getLastOSDS(orderServiceID, RECOMBO);

        final COrderServiceDataSource osds;
        if (existingRecombo.isPresent()) {
            osds = existingRecombo.get();
        }
        else {
            osds = new COrderServiceDataSource();
            osds.setOrderServiceID(orderServiceID);
            osds.setState(STATE_COMPLETED);
            osds.setStateDate(new Date());
            osds.setStateMachineID(28);
            osds.setProviderDataSourceID(RECOMBO);
            osds.setResponseFormat("TEXT");
            osds.setResponseType("EXTERNAL");
        }
        osds.setResponse(response);
        osds.setResponseDate(new Date());
        osds.setProperties(props);

        COrderServiceDataSourceFactory.save(osds);
    }
}
