package hireright.applications.fulfillment_task_api.rest.controller;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-01-16  HRG-330191 migration to Spring MVC
 */

import com.hireright.component.spring.rest.log.exchange.LogDataExchange;
import hireright.applications.fulfillment_task_api.api.ITestApiProvider;

import hireright.applications.fulfillment_task_api.model.CEmpty;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

@Controller
public class CTestController extends CAbstractController implements TestApi {

    public CTestController(ITestApiProvider apiProvider) {
        super(apiProvider);
    }

    @Override
    @LogDataExchange (protocol = "HR-FULFILLMENT-TASK-API/1.0",
            recipientClass = "WEBAPP",
            recipientID = "fulfillment_task_api")
    public ResponseEntity<CEmpty> testError(
            String xHRDbTenantCode,
            String xHROriginator,
            String xHRTransactionId) {

        execute(xHRDbTenantCode, xHROriginator, xHRTransactionId, api -> {
            api.getTestManager().error();
            return null;
        });

        return ResponseEntity.noContent().build();
    }

    @Override
    //@CommitTransaction
    @LogDataExchange (protocol = "HR-FULFILLMENT-TASK-API/1.0",
            recipientClass = "WEBAPP",
            recipientID = "fulfillment_task_api")
    public ResponseEntity<CEmpty> testOk(String xHRDbTenantCode,
            String xHROriginator,
            String xHRTransactionId) {

        execute(xHRDbTenantCode, xHROriginator, xHRTransactionId, api -> {
            api.getTestManager().ok();
            return null;
        });

        return ResponseEntity.noContent().build();
    }


}
