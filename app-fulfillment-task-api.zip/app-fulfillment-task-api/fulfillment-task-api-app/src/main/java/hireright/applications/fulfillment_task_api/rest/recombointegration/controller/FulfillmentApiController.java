package hireright.applications.fulfillment_task_api.rest.recombointegration.controller;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.common.CFulfillmentResponse;
import hireright.applications.fulfillment_task_api.rest.controller.FulfillmentApi;
import hireright.applications.fulfillment_task_api.rest.recombointegration.db.IDbProcessor;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * Fulfillment Controller for initiating processing
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@RestController
@EnableRetry
@Validated
public class FulfillmentApiController implements FulfillmentApi {

    private static final Logger LOG = LoggerFactory.getLogger(FulfillmentApiController.class);

    private final FulfillmentService fulfillmentService;
    private final ObjectMapper objectMapper;

    public FulfillmentApiController(FulfillmentService fulfillmentService, ObjectMapper objectMapper) {
        this.fulfillmentService = fulfillmentService;
        this.objectMapper = objectMapper;
    }

    /**
     * POST endpoint to initiate a fulfillment
     * Returns immediately with "Accepted" status and processes asynchronously
     *
     * @param requestId to initiate
     * @return ResponseEntity with immediate acceptance response
     */
    @Override
    public ResponseEntity<CFulfillmentResponse> initiate(
            @PathVariable("request_id") final String requestId) {
        LOG.info("Received initiation request - Task ID: {}", requestId);

        //Trigger async processing
        fulfillmentService.fulfill(requestId);

        // Return immediate response
        CFulfillmentResponse response = new CFulfillmentResponse.Builder()
                .status("Accepted")
                .message("Sub-request triggered successfully.")
                .build();

        LOG.info("initiation accepted - Task ID: {}", requestId);

        return ResponseEntity.accepted().body(response);
    }

    /**
     * GET endpoint to retrieve task data by request ID
     * Returns the task data result containing verification data
     *
     * @param requestId to retrieve task data for
     * @return ResponseEntity with task data or error response
     */
    @Override
    public ResponseEntity<CFulfillmentResponse> getTaskData(
            @PathVariable("request_id") final String requestId) {
        LOG.info("Received task data retrieval request - Request ID: {}", requestId);

        try {
            IDbProcessor.ITaskDataResult<?> taskDataResult = fulfillmentService.getTaskData(requestId);

            if (taskDataResult == null) {
                LOG.warn("Task data not found - Request ID: {}", requestId);
                CFulfillmentResponse response = new CFulfillmentResponse.Builder()
                        .status("NotFound")
                        .message("Task data not found for request ID: " + requestId)
                        .build();
                return ResponseEntity.status(404).body(response);
            }

            // Serialize the task data to JSON string
            String taskDataJson = objectMapper.writeValueAsString(taskDataResult.getData());

            CFulfillmentResponse response = new CFulfillmentResponse.Builder()
                    .status("Success")
                    .message(taskDataJson)
                    .build();

            LOG.info("Task data retrieved successfully - Request ID: {}", requestId);
            return ResponseEntity.ok().body(response);

        } catch (Exception e) {
            LOG.error("Error retrieving task data - Request ID: {}", requestId, e);
            CFulfillmentResponse response = new CFulfillmentResponse.Builder()
                    .status("Error")
                    .message("Error retrieving task data: " + e.getMessage())
                    .build();
            return ResponseEntity.status(500).body(response);
        }
    }

}