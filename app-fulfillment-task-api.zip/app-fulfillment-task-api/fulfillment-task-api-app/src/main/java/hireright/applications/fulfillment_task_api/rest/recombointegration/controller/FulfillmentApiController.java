package hireright.applications.fulfillment_task_api.rest.recombointegration.controller;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import hireright.applications.fulfillment_task_api.model.recombointegration.common.CFulfillmentResponse;
import hireright.applications.fulfillment_task_api.rest.controller.FulfillmentApi;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * Fulfillment Controller for initiating processing
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@RestController
@EnableRetry
@Validated
public class FulfillmentApiController implements FulfillmentApi {

    private static final Logger LOG = LoggerFactory.getLogger(FulfillmentApiController.class);

    private final FulfillmentService fulfillmentService;

    public FulfillmentApiController(FulfillmentService fulfillmentService) {
        this.fulfillmentService = fulfillmentService;
    }

    /**
     * POST endpoint to initiate a fulfillment
     * Returns immediately with "Accepted" status and processes asynchronously
     *
     * @param requestId to initiate
     * @return ResponseEntity with immediate acceptance response
     */
    @Override
    public ResponseEntity<CFulfillmentResponse> initiate(
            @PathVariable("request_id") final String requestId) {
        LOG.info("Received initiation request - Task ID: {}", requestId);

        //Trigger async processing
        fulfillmentService.fulfill(requestId);

        // Return immediate response
        CFulfillmentResponse response = new CFulfillmentResponse.Builder()
                .status("Accepted")
                .message("Sub-request triggered successfully.")
                .build();

        LOG.info("initiation accepted - Task ID: {}", requestId);

        return ResponseEntity.accepted().body(response);
    }

}

