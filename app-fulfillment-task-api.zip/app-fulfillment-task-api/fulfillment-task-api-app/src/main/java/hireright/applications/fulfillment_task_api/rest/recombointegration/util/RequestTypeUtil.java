/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.util;

/**
 * Utility class for determining request types based on request ID patterns.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
public class RequestTypeUtil
{

	private static final String EMPLOYMENT_IDENTIFIER = "-EM-";
	private static final String EDUCATION_IDENTIFIER = "-ED-";

	/**
	 * Private constructor to prevent instantiation
	 */
	private RequestTypeUtil()
	{
		throw new IllegalStateException("Utility class");
	}

	/**
	 * Determines if the request is for employment verification based on request ID.
	 *
	 * @param requestId The request identifier
	 * @return true if the request is for employment verification
	 */
	public static boolean isEmploymentRequest(String requestId)
	{
		return requestId != null && requestId.contains(EMPLOYMENT_IDENTIFIER);
	}

	/**
	 * Determines if the request is for education verification based on request ID.
	 *
	 * @param requestId The request identifier
	 * @return true if the request is for education verification
	 */
	public static boolean isEducationRequest(String requestId)
	{
		return requestId != null && requestId.contains(EDUCATION_IDENTIFIER);
	}

	/**
	 * Gets the request type as a string.
	 *
	 * @param requestId The request identifier
	 * @return "EMPLOYMENT", "EDUCATION", or "UNKNOWN"
	 */
	public static String getRequestType(String requestId)
	{
		if(isEmploymentRequest(requestId))
		{
			return "EMPLOYMENT";
		}
		else if(isEducationRequest(requestId))
		{
			return "EDUCATION";
		}
		return "UNKNOWN";
	}
}

