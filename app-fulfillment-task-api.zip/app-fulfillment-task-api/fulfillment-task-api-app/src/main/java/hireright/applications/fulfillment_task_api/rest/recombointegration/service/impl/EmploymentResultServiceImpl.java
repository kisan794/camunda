package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.response.EmploymentResultData;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.response.EmploymentResultRequest;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.EmploymentValidationUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class EmploymentResultServiceImpl extends ResultService {

    private final LoggingService loggingService;
    private final ObjectMapper objectMapper;

    public EmploymentResultServiceImpl(LoggingService loggingService, ObjectMapper objectMapper) {
        this.loggingService = loggingService;
        this.objectMapper = objectMapper;
    }

    @Override
    public void processEmploymentSubmission(String requestId, EmploymentResultRequest resultRequest) {
        EmploymentValidationUtil.validateResultRequest(requestId, resultRequest);

        log.info("Processing fulfillment result - Request ID: {}, Type: {}", requestId, resultRequest.getType());

        EmploymentResultData resultData = resultRequest.getData().getResultData();
        // @TODO need to process internally
        processResultData(resultData, requestId);

        String jsonPayload = serializeRequest(resultRequest);
        loggingService.log(jsonPayload, requestId, RecipientName.FULFILLMENT_RESPONSE, Direction.IN);

        log.info("Successfully processed fulfillment result - Request ID: {}, Decision: {}", requestId, resultRequest.getData().getDecision());

    }

    /**
     * Serialize the submit request to JSON
     *
     * @param resultRequest The request to serialize
     * @return JSON string representation
     */
    private String serializeRequest(EmploymentResultRequest resultRequest) {
        try {
            return objectMapper.writeValueAsString(resultRequest);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    private void processResultData(EmploymentResultData resultData, String requestId) {
        log.info("Employment verification result - Request ID: {}, Employer: {}, Position: {}", requestId, resultData.getEmployerOrgName(),
                resultData.getPositionHistory() != null ? resultData.getPositionHistory().getTitle() : "N/A");

    }
}
