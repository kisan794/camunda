/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.controller;

import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CResultRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.cloudevents.CResultResponse;
import hireright.applications.fulfillment_task_api.rest.controller.ResultApi;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.ResultService;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * Results Controller for receiving fulfillment task results.
 * Implements CloudEvents v1.0 specification for result submissions.
 *
 * @author Keshav Ladha
 * @version 1.0
 * @see CResultRequest
 * @see CResultResponse
 */
@RestController
@EnableRetry
@Validated
public class ResultApiController implements ResultApi {

    private final ResultService resultService;

    public ResultApiController(ResultService resultService) {
        this.resultService = resultService;
    }

    /**
     * POST endpoint to receive task results in CloudEvents format.
     */
    @Override
    public ResponseEntity<CResultResponse> submitResult(
            @PathVariable("request_id") final String requestId,
            @Valid @RequestBody CResultRequest resultRequest) {
        CResultResponse resultResponse = this.resultService.processSubmission(requestId, resultRequest);
        // Create and return success response
        return ResponseEntity.accepted().body(resultResponse);

    }
}