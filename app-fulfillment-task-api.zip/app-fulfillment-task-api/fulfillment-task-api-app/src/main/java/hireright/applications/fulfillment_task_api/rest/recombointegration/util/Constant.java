/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.util;

public final class Constant
{

	public static final String TITLE = "Recombo Integration Serivce";
	public static final String VERSION = "v1";
	public static final String DESCRIPTION = "REST API for Recombo Integration Service";
	public static final String FULFILLMENTS_SERVICE = "/fulfillments";
	public static final String API_PREFIX = "/api";
	public static final String BASE_FULFILLMENTS_SERVICE_API_PATH = VERSION + FULFILLMENTS_SERVICE;

	public static final String ERROR_CODE_XML_TRANSFORMATION = "XML_TRANSFORMATION_ERROR";
	public static final String ERROR_CODE_XML_VALIDATION = "XML_VALIDATION_ERROR";
	public static final String ERROR_CODE_HTTP_CLIENT = "HTTP_CLIENT_ERROR";
	public static final String ERROR_CODE_RETRY_EXHAUSTED = "RETRY_EXHAUSTED";
	public static final String ERROR_CODE_JWT_AUTH = "JWT_AUTH_ERROR";
	public static final String SCREENING_TYPE_EDUCATION = "education";
	public static final String SCREENING_TYPE_EMPLOYMENT = "employment";
	public static final String FIELD_STATUS = "status";
	public static final String FIELD_MESSAGE = "message";
	public static final String FIELD_ERROR = "error";
	public static final String FIELD_ERROR_CODE = "errorCode";
	public static final String FIELD_TYPE = "type";
	public static final String FIELD_NAME = "name";
	public static final String FIELD_TIMESTAMP = "timestamp";
	public static final String FIELD_PATH = "path";
	public static final String XML_PATH_ANY_DATE = "AnyDate";
	public static final String XML_PATH_SCREENING = "Screening";
	public static final String XML_PATH_NAME = "name";
	public static final String XML_PATH_TYPE = "type";
	public static final String XML_PATH_PRODUCER_REFERENCE_ID = "ProducerReferenceId";
	public static final String XML_PATH_ID_VALUE = "IdValue";

	private Constant()
	{
		throw new UnsupportedOperationException(
			"This is a utility class and cannot be instantiated");
	}

}
