package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;
/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.rest.recombointegration.db.IDbProcessor;
import hireright.applications.fulfillment_task_api.rest.recombointegration.http.client.Http2ClientService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.COrderHistoryService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.util.CorrelationIdHolder;
import hireright.lib.logging.log_data_exchange.CDataExchangeLogger;
import hireright.sdk.db3.DB;
import hireright.sdk.util.CProperties;
import hireright.sdk.util.CStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;

import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
public class FulfillmentServiceImpl implements FulfillmentService {

    private static final Logger LOG = LoggerFactory.getLogger(FulfillmentServiceImpl.class);
    private static final String REQUEST_ID = "requestId";

    private final Http2ClientService http2ClientService;
    private final ObjectMapper objectMapper;
    private final LoggingService loggingService;
    private final IDbProcessor dbProcessor;
    private final COrderHistoryService orderHistoryService;

    // Recombo service configuration
    @Value("${recombo.service.base-url}")
    private String recomboServiceBaseUrl;

    @Value("${recombo.third-party.submit-endpoint}")
    private String recomboSubmitEndpoint;

    @Value("${api.key}")
    private String apiKey;

    public FulfillmentServiceImpl(
            ObjectMapper objectMapper,
            IDbProcessor dbProcessor,
            Http2ClientService http2ClientService,
            LoggingService loggingService,
            COrderHistoryService orderHistoryService) {
        this.http2ClientService = http2ClientService;
        this.objectMapper = objectMapper;
        this.loggingService = loggingService;
        this.dbProcessor = dbProcessor;
        this.orderHistoryService = orderHistoryService;
    }

    /**
     * Process the task asynchronously
     *
     * @param sTaskId The task ID to process
     */
    @Override
    public void fulfill(String sTaskId) {
        if (CStringUtils.isEmpty(CorrelationIdHolder.get())) {
            CorrelationIdHolder.set(CorrelationIdHolder.generate());
        }

        LOG.info("Starting async processing - Request ID: {}", sTaskId);

        // Step 1: Get verification data from cache @TODO DB call and Transformation
        IDbProcessor.ITaskDataResult<?> taskDataResult = this.dbProcessor.getTaskData(sTaskId);
        if (taskDataResult == null) {
            return;
        }

        // Step 2: Send async POST to third-party submit endpoint
        sendAsyncSubmitRequest(sTaskId, taskDataResult);

        LOG.info("Async task processing completed - Task ID: {}", sTaskId);
    }

    /**
     * Get task data by request ID
     *
     * @param requestId The request ID to retrieve task data
     * @return ITaskDataResult containing the task data or null if not found
     */
    @Override
    public IDbProcessor.ITaskDataResult<?> getTaskData(String requestId) {
        return dbProcessor.getTaskData(requestId);
    }

    /**
     * Send async POST request to third-party submit endpoint
     *
     * @param requestId        Task ID
     */
    @Async
    protected void sendAsyncSubmitRequest(String requestId, IDbProcessor.ITaskDataResult<?> taskDataResult) {

        String submitUrl = this.recomboServiceBaseUrl + this.recomboSubmitEndpoint.replace("{sourceType}", taskDataResult.getSourceType());
        LOG.debug("Sending async POST to submit endpoint - URL: {}, Request ID: {}", submitUrl, requestId);

        String jsonPayload;
        try {
            jsonPayload = this.objectMapper.writeValueAsString(taskDataResult.getData());
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        // Log the request for auditing
        final String transactionID = CDataExchangeLogger.generateTransactionID();
        this.loggingService.log(
                jsonPayload, transactionID, RecipientName.FULFILLMENT_REQUEST, Direction.OUT,
                new CProperties()
                        .setProperty(REQUEST_ID, requestId)
                        .setProperty("url", submitUrl)
                        .setProperty("key", this.apiKey)
        );


        Map<String, String> headers = new HashMap<>();
        headers.put("x-api-key", this.apiKey);
        // Send async POST request

        try {
            DB.execute(() -> {
                this.orderHistoryService.createHistoryRecord(taskDataResult.getOrderServiceID(),
                        "Data has been send to RecomboAI. Request: <" + requestId +">. Transaction: " + transactionID);
                DB.commit();
                return null;
            });
        } catch (Exception e) {
            LOG.error("Failed to submit history record for orderServiceID: {}", taskDataResult.getOrderServiceID(), e);
        }

        CompletableFuture<HttpResponse<String>> futureResponse = this.http2ClientService.postAsync(submitUrl, jsonPayload, headers);

        // Handle async response (non-blocking)
        futureResponse.thenAccept(response -> {
            this.loggingService.log(response.body(), transactionID, RecipientName.FULFILLMENT_REQUEST, Direction.IN, new CProperties()
                    .setProperty(REQUEST_ID, requestId)
                    .setProperty("responseCode", response.statusCode()));

            if(response.statusCode() >= 200 && response.statusCode() < 300) {
                LOG.info("Successfully submitted fulfillment data to external system Status: {}, url: {} - Task ID: {}", response.statusCode(), submitUrl, requestId);
            } else {
                LOG.warn("Returned non-success status from external system: {}, url: {} for Task ID: {}", response.statusCode(), submitUrl, requestId);
            }
        }).exceptionally(ex -> {
            LOG.error("Failed to submit fulfillment data to external system url:{}, Task ID: {} - {}", submitUrl, requestId, ex);
            return null;
        });

        LOG.info("Async submit request initiated for Task ID: {}", requestId);
    }
}