/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.education.EducationDataRequest;
import hireright.applications.fulfillment_task_api.model.recombointegration.employment.EmploymentDataRequest;
import hireright.applications.fulfillment_task_api.rest.recombointegration.helper.ReadEducationMockResponse;
import hireright.applications.fulfillment_task_api.rest.recombointegration.helper.ReadEmploymentMockResponse;
import hireright.applications.fulfillment_task_api.rest.recombointegration.http.client.Http2ClientService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.Direction;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.enums.RecipientName;
import hireright.applications.fulfillment_task_api.rest.recombointegration.log.service.LoggingService;
import hireright.applications.fulfillment_task_api.rest.recombointegration.service.FulfillmentService;
import hireright.lib.logging.log_trace.CTraceLogger;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class FulfillmentServiceImpl implements FulfillmentService
{

	private final Http2ClientService http2ClientService;
	private final ObjectMapper objectMapper;
	private final LoggingService loggingService;

	// Cache for education verification data
	private Map<String, EducationDataRequest> educationCache;

	// Cache for employment verification data
	private Map<String, EmploymentDataRequest> employmentCache;

	// Recombo service configuration
	@Value("${recombo.service.base-url}")
	private String recomboServiceBaseUrl;

	@Value("${recombo.third-party.submit-endpoint}")
	private String recomboSubmitEndpoint;

	public FulfillmentServiceImpl(Http2ClientService http2ClientService, ObjectMapper objectMapper,
		LoggingService loggingService)
	{
		this.http2ClientService = http2ClientService;
		this.objectMapper = objectMapper;
		this.loggingService = loggingService;
	}

	/**
	 * Initialize caches on application startup
	 */
	@PostConstruct
	public void initializeCaches()
	{
		try
		{
			log.info("Initializing fulfillment task caches...");
			educationCache = ReadEducationMockResponse.readAllEducationMockResponses();
			employmentCache = ReadEmploymentMockResponse.readAllEmploymentMockResponses();
			log.info(
				"Fulfillment task caches initialized successfully - Education: {}, Employment: {}",
				educationCache.size(), employmentCache.size());
		}
		catch(Exception e)
		{
			log.error("Failed to initialize fulfillment task caches", e);
			// Initialize empty caches to prevent null pointer exceptions
			educationCache = new HashMap<>();
			employmentCache = new HashMap<>();
		}
	}

	/**
	 * Process the task asynchronously
	 *
	 * @param taskId The task ID to process
	 */
	@Async
	@Override
	public void fulfill(String taskId)
	{
		try
		{
			log.info("Starting async task processing - Task ID: {}", taskId);

			// Step 1: Get verification data from cache
			Object verificationData = getVerificationData(taskId);

			if(Objects.isNull(verificationData))
			{
				log.warn("Verification data not found for Task ID: {}", taskId);
				return;
			}

			// Step 2: Send async POST to third-party submit endpoint
			sendAsyncSubmitRequest(taskId, verificationData);

			log.info("Async task processing completed - Task ID: {}", taskId);

		}
		catch(Exception e)
		{
			log.error("Failed to process task asynchronously - Task ID: {}", taskId, e);
		}
	}

	/**
	 * Get verification data from cache based on task ID
	 *
	 * @param taskId The task ID
	 * @return Verification data or null if not found
	 */
	private Object getVerificationData(String taskId)
	{
		// Determine type based on task ID content
		if(taskId.contains("edu") || taskId.contains("EDU"))
		{
			log.debug("Fetching education verification data for Task ID: {}", taskId);
			return educationCache.get(taskId);
		}
		else if(taskId.contains("emp") || taskId.contains("EMP"))
		{
			log.debug("Fetching employment verification data for Task ID: {}", taskId);
			return employmentCache.get(taskId);
		}
		else
		{
			log.warn("Unable to determine verification type for Task ID: {}", taskId);
			return null;
		}
	}

	/**
	 * Send async POST request to third-party submit endpoint
	 *
	 * @param taskId           Task ID
	 * @param verificationData Verification data to submit
	 */
	private void sendAsyncSubmitRequest(String taskId, Object verificationData)
	{
		try
		{
			String submitUrl = recomboServiceBaseUrl + recomboSubmitEndpoint;
			log.debug("Sending async POST to submit endpoint - URL: {}, Task ID: {}", submitUrl,
				taskId);

			String jsonPayload = objectMapper.writeValueAsString(verificationData);

			Map<String, String> headers = new HashMap<>();
			headers.put("Content-Type", "application/json");

			// Log the request for auditing
			logRequest(jsonPayload, taskId);
			// Send async POST request
			CompletableFuture<HttpResponse<String>> futureResponse =
				http2ClientService.postAsync(submitUrl, jsonPayload, headers);

			// Handle async response (non-blocking)
			futureResponse.thenAccept(response -> {
				if(response.statusCode() >= 200 && response.statusCode() < 300)
				{
					log.info(
						"Successfully submitted verification data to third-party - Task ID: {}, Status: {}",
						taskId, response.statusCode());
				}
				else
				{
					log.warn("Third-party submit returned non-success status: {} for Task ID: {}",
						response.statusCode(), taskId);
					CTraceLogger.error(this.getClass().getName(), jsonPayload);
				}
			}).exceptionally(ex -> {
				log.error("Failed to submit verification data to third-party - Task ID: {}", taskId,
					ex);
				return null;
			});

			log.info("Async submit request initiated for Task ID: {}", taskId);

		}
		catch(Exception e)
		{
			log.error("Failed to send async submit request - Task ID: {}", taskId, e);
			// Don't throw exception - this is async and shouldn't block the main response
		}
	}

	/**
	 * Log the request using the logging service.
	 */
	private void logRequest(String jsonPayload, String requestId)
	{
		try
		{
			loggingService.log(jsonPayload, requestId, RecipientName.RECOMBO_REQUEST, Direction.IN);
		}
		catch(Exception e)
		{
			log.error("Failed to log request - ID: {}", requestId, e);
			// Don't fail the request if logging fails
			CTraceLogger.error(e, this.getClass().getName(), e.getMessage());
		}
	}
}
