package hireright.applications.fulfillment_task_api.rest.recombointegration.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ configuration for listener-only setup.
 * Configures queue declarations and listener container factory.
 * Queue creation and bindings are managed externally by the message producer.
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Slf4j
@Configuration
public class RabbitMQConfig
{

	@Value("${rabbitmq.queue.screening-requests}")
	private String screeningRequestsQueue;

	@Value("${rabbitmq.queue.screening-dlq}")
	private String screeningDlq;

	@Value("${rabbitmq.listener.concurrency:5}")
	private int concurrency;

	@Value("${rabbitmq.listener.max-concurrency:10}")
	private int maxConcurrency;

	@Value("${rabbitmq.listener.prefetch-count:10}")
	private int prefetchCount;

	/**
	 * Declares the main screening requests queue.
	 * Messages that fail processing will be sent to DLQ.
	 *
	 * @return Queue bean for screening requests
	 */
	@Bean
	public Queue screeningRequestsQueue()
	{
		log.info("Declaring screening requests queue: {}", screeningRequestsQueue);
		return QueueBuilder.durable(screeningRequestsQueue)
			.withArgument("x-dead-letter-exchange", "")
			.withArgument("x-dead-letter-routing-key", screeningDlq)
			.build();
	}

	/**
	 * Declares the Dead Letter Queue (DLQ) for failed messages.
	 *
	 * @return Queue bean for DLQ
	 */
	@Bean
	public Queue screeningDlq()
	{
		log.info("Declaring screening DLQ: {}", screeningDlq);
		return QueueBuilder.durable(screeningDlq).build();
	}

	/**
	 * Configures the RabbitMQ listener container factory.
	 * Sets concurrency, prefetch count, and message converter.
	 *
	 * @param connectionFactory RabbitMQ connection factory
	 * @return configured listener container factory
	 */
	@Bean
	public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
		ConnectionFactory connectionFactory)
	{

		SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
		factory.setConnectionFactory(connectionFactory);
		factory.setMessageConverter(jsonMessageConverter());
		factory.setConcurrentConsumers(concurrency);
		factory.setMaxConcurrentConsumers(maxConcurrency);
		factory.setPrefetchCount(prefetchCount);
		factory.setDefaultRequeueRejected(false); // Send to DLQ on failure

		log.info("RabbitMQ listener factory configured - Concurrency: {}-{}, Prefetch: {}",
			concurrency, maxConcurrency, prefetchCount);

		return factory;
	}

	/**
	 * Configures JSON message converter for RabbitMQ messages.
	 *
	 * @return Jackson2JsonMessageConverter
	 */
	@Bean
	public MessageConverter jsonMessageConverter()
	{
		return new Jackson2JsonMessageConverter();
	}
}

