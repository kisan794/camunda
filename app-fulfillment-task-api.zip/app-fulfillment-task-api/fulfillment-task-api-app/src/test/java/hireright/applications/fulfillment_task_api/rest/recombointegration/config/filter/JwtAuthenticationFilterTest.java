/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.config.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import hireright.applications.fulfillment_task_api.model.recombointegration.validation.ErrorResponse;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for JwtAuthenticationFilter
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("JwtAuthenticationFilter Tests")
class JwtAuthenticationFilterTest
{

	@Mock
	private JwtTokenValidator jwtTokenValidator;

	@Mock
	private FilterChain filterChain;

	private JwtAuthenticationFilter filter;
	private ObjectMapper objectMapper;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	@BeforeEach
	void setUp()
	{
		objectMapper = new ObjectMapper();
		filter = new JwtAuthenticationFilter(jwtTokenValidator, objectMapper);
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
	}

	@Test
	@DisplayName("Should allow request with valid JWT token")
	void testValidJwtToken() throws ServletException, IOException
	{
		// Given
		String validToken = "valid.jwt.token";
		request.addHeader("Authorization", "Bearer " + validToken);
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		when(jwtTokenValidator.validateToken(validToken)).thenReturn(true);

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(jwtTokenValidator, times(1)).validateToken(validToken);
		verify(filterChain, times(1)).doFilter(request, response);
		assertEquals(200, response.getStatus());
	}

	@Test
	@DisplayName("Should reject request with invalid JWT token")
	void testInvalidJwtToken() throws ServletException, IOException
	{
		// Given
		String invalidToken = "invalid.jwt.token";
		request.addHeader("Authorization", "Bearer " + invalidToken);
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		when(jwtTokenValidator.validateToken(invalidToken)).thenReturn(false);

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(jwtTokenValidator, times(1)).validateToken(invalidToken);
		verify(filterChain, never()).doFilter(request, response);
		assertEquals(401, response.getStatus());
		assertEquals(MediaType.APPLICATION_JSON_VALUE, response.getContentType());

		String responseBody = response.getContentAsString();
		assertTrue(responseBody.contains("INVALID_OR_EXPIRED_TOKEN"));
	}

	@Test
	@DisplayName("Should reject request without Authorization header")
	void testMissingAuthorizationHeader() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");
		// No Authorization header

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(jwtTokenValidator, never()).validateToken(anyString());
		verify(filterChain, never()).doFilter(request, response);
		assertEquals(401, response.getStatus());

		String responseBody = response.getContentAsString();
		assertTrue(responseBody.contains("MISSING_TOKEN"));
	}

	@Test
	@DisplayName("Should reject request with Authorization header not starting with Bearer")
	void testInvalidAuthorizationHeaderFormat() throws ServletException, IOException
	{
		// Given
		request.addHeader("Authorization", "Basic dXNlcjpwYXNz");
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(jwtTokenValidator, never()).validateToken(anyString());
		verify(filterChain, never()).doFilter(request, response);
		assertEquals(401, response.getStatus());

		String responseBody = response.getContentAsString();
		assertTrue(responseBody.contains("MISSING_TOKEN"));
	}

	@Test
	@DisplayName("Should skip authentication for actuator endpoints")
	void testSkipAuthenticationForActuator() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/actuator/health");
		// No Authorization header

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(jwtTokenValidator, never()).validateToken(anyString());
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should skip authentication for health endpoints")
	void testSkipAuthenticationForHealth() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/health");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(jwtTokenValidator, never()).validateToken(anyString());
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should skip authentication for swagger endpoints")
	void testSkipAuthenticationForSwagger() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/swagger-ui/index.html");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(jwtTokenValidator, never()).validateToken(anyString());
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should skip authentication for api-docs endpoints")
	void testSkipAuthenticationForApiDocs() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/v3/api-docs");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(jwtTokenValidator, never()).validateToken(anyString());
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should skip authentication for root path")
	void testSkipAuthenticationForRootPath() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(jwtTokenValidator, never()).validateToken(anyString());
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should return proper error response structure for missing token")
	void testErrorResponseStructureForMissingToken() throws ServletException, IOException
	{
		// Given
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		assertEquals(401, response.getStatus());
		String responseBody = response.getContentAsString();

		ErrorResponse errorResponse = objectMapper.readValue(responseBody, ErrorResponse.class);
		assertNotNull(errorResponse);
		assertEquals("Error.Authentication", errorResponse.getType());
		assertNotNull(errorResponse.getId());
		assertEquals(401, errorResponse.getData().getStatus());
		assertTrue(errorResponse.getData().getMessage().contains("missing or invalid"));
	}

	@Test
	@DisplayName("Should return proper error response structure for invalid token")
	void testErrorResponseStructureForInvalidToken() throws ServletException, IOException
	{
		// Given
		String invalidToken = "invalid.token";
		request.addHeader("Authorization", "Bearer " + invalidToken);
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		when(jwtTokenValidator.validateToken(invalidToken)).thenReturn(false);

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		assertEquals(401, response.getStatus());
		String responseBody = response.getContentAsString();

		ErrorResponse errorResponse = objectMapper.readValue(responseBody, ErrorResponse.class);
		assertNotNull(errorResponse);
		assertEquals("Error.Authentication", errorResponse.getType());
		assertEquals(401, errorResponse.getData().getStatus());
	}

	@Test
	@DisplayName("Should extract token correctly from Bearer header")
	void testTokenExtractionFromBearerHeader() throws ServletException, IOException
	{
		// Given
		String token = "my.jwt.token.with.multiple.parts";
		request.addHeader("Authorization", "Bearer " + token);
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		when(jwtTokenValidator.validateToken(token)).thenReturn(true);

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(jwtTokenValidator, times(1)).validateToken(token);
		verify(filterChain, times(1)).doFilter(request, response);
	}

	@Test
	@DisplayName("Should handle Bearer header with extra spaces")
	void testBearerHeaderWithExtraSpaces() throws ServletException, IOException
	{
		// Given - "Bearer  token" with two spaces
		request.addHeader("Authorization", "Bearer  extra.space.token");
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then - Should fail because token extraction will include the extra space
		verify(filterChain, never()).doFilter(request, response);
		assertEquals(401, response.getStatus());
	}

	@Test
	@DisplayName("Should handle empty token after Bearer prefix")
	void testEmptyTokenAfterBearer() throws ServletException, IOException
	{
		// Given
		request.addHeader("Authorization", "Bearer ");
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then
		verify(filterChain, never()).doFilter(request, response);
		assertEquals(401, response.getStatus());
	}

	@Test
	@DisplayName("Should handle case-sensitive Bearer prefix")
	void testCaseSensitiveBearerPrefix() throws ServletException, IOException
	{
		// Given - lowercase "bearer"
		request.addHeader("Authorization", "bearer valid.jwt.token");
		request.setRequestURI("/fulfillment_task_api/v1/recombo/results");

		// When
		filter.doFilterInternal(request, response, filterChain);

		// Then - Should fail because it's case-sensitive
		verify(jwtTokenValidator, never()).validateToken(anyString());
		verify(filterChain, never()).doFilter(request, response);
		assertEquals(401, response.getStatus());
	}
}
