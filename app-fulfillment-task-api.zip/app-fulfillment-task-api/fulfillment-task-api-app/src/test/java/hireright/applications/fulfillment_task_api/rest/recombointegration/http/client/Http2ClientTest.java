/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.http.client;

import hireright.applications.fulfillment_task_api.rest.recombointegration.http.config.HttpClientConfig;
import hireright.applications.fulfillment_task_api.rest.recombointegration.http.config.JwtConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.http.HttpClient;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit tests for Http2Client
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@DisplayName("Http2Client Tests")
class Http2ClientTest
{

	private HttpClientConfig httpClientConfig;
	private JwtConfig jwtConfig;

	@BeforeEach
	void setUp()
	{
		httpClientConfig = new HttpClientConfig();
		ReflectionTestUtils.setField(httpClientConfig, "connectTimeoutSeconds", 10);
		ReflectionTestUtils.setField(httpClientConfig, "requestTimeoutSeconds", 30);
		ReflectionTestUtils.setField(httpClientConfig, "httpVersionString", "HTTP_2");
		ReflectionTestUtils.setField(httpClientConfig, "redirectPolicyString", "NORMAL");
		ReflectionTestUtils.setField(httpClientConfig, "enableCompression", true);

		jwtConfig = new JwtConfig();
		ReflectionTestUtils.setField(jwtConfig, "secretKey",
			"test-secret-key-that-is-long-enough-for-hmac-sha-256-algorithm");
		ReflectionTestUtils.setField(jwtConfig, "issuer", "hrg:hre:fulfillment");
		ReflectionTestUtils.setField(jwtConfig, "subject", "recombo-integration");
		ReflectionTestUtils.setField(jwtConfig, "expirationSeconds", 600);
	}

	@Test
	@DisplayName("Should build Http2Client successfully with required config")
	void testBuildWithRequiredConfig()
	{
		// When
		Http2Client client = Http2Client.builder().clientConfig(httpClientConfig).build();

		// Then
		assertNotNull(client);
	}

	@Test
	@DisplayName("Should build Http2Client successfully with JWT config")
	void testBuildWithJwtConfig()
	{
		// When
		Http2Client client =
			Http2Client.builder().clientConfig(httpClientConfig).jwtConfig(jwtConfig).build();

		// Then
		assertNotNull(client);
	}

	@Test
	@DisplayName("Should throw IllegalStateException when clientConfig is missing")
	void testBuildWithoutClientConfig()
	{
		// When & Then
		assertThrows(IllegalStateException.class, () -> Http2Client.builder().build());
	}

	@Test
	@DisplayName("Should create builder instance")
	void testBuilderCreation()
	{
		// When
		Http2Client.Builder builder = Http2Client.builder();

		// Then
		assertNotNull(builder);
	}

	@Test
	@DisplayName("Should set clientConfig in builder")
	void testBuilderSetClientConfig()
	{
		// When
		Http2Client.Builder builder = Http2Client.builder().clientConfig(httpClientConfig);

		// Then
		assertNotNull(builder);
	}

	@Test
	@DisplayName("Should set jwtConfig in builder")
	void testBuilderSetJwtConfig()
	{
		// When
		Http2Client.Builder builder =
			Http2Client.builder().clientConfig(httpClientConfig).jwtConfig(jwtConfig);

		// Then
		assertNotNull(builder);
	}

	@Test
	@DisplayName("Should handle null JWT config gracefully")
	void testBuildWithNullJwtConfig()
	{
		// When
		Http2Client client =
			Http2Client.builder().clientConfig(httpClientConfig).jwtConfig(null).build();

		// Then
		assertNotNull(client);
	}

	@Test
	@DisplayName("Should use HTTP_2 version from config")
	void testHttpVersionConfiguration()
	{
		// Given
		ReflectionTestUtils.setField(httpClientConfig, "httpVersionString", "HTTP_2");

		// When
		Http2Client client = Http2Client.builder().clientConfig(httpClientConfig).build();

		// Then
		assertNotNull(client);
		assertEquals(HttpClient.Version.HTTP_2, httpClientConfig.getHttpVersion());
	}

	@Test
	@DisplayName("Should use HTTP_1_1 version from config")
	void testHttp11VersionConfiguration()
	{
		// Given
		ReflectionTestUtils.setField(httpClientConfig, "httpVersionString", "HTTP_1_1");

		// When
		Http2Client client = Http2Client.builder().clientConfig(httpClientConfig).build();

		// Then
		assertNotNull(client);
		assertEquals(HttpClient.Version.HTTP_1_1, httpClientConfig.getHttpVersion());
	}

	@Test
	@DisplayName("Should use NORMAL redirect policy from config")
	void testNormalRedirectPolicy()
	{
		// Given
		ReflectionTestUtils.setField(httpClientConfig, "redirectPolicyString", "NORMAL");

		// When
		Http2Client client = Http2Client.builder().clientConfig(httpClientConfig).build();

		// Then
		assertNotNull(client);
		assertEquals(HttpClient.Redirect.NORMAL, httpClientConfig.getRedirectPolicy());
	}

	@Test
	@DisplayName("Should use NEVER redirect policy from config")
	void testNeverRedirectPolicy()
	{
		// Given
		ReflectionTestUtils.setField(httpClientConfig, "redirectPolicyString", "NEVER");

		// When
		Http2Client client = Http2Client.builder().clientConfig(httpClientConfig).build();

		// Then
		assertNotNull(client);
		assertEquals(HttpClient.Redirect.NEVER, httpClientConfig.getRedirectPolicy());
	}

	@Test
	@DisplayName("Should use connect timeout from config")
	void testConnectTimeoutConfiguration()
	{
		// Given
		ReflectionTestUtils.setField(httpClientConfig, "connectTimeoutSeconds", 15);

		// When
		Http2Client client = Http2Client.builder().clientConfig(httpClientConfig).build();

		// Then
		assertNotNull(client);
		assertEquals(Duration.ofSeconds(15), httpClientConfig.getConnectTimeout());
	}

	@Test
	@DisplayName("Should use request timeout from config")
	void testRequestTimeoutConfiguration()
	{
		// Given
		ReflectionTestUtils.setField(httpClientConfig, "requestTimeoutSeconds", 60);

		// When
		Http2Client client = Http2Client.builder().clientConfig(httpClientConfig).build();

		// Then
		assertNotNull(client);
		assertEquals(Duration.ofSeconds(60), httpClientConfig.getRequestTimeout());
	}

	@Test
	@DisplayName("Should enable compression when configured")
	void testCompressionEnabled()
	{
		// Given
		ReflectionTestUtils.setField(httpClientConfig, "enableCompression", true);

		// When
		Http2Client client = Http2Client.builder().clientConfig(httpClientConfig).build();

		// Then
		assertNotNull(client);
		assertTrue(httpClientConfig.isEnableCompression());
	}

	@Test
	@DisplayName("Should disable compression when configured")
	void testCompressionDisabled()
	{
		// Given
		ReflectionTestUtils.setField(httpClientConfig, "enableCompression", false);

		// When
		Http2Client client = Http2Client.builder().clientConfig(httpClientConfig).build();

		// Then
		assertNotNull(client);
		assertFalse(httpClientConfig.isEnableCompression());
	}

}
