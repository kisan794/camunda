/*
 * Copyright 2001-2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 */

package hireright.applications.fulfillment_task_api.rest.recombointegration.config;

import hireright.applications.fulfillment_task_api.rest.recombointegration.http.config.JwtConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Unit tests for JwtConfig
 *
 * @author Keshav Ladha
 * @version 1.0
 */
@Disabled("Temporarily disabled due to unstable behavior")
@DisplayName("JwtConfig Tests")
class JwtConfigTest
{

	private JwtConfig config;

	@BeforeEach
	void setUp()
	{
		config = new JwtConfig();
	}

	@Test
	@DisplayName("Should initialize with valid configuration")
	void testInitWithValidConfig()
	{
		// Given
		ReflectionTestUtils.setField(config, "secretKey", "test-secret-key");
		ReflectionTestUtils.setField(config, "issuer", "hrg:hre:fulfillment");
		ReflectionTestUtils.setField(config, "subject", "recombo-integration");
		ReflectionTestUtils.setField(config, "expirationSeconds", 600);

		// When & Then
		assertDoesNotThrow(() -> config.init());
	}

	@Test
	@DisplayName("Should throw exception when secret key is null")
	void testInitWithNullSecretKey()
	{
		// Given
		ReflectionTestUtils.setField(config, "secretKey", null);
		ReflectionTestUtils.setField(config, "expirationSeconds", 600);

		// When & Then
		assertThrows(IllegalStateException.class, () -> config.init());
	}

	@Test
	@DisplayName("Should throw exception when secret key is blank")
	void testInitWithBlankSecretKey()
	{
		// Given
		ReflectionTestUtils.setField(config, "secretKey", "   ");
		ReflectionTestUtils.setField(config, "expirationSeconds", 600);

		// When & Then
		assertThrows(IllegalStateException.class, () -> config.init());
	}

	@Test
	@DisplayName("Should throw exception when secret key is empty")
	void testInitWithEmptySecretKey()
	{
		// Given
		ReflectionTestUtils.setField(config, "secretKey", "");
		ReflectionTestUtils.setField(config, "expirationSeconds", 600);

		// When & Then
		assertThrows(IllegalStateException.class, () -> config.init());
	}

	@Test
	@DisplayName("Should throw exception when expiration seconds is zero")
	void testInitWithZeroExpirationSeconds()
	{
		// Given
		ReflectionTestUtils.setField(config, "secretKey", "test-secret-key");
		ReflectionTestUtils.setField(config, "expirationSeconds", 0);

		// When & Then
		assertThrows(IllegalStateException.class, () -> config.init());
	}

	@Test
	@DisplayName("Should throw exception when expiration seconds is negative")
	void testInitWithNegativeExpirationSeconds()
	{
		// Given
		ReflectionTestUtils.setField(config, "secretKey", "test-secret-key");
		ReflectionTestUtils.setField(config, "expirationSeconds", -100);

		// When & Then
		assertThrows(IllegalStateException.class, () -> config.init());
	}

	@Test
	@DisplayName("Should return correct secret key")
	void testGetSecretKey()
	{
		// Given
		String secretKey = "my-secret-key-12345";
		ReflectionTestUtils.setField(config, "secretKey", secretKey);

		// When
		String result = config.getSecretKey();

		// Then
		assertEquals(secretKey, result);
	}

	@Test
	@DisplayName("Should return correct issuer")
	void testGetIssuer()
	{
		// Given
		String issuer = "hrg:hre:fulfillment";
		ReflectionTestUtils.setField(config, "issuer", issuer);

		// When
		String result = config.getIssuer();

		// Then
		assertEquals(issuer, result);
	}

	@Test
	@DisplayName("Should return correct subject")
	void testGetSubject()
	{
		// Given
		String subject = "recombo-integration";
		ReflectionTestUtils.setField(config, "subject", subject);

		// When
		String result = config.getSubject();

		// Then
		assertEquals(subject, result);
	}

	@Test
	@DisplayName("Should return correct expiration seconds")
	void testGetExpirationSeconds()
	{
		// Given
		ReflectionTestUtils.setField(config, "expirationSeconds", 1800);

		// When
		int result = config.getExpirationSeconds();

		// Then
		assertEquals(1800, result);
	}

	@Test
	@DisplayName("Should return correct expiration time duration")
	void testGetExpirationTime()
	{
		// Given
		ReflectionTestUtils.setField(config, "expirationSeconds", 600);

		// When
		Duration duration = config.getExpirationTime();

		// Then
		assertEquals(Duration.ofSeconds(600), duration);
	}

	@Test
	@DisplayName("Should handle empty issuer")
	void testEmptyIssuer()
	{
		// Given
		ReflectionTestUtils.setField(config, "secretKey", "test-secret-key");
		ReflectionTestUtils.setField(config, "issuer", "");
		ReflectionTestUtils.setField(config, "expirationSeconds", 600);

		// When & Then
		assertDoesNotThrow(() -> config.init());
		assertEquals("", config.getIssuer());
	}

	@Test
	@DisplayName("Should handle empty subject")
	void testEmptySubject()
	{
		// Given
		ReflectionTestUtils.setField(config, "secretKey", "test-secret-key");
		ReflectionTestUtils.setField(config, "subject", "");
		ReflectionTestUtils.setField(config, "expirationSeconds", 600);

		// When & Then
		assertDoesNotThrow(() -> config.init());
		assertEquals("", config.getSubject());
	}

	@Test
	@DisplayName("Should convert different expiration seconds to duration")
	void testDifferentExpirationTimes()
	{
		// Test 5 minutes
		ReflectionTestUtils.setField(config, "expirationSeconds", 300);
		assertEquals(Duration.ofMinutes(5), config.getExpirationTime());

		// Test 1 hour
		ReflectionTestUtils.setField(config, "expirationSeconds", 3600);
		assertEquals(Duration.ofHours(1), config.getExpirationTime());

		// Test 1 day
		ReflectionTestUtils.setField(config, "expirationSeconds", 86400);
		assertEquals(Duration.ofDays(1), config.getExpirationTime());
	}

	@Test
	@DisplayName("Should handle very long secret key")
	void testVeryLongSecretKey()
	{
		// Given
		String longKey = "a".repeat(1000);
		ReflectionTestUtils.setField(config, "secretKey", longKey);
		ReflectionTestUtils.setField(config, "expirationSeconds", 600);

		// When & Then
		assertDoesNotThrow(() -> config.init());
		assertEquals(longKey, config.getSecretKey());
	}

	@Test
	@DisplayName("Should handle very large expiration seconds")
	void testVeryLargeExpirationSeconds()
	{
		// Given
		ReflectionTestUtils.setField(config, "secretKey", "test-secret-key");
		ReflectionTestUtils.setField(config, "expirationSeconds", Integer.MAX_VALUE);

		// When & Then
		assertDoesNotThrow(() -> config.init());
		assertEquals(Duration.ofSeconds(Integer.MAX_VALUE), config.getExpirationTime());
	}
}
