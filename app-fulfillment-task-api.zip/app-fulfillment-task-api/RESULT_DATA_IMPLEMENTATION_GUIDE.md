# Result Data Implementation Guide - Polymorphic Type Approach

## Overview

The `POST /{request-id}/results` endpoint handles two different payload types:
1. **Employment Fulfillment Results** (request-id contains `-EM-`)
2. **Education Fulfillment Results** (request-id contains `-ED-`)

## Implementation: Polymorphic Types (Type-Safe)

### Option 1: Flexible Single Class (CURRENT - SIMPLER)

**Location:** `fulfillment-task-api-model/src/main/java/hireright/applications/fulfillment_task_api/model/recombointegration/ResultData.java`

#### Pros:
- ✅ Simple implementation
- ✅ No code changes needed in existing services
- ✅ Jackson automatically ignores null fields during serialization
- ✅ Works with existing `TaskResultData` class

#### Cons:
- ❌ Less type-safe (both employment and education fields exist on same object)
- ❌ No compile-time validation of which fields should be populated

#### Structure:
```java
public class ResultData {
    // Employment fields
    private String employerOrgName;
    private PositionHistory positionHistory;
    
    // Education fields
    private String institutionName;
    private EducationQualifications qualifications;
    
    // Common fields
    private String city;
    private String region;
    private String country;
}
```

#### Usage Example:
```java
// Employment result - education fields will be null
ResultData employmentResult = ResultData.builder()
    .employerOrgName("Tech Innovations Inc.")
    .city("Berkeley")
    .region("CA")
    .country("US")
    .positionHistory(positionHistory)
    .build();

// Education result - employment fields will be null
ResultData educationResult = ResultData.builder()
    .institutionName("University of California, Berkeley")
    .city("Berkeley")
    .region("CA")
    .country("US")
    .qualifications(qualifications)
    .build();
```

---

### Option 2: Polymorphic Types (MORE TYPE-SAFE)

**Location:** `fulfillment-task-api-model/src/main/java/hireright/applications/fulfillment_task_api/model/recombointegration/polymorphic/`

#### Pros:
- ✅ Type-safe - compile-time validation
- ✅ Clear separation of employment vs education data
- ✅ Better for pattern matching and instanceof checks
- ✅ Follows OOP principles

#### Cons:
- ❌ More complex implementation
- ❌ Requires changes to `TaskResultData` to use `BaseResultData`
- ❌ Need to update service layer to handle polymorphic types

#### Structure:
```java
// Base class
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "resultType")
@JsonSubTypes({
    @JsonSubTypes.Type(value = EmploymentResultData.class, name = "EMPLOYMENT"),
    @JsonSubTypes.Type(value = EducationResultData.class, name = "EDUCATION")
})
public abstract class BaseResultData {
    private String city;
    private String region;
    private String country;
    public abstract String getResultType();
}

// Employment implementation
public class EmploymentResultData extends BaseResultData {
    private String employerOrgName;
    private PositionHistory positionHistory;
}

// Education implementation
public class EducationResultData extends BaseResultData {
    private String institutionName;
    private EducationQualifications qualifications;
}
```

#### Usage Example:
```java
// In service layer - type-safe handling
BaseResultData resultData = resultRequest.getData().getResultData();

if (resultData instanceof EmploymentResultData employment) {
    log.info("Processing employment result for: {}", 
        employment.getEmployerOrgName());
    // Access employment-specific fields
} else if (resultData instanceof EducationResultData education) {
    log.info("Processing education result for: {}", 
        education.getInstitutionName());
    // Access education-specific fields
}
```

---

## Request Type Detection

Both approaches use the `RequestTypeUtil` utility class to determine the request type:

```java
public class RequestTypeUtil {
    public static boolean isEmploymentRequest(String requestId) {
        return requestId != null && requestId.contains("-EM-");
    }
    
    public static boolean isEducationRequest(String requestId) {
        return requestId != null && requestId.contains("-ED-");
    }
    
    public static String getRequestType(String requestId) {
        if (isEmploymentRequest(requestId)) return "EMPLOYMENT";
        if (isEducationRequest(requestId)) return "EDUCATION";
        return "UNKNOWN";
    }
}
```

---

## Sample Payloads

### Employment Result
```json
{
  "specversion": "1.0",
  "id": "HE-010101-XXXXX-EM-001-CLASSIFICATION",
  "source": "hrg:hre:task",
  "type": "EmploymentFulfillmentResult",
  "datacontenttype": "application/json",
  "dataschema": "schemas/EmploymentFulfillmentResult.json",
  "data": {
    "decision": "VERIFIED_WITH_DISCREPANCY",
    "confidenceScore": 0.95,
    "decisionDescription": "Major discrepancy in title per guidelines",
    "riskIndicator": 1.0,
    "sourceReference": "56789",
    "resultData": {
      "employerOrgName": "Tech Innovations Inc.",
      "city": "Berkeley",
      "region": "CA",
      "country": "US",
      "positionHistory": {
        "title": "Software Engineer",
        "startDate": "2013-05-18",
        "endDate": "2017-05-22",
        "mostRecentHireDate": "2023-05-18",
        "employeeStatusCode": "8",
        "employeeStatus": "Inactive"
      }
    }
  }
}
```

### Education Result
```json
{
  "specversion": "1.0",
  "id": "HE-010101-XXXXX-ED-001-CLASSIFICATION",
  "source": "hrg:hre:task",
  "type": "EducationFulfillmentResult",
  "datacontenttype": "application/json",
  "dataschema": "schemas/EducationFulfillmentResult.json",
  "data": {
    "decision": "VERIFIED_WITH_DISCREPANCY",
    "confidenceScore": 0.95,
    "decisionDescription": "Major discrepancy in title per guidelines",
    "riskIndicator": 1.0,
    "resultData": {
      "institutionName": "University of California, Berkeley",
      "city": "Berkeley",
      "region": "CA",
      "country": "US",
      "qualifications": {
        "degree": "MS",
        "startDate": "2013-05-18",
        "endDate": "2017-05-22",
        "educationStatusCode": "8",
        "educationStatus": "Inactive"
      }
    }
  }
}
```

---

## Current Implementation Status

✅ **Option 1 (Flexible Single Class)** - IMPLEMENTED
- `ResultData.java` updated with both employment and education fields
- `EducationQualifications.java` created
- `RequestTypeUtil.java` created for type detection
- `ResultServiceImpl.java` updated with logging for request type
- Sample JSON files created in `src/main/resources/mock/`

⚠️ **Option 2 (Polymorphic Types)** - AVAILABLE BUT NOT ACTIVE
- Classes created in `polymorphic/` package
- `BaseResultData.java`, `EmploymentResultData.java`, `EducationResultData.java`
- `TaskResultDataPolymorphic.java` created as alternative
- To activate: Replace `ResultData` with `BaseResultData` in `TaskResultData.java`

---

## Recommendation

**Use Option 1 (Current Implementation)** because:
1. It's simpler and requires no changes to existing code
2. Jackson handles null fields gracefully
3. The API already works with both payload types
4. Request type detection is available via `RequestTypeUtil`

**Consider Option 2** if you need:
1. Strict type safety in business logic
2. Different processing logic for employment vs education
3. Compile-time validation of field usage
4. Better IDE support for field suggestions

---

## Testing

Test both payload types using the sample files:
```bash
# Employment result
curl -X POST http://localhost:8080/api/v1/HE-010101-XXXXX-EM-001-CLASSIFICATION/results \
  -H "Content-Type: application/json" \
  -d @src/main/resources/mock/employment-result-sample.json

# Education result
curl -X POST http://localhost:8080/api/v1/HE-010101-XXXXX-ED-001-CLASSIFICATION/results \
  -H "Content-Type: application/json" \
  -d @src/main/resources/mock/education-result-sample.json
```

Check logs for:
```
Processing EMPLOYMENT fulfillment result - Request ID: HE-010101-XXXXX-EM-001-CLASSIFICATION
Processing EDUCATION fulfillment result - Request ID: HE-010101-XXXXX-ED-001-CLASSIFICATION
```

