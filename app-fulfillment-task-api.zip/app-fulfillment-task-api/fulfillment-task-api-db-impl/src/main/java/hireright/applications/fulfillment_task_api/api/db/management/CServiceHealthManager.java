package hireright.applications.fulfillment_task_api.api.db.management;
/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 *
 * History:
 * M.Kuznetsov          2025-11-19  Created
 */

import hireright.applications.fulfillment_task_api.api.management.IServiceHealthManager;
import hireright.applications.fulfillment_task_api.model.CHealth;

/**
 * @author mkuznetsov
 */
public class CServiceHealthManager implements IServiceHealthManager {

    private static final CHealth PASS = new CHealth(CHealth.EStatus.pass);
    private static final CHealth FAIL = new CHealth(CHealth.EStatus.fail);

    @Override
    public CHealth getHealth() {
        return PASS;
    }
}
