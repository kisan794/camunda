package hireright.applications.fulfillment_task_api.api.log.management;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-07-21  HRG-332639 initial version
 */


import hireright.applications.fulfillment_task_api.api.management.ITestManager;

import hireright.lib.logging.log_activity.IActivityLogger;
import hireright.lib.logging.log_activity.model.CLogActivity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Function;

public class CTestManager implements ITestManager {
    private static final Logger LOGGER = LoggerFactory.getLogger(CTestManager.class);

    private final ITestManager delegate;
    private final IActivityLogger logger;

    public CTestManager(ITestManager delegate, IActivityLogger logger) {
        this.delegate = delegate;
        this.logger = logger;
    }

    @Override
    public void ok() {
        this.delegate.ok();

        try {
            CLogActivity.Builder log = new CLogActivity.Builder();

            log.activity("OK");
            log.text("ok test");

            this.logger.log(log.build());
        } catch (Exception e) {
            LOGGER.error("Failed to add an activity log", e);
        }
    }

    @Override
    public void error() {
        this.delegate.ok();
    }
}
