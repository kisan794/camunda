package hireright.applications.fulfillment_task_api.api.log;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 * M.Naumov   2025-05-22  HRG-337113 adding getOrderFormInstructionManager
 */

import hireright.applications.fulfillment_task_api.api.ITestApi;
import hireright.applications.fulfillment_task_api.api.log.management.CTestManager;
import hireright.applications.fulfillment_task_api.api.management.IServiceHealthManager;
import hireright.applications.fulfillment_task_api.api.management.ITestManager;
import hireright.lib.logging.log_activity.IActivityLogger;


public class CTestApi implements ITestApi {
    private final ITestApi delegate;
    private final IActivityLogger logger;

    public CTestApi(ITestApi delegate, IActivityLogger logger) {
        this.delegate = delegate;
        this.logger = logger;
    }

    @Override
    public ITestManager getTestManager() {
        return new CTestManager(this.delegate.getTestManager(), this.logger);
    }

    @Override
    public IServiceHealthManager getServiceHealthManager() {
        return this.delegate.getServiceHealthManager();
    }
}
