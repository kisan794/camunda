package hireright.applications.fulfillment_task_api.api.log;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-13  HRG-332327 initial version
 */

import hireright.applications.fulfillment_task_api.api.ITestApi;
import hireright.applications.fulfillment_task_api.api.ITestApiProvider;
import hireright.lib.logging.log_activity.CActivityLogger;
import hireright.lib.logging.log_activity.IActivityLogger;

public class CLoggingTestApiProvider implements ITestApiProvider {

    private final ITestApiProvider delegate;
    private final IActivityLogger m_logger;

    public CLoggingTestApiProvider(ITestApiProvider delegate,
            IActivityLogger logger) {
        this.delegate = delegate;
        this.m_logger = logger;
    }

    public CLoggingTestApiProvider(ITestApiProvider delegate) {
        this(delegate, CActivityLogger.DEFAULT);
    }


    @Override
    public ITestApi getApi() {
        return new CTestApi(this.delegate.getApi(), this.m_logger);
    }
}
