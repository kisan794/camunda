package hireright.applications.fulfillment_task_api.api.db.management;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-24  ATS-1045 initial version
 */

import hireright.applications.fulfillment_task_api.api.management.ITestManager;


public class CTestManager implements ITestManager {

    @Override
    public void ok() {

    }

    @Override
    public void error() {

    }
}
