package hireright.applications.fulfillment_task_api.api.validation.management;

/*
 * Copyright 2025 by HireRight, Inc. All rights reserved.
 * This software is the confidential and proprietary information
 * of HireRight, Inc. Use is subject to license terms.
 *
 * History:
 * S.Barinov  2025-03-27  ATS-1045 initial version
 */

import hireright.applications.fulfillment_task_api.api.management.ITestManager;

public class CTestManager implements ITestManager {

    private final ITestManager delegate;

    public CTestManager(ITestManager delegate) {
        this.delegate = delegate;
    }

    @Override
    public void ok() {
        this.delegate.ok();
    }

    @Override
    public void error() {
        this.delegate.error();
        throw new IllegalArgumentException("Always error");
    }
}
