Event example:
```xml
<Event version="2.0" id="25121001261615890863" typeID="936">
	<Domain id="BASE"/>
	<EventDate>2025-12-10T09:36:34 530</EventDate>
	<Parameters>
		<Parameter name="orderID">hrg:hre-us.devxx:ORDER:HE-111424-TC8CD</Parameter>
		<Parameter name="orderServiceID">hrg:hre-us.devxx:ORDER SERVICE:HE-111424-TC8CD-ED-002</Parameter>
		<Parameter name="customerID">hrg:hre-us.devxx:CUSTOMER:WSTST10</Parameter>
		<Parameter name="taskID">hrg:hre-us.devxx:task:purumpumpum2</Parameter>
	</Parameters>
</Event>
```

Env variables:

HRG_WEBAPP_LOGGING_INITIAL_GLX_POSTING_URL=http://172.24.227.100:8087/log_receiver/postGlx

HRG_JDBC_CTS_USER1_USERNAME=user1
HRG_JDBC_CTS_USER1_PASSWORD=user1
HRG_JDBC_CTS_USER1_HOST=172.24.227.100
HRG_JDBC_CTS_USER1_PORT=1521
HRG_JDBC_CTS_USER1_SERVICE=hr2.devxx

HRG_SECRET_KEY=N43iHLSmad3IWJVSlk3nQ+LwR4+3Snb3WodQ7R/7FCE=Y
RECOMBO_SECRET_KEY=R43iHLSmad3IWJVSlk3nQ+LwR4+3Snb3WodQ7R/7FCE=

HRG_JMS_RABBITMQ_CONSUMER_USERNAME=consumer
HRG_JMS_RABBITMQ_CONSUMER_PASSWORD=Iv168n6377
HRG_JMS_RABBITMQ_CONSUMER_HOST=172.24.227.100
HRG_JMS_RABBITMQ_CONSUMER_PORT=5672